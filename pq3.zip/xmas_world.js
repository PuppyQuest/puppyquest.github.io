/* ================================================================
   Christmas Snow: the islands at Christmas (25 Nov 2026, claude/christmas-snow-design.md)
   - Pawprint Village: the giant tree (dark until the star is home), the Christmas market and its
     lights, the ice rink, carol-singing pups, the Snow Globe and the Season Calendar house;
   - a decorated tree and fairy lights on every island, and each island's surprise: Meadow's snowman,
     the Reef's coral tree, Sensei Mochi's snowball dojo, the Advent Calendar, the Rescue Bay lights
     switch-on, the long-neck tree, and floating sprouts at Christmas dinner on Moon Base;
   - the two spotlights: the Sleigh Run (Snowy Summit) and Tinker's Toy Factory with Toy Packing;
   - Professor Fizz's winter experiment, the Christmas Den, carols and sleigh bells, real-date extras.
   Hooks: XWORLD.build(A) (while an area is built, Christmas only), XWORLD.after(A), COLLECT, QUIZ, regAct, TUNES.
   ================================================================ */
(function(){
const XM=window.XMAS,PI=Math.PI,RED='#d9363e',GRN='#2f9a54',GLD='#ffd23f',BULB=['#ff4f5e','#ffd23f','#5cb8ff','#5fe07a','#ff7fd0'];
const X=()=>XM.XS(),acts=()=>{const s=X();s.acts=s.acts||{};return s.acts;};
const lit=()=>!!X().lit;
/* ---------------- helpers ---------------- */
function clearAt(x,z,r,ymax){for(const k in instMap){const o=instMap[k];o.m=o.m.filter(m=>{const e=m.elements;return !(Math.hypot(e[12]-x,e[14]-z)<r&&(ymax==null||e[13]<ymax));});}}
function bulbs(pts,on,s){s=s||.13;const m=new THREE.MeshBasicMaterial({color:on?'#ffffff':'#4a4d55'}),im=new THREE.InstancedMesh(G.sph,m,Math.max(1,pts.length)),M4=new THREE.Matrix4(),c=new THREE.Color();
  pts.forEach((p,i)=>{M4.makeScale(s,s*1.3,s);M4.setPosition(p[0],p[1],p[2]);im.setMatrixAt(i,M4);im.setColorAt(i,c.set(p[3]||BULB[i%5]));});if(im.instanceColor)im.instanceColor.needsUpdate=true;
  im.count=pts.length;im.frustumCulled=false;W.ag.add(im);W.disp.push(m);const o={im,m,on:!!on,set(v){o.on=v;m.color.set(v?'#ffffff':'#4a4d55');}};BL.push(o);return o;}
let BL=[];
function strand(a,b,n,sag){const out=[];for(let i=0;i<=n;i++){const t=i/n;out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t-Math.sin(t*PI)*(sag==null?.8:sag),a[2]+(b[2]-a[2])*t]);}return out;}
/* a Christmas tree: s scale; o.lights 'on'/'off'/null, o.star */
function xtree(x,z,s,o){o=o||{};const y=gy(x,z),R=seed(Math.round(x*13+z*7)+3);I('cyl','#7a4a28',.5*s,1.6*s,.5*s,x,y+.8*s,z);
  const T=[[2.6,2.4,1.6],[2.1,2.2,3],[1.6,2,4.3],[1.05,1.8,5.5]];T.forEach(q=>I('cone',q===T[0]?'#2a7a44':'#2f8a4a',q[0]*s,q[1]*s,q[0]*s,x,y+q[2]*s+q[1]*s*.5,z));
  for(let i=0;i<4;i++)I('cone','#ffffff',T[i][0]*s*.55,.25*s,T[i][0]*s*.55,x,y+T[i][2]*s+T[i][1]*s*.95,z);
  const pts=[];for(let i=0;i<(o.n||26);i++){const t=i/(o.n||26),h=1.7+t*4.6,r=(2.5-t*2.1)*.92,a=i*2.4;pts.push([x+Math.cos(a)*r*s,y+h*s,z+Math.sin(a)*r*s]);}
  pts.forEach((p,i)=>{if(i%2)I('sph',BULB[(i>>1)%5],.24*s,.24*s,.24*s,p[0],p[1]-.1*s,p[2]);});
  let L=null;if(o.lights)L=bulbs(pts.filter((p,i)=>!(i%2)).map(p=>[p[0],p[1]+.15*s,p[2]]),o.lights==='on',.12*s+.02);
  let st=null;if(o.star!==false)st=star3D(x,y+8.1*s,z,.9*s,o.star!=='off');col(x,z,1.3*s);return {L,st,top:[x,y+8.1*s,z]};}
function star3D(x,y,z,s,on){const g=grp();for(let i=0;i<5;i++){const c=mk('cone',GLD,.28,1,.12,0,0,0,g,on);c.rotation.z=i*PI*2/5;c.position.set(-Math.sin(i*PI*2/5)*.5,Math.cos(i*PI*2/5)*.5,0);}mk('sph',GLD,.42,.42,.2,0,0,0,g,on);
  g.scale.setScalar(s);g.position.set(x,y,z);W.ag.add(g);g.visible=!!on;W.ticks.push(()=>{g.rotation.y=W.t*.8;});return g;}
function snowman(x,z,s,col2,grey){const y=gy(x,z),C=grey?'#cfd2da':'#ffffff';I('sph',C,1.1*s,1*s,1.1*s,x,y+.9*s,z);I('sph',C,.8*s,.75*s,.8*s,x,y+2.3*s,z);I('sph',C,.55*s,.55*s,.55*s,x,y+3.4*s,z);
  I('cyl','#26232e',.4*s,.55*s,.4*s,x,y+4.1*s,z);I('cyl','#26232e',.62*s,.06*s,.62*s,x,y+3.85*s,z);I('cone','#ff8a3c',.1*s,.5*s,.1*s,x,y+3.4*s,z+.6*s,PI/2,0,0);
  I('tor',col2||RED,.6*s,.6*s,.6*s,x,y+2.95*s,z,PI/2,0,0);[-.15,.15].forEach(q=>I('sph','#26232e',.07*s,.07*s,.07*s,x+q*s,y+3.55*s,z+.48*s));col(x,z,1.1*s);}
function sayOnce(k,m){const a=acts();if(a['s_'+k])return;a['s_'+k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say(m);},1600);}
const D=()=>XM.deer().name;

/* ================= Pawprint Village ================= */
const MK=[[9.5,21,'☕ Hot chocolate','#7a4a2a'],[9.5,28,'🍪 Gingerbread','#c8844a'],[9.5,35,'🎄 Decorations','#2f8a4a']];
function stall(x,z,name,c){const y=gy(x,z);I('box','#9b6a43',1.1,1.1,2.8,x,y+.55,z);I('box','#fff8e6',1.2,.12,2.9,x,y+1.12,z);[-1.3,1.3].forEach(q=>{I('cyl','#7a4a28',.1,2.8,.1,x+.45,y+1.4,z+q);I('cyl','#7a4a28',.1,2.8,.1,x-.5,y+1.4,z+q);});
  for(let i=0;i<5;i++)I('box',i%2?'#ffffff':RED,1.5,.12,.62,x,y+2.85-.1,z-1.24+i*.62,0,0,-.2);
  const l=label(name,5.5,'#fffdf5');l.position.set(x-.2,y+3.7,z);W.ag.add(l);rect(x-.6,z-1.5,x+.6,z+1.5);
  bulbs(strand([x-.7,y+2.6,z-1.4],[x-.7,y+2.6,z+1.4],8,.25),true,.09);
  if(/chocolate/.test(name))for(let i=0;i<5;i++){I('cyl','#ffffff',.14,.22,.14,x-.2,y+1.3,z-1+i*.5);I('cyl','#7a4a2a',.12,.02,.12,x-.2,y+1.42,z-1+i*.5);}
  if(/Ginger/.test(name))for(let i=0;i<6;i++)I('cyl','#c8844a',.22,.05,.22,x-.2+(i%2)*.2,y+1.22,z-1.1+i*.44);
  if(/Decor/.test(name))for(let i=0;i<7;i++)I('sph',BULB[i%5],.16,.16,.16,x-.2+(i%2)*.25,y+1.32,z-1.1+i*.37);}
function villageX(A){
  /* the fountain freezes, and the giant tree stands in its place */
  clearAt(0,5,3.2,4.2);W.ticks=W.ticks.filter(f=>!/💧/.test(String(f)));
  const T=xtree(0,5,1.55,{lights:lit()?'on':'off',star:lit()?'on':'off',n:40});XWORLD.tree=T;
  const LP=[25,108,180,-68].map(a=>[Math.cos(a*D2R)*11.5,Math.sin(a*D2R)*11.5]);for(let i=0;i<4;i++){const a=LP[i],b=LP[(i+1)%4];bulbs(strand([a[0],4.0,a[1]],[b[0],4.0,b[1]],16,.9),true,.1);}
  /* the Christmas market, and Holly hiding behind it */
  MK.forEach(m=>{stall(m[0],m[1],m[2],m[3]);W.things.push({x:m[0]-2.2,z:m[1],r:3.2,icon:m[2].slice(0,2),label:m[2].slice(2).trim(),act:()=>market(m)});});
  /* the ice rink */
  const rx=22,rz=5,y=gy(rx,rz),ice=new THREE.Mesh(G.disc,new THREE.MeshLambertMaterial({color:'#d8f0fb'}));ice.scale.set(5,1,5);ice.position.set(rx,y+.07,rz);W.ag.add(ice);W.disp.push(ice.material);
  for(let i=0;i<24;i++){const a=i/24*PI*2,b2=(i+.5)/24*PI*2;I('cyl','#ffffff',.12,.8,.12,rx+Math.cos(a)*5.3,y+.4,rz+Math.sin(a)*5.3);I('box',i%2?RED:'#ffffff',1.42,.16,.12,rx+Math.cos(b2)*5.3,y+.72,rz+Math.sin(b2)*5.3,0,-b2+PI/2,0);}
  for(let i=0;i<4;i++){const a=i*PI/2+.4;I('sph','#ffffff',.5,.3,.5,rx+Math.cos(a)*6.2,y+.15,rz+Math.sin(a)*6.2);}
  sign(rx-6.5,rz+3,'⛸️ Ice Rink',3,5);W.things.push({x:rx-5.6,z:rz,r:3.6,icon:'⛸️',label:'Skate',act:()=>skate(rx,rz)});
  /* carol singers */
  carols(A);
  /* the Snow Globe and the Season Calendar */
  globe3D(-5.5,9);calHouse(-9,-18);
  sayOnce('village','Welcome to Christmas Snow in Pawprint Village! Look at the Christmas market and the ice rink. Shake the Snow Globe to go back to the islands as they are.');}
function globe3D(x,z){const y=gy(x,z);I('cyl','#7a4a28',.9,.7,.9,x,y+.35,z);I('cyl','#c9a070',.95,.12,.95,x,y+.72,z);I('cyl','#ffffff',.8,.15,.8,x,y+.85,z);I('cone','#2f8a4a',.35,.9,.35,x,y+1.4,z);I('sph',GLD,.08,.08,.08,x,y+1.9,z,0,0,0,true);
  const gl=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#dff4ff',transparent:true,opacity:.28,depthWrite:false}));gl.scale.setScalar(1);gl.position.set(x,y+1.6,z);W.ag.add(gl);W.disp.push(gl.material);col(x,z,1.1);
  const P=new Float32Array(30),fg=new THREE.BufferGeometry();fg.setAttribute('position',new THREE.BufferAttribute(P,3));const fm=new THREE.PointsMaterial({color:'#ffffff',size:.14});const fp=new THREE.Points(fg,fm);fp.frustumCulled=false;W.ag.add(fp);W.disp.push(fg,fm);
  W.ticks.push(()=>{for(let i=0;i<10;i++){const a=W.t*.7+i;P[i*3]=x+Math.cos(a)*.6;P[i*3+1]=y+1.2+((W.t*.3+i*.11)%1)*.9;P[i*3+2]=z+Math.sin(a*1.3)*.6;}fg.attributes.position.needsUpdate=true;});
  const l=label(XM.on()?'🔮 Snow Globe':'🔮 Season Globe',4.6);l.position.set(x,y+3.2,z);W.ag.add(l);W.things.push({x,z:z+1.6,r:3.4,icon:'🔮',label:'Snow Globe',act:()=>XM.globe()});}
function calHouse(x,z){const y=gy(x,z);I('box','#c8844a',4,3,3,x,y+1.5,z);I('pyr','#fff8e6',3.4,1.8,2.6,x,y+3.9,z,0,PI/4,0);I('box','#ffffff',4.2,.22,3.2,x,y+3.05,z);I('box','#8a4a22',1,1.6,.1,x,y+.8,z+1.52);
  for(let i=0;i<8;i++)I('sph',BULB[i%5],.18,.18,.18,x-1.75+i*.5,y+3.2,z+1.6);for(let i=0;i<3;i++)for(let j=0;j<2;j++)if(!(i===1&&j===0))I('box',(i+j)%2?'#ffd86a':'#5a3a2a',.6,.5,.06,x-1.3+i*1.3,y+1+j*1.1,z+1.52,0,0,0,(i+j)%2===1);
  col(x,z,2.4);const l=label('🏠 Season Calendar',6);l.position.set(x,y+5.4,z);W.ag.add(l);W.things.push({x,z:z+3.2,r:3.4,icon:'🏠',label:'Calendar',act:()=>XM.calendar()});}
function carols(A){const ids=Object.keys(state.found).filter(id=>PUPS[id]&&teamIds().indexOf(id)<0);if(ids.length<3)return;const R=seed(1225),pk=[];while(pk.length<3){const id=ids[Math.floor(R()*ids.length)];if(pk.indexOf(id)<0)pk.push(id);}
  const P=[[6.5,-8.5],[8.6,-6.6],[10.2,-4.2]];pk.forEach((id,i)=>{const g=pup3D(PUPS[id]);add(g,P[i][0],P[i][1]);g.rotation.y=Math.atan2(-P[i][0],-P[i][1]);col(P[i][0],P[i][1],.8);W.ticks.push(()=>{animPup(g,W.t+i,false);});});
  let nt=0;W.ticks.push(dt=>{nt-=dt;if(nt<0){nt=.7;const q=P[Math.floor(Math.random()*3)];floatS(pick(['🎵','🎶']),q[0],gy(q[0],q[1])+2.6,q[1],1.2,1.6);}});
  W.things.push({x:8,z:-5,r:3.6,icon:'🎶',label:'Carols',act:()=>{sfx.chime();XWORLD.carol=W.t+30;say('The pups are singing Deck the Halls! Fa la la la la, la la la la!');}});}
function market(m){if(player.lock)return;sfx.chime();
  if(/chocolate/.test(m[2])){player.cheer=1.4;followers.forEach(f=>{f.grp.userData.jump=.5;floatS('☕',f.x,gy(f.x,f.z)+2.6,f.z,1.4);});say(`Mr Crumbs pours hot chocolate for you and your pups. Mmm, warm and chocolatey! ${D()} has a sip too, and gets a chocolate moustache!`);return;}
  if(/Ginger/.test(m[2])){player.cheer=1.4;followers.forEach(f=>{floatS('🍪',f.x,gy(f.x,f.z)+2.6,f.z,1.4);});say('Gingerbread pups! Mr Crumbs made a gingerbread biscuit shaped like every pup on the islands. Crunch!');return;}
  const a=acts();if(a.den){say('Your den is all decorated for Christmas! Pop in and see it.');return;}
  card({art:'<div style="font-size:100px;line-height:1">🎄🧦🔥</div>',h:'Christmas decorations for your den',p:'Mr Crumbs has a little Christmas tree, stockings for your pups and a cosy fireplace. Decorate your den for 30 stars?',
    btns:[[state.stars>=30?'⭐ 30 Yes please!':'Not enough stars yet','green',()=>{if(state.stars<30){sfx.oops();say('You need 30 stars. Find more Christmas pups to earn stars!');return;}state.stars-=30;a.den=Date.now();save();hud();sfx.fanfare();confetti(30);say('Your den is decorated for Christmas! Pop in and see it.');}],['Not now','white']]});}
function skate(rx,rz){if(player.lock)return;player.lock=true;XM.DEER.script=true;sfx.chime();say(`Wheee! You skate round the ice rink with your pups. ${D()} is a bit wobbly on the ice!`);let t=0;const a0=Math.atan2(player.z-rz,player.x-rx);
  W.ticks.push(dt=>{t+=dt;const a=a0+t*1.5,r=3.4;player.x=rx+Math.cos(a)*r;player.z=rz+Math.sin(a)*r;player.h=a+PI;player.moving=true;
    followers.forEach((f,i)=>{const b=a-.7*(i+1);f.x=rx+Math.cos(b)*(r-.6);f.z=rz+Math.sin(b)*(r-.6);f.h=b+PI;});
    if(XM.DEER.g){const b=a+.9;XM.DEER.x=rx+Math.cos(b)*2;XM.DEER.z=rz+Math.sin(b)*2;XM.DEER.g.position.set(XM.DEER.x,walkY(XM.DEER.x,XM.DEER.z),XM.DEER.z);XM.DEER.g.rotation.y=b+PI;XM.DEER.g.rotation.z=Math.sin(t*6)*.15;}
    if(t>8.5){player.lock=false;XM.DEER.script=false;if(XM.DEER.g)XM.DEER.g.rotation.z=0;acts().skate=1;save();say('What a lovely skate!');return true;}});}

/* ================= the islands ================= */
const ISL={};
/* Meadow: lights on the windmill, a tree, and the snowman to build */
ISL.windmill=A=>{xtree(-6,28,.9,{lights:'on',star:'on'});const T=[];for(let i=0;i<46;i++){const a=i*.55,h=1+i*.22;T.push([Math.cos(a)*3.3,h,-14+Math.sin(a)*3.3]);}bulbs(T,true,.12);
  snowmanSite(-13,24);sayOnce('meadow','Snow on Meadow Island! Look, the windmill is covered in fairy lights. You could build a snowman by the tree!');};
function snowmanSite(x,z){const a=acts(),y=gy(x,z);if(a.snowman){const s=a.snowman;snowman(x,z,.9,s.c,false);if(s.h==='top')0;}
  else{I('sph','#ffffff',.5,.4,.5,x,y+.2,z);sign(x-2.4,z+1.5,'⛄ Build a snowman',3,6);}
  W.things.push({x,z:z+2.4,r:3.6,icon:'⛄',label:a.snowman?'Snowman':'Build',act:()=>buildSnowman(x,z)});}
function buildSnowman(x,z){if(player.lock)return;const a=acts();if(a.snowman){sfx.chime();say('Your snowman waves hello! "Happy Christmas!" he says. Well, he would, if snowmen could talk.');return;}
  player.lock=true;let n=0;const roll=()=>{n++;XM.snd.crunch();player.cheer=1;
    if(n<3){say(['Roll a big snowball for the bottom! Tap again for the middle.','Now the middle snowball! Tap once more for the head.'][n-1]);card({art:`<div style="font-size:${60+n*25}px;line-height:1">⚪</div>`,h:`Snowball ${n}!`,p:n===1?'A big snowball for the bottom!':'A middle snowball!',say:false,btns:[['❄️ Roll another!','green',roll]]});return;}
    card({art:'<div style="font-size:100px;line-height:1">⛄</div>',h:'Pick a scarf!',p:'Which colour scarf for your snowman?',btns:[['🔴 Red','green',()=>done(RED)],['🟢 Green','green',()=>done(GRN)],['🔵 Blue','blue',()=>done('#3d8fe0')]]});};
  const done=c=>{a.snowman={c,at:Date.now()};save();player.lock=false;sfx.fanfare();confetti(40);XM.snd.bells(6);say('Your snowman is finished! He waves at you with his twiggy arm!');if(window.XSTORY&&XSTORY.award)XSTORY.award();
    snowman(x,z,.9,c,false);flushTo(W.ag);};
  sfx.chime();say('Let\'s build a snowman! Tap to roll the snowballs.');roll();}
/* Snowy Summit: lights on the hut and the Sleigh Run */
ISL.hut=A=>{xtree(10,24,1,{lights:'on'});bulbs(strand([-8,8,-14],[4,8,-14],16,.6),true,.12);
  const P=SLEIGH.items;for(let i=0;i<10;i++){const a=i/10*PI*2+.3,x=Math.cos(a)*27,z=Math.sin(a)*24-2,y=gy(x,z),h=a+PI/2;
    [-1,1].forEach(s=>I('cyl','#ffffff',.2,4.2,.2,x+Math.cos(h)*s*2.4,y+2.1,z+Math.sin(h)*s*2.4));bulbs(strand([x-Math.cos(h)*2.4,y+4.2,z-Math.sin(h)*2.4],[x+Math.cos(h)*2.4,y+4.2,z+Math.sin(h)*2.4],8,-.6),true,.12);}
  sign(-1,32,'🛷 Sleigh Run',3,5.5);W.things.push({x:1,z:31,r:4,icon:'🛷',label:'Sleigh Run',act:startSleigh});
  sayOnce('snowy','Look! A Sleigh Run starts at the Mountain Hut. '+(XM.nSp()>=3?`${D()} can pull the sleigh!`:`Bring home 3 star sparkles, and ${D()} will be brave enough to pull the sleigh.`));};
ISL.lift=A=>{xtree(-12,30,1,{lights:'on'});};
/* Coral Reef: the coral tree and its jellyfish lights */
ISL.lagoon=A=>{const x=0,z=-12,y=gy(x,z),a=acts();for(let i=0;i<5;i++){const s=1-i*.18;for(let k=0;k<7;k++){const an=k/7*PI*2+i;I('cyl',['#ff7f9a','#ff9a5a','#ffb3c8'][k%3],.18,2.4*s,.18,x+Math.cos(an)*2.2*s,y+1+i*1.6,z+Math.sin(an)*2.2*s,Math.sin(an)*.6,0,-Math.cos(an)*.6);}}
  I('sph','#ffd23f',.5,.5,.5,x,y+9.2,z,0,0,0,true);col(x,z,2.4);
  const P=[];for(let i=0;i<18;i++){const t=i/18,an=i*2.3;P.push([x+Math.cos(an)*(2.8-t*2),y+1.4+t*7.2,z+Math.sin(an)*(2.8-t*2),BULB[i%5]]);}const L=bulbs(P,!!a.coral,.28);
  const jel=[];for(let i=0;i<6;i++){const m=new THREE.Mesh(G.hemi,new THREE.MeshBasicMaterial({color:BULB[i%5],transparent:true,opacity:.6,depthWrite:false}));m.scale.set(.6,.5,.6);W.ag.add(m);W.disp.push(m.material);jel.push(m);}
  W.ticks.push(()=>{jel.forEach((m,i)=>{const an=W.t*.4+i*1.05;m.position.set(x+Math.cos(an)*4.2,y+4+i*.8+Math.sin(W.t*1.3+i)*.4,z+Math.sin(an)*4.2);m.scale.y=.5+Math.sin(W.t*3+i)*.12;});});
  sign(x+3.6,z+3.6,'🎄 Coral Tree',3,5);W.things.push({x,z:z+4,r:4.2,icon:'✨',label:'Light it',act:()=>{if(player.lock)return;sfx.chime();let k=0;
    const step=()=>{k++;const n=Math.min(P.length,k*3);L.im.count=n;L.set(true);XM.snd.twinkle();if(n<P.length)setTimeout(step,260);else{a.coral=1;save();confetti(30);say('The jellyfish swim round and light up the coral tree! What you give comes back to you, like the tide.');}};L.im.count=0;step();}});};
/* Ninja Mountains: lanterns and the snowball dojo */
ISL.dojo=A=>{xtree(-10,26,1,{lights:'on'});for(let i=0;i<8;i++){const x=-14+i*4,z=8;I('sph',i%2?RED:GRN,.55,.7,.55,x,gy(x,z)+8.2,z,0,0,0,true);I('cyl','#26232e',.6,.1,.6,x,gy(x,z)+8.95,z);}
  bulbs(strand([-16,9.2,8],[16,9.2,8],24,.5),true,.08);snowDojo();};
const TGT=[[-30,-12],[-26,-17],[-21,-19],[-16,-17],[-12,-12],[-24,-8]];
function snowDojo(){const a=acts(),st={hit:{},n:0,t0:0};TGT.forEach((q,i)=>{const y=gy(q[0],q[1]);I('cyl','#7a4a28',.2,2.4,.2,q[0],y+1.2,q[1]);const g=grp();mk('cyl','#ffffff',.8,.15,.8,0,0,0,g);mk('cyl',RED,.55,.17,.55,0,0,0,g);mk('cyl','#ffffff',.3,.19,.3,0,0,0,g);mk('cyl',RED,.12,.21,.12,0,0,0,g);
    g.rotation.x=PI/2;g.position.set(q[0],y+2.9,q[1]);g.rotation.z=0;W.ag.add(g);st['g'+i]=g;col(q[0],q[1],.4);});
  sign(-36,-4,'❄️ Snowball Dojo',3,6);W.things.push({x:-21,z:-11,r:9,icon:'❄️',label:'Throw!',act:()=>throwSnow(st)});}
function throwSnow(st){if(player.lock)return;const P=player;let best=-1,bd=1e9;TGT.forEach((q,i)=>{if(st.hit[i])return;const d=Math.hypot(q[0]-P.x,q[1]-P.z);if(d<bd){bd=d;best=i;}});if(best<0)return;
  if(!st.n){st.t0=W.t;say('Sensei Mochi\'s snowball dojo! Knock all 6 targets off their posts!');}
  const q=TGT[best],sp=sprite('⚪',.9);scene.add(sp);let k=0;const x0=P.x,z0=P.z,y0=P.y+2.4,g=st['g'+best];player.h=Math.atan2(q[0]-P.x,q[1]-P.z);player.wave=.8;XM.snd.crunch();
  W.ticks.push(dt=>{k+=dt*2.2;const e=Math.min(1,k);sp.position.set(x0+(q[0]-x0)*e,y0+(g.position.y-y0)*e+Math.sin(e*PI)*2.5,z0+(q[1]-z0)*e);if(e<1)return;scene.remove(sp);
    st.hit[best]=1;st.n++;XM.snd.whump();floatS('❄️',q[0],g.position.y,q[1],2);let f=0;W.ticks.push(dt2=>{f+=dt2;g.rotation.y=f*8;g.position.y-=dt2*6;if(g.position.y<gy(q[0],q[1])+.2){g.position.y=gy(q[0],q[1])+.2;return true;}});
    if(st.n>=6){const secs=W.t-st.t0;setTimeout(()=>finishAct('snowdojo',secs,'<div style="font-size:110px;line-height:1">❄️🎯</div>','You knocked down every target! Sensei Mochi bows to you.',()=>{},true),600);}
    else say(`${st.n}! ${6-st.n} more ${6-st.n>1?'targets':'target'}!`);return true;});}
/* Number Kingdom: a number tree and the Advent Calendar on the clock tower */
ISL.ntown=A=>{const T=xtree(14,24,1,{lights:'on'});for(let i=1;i<=9;i++){const a=i*2.2,h=1.8+i*.55,r=2.3-i*.2;spr(['','1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣'][i],.7,14+Math.cos(a)*r,gy(14,24)+h,24+Math.sin(a)*r);}
  advent3D();};
function adventTex(){const c=document.createElement('canvas');c.width=256;c.height=384;const g=c.getContext('2d'),d=new Date(),day=d.getMonth()===11?d.getDate():0,a=acts().adv||{};
  g.fillStyle='#2f8a4a';g.fillRect(0,0,256,384);g.fillStyle='#ffd23f';g.font='bold 30px Arial';g.textAlign='center';g.fillText('ADVENT',128,36);
  for(let i=0;i<24;i++){const x=12+(i%4)*60,y=54+Math.floor(i/4)*54,n=i+1;g.fillStyle=a[n]?'#fff3c2':n===day?'#ffd23f':['#d9363e','#c8844a','#5b8def','#8a5ad6'][i%4];g.fillRect(x,y,52,46);g.strokeStyle='#26232e';g.lineWidth=3;g.strokeRect(x,y,52,46);
    g.fillStyle=n===day?'#d9363e':'#fff';g.font='bold 24px Arial';g.fillText(String(n),x+26,y+32);}
  const t=new THREE.CanvasTexture(c);W.disp.push(t);return t;}
function advent3D(){const y=gy(0,-6),m=new THREE.Mesh(new THREE.PlaneGeometry(3.4,5.1),new THREE.MeshBasicMaterial({map:adventTex()}));m.position.set(0,y+5.2,-3.97);W.ag.add(m);W.disp.push(m.geometry,m.material);XWORLD.adv=m;
  W.things.push({x:0,z:-1.4,r:3.4,icon:'🗓️',label:'Advent',act:openAdvent});}
const ADV=['What do snowmen eat for lunch? Iceberg-ers!','2 + 2 = 4. And 4 reindeer + 4 reindeer = 8 reindeer!','What do you call a cat on the beach at Christmas? Sandy Claws!','There are 12 days of Christmas. 12 is 3 lots of 4!',
 'What is a reindeer\'s favourite game? Stable tennis!','A snowflake has 6 points. 2 snowflakes have 12 points!','Why did the robin cross the road? It was the chicken\'s day off!','10 + 10 = 20. That\'s a lot of presents!',
 'What do elves learn at school? The elf-abet!','Count back from 10 to 1, then shout Happy Christmas!','What falls but never gets hurt? Snow!','Half of 24 is 12. And 24 is Christmas Eve!',
 'What does a snowman call his dog? A slush puppy!','A week has 7 days. 3 weeks is 21 days!','Why was the Christmas tree bad at knitting? It kept dropping its needles!','Double 8 is 16. Double 16 is 32!',
 'What do you get if you cross a bell with a skunk? Jingle smells!','5 pups + 5 pups + 5 pups = 15 pups!','What is a polar bear\'s favourite food? Ice-burgers!','100 is ten lots of 10.',
 'How do sheep say Happy Christmas? Fleece Navidad!','9 + 9 = 18. Try counting on from 9!','What do you call a penguin in the desert? Lost!','Christmas Eve! Tomorrow is the 25th. 25 is 5 lots of 5!'];
function openAdvent(){if(player.lock)return;sfx.chime();const d=new Date(),day=d.getMonth()===11&&d.getDate()<=24?d.getDate():0,a=acts();a.adv=a.adv||{};
  const c=$('#menuCard');c.className='card wide';c.innerHTML=`<h2>🗓️ The Advent Calendar</h2><div class="xadv">${ADV.map((t,i)=>`<button class="xad${a.adv[i+1]?' open':''}${i+1===day?' today':''}" data-n="${i+1}">${a.adv[i+1]?'⭐':i+1}</button>`).join('')}</div><p id="xadMsg">${day?`Today is the ${day}${['th','st','nd','rd'][day%10>3||Math.floor(day/10)===1?0:day%10]} of December. Door ${day} glows! Open it for 10 stars.`:'Open a door for a number fact or a Christmas joke!'}</p><div class="btns"><button class="btn white" data-n="0">Close ✕</button></div>`;
  $('#menu').classList.add('on');
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();const n=+b.dataset.n;if(!n){sfx.boop();$('#menu').classList.remove('on');c.onclick=null;if(XWORLD.adv)XWORLD.adv.material.map=adventTex();return;}
    sfx.pop();let m=ADV[n-1];if(n===day&&!a.adv[n]){state.stars+=10;m+=' And 10 stars for opening today\'s door!';confetti(20);hud();}a.adv[n]=1;save();b.classList.add('open');b.textContent='⭐';$('#xadMsg').textContent=m;speak(m);};}
/* Gadget Island: Tinker's Toy Factory */
ISL.factory=A=>{const G2=window.GADGET2;if(G2&&G2.MAZE){const M=G2.MAZE,Z=G2.MZ;
    /* ribbons and bows turn the containers into giant presents */
    for(let i=0;i<Z.n;i++)for(let j=0;j<Z.n;j++){const X0=Z.x0+i*Z.c,Z0=Z.z0+j*Z.c,y=gy(X0,Z0);
      if(M.walls.has(M.k(i,j,'E'))&&!(i===Z.n-1&&j===M.door.e)){I('box',GLD,.96,2.15,.5,X0+Z.c,y+1.07,Z0+Z.c/2);I('sph',GLD,.5,.35,.3,X0+Z.c,y+2.3,Z0+Z.c/2);}
      if(M.walls.has(M.k(i,j,'S'))&&j<Z.n-1){I('box',GLD,.5,2.15,.96,X0+Z.c/2,y+1.07,Z0+Z.c);I('sph',GLD,.3,.35,.5,X0+Z.c/2,y+2.3,Z0+Z.c);}}
    const E=M.ends.slice().sort((p,q)=>Math.hypot(q[0]-5,q[1]-4)-Math.hypot(p[0]-5,p[1]-4)).filter(e=>!(e[0]===5&&e[1]===4)&&!(e[0]===0&&e[1]===0)),e=E[3]||E[E.length-1],cc=M.cell(e[0],e[1]);
    window.XSPOTS=window.XSPOTS||{};XSPOTS.tinsel={k:'gold',x:+cc[0].toFixed(1),z:+cc[1].toFixed(1)};}
  for(let i=0;i<14;i++){const x=6+i*1.6,z=-14,y=gy(x,z);[['🧸'],['🚂'],['⚽'],['🤖'],['🪀'],['🎁']].forEach((q,k)=>{});}
  const toys=['🧸','🚂','⚽','🤖','🪀','🎁','🪁'],belt=[];for(let i=0;i<8;i++){const s=sprite(toys[i%7],1.2);s.position.set(6+i*2,gy(6,-14)+1.6,-14);W.ag.add(s);belt.push(s);}
  I('box','#3a3f4c',18,.8,1.8,14,gy(14,-14)+.4,-14);I('box','#26232e',18.2,.12,1.6,14,gy(14,-14)+.86,-14);rect(5,-15,23,-13);
  W.ticks.push(dt=>{belt.forEach((s,i)=>{s.position.x=6+((i*2+W.t*1.6)%16);s.position.y=gy(6,-14)+1.6+Math.abs(Math.sin(W.t*3+i))*.12;});});
  xtree(24,-4,1,{lights:'on'});sign(4,-11,'🧸 Toy Packing',3,5.5);W.things.push({x:4,z:-12,r:3.8,icon:'📦',label:'Toy Packing',act:()=>{sfx.chime();startQuiz('activity','toypack');}});
  sayOnce('factory','The Factory is a Christmas toy factory! Tinker needs help packing toys. And look: the container maze is full of giant presents!');};
ISL.workshop=A=>{xtree(-14,22,1,{lights:'on'});};
/* Rescue Bay: the lights switch-on */
ISL.townsq=A=>{const a=acts(),sets=[[[-20,10.5,-12],[20,10.5,-12]],[[-20,10.5,12],[20,10.5,12]],[[-16,11,-16],[16,11,16]],[[16,11,-16],[-16,11,16]]];
  const pts=[];sets.forEach(s=>strand(s[0],s[1],28,1).forEach(p=>pts.push(p)));const L=bulbs(pts,!!a.lights,.16);const T=xtree(8,-6,1.2,{lights:a.lights?'on':'off',star:a.lights?'on':'off'});
  const sx=-6,sz=6,y=gy(sx,sz);I('box','#5b6378',1,1.6,.7,sx,y+.8,sz);I('box',RED,.3,.6,.3,sx,y+1.9,sz);sign(sx-2,sz+2,'💡 Christmas lights',3,6);
  W.things.push({x:sx,z:sz+1.6,r:3.6,icon:'💡',label:a.lights?'Lights':'Switch on',act:()=>{if(player.lock)return;if(a.lights){sfx.chime();say('The Christmas lights twinkle all over Town Square!');return;}
    player.lock=true;let n=10;say('Chief Woofles says: let\'s switch on the Christmas lights! Count down with me!');const tickD=()=>{speak(String(n));floatS(['🔟','9️⃣','8️⃣','7️⃣','6️⃣','5️⃣','4️⃣','3️⃣','2️⃣','1️⃣'][10-n],sx,y+4,sz,2.4,1);sfx.boop();n--;
      if(n>0){setTimeout(tickD,900);return;}setTimeout(()=>{L.set(true);if(T.L)T.L.set(true);if(T.st)T.st.visible=true;a.lights=1;save();sfx.fanfare();confetti(60);XM.snd.bells(12);player.lock=false;say('Hooray! The Christmas lights are on! Helping someone at Christmas is the brightest light of all.');},900);};setTimeout(tickD,1800);}});};
ISL.firestation=A=>{xtree(16,20,1,{lights:'on'});};
/* Dino Valley: the mother long-neck becomes the tallest Christmas tree */
ISL.nest=A=>{};
function neckTree(A){const a=acts();let g=null;W.ag.children.forEach(o=>{if(o.userData&&o.userData.d&&o.userData.d.neck&&Math.hypot(o.position.x,o.position.z+34)<2)g=o;});if(!g)return;const d=g.userData.d;
  const add2=()=>{d.neck.forEach((n,i)=>{for(let k=0;k<3;k++){const an=k*2.1+i;const m=mk('sph',BULB[(i+k)%5],.32,.32,.32,Math.cos(an)*1.15,1.1,Math.sin(an)*1.15,n,true);}});const st=grp();for(let i=0;i<5;i++){const c=mk('cone',GLD,.3,1.1,.14,-Math.sin(i*1.2566)*.55,Math.cos(i*1.2566)*.55,0,st,true);c.rotation.z=i*1.2566;}st.position.set(0,1.6,.5);d.head.add(st);};
  if(a.neck)add2();
  W.things.push({x:0,z:-24,r:5,icon:'🎄',label:a.neck?'Long-neck':'Decorate',act:()=>{if(player.lock)return;if(a.neck){sfx.chime();say('The mother long-neck is the tallest Christmas tree on all the islands!');return;}
    player.lock=true;sfx.chime();followers.forEach(f=>f.grp.userData.jump=.8);say('The pups hang baubles on the mother long-neck\'s neck... she bends down so they can reach!');
    setTimeout(()=>{add2();a.neck=1;save();XM.snd.twinkle();confetti(50);player.lock=false;say('Ta-da! The mother long-neck is the tallest Christmas tree on all the islands! The best things are worth waiting for.');},1800);}});}
ISL.digcamp=A=>{xtree(-12,20,1,{lights:'on'});};
/* Planet Hop: moon-dust snowmen, and floating sprouts at Christmas dinner */
ISL.moon=A=>{snowman(14,-14,.9,GRN,true);snowman(-22,-2,.8,RED,true);xtree(6,22,.9,{lights:'on'});
  const tx=-2,tz=-15,y=gy(tx,tz);I('box','#e6eaf0',4,.15,2,tx,y+1.1,tz);[[-1.8,-.8],[1.8,-.8],[-1.8,.8],[1.8,.8]].forEach(q=>I('cyl','#8a8f99',.08,1.1,.08,tx+q[0],y+.55,tz+q[1]));
  for(let i=0;i<4;i++)I('cyl','#ffffff',.36,.05,.36,tx-1.3+i*.85,y+1.2,tz);I('sph','#c8844a',.5,.35,.4,tx,y+1.45,tz);col(tx,tz,2);
  W.things.push({x:tx,z:tz+2.4,r:3.8,icon:'🍽️',label:'Christmas dinner',act:()=>{sfx.chime();startCollect('sprouts');}});};
ISL.station=A=>{bulbs(strand([-20,9,-6],[20,9,-6],30,1),true,.14);xtree(-14,14,.9,{lights:'on'});};
/* the Lab, Spa and Den */
ISL.den=A=>{const a=acts();if(!a.den&&!X().done)return;xtree(11,6,.55,{lights:'on'});
  const fx=-3,fz=-10.4;I('box','#a8644a',5,3.2,1.2,fx,1.6,fz);I('box','#26232e',2.6,2,1.3,fx,1.1,fz+.05);I('box','#fff8e6',5.4,.3,1.6,fx,3.3,fz+.1);
  const fl=[];for(let i=0;i<3;i++){const m=new THREE.Mesh(G.cone,new THREE.MeshBasicMaterial({color:['#ff8a3c','#ffd23f','#ff6b2a'][i],transparent:true,opacity:.85}));m.scale.set(.35,.8,.35);m.position.set(fx-.6+i*.6,.6,fz+.4);W.ag.add(m);W.disp.push(m.material);fl.push(m);}
  W.ticks.push(()=>{fl.forEach((m,i)=>{m.scale.y=.7+Math.sin(W.t*9+i*2)*.2;});});
  const ids=teamIds();ids.forEach((id,i)=>{const x=fx-1.8+i*1.8;I('box',[RED,GRN,'#ffffff'][i%3],.6,1,.3,x,2.6,fz+.8);I('box','#ffffff',.7,.25,.32,x,3.05,fz+.8);const p=pupById(id);if(p){const l=label(p.name,1.8,'#fffdf5');l.position.set(x,1.9,fz+1);l.scale.multiplyScalar(.5);W.ag.add(l);}});
  if(X().done){I('sph','#d8dde6',.35,.35,.35,4,4.2,-10.9);I('cyl',RED,.08,.8,.08,4,4.8,-10.9);}rect(fx-2.6,fz-.6,fx+2.6,fz+.8);};

/* ================= the Sleigh Run ================= */
const SLEIGH={items:[[-24,-28],[-36,6],[-20,28],[22,26],[36,4],[18,-24]]};
COLLECT.sleighrun={k:'sleighrun',area:'hut',icon:'🎁',size:2.2,h:1.8,items:SLEIGH.items,start:[4,26,PI],thing:'dropped present',art:'🛷',ride:'sleigh',
  intro:'The Sleigh Run! Steer the sleigh round the mountain and pick up the 6 presents that fell out of the sack. Go through the arches of fairy lights!',title:'Every present is back in the sleigh! What a sleigh ride!'};
COLLECT.sprouts={k:'sprouts',area:'moon',icon:'🟢',size:1.6,h:3.2,items:[[-8,-20],[4,-22],[10,-12],[-14,-14],[-10,-4],[6,-4]],start:[-2,-10,PI],thing:'floating sprout',art:'🥗',
  intro:'Christmas dinner on Moon Base! Oh no, the low gravity has made the Brussels sprouts float away! Catch all 6 sprouts for Captain Nibbles.',title:'You caught every sprout! Captain Nibbles says they are delicious. Yuck!'};
regRide('sleigh',()=>{const g=grp();mk('box',RED,1.5,.6,2.4,0,.6,0,g);mk('box',RED,1.5,1,.4,0,1.1,-1.1,g);mk('box',GLD,1.55,.12,2.45,0,.95,0,g);[-1,1].forEach(s=>{mk('box','#c9d2e3',.1,.1,3,s*.7,.08,.2,g);const c=mk('tor','#c9d2e3',.3,.3,.2,s*.7,.35,1.6,g);c.rotation.y=PI/2;});
  mk('sph','#a8743a',.5,.45,.5,0,1.35,-.6,g);bakeModel(g,'xsleigh');const d=XM.deer3D();if(d){d.position.set(0,0,3.2);d.scale.setScalar(.8);g.add(d);g.userData.tick=(t,mv)=>{const u=d.userData;if(u.legs)u.legs.forEach((l,i)=>{l.rotation.x=mv?Math.sin(t*10)*(i===0||i===3?.6:-.6):0;});};}
  return g;},.55);
function startSleigh(){if(player.lock)return;if(XM.nSp()<3){sfx.oops();say(`${D()} is too nervous to pull the sleigh yet. Bring home 3 star sparkles from the unicorns, and ${XM.he()} will be brave enough!`);return;}sfx.chime();XM.snd.bells(8);if(XM.DEER.g)XM.DEER.g.visible=false;startCollect('sleighrun');}
const _ft=finishAct;finishAct=function(k){if(k==='sleighrun'&&XM.DEER.g&&XM.on())XM.DEER.g.visible=true;return _ft.apply(this,arguments);};
/* sprouts: a custom picture */
(function(){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.fillStyle='#5aa83a';g.beginPath();g.arc(64,64,46,0,PI*2);g.fill();g.strokeStyle='#2f6a24';g.lineWidth=6;g.stroke();
  g.strokeStyle='#8fd46a';g.lineWidth=5;for(let i=0;i<4;i++){g.beginPath();g.arc(64,64,30-i*7,-.8+i*.4,1.8+i*.3);g.stroke();}texC['🟢']=new THREE.CanvasTexture(c);})();

/* ================= quizzes: Toy Packing and Why is winter cold? ================= */
const toyBG=()=>`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="768" fill="#cfe0f5"/><rect y="560" width="1024" height="208" fill="#8fb0d6"/><rect x="0" y="470" width="1024" height="60" fill="#3a3f4c"/>`+
  [0,1,2,3,4,5,6].map(i=>`<text x="${80+i*140}" y="460" font-size="80" text-anchor="middle">${['🧸','🚂','⚽','🤖','🪀','🎁','🪁'][i]}</text>`).join('')+`<text x="900" y="130" font-size="110">🎄</text></svg>`;
const TOYS=[['teddies','🧸'],['toy trains','🚂'],['footballs','⚽'],['robots','🤖'],['yo-yos','🪀'],['kites','🪁']];
QUIZ.toypack={k:'toypack',name:'Toy Packing',icon:'📦',n:6,bg:toyBG,introMs:3200,intro:'Toy Packing! Tinker the robot needs help packing toys into boxes for Christmas. Count the toys!',
  make:i=>{const T=TOYS[i%TOYS.length],tb=tablesOn(),small=i<2;let a,b;if(small){a=rint(2,4);b=rint(2,3);}else{a=pick(tb);b=rint(2,i<4?5:10);}const ans=a*b,emo=T[1];
    const pic=small?`<div style="font-size:44px;line-height:1.2">${Array.from({length:b},()=>`<span style="display:inline-block;border:4px solid #8a5a32;border-radius:10px;padding:4px;margin:4px;background:#f3d9a8">${emo.repeat(a)}</span>`).join('')}</div>`:`<div style="font-size:90px;line-height:1">📦${emo}</div>`;
    return {q:`Each box holds <b>${a} ${T[0]}</b>. Tinker fills <b>${b} boxes</b>. How many ${T[0]}?`,say:`Each box holds ${a} ${T[0]}. Tinker fills ${b} boxes. How many ${T[0]} is that?`,pic,ans,opts:opts(ans,[ans+a,ans-a,ans+b,ans-b,ans+1],4),hintSay:small?`Count them all, or count in ${a}s.`:`That is ${b} lots of ${a}. Count in ${a}s, ${b} times.`};},
  block:()=>'📦',title:'Every toy is packed! Tinker says thank you, Toy Maker!'};
const labBG=()=>`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="768" fill="#14204a"/><circle cx="512" cy="300" r="70" fill="#ffd23f"/><circle cx="512" cy="300" r="110" fill="#ffd23f" opacity=".2"/>`+
  `<ellipse cx="512" cy="330" rx="380" ry="120" fill="none" stroke="#7fa8ff" stroke-width="3" stroke-dasharray="10 10"/><g transform="translate(150 360) rotate(23)"><circle r="50" fill="#3d8fe0"/><path d="M-30 -20 q20 -10 30 10 q10 20 -10 30" fill="#3fae5a"/><line y1="-75" y2="75" stroke="#fff" stroke-width="4"/></g>`+
  `<g transform="translate(874 360) rotate(23)"><circle r="50" fill="#3d8fe0"/><path d="M-30 -20 q20 -10 30 10 q10 20 -10 30" fill="#3fae5a"/><line y1="-75" y2="75" stroke="#fff" stroke-width="4"/></g></svg>`;
const WINTER=[['Which way is the Earth tilted?','The Earth spins on a tilted line called its axis, like a spinning top leaning over.',['Leaning over','Standing up straight','Upside down'],'Leaning over'],
 ['In December, the top half of the Earth, where we live, leans...','In December our half of the Earth leans away from the Sun, so the sunshine is weaker.',['Away from the Sun','Towards the Sun'],'Away from the Sun'],
 ['When our half leans away from the Sun, the days are...','The Sun is low in the sky in winter, so the days are short and the nights are long.',['Short','Long'],'Short'],
 ['Is the Earth closer to the Sun in winter?','No! The Earth is actually a little closer to the Sun in January. It is the tilt that makes winter.',['No, it is the tilt','Yes, much closer'],'No, it is the tilt'],
 ['When it is winter for us, what is it in Australia?','The bottom half of the Earth leans towards the Sun in December, so it is summer in Australia at Christmas!',['Summer','Winter'],'Summer'],
 ['What do we get on the shortest day of the year?','The shortest day is around 21 December, the winter solstice. After that the days get longer!',['The least daylight','The most daylight'],'The least daylight']];
QUIZ.winter={k:'winter',name:'Why Is Winter Cold?',icon:'🌍',n:6,bg:labBG,introMs:3600,intro:'Professor Fizz has a winter experiment! She tilts a little Earth round a lamp, like the Sun, to show why winter is cold. Let\'s find out!',
  make:i=>{const W2=WINTER[i%WINTER.length],o=W2[2].slice().sort(()=>Math.random()-.5);return {q:W2[0],say:W2[0]+' '+o.join(', or ')+'?',pic:'<div style="font-size:110px;line-height:1">🌍💡</div>',ans:W2[3],opts:o,hintSay:W2[1],after:`<div style="font-size:26px;font-weight:800;padding:10px">${W2[1]}</div>`};},
  block:()=>'🌍',title:'Now you know why winter is cold! Brilliant scientist!'};
regAct('sleighrun',{name:'Sleigh Run',icon:'🛷',island:'snowy',area:'hut',where:'Christmas Snow, at the Mountain Hut',lockSay:'Find the Sleigh Run at the Mountain Hut in Christmas Snow, and play it there first!',play:()=>xTravel('hut',COLLECT.sleighrun.start,()=>startCollect('sleighrun'),'The Sleigh Run is about to start!')});
regAct('toypack',{name:'Toy Packing',icon:'📦',island:'gadget',area:'factory',where:'Christmas Snow, in the Factory',lockSay:'Find Toy Packing in the Factory in Christmas Snow, and play it there first!',play:()=>startQuiz('arcade','toypack')});
regAct('snowdojo',{name:'Snowball Dojo',icon:'❄️',island:'ninja',area:'dojo',where:'Christmas Snow, at the Dojo',lockSay:'Find the Snowball Dojo in Christmas Snow, and play it there first!',play:()=>xTravel('dojo',[-21,-4,PI],()=>say('Knock all 6 targets off their posts! Walk near them and tap Throw.'),'The Snowball Dojo!')});
regAct('sprouts',{name:'Sprout Catch',icon:'🟢',island:'planet',area:'moon',where:'Christmas Snow, on Moon Base',lockSay:'Find Christmas dinner on Moon Base in Christmas Snow, and play it there first!',play:()=>xTravel('moon',COLLECT.sprouts.start,()=>startCollect('sprouts'),'Christmas dinner is served!')});
function xTravel(area,pos,start,msg){if(!XM.on()){state.season='xmas';save();XM.rebuildPack();}arcadeTravel(area,pos,start,msg);}
/* the Lab gets a winter experiment while Christmas Snow is on */
if(typeof openLab==='function'){const base=openLab;openLab=function(){base.apply(this,arguments);if(!XM.on())return;setTimeout(()=>{const c=document.querySelector('#lab .xwin');if(c)return;const host=document.querySelector('#lab');if(!host)return;
  const b=el('button','btn green xwin','🌍 Why is winter cold?');b.style.cssText='position:absolute;right:24px;bottom:24px;z-index:30;font-size:24px';tap(b,()=>{sfx.pop();startQuiz('lab','winter');});host.appendChild(b);},50);};}

/* ================= music: carols and sleigh bells ================= */
const C1=(s)=>tuneRow(s);
TUNES.xdeck={step:.24,mw:'triangle',mv:.5,mel:C1('G5 - - F5 E5 - D5 - C5 - D5 - E5 - C5 - D5 E5 F5 D5 E5 - - D5 C5 - B4 - C5 - - - G5 - - F5 E5 - D5 - C5 - D5 - E5 - C5 - D5 E5 F5 D5 E5 - - D5 C5 - B4 - C5 - - - D5 - - E5 F5 - D5 - E5 - - F5 G5 - D5 - E5 F#5 G5 - A5 B5 C6 - B5 - A5 - G5 - - - G5 - - F5 E5 - D5 - C5 - D5 - E5 - C5 - A5 A5 A5 A5 G5 - - F5 E5 - D5 - C5 - - -'),
  bas:C1('C3 - - - G3 - - - C3 - - - G3 - - - C3 - - - G3 - - - C3 - - - G3 - - - G3 - - - D3 - - - G3 - - - C3 - - - C3 - - - G3 - - - F3 - - - C3 - - -'),drm:'k...h...k...h...'};
TUNES.xjingle={step:.2,mw:'triangle',mv:.5,mel:C1('E5 - E5 - E5 - - - E5 - E5 - E5 - - - E5 - G5 - C5 - - D5 E5 - - - - - - - F5 - F5 - F5 - - F5 F5 - E5 - E5 - E5 E5 E5 - D5 - D5 - E5 - D5 - - - G5 - - - E5 - E5 - E5 - - - E5 - E5 - E5 - - - E5 - G5 - C5 - - D5 E5 - - - - - - - F5 - F5 - F5 - - F5 F5 - E5 - E5 - E5 E5 G5 - G5 - F5 - D5 - C5 - - - - - - -'),
  bas:C1('C3 - G3 - C3 - G3 - C3 - G3 - C3 - G3 - F3 - C3 - G3 - D3 - G3 - D3 - C3 - G3 -'),drm:'x.h.y.h.x.h.y.h.'};
TUNES.xwish={step:.2,mw:'triangle',mv:.5,mel:C1('G4 - C5 - C5 D5 C5 B4 A4 - A4 - A4 - D5 - D5 E5 D5 C5 B4 - G4 - G4 - E5 - E5 F5 E5 D5 C5 - A4 - G4 G4 A4 - D5 - B4 - C5 - - - - -'),
  bas:C1('C3 - - - - - F3 - - - - - D3 - - - - - G3 - - - - - E3 - - - - - F3 - - - - - G3 - - - - - C3 - - - - -'),drm:'k.h.h.'};
TUNES.xtree={step:.16,mw:'sine',mv:.55,mel:C1('G4 - - - C5 - - C5 C5 - - - - - D5 - E5 - - E5 E5 - - - - - E5 - D5 - E5 - F5 - - - B4 - - - D5 - - - C5 - - - G4 - - - C5 - - C5 C5 - - - - - D5 - E5 - - E5 E5 - - - - - E5 - D5 - E5 - F5 - - - B4 - - - D5 - - - C5 - - - - - - -'),
  bas:C1('C3 - - - - - - - - - - - C3 - - - - - - - - - - - G2 - - - - - - - - - - - C3 - - - - - - - - - - -'),hw:'sine',hv:.12};
const SEASON_TUNE={village:'xdeck'};
const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;if(XM.on()&&typeof W!=='undefined'&&W&&W.area){if(W.act&&W.act.k==='sleighrun')return 'xjingle';if(W.area.id==='village'&&(XWORLD.carol||0)>W.t)return 'xdeck';if(W.area.id==='village')return 'xdeck';}return _mk();};
const _ps=playStep;playStep=function(T,i,t){_ps(T,i,t);if(!XM.on()||!AC)return;if(i%2===0&&T!==TUNES.xjingle){try{const d=musF;tone(2600+(i%4)*180,t,.07,'sine',.035,d);nzHit(t,.04,.035,'highpass',7500,d);}catch(e){}}};

/* ================= build hooks ================= */
window.XWORLD={build(A){BL=[];try{if(A.id==='village')villageX(A);else if(ISL[A.id])ISL[A.id](A);}catch(e){console.warn('xmas island',A.id,e);}},
  after(A){if(A.id==='nest')neckTree(A);
    /* the lights twinkle */
    if(BL.length)W.ticks.push(()=>{BL.forEach((o,i)=>{if(o.on)o.m.color.setHSL(0,0,.82+.18*Math.sin(W.t*3+i));});});},
  xtree,star3D,bulbs,strand,snowman,tree:null,carol:0,lights:()=>BL};
/* on Christmas Day, whatever Seb is playing, a present waits in the Den */
{const Dn=AREAS.den,b=Dn.build;Dn.build=function(){b.apply(this,arguments);const d=new Date();if(d.getMonth()!==11||d.getDate()!==25)return;const a=state.xday||(state.xday={}),y=d.getFullYear();if(a[y])return;
  const q=XM.present3D(['#d9363e','#ffd23f'],1.1);add(q.g,9,4);W.things.push({x:9,z:5.6,r:3.6,icon:'🎁',label:'A present!',show:()=>!a[y],act:()=>{a[y]=1;state.stars+=25;save();hud();sfx.fanfare();confetti(60);q.lid.position.y=1.4;q.lid.rotation.z=.9;
    say('Happy Christmas, Seb! A present from all the pups: 25 stars, and a big puppy hug!');}});};}
/* the Snow Globe is in the plaza in the normal game too, so Seb can switch to Christmas Snow */
{const V=AREAS.village,b=V.build;V.build=function(){b.apply(this,arguments);if(!XM.on())globe3D(-5.5,9);};}
const css=document.createElement('style');css.textContent=`.xadv{display:grid;grid-template-columns:repeat(8,1fr);gap:8px;margin:10px 0}.xad{height:64px;border-radius:12px;border:4px solid #26232e;background:#d9363e;color:#fff;font:900 26px inherit;font-family:inherit}
.xad:nth-child(3n){background:#2f8a4a}.xad:nth-child(4n){background:#c8844a}.xad.open{background:#fff3c2;color:#26232e}.xad.today{background:#ffd23f;color:#d9363e;box-shadow:0 0 16px #ffd23f;animation:xhint .8s ease-in-out infinite}#xadMsg{min-height:60px;font-size:24px;font-weight:800}`;document.head.appendChild(css);
})();
