/* ================================================================
   Seb's Puppy Quest 3: core engine
   Save, screens, the 3D world (one area built at a time), finding
   pups, the Pup House, maps, the grown-ups panel and the village.
   Islands live in their own files and call regIsland().
   ================================================================ */

/* ============ registries ============ */
const TYPES={
  leaf:{name:'Leaf',icon:'🍃',col:'#3fae5a',power:'grows vine bridges'},
  water:{name:'Water',icon:'💧',col:'#3d8fe0',power:'makes stepping stones'},
  fire:{name:'Fire',icon:'🔥',col:'#e8603a',power:'melts ice walls'},
  snow:{name:'Snow',icon:'❄️',col:'#5aa9dc',power:'clears snowdrifts'},
  sky:{name:'Sky',icon:'☁️',col:'#8a8fe0',power:'floats on the wind'},
  spark:{name:'Spark',icon:'⚡',col:'#e0a400',power:'lights up dark places'},
  star:{name:'Star',icon:'⭐',col:'#b26fe0',power:'shines the way'}};
const ISLANDS=[],PUPS={},AREAS={};
/* the islands still to come, shown on the world map and in the Pup House */
const SOON=[
  {id:'snowy',name:'Snowy Summit',icon:'🏔️',ride:'the chairlift'},{id:'reef',name:'Coral Reef',icon:'🐠',ride:'the submarine'},
  {id:'ninja',name:'Ninja Mountains',icon:'🥷'},{id:'number',name:'Number Kingdom',icon:'🔢'},
  {id:'gadget',name:'Gadget Island',icon:'🔧'},{id:'rescue',name:'Rescue Bay',icon:'🚒'},
  {id:'dino',name:'Dino Valley',icon:'🦕'},{id:'planet',name:'Planet Hop',icon:'🪐'}];
function regIsland(I){ISLANDS.push(I);
  I.pups.forEach(p=>{p.island=I.id;p.lv=1;p.type=p.type||I.type;PUPS[p.id]=p;});
  (I.bonus||[]).forEach(p=>{p.island=I.id;p.lv=1;p.type=p.type||I.type;p.bonus=true;p.shiny=true;PUPS[p.id]=p;});
  I.areas.forEach(a=>{a.island=I.id;AREAS[a.id]=a;});}
const islandOf=id=>ISLANDS.find(I=>I.id===id);
const islPups=I=>I.pups;
const areaPups=a=>Object.values(PUPS).filter(p=>p.area===a&&!p.sci);
const isFound=id=>!!state.found[id];
const foundIn=list=>list.filter(p=>isFound(p.id)).length;

/* ============ save ============ */
const SAVE='sebPuppyQuest3v1';
let state=null;
function fresh(){return{v:1,intro:false,found:{},tagged:{},gear:{},vines:{},seen:{},islDone:{},stars:0,where:'village',
  buddy:null,pack:[],dress:{},stats:{pets:0,found:0,searches:0},guest:null,hi:{},acts:{},badges:{},certs:{},played:{},
  set:{voice:true,sfx:true,music:true,sleepMin:20,hsEasy:false,openIsl:false,openAreas:false},playSecs:0,sleepUntil:0};}
function load(){try{const j=JSON.parse(localStorage.getItem(SAVE)||'null');
  if(j&&j.v===1){const f=fresh();state=Object.assign(f,j);state.set=Object.assign(fresh().set,j.set||{});state.stats=Object.assign(fresh().stats,j.stats||{});return;}}catch(e){}
  state=fresh();}
let RESTORING=false;function save(){if(RESTORING)return;try{localStorage.setItem(SAVE,JSON.stringify(state));}catch(e){}}
function backupCode(){return 'PQ3:'+btoa(unescape(encodeURIComponent(JSON.stringify(state))));}
/* backup codes: find every PQ3: (or PQ2:) code in the text, even with other text stuck on (an iPad paste can land
   in the middle of a code already in the box), and decode each; readCode picks the last good one, skipping any the caller rules out */
function decodeCode(c){const J=x=>{try{return JSON.parse(decodeURIComponent(escape(x)));}catch(e){return null;}};const eq=c.indexOf('=');if(eq>=0)c=c.slice(0,eq);
  try{let d=c;while(d.length%4)d+='=';const j=J(atob(d));if(j)return j;}catch(e){}
  let b;try{b=atob(c.slice(0,c.length-c.length%4));}catch(e){return null;}let n=0;for(let i=b.lastIndexOf('}');i>0&&n<4000;i=b.lastIndexOf('}',i-1),n++){const j=J(b.slice(0,i+1));if(j)return j;}return null;}
function readCodes(t,pre){const parts=String(t||'').replace(/\s+/g,'').split(new RegExp(pre.replace(':','')+':','i')),out=[];parts.slice(1).forEach(q=>{const m=q.match(/^[A-Za-z0-9+/=]+/);const j=m&&decodeCode(m[0]);if(j&&typeof j==='object')out.push(j);});return out;}
function readCode(t,pre,skip){const L=readCodes(t,pre);for(let i=L.length-1;i>=0;i--)if(!skip||!skip(L[i]))return L[i];return L.length?L[L.length-1]:null;}

/* ============ screens and UI helpers ============ */
let cur='title',sleepOn=false,rotOk=false;
function show(id){document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id===id));cur=id;
  $('#gl').style.visibility=id==='world'?'visible':'hidden';if(id!=='world'){joyReset();hush();}}
function tap(sel,fn){const e=typeof sel==='string'?$(sel):sel;e.addEventListener('click',ev=>{initAudio();fn(ev);});return e;}
function hold(sel,fn){const e=$(sel);let t=null;const stop=()=>{clearTimeout(t);t=null;e.classList.remove('holding');};
  e.addEventListener('pointerdown',ev=>{ev.stopPropagation();e.classList.add('holding');t=setTimeout(()=>{stop();fn();},3000);});
  ['pointerup','pointerleave','pointercancel'].forEach(k=>e.addEventListener(k,stop));}
const ovOpen=()=>!!document.querySelector('.ov.on');
function closeOv(id){$('#'+id).classList.remove('on');}
function fadeTo(fn,art){const f=$('#fade');f.innerHTML=art?`<div style="position:absolute;left:0;right:0;top:250px;text-align:center;font-size:120px">${art[0]}</div><div style="position:absolute;left:0;right:0;top:420px;text-align:center;font-size:44px;font-weight:900">${art[1]||''}</div>`:'';
  f.classList.add('on');setTimeout(()=>{fn();setTimeout(()=>f.classList.remove('on'),art?900:80);},450);}
function typeBadge(t){const T=TYPES[t];return T?`<span class="tb" style="background:${T.col}">${T.icon} ${T.name}</span>`:'';}
function pupBox(p,o){if(p&&(p.shiny||(p.id&&bestFriend(p.id))))o=Object.assign({sparkly:true},o||{});return `<div class="fitsvg">${critterSVG(p,o)}</div>`;}
/* a card overlay: art html, title, text (read aloud), buttons [[label,cls,fn]] */
function card(o){const c=$('#celeCard');c.className='card pop'+(o.cls?' '+o.cls:'');
  c.innerHTML=(o.art?`<div class="art">${o.art}</div>`:'')+(o.h?`<h2>${o.h}</h2>`:'')+(o.h3?`<h3>${o.h3}</h3>`:'')+(o.p?`<p>${o.p}</p>`:'')+'<div class="btns"></div>';
  const B=c.querySelector('.btns');(o.btns||[['OK','green']]).forEach(b=>{const e=el('button','btn '+(b[1]||''),b[0]);tap(e,()=>{sfx.boop();closeOv('cele');if(b[2])b[2]();});B.appendChild(e);});
  $('#cele').classList.add('on');if(o.say!==false)speak(o.say||((o.h||'')+'. '+(o.p||'').replace(/<[^>]+>/g,' ')));}
/* a run of story cards */
function story(pages,done){let i=0;const nx=()=>{if(i>=pages.length){if(done)done();return;}const p=pages[i++];card({art:p.art,p:p.t,say:p.t,btns:[[i<pages.length?'▶':'✓ OK','green',nx]]});};nx();}

/* ============ 3D world ============ */
const D2R=Math.PI/180,SPEED=10;
let R3=null,scene=null,cam=null;
const G={},mats={},instMap={},texC={};
const W={ready:false,fail:false,t:0,last:0,fl:[],cols:[],rects:[],decks:[],exits:[],things:[],spots:[],ticks:[],disp:[],ag:null,area:null,
  camYaw:Math.PI,near:null,msgT:-9,wanderers:[],findT:0,trail:[],wild:null,rescue:null,clueT:0,hintT:0};
const player={x:0,z:0,y:0,h:0,grp:null,lock:false,moving:false,wt:0};
const followers=[];
const joy={id:null,ox:0,oy:0,x:0,y:0},keys={};
const sstep=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t);};
function meshY(x,z){const g=W.gm;let fx=(x-g.x0)/g.sx,fz=(z-g.z0)/g.sz;const ix=Math.floor(fx),iz=Math.floor(fz);if(ix<0||iz<0||ix>=g.nx||iz>=g.nz)return null;
  fx-=ix;fz-=iz;const r=g.nx+1,Y=g.Y,a=(ix+r*iz)*3+1,b=(ix+r*(iz+1))*3+1,c=(ix+1+r*(iz+1))*3+1,d=(ix+1+r*iz)*3+1;return fx+fz<=1?Y[a]+(Y[d]-Y[a])*fx+(Y[b]-Y[a])*fz:Y[c]+(Y[b]-Y[c])*(1-fx)+(Y[d]-Y[c])*(1-fz);}
/* ground height: the drawn ground mesh where there is one (so feet meet what you see), plus any path, plaza or step being stood on (ground.js) */
const gy=(x,z)=>{let b=W.gm?meshY(x,z):null;if(b==null)b=W.area&&W.area.hf?W.area.hf(x,z):0;return W.lift?b+surfLift(x,z,b):b;};

function initWorld(){
  if(W.ready||W.fail)return;
  try{if(typeof THREE==='undefined')throw new Error('no three');R3=new THREE.WebGLRenderer({canvas:$('#gl'),antialias:(window.devicePixelRatio||1)<2,powerPreference:'high-performance'});}catch(e){W.fail=true;return;}
  R3.setPixelRatio(Math.min(window.devicePixelRatio||1,1.5));
  scene=new THREE.Scene();scene.background=new THREE.Color('#a6dfff');scene.fog=new THREE.Fog('#a6dfff',70,200);
  cam=new THREE.PerspectiveCamera(55,1,.5,800);
  G.sph=new THREE.SphereGeometry(1,12,8);G.sphL=new THREE.SphereGeometry(1,6,4);G.cylL=new THREE.CylinderGeometry(1,1,1,5,1,true);G.coneL=new THREE.ConeGeometry(1,1,5,1,true);G.cone=new THREE.ConeGeometry(1,1,10);G.cyl=new THREE.CylinderGeometry(1,1,1,12);G.tor=new THREE.TorusGeometry(1,.26,8,18);G.ring=new THREE.TorusGeometry(1,.06,6,20);G.band=new THREE.TorusGeometry(1,.075,6,24);G.box=new THREE.BoxGeometry(1,1,1);G.pyr=new THREE.ConeGeometry(1,1,4);
  G.hemi=new THREE.SphereGeometry(1,14,8,0,Math.PI*2,0,Math.PI/2);G.disc=new THREE.CircleGeometry(1,22);G.disc.rotateX(-Math.PI/2);G.arc=new THREE.TorusGeometry(1,.045,6,26,Math.PI);
  G.arch=new THREE.TorusGeometry(1,.08,8,24,Math.PI);G.plane=new THREE.PlaneGeometry(1,1);G.plane.rotateX(-Math.PI/2);
  shadowMat=new THREE.MeshBasicMaterial({color:0x000000,transparent:true,opacity:.2,depthWrite:false});
  W.hemi=new THREE.HemisphereLight(0xffffff,0xa8b898,.66);scene.add(W.hemi);const dl=new THREE.DirectionalLight(0xffffff,.45);dl.position.set(60,90,-40);scene.add(dl);
  W.ag=new THREE.Group();scene.add(W.ag);
  player.grp=seb3D();scene.add(player.grp);addKit();
  W.ready=true;resize3D();
}
function resize3D(){if(!R3)return;const w=window.innerWidth,h=window.innerHeight;R3.setSize(w,h,false);cam.aspect=w/h;cam.updateProjectionMatrix();}

/* ----- building helpers, used by the village and the island files ----- */
function I(g,c,sx,sy,sz,x,y,z,rx,ry,rz,basic){addInst(g,c,sx,sy,sz,x,y,z,rx,ry,rz,basic);}
function flushTo(par){for(const k in instMap){const o=instMap[k],im=new THREE.InstancedMesh(G[o.g],M(o.c,o.basic),o.m.length);o.m.forEach((m,i)=>im.setMatrixAt(i,m));im.frustumCulled=false;par.add(im);W.disp.push(im);delete instMap[k];}}
function add(o,x,z,y){o.position.set(x,y!=null?y:gy(x,z),z);W.ag.add(o);return o;}
function grp(){return new THREE.Group();}
function col(x,z,r){W.cols.push({x,z,r});}
function colLine(x1,z1,x2,z2,r){const d=Math.hypot(x2-x1,z2-z1),n=Math.max(1,Math.ceil(d/(r*1.2)));for(let i=0;i<=n;i++)col(x1+(x2-x1)*i/n,z1+(z2-z1)*i/n,r);}
function rect(x1,z1,x2,z2){W.rects.push({x1:Math.min(x1,x2),z1:Math.min(z1,z2),x2:Math.max(x1,x2),z2:Math.max(z1,z2)});}
function camBlock(x1,z1,x2,z2){(W.camBlocks=W.camBlocks||[]).push({x1:Math.min(x1,x2)-1.4,z1:Math.min(z1,z2)-1.4,x2:Math.max(x1,x2)+1.4,z2:Math.max(z1,z2)+1.4});}
function camRoom(fx,fz,D){const B=W.camBlocks;if(!B||!B.length||player.ski)return D;for(let s=1.6;s<=D;s+=.4){const x=player.x-fx*s,z=player.z-fz*s;if(B.some(b=>x>b.x1&&x<b.x2&&z>b.z1&&z<b.z2))return Math.max(2.4,s-.6);}return D;}
function tree(x,z,s,leaf,kind){s=s||1;leaf=leaf||'#5fbf5a';const y=gy(x,z);
  if(kind==='pine'){I('cyl','#8a5a3a',.3*s,2*s,.3*s,x,y+1*s,z);I('cone',leaf,1.9*s,3.4*s,1.9*s,x,y+3.4*s,z);I('cone',shade(leaf,.1),1.4*s,2.8*s,1.4*s,x,y+5*s,z);}
  else if(kind==='willow'){I('cyl','#8a6a4a',.45*s,4*s,.45*s,x,y+2*s,z);I('sph',leaf,2.6*s,2*s,2.6*s,x,y+5*s,z);for(let i=0;i<8;i++){const a=i*.785;I('cyl',shade(leaf,.08),.5*s,3.4*s,.5*s,x+Math.cos(a)*2*s,y+3.2*s,z+Math.sin(a)*2*s);}}
  else{I('cyl','#9b6a43',.35*s,3*s,.35*s,x,y+1.5*s,z);I('sph',leaf,2*s,1.8*s,2*s,x,y+4*s,z);I('sph',shade(leaf,.12),1.4*s,1.3*s,1.4*s,x+.9*s,y+4.8*s,z-.4*s);}
  col(x,z,.8*s);}
function bush(x,z,s,c,berries){s=s||1;c=c||'#5fbf5a';const y=gy(x,z);I('sph',c,1.3*s,1*s,1.3*s,x,y+.7*s,z);I('sph',shade(c,.1),.9*s,.8*s,.9*s,x+.8*s,y+.6*s,z+.3*s);
  if(berries)for(let i=0;i<4;i++)I('sph',berries,.14,.14,.14,x+Math.cos(i*1.7)*1.1*s,y+(.8+.3*(i%2))*s,z+Math.sin(i*1.7)*1.1*s);col(x,z,1.1*s);}
function flower(x,z,c,s){s=s||1;const y=gy(x,z);I('cylL','#4fae4a',.05,.7*s,.05,x,y+.35*s,z);I('sphL',c,.2*s,.13*s,.2*s,x,y+.75*s,z);I('sphL','#ffe066',.08*s,.08*s,.08*s,x,y+.82*s,z);}
function flowerPatch(x,z,n,rad,cols,R){R=R||Math.random;for(let i=0;i<n;i++){const a=R()*6.283,r=Math.sqrt(R())*rad;flower(x+Math.cos(a)*r,z+Math.sin(a)*r,cols[i%cols.length],.8+R()*.5);}}
function rock(x,z,s,c){s=s||1;I('sph',c||'#b7bcc9',1.2*s,.8*s,1*s,x,gy(x,z)+.3*s,z,0,x*7%3,0);col(x,z,1*s);}
function fence(x1,z1,x2,z2,c,noCol){c=c||'#fff8e6';const d=Math.hypot(x2-x1,z2-z1),n=Math.max(1,Math.round(d/2.4)),ang=Math.atan2(x2-x1,z2-z1);
  for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;I('box',c,.25,1.3,.25,x,gy(x,z)+.65,z);}
  for(let i=0;i<n;i++){const x=x1+(x2-x1)*(i+.5)/n,z=z1+(z2-z1)*(i+.5)/n,y=gy(x,z);I('box',c,.12,.18,d/n,x,y+.85,z,0,ang,0);I('box',c,.12,.18,d/n,x,y+.45,z,0,ang,0);}
  if(!noCol)colLine(x1,z1,x2,z2,.5);}
function water(y,size,c){const m=new THREE.Mesh(G.plane,new THREE.MeshLambertMaterial({color:c||'#6cc6ef'}));m.scale.set(size,1,size);m.position.y=y;W.ag.add(m);W.disp.push(m.material);return m;}
function pond(x,z,r,c){const m=new THREE.Mesh(G.disc,new THREE.MeshLambertMaterial({color:c||'#6cc6ef'}));m.scale.set(r,1,r);m.position.set(x,gy(x,z)+.08,z);W.ag.add(m);W.disp.push(m.material);col(x,z,r-.4);return m;}
function rr(x,a,b,w,h,r){x.beginPath();x.moveTo(a+r,b);x.arcTo(a+w,b,a+w,b+h,r);x.arcTo(a+w,b+h,a,b+h,r);x.arcTo(a,b+h,a,b,r);x.arcTo(a,b,a+w,b,r);x.closePath();}
function label(str,w,bg,fg){const c=document.createElement('canvas');c.width=512;c.height=128;const x=c.getContext('2d');
  x.fillStyle=bg||'#ffffff';x.strokeStyle=INK;x.lineWidth=10;rr(x,8,8,496,112,44);x.fill();x.stroke();
  x.fillStyle=fg||INK;let fs=60;x.font=`900 ${fs}px ui-rounded,"Arial Rounded MT Bold",system-ui,sans-serif`;while(x.measureText(str).width>470&&fs>24){fs-=4;x.font=`900 ${fs}px ui-rounded,"Arial Rounded MT Bold",system-ui,sans-serif`;}
  x.textAlign='center';x.textBaseline='middle';x.fillText(str,256,70);
  const t=new THREE.CanvasTexture(c),m=new THREE.SpriteMaterial({map:t,transparent:true,depthWrite:false}),sp=new THREE.Sprite(m);w=w||7;sp.scale.set(w,w/4,1);W.disp.push(t,m);return sp;}
function sign(x,z,str,h,w){const y=gy(x,z);I('cyl','#9b6a43',.14,h||3,.14,x,y+(h||3)/2,z);const s=label(str,w||7);s.position.set(x,y+(h||3)+.6,z);W.ag.add(s);return s;}
function spr(ch,s,x,y,z){const sp=sprite(ch,s);sp.position.set(x,y,z);W.ag.add(sp);return sp;}
/* trees all round the edge, leaving gaps where the exits are */
function edgeTrees(R,gapAngs,leafs,kind,Rnd){Rnd=Rnd||seed(R*7);for(let a=0;a<360;a+=5.5){if(gapAngs.some(g=>Math.abs(((a-g+540)%360)-180)<9))continue;
  for(let k=0;k<2;k++){const ang=(a+Rnd()*4)*D2R,r=R+3+k*5+Rnd()*3;tree(Math.cos(ang)*r,Math.sin(ang)*r,1+Rnd()*.5,leafs[Math.floor(Rnd()*leafs.length)],kind);}}}
const angOf=(x,z)=>(Math.atan2(z,x)/D2R+360)%360;
/* an exit: an arch at the edge of the area */
function buildExit(e){e.isOpen=()=>state.set.openAreas||(window.XOPEN&&XOPEN())||((!e.open||e.open())&&(!e.nlock||!!state.vines[e.nlock.key]));if(e.nlock&&!e.lock)e.lock='This gate has a number lock! Tap the 🔢 Number lock sign and answer the sums to open it.';
  if(e.noArch){if(!e.noLabel){const lb=label((e.icon||'')+' '+e.name,7);lb.position.set(e.x+6,gy(e.x,e.z)+5,e.z-2);W.ag.add(lb);}return;}
  const g=grp(),ang=Math.atan2(-e.x,-e.z),c=e.col||'#fff2b8';
  [-1,1].forEach(s=>{mk('cyl','#9b6a43',.42,4.4,.42,s*2.7,2.2,0,g);mk('sph',c,.6,.6,.6,s*2.7,4.5,0,g);});mk('arch',c,2.7,2.7,2.7,0,4.4,0,g);
  const lb=label((e.icon||'')+' '+e.name,7);lb.position.set(0,8,0);g.add(lb);
  const bar=grp();g.add(bar);for(let i=0;i<4;i++)mk('box','#c9905f',.25,2.2,.2,-1.8+i*1.2,1.2,0,bar);mk('box','#c9905f',5,.3,.25,0,1.6,0,bar);mk('box','#c9905f',5,.3,.25,0,.7,0,bar);
  const lock=sprite('🔒',1.6);lock.position.set(0,2.8,.3);bar.add(lock);
  g.rotation.y=ang;add(g,e.x,e.z);e.grp=g;e.bar=bar;
  const d=Math.hypot(e.x,e.z)||1,lx=-e.z/d,lz=e.x/d;[-1,1].forEach(k=>col(e.x+lx*2.7*k,e.z+lz*2.7*k,.5));if(e.gate)buildTypeGate(e);if(e.nlock)buildNumLock(e);}
/* a thick hedge all round the edge of an area, with a gap only where an arch is */
function edgeHedge(R,skip,c){c=c||'#4f9e46';const r=R+.8,n=Math.ceil(2*Math.PI*r/1.1);
  for(let i=0;i<n;i++){const a=i/n*Math.PI*2,x=Math.cos(a)*r,z=Math.sin(a)*r;if(skip&&skip(x,z))continue;if(W.exits.some(e=>!e.noArch&&Math.hypot(x-e.x,z-e.z)<3.4))continue;
    const y=gy(x,z),h=1+(i*37%10)/40;I('sph',c,1.35,1.5*h,1.35,x,y+1.1*h,z);if(i%3===0)I('sph',shade(c,.12),.95,.8,.95,x,y+2.3*h,z);if(i%7===0)I('sph',i%2?'#ff9ecb':'#ffffff',.17,.17,.17,x-Math.cos(a)*1.25,y+1.5,z-Math.sin(a)*1.25);}}
/* the sea: blocked south of z0 except along the jetty, with rocks along the shore */
function seaShore(z0,jx){rect(-300,z0,-jx,300);rect(jx,z0,300,300);
  for(let x=-64;x<=64;x+=1.5){if(Math.abs(x)<jx+.9)continue;I('sph',Math.abs(Math.round(x/1.5))%2?'#b7bcc9':'#c9cdd6',.95,.6,.85,x,gy(x,z0)+.15,z0+.5,0,x,0);}}
/* a wooden jetty you can walk along, with rails */
function jettyDeck(z0,len){const y=gy(0,z0)+.2;
  for(let z=z0;z<z0+len;z+=1.15)I('box','#c9905f',5.2,.3,1.05,0,y-.1,z+.55);
  for(let z=z0+2;z<z0+len;z+=4)[-1,1].forEach(k=>I('cyl','#9b6a43',.28,4,.28,k*2.5,y-1.9,z));
  [-1,1].forEach(k=>{I('box','#9b6a43',.18,.18,len,k*2.5,y+.9,z0+len/2);for(let z=z0+1;z<z0+len;z+=2.4)I('box','#9b6a43',.16,.9,.16,k*2.5,y+.45,z);});
  W.decks.push({x1:-2.7,z1:z0-.3,x2:2.7,z2:z0+len,y});seaShore(z0-.3,2.6);rect(-2.6,z0+len-.4,2.6,400);water(-1.4,500);return y;}
function walkY(x,z){const g=gy(x,z);for(const d of W.decks)if(x>d.x1&&x<d.x2&&z>d.z1&&z<d.z2)return Math.max(d.y,g);return g;}

/* ----- entering and leaving areas ----- */
function clearArea(){
  while(W.ag.children.length){const o=W.ag.children[0];W.ag.remove(o);}
  W.disp.forEach(d=>{try{d.dispose();}catch(e){}});W.disp=[];
  W.lift=null;W.gm=null;W.friendWait=null;W.act=null;W.cols=[];W.rects=[];W.camBlocks=[];W.decks=[];W.exits=[];W.things=[];W.spots=[];W.ticks=[];W.wanderers=[];W.trail=[];W.wild=null;W.rescue=null;
  W.fl.forEach(f=>scene.remove(f.sp));W.fl=[];}
function buildGround(A){const B=areaBox(A),w=B.x2-B.x1+80,d=B.z2-B.z1+80,nx=Math.min(140,Math.round(w/1.5)),nz=Math.min(160,Math.round(d/1.6)),geo=new THREE.PlaneGeometry(w,d,nx,nz);geo.rotateX(-Math.PI/2);geo.translate((B.x1+B.x2)/2,0,(B.z1+B.z2)/2);
  const p=geo.attributes.position,colA=new Float32Array(p.count*3),c1=new THREE.Color(A.ground),c2=new THREE.Color(A.ground2||A.ground),t=new THREE.Color();
  for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i);p.setY(i,A.hf?A.hf(x,z):0);const n=A.gmix?A.gmix(x,z):(Math.sin(x*.21)+Math.sin(z*.17+x*.05)+2)*.25;t.copy(c1).lerp(c2,Math.max(0,Math.min(1,n)));colA[i*3]=t.r;colA[i*3+1]=t.g;colA[i*3+2]=t.b;}
  geo.setAttribute('color',new THREE.BufferAttribute(colA,3));geo.computeVertexNormals();if(A.hf)W.gm={x0:(B.x1+B.x2)/2-w/2,z0:(B.z1+B.z2)/2-d/2,sx:w/nx,sz:d/nz,nx,nz,Y:p.array};
  const m=new THREE.Mesh(geo,new THREE.MeshLambertMaterial({vertexColors:true}));W.ag.add(m);W.disp.push(geo,m.material);}
function enterArea(id,pos,msg){
  initWorld();if(W.fail){show('title');say('Sorry, this iPad could not start the 3D world.');return;}
  const A=AREAS[id];clearArea();W.area=A;state.where=id;const first=!state.seen[id];state.seen[id]=true;save();
  scene.background.set(A.sky||'#a6dfff');scene.fog.color.set(A.fogC||A.sky||'#a6dfff');scene.fog.near=(A.fog||[70,200])[0];scene.fog.far=(A.fog||[70,200])[1];
  buildGround(A);W.exits=A.exits||[];W.exits.forEach(e=>snapExit(A,e));
  player.ski=null;player.float=false;player.vy=0;skiKit(false);player.grp.rotation.x=0;player.grp.userData.helmet.forEach(m=>m.visible=!!A.swim);$('#floatBtn').style.display=A.swim?'':'none';
  A.build();if(A.ski)skiFurniture(A);if(!A.noHedge)(A.rect?edgeRect(A.rect,A.hedgeSkip,A.hedgeC):edgeHedge(A.R,A.hedgeSkip,A.hedgeC));W.exits.forEach(buildExit);
  W.bossUp=null;buildSpots(A);if(A.island){const IS=islandOf(A.island);if(IS.boss&&IS.boss.area===id)buildBoss(IS);}
  enrich(A);
  flushTo(W.ag);groundPass(A);setTimeout(bakeSweep,0);
  if(id==='village'){spawnWanderers();if(arcadeOpen()&&!state.arcadeSaid&&!msg){state.arcadeSaid=true;save();msg='The Games Arcade is open! Find it by the Pup House, and play games with your pups.';}
    else if(!state.v4Said&&!msg&&state.intro){state.v4Said=true;save();msg='New in Pawprint Village: the Shop, the Pup Spa and Seb\'s Den! Spend your stars in the Shop, and look after your pups at the Spa.';}
    else if(!state.v6Said&&!msg&&state.intro){state.v6Said=true;save();msg='New in Pawprint Village: the Science Lab! Science pups inspired by real scientists are hiding on the islands. Find them, then try their experiments in the lab.';}}
  const s=pos||A.start;player.x=s[0];player.z=s[1];player.h=s[2]||0;player.y=walkY(player.x,player.z)+(A.swim?1.2:0);W.camYaw=player.h;player.lock=false;
  syncFollowers(true);camUpdate(0,true);W.findT=W.t;W.hintT=W.t;
  show('world');hud();
  const welcome=msg||(first&&A.hello?A.hello:`${A.icon} ${A.name}`);setTimeout(()=>say(welcome),350);
  if(!state.stats.walked)$('#tip').style.display='block';
}
function travel(e){if(player.lock)return;player.lock=true;sfx.chime();const to=AREAS[e.to];
  fadeTo(()=>enterArea(e.to,e.arrive),e.ride||null);}
function hud(){const A=W.area,wa=$('#wAct');wa.style.display=W.act?'block':'none';if(W.act)wa.textContent=`${W.act.icon} ${W.act.got}/${W.act.items.length}  ⏱ ${Math.floor(W.act.t)}`;else if(player.ski){wa.style.display='block';wa.textContent=`🚩 ${player.ski.passed}  ⏱ ${Math.floor(player.ski.t)}`;}$('#wPill').textContent=A?`${A.icon} ${A.name}${A.island?'  '+areaCount(A.id):''}`:'';$('#wStars').textContent='⭐ '+state.stars;}
function areaCount(a){const L=areaPups(a);return L.length?`🐶 ${foundIn(L)}/${L.length}`:'';}

/* ----- hiding spots and finding pups ----- */
const spotOf=p=>state.tagged[p.id]&&p.tag?p.tag:p.spot;
function buildSpots(A){Object.values(PUPS).filter(p=>p.area===A.id).forEach(p=>{const s=spotOf(p);addSpot(p,s);});}
function addSpot(p,s){const g=spot3D(s.kind);g.rotation.y=(s.x*13+s.z*7)%6;add(g,s.x,s.z);col(s.x,s.z,1.3);
  const o={p,x:s.x,z:s.z,grp:g,mark:null,easy:null,wob:0};
  if(isFound(p.id)){o.mark=spr('✅',1.5,s.x,gy(s.x,s.z)+3.4,s.z);}else{o.easy=spr('✨',1.6,s.x,gy(s.x,s.z)+3.6,s.z);o.easy.visible=state.set.hsEasy;}
  W.spots.push(o);return o;}
function searchSpot(s){if(player.lock||W.rescue||W.friendWait||(W.wild&&W.wild.p===s.p))return;player.lock=true;hush();sfx.sniff();state.stats.searches++;s.wob=.9;
  setTimeout(()=>{const p=s.p;
    if(p.tag&&!state.tagged[p.id]){tagRun(s);return;}
    revealPup(s);},900);}
function wildPup(p,x,z){if(W.wild){W.ag.remove(W.wild.grp);W.wild=null;}const g=pup3D(p,p.shiny||bestFriend(p.id));add(g,x,z);g.rotation.y=Math.atan2(player.x-x,player.z-z);W.wild={p,grp:g,x,z};return g;}
/* the first time a tag pup is found, it giggles and dashes off to its second hiding spot */
function tagRun(s){const p=s.p,t=p.tag;sfx.giggle();const g=wildPup(p,s.x+.01,s.z+.01);g.userData.jump=.6;
  say(`Hee hee! ${p.name} giggles and runs off to hide somewhere else! Can you find ${p.name} again?`);
  state.tagged[p.id]=true;save();
  const x0=s.x,z0=s.z,dur=2.2;let k=0;W.ticks.push(function run(dt){k+=dt/dur;const e=Math.min(1,k),x=x0+(t.x-x0)*e,z=z0+(t.z-z0)*e;g.position.set(x,gy(x,z)+Math.abs(Math.sin(e*18))*.4,z);g.rotation.y=Math.atan2(t.x-x0,t.z-z0);animPup(g,W.t,true);
    if(e>=1){W.ag.remove(g);W.wild=null;W.ag.remove(s.grp);if(s.easy)W.ag.remove(s.easy);W.cols=W.cols.filter(c=>!(c.x===s.x&&c.z===s.z));W.spots=W.spots.filter(q=>q!==s);addSpot(p,t);flushTo(W.ag);player.lock=false;return true;}});}
function revealPup(s){const p=s.p,dx=player.x-s.x,dz=player.z-s.z,d=Math.hypot(dx,dz)||1;const g=wildPup(p,s.x+dx/d*1.9,s.z+dz/d*1.9);g.userData.jump=.6;player.wow=.8;sfx.yip(p.pitch);
  const R=p.rescue||{icon:'🤲',verb:'Help',say:`${p.name} is stuck! Tap the button to help!`};
  W.rescue={p,s,n:0,need:R.taps||5,R};player.lock=false;say(R.say);setAct(R.icon,R.verb+'!');}
function rescueTap(){const W2=W.rescue;if(!W2)return;W2.n++;const g=W.wild&&W.wild.grp;sfx.pop();if(g){g.userData.jump=.35;floatS(W2.R.icon,g.position.x,g.position.y+2.4,g.position.z,1.6);}
  if(W2.n>=W2.need){W.rescue=null;W.friendWait={p:W2.p,s:W2.s};W.actBlock=W.t+1.2;setAct(null);setTimeout(()=>{if(W.friendWait&&W.friendWait.p===W2.p&&cur==='world'&&!ovOpen())friendGame(W2.p,W2.s);},500);}}
function freePup(p,s,score){const first=!Object.keys(state.found).length;player.cheer=1.25;player.wave=2.8;state.found[p.id]=Date.now();state.stats.found++;state.stars+=10;W.findT=W.t;W.trail.forEach(t=>W.ag.remove(t));W.trail=[];
  if(!state.buddy)state.buddy=p.id;save();hud();sfx.jingle();confetti(40);
  if(s){if(s.easy)W.ag.remove(s.easy);s.mark=spr('✅',1.5,s.x,gy(s.x,s.z)+3.4,s.z);}
  const T=TYPES[p.type],IS=islandOf(p.island),done=foundIn(IS.pups)===IS.pups.length;
  card({art:pupBox(p),h:`You found ${p.name}!`,h3:p.sci?`🔬 Science pup · ${p.breed}`:`${p.breed} ${typeBadge(p.type)}`,p:p.fact,say:p.sci?`You found ${p.name}, a science pup! ${p.fact}`:`You found ${p.name}! ${p.name} is a ${T.name} pup. ${p.fact}`,
    btns:[['💖 Yay!','green',()=>{
      if(W.wild){const g=W.wild.grp;W.ag.remove(g);W.wild=null;}
      syncFollowers();
      if(done&&IS.boss&&W.area&&IS.boss.area===W.area.id&&W.bossUp!==IS.id)setTimeout(()=>bossArrive(IS),1400);
      if(Object.keys(state.found).filter(id=>PUPS[id]).length===3&&!state.arcadeSaid){state.arcadeSaid=true;save();setTimeout(arcadeNews,350);}
      else if(first)setTimeout(()=>story([{art:pupBox(p),t:`${p.name} is your buddy now, and will follow you everywhere. ${T.name} pups like ${p.name} have a special power: a ${T.name} pup ${T.power}!`},
        {art:`<div class="fitsvg" style="width:160px">${grannySVG()}</div>`,t:'Every pup you find goes to live in Pawprint Village. You can see them all in the Pup House. Tap the book button to look!'}],()=>{}),300);
      else if(p.sci)setTimeout(()=>say(sciFoundSay(p)),300);
      else if(done)setTimeout(()=>say(`You found all ${IS.pups.length} pups on ${IS.name}! ${IS.bossHint||''}`),300);
      else{const A=W.area,L=areaPups(A.id),left=L.length-foundIn(L);setTimeout(()=>say(left?`${left} more ${left>1?'pups':'pup'} to find in ${A.name}.`:`You found every pup in ${A.name}! Well done!`),300);}
    }]]});}

/* ----- the buddy and pack follow Seb ----- */
function teamIds(){const ids=[];if(state.buddy)ids.push(state.buddy);(state.pack||[]).forEach(id=>{if(id!==state.buddy&&ids.length<3)ids.push(id);});return ids.filter(id=>PUPS[id]||id==='guest');}
const pupById=id=>id==='guest'?guestPup():PUPS[id];
function syncFollowers(snap){const ids=teamIds();
  for(let i=followers.length-1;i>=0;i--){if(ids.indexOf(followers[i].id)<0){scene.remove(followers[i].grp);followers.splice(i,1);}}
  ids.forEach((id,i)=>{let f=followers.find(q=>q.id===id);const p=pupById(id);if(!p)return;const key=id+(state.dress[(p.id||id)+'@1']||'')+(bestFriend(p.id||id)?'*':'');
    if(f&&f.key!==key){scene.remove(f.grp);followers.splice(followers.indexOf(f),1);f=null;}
    if(!f){f={id,key,grp:pup3D(p,p.shiny||bestFriend(p.id)),x:player.x,z:player.z,h:player.h,moving:false};scene.add(f.grp);followers.push(f);snap=true;}});
  followers.sort((a,b)=>ids.indexOf(a.id)-ids.indexOf(b.id));
  if(snap)followers.forEach((f,i)=>{f.x=player.x-Math.sin(player.h)*(2.4+i*2)+(i%2?1:-1)*.8;f.z=player.z-Math.cos(player.h)*(2.4+i*2);});}
function updateFollowers(dt,t){let lx=player.x,lz=player.z;
  followers.forEach((f,i)=>{f.grp.visible=!player.ski;if(player.ski){f.x=player.x-(i%2?1.5:-1.5);f.z=player.z-3-i*2;return;}const dx=lx-f.x,dz=lz-f.z,d=Math.hypot(dx,dz),gap=i?2.2:2.6;f.moving=d>gap+.3;
    if(f.moving){const sp=Math.min(player.ski?player.ski.v*1.3+4:SPEED*1.15,(d-gap)*4);f.x+=dx/d*sp*dt;f.z+=dz/d*sp*dt;f.h=lerpAng(f.h,Math.atan2(dx,dz),Math.min(1,dt*10));}
    if(d>30){f.x=lx-dx/d*gap;f.z=lz-dz/d*gap;}
    const fy=walkY(f.x,f.z);if(W.area.swim){f.y=f.y==null?player.y:f.y;f.y+=(Math.max(fy+.2,player.y-.5)-f.y)*Math.min(1,dt*3);}else f.y=fy;f.grp.position.set(f.x,f.y,f.z);f.grp.rotation.y=f.h;animPup(f.grp,t,f.moving);lx=f.x;lz=f.z;});}
function petBuddy(f){const p=pupById(f.id);pupTrick(f.grp,'roll');player.pet=1.9;player.h=Math.atan2(f.x-player.x,f.z-player.z);sfx.yip(p.pitch);floatS('💖',f.x,2.8+gy(f.x,f.z),f.z);state.stats.pets++;save();
  say(pick([`${p.name} loves a cuddle!`,`${p.name} wags happily!`,`Good pup, ${p.name}!`,`${p.name} gives you a big lick!`]));}

/* ----- found pups play in the village ----- */
function spawnWanderers(){const ids=Object.keys(state.found).filter(id=>PUPS[id]&&teamIds().indexOf(id)<0);
  bakeSweep();const R=seed(77);ids.slice(0,24).forEach((id,i)=>{const p=PUPS[id],a=R()*6.28,r=4+R()*9,c=W.area.park||[0,0],x=c[0]+Math.cos(a)*r,z=c[1]+Math.sin(a)*r;
    const g=pup3D(p,p.shiny||bestFriend(p.id));add(g,x,z);W.wanderers.push({p,grp:g,x,z,h:R()*6,tx:x,tz:z,wait:R()*3,c});});
  if(state.guest&&teamIds().indexOf('guest')<0){const p=guestPup();if(p){const c=W.area.park||[0,0],g=pup3D(p);add(g,c[0],c[1]);W.wanderers.push({p,grp:g,x:c[0],z:c[1],h:0,tx:c[0],tz:c[1],wait:1,c,guest:true});}}}
function updateWanderers(dt,t){W.wanderers.forEach(w=>{w.wait-=dt;const dx=w.tx-w.x,dz=w.tz-w.z,d=Math.hypot(dx,dz);let mv=false;
  if(d>.3){mv=true;const sp=3;w.x+=dx/d*sp*dt;w.z+=dz/d*sp*dt;w.h=lerpAng(w.h,Math.atan2(dx,dz),Math.min(1,dt*6));}
  else if(w.wait<0){const a=Math.random()*6.28,r=3+Math.random()*10;w.tx=w.c[0]+Math.cos(a)*r;w.tz=w.c[1]+Math.sin(a)*r;w.wait=3+Math.random()*8;}
  w.grp.position.set(w.x,gy(w.x,w.z),w.z);w.grp.rotation.y=w.h;animPup(w.grp,t,mv);});}

/* ----- the island boss: a unicorn friend and Muddle the Magpie ----- */
/* the last pup found in the boss's own area: the boss arrives straight away with a sparkle (24 Nov 2026), rather than after leaving and coming back */
function bossArrive(IS){if(cur!=='world'||!W.area||IS.boss.area!==W.area.id||W.bossUp===IS.id)return;const B=IS.boss,y=gy(B.x,B.z);
  for(let i=0;i<8;i++)floatS(pick(['✨','🌈','⭐']),B.x+(Math.random()-.5)*6,y+1+Math.random()*4,B.z+(Math.random()-.5)*6,2.2,1.8);sfx.chime();buildBoss(IS);}
function buildBoss(IS){const B=IS.boss;if(foundIn(IS.pups)<IS.pups.length&&!state.islDone[IS.id])return;if(W.bossUp===IS.id)return;W.bossUp=IS.id;
  const u=pup3D(B.uni,true);u.rotation.y=Math.atan2(-B.x,-B.z)+Math.PI;add(u,B.x,B.z);col(B.x,B.z,1.4);
  const m=magpie3D();m.scale.setScalar(1.3);if(W.area.swim){const hb=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#bfe8ff',transparent:true,opacity:.35,depthWrite:false}));hb.scale.setScalar(.7);hb.position.set(0,1.75,.3);m.add(hb);W.disp.push(hb.material);}add(m,B.x+2.6,B.z+.5,gy(B.x,B.z)+(B.perch||0));
  W.ticks.push(()=>{animPup(u,W.t,false);m.position.y=gy(B.x,B.z)+(B.perch||0)+Math.abs(Math.sin(W.t*3))*.3;m.rotation.y=Math.sin(W.t)*.5;});
  if(!state.islDone[IS.id]){W.things.push({x:B.x,z:B.z,r:5,icon:'💬',label:'Talk',act:()=>islandFinale(IS)});setTimeout(()=>say(`${B.uni.name} and Muddle are here! Go and talk to them!`),2500);}
  else W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(pick(B.after));}});}
function islandFinale(IS){player.lock=true;hush();const B=IS.boss,u=`<div class="fitsvg">${critterSVG(B.uni)}</div>`,mg=`<div class="fitsvg" style="width:150px">${magpieSVG()}</div>`;
  story(B.story.map(s=>({art:s[0]==='u'?u:s[0]==='m'?mg:u+mg,t:s[1]})),()=>{state.islDone[IS.id]=true;state.certs=state.certs||{};state.certs[IS.id]=Date.now();state.stars+=100;save();hud();sfx.fanfare();confetti(90);
    card({cls:'cert',art:`<div class="fitsvg" style="width:120px">${sebSVG(true)}</div>${u}`,h:IS.cert,h3:`🏅 ${IS.badge}`,p:`For finding all ${IS.pups.length} pups on ${IS.name}. Plus 100 stars!`,
      btns:[['🎉 Hooray!','green',()=>{player.lock=false;W.things=W.things.filter(t=>t.icon!=='💬');W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(pick(B.after));}});say(IS.nextSay||'');}]]});});}
function magpie3D(){const g=grp(),k='#26232e';mk('sph',k,.5,.45,.7,0,1.2,0,g);mk('sph','#ffffff',.36,.32,.45,0,1.1,.1,g);mk('sph','#ffffff',.3,.2,.4,.3,1.25,-.05,g);mk('sph','#ffffff',.3,.2,.4,-.3,1.25,-.05,g);
  [-1,1].forEach(s=>{const w=mk('sph','#2f4fa8',.16,.36,.6,s*.45,1.25,-.1,g);w.rotation.z=s*.3;});mk('box','#2f4fa8',.22,.08,1.2,0,1.3,-.9,g).rotation.x=-.35;
  mk('sph',k,.36,.34,.36,0,1.75,.35,g);mk('cone','#3a3338',.08,.3,.08,0,1.72,.75,g).rotation.x=Math.PI/2;
  [-1,1].forEach(s=>{mk('sph','#ffffff',.1,.1,.06,s*.17,1.82,.6,g,true);mk('sph','#26232e',.05,.06,.04,s*.17,1.82,.65,g,true);mk('cyl','#3a3338',.04,.5,.04,s*.15,.6,0,g);});
  shadow(g,.6);return g;}
function magpieSVG(){const k=INK,S=`stroke="${k}" stroke-width="5" stroke-linejoin="round"`;return `<svg viewBox="0 0 200 190"><g ${S}>
  <path d="M70 120 L10 160 L22 168 L84 134Z" fill="#2f4fa8"/><ellipse cx="100" cy="110" rx="52" ry="44" fill="#26232e"/><ellipse cx="108" cy="122" rx="32" ry="26" fill="#fff"/>
  <path d="M74 96 Q60 130 96 136 Q84 112 96 92Z" fill="#2f4fa8"/><circle cx="140" cy="66" r="34" fill="#26232e"/><path d="M168 62 L196 70 L168 78Z" fill="#ffd23f"/>
  <circle cx="148" cy="58" r="11" fill="#fff"/><circle cx="151" cy="58" r="6" fill="${k}" stroke="none"/><path d="M92 152 L86 178 M112 152 L116 178" fill="none"/></g>
  <circle cx="153" cy="55" r="2.4" fill="#fff"/><path d="M130 30 l6 -14 l6 14" fill="#ffd23f" stroke="${k}" stroke-width="3"/></svg>`;}

/* ----- the area map and the world map ----- */
function openMap(){if(!W.area)return;sfx.boop();if(!W.area.island)return worldMap();areaMap(islandOf(W.area.island));}
function areaMap(IS){const Mp=IS.map,c=$('#menuCard');c.className='card wide';let s=`<svg viewBox="0 0 860 470"><path d="${Mp.shape}" fill="#bfeaa8" stroke="${INK}" stroke-width="6"/>`;
  Mp.links.forEach(l=>{const a=Mp.nodes[l[0]],b=Mp.nodes[l[1]];s+=`<path d="M${a[0]} ${a[1]} L${b[0]} ${b[1]}" stroke="#fff8e6" stroke-width="16" stroke-linecap="round" fill="none"/><path d="M${a[0]} ${a[1]} L${b[0]} ${b[1]}" stroke="#c9a36b" stroke-width="5" stroke-dasharray="12 10" fill="none"/>`;});
  Object.keys(Mp.nodes).forEach(id=>{const n=Mp.nodes[id],A=AREAS[id],seen=state.seen[id],L=areaPups(id),f=foundIn(L),here=W.area.id===id;
    s+=`<g opacity="${seen?1:.55}"><circle cx="${n[0]}" cy="${n[1]}" r="52" fill="${here?'#fff2b8':'#ffffff'}" stroke="${INK}" stroke-width="5"/><text x="${n[0]}" y="${n[1]+16}" font-size="48" text-anchor="middle">${seen?A.icon:'❓'}</text>
      <text x="${n[0]}" y="${n[1]+84}" font-size="22" font-weight="900" text-anchor="middle" fill="${INK}">${seen?A.name:'Not visited yet'}</text>
      <text x="${n[0]}" y="${n[1]+110}" font-size="22" font-weight="900" text-anchor="middle" fill="${f===L.length?'#2e8b47':INK}">${seen&&L.length?`🐶 ${f} of ${L.length}${f===L.length?' ✅':''}`:''}</text></g>`;
    if(here)s+=`<text x="${n[0]+40}" y="${n[1]-36}" font-size="40">📍</text>`;});
  s+='</svg>';const tot=foundIn(IS.pups);
  c.innerHTML=`<h2>${IS.icon} ${IS.name}</h2>${s}<div class="mapnote">🐶 ${tot} of ${IS.pups.length} pups found</div><div class="btns"><button class="btn green" id="mapOk">✓ OK</button><button class="btn blue" id="mapHome">🏡 Go home</button></div>`;
  tap('#mapOk',()=>closeOv('menu'));tap('#mapHome',()=>{closeOv('menu');goHome();});$('#menu').classList.add('on');
  speak(`${IS.name}. You have found ${tot} of ${IS.pups.length} pups.`);}
function goHome(){if(!W.area||W.area.id==='village')return;const IS=islandOf(W.area.island)||ISLANDS[0];player.lock=true;sfx.chime();fadeTo(()=>enterArea('village',IS.homePos||AREAS.village.dock,'Home again in Pawprint Village!'),[IS.rideIcon,IS.homeSay||'Sailing home...']);}
function worldMap(){const c=$('#menuCard');c.className='card wide';
  const pos=[[140,95],[720,95],[120,255],[740,255],[150,415],[710,415],[330,95],[530,95]],all=[...ISLANDS.map(I=>({id:I.id,name:I.name,icon:I.icon,real:I})),...SOON];
  let s=`<svg viewBox="0 0 860 500"><rect x="0" y="0" width="860" height="500" rx="40" fill="#8fd3f5"/>`;
  for(let i=0;i<14;i++)s+=`<path d="M${(i*137)%820+20} ${(i*89)%460+20} q12 -8 24 0 t24 0" stroke="#fff" stroke-width="4" fill="none" opacity=".7"/>`;
  s+=`<ellipse cx="430" cy="250" rx="120" ry="80" fill="#bfeaa8" stroke="${INK}" stroke-width="5"/><text x="430" y="250" font-size="56" text-anchor="middle">🏡</text><text x="430" y="300" font-size="22" font-weight="900" text-anchor="middle" fill="${INK}">Pawprint Village</text>`;
  const slots=[{id:'meadow'}].concat(SOON);
  slots.forEach((q,i)=>{const I=all.find(a=>a.id===q.id),p=i===0?[430,450]:pos[i-1],open=!!I.real&&islOpen(I.id);
    s+=`<g opacity="${open?1:.6}" data-isl="${I.id}"><ellipse cx="${p[0]}" cy="${p[1]-10}" rx="${i===0?90:80}" ry="${i===0?44:40}" fill="${open?'#d9f5c2':'#e8eef2'}" stroke="${INK}" stroke-width="5"/>
      <text x="${p[0]}" y="${p[1]+4}" font-size="44" text-anchor="middle">${open?I.icon:I.icon}</text><text x="${p[0]}" y="${p[1]+42}" font-size="20" font-weight="900" text-anchor="middle" fill="${INK}">${I.name}${open?'':' 🔒'}</text></g>`;});
  s+='</svg>';
  c.innerHTML=`<h2>🗺️ The World Map</h2>${s}<div class="mapnote">Tap an island!</div><div class="btns"><button class="btn green" id="mapOk">✓ OK</button></div>`;
  tap('#mapOk',()=>closeOv('menu'));
  c.querySelectorAll('[data-isl]').forEach(g=>tap(g,()=>{const id=g.getAttribute('data-isl'),IS=islandOf(id);
    if(IS&&!islOpen(id)){sfx.oops();say(islLockSay(id));return;}
    if(!IS){const S=SOON.find(q=>q.id===id);sfx.oops();say(`${S.name} is still being built. ${id==='snowy'||id==='reef'?'It opens after Meadow Island!':'It opens later in the adventure!'}`);return;}
    if(state.seen[IS.areas[0].id]){closeOv('menu');player.lock=true;sfx.chime();fadeTo(()=>enterArea(IS.areas[0].id,IS.areas[0].start,`Welcome back to ${IS.name}!`),[IS.rideIcon,IS.rideSay]);}
    else say(`To get to ${IS.name}, take ${IS.ride} from the ${IS.from}.`);}));
  $('#menu').classList.add('on');speak('The World Map. Tap an island!');}

/* ----- finding what is near, and the big action button ----- */
let actIcon='';
function setAct(icon,txt){const b=$('#actBtn');if(!icon){b.classList.remove('on');actIcon='';return;}const key=icon+(txt||'');if(actIcon!==key){b.innerHTML=icon+(txt?`<small>${txt}</small>`:'');actIcon=key;}b.classList.add('on');}
function findNear(){let best=null,bd=1e9;const P=player,cand=(o,d,kind)=>{if(d<bd){bd=d;best={o,kind};}};if(P.ski)return null;const sw=W.area.swim,low=(x,z,y)=>!sw||P.y-(y!=null?y:gy(x,z))<4.5;
  if(W.rescue)return {kind:'rescue'};
  if(W.friendWait&&W.wild){const g=W.wild.grp.position;if(Math.hypot(P.x-g.x,P.z-g.z)<4.5)return {kind:'friend'};}
  W.things.forEach(t=>{if(t.show&&!t.show())return;if(!low(t.x,t.z,t.y))return;const d=Math.hypot(P.x-t.x,P.z-t.z);if(d<(t.r||3.5))cand(t,d-1,'thing');});
  W.spots.forEach(s=>{if(isFound(s.p.id))return;if(W.wild&&W.wild.p===s.p)return;if(!low(s.x,s.z))return;const d=Math.hypot(P.x-s.x,P.z-s.z);if(d<3.8)cand(s,d,'spot');});
  if(!best)followers.forEach(f=>{const d=Math.hypot(P.x-f.x,P.z-f.z);if(d<2.2)cand(f,d+2,'pet');});
  return best;}
function doAction(){if(cur!=='world'||ovOpen())return;initAudio();if(W.rescue)return rescueTap();if(W.t<(W.actBlock||0))return;const n=W.near;if(!n)return;
  if(n.kind==='rescue')return rescueTap();if(player.lock)return;
  if(n.kind==='friend')return friendGame(W.friendWait.p,W.friendWait.s);if(n.kind==='thing'){if(n.o.icon==='💬')player.wave=1.6;return n.o.act();}if(n.kind==='spot')return searchSpot(n.o);if(n.kind==='pet')return petBuddy(n.o);}

/* ----- controls ----- */
function joyReset(){joy.id=null;joy.x=joy.y=0;$('#joyBase').style.display=$('#joyKnob').style.display='none';}
(function(){const base=$('#joyBase'),knob=$('#joyKnob');
  document.addEventListener('pointerdown',e=>{initAudio();if(cur!=='world'||joy.id!==null||ovOpen()||e.target.closest('button,.pill,.card'))return;joy.id=e.pointerId;joy.ox=e.clientX;joy.oy=e.clientY;joy.x=joy.y=0;
    base.style.display=knob.style.display='block';base.style.left=knob.style.left=e.clientX+'px';base.style.top=knob.style.top=e.clientY+'px';});
  document.addEventListener('pointermove',e=>{if(e.pointerId!==joy.id)return;let dx=e.clientX-joy.ox,dy=e.clientY-joy.oy;const d=Math.hypot(dx,dy),mx=64;if(d>mx){dx=dx/d*mx;dy=dy/d*mx;}joy.x=dx/mx;joy.y=dy/mx;knob.style.left=(joy.ox+dx)+'px';knob.style.top=(joy.oy+dy)+'px';});
  const up=e=>{if(e.pointerId!==joy.id)return;joyReset();};document.addEventListener('pointerup',up);document.addEventListener('pointercancel',up);
  window.addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Space'&&cur==='world'){e.preventDefault();doAction();}});window.addEventListener('keyup',e=>{keys[e.code]=false;});})();

/* ----- frame update ----- */
function resolve(x,z){for(const c of W.cols){const dx=x-c.x,dz=z-c.z,d=Math.hypot(dx,dz),m=c.r+.55;if(d<m){if(d<1e-4){x+=m;continue;}x=c.x+dx/d*m;z=c.z+dz/d*m;}}
  for(const r of W.rects){const p=.55;if(x>r.x1-p&&x<r.x2+p&&z>r.z1-p&&z<r.z2+p){const o=[x-(r.x1-p),(r.x2+p)-x,z-(r.z1-p),(r.z2+p)-z],m=Math.min(...o);if(m===o[0])x=r.x1-p;else if(m===o[1])x=r.x2+p;else if(m===o[2])z=r.z1-p;else z=r.z2+p;}}
  if(W.area.rect){const B=W.area.rect;return[clamp(x,B.x1+.9,B.x2-.9),clamp(z,B.z1+.9,B.z2-.9)];}
  const R=W.area.R-.9,d=Math.hypot(x,z);if(d>R){x*=R/d;z*=R/d;}return[x,z];}
function camUpdate(dt,snap){const yaw=W.camYaw,fx=Math.sin(yaw),fz=Math.cos(yaw),A=W.area,sk=!!player.ski,D=camRoom(fx,fz,sk?13:A.camD||11),H=sk?6.5:A.swim?3.6:A.camH||5.4;
  const tx=player.x-fx*D,tz=player.z-fz*D,ty=Math.max(player.y+H,gy(tx,tz)+(A.swim?1.5:3)),k=snap?1:Math.min(1,dt*(sk?6:4));
  cam.position.x+=(tx-cam.position.x)*k;cam.position.y+=(ty-cam.position.y)*k;cam.position.z+=(tz-cam.position.z)*k;cam.lookAt(player.x,player.y+(A.swim?1.8:3.2),player.z);}
function update(dt){W.t+=dt;const t=W.t,P=player;
  let ix=joy.x,iy=joy.y;if(keys.ArrowLeft||keys.KeyA)ix=-1;if(keys.ArrowRight||keys.KeyD)ix=1;if(keys.ArrowUp||keys.KeyW)iy=-1;if(keys.ArrowDown||keys.KeyS)iy=1;
  const mag=Math.min(1,Math.hypot(ix,iy));P.moving=false;
  if(P.ski){if(!P.lock&&!ovOpen())skiUpdate(dt,ix);}
  else if(mag>.12&&!P.lock&&!ovOpen()&&!W.rescue){const yaw=W.camYaw,fx=Math.sin(yaw),fz=Math.cos(yaw);let mx=fx*(-iy)-fz*ix,mz=fz*(-iy)+fx*ix;const l=Math.hypot(mx,mz)||1;mx/=l;mz/=l;
    const sp=SPEED*(.35+.65*mag)*(W.area.swim?(state.gear.flippers?1.05:.8):1),r=resolve(P.x+mx*sp*dt,P.z+mz*sp*dt);P.x=r[0];P.z=r[1];P.h=lerpAng(P.h,Math.atan2(mx,mz),Math.min(1,dt*12));P.moving=true;
    if(iy<.4)W.camYaw=lerpAng(W.camYaw,P.h,Math.min(1,dt*1.3*mag));
    if(!state.stats.walked){state.stats.walked=1;save();$('#tip').style.display='none';}}
  if(W.area.swim){swimY(dt);P.grp.rotation.x=lerpAng(P.grp.rotation.x,P.moving?.75:0,Math.min(1,dt*4));}else P.y=walkY(P.x,P.z);P.grp.position.set(P.x,P.y,P.z);P.grp.rotation.y=P.h;
  P.wt+=P.moving?dt:0;animSeb(P,dt,t);
  /* exits */
  if(!P.lock)for(const e of W.exits){const d=Math.hypot(P.x-e.x,P.z-e.z);const open=e.isOpen();if(e.bar)e.bar.visible=!open;
    if(d<2.6){if(open){travel(e);break;}else if(P.moving){const dx=P.x-e.x,dz=P.z-e.z,dd=Math.hypot(dx,dz)||1;P.x=e.x+dx/dd*2.7;P.z=e.z+dz/dd*2.7;if(t-W.msgT>4){W.msgT=t;sfx.oops();say(typeof e.lock==='function'?e.lock():e.lock);}}}}
  updateFollowers(dt,t);updateWanderers(dt,t);
  W.ticks=W.ticks.filter(f=>!f(dt));
  W.spots.forEach(s=>{if(s.wob>0){s.wob-=dt;s.grp.rotation.z=Math.sin(s.wob*30)*.08*s.wob;}if(s.easy){s.easy.visible=state.set.hsEasy;s.easy.position.y=gy(s.x,s.z)+3.6+Math.sin(t*3)*.3;}});
  if(W.wild){animPup(W.wild.grp,t,false);}
  /* clues: a nearby hidden pup gives a little yip and its hiding spot wobbles */
  if(!W.rescue&&t-W.clueT>3.5){let nb=null,nd=11;W.spots.forEach(s=>{if(isFound(s.p.id))return;const d=Math.hypot(P.x-s.x,P.z-s.z);if(d<nd){nd=d;nb=s;}});
    if(nb){W.clueT=t;nb.wob=.6;sfx.yip((nb.p.pitch||1)*1.1);floatS(pick(['❓','🐾','💭']),nb.x,gy(nb.x,nb.z)+3,nb.z,1.4);}}
  /* never stuck: after a while the buddy sniffs out a trail of paw prints */
  if(W.area.island&&!W.rescue&&!P.lock&&t-W.findT>75&&t-W.hintT>75){W.hintT=t;sniffTrail();}
  W.fl=W.fl.filter(f=>{f.t+=dt;f.sp.position.y+=dt*1.6;f.sp.material.opacity=1-f.t/f.life;if(f.t>=f.life){scene.remove(f.sp);return false;}return true;});
  W.near=P.lock&&!W.rescue?null:findNear();const n=W.near;
  if(!n||ovOpen())setAct(null);else if(n.kind==='rescue'){const R=W.rescue.R;setAct(R.icon,`${R.verb}! ${W.rescue.n}/${W.rescue.need}`);}
  else if(n.kind==='friend')setAct('💖','Play');else if(n.kind==='thing')setAct(n.o.icon,n.o.label);else if(n.kind==='spot')setAct('🔍','Look');else setAct('💖','Pet');
  if(W.act)actTick(dt);
  camUpdate(dt);playClock(dt);}
function sniffTrail(){const P=player;let nb=null,nd=1e9;W.spots.forEach(s=>{if(isFound(s.p.id))return;const d=Math.hypot(P.x-s.x,P.z-s.z);if(d<nd){nd=d;nb=s;}});if(!nb)return;
  W.trail.forEach(t=>W.ag.remove(t));W.trail=[];const dx=nb.x-P.x,dz=nb.z-P.z,n=Math.min(10,Math.floor((nd-3)/2.5));
  for(let i=1;i<=n;i++){const x=P.x+dx*i/(n+1.2),z=P.z+dz*i/(n+1.2);W.trail.push(spr('🐾',1.1,x,gy(x,z)+.5,z));}
  const b=followers[0];if(b){b.grp.userData.jump=.6;sfx.sniff();say(`Woof! ${pupById(b.id).name} can smell a pup! Follow the paw prints!`);}else say('Look! Paw prints! Follow them to find a pup!');}
function frame(ts){requestAnimationFrame(frame);const dt=Math.min(W.dtMax||.05,((ts-(W.last||ts))/1000)||0);W.last=ts;if(!W.ready||cur!=='world'||sleepOn)return;update(dt);R3.render(scene,cam);}

/* ----- the Pup House ----- */
let bookIsl='meadow';
function showBook(isl){sfx.boop();closeOv('menu');bookIsl=isl||bookIsl;show('book');$('#bookStars').textContent='⭐ '+state.stars;
  const tabs=$('#bookTabs');tabs.innerHTML='';
  {const b=el('button','tab'+(bookIsl==='pack'?' sel':''),`🎒<small>${teamIds().length}/3</small>`);tap(b,()=>showBook('pack'));tabs.appendChild(b);}
  ISLANDS.forEach(IS=>{if(!islOpen(IS.id)){const b=el('button','tab lock',`${IS.icon}<small>🔒</small>`);tap(b,()=>{sfx.oops();say(islLockSay(IS.id));});tabs.appendChild(b);return;}
    const b=el('button','tab'+(IS.id===bookIsl?' sel':''),`${IS.icon}<small>${foundIn(IS.pups)}/${IS.pups.length}</small>`);tap(b,()=>showBook(IS.id));tabs.appendChild(b);});
  if(typeof SCI!=='undefined'&&SCI.length){const L=SCI.filter(p=>islOpen(p.island));const b=el('button','tab'+(bookIsl==='sci'?' sel':''),`🔬<small>${foundIn(L)}/${L.length}</small>`);tap(b,()=>showBook('sci'));tabs.appendChild(b);}
  if(state.guest){const b=el('button','tab'+(bookIsl==='guest'?' sel':''),'🎁<small>Guest</small>');tap(b,()=>showBook('guest'));tabs.appendChild(b);}
  [['badges','🏅',()=>`${MERITS.filter(m=>(state.badges||{})[m.id]).length}/${MERITS.length}`],['certs','📜',()=>`${CERTS.filter(c=>(state.certs||{})[c.id]).length}/${CERTS.length}`]].forEach(q=>{const b=el('button','tab'+(bookIsl===q[0]?' sel':''),`${q[1]}<small>${q[2]()}</small>`);tap(b,()=>showBook(q[0]));tabs.appendChild(b);});
  SOON.filter(S=>!islandOf(S.id)).forEach(S=>{const b=el('button','tab lock',`${S.icon}`);tap(b,()=>{sfx.oops();say(`${S.name} is coming later. Its pups are still hiding!`);});tabs.appendChild(b);});
  const gr=$('#bookGrid');gr.innerHTML='';gr.className='';$('#bookPager').style.display='none';
  if(bookIsl!==showBook.last){awPage=0;showBook.last=bookIsl;}
  if(bookIsl==='badges')return badgesPage();if(bookIsl==='certs')return certsPage();
  if(bookIsl==='sci'){const L=SCI.filter(p=>islOpen(p.island));pager(L.length,14,()=>showBook('sci'));L.slice(awPage*14,awPage*14+14).forEach(p=>gr.appendChild(pupCard(p,isFound(p.id))));say(`Science pups. ${foundIn(L)} of ${L.length} found. Visit the Science Lab to try their experiments!`);return;}
  if(bookIsl==='pack')return packPage();
  if(bookIsl==='guest'){const p=guestPup();if(p)gr.appendChild(pupCard(p,true));say(`${p?p.name:'Your guest'} came all the way from Puppy Quest 2!`);return;}
  const IS=islandOf(bookIsl)||ISLANDS[0];IS.pups.concat((IS.bonus||[]).filter(p=>isFound(p.id))).forEach(p=>gr.appendChild(pupCard(p,isFound(p.id))));
  say(`${IS.name}. ${foundIn(IS.pups)} of ${IS.pups.length} pups found.`);}
/* My pack (23 Nov): the best buddy and the two pack pups, as in Puppy Quest 2 */
function packPage(){if(teamIds().includes('guest')&&!guestPup()&&!packPage.wait&&typeof loadPQ2Friends==='function'){packPage.wait=1;loadPQ2Friends(()=>{packPage.wait=0;if(cur==='book'&&bookIsl==='pack'&&guestPup())showBook('pack');});}
  const gr=$('#bookGrid');gr.className='packp';const bud=state.buddy?pupById(state.buddy):null;
  const pk=(state.pack||[]).filter(id=>id!==state.buddy&&pupById(id)).slice(0,2).map(pupById);
  const slots=[{p:bud,lab:'⭐ Best buddy',role:'buddy',how:'Make buddy'},{p:pk[0],lab:'🐾 Pack pup',role:'pack',how:'Join pack'},{p:pk[1],lab:'🐾 Pack pup',role:'pack',how:'Join pack'}];
  slots.forEach(s=>{const p=s.p;
    if(!p){const b=el('button','pcard pk no',`<div class="pkt">${s.lab}</div><div class="pke">+</div><span>Empty</span><small>Tap a pup you have found, then tap ${s.how}</small>`);
      tap(b,()=>{sfx.boop();say(`This space is empty. Tap any pup you have found in the Pup House, then tap ${s.how}!`);});gr.appendChild(b);return;}
    const T=TYPES[p.type],A=AREAS[p.area],I=A&&islandOf(A.island),fr=(state.friend||{})[p.id]||0;
    const b=el('button','pcard pk '+s.role,`<div class="pkt">${s.lab}</div>${pupBox(p,{anim:false})}<span>${p.name}</span><small>${p.breed||''}</small>`+
      (T?`<small class="pkp">${T.icon} ${T.name} pup: ${T.power}</small>`:'<small class="pkp">🎁 From Puppy Quest 2</small>')+
      `<small>${I?I.icon+' '+I.name:''}${p.sci?' 🔬':''}</small><small>💖 Friendship ${fr} of 10</small>`);
    tap(b,()=>{sfx.yip(p.pitch||1);pupDetail(p);});gr.appendChild(b);});
  gr.appendChild(el('div','pkn','Your pack follows you everywhere, and their Pup Type powers can open gates. Tap a pup to see it, or to change your pack.'));
  const names=pk.map(p=>p.name);say(`Your pack. ${bud?bud.name+' is your best buddy':'You have no best buddy yet'}${names.length?`, and ${names.join(' and ')} ${names.length>1?'are':'is'} in your pack`:''}. Your pack follows you everywhere!`);}
function pupCard(p,found){const id=p.guest?'guest':p.id;
  if(!found){const b=el('button','pcard miss',`<div class="q">?</div><span>${AREAS[p.area].icon} ${AREAS[p.area].name}</span>`);tap(b,()=>{sfx.boop();say(`A pup is still hiding in ${AREAS[p.area].name}. ${p.hint||''}`);});return b;}
  const role=state.buddy===id?'buddy':(state.pack||[]).indexOf(id)>=0?'pack':'';
  const b=el('button','pcard '+role,`<div class="who">${role==='buddy'?'⭐':role==='pack'?'🐾':''}</div>${pupBox(p,{anim:false})}<span>${p.name}</span><small>${p.breed}</small><small>${TYPES[p.type]?TYPES[p.type].icon+' '+TYPES[p.type].name:'🎁 Guest'}</small>`);
  tap(b,()=>pupDetail(p));return b;}
function pupDetail(p){const id=p.guest?'guest':p.id,isB=state.buddy===id,inP=(state.pack||[]).indexOf(id)>=0;
  const fr=(state.friend||{})[p.id]||0;card({art:pupBox(p),h:p.name,h3:`${p.breed} ${p.type?typeBadge(p.type):''}`,p:`${p.fact}<br><span style="font-size:22px">💖 Friendship ${fr} of 10${fr>=10?': best friends!':''}</span>`,say:`${p.name}. ${p.fact}`,
    btns:[[isB?'⭐ My buddy':'⭐ Make buddy','green',()=>{if(!isB){state.pack=(state.pack||[]).filter(q=>q!==id);if(state.buddy)state.pack.unshift(state.buddy);state.pack=state.pack.slice(0,2);state.buddy=id;save();sfx.chime();}showBook();}],
      [isB?'↩ Back':inP?'🏡 Leave pack':'🐾 Join pack','white',()=>{if(isB){showBook();return;}if(inP)state.pack=state.pack.filter(q=>q!==id);else{state.pack=(state.pack||[]).filter(q=>q!==id);state.pack.push(id);if(state.pack.length>2){const out=state.pack.shift();say(`${pupById(out).name} goes back to play in the village.`);}}save();sfx.boop();showBook();}]]});}
function leaveBook(){sfx.boop();if(W.area){show('world');syncFollowers(true);if(W.area.id==='village'){W.wanderers.forEach(w=>W.ag.remove(w.grp));W.wanderers=[];spawnWanderers();}hud();}else showTitle();}

/* ----- bring a friend from Puppy Quest 2 ----- */
function guestPup(){const g=state.guest;if(!g)return null;const B=window.PQ2_BASE&&window.PQ2_BASE.find(p=>p.id===g.id);if(!B)return null;
  return Object.assign({},B,{id:'guest',guest:true,lv:1,type:null,breed:B.breed,dressAs:g.cos||null,fact:`${B.name} came to visit from Puppy Quest 2! ${B.fact}`});}
function loadPQ2Friends(cb){if(window.PQ2_BASE)return cb();const s=document.createElement('script');s.src='pq2friends.js';s.onload=cb;s.onerror=()=>cb();document.head.appendChild(s);}
function bringFriend(code){const j=readCode(code,'PQ2:');if(!j||!j.buddy)return false;
  loadPQ2Friends(()=>{const B=window.PQ2_BASE&&window.PQ2_BASE.find(p=>p.id===j.buddy.id);if(!B){say('Sorry, that pup could not come across.');return;}
    state.guest={id:B.id,cos:(j.dress||{})[B.id+'@'+j.buddy.lv]||null};state.stars+=50;save();closeOv('settings');const p=guestPup();
    card({cls:'cert',art:pupBox(p),h:`${p.name} has arrived!`,h3:'🎁 A friend from Puppy Quest 2',p:`${p.name} sailed all the way to Pawprint Village to play with Seb. Plus 50 stars!`,btns:[['💖 Welcome!','green',()=>{if(W.area&&W.area.id==='village'&&cur==='world'){W.wanderers.forEach(w=>W.ag.remove(w.grp));W.wanderers=[];spawnWanderers();}}]]});});
  return true;}

/* ----- grown-ups panel (hold the cog for 3 seconds) ----- */
const esc0=s=>String(s).replace(/[&<>"]/g,ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'})[ch]);
function openSettings(){pickVoice();const S=state.set,c=$('#setCard'),mv0=S.mvol==null?(S.mvol='m',1):0,o=(k,v,txt)=>`<button class="opt${S[k]===v?' on':''}" data-k="${k}" data-v='${JSON.stringify(v)}'>${txt}</button>`;
  c.innerHTML=`<h2>⚙️ Grown-ups</h2>
  <div class="srow">🔊 Read-aloud voice<div class="opts">${o('voice',true,'On')}${o('voice',false,'Off')}</div></div>
  <div class="srow"><span>🗣️ Voice: <b>${voice?esc0(voice.name):'the iPad\'s own voice'}</b></span><div class="opts"><button class="opt" id="vPrev">◀</button><button class="opt" id="vNext">▶</button><button class="opt" id="vTest">Test</button></div></div>
  <div class="snote">${voiceList.length?`${voiceList.length} English ${voiceList.length===1?'voice':'voices'} found on this iPad. Tap ◀ or ▶ to hear the next one.`:'No other English voices found yet.'} More voices can be added in the iPad's speech settings.</div>
  <div class="srow">🎵 Sounds and music<div class="opts">${o('sfx',true,'Sounds on')}${o('sfx',false,'Sounds off')}${o('music',true,'Music on')}${o('music',false,'Music off')}</div></div>
  <div class="srow">🎶 Music volume<div class="opts">${o('mvol','l','Low')}${o('mvol','m','Medium')}${o('mvol','h','High')}</div></div>
  <div class="srow">😴 Sleepy break after<div class="opts">${o('sleepMin',0,'Off')}${o('sleepMin',15,'15 min')}${o('sleepMin',20,'20 min')}${o('sleepMin',30,'30 min')}</div></div>
  <div class="srow">🔍 Hide and seek<div class="opts">${o('hsEasy',false,'Normal')}${o('hsEasy',true,'Easy (sparkles)')}</div></div>
  <div class="srow">🔓 Open all areas on an island<div class="opts">${o('openAreas',false,'Off')}${o('openAreas',true,'On')}</div></div>
  <div class="srow">🏝️ Open islands early<div class="opts">${o('openIsl',false,'Off')}${o('openIsl',true,'On')}</div></div>
  <div class="snote">Islands open in pairs: Snowy Summit and Coral Reef after Meadow Island, then Ninja Mountains and Number Kingdom after those two. "Open islands early" opens them all straight away; the rides in Pawprint Village take Seb there.</div>
  <div class="srow" style="border:0">💾 Backup code<div class="opts"><button class="opt" id="bkCopy">Copy</button><button class="opt" id="bkLoad">Restore from box</button></div></div>
  <textarea id="bkTxt" spellcheck="false" autocapitalize="off" autocorrect="off" autocomplete="off" placeholder="Paste a code here. A Puppy Quest 3 code starts with PQ3:"></textarea><div class="snote" id="bkMsg" style="color:#d9363e"></div>
  <div class="snote">Copy makes a code for this game: keep it somewhere safe (in Notes, or a message to yourself). To bring a saved game back, paste its code in the box and tap Restore.</div>
  <div class="srow" style="border:0">🎁 Bring a friend from Puppy Quest 2<div class="opts"><button class="opt" id="pq2Go">Bring my buddy</button></div></div>
  <div class="snote">In Puppy Quest 2, open the grown-ups panel and copy the backup code. Paste it in the box above, then tap "Bring my buddy". Puppy Quest 2 is not changed.</div>
  <div class="btns"><button class="btn green" id="setOk">✓ Done</button></div>`;
  c.querySelectorAll('.opt[data-k]').forEach(b=>tap(b,()=>{if(b.dataset.k==='openIsl'||b.dataset.k==='openAreas')openSettings.dirty=b.dataset.k;S[b.dataset.k]=JSON.parse(b.dataset.v);if(b.dataset.k==='sleepMin')state.playSecs=0;save();sfx.boop();openSettings();if(b.dataset.k==='voice'&&!S.voice)quiet();if(b.dataset.k==='mvol'){setMusVol();musPreview();}}));
  const vStep=d=>{initAudio();if(!voiceList.length){speak('Hello Seb! Shall we find some puppies?');return;}const i=voiceList.indexOf(voice),n=voiceList.length;voice=voiceList[((i<0?0:i)+d+n)%n];S.voiceName=voice.name;save();openSettings();speak('Hello Seb! Shall we find some puppies?');};
  tap('#vPrev',()=>vStep(-1));tap('#vNext',()=>vStep(1));tap('#vTest',()=>{initAudio();speak('Hello Seb! Shall we find some puppies?');});
  tap('#bkCopy',()=>{const t=$('#bkTxt');t.value=backupCode();t.focus();t.select();try{t.setSelectionRange(0,t.value.length);}catch(e){}try{navigator.clipboard.writeText(t.value).then(()=>msg('Copied!'),()=>{try{document.execCommand('copy');msg('Copied!');}catch(_){msg('Select the code in the box and copy it.');}});}catch(e){try{document.execCommand('copy');msg('Copied!');}catch(_){}}sfx.chime();});
  const msg=t=>{$('#bkMsg').textContent=t;};
  tap('#bkLoad',()=>{const fp=x=>(x.stars||0)+'|'+JSON.stringify(x.found||{})+'|'+JSON.stringify(x.badges||{}),now=fp(state),same=x=>fp(x)===now,j=readCode($('#bkTxt').value,'PQ3:',same);
    if(!j||j.v!==1){sfx.oops();msg('That code does not look right. A Puppy Quest 3 code starts with PQ3: (paste it into the empty box).');return;}
    if(same(j)){sfx.oops();msg('That is the code for the game already on this iPad. Paste the code you saved, then tap Restore.');return;}
    const pups=o=>Object.keys(o.found||{}).length;msg('');closeOv('settings');
    card({h:'Bring back the saved game?',p:`The saved game has ${pups(j)} pups found and ${j.stars||0} stars. It will replace the game on this iPad, which has ${pups(state)} pups found and ${state.stars||0} stars.`,
      btns:[['✅ Yes, bring it back','green',()=>{const txt=JSON.stringify(j);RESTORING=true;let ok=false;try{localStorage.setItem(SAVE,txt);ok=localStorage.getItem(SAVE)===txt;}catch(e){}
        if(!ok){RESTORING=false;save();openSettings();msg('This iPad would not store the saved game, so nothing has changed. Please try again.');return;}location.reload();}],['No, keep this game','',()=>openSettings()]]});});
  tap('#pq2Go',()=>{if(!bringFriend($('#bkTxt').value)){sfx.oops();msg('Paste a Puppy Quest 2 backup code (it starts with PQ2:) in the box first.');}});
  tap('#setOk',()=>{closeOv('settings');if(sleepOn&&!(state.sleepUntil>Date.now()))hideSleep();const d=openSettings.dirty;openSettings.dirty=null;if(!d)return;
    const msg=d==='openIsl'&&S.openIsl?'All the islands are open! Take the rides from Pawprint Village.':null;
    if(cur==='book')showBook();else if(cur==='world'&&W.area)enterArea(W.area.id,[player.x,player.z,player.h],msg);else if(msg)setTimeout(()=>say(msg),300);});
  $('#settings').classList.add('on');}
function settingsFromSleep(){state.sleepUntil=0;state.playSecs=0;save();hideSleep();openSettings();}

/* ----- sleepy break ----- */
function playClock(dt){const m=state.set.sleepMin;if(!m)return;state.playSecs+=dt;if(Math.floor(state.playSecs)%15===0&&state.playSecs-dt<Math.floor(state.playSecs))save();
  if(state.playSecs>=m*60){state.playSecs=0;state.sleepUntil=Date.now()+20*60*1000;save();showSleep();}}
function showSleep(){sleepOn=true;quiet();hush();joyReset();const a=$('#sleepArt');const ids=teamIds();a.innerHTML=ids.slice(0,3).map(id=>pupBox(pupById(id),{anim:false})).join('')||`<div class="fitsvg">${sebSVG()}</div>`;
  for(let i=0;i<3;i++){const z=el('div','zz','💤');z.style.left=(180+i*170)+'px';z.style.top='20px';z.style.animationDelay=(i*.8)+'s';a.appendChild(z);}
  $('#sleep').classList.add('on');}
function hideSleep(){sleepOn=false;$('#sleep').classList.remove('on');}
function checkSleep(){if(state.sleepUntil>Date.now()){showSleep();return true;}if(sleepOn)hideSleep();return false;}

/* ============ Pawprint Village (the hub) ============ */
AREAS.village={id:'village',name:'Pawprint Village',icon:'🏡',R:56,ground:'#8fd170',ground2:'#a9df8a',sky:'#a6dfff',fog:[80,230],
  start:[0,12,Math.PI],dock:[0,36,Math.PI],park:[-24,16],hedgeSkip:(x,z)=>z>43,
  hf:(x,z)=>{const r=Math.hypot(x,z);return (Math.sin(x*.09)*.5+Math.cos(z*.08)*.5)*sstep(22,40,r)-4.5*sstep(45,52,z);},
  hello:'Welcome to Pawprint Village! This is your home. Take the ferry from the jetty to Meadow Island!',
  build(){const R=seed(11);
    /* plaza and map tower */
    const pl=new THREE.Mesh(G.disc,M('#ead9bd'));pl.scale.set(13,1,13);pl.position.y=.05;W.ag.add(pl);
    const path=(x1,z1,x2,z2,w)=>{const d=Math.hypot(x2-x1,z2-z1),m=new THREE.Mesh(G.plane,M('#ead9bd'));m.scale.set(w||4,1,d);m.position.set((x1+x2)/2,gy((x1+x2)/2,(z1+z2)/2)+.06,(z1+z2)/2);m.rotation.y=Math.atan2(x2-x1,z2-z1);W.ag.add(m);};
    path(0,12,0,44,5);path(-8,-6,-20,-10,4);path(8,-6,21,-12,4);path(-6,8,-22,16,4);path(6,8,36,22,4);path(-6,8,-38,26,4);
    I('cyl','#c9c2b8',2.2,12,2.2,0,6,-4);I('cyl','#b0a89c',2.6,.8,2.6,0,12.2,-4);I('cone','#e8423a',3,4,3,0,14.6,-4);I('cyl','#9b6a43',.1,3,.1,0,17.5,-4);I('box','#3fae5a',1.8,1,.08,.9,18.4,-4);
    I('box','#5b4636',1.4,2.2,.2,0,1.1,-1.75);for(let i=0;i<3;i++)I('box','#9bdcff',.8,.8,.2,0,4+i*3,-1.76);col(0,-4,2.6);
    const tl=label('🗺️ Map Tower',7);tl.position.set(0,20.5,-4);W.ag.add(tl);
    W.things.push({x:0,z:-1,r:4,icon:'🗺️',label:'Map',act:()=>{sfx.chime();worldMap();}});
    /* fountain */
    I('cyl','#c9c2b8',2.4,.8,2.4,0,.4,5);I('cyl','#7fd3f0',2,.1,2,0,.82,5,0,0,0,true);I('cyl','#c9c2b8',.4,2,.4,0,1.6,5);I('sph','#7fd3f0',.6,.4,.6,0,2.7,5,0,0,0,true);col(0,5,2.5);
    /* the Pup House */
    const hx=-20,hz=-12;I('box','#ffb3cf',10,6,8,hx,3,hz);I('pyr','#e8423a',8.2,4.2,6.2,hx,8.1,hz,0,Math.PI/4,0);I('box','#5b4636',2.6,3.6,.3,hx+2.6,1.8,hz+4.05);I('cyl','#5b4636',1.3,.3,1.3,hx+2.6,3.6,hz+4.05,Math.PI/2,0,0);
    I('box','#9bdcff',1.6,1.6,.2,hx-2.4,3.4,hz+4.05);I('sph','#ffffff',.5,.5,.2,hx,8.4,hz+3);rect(hx-5,hz-4,hx+5,hz+4);
    const hl=label('🏠 Pup House',7);hl.position.set(hx,12,hz);W.ag.add(hl);
    W.things.push({x:hx+2.6,z:hz+6,r:4,icon:'📖',label:'Pup House',act:()=>showBook()});
    /* Granny's cottage */
    const gx=22,gz=-14;I('box','#fff2b8',8,5,7,gx,2.5,gz);I('pyr','#9b6a43',6.6,3.6,5.6,gx,6.8,gz,0,Math.PI/4,0);I('box','#5b4636',1.8,3,.3,gx,1.5,gz+3.55);I('box','#9bdcff',1.4,1.4,.2,gx-2.4,3,gz+3.55);I('box','#9bdcff',1.4,1.4,.2,gx+2.4,3,gz+3.55);
    I('cyl','#c26a32',.5,2,.5,gx+2.4,8.6,gz-1);rect(gx-4,gz-3.5,gx+4,gz+3.5);camBlock(gx-4,gz-3.5,gx+4,gz+3.5);flowerPatch(gx,gz+5,14,3,['#ff9ecb','#ffffff','#c9b6ff'],R);
    const gr=granny3D();gr.rotation.y=Math.PI*1.1;add(gr,gx-4,gz+6);col(gx-4,gz+6,1);
    W.ticks.push(()=>{gr.rotation.y=Math.atan2(player.x-gr.position.x,player.z-gr.position.z);});
    W.things.push({x:gx-4,z:gz+6,r:4.2,icon:'💬',label:'Granny',act:grannyHint});
    /* the park */
    const pk=new THREE.Mesh(G.disc,M('#b6e89a'));pk.scale.set(12,1,12);pk.position.set(-24,gy(-24,16)+.07,16);W.ag.add(pk);
    tree(-33,10,1.2,'#5fbf5a');tree(-31,4,1.1,'#7fcf6a');tree(-15,24,1,'#5fbf5a');I('box','#c9905f',3,.3,1,-18,.9,9);I('box','#c9905f',3,1,.25,-18,1.4,8.6);col(-18,9,1.5);
    sign(-14,12,'🐶 Pup Park',3,6);flowerPatch(-24,16,24,10,['#ff9ecb','#fff27a','#ffffff'],R);
    /* the jetty and the ferry to Meadow Island */
    jettyDeck(44,18);const boat=ferry3D();add(boat,4.8,58,-1.1);boat.rotation.y=Math.PI/2;W.ticks.push(()=>{boat.position.y=-1.1+Math.sin(W.t*1.5)*.12;boat.rotation.z=Math.sin(W.t*1.1)*.03;});
    sign(-10,41.5,'⛴️ To Meadow Island',3,6);
    W.things.push({x:0,z:52,r:5,icon:'⛴️',label:'Ferry',act:()=>{const IS=islandOf('meadow');player.lock=true;sfx.chime();fadeTo(()=>enterArea(IS.areas[0].id,IS.areas[0].start),[IS.rideIcon,IS.rideSay]);}});
    /* Meadow Island far away across the water */
    I('sph','#8fd170',60,14,40,0,-6,200);I('cyl','#fff8e6',2,12,2,-8,10,186);I('cone','#e8423a',2.6,4,2.6,-8,18,186);
    /* future departure points */
    /* the chairlift to Snowy Summit: a station with a big wheel, towers and moving chairs up to a snowy mountain */
    {const cx=40,cz=20,y0=gy(cx,cz),mx=130,my=37,ytop=x=>y0+6.2+(x-cx)*(my+4-y0-6.2)/(mx-cx);
      I('box','#c9c2b8',9,1,7,cx,y0+.5,cz);[[-4,-3],[4,-3],[-4,3],[4,3]].forEach(q=>I('cyl','#8a8f99',.25,6,.25,cx+q[0],y0+3.5,cz+q[1]));I('box','#e8423a',10,.5,8,cx,y0+6.6,cz);I('pyr','#e8423a',7,1.6,5.6,cx,y0+7.6,cz,0,Math.PI/4,0);
      I('tor','#3a3338',2.4,2.4,2.4,cx+2,y0+6,cz,Math.PI/2,0,0);I('box','#fff2b8',2.6,3,2.6,cx-2.8,y0+2.5,cz-4.2);I('box','#9bdcff',1.4,1,.2,cx-2.8,y0+3,cz-2.85);rect(cx-4.5,cz-5.5,cx+4.5,cz+3.5);
      const towers=[cx+14,cx+30,cx+50,cx+72,cx+96];towers.forEach(x=>{const top=ytop(x),base=x<cx+56?gy(x,cz):top-14;I('cyl','#8a8f99',.4,top-base+1,.4,x,(top+base)/2,cz);I('box','#8a8f99',.3,.3,3.4,x,top,cz);if(x<cx+16)col(x,cz,.7);});
      const pts=[[cx+2,y0+6]].concat(towers.map(x=>[x,ytop(x)])).concat([[mx,my+4]]);
      [-1.4,1.4].forEach(dz=>{for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],L=Math.hypot(b[0]-a[0],b[1]-a[1]);I('box','#3a3338',L,.08,.08,(a[0]+b[0])/2,(a[1]+b[1])/2,cz+dz,0,0,Math.atan2(b[1]-a[1],b[0]-a[0]));}});
      const chairs=[];for(let i=0;i<14;i++){const c=grp();mk('cyl','#3a3338',.05,1.8,.05,0,-.9,0,c);mk('box','#3d8fe0',1.4,.18,.9,0,-1.8,0,c);mk('box','#3d8fe0',1.4,.9,.16,0,-1.4,-.4,c);W.ag.add(c);chairs.push({c,k:i/14});}
      W.ticks.push(dt=>chairs.forEach(o=>{o.k=(o.k+dt*.012)%1;const up=o.k<.5,f=up?o.k*2:(1-o.k)*2,x=cx+2+(mx-cx-2)*f;o.c.position.set(x,ytop(x)-.1,cz+(up?-1.4:1.4));o.c.rotation.y=Math.PI/2;}));
      I('cone','#c9d6e6',80,130,80,180,my-75,cz+10);I('cone','#ffffff',34,48,34,180,my+14,cz+10);I('cone','#d9e4ef',50,80,50,150,my-60,cz-60);I('cone','#ffffff',20,28,20,150,my-10,cz-60);
      I('box','#8a8f99',8,5,6,mx+2,my+2,cz);I('box','#e8423a',9,.6,7,mx+2,my+4.8,cz);
      const lb=label(islOpen('snowy')&&islandOf('snowy')?'🚡 Chairlift to Snowy Summit':'🚡 Snowy Summit 🔒',8);lb.position.set(cx,y0+10.5,cz);W.ag.add(lb);
      W.things.push({x:cx-6.5,z:cz,r:4.6,icon:'🚡',label:'Chairlift',act:()=>rideTo('snowy')});}
    /* the little harbour with the yellow submarine to Coral Reef */
    {const hx=-42,hz=32;pond(hx,hz,4.6,'#4fb0e0');for(let a=0;a<6.28;a+=.35)I('sph','#b7bcc9',.7,.45,.6,hx+Math.cos(a)*4.8,gy(hx+Math.cos(a)*4.8,hz+Math.sin(a)*4.8)+.15,hz+Math.sin(a)*4.8,0,a,0);
      for(let i=0;i<3;i++)I('box','#c9905f',1.1,.25,2.2,hx+5.2+i*1.1,gy(hx+6,hz-1)+.35,hz-1.5);
      const sb=sub3D();sb.scale.setScalar(.75);add(sb,hx,hz,gy(hx,hz)+.6);sb.rotation.y=.6;W.ticks.push(()=>{sb.position.y=gy(hx,hz)+.6+Math.sin(W.t*1.4)*.15;sb.rotation.z=Math.sin(W.t)*.04;});
      const lb=label(islOpen('reef')&&islandOf('reef')?'🚢 Submarine to Coral Reef':'🚢 Coral Reef 🔒',8);lb.position.set(hx,gy(hx,hz)+6.5,hz);W.ag.add(lb);
      W.things.push({x:hx+7.5,z:hz-2.5,r:4.6,icon:'🚢',label:'Submarine',act:()=>rideTo('reef')});}
    /* village houses and coming-soon plots */
    [[-40,-10,'#c9e6ff'],[-36,-26,'#ffe1c9'],[38,-2,'#e6d9ff'],[34,-30,'#d9f5c2'],[-6,-34,'#ffd9e6'],[12,-36,'#fff2b8']].forEach((h,i)=>{I('box',h[2],6,4,5,h[0],gy(h[0],h[1])+2,h[1]);I('pyr',i%2?'#e8423a':'#5b8def',4.8,2.6,4,h[0],gy(h[0],h[1])+5.3,h[1],0,Math.PI/4,0);I('box','#5b4636',1.2,2,.2,h[0],gy(h[0],h[1])+1,h[1]+2.55);rect(h[0]-3,h[1]-2.5,h[0]+3,h[1]+2.5);camBlock(h[0]-3,h[1]-2.5,h[0]+3,h[1]+2.5);});
    /* the Games Arcade */
    {const ax=-28,az=-34;I('box','#b58cff',10,5.5,7,ax,gy(ax,az)+2.75,az);I('box','#ffd23f',10.4,.6,7.4,ax,gy(ax,az)+5.8,az);for(let i=0;i<5;i++)I('box',['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0','#ff9ecb'][i],1.6,.5,.2,ax-4+i*2,gy(ax,az)+5,az+3.6);
      I('box','#5b4636',2.6,3.4,.3,ax,gy(ax,az)+1.7,az+3.55);I('box','#9bdcff',1.6,1.6,.2,ax-3.2,gy(ax,az)+2.8,az+3.55);I('box','#9bdcff',1.6,1.6,.2,ax+3.2,gy(ax,az)+2.8,az+3.55);rect(ax-5,az-3.5,ax+5,az+3.5);
      const al=label('🎮 Games Arcade',7);al.position.set(ax,gy(ax,az)+9,az);W.ag.add(al);spr('🕹️',2.2,ax,gy(ax,az)+6.8,az+3.8);
      W.things.push({x:ax,z:az+6,r:4,icon:'🎮',label:'Games',act:()=>{if(arcadeOpen()){sfx.chime();openGames();}else{sfx.oops();const n=3-Object.keys(state.found).filter(id=>PUPS[id]).length;say(`The Games Arcade opens when you have found 3 pups. ${n} more to go!`);}}});}
    [['🛁 Pup Spa',26,-34],['🏟️ Sports Field',44,-16]].forEach(q=>{fence(q[1]-4,q[2]-3,q[1]+4,q[2]-3,'#fff8e6');sign(q[1],q[2],q[0]+' soon',3,7);});
    edgeTrees(56,[90],['#5fbf5a','#7fcf6a','#4fae4a'],null,R);
  }};
function ferry3D(){const g=grp();mk('box','#ffffff',7,1.4,3,0,.7,0,g);mk('box','#e8423a',7.2,.4,3.2,0,1.5,0,g);mk('box','#9bdcff',3,1.6,2.2,-.5,2.5,0,g);mk('cyl','#ffd23f',.4,1.8,.4,1.4,3.6,0,g);mk('sph','#ffffff',.5,.4,.5,1.4,4.8,0,g);const f=sprite('🌼',1.6);f.position.set(-3,2.6,0);g.add(f);return g;}
function arcadeNews(){card({art:'<div style="font-size:110px;line-height:1">🎮</div>',h:'The Games Arcade is open!',p:'Go to Pawprint Village to play Treat Toss, Tummy Tickle, Bubble Pop and Paw Pairs whenever you like!'});}
function rideTo(id){const IS=islandOf(id);if(!IS||!islOpen(id)){sfx.oops();say(IS?`${IS.rideName||'This ride'} opens soon! ${islLockSay(id)}`:'That ride is still being built!');return;}
  player.lock=true;sfx.chime();fadeTo(()=>enterArea(IS.areas[0].id,IS.areas[0].start),[IS.rideIcon,IS.rideSay]);}
function grannyHint(){sfx.chime();state.stats.granny=(state.stats.granny||0)+1;save();const IS=ISLANDS[0];
  if(!Object.keys(state.found).length)return say('Hello, dear! The pups are hiding on Meadow Island. Take the ferry from the jetty, and look for wobbling hiding spots!');
  for(const IS2 of ISLANDS){if(!islOpen(IS2.id))continue;const miss=IS2.pups.filter(p=>!isFound(p.id));if(miss.length){const p=pick(miss),A=AREAS[p.area];
    return say(state.seen[p.area]?`I heard a little yip in ${A.name}. ${p.hint||''}`:`Have you been to ${A.name} yet? ${A.how||''}`);}
    if(!state.islDone[IS2.id])return say(IS2.bossHint);}
  say(ISLANDS.every(I=>islOpen(I.id))?'You found every pup on every island! More islands are coming soon. Well done, Seb!':`You have done everything you can for now, dear. ${islLockSay(ISLANDS.find(I=>!islOpen(I.id)).id)}`);}

/* ============ title and start ============ */
function showTitle(){show('title');hush();}
function play(){initAudio();if(checkSleep())return;
  if(!state.intro){story([
    {art:`<div class="fitsvg" style="width:150px">${grannySVG()}</div>`,t:'Hello Seb! Welcome to Pawprint Village, a little village in the middle of the sea, with islands all around it.'},
    {art:`<div class="fitsvg" style="width:170px">${magpieSVG()}</div>`,t:'Oh dear! Muddle the Magpie flew over the islands and borrowed every shiny thing he could find. The pups chased after him, and now they are hiding all over the islands!'},
    {art:`<div class="fitsvg" style="width:120px">${sebSVG(true)}</div>`,t:'Can you find the pups and bring them home? Start on Meadow Island. Take the little ferry from the jetty!'}],
    ()=>{state.intro=true;save();enterArea('village',null,'Drag your finger to walk. Find the jetty, then tap the big button to take the ferry!');});return;}
  const A=AREAS[state.where]||AREAS.village;enterArea(A.id,A.start);}
