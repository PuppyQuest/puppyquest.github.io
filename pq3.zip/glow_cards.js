/* ================================================================
   Night Glow: the Night Glow cards (25 Nov 2026, claude/night-glow-design.md section 11)
   - a card for each of the 119 Night Glow pups, the firefly (Season Friend) and the nine unicorns
     in night looks; on the Seasons shelf, one tab per island plus a 🌙 tab for the firefly,
     Foxfire and Dusk;
   - stats and powers as on the main card (the saga's fixed scale); the everyday move gets a night name;
   - the island's scene at night, a star and moon frame, a moon badge, a firefly edge, and the
     Night Glow-only Glow finish (cardlook.js rolls it);
   - packs per area, dark blue with a crescent moon; the Pup House and binder night look.
   Hooks: window.XCARDS, window.SEALOOK['g:'], window.SEAPACK.g_, CLOOK.EDGE.glow.
   ================================================================ */
(function(){
const GW=window.GLOW,GL=window.GLOOK,gp=GL.gp,X=()=>(state&&state.sx&&state.sx.glow)||{};
const GMOVE={herd:'Moonbeam Dash',pull:'Moonbeam Dash',snow:'Moonbeam Dash',tug:'Moonbeam Dash',rescue:'Moonbeam Dash',dig:'Comet Leap',giant:'Comet Leap',sniff:'Star Pounce',point:'Star Pounce',truffle:'Star Pounce',
 zoom:'Glow Flash',spots:'Glow Flash',fetch:'Glow Flash',splash:'Glow Flash',guard:'Night Howl',yodel:'Night Howl',snore:'Night Howl',cuddle:'Firefly Twirl',wiggle:'Firefly Twirl',rainbow:'Firefly Twirl',cloud:'Firefly Twirl'};
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const HOW={swarm:'✨ Found where the fireflies gathered',prints:'🐾 Found by following its glowing paw prints',stars:'⭐ Found by joining the stars'};
const dstr=d=>d&&d>1e12?new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'';
const TM={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const hs=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;},cp=(v,a,b)=>Math.max(a,Math.min(b,v));
/* the same numbers as the main card, worked out here so the binder is not asked while it builds its sets */
function gcard(p,set,n,of,isl){const C=window.CARDS,B=C.breedOf(p.breed),T=C.TY(p.type),z=SZ[B.sz]||SZ.m,sh=p.shiny||p.season?10:0,st={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  st[C.STATS[hs(p.id)%4][0]]+=1;for(const k in st)st[k]=cp(st[k],1,10);
  const c={stats:st,zoom:cp(z[0]+sh,30,120),moves:[[GMOVE[B.g]||'Glow Flash',1,z[1]],[TM[p.type]||'Pup Power',2,z[2]+sh]],col:T.col,bg:shade(T.col,.72)};
  Object.assign(c,{cid:'3:gl_'+p.id,game:3,set,n,of,src:p,base:p.id,name:p.name,breed:p.breed,type:p.type,rar:p.shiny||p.season?'sparkly':'common',fact:GL.FACT[p.id]||p.fact||'',glow:true,gisl:isl});
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return p.id==='dusk'?'the Star Party, Pawprint Village':(A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>GW.xFound(p.id);c.foundAt=()=>{const v=(X().found||{})[p.id];return typeof v==='number'?v:0;};
  c.art=an=>critterSVG(gp(p),{anim:an,sparkly:!!(p.shiny||p.season)});
  c.hint=()=>GW.opened()?`${p.name} is hiding in ${AREAS[p.area]?AREAS[p.area].name:'the village'} in Night Glow. ${p.hint||''}`:'Night Glow opens after Christmas Snow is finished!';
  c.back=()=>{const d=c.foundAt(),h=(X().how||{})[p.id];return [`🌙 Found in Night Glow${d?' on '+dstr(d):''}`,`📍 ${c.home()}`,HOW[h]||'✨ Found in Night Glow','✨ Its fireflies flew home to the Glow'];};
  return c;}
function unicard(I,set,n,of){const u=I.boss.uni,C=window.CARDS,T=C.TY(I.type);const c={cid:'3:gl_'+u.id,game:3,set,n,of,src:u,base:u.id,name:u.name,breed:u.breed,type:I.type,rar:'unicorn',uni:true,glow:true,gisl:I.id,
  fact:`${u.name}'s night lesson: ${GW.LESSON[u.id]||'Every light matters.'}`,zoom:120,moves:[['Rainbow Gallop',1,30],['Moonbeam',3,100]],col:T.col,bg:'#e6e8ff',stats:{spd:9,brn:9,cud:10,brv:9}};
  c.home=()=>I.name;c.earned=()=>!!(X().fl||{})[I.id];c.foundAt=()=>(X().fl||{})[I.id]||0;c.art=an=>critterSVG(gp(u),{anim:an});
  c.hint=()=>`Find ${GW.NEED} Night Glow pups on ${I.name}, and ${u.name} will teach your firefly a flash of the Glow Song.`;
  c.back=()=>{const d=c.foundAt();return [`✨ Taught a flash of the Glow Song${d?' on '+dstr(d):''}`,`🦄 ${I.name}`,`💬 ${GW.LESSON[u.id]||''}`];};return c;}
function flycard(set,n,of){const c={cid:'3:gl_fly',game:3,set,n,of,src:{id:'gfly'},base:'gfly',get name(){return GW.fly().name;},breed:'Firefly',type:'spark',rar:'friend',glow:true,gisl:'village',
  fact:'Fireflies are beetles, not flies! Their cold light is made by mixing a chemical called luciferin with oxygen, right inside their tails.',zoom:100,moves:[['Glow Flash',1,30],['Glow Song',3,90]],col:'#7aa83a',bg:'#eaf6d8',stats:{spd:8,brn:8,cud:9,brv:9}};
  c.home=()=>'Bluebell Wood, Meadow Island';c.earned=()=>GW.named();c.foundAt=()=>GW.named()&&X().fly.at||0;c.art=()=>GW.flySVG().replace('<svg ','<svg class="pup" ');
  c.hint=()=>'Meet the little firefly when Night Glow begins!';
  c.back=()=>[`✨ Named by Seb${c.foundAt()?' on '+dstr(c.foundAt()):''}`,'📍 Bluebell Wood, the home of the Glow','🎵 Learning the Glow Song',X().done?'🌟 Led the Glow Flight with Seb!':`✨ ${GW.nFl()} of 9 flashes learned`];return c;}
/* the sets, one per island and a special one */
const SETS={};
function mkSet(key){if(SETS[key])return SETS[key];let S;const lock=()=>'Night Glow opens after Christmas Snow is finished!';
  if(key==='glow'){const L=[];S={id:'3:g_glow',game:3,g:true,season:'glow',isl:'g_glow',name:'Night Glow',short:'Night Glow',icon:'🌙',open:()=>GW.opened(),lockSay:lock,cards:L};
    L.push(flycard(S.id,1,3),gcard(GL.GPUPS.foxfire,S.id,2,3,'snowy'),gcard(GL.GPUPS.dusk,S.id,3,3,'village'));}
  else{const I=islandOf(key),P=GW.islX(I),of=P.length+1,L=P.map((p,i)=>gcard(p,'3:g_'+key,i+1,of,key));L.push(unicard(I,'3:g_'+key,of,of));
    S={id:'3:g_'+key,game:3,g:true,season:'glow',isl:'g_'+key,name:`${I.name} at night`,short:I.name.split(' ')[0],icon:I.icon,open:()=>GW.opened(),lockSay:lock,cards:L};}
  return (SETS[key]=S);}
function entry(key){const I=key!=='glow'&&islandOf(key),pups=key==='glow'?[GL.GPUPS.foxfire,GL.GPUPS.dusk]:GW.islX(I),areas=key==='glow'?['village','eagle']:I.areas.map(a=>a.id).filter(a=>GW.areaX(a).some(p=>pups.indexOf(p)>=0));
  const mine=cid=>cid.indexOf('3:gl_')===0&&(cid==='3:gl_fly'?key==='glow':cid==='3:gl_'+(I&&I.boss.uni.id)||pups.some(p=>cid==='3:gl_'+p.id));
  const inSet=a=>GW.areaX(a).filter(p=>pups.indexOf(p)>=0);
  return {isl:'g_'+key,season:'glow',keys:()=>areas.map(a=>'x:gl:'+(key==='glow'?'g'+a:a)),set:()=>mkSet(key),
    ids(){if(!state)return [];const out=pups.filter(p=>GW.xFound(p.id)).map(p=>'3:gl_'+p.id);if(key==='glow'&&GW.named())out.unshift('3:gl_fly');if(I&&(X().fl||{})[I.id])out.push('3:gl_'+I.boss.uni.id);return out;},
    key(cid){if(!mine(cid))return undefined;if(cid==='3:gl_fly')return null;const id=cid.slice(5),p=GW.gpup(id);return p?'x:gl:'+(key==='glow'?'g'+p.area:p.area):null;},
    done(k){const a=k.slice(5).replace(/^g(?=village|eagle)/,'');return inSet(a).every(p=>GW.xFound(p.id));},
    info(k){const a=k.slice(5).replace(/^g(?=village|eagle)/,''),A=AREAS[a];return {k,isl:'g_'+key,icon:key==='glow'?'🌙':(A&&A.icon)||'🌙',name:`${A?A.name:'Night Glow'} at night`,short:A?A.name:'Night Glow',glow:true};},
    say(k,c){const a=k.slice(5).replace(/^g(?=village|eagle)/,''),A=AREAS[a],left=inSet(a).filter(p=>!GW.xFound(p.id)).length;return `${c.name}'s Night Glow card is waiting in the ${A?A.name:''} night pack. Find ${left} more Night Glow ${left>1?'pups':'pup'} there to open it!`;}};}
window.XCARDS=(window.XCARDS||[]).concat(['glow'].concat(ISLANDS.map(I=>I.id)).map(entry));

/* ---------------- the night look ---------------- */
const K=INK,LIME='#d8ff5a',GOLD='#ffd23f';
const st5=(x,y,r,c,o)=>{let d='';for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.45:r;d+=(i?'L':'M')+(x+Math.cos(a)*rr).toFixed(1)+' '+(y+Math.sin(a)*rr).toFixed(1);}return `<path d="${d}Z" fill="${c}" opacity="${o}"/>`;};
const cres=(x,y,r,c,o)=>`<path d="M${x} ${y-r} A${r} ${r} 0 1 0 ${x} ${y+r} A${(r*.42).toFixed(1)} ${r} 0 1 1 ${x} ${y-r} Z" fill="${c}" opacity="${o}"/>`;
const ffly=(x,y,r)=>`<circle cx="${x}" cy="${y}" r="${r*2.6}" fill="${LIME}" opacity=".3"/><circle cx="${x}" cy="${y}" r="${r}" fill="${LIME}"/>`;
const PATG=`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">${st5(14,14,6,'#fff',.55)}${st5(48,42,4,GOLD,.6)}${cres(46,14,6,GOLD,.55)}${cres(16,46,5,'#fff',.45)}<circle cx="32" cy="30" r="1.6" fill="#fff" opacity=".6"/></svg>`;
function night(i){const R=seed(i.length*37+11);let s=`<rect width="200" height="190" fill="#0f1844" opacity=".52"/><rect width="200" height="80" fill="#0a1238" opacity=".35"/>`;
  for(let k=0;k<16;k++)s+=`<circle cx="${(R()*200).toFixed(1)}" cy="${(R()*70).toFixed(1)}" r="${(.7+R()*1.2).toFixed(1)}" fill="#fff" opacity="${(.6+R()*.4).toFixed(2)}"/>`;
  s+=`<circle cx="34" cy="30" r="20" fill="#f6f0d0" opacity=".18"/>`+cres(34,30,13,'#f6f0d0',1);
  if(i==='reef')for(let k=0;k<12;k++)s+=`<circle cx="${(R()*200).toFixed(1)}" cy="${(110+R()*75).toFixed(1)}" r="${(1+R()*1.6).toFixed(1)}" fill="#7ff4ff" opacity=".85"/>`;
  else if(i==='planet')s+=`<path d="M150 20 l30 18" stroke="#fff" stroke-width="2" opacity=".8" stroke-linecap="round"/><path d="M120 40 l20 12" stroke="#fff" stroke-width="1.4" opacity=".6" stroke-linecap="round"/>`;
  else for(let k=0;k<7;k++)s+=ffly((R()*200).toFixed(1),(100+R()*70).toFixed(1),1.6);
  return s;}
const EDGEG=()=>{let s=`<path d="M0 0 H400 V14 Q200 30 0 14 Z" fill="#1f2a5a" opacity=".85"/>`;for(let x=24;x<390;x+=34)s+=st5(x,10+((x/34)%2)*4,4.5,x%68<34?GOLD:'#fff',1);
  let k=0;for(let y=50;y<540;y+=38){[6,394].forEach(x=>{s+=`<g class="twk" style="animation-delay:${(k%5)*.35}s">${ffly(x,y,3.2)}</g>`;k++;});}
  for(let x=30;x<380;x+=34){s+=`<g class="twk" style="animation-delay:${(k%5)*.35}s">${ffly(x,557,3)}</g>`;k++;}
  return s+cres(16,26,11,GOLD,1)+cres(384,26,11,GOLD,1)+st5(16,546,9,GOLD,1)+st5(384,546,9,GOLD,1);};
if(window.CLOOK&&CLOOK.EDGE)CLOOK.EDGE.glow=EDGEG;
function packSVG(s){const n=s.n!=null?s.n:(s.cards||[]).length;const R=seed((s.icon||'').length*7+n);let st='';for(let k=0;k<14;k++)st+=st5(30+R()*140,70+R()*150,2+R()*2.5,R()<.5?'#fff':GOLD,.9);
  return `<svg viewBox="0 0 200 270" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="20" width="160" height="236" rx="16" fill="#1b2452" stroke="#5b4636" stroke-width="5"/>${st}`+
  `<g class="gmoon"><circle cx="100" cy="66" r="34" fill="#f6f0d0" opacity=".22"/>${cres(100,66,24,'#f6f0d0',1)}</g>`+
  `<circle cx="100" cy="150" r="36" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="166" text-anchor="middle" font-size="40">${s.icon||'🌙'}</text>`+
  `<rect x="34" y="214" width="132" height="34" rx="12" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="239" text-anchor="middle" font-size="21" font-weight="900" fill="#5b4636" font-family="Arial">${n} card${n===1?'':'s'}</text></svg>`;}
function openPack(P,pk){GW.snd.twinkle();setTimeout(()=>{const b=pk&&pk.querySelector('.gmoon');if(b)b.classList.add('pop');GW.snd.blink();},450);}
window.GCL={pat:()=>PATG,night,packSVG,open:openPack,gcard};
window.SEALOOK=Object.assign(window.SEALOOK||{},{'g:':{pat:()=>PATG,over:night,edge:'glow',badge:'🌙'}});
window.SEAPACK=Object.assign(window.SEAPACK||{},{g_:{packSVG,open:openPack}});

/* the night look for cards, the Pup House and the binder */
const FLK=(()=>{const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300">${[[40,50],[205,25],[150,150],[265,205],[70,250],[115,80],[250,110],[30,175],[185,265],[95,205],[280,30]].map((q,i)=>`<circle cx="${q[0]}" cy="${q[1]}" r="${i%3?6:9}" fill="${i%2?LIME:'#fff6c2'}" opacity=".3"/><circle cx="${q[0]}" cy="${q[1]}" r="${i%3?2.2:3.2}" fill="${i%2?LIME:'#fff6c2'}"/>`).join('')}</svg>`;return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';})();
const css=document.createElement('style');css.textContent=`
.mc.fin-w,.tc.fin-w{box-shadow:0 0 14px #c8ff4a,0 0 0 2px #5cffb0 inset}.mc.fin-w .finsh,.tc.fin-w .finsh{background:radial-gradient(ellipse at 50% 50%,rgba(200,255,74,.0) 55%,rgba(200,255,74,.35) 100%);animation:gGlow 2.4s ease-in-out infinite}
@keyframes gGlow{0%,100%{opacity:.55}50%{opacity:1}}
.pq2pack .gmoon{transform-origin:100px 66px;transition:transform .5s}.pq2pack .gmoon.pop{transform:scale(1.5);filter:drop-shadow(0 0 10px #fff6c2)}
#book[data-sea=glow],#binder[data-sea=glow]{isolation:isolate}
#book[data-sea=glow]{background:linear-gradient(#1b2452,#2c3a78)}#book[data-sea=glow] #bookH{color:#fff;text-shadow:2px 2px 0 #26232e}
#binder[data-sea=glow]{background:#1b2452}#binder[data-sea=glow] .bcover{border-color:rgba(216,255,90,.5)}
#book[data-sea=glow]::before,#binder[data-sea=glow]::before{content:'';position:absolute;left:0;right:0;top:0;bottom:0;z-index:-1;background-image:${FLK};background-size:300px 300px;pointer-events:none;animation:gTwinkle 4s ease-in-out infinite}
@keyframes gTwinkle{0%,100%{opacity:.6}50%{opacity:1}}@media (prefers-reduced-motion:reduce){#book[data-sea=glow]::before,#binder[data-sea=glow]::before{animation:none}}
#book[data-sea=glow] .tab{opacity:1;background:#e6e8f8}#book[data-sea=glow] .tab.sel{background:#d8ff8a}#binder[data-sea=glow] #bdTabs .tab.sel{background:#d8ff8a}`;
document.head.appendChild(css);
})();
