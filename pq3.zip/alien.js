/* ================================================================
   Seb's Puppy Quest 3: the Black Hole side quest, part 2 (24 Nov 2026).
   The alien planet on the far side of the galaxy: round like the Planet
   Hop planets but twice as wide, named by Seb when he lands. Zuzu, a
   shy alien dog, has lost her 10 puppies at hide-and-seek. Her antennae
   glow brighter when a puppy is near. Five zones, two puppies in each,
   and every puppy is found a different way:
     Glowing Flower Meadow: Peep (inside one of 9 closed flowers, hot and
       cold) and Dart (six legs, plays tag right round the planet)
     Jelly Hills: Wobble (tap jelly blobs until one giggles) and Puff
       (bounce up to a floating island)
     Rainbow Crystal Fields: Swatch (spot the crystal with blinking eyes)
       and Glow (switch off the helmet light in the Dark Cave)
     Singing Rocks: Echo (copy her tune) and Popper (numbered holes and
       a maths clue)
     Upside-down Forest: Upside (under a floating island, look up and
       call) and Boing (catch him in a net as he lands)
   Found puppies run to Zuzu, then follow Seb in a line. With all 10
   home, each puppy mends part of the Stargazer while Seb counts to 10,
   Zuzu gives him a star map and he flies home (bhquest.js).
   ================================================================ */
(function(){
const BH=window.BHQ,S=BH.S,snd=BH.snd,L=192,HL=L/2,wd=d=>PLANET.wrapD(d,L),wr=v=>v-L*Math.floor((v+HL)/L),wy=(x,z)=>gy(wr(x),wr(z));
const dist=(x1,z1,x2,z2)=>Math.hypot(wd(x1-x2),wd(z1-z2)),near=(x,z)=>dist(player.x,player.z,x,z);
const ZN={meadow:{x:0,z:0,name:'Glowing Flower Meadow',col:'#a8ecc0',path:'#fff27a',icon:'🌸'},jelly:{x:-55,z:-45,name:'Jelly Hills',col:'#ffb8dc',path:'#ff8fd0',icon:'🍮',say:'The Jelly Hills! Everything here wobbles.'},
  crystal:{x:55,z:-50,name:'Rainbow Crystal Fields',col:'#cdb8ff',path:'#b58cff',icon:'💎',say:'The Rainbow Crystal Fields! Every crystal is a different colour. And there is a dark cave!'},
  sing:{x:55,z:50,name:'Singing Rocks',col:'#ffd6ad',path:'#ffa64d',icon:'🎵',say:'The Singing Rocks! Listen, the rocks are humming. And look at all those holes in the ground!'},
  forest:{x:-55,z:50,name:'Upside-down Forest',col:'#9be8d6',path:'#3fd0b0',icon:'🌳',say:'The Upside-down Forest! The trees are standing on their heads!'}};
/* ----------------- Zuzu and her 10 puppies ----------------- */
const pupL=(fur,o)=>Object.assign({fur,belly:'#ffffff',muzzle:'#ffffff',ears:'none',eyeWhite:true,tail:'wag',scale:.7},o);
const mv=(m,p)=>[['Antenna Beep',1,10],[m,2,p||40]];
const ZUZU={id:'al_zuzu',name:'Zuzu',mum:true,breed:'Alien Dog',pitch:1.25,ant:'#fff27a',antS:'#b48ae0',bg:'#e6d6ff',
  look:{fur:'#c9a8f0',belly:'#efe2ff',muzzle:'#efe2ff',ears:'none',spots:true,spotCs:['#ffffff','#fff3a0','#ffd6f5'],spotGlow:true,tail:'plume',tailTip:'#fff0ff',eyeWhite:true,iris:'#8a4ad8',acc:['startail'],scale:1.1,legLen:1.15},
  card:'Zuzu is an alien dog from the far side of the galaxy. She talks in beeps, and her antennae glow brighter when her puppies are near. No one has found aliens in real life yet, but scientists keep looking!',
  stats:{spd:8,brn:9,cud:10,brv:9},zoom:110,moves:[['Antenna Glow',1,30],['Star Map',3,100]]};
const AP=[
 {id:'al_wobble',name:'Wobble',zone:'jelly',where:'Jelly Hills',ant:'#ff8fd0',pitch:1.3,look:pupL('#9be86a',{belly:'#d2f7b8',muzzle:'#d2f7b8',scale:.72}),
  hint:'Wobble loves the jelly blobs in the Jelly Hills. Tap them until one giggles!',found:'Wobble wobbles all the way back to Zuzu for a big jelly cuddle!',
  card:'Wobble is made of jelly, and wobbles all over when she giggles! Real jellyfish have no bones and no brain, and they are mostly water.',stats:{spd:5,brn:6,cud:10,brv:6},zoom:60,moves:mv('Jelly Wobble')},
 {id:'al_peep',name:'Peep',zone:'meadow',where:'Glowing Flower Meadow',ant:'#fff27a',pitch:1.8,look:pupL('#ffb3d9',{belly:'#ffe3f2',muzzle:'#ffe3f2',tail:'pom',scale:.46}),
  hint:'Peep is so tiny she could be inside one of the closed flowers in the meadow. My antennae glow brighter when you are close!',found:'Peep hops out of the flower and runs to Zuzu. She is so tiny she rides on Zuzu\'s nose!',
  card:'Peep is so tiny she can fit in a teacup! Neutron stars are tiny too. One is only about as wide as a city, but it is heavier than our whole Sun!',stats:{spd:6,brn:7,cud:10,brv:4},zoom:50,moves:mv('Teacup Hide',30)},
 {id:'al_puff',name:'Puff',zone:'jelly',where:'Jelly Hills',ant:'#ff9ecb',pitch:1.45,look:pupL('#bfe3ff',{fluffy:true,wool:true,tail:'plume',bw:54,bh:48,scale:.7}),
  hint:'Puff floated up onto a floating island in the Jelly Hills. Bounce up on the jelly pad!',found:'Puff floats gently down into Zuzu\'s arms. Boop!',
  card:'Puff floats like a balloon! Astronauts on the space station float too, because they are falling round and round the Earth.',stats:{spd:4,brn:6,cud:10,brv:6},zoom:60,moves:mv('Balloon Float')},
 {id:'al_dart',name:'Dart',zone:'meadow',where:'all round the planet',ant:'#7fe0ff',pitch:1.2,look:pupL('#ffa64d',{belly:'#ffe0b8',muzzle:'#ffe0b8',stripes:'#c96a1a',long:true,legLen:.85,tail:'fox'}),
  hint:'Dart loves playing tag! He zooms right round the planet. Chase him!',found:'Dart is puffed out from running all round the planet. He gives Zuzu a six-legged hug!',
  card:'Dart has six legs, and he is the fastest puppy on the planet! Real insects have six legs too.',stats:{spd:10,brn:6,cud:6,brv:8},zoom:70,moves:mv('Six-Leg Sprint',50)},
 {id:'al_glow',name:'Glow',zone:'crystal',where:'the Dark Cave',ant:'#7ff6ff',pitch:1.1,look:pupL('#2a2f6a',{belly:'#3a4080',muzzle:'#3a4080',spots:true,spotCs:['#7ff6ff','#b8ff7f','#fff27a'],spotGlow:true,tail:'curl'}),
  hint:'Glow is hiding in the Dark Cave in the Rainbow Crystal Fields. His spots only shine in the dark!',found:'Glow\'s spots twinkle as he snuggles up to Zuzu.',
  card:'Glow\'s spots shine in the dark! Some real animals glow too, like fireflies and some deep sea fish. Scientists call it bioluminescence.',stats:{spd:6,brn:7,cud:8,brv:7},zoom:60,moves:mv('Glow Spots')},
 {id:'al_echo',name:'Echo',zone:'sing',where:'the Singing Rocks',ant:'#ffd23f',pitch:1.35,look:pupL('#5fd6c8',{belly:'#c8f5ef',muzzle:'#c8f5ef',tail:'curl'}),
  hint:'Echo is hiding behind the Singing Rocks. Copy her song to coax her out!',found:'Echo sings Zuzu\'s song back to her. Beep beep boop!',
  card:'Echo copies every sound she hears! In space there is no air to carry sound, so space is completely silent.',stats:{spd:6,brn:9,cud:8,brv:5},zoom:60,moves:mv('Copycat Song')},
 {id:'al_swatch',name:'Swatch',zone:'crystal',where:'Rainbow Crystal Fields',ant:'#ff7fb8',pitch:1.4,look:pupL('#ffffff',{tail:'plume'}),
  hint:'Swatch is pretending to be a crystal in the Rainbow Crystal Fields. Look for blinking eyes!',found:'Swatch turns bright pink with happiness and cuddles Zuzu.',
  card:'Swatch can change colour to match anything! Real chameleons and octopuses can change colour too.',stats:{spd:7,brn:8,cud:7,brv:6},zoom:60,moves:mv('Colour Swap')},
 {id:'al_boing',name:'Boing',zone:'forest',where:'Upside-down Forest',ant:'#7f9cff',pitch:1.25,look:pupL('#ffe066',{belly:'#fff3b8',muzzle:'#fff3b8',tail:'curl',legLen:1.2}),
  hint:'Boing is bouncing by the Upside-down Forest. Stand in the glowing ring and catch him in the net!',found:'Boing bounces all the way back to Zuzu. Boing, boing, boing!',
  card:'Boing bounces far too high! On the Moon you could jump about six times higher than on Earth, because its gravity is weaker.',stats:{spd:9,brn:5,cud:7,brv:9},zoom:70,moves:mv('Super Boing',50)},
 {id:'al_popper',name:'Popper',zone:'sing',where:'Pop-up Plains',ant:'#8fe39a',pitch:1.5,look:pupL('#e8a86a',{belly:'#ffe6c8',muzzle:'#ffe6c8',scale:.66}),
  hint:'Popper is hiding in the holes by the Singing Rocks. Listen to his number clue!',found:'Popper pops out and pops straight into Zuzu\'s arms!',
  card:'Popper pops out of holes to say hello! Real meerkats and prairie dogs live in tunnels underground, and pop up to look around.',stats:{spd:8,brn:8,cud:7,brv:7},zoom:60,moves:mv('Pop-up Peek')},
 {id:'al_upside',name:'Upside',zone:'forest',where:'Upside-down Forest',ant:'#ffb347',pitch:1.15,look:pupL('#8fe3c8',{belly:'#d6fff2',muzzle:'#d6fff2'}),
  hint:'Upside is walking upside down under the floating island in the Upside-down Forest. Stand underneath and call him!',found:'Upside flips the right way up to give Zuzu a cuddle. Then he flips back again!',
  card:'Upside walks upside down! In space there is no real up or down. Astronauts sleep in sleeping bags tied to the wall.',stats:{spd:6,brn:7,cud:8,brv:9},zoom:60,moves:mv('Upside Walk')}];
AP.concat([ZUZU]).forEach(p=>{p.breed=p.breed||'Alien Pup';p.type='alien';p.alien=true;p.lv=1;});
BH.APUPS=AP;BH.ZUZU=ZUZU;const P=id=>AP.find(p=>p.id==='al_'+id);
const fnd=id=>!!S().found['al_'+id];

/* ----------------- places ----------------- */
const K=[10,-6],MUSH=[-6,-14],FG=[-16,12],DART=[[18,24],[74,24],[-62,24],[-6,24]],WB=[-46,-34],PI=[-66,-56],PB=[-58,-47],PIH=9,
  CAVE=[66,-60],CAVEM=[59.5,-54],SWC=[44,-40],SR=[42,40],HP=[64,60],FI=[-54,46],FIH=11,BR=[[-34,62],[-43,71],[-27,72]],FLAGP=[15,1];
const HOLES=Array.from({length:10},(_,i)=>[HP[0]-8+(i%5)*4,HP[1]-3+Math.floor(i/5)*7]);
BH.dbg={pop:()=>popper&&popper.q,ent:()=>ENT,dart:()=>dart,boing:()=>boing,BR,HOLES,FL:()=>FL,WB,PB,FI,SR,SWC,CAVEM,K};
const KEEP=[[4,6,4]].concat(['jelly','crystal','sing','forest'].map(k=>{const q={jelly:[-55,-45],crystal:[55,-50],sing:[55,50],forest:[-55,50]}[k],d=Math.hypot(q[0],q[1]),ux=q[0]/d,uz=q[1]/d;return [ux*13-uz*2.4,uz*13+ux*2.4,2];})).concat([[K[0],K[1],9],[MUSH[0],MUSH[1],4],[FG[0],FG[1],10],[0,0,5],[WB[0],WB[1],7],[PI[0],PI[1],6],[PB[0],PB[1],4],[CAVE[0],CAVE[1],10],[SWC[0],SWC[1],7],[SR[0],SR[1],8],[HP[0],HP[1],12],
  [FI[0],FI[1],12],[FLAGP[0],FLAGP[1],2]]).concat(BR.map(b=>[b[0],b[1],4]),DART.map(d=>[d[0],d[1],3]));
const free=(x,z,r)=>!KEEP.some(q=>dist(x,z,q[0],q[1])<q[2]+r);
function place(n,cx,cz,R,r,sd,fn){const Rn=seed(sd);let made=0;for(let t=0;t<n*8&&made<n;t++){const a=Rn()*6.283,d=Math.sqrt(Rn())*R,x=wr(cx+Math.cos(a)*d),z=wr(cz+Math.sin(a)*d);if(!free(x,z,r))continue;fn(x,z,Rn);made++;}}
const HILLS=[[-56,-44,9,3.6],[-68,-36,7,2.8],[-44,-56,7,2.6],[-62,-62,6,2]];
const baseHF=planetHF(L,[[.6,2,3],[.45,4,3,1],[.25,7,5,2]]);
function hf(x,z){let h=baseHF(x,z);HILLS.forEach(q=>{const dx=wd(x-q[0]),dz=wd(z-q[1]),d=(dx*dx+dz*dz)/(q[2]*q[2]);if(d<6)h+=q[3]*Math.exp(-d);});
  const fl=(cx,cz,r)=>{const d=Math.hypot(wd(x-cx),wd(z-cz))/r;return d<1?1:d<1.7?1-(d-1)/.7:0;};
  const f=Math.max(fl(4,0,20),fl(HP[0],HP[1],12),fl(FG[0],FG[1],9),fl(FI[0],FI[1],10));return h*(1-f*.85);}
function zoneOf(x,z){let best='meadow',bd=1e9;for(const k in ZN){const d=dist(x,z,ZN[k].x,ZN[k].z);if(d<bd){bd=d;best=k;}}return best;}

/* ----------------- sky pictures ----------------- */
const {cv,glow,ball,SKY}=PLANET;
SKY.pinksun=()=>cv('pinksun',256,0,g=>{glow(g,128,128,30,128,'rgba(255,120,200,.85)');ball(g,128,128,50,['#fff0fa','#ff9ad6'],'#e0509a');});
SKY.bluesun=()=>cv('bluesun',256,0,g=>{glow(g,128,128,24,128,'rgba(110,180,255,.85)');ball(g,128,128,40,['#f4faff','#8cc8ff'],'#3a70d0');});
SKY.homegal=()=>cv('homegal',256,0,g=>{glow(g,128,110,0,90,'rgba(220,210,255,.45)');for(let arm=0;arm<2;arm++)for(let k=0;k<40;k++){const a=k*.22+arm*Math.PI,r=4+k*1.7;g.fillStyle=`rgba(255,${235-k*2},255,${.95-k*.018})`;g.beginPath();g.arc(128+Math.cos(a)*r,110+Math.sin(a)*r*.55,2.2,0,6.283);g.fill();}
  glow(g,128,110,0,16,'rgba(255,250,220,1)');g.font='900 34px sans-serif';g.textAlign='center';g.lineWidth=7;g.strokeStyle='#26232e';g.strokeText('HOME',128,206);g.fillStyle='#fff';g.fillText('HOME',128,206);
  g.strokeStyle='#fff';g.lineWidth=5;g.beginPath();g.moveTo(128,176);g.lineTo(128,148);g.moveTo(118,158);g.lineTo(128,146);g.lineTo(138,158);g.stroke();});

/* ----------------- the area ----------------- */
const EXIT={x:22,z:-14,to:'blackhole',arrive:[BH.DOCK[0]+5,BH.DOCK[1]-6,Math.PI],name:'The Black Hole',icon:'🌀',col:'#c9b6ff',noArch:true,noLabel:true,hop:true,ride:['🚀','The Stargazer zooms back through the wormhole, to the Black Hole!']};
const A={id:'alien',icon:'🌈',island:'planet',planet:{L,Rs:100,lowG:true},rect:{x1:-HL,z1:-HL,x2:HL,z2:HL},noHedge:true,noEnrich:true,camH:6.6,camD:12.5,fog:[500,900],sky:'#3a1868',
  get name(){return (state&&state.bh&&state.bh.name)||'Alien Planet';},start:[4,6,Math.PI*.8],ground:'#a8ecc0',ground2:'#ffb8dc',hf,
  light:{sky:'#ffe6fa',gr:'#6a4a9a',hi:.78,dir:'#fff0ff',di:.6,pos:[60,70,40]},
  space:{band:70,starTint:'#ffd6f5',items:[{k:'pinksun',az:-60,el:7,size:130},{k:'bluesun',az:-25,el:3,size:76},{k:'neb',c1:'rgba(255,120,210,.8)',c2:'rgba(120,230,220,.7)',key:'al1',az:60,el:5,size:480,op:.7},
    {k:'neb',c1:'rgba(180,140,255,.8)',c2:'rgba(255,200,120,.6)',key:'al2',az:170,el:3,size:440,op:.6},{k:'saturn',az:118,el:9,size:100},{k:'homegal',az:-140,el:8,size:80}]},
  hello:'You landed on a strange, colourful planet!',how:'Take the Black Hole Tour from the Black Hole planet on Planet Hop.',exits:[],build(){buildAlien(this);}};
AREAS.alien=A;BH.alien={};

let ENT={},Z=null,FL=[],BLOBS=[],NET=null,zoneSaid={},hold=null,lastBeep=0,lastHint=0,boing=null,popper=null,dart=null,upside=null;
function buildAlien(A){const B=S();ENT={};Z=null;FL=[];BLOBS=[];NET=null;zoneSaid={meadow:1};hold=null;boing=null;popper=null;dart=null;upside=null;BH.alien={K,look:MUSH};
  recolour();
  /* glowing paths from the meadow to each zone, and signposts */
  ['jelly','crystal','sing','forest'].forEach((k,i)=>{const Zn=ZN[k],d=Math.hypot(Zn.x,Zn.z),n=Math.floor((d-14)/2.6);for(let j=0;j<n;j++){const f=(8+j*2.6)/d,x=Zn.x*f+Math.sin(j*.9)*.8,z=Zn.z*f+Math.cos(j*.7)*.8;I('sph',Zn.path,.42,.1,.42,x,wy(x,z)+.04,z,0,0,0,true);}
    const ux=Zn.x/d,uz=Zn.z/d,sx=ux*13-uz*2.4,sz=uz*13+ux*2.4;sign(sx,sz,`${Zn.icon} ${Zn.name}`,2.8,6);});
  /* the meadow: giant glowing flowers and mushrooms */
  const FC=['#ff8fd0','#b58cff','#7fe0ff','#fff27a'];
  place(46,0,0,30,2,11,(x,z,R)=>{const y=wy(x,z),h=2+R()*2.5,c=FC[Math.floor(R()*4)];I('cylL','#5fbf7a',.12,h,.12,x,y+h/2,z);for(let k=0;k<5;k++){const a=k*1.2566+R();I('sph',c,.75,.16,.42,x+Math.cos(a)*.6,y+h,z+Math.sin(a)*.6,0,-a,0);}I('sph','#fff7c0',.34,.24,.34,x,y+h+.08,z,0,0,0,true);});
  const mush=(x,z,s,c)=>{const y=wy(x,z);I('cyl','#f4ecd8',.5*s,3*s,.5*s,x,y+1.5*s,z);I('hemi',c,2.4*s,1.5*s,2.4*s,x,y+2.9*s,z);for(let k=0;k<5;k++){const a=k*1.3;I('sph','#ffffff',.3*s,.12*s,.3*s,x+Math.cos(a)*1.5*s,y+3.3*s+.3*s,z+Math.sin(a)*1.5*s);}col(x,z,.8*s);};
  mush(MUSH[0],MUSH[1],1.5,'#ff5fa8');place(7,0,0,34,3,12,(x,z,R)=>mush(x,z,.8+R()*.7,pick(['#ff5fa8','#b58cff','#7fe0ff'])));
  /* the crashed Stargazer (or the mended one) */
  {const fixed=!!B.fixed,sh=BH.stargazer3D({crash:!fixed,map:fixed});add(sh,K[0],K[1]);sh.rotation.y=0;col(K[0],K[1],3);col(K[0],K[1]+4,2.2);col(K[0],K[1]-4,2.2);camBlock(K[0]-2.4,K[1]-6,K[0]+2.4,K[1]+6);BH.alien.ship=sh;BH.alien.K=K;
    if(!fixed){sh.userData.hatch.rotation.z=B.landed?-1.35:0;W.ticks.push(dt=>{if(Math.random()<dt*1.2)floatS('💨',K[0]+Math.random()-.5,wy(K[0],K[1])+3,K[1]-4.5,1.4,1.4);});}
    else{sh.userData.flame.visible=false;}
    W.things.push({x:K[0]+4,z:K[1]+1,r:4.4,icon:'🔧',label:'Fix the ship',show:()=>S().met&&aFound()>=10&&!S().fixed,act:repair});
    W.things.push({x:K[0]+4,z:K[1]+1,r:4.4,icon:'🚀',label:'Fly home',show:()=>!!S().fixed&&!S().done,act:()=>{player.lock=true;BH.flyHome();}});
    W.things.push({x:K[0]+4,z:K[1]+1,r:4.4,icon:'🚀',label:'Stargazer',show:()=>S().met&&aFound()<10,act:()=>{sfx.chime();say(`The Stargazer is broken. Find all ten of Zuzu's puppies, then they can help mend it! You have found ${aFound()} of 10.`);}});}
  if(B.name)flag();
  buildFlowers();buildJelly();buildCrystal();buildSing();buildForest();
  /* scattered scenery all over the planet */
  place(70,0,0,96,1.6,21,(x,z,R)=>{const zn=zoneOf(x,z),y=wy(x,z),s=.5+R()*1.4;
    if(zn==='crystal')I('cone',pick(['#ff8fd0','#b58cff','#7fe0ff','#fff27a','#8fe39a']),.5*s,(2+R()*2)*s,.5*s,x,y+s,z,0,0,(R()-.5)*.4);
    else if(zn==='forest')upTree(x,z,s);else if(zn==='jelly')I('sph',pick(['#ffb3d9','#c9f5a8','#bfe3ff']),1.2*s,.8*s,1.2*s,x,y+.3*s,z);
    else I('sph',pick(['#f2c6e8','#c8e8f2','#e8d8ff']),1.1*s,.7*s,1*s,x,y+.25*s,z,0,R()*6,0);if(s>1)col(x,z,.8*s);});
  /* Zuzu, and any puppies already found */
  Z=ent(ZUZU,MUSH[0]-2.6,MUSH[1]-1.2);Z.mode=B.done||B.fixed?'wander':B.met?'side':'peek';
  if(B.met&&!B.done&&!B.fixed){Z.x=A.start[0]+2;Z.z=A.start[1]+2;}
  AP.forEach(p=>{if(S().found[p.id]){const e=ent(p,K[0]+3+Math.random()*4,K[1]+4+Math.random()*4);e.mode=B.done||B.fixed?'wander':'follow';}});
  buildDart();buildBoing();buildPopper();
  W.things.push({x:0,z:0,r:3.4,icon:'💬',label:'Zuzu',zz:1,show:()=>!!Z&&Z.mode!=='peek'&&!followers.some(f=>Math.hypot(f.x-player.x,f.z-player.z)<2.3),act:zTalk});
  W.things.push({x:MUSH[0],z:MUSH[1],r:6.5,icon:'💬',label:'Hello?',show:()=>!S().met&&!!S().name,act:meet});
  W.ticks.push(tick);
  if(B.landed&&!B.name)setTimeout(()=>{if(W.area===A&&!S().name)BH.nameCard(()=>{player.lock=false;afterName();});},900);}
function recolour(){const m=W.ag.children.find(o=>o.isMesh&&o.geometry&&o.geometry.parameters&&o.geometry.parameters.width===L);if(!m)return;
  const p=m.geometry.attributes.position,c=m.geometry.attributes.color,tc=new THREE.Color(),base=new THREE.Color('#e2c8f4'),Zc={};for(const k in ZN)Zc[k]=new THREE.Color(ZN[k].col);
  for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i);let r=base.r*.25,g=base.g*.25,b=base.b*.25,w=.25;
    for(const k in ZN){const d=dist(x,z,ZN[k].x,ZN[k].z)/(k==='meadow'?34:30),q=Math.exp(-d*d*1.4);r+=Zc[k].r*q;g+=Zc[k].g*q;b+=Zc[k].b*q;w+=q;}
    const v=1+(Math.sin(x*.21+Math.sin(z*.13)*2)*.04);tc.setRGB(r/w*v,g/w*v,b/w*v);c.setXYZ(i,tc.r,tc.g,tc.b);}c.needsUpdate=true;}
function upTree(x,z,s){const y=wy(x,z);I('cone',pick(['#3fd0b0','#7fd6c8','#5fbf9a']),1.4*s,3*s,1.4*s,x,y+1.5*s,z,Math.PI,0,0);I('cyl','#9b6a43',.25*s,2.4*s,.25*s,x,y+4.2*s,z);
  for(let k=0;k<3;k++){const a=k*2.09;I('cylL','#9b6a43',.08*s,1.1*s,.08*s,x+Math.cos(a)*.35*s,y+5.7*s,z+Math.sin(a)*.35*s,Math.sin(a)*.6,0,-Math.cos(a)*.6);}col(x,z,.9*s);}
function flag(){const [x,z]=FLAGP,y=wy(x,z);if(BH.alien.flag){BH.alien.flag.forEach(o=>W.ag.remove(o));}
  const g=grp();mk('cyl','#c9d2e3',.08,4,.08,0,2,0,g);const f=mk('box','#ff5fa8',1.6,1,.06,.8,3.5,0,g);mk('sph','#fff27a',.3,.3,.08,.8,3.5,.04,g);add(g,x,z,y);col(x,z,.3);
  const lb=label('🚩 '+S().name,7);lb.position.set(x,y+5.6,z);W.ag.add(lb);BH.alien.flag=[g,lb];W.ticks.push(()=>{if(!g.parent)return true;f.rotation.y=Math.sin(W.t*2)*.25;});}
BH.flag=()=>{if(W.area&&W.area.id==='alien')flag();};

/* ----------------- alien dogs in 3D ----------------- */
function alien3D(p){const g=pup3D(p),u=g.userData,h=u.head,tm=new THREE.MeshBasicMaterial({color:p.ant});W.disp.push(tm);const tips=[];const big=p.mum?1.25:1;
  [-1,1].forEach(s=>{const st=new THREE.Mesh(G.cyl,M(p.antS||p.look.fur));st.scale.set(.035*big,.62*big,.035*big);st.position.set(s*.22,.42+.31*big,-.04);st.rotation.z=-s*.38;h.add(st);
    const tp=new THREE.Mesh(G.sph,tm);tp.scale.setScalar(.12*big);tp.position.set(s*(.22+.12*big),.42+.6*big,-.04);h.add(tp);tips.push(tp);});
  if(p.id==='al_dart'){u.mid=[];[-1,1].forEach(s=>{const pv=grp();pv.position.set(s*.3,.5,0);u.body.add(pv);mk('cyl',p.look.fur,.08,.5,.08,0,-.22,0,pv);u.mid.push(pv);});}
  if(p.id==='al_wobble'||p.id==='al_swatch')g.traverse(o=>{if(o.isSkinnedMesh&&o.material&&o.material.isMeshLambertMaterial){o.material=o.material.clone();W.disp.push(o.material);if(p.id==='al_wobble'){o.material.transparent=true;o.material.opacity=.8;}u.tint=o.material;}});
  u.tips=tips;u.tm=tm;g.traverse(o=>{o.frustumCulled=false;});return g;}
BH.alien3D=alien3D;/* the conga finale (conga.js) borrows it for Zuzu's family on the Moon */
function ent(p,x,z){if(ENT[p.id])return ENT[p.id];const g=alien3D(p);add(g,x,z);const e={p,g,x,z,h:0,mode:'idle',lift:p.id==='al_puff'?1:0,moving:false};ENT[p.id]=e;return e;}
const aFound=()=>BH.aFound();

/* ----------------- finding a puppy ----------------- */
function toast(html){const t=el('div','pktoast',html);$('#fx').appendChild(t);setTimeout(()=>t.classList.add('on'),30);setTimeout(()=>{t.classList.remove('on');setTimeout(()=>t.remove(),400);},3400);}
function foundPup(p,x,z,done){const B=S();if(B.found[p.id]){if(done)done();return;}B.found[p.id]=Date.now();save();hud();
  const e=ent(p,x,z);e.x=x;e.z=z;e.mode='reunion';e.rt=0;e.rx=x;e.rz=z;e.g.userData.jump=.8;sfx.giggle();snd.sparkle();player.cheer=1.3;confetti(30);floatS('✨',x,wy(x,z)+2.6,z,2.4);
  const n=aFound();player.lock=true;
  setTimeout(()=>{snd.beep(4);if(Z)floatS('💖',Z.x,wy(Z.x,Z.z)+3.2,Z.z,2.4);},1300);
  setTimeout(()=>{toast(`🎴 Card saved for the <b>${S().name||'Alien Planet'}</b> pack`);
    card({art:`<div class="fitsvg" style="width:150px">${BH.alienSVG(p)}</div>`,h:`You found ${p.name}!`,p:`${p.found} ${n<10?`That's ${n} of 10 puppies!`:'That\'s all 10 puppies!'}`,say:`You found ${p.name}! ${p.found} ${n<10?`That's ${n} of 10 puppies!`:''}`,
      btns:[['💖 Yay!','green',()=>{e.mode='follow';player.lock=false;if(n>=10)setTimeout(allHome,400);if(done)done();}]]});},1900);}
function allHome(){player.lock=true;const z=`<div class="fitsvg" style="width:150px">${BH.alienSVG(ZUZU)}</div>`;
  story([{art:z,t:'Beep beep boop! All ten of my puppies are home! Thank you, Seb!'},{art:z,t:'Now it is our turn to help you. My puppies are very clever. Let\'s go and mend your spaceship!'}],()=>{player.lock=false;say('Go back to the Stargazer, by the glowing flowers in the meadow, and tap 🔧 Fix the ship!');});}
/* Zuzu's hints: the nearest puppy still hiding */
function hintPt(p){const id=p.id.slice(3);if(id==='peep'){const f=FL[S().sub.peepK||0];return f?[f.x,f.z]:FG;}if(id==='wobble')return WB;if(id==='puff')return PB;
  if(id==='dart'){const d=dart;return d?[d.e.x,d.e.z]:DART[0];}if(id==='glow')return CAVEM;if(id==='echo')return SR;if(id==='swatch')return SWC;if(id==='boing')return BR[0];if(id==='popper')return HP;if(id==='upside')return FI;return [0,0];}
function nearest(){let best=null,bd=1e9;AP.forEach(p=>{if(S().found[p.id])return;const h=hintPt(p),d=near(h[0],h[1]);if(d<bd){bd=d;best=p;}});return best?{p:best,d:bd}:null;}
function zTalk(){if(player.lock)return;sfx.chime();snd.beep(3);if(Z)Z.g.userData.jump=.6;const B=S();
  if(B.done)return say(pick(['Zuzu says: beep boop! Thank you for finding my puppies, Seb. Come and visit any time!','Zuzu says: my puppies love playing with you!',`Zuzu says: you named our planet ${B.name}. We love it!`]));
  if(B.fixed)return say('Zuzu says: the Stargazer is mended! Follow my star map home. Tap 🚀 Fly home by the ship.');
  if(aFound()>=10)return say('Zuzu says: all my puppies are home! Let\'s mend your spaceship. It\'s by the glowing flowers.');
  const n=nearest();if(!n)return;const zn=ZN[n.p.zone];
  say(`Zuzu says: beep beep! ${n.p.hint}${n.d>30&&n.p.zone!=='meadow'?` Follow the glowing path to the ${zn.name}.`:''}`);}
/* meeting Zuzu */
function afterName(){if(S().met)return;setTimeout(()=>{if(W.area!==A)return;say('Look! Something is peeking out from behind that giant mushroom!');if(Z)floatS('👀',Z.x,wy(Z.x,Z.z)+3,Z.z,2,2);},2600);}
BH.afterName=afterName;
function meet(){if(player.lock)return;player.lock=true;sfx.chime();const z=`<div class="fitsvg" style="width:150px">${BH.alienSVG(ZUZU)}</div>`;Z.mode='creep';Z.ct=0;player.pet=2.4;
  say('Seb kneels down very slowly, and holds out his glove...');snd.beep(2);
  setTimeout(()=>{snd.beep(5);story([{art:z,t:'"Beep, boop, bee-beep?" Your helmet translator crackles, and turns her beeps into words.'},
    {art:z,t:'"Hello. My name is Zuzu. Have you seen my puppies?"'},
    {art:z,t:'"My ten puppies were playing hide-and-seek. They hid so well that even I can\'t find them!"'},
    {art:z,t:'"When one of my puppies is near, my antennae glow brighter. Will you help me find them? Then we will help you mend your spaceship."'}],()=>{
    card({art:z,h:'Help Zuzu?',p:'Ten alien puppies are hiding all over the planet!',btns:[['🐾 Yes, let\'s find them!','green',()=>{const B=S();B.met=Date.now();save();Z.mode='side';player.lock=false;sfx.jingle();
      say('Zuzu floats along beside you. Follow the glowing paths, and watch her antennae. They glow brighter when a puppy is near! Tap 💬 Zuzu for a clue.');}]]});});},2600);}

/* ----------------- Peep: nine closed flowers ----------------- */
let lastD=null;
function buildFlowers(){const B=S();if(B.sub.peepK==null){B.sub.peepK=Math.floor(Math.random()*9);save();}lastD=null;
  const FC=['#ff8fd0','#b58cff','#7fe0ff','#fff27a'];
  for(let i=0;i<9;i++){const x=FG[0]+(i%3-1)*5,z=FG[1]+(Math.floor(i/3)-1)*5,y=wy(x,z),g=grp();mk('cyl','#4fae6a',.2,3.4,.2,0,1.7,0,g);const bud=grp();bud.position.y=3.4;g.add(bud);const tilts=[];
    for(let k=0;k<5;k++){const pv=grp();pv.rotation.y=k*1.2566;bud.add(pv);const tl=grp();pv.add(tl);mk('sph',FC[i%4],.5,1.15,.24,0,.75,.22,tl);tilts.push(tl);}
    mk('sph','#fff7c0',.32,.3,.32,0,.25,0,bud,true);[-1,1].forEach(s=>{const lf=mk('sph','#5fbf7a',.5,.12,.9,s*.5,1.4,0,g);lf.rotation.z=s*.4;});
    add(g,x,z,y);col(x,z,.7);const f={i,x,z,g,tilts,open:0,target:0};FL.push(f);
    W.things.push({x,z,r:2.4,icon:'🌷',label:'Open',show:()=>S().met&&!fnd('peep')&&!f.tried,act:()=>openFlower(f)});}}
function openFlower(f){if(player.lock)return;f.tried=true;f.target=1;snd.pop();const B=S(),right=FL[B.sub.peepK];
  if(f===right){setTimeout(()=>{snd.sparkle();const p=P('peep'),e=ent(p,f.x,f.z);e.lift=3.6;e.g.userData.jump=.8;setTimeout(()=>{e.lift=0;foundPup(p,f.x+1.2,f.z+1.2);},700);},500);return;}
  const d=Math.hypot(f.x-right.x,f.z-right.z);let m;
  if(lastD==null)m=d<=5.5?'Warm! Peep is very close to this flower!':d<=8?'Warmish! Peep is near here somewhere.':'Cold! Peep is not near this one.';else m=d<lastD?'Warmer!':d>lastD?'Colder!':'Just as warm as before!';lastD=d;
  setTimeout(()=>{snd.beep(2);say(`Empty! Zuzu beeps: ${m}`);},500);}

/* ----------------- the Jelly Hills: Wobble and Puff ----------------- */
let jmat=null;
function buildJelly(){const B=S();if(B.sub.wobK==null){B.sub.wobK=Math.floor(Math.random()*8);save();}let tries=0;
  if(!jmat){jmat=['#ff8fd0','#9be86a','#7fe0ff','#ffd23f'].map(c=>new THREE.MeshLambertMaterial({color:c,transparent:true,opacity:.78}));}
  for(let i=0;i<8;i++){const a=i/8*6.283,x=WB[0]+Math.cos(a)*4.6,z=WB[1]+Math.sin(a)*4.6,y=wy(x,z),m=new THREE.Mesh(G.sph,jmat[i%4]);m.scale.set(1.4,1.1,1.4);m.position.set(x,y+.8,z);W.ag.add(m);
    const hl=mk('sph','#ffffff',.25,.15,.2,x-.4,y+1.5,z-.3,null,true);W.ag.add(hl);col(x,z,1.2);const b={i,x,z,m,hl,wob:0};BLOBS.push(b);
    W.things.push({x,z,r:2.3,icon:'🍮',label:'Tap',show:()=>S().met&&!fnd('wobble'),act:()=>{if(player.lock)return;b.wob=1;
      if(i===S().sub.wobK){sfx.giggle();floatS('😆',x,y+2.6,z,2);setTimeout(()=>{b.m.visible=false;b.hl.visible=false;foundPup(P('wobble'),x,z);},800);}
      else{snd.boing();floatS('〰️',x,y+2.4,z,1.6);tries++;if(tries===2)say('Boing! Just jelly. Zuzu beeps: listen for a giggle!');}}});}
  W.ticks.push(dt=>{BLOBS.forEach(b=>{if(b.wob>0)b.wob=Math.max(0,b.wob-dt*1.2);const w=Math.sin(W.t*16)*.2*b.wob;b.m.scale.set(1.4+w,1.1-w,1.4+w);});
    if(tries>=3&&!fnd('wobble')&&S().met&&(W.wgig=(W.wgig||0)-dt)<0){W.wgig=3.5;const b=BLOBS[S().sub.wobK];if(b&&near(b.x,b.z)<20){b.wob=.6;sfx.giggle();floatS('😆',b.x,wy(b.x,b.z)+2.6,b.z,1.6);}}});
  /* Puff's floating island and the jelly bounce pad */
  const iy=wy(PI[0],PI[1])+PIH;I('cyl','#ffd1f0',4.2,.7,4.2,PI[0],iy,PI[1]);I('cone','#9a7ad0',4.2,4.5,4.2,PI[0],iy-2.6,PI[1],Math.PI,0,0);
  for(let k=0;k<5;k++){const a=k*1.3;I('sph',pick(['#ff8fd0','#7fe0ff']),.4,.3,.4,PI[0]+Math.cos(a)*3,iy+.5,PI[1]+Math.sin(a)*3);}
  [[-48,-60,14,3],[-72,-38,12,2.6],[-40,-46,16,2.2]].forEach(q=>{const y=wy(q[0],q[1])+q[2];I('cyl','#ffd1f0',q[3],.5,q[3],q[0],y,q[1]);I('cone','#9a7ad0',q[3],q[3]*1.1,q[3],q[0],y-q[3]*.6,q[1],Math.PI,0,0);});
  if(!fnd('puff')){const e=ent(P('puff'),PI[0],PI[1]);e.mode='island';}
  const pad=new THREE.Mesh(G.cyl,new THREE.MeshLambertMaterial({color:'#ff8fd0',transparent:true,opacity:.85}));pad.scale.set(1.8,.5,1.8);pad.position.set(PB[0],wy(PB[0],PB[1])+.25,PB[1]);W.ag.add(pad);W.disp.push(pad.material);
  W.ticks.push(()=>{pad.scale.y=.5+Math.abs(Math.sin(W.t*3))*.15;});
  sign(PB[0]+3,PB[1]+2,'🍮 Jelly bounce pad',2.6,6);
  W.things.push({x:PB[0],z:PB[1],r:2.8,icon:'🍮',label:'Bounce!',show:()=>S().met&&!fnd('puff'),act:bouncePuff});
  place(26,ZN.jelly.x,ZN.jelly.z,26,1.4,31,(x,z,R)=>{const s=.6+R()*1;I('sph',pick(['#ffb3d9','#c9f5a8','#bfe3ff','#fff0a0']),1.3*s,.9*s,1.3*s,x,wy(x,z)+.4*s,z);col(x,z,1*s);});}
function arc(x0,z0,x1,z1,y0,y1,peak,secs){return new Promise(res=>{hold={x0,z0,x1,z1,y0,y1,peak,t:0,d:secs,res};});}
async function bouncePuff(){if(player.lock)return;player.lock=true;snd.boing();const iy=wy(PI[0],PI[1])+PIH+.4;
  await arc(player.x,player.z,PI[0]+1,PI[1]+1,wy(player.x,player.z),iy,iy+5,1.5);snd.squish();hold={stay:[PI[0]+1,iy,PI[1]+1]};
  const e=ENT.al_puff;if(e){e.mode='script';}
  setTimeout(()=>foundPup(P('puff'),PI[0]+1.5,PI[1]+1.8,async()=>{player.lock=true;snd.boing();await arc(PI[0]+1,PI[1]+1,PB[0]+2,PB[1]+2,iy,wy(PB[0]+2,PB[1]+2),iy+3,1.3);hold=null;snd.squish();player.lock=false;}),600);}

/* ----------------- Dart: tag right round the planet ----------------- */
function buildDart(){if(fnd('dart'))return;const B=S(),i=Math.min(3,B.sub.dart||0),e=ent(P('dart'),DART[i][0],DART[i][1]);e.mode='dart';dart={e,i,run:null};
  W.things.push({x:0,z:0,r:3.2,icon:'🏃',label:'Tag!',dt:1,show:()=>!!dart&&dart.i>=3&&!dart.run&&S().met&&!fnd('dart'),act:()=>{if(player.lock)return;dart.e.mode='script';foundPup(P('dart'),dart.e.x,dart.e.z);dart=null;}});}
const DSAY=['Dart\'s playing tag! He zoomed off that way. Chase him!','Whoosh! Dart is running right round the planet! Keep going the same way!','Dart ran all the way round the planet and came back to the meadow! He\'s puffed out now. Tag him!'];
function dartTick(dt){const d=dart;if(!d)return;const e=d.e;
  if(d.run){const r=d.run;r.t+=dt;const k=Math.min(1,r.t/r.d);e.x=r.x0+(r.x1-r.x0)*k;e.z=r.z0+(r.z1-r.z0)*k;e.h=Math.PI/2;e.moving=true;
    if(Math.random()<dt*10)floatS('💨',e.x,wy(e.x,e.z)+.6,e.z,1.2,.8);
    if(k>=1){d.run=null;e.x=wr(e.x);e.z=wr(e.z);e.moving=false;if(d.i>=3){e.g.userData.pant=8;}}return;}
  e.moving=false;e.h=-Math.PI/2+Math.sin(W.t*1.5)*.6;
  if(d.i<3&&S().met&&near(e.x,e.z)<7&&!player.lock){const a=DART[d.i],b=DART[d.i+1];let x1=b[0];while(x1<e.x)x1+=L;d.run={t:0,d:2.8,x0:e.x,z0:e.z,x1,z1:b[1]};d.i++;S().sub.dart=d.i;save();sfx.giggle();snd.whoosh(1.2);say(DSAY[d.i-1]);}}

/* ----------------- the Crystal Fields: Swatch and Glow ----------------- */
function buildCrystal(){const cy=wy(CAVE[0],CAVE[1]);I('sph','#4a3a7a',7.5,5.2,7,CAVE[0],cy+.5,CAVE[1]);I('sph','#3a2a66',5,3.5,5,CAVE[0]+2,cy+3.5,CAVE[1]-2);
  const dx=CAVEM[0]-CAVE[0],dz=CAVEM[1]-CAVE[1],dd=Math.hypot(dx,dz),ux=dx/dd,uz=dz/dd,ex=CAVE[0]+ux*6.6,ez=CAVE[1]+uz*6.6;
  const mo=new THREE.Mesh(G.sph,new THREE.MeshBasicMaterial({color:'#06030e'}));mo.scale.set(2.2,2.6,.5);mo.position.set(ex,wy(ex,ez)+1.6,ez);mo.rotation.y=Math.atan2(ux,uz);W.ag.add(mo);W.disp.push(mo.material);col(CAVE[0],CAVE[1],7.2);
  for(let k=0;k<7;k++){const a=Math.atan2(uz,ux)+(k-3)*.32,x=CAVE[0]+Math.cos(a)*7.4,z=CAVE[1]+Math.sin(a)*7.4;I('cone',pick(['#7ff6ff','#ff9ee0','#fff27a']),.4,1.6+(k%3)*.8,.4,x,wy(x,z)+.9,z,0,0,(k-3)*.12,true);}
  sign(CAVEM[0]-2.5,CAVEM[1]+1.5,'🕳️ The Dark Cave',2.6,5.6);
  W.things.push({x:CAVEM[0],z:CAVEM[1],r:3.6,icon:'🔦',label:'Go in',show:()=>S().met&&!fnd('glow'),act:()=>{if(player.lock)return;caveGame();}});
  const R=seed(41);for(let k=0;k<14;k++){const a=R()*6.283,d=1+R()*4.5,x=SWC[0]+Math.cos(a)*d,z=SWC[1]+Math.sin(a)*d;I('cone',pick(['#ff8fd0','#b58cff','#7fe0ff','#fff27a','#8fe39a','#ffa64d']),.55,2+R()*2,.55,x,wy(x,z)+1.2,z,0,0,(R()-.5)*.5);}
  col(SWC[0],SWC[1],1.5);sign(SWC[0]+3,SWC[1]+5,'💎 Crystal patch',2.6,5.4);
  W.things.push({x:SWC[0],z:SWC[1]+3,r:4,icon:'🔍',label:'Look closely',show:()=>S().met&&!fnd('swatch'),act:()=>{if(player.lock)return;swatchGame();}});
  place(16,ZN.crystal.x,ZN.crystal.z,24,2.2,43,(x,z,R)=>{const y=wy(x,z),s=.8+R()*.6;I('cyl','#e8e2ff',.15*s,2.2*s,.15*s,x,y+1.1*s,z);I('cone',pick(['#ff8fd0','#b58cff','#7fe0ff','#fff27a']),.9*s,2.4*s,.9*s,x,y+3.3*s,z);col(x,z,.5);});}

/* ----------------- the Singing Rocks: Echo and Popper ----------------- */
const ROCKC=['#ff8fa3','#ffd23f','#8fe39a','#7fc8f0'],ROCKO=[[-5,1],[-1.8,-2.6],[1.8,-2.6],[5,1]];let rockIn=[];
function buildSing(){ROCKO.forEach((o,i)=>{const x=SR[0]+o[0],z=SR[1]+o[1],y=wy(x,z),s=1.2+(i%2)*.4;I('sph',ROCKC[i],1.4*s,1.6*s,1.3*s,x,y+1.1*s,z);I('sph','#ffffff',.3,.3,.15,x-.4*s,y+2*s,z+1.1*s,0,0,0,true);col(x,z,1.2*s);});rockIn=[0,0,0,0];
  sign(SR[0],SR[1]+5,'🎵 Singing Rocks',2.6,5.6);
  W.things.push({x:SR[0],z:SR[1]+2.2,r:3.6,icon:'🎵',label:'Listen',show:()=>S().met&&!fnd('echo'),act:()=>{if(player.lock)return;echoGame();}});
  place(12,ZN.sing.x,ZN.sing.z,26,2,51,(x,z,R)=>{const s=.7+R()*.9;I('sph',pick(['#ffd6ad','#ffb3a8','#ffe8a8']),1.2*s,1.4*s,1.1*s,x,wy(x,z)+.9*s,z);col(x,z,1*s);});}
function buildPopper(){HOLES.forEach((h,i)=>{const y=wy(h[0],h[1]);I('cyl','#5a3a2a',1.1,.06,1.1,h[0],y+.03,h[1],0,0,0,true);I('tor','#c98a5a',1.05,1.05,.5,h[0],y+.05,h[1],Math.PI/2,0,0);
    const lb=label(String(i+1),2.4);lb.position.set(h[0],y+2.3,h[1]);W.ag.add(lb);
    W.things.push({x:h[0],z:h[1],r:1.9,icon:'👀',label:'Hole '+(i+1),show:()=>S().met&&!fnd('popper')&&!!popper&&!!popper.q,act:()=>peekHole(i)});});
  sign(HP[0]-12,HP[1]+2,'🕳️ Pop-up Plains',2.6,5.6);
  if(fnd('popper'))return;const e=ent(P('popper'),HP[0],HP[1]);e.mode='pop';e.g.visible=false;popper={e,q:null,round:S().sub.popper||0,up:0,hole:0};}
const CL1=[['3 more than 4',7],['2 more than 3',5],['10 take away 2',8],['1 less than 7',6],['4 more than 5',9]],CL2=[['double 3',6],['2 times 5',10],['half of 8',4],['3 times 3',9],['double 4',8]];
function popUp(i,t){const p=popper;if(!p)return;p.hole=i;p.up=t||1.4;p.e.g.visible=true;sfx.pop();}
function newClue(){const p=popper,q=pick(p.round?CL2:CL1);p.q=q;const fake=(q[1]+2+Math.floor(Math.random()*6))%10;popUp(fake,1.6);
  setTimeout(()=>say(`Popper giggles: "I'm hiding in the hole that's ${q[0]}! Which number is that?"`),500);}
function peekHole(i){const p=popper;if(player.lock||!p||!p.q)return;
  if(i+1===p.q[1]){popUp(i,2.2);snd.sparkle();p.round++;S().sub.popper=p.round;save();
    if(p.round>=2){p.q=null;player.lock=true;setTimeout(()=>{p.e.mode='script';p.e.g.visible=true;const h=HOLES[i];foundPup(P('popper'),h[0]+1,h[1]+1);popper=null;},900);return;}
    say(`Yes! ${p.q[0]} is ${p.q[1]}! Popper pops out. "You found me! Now find me again!"`);p.q=null;p.wait=1;setTimeout(()=>{if(popper){popper.wait=0;newClue();}},4200);}
  else{snd.boing();sfx.giggle();say(`Not hole ${i+1}! Popper's clue: the hole that's ${p.q[0]}.`);}}
function popTick(dt){const p=popper;if(!p)return;const e=p.e;
  if(!p.q&&p.up<=0&&S().met&&near(HP[0],HP[1])<15&&!player.lock&&!p.wait){p.wait=1;setTimeout(()=>{p.wait=0;if(popper&&!popper.q)newClue();},600);}
  if(p.up>0){p.up-=dt;const h=HOLES[p.hole],k=Math.min(1,p.up*3,(2.2-Math.min(2.2,p.up))*4);e.x=h[0];e.z=h[1];e.lift=-1.2+1.6*Math.max(0,Math.min(1,k));e.g.visible=true;e.h=Math.atan2(player.x-h[0],player.z-h[1]);if(p.up<=0)e.g.visible=false;}}

/* ----------------- the Upside-down Forest: Upside and Boing ----------------- */
function buildForest(){const y0=wy(FI[0],FI[1]),iy=y0+FIH;I('cyl','#7fd6c8',10,1.2,10,FI[0],iy,FI[1]);I('cyl','#5a4a8a',9.6,1.4,9.6,FI[0],iy-1.2,FI[1]);
  const R=seed(61);for(let k=0;k<14;k++){const a=R()*6.283,d=R()*8,x=FI[0]+Math.cos(a)*d,z=FI[1]+Math.sin(a)*d;I('cyl','#9b6a43',.22,2,.22,x,iy-2.8,z);I('cone',pick(['#3fd0b0','#7fd6c8','#ff9ee0']),1.3,3,1.3,x,iy-5.2,z,Math.PI,0,0);
    for(let j=0;j<3;j++){const b=j*2.09;I('cylL','#9b6a43',.07,1,.07,x+Math.cos(b)*.3,iy+1,z+Math.sin(b)*.3,Math.sin(b)*.6,0,-Math.cos(b)*.6);}}
  sign(FI[0]+6,FI[1]+9,'🌳 Look up!',2.6,4.6);
  if(!fnd('upside')){const e=ent(P('upside'),FI[0],FI[1]+2);e.mode='under';upside={e};}
  W.things.push({x:FI[0],z:FI[1]+2,r:5.5,icon:'📣',label:'Call Upside',show:()=>S().met&&!fnd('upside')&&!!upside,act:callUpside});
  place(18,ZN.forest.x,ZN.forest.z,28,2,63,(x,z,R)=>upTree(x,z,.7+R()*.6));}
function callUpside(){if(player.lock||!upside)return;player.lock=true;sfx.chime();say('"Upside! Come down!" you call, looking up.');const e=upside.e;let t=0;const ex=e.x,ez=e.z;
  W.cine={cam(dt){t+=dt;cam.position.set(player.x+Math.sin(player.h+Math.PI)*3,wy(player.x,player.z)+2.2,player.z+Math.cos(player.h+Math.PI)*3);cam.lookAt(e.x,wy(e.x,e.z)+FIH-2,e.z);
    if(t>1.6&&e.mode==='under'){e.mode='script';e.ft=0;e.fx=ex;e.fz=ez;floatS('❗',ex,wy(ex,ez)+FIH-3.5,ez,2);sfx.giggle();}
    if(e.mode==='script'&&e.ft!=null){e.ft+=dt;const k=Math.min(1,e.ft/1.3);e.x=ex+(player.x+1.2-ex)*k;e.z=ez+(player.z+1.2-ez)*k;e.lift=(FIH-.9)*(1-k)+Math.sin(k*Math.PI)*1.5;e.g.rotation.z=Math.PI*(1-k)+Math.PI*2*k;}
    if(t>3.6){W.cine=null;e.ft=null;e.g.rotation.z=0;upside=null;foundPup(P('upside'),e.x,e.z);}}};}
function buildBoing(){if(fnd('boing'))return;const e=ent(P('boing'),BR[0][0],BR[0][1]);e.mode='boing';
  const mk2=new THREE.Mesh(G.ring,new THREE.MeshBasicMaterial({color:'#fff27a'}));mk2.rotation.x=Math.PI/2;mk2.scale.setScalar(2.4);W.ag.add(mk2);W.disp.push(mk2.material);
  boing={e,i:0,t:0,phase:'rest',ring:mk2,miss:0};}
function boingTick(dt){const b=boing;if(!b)return;const e=b.e,nx=(b.i+1)%BR.length,a=BR[b.i],c=BR[nx];b.ring.position.set(c[0],wy(c[0],c[1])+.12,c[1]);b.ring.material.color.setHSL(.15,1,.55+Math.sin(W.t*6)*.15);b.ring.scale.setScalar(2.4+Math.sin(W.t*5)*.2);
  const near16=S().met&&near(BR[0][0],BR[0][1])<22;
  if(b.phase==='rest'){b.t+=dt;e.x=a[0];e.z=a[1];e.lift=0;if(b.t>(near16?.9:.6)){b.t=0;b.phase='fly';snd.boing();}}
  else if(b.phase==='fly'){b.t+=dt;const D=2.8,k=Math.min(1,b.t/D);e.x=a[0]+(c[0]-a[0])*k;e.z=a[1]+(c[1]-a[1])*k;e.lift=Math.sin(k*Math.PI)*13;e.h=Math.atan2(c[0]-a[0],c[1]-a[1]);e.g.rotation.x=k*Math.PI*2;
    if(k>=1){e.g.rotation.x=0;b.t=0;b.i=nx;b.phase='rest';snd.thump();
      if(near16&&near(c[0],c[1])<2.8&&!player.lock){b.phase='done';snd.sparkle();say('Boing! You caught him in the net!');const x=e.x,z=e.z;boing=null;W.ag.remove(b.ring);e.mode='script';foundPup(P('boing'),x,z);return;}
      if(near16&&(b.miss++)%3===1)say('Boing bounces far too high! Stand in the glowing yellow ring, and he will land in your net!');}}
  if(!NET){NET=grp();const hp=new THREE.Mesh(G.ring,M('#ffd23f'));hp.scale.setScalar(.9);hp.rotation.x=Math.PI/2;NET.add(hp);const ms=new THREE.Mesh(G.cone,new THREE.MeshLambertMaterial({color:'#ffffff',transparent:true,opacity:.45,depthWrite:false}));ms.scale.set(.85,1,.85);ms.rotation.x=Math.PI;ms.position.y=-.5;NET.add(ms);W.disp.push(ms.material);
    mk('cyl','#9b6a43',.06,1.6,.06,.9,-.6,0,NET).rotation.z=-.7;W.ag.add(NET);NET.traverse(o=>{o.frustumCulled=false;});}
  NET.visible=near16&&!player.lock;NET.position.set(player.x+Math.sin(player.h)*.4,player.y+4,player.z+Math.cos(player.h)*.4);}

/* ----------------- every frame ----------------- */
function tick(dt){const t=W.t,B=S();if(W.area!==A)return true;
  /* bounces and perches (Puff's island) */
  if(hold){if(hold.stay){player.x=hold.stay[0];player.z=hold.stay[2];player.y=hold.stay[1];}else{hold.t+=dt;const k=Math.min(1,hold.t/hold.d),q=k*k*(3-2*k);player.x=hold.x0+(hold.x1-hold.x0)*q;player.z=hold.z0+(hold.z1-hold.z0)*q;
      const by=hold.y0+(hold.y1-hold.y0)*k;player.y=by+(hold.peak-Math.max(hold.y0,hold.y1))*Math.sin(k*Math.PI);if(k>=1){const r=hold.res;hold=null;r();}}player.grp.position.set(player.x,player.y,player.z);}
  /* Zuzu */
  if(Z){const z=Z;if(z.mode==='peek'){const dx=player.x-MUSH[0],dz=player.z-MUSH[1],d=Math.hypot(dx,dz)||1,ux=dx/d,uz=dz/d,side=Math.sin(t*.9)*1.9;z.x=MUSH[0]-ux*2.9-uz*side;z.z=MUSH[1]-uz*2.9+ux*side;z.h=Math.atan2(dx,dz);z.moving=false;}
    else if(z.mode==='creep'){z.ct+=dt;const tx=player.x+Math.sin(player.h)*2.2,tz=player.z+Math.cos(player.h)*2.2;z.x+=(tx-z.x)*Math.min(1,dt*.9);z.z+=(tz-z.z)*Math.min(1,dt*.9);z.h=Math.atan2(player.x-z.x,player.z-z.z);z.moving=Math.hypot(tx-z.x,tz-z.z)>.4;}
    else if(z.mode==='side'){const fx=Math.sin(player.h),fz=Math.cos(player.h),tx=player.x+fz*2.1-fx*1.1,tz=player.z-fx*2.1-fz*1.1,dx=wd(tx-z.x),dz=wd(tz-z.z),d=Math.hypot(dx,dz);
      z.moving=d>.35;if(d>.05){z.x+=dx*Math.min(1,dt*3.2);z.z+=dz*Math.min(1,dt*3.2);}if(d>25){z.x=tx;z.z=tz;}z.h=lerpAng(z.h,z.moving?Math.atan2(dx,dz):player.h,Math.min(1,dt*5));z.x=player.x+wd(z.x-player.x);z.z=player.z+wd(z.z-player.z);}
    else if(z.mode==='wander')wander(z,dt,K[0]-6,K[1]+8);
    z.lift=z.mode==='peek'?0:.5+Math.sin(t*1.7)*.22;
    const zz=W.things.find(q=>q.zz);if(zz){zz.x=z.x;zz.z=z.z;}
    /* hot and cold: the antennae glow brighter near a hiding puppy */
    const n=B.met&&!B.fixed?nearest():null,k=n?Math.max(0,Math.min(1,1-n.d/55)):.3,pulse=.55+.45*Math.sin(t*(2+9*k));
    z.g.userData.tm.color.setHSL(.15-.05*k,1,.3+.55*k*pulse+.1);z.g.userData.tips.forEach(m=>m.scale.setScalar(.15*(1+.5*k*pulse)));
    if(n&&n.d<9&&t-lastBeep>1.7&&!player.lock&&!ovOpen()){lastBeep=t;snd.beep(2);floatS('📡',z.x,wy(z.x,z.z)+3.4,z.z,1.2,.9);}
    if(B.met&&!B.fixed&&!player.lock&&!ovOpen()){for(const k2 in ZN){const q=ZN[k2];if(!zoneSaid[k2]&&near(q.x,q.z)<24){zoneSaid[k2]=1;say(`${q.icon} ${q.say}`);break;}}
      if(t-lastHint>70&&t-W.findT>70){lastHint=t;zTalk();}}}
  /* the puppies */
  let lx=player.x,lz=player.z;if(followers.length){const f=followers[followers.length-1];lx=f.x;lz=f.z;}
  const line=AP.filter(p=>ENT[p.id]&&ENT[p.id].mode==='follow').sort((a,b)=>B.found[a.id]-B.found[b.id]);
  line.forEach((p,i)=>{const e=ENT[p.id],dx=wd(lx-e.x),dz=wd(lz-e.z),d=Math.hypot(dx,dz),gap=i?1.9:2.4;e.moving=d>gap+.3;if(e.moving){const sp=Math.min(SPEED*1.2,(d-gap)*4);e.x+=dx/d*sp*dt;e.z+=dz/d*sp*dt;e.h=lerpAng(e.h,Math.atan2(dx,dz),Math.min(1,dt*10));}
    if(d>30){e.x=lx-dx/d*gap;e.z=lz-dz/d*gap;}e.x=player.x+wd(e.x-player.x);e.z=player.z+wd(e.z-player.z);lx=e.x;lz=e.z;});
  AP.forEach(p=>{const e=ENT[p.id];if(!e)return;
    if(e.mode==='reunion'&&Z){e.rt+=dt;const k=Math.min(1,e.rt/1.2),tx=Z.x+Math.sin(Z.h)*1.4,tz=Z.z+Math.cos(Z.h)*1.4;e.x+= (tx-e.x)*Math.min(1,dt*3);e.z+=(tz-e.z)*Math.min(1,dt*3);e.moving=k<1;e.h=Math.atan2(Z.x-e.x,Z.z-e.z);if(p.id!=='al_puff')e.lift=0;}
    else if(e.mode==='wander')wander(e,dt,K[0]-6,K[1]+8);
    else if(e.mode==='island'){e.x=PI[0];e.z=PI[1];e.lift=PIH+1+Math.sin(t*2)*.3;e.h=Math.atan2(player.x-e.x,player.z-e.z);if(S().met&&near(e.x,e.z)<16&&(e.cry=(e.cry||0)-dt)<0){e.cry=4;floatS('🎈',e.x,wy(e.x,e.z)+e.lift+2,e.z,1.6);sfx.yip(p.pitch);}}
    else if(e.mode==='under'){e.x=FI[0]+Math.sin(t*.35)*5;e.z=FI[1]+2+Math.cos(t*.27)*2;e.moving=true;e.h=Math.cos(t*.35)>0?Math.PI/2:-Math.PI/2;e.lift=FIH-1.05;e.g.rotation.z=Math.PI;}
    if(p.id==='al_puff'&&e.mode!=='island')e.lift=1+Math.sin(t*2+1)*.3;
    if(p.id==='al_upside'&&(e.mode==='follow'||e.mode==='wander')){e.g.rotation.z=Math.PI;e.lift=1.1;}
    if(p.id==='al_boing'&&e.mode!=='boing'&&!e.moving&&Math.random()<dt*.8)e.g.userData.jump=.6;
    const u=e.g.userData;if(u.tint&&p.id==='al_swatch')u.tint.color.setHSL((t*.15)%1,.75,.72);if(p.id==='al_wobble'){const w=Math.sin(t*9)*.04;e.g.scale.set(u.s*(1+w),u.s*(1-w),u.s*(1+w));}
    if(u.mid)u.mid.forEach((m,i)=>{m.rotation.x=e.moving?Math.sin(t*14+i*Math.PI)*.7:0;});
    u.tm.color.setHSL(0,0,0);u.tm.color.set(p.ant);u.tm.color.multiplyScalar(.75+.25*Math.sin(t*3+p.pitch*7));});
  dartTick(dt);boingTick(dt);popTick(dt);{const q=W.things.find(q=>q.dt);if(q&&dart){q.x=dart.e.x;q.z=dart.e.z;}}
  /* place everyone on the ground */
  [Z].concat(AP.map(p=>ENT[p.id])).forEach(e=>{if(!e)return;e.g.position.set(e.x,wy(e.x,e.z)+(e.lift||0),e.z);e.g.rotation.y=e.h;if(e.g.visible)animPup(e.g,t,e.moving);});
  FL.forEach(f=>{f.open+=(f.target-f.open)*Math.min(1,dt*4);f.tilts.forEach(tl=>{tl.rotation.x=f.open*1.25;});});
  /* the singing rocks hum as Seb walks past */
  ROCKO.forEach((o,i)=>{const d=near(SR[0]+o[0],SR[1]+o[1])<3.4;if(d&&!rockIn[i])snd.note(i);rockIn[i]=d;});}
function wander(e,dt,cx,cz){e.wait=(e.wait||0)-dt;if(e.tx==null){e.tx=e.x;e.tz=e.z;}const dx=e.tx-e.x,dz=e.tz-e.z,d=Math.hypot(dx,dz);e.moving=false;
  if(d>.3){e.moving=true;e.x+=dx/d*3*dt;e.z+=dz/d*3*dt;e.h=lerpAng(e.h,Math.atan2(dx,dz),Math.min(1,dt*6));}else if(e.wait<0){const a=Math.random()*6.28,r=3+Math.random()*9;e.tx=cx+Math.cos(a)*r;e.tz=cz+Math.sin(a)*r;e.wait=2+Math.random()*6;}}

/* ================= mini-games on the cutscene screen ================= */
const SCR=BH.scr,V=SCR.V;
function backBtn(fn){const b=el('button','btn rnd white','◀');b.style.cssText='position:absolute;left:14px;top:10px;pointer-events:auto;z-index:9';SCR.V.back=fn;tap(b,()=>{sfx.boop();SCR.skipAll();fn();});$('#bhUI').appendChild(b);}
function toWorld(){SCR.close();show('world');player.lock=false;hud();}
function winTo(p,x,z){SCR.close();show('world');player.lock=false;foundPup(p,x,z);}
/* Glow: the Dark Cave */
const CR=seed(7);const CAVEBITS=Array.from({length:26},(_,i)=>({x:CR()*1024,y:i<10?0:300+CR()*460,s:30+CR()*60,c:['#7ff6ff','#ff9ee0','#fff27a','#b58cff'][i%4],k:i<10?'tite':i<18?'rock':'crys'}));
BH.MODES.cave=(c,dt)=>{const g=c.createLinearGradient(0,0,0,768);g.addColorStop(0,'#1a1238');g.addColorStop(1,'#2a1a4a');c.fillStyle=g;c.fillRect(0,0,1024,768);
  CAVEBITS.forEach(b=>{if(b.k==='tite'){c.fillStyle='#3a2a5a';c.beginPath();c.moveTo(b.x-b.s*.4,0);c.lineTo(b.x,b.s*2.4);c.lineTo(b.x+b.s*.4,0);c.fill();}
    else if(b.k==='rock'){c.fillStyle='#4a3a6a';c.beginPath();c.ellipse(b.x,b.y,b.s*1.4,b.s*.8,0,0,6.283);c.fill();}
    else{c.fillStyle=b.c;c.globalAlpha=.75;c.beginPath();c.moveTo(b.x-b.s*.25,b.y);c.lineTo(b.x,b.y-b.s*1.2);c.lineTo(b.x+b.s*.25,b.y);c.fill();c.globalAlpha=1;}});
  c.fillStyle='#2a2f6a';c.beginPath();c.ellipse(V.gx,V.gy,58,36,0,0,6.283);c.fill();c.beginPath();c.arc(V.gx+46,V.gy-26,26,0,6.283);c.fill();
  if(V.light===1){const r=c.createRadialGradient(V.lx,V.ly,120,V.lx,V.ly,250);r.addColorStop(0,'rgba(0,0,0,0)');r.addColorStop(1,'rgba(0,0,0,.96)');c.fillStyle=r;c.fillRect(0,0,1024,768);}
  else if(V.light===0){c.fillStyle='rgba(0,0,0,.97)';c.fillRect(0,0,1024,768);
    V.worms.forEach((w,i)=>{BH.glow(c,w.x,w.y,0,7,'rgba(180,255,140,.8)',.5+.5*Math.sin(V.t*2+i));});
    const sp=[[-40,-6],[-20,10],[0,-12],[22,6],[-30,18],[10,20],[34,-10],[46,-30],[56,-20]];sp.forEach((q,i)=>BH.glow(c,V.gx+q[0]*1.3,V.gy+q[1]*1.3,0,20,i%3?'rgba(127,246,255,1)':'rgba(184,255,127,1)',.7+.3*Math.sin(V.t*3+i)));
    const bl=(V.t%3)<.15;c.fillStyle='#fff';[-1,1].forEach(s=>{c.beginPath();c.ellipse(V.gx+60+s*12,V.gy-40,7,bl?1:8,0,0,6.283);c.fill();});}};
async function caveGame(){player.lock=true;const B=S();SCR.open('cave');Object.assign(V,{light:1,lx:512,ly:420,gx:160+Math.random()*700,gy:380+Math.random()*260,worms:Array.from({length:9},()=>({x:60+Math.random()*900,y:120+Math.random()*600})),won:0,taps:0});
  const btn=el('button','bhPrompt','💡 Helmet light: ON');btn.style.cssText+='left:330px;top:660px;width:360px;animation:none';$('#bhUI').appendChild(btn);
  tap(btn,()=>{if(V.won)return;V.light=V.light?0:1;btn.textContent=V.light?'💡 Helmet light: ON':'🌑 Helmet light: OFF';sfx.boop();
    if(!V.light)SCR.cap(ZUZU,'It\'s pitch black! Can you see anything glowing? Tap it!',{dur:5});});
  backBtn(toWorld);
  V.ptr=(k,x,y)=>{if(V.won)return;V.lx=x;V.ly=y;if(k!=='down'||y>640)return;const dg=Math.hypot(x-V.gx-10,y-V.gy+5);
    if(!V.light&&dg<80){V.won=1;V.light=2;snd.sparkle();sfx.giggle();SCR.big('Found you, Glow!');const d=SCR.crewAdd('glow',P('glow'),V.gx-50,V.gy-90);d.querySelector('.hel').style.display='none';
      SCR.cap(ZUZU,'Glow! There you are! Your spots are so bright in the dark!',{dur:4}).then(()=>winTo(P('glow'),CAVEM[0]+1,CAVEM[1]+1));return;}
    if(!V.light){if(V.worms.some(w=>Math.hypot(x-w.x,y-w.y)<40)){snd.tink();SCR.cap(null,'That\'s just a little glow-worm. Look for lots of spots together!',{dur:3.5});}return;}
    if(dg<90){V.taps++;snd.tink();SCR.cap(ZUZU,'Hmm, just a dark lumpy rock... Glow\'s spots only shine in the dark. Try switching off your helmet light!',{dur:5});}};
  await SCR.cap(ZUZU,'It\'s very dark in here! Glow is hiding in this cave. Shine your helmet light around with your finger.',{dur:5});
  setTimeout(()=>{if(cur==='bhcut'&&V.light===1&&!V.won)SCR.cap(ZUZU,'Glow\'s spots only shine in the dark. Try switching off your helmet light!',{dur:5});},9000);}
/* Echo: copy the tune */
const rockSVG=c=>`<svg viewBox="0 0 160 140"><path d="M14 128 Q4 70 40 34 Q80 0 120 30 Q156 60 148 128 Z" fill="${c}" stroke="#26232e" stroke-width="7" stroke-linejoin="round"/><ellipse cx="62" cy="52" rx="14" ry="9" fill="#fff" opacity=".6"/></svg>`;
BH.MODES.echo=(c,dt)=>{const g=c.createLinearGradient(0,0,0,768);g.addColorStop(0,'#5a2a7a');g.addColorStop(.6,'#ff9ec8');g.addColorStop(1,'#ffd6ad');c.fillStyle=g;c.fillRect(0,0,1024,768);
  BH.glow(c,300,180,20,160,'rgba(255,120,200,.7)');BH.glow(c,760,150,10,100,'rgba(110,180,255,.6)');c.fillStyle='#ffc89a';c.beginPath();c.ellipse(512,820,800,280,0,0,6.283);c.fill();};
async function echoGame(){player.lock=true;SCR.open('echo');backBtn(toWorld);const ui=$('#bhUI');const rocks=[];let accept=null;
  const peek=el('div','bhPeek',BH.alienSVG(P('echo')));peek.style.cssText='position:absolute;left:600px;top:250px;width:150px;height:160px;transition:top .6s';ui.appendChild(peek);
  ROCKC.forEach((col,i)=>{const b=el('button','bhRock',rockSVG(col));b.style.left=(90+i*220)+'px';b.style.top=(i===1||i===2?300:340)+'px';ui.appendChild(b);rocks.push(b);
    tap(b,()=>{lite(i);snd.note(i);if(accept)accept(i);});});
  function lite(i){const b=rocks[i];b.classList.remove('lit');void b.offsetWidth;b.classList.add('lit');}
  const play=async seq=>{for(const i of seq){if(SCR.V.skip)throw SCR.SKIP;lite(i);snd.note(i);await SCR.wait(700);}};
  try{await SCR.go(SCR.cap(ZUZU,'Echo is hiding behind the Singing Rocks! She copies every sound. Listen to her song, then tap the rocks to sing it back.',{dur:6}));
    for(let r=0;r<3;r++){const seq=Array.from({length:r+2},()=>Math.floor(Math.random()*4));
      for(;;){SCR.cap(null,`Echo sings ${seq.length} notes. Listen!`,{dur:2,noNext:true});await SCR.go(SCR.wait(1100));await play(seq);SCR.cap(null,'Your turn! Tap the rocks.',{dur:30,noNext:true});
        SCR.V.seq=seq;const ok=await new Promise(res=>{let k=0;accept=i=>{if(i!==seq[k]){accept=null;res(false);return;}k++;if(k>=seq.length){accept=null;res(true);}};SCR.V.onSkip=()=>res(true);});
        if(SCR.V.skip)throw SCR.SKIP;if(ok)break;SCR.cap(null,'Oops! Listen again.',{dur:2});snd.boing();await SCR.go(SCR.wait(1500));}
      snd.sparkle();SCR.big(r<2?'🎵 Yes!':'🎵🎵🎵');await SCR.go(SCR.wait(1500));}
    peek.style.top='90px';sfx.giggle();for(let i=0;i<4;i++){lite(i);snd.note(i);await SCR.wait(260);}
    await SCR.go(SCR.cap(ZUZU,'Echo popped out to sing with you! Clever Seb!',{dur:3.6}));winTo(P('echo'),SR[0],SR[1]+3);}catch(e){if(e!==SCR.SKIP)console.warn(e);}}
/* Swatch: the crystal with blinking eyes */
const crystalSVG=(c,eyes)=>`<svg viewBox="0 0 100 150"><path d="M50 4 L84 40 L72 144 L28 144 L16 40 Z" fill="${c}" stroke="#26232e" stroke-width="6" stroke-linejoin="round"/><path d="M50 4 L50 144 M16 40 L84 40" stroke="#fff" stroke-width="3" opacity=".5"/>${eyes?'<g class="eyes"><ellipse cx="38" cy="70" rx="8" ry="10" fill="#fff" stroke="#26232e" stroke-width="3"/><ellipse cx="62" cy="70" rx="8" ry="10" fill="#fff" stroke="#26232e" stroke-width="3"/><circle cx="39" cy="72" r="4" fill="#26232e"/><circle cx="63" cy="72" r="4" fill="#26232e"/></g>':''}</svg>`;
BH.MODES.swatch=(c,dt)=>{const g=c.createLinearGradient(0,0,0,768);g.addColorStop(0,'#3a1a6a');g.addColorStop(.55,'#b58cff');g.addColorStop(1,'#e8d8ff');c.fillStyle=g;c.fillRect(0,0,1024,768);BH.glow(c,820,140,10,120,'rgba(255,120,200,.7)');c.fillStyle='#d6c4ff';c.fillRect(0,560,1024,208);};
async function swatchGame(){player.lock=true;SCR.open('swatch');backBtn(toWorld);const ui=$('#bhUI'),cols=['#ff8fd0','#b58cff','#7fe0ff','#fff27a','#8fe39a','#ffa64d'],k=Math.floor(Math.random()*16);let miss=0,won=false;
  for(let i=0;i<16;i++){const c=cols[(i*5+Math.floor(i/4))%6],b=el('button','bhCrys'+(i===k?' sw':''),crystalSVG(c,i===k));b.style.left=(70+(i%8)*112+(Math.floor(i/8)%2)*40)+'px';b.style.top=(i<8?190:420)+((i*37)%40)+'px';b.style.setProperty('--s',(.85+((i*13)%5)*.07).toFixed(2));ui.appendChild(b);
    tap(b,()=>{if(won)return;if(i===k){won=true;snd.sparkle();sfx.giggle();b.innerHTML=BH.alienSVG(P('swatch'));b.classList.add('rainbow');SCR.big('Found you, Swatch!');SCR.cap(ZUZU,'Swatch! You were pretending to be a crystal! What a clever disguise.',{dur:4}).then(()=>winTo(P('swatch'),SWC[0]+1,SWC[1]+4));}
      else{snd.tink();b.classList.remove('nope');void b.offsetWidth;b.classList.add('nope');miss++;if(miss===2||miss===5)SCR.cap(ZUZU,'That\'s just a crystal. Watch closely for one with eyes that blink!',{dur:4});}});}
  SCR.cap(ZUZU,'Swatch is pretending to be one of these crystals! Watch carefully, and tap the one that blinks.',{dur:6});}

/* ================= mending the Stargazer: count to 10 ================= */
const FIX={al_wobble:['crack','🍮','Wobble squishes jelly into the crack in the windscreen. Sealed!'],al_peep:['pipe','🔧','Peep squeezes into a tiny pipe and unblocks it!'],al_puff:['fin','🎈','Puff floats up and pushes the bent fin straight!'],
  al_dart:['bolts','🔩','Six legs, six spanners! Dart tightens every bolt.'],al_glow:['light','💡','Glow lights up the dashboard!'],al_echo:['song','🎵','Echo sings the engine\'s song, and it starts to purr!'],
  al_swatch:['scorch','🎨','Swatch paints over the scorch marks!'],al_boing:['dent','💥','Boing bounces on the dent and pops it out!'],al_popper:['pebble','🪨','Popper pops into the engine, and pops out the space pebble!'],al_upside:['bottom','🔧','Upside hangs upside down and mends the bottom of the ship!']};
const NUMW=['One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten'];
BH.MODES.repair=(c,dt)=>{BH.farSky(c,dt,{home:false});c.fillStyle='#a8ecc0';c.beginPath();c.ellipse(512,900,900,400,0,0,6.283);c.fill();
  for(let i=0;i<12;i++){const x=40+i*86,y=560+(i%3)*18;c.fillStyle='#5fbf7a';c.fillRect(x-2,y-40,4,40);BH.glow(c,x,y-44,0,18,['rgba(255,143,208,.9)','rgba(127,224,255,.9)','rgba(255,242,122,.9)'][i%3]);}
  const fx=V.fixed,br={crack:!fx.crack,fin:!fx.fin,dent:!fx.dent,scorch:!fx.scorch,bolts:!fx.bolts};
  if(!(fx.song&&fx.pebble)&&Math.random()<dt*5)V.pf.push({x:330,y:330,r:16,a:.7});V.pf=V.pf.filter(p=>{p.y-=dt*40;p.x-=dt*12;p.r+=dt*14;p.a-=dt*.25;if(p.a<=0)return false;c.fillStyle=`rgba(100,100,110,${p.a})`;c.beginPath();c.arc(p.x,p.y,p.r,0,6.283);c.fill();return true;});
  BH.ship2D(c,560,360,3,V.done?-.05:.08,{broken:br,light:fx.light?'blink':'off',flame:!!V.done});
  if(V.done)BH.glow(c,560,360,60,340,'rgba(255,250,200,.25)');};
async function repair(){if(player.lock)return;player.lock=true;SCR.open('repair');Object.assign(V,{fixed:{},pf:[],done:false});backBtn(toWorld);const ui=$('#bhUI');let n=0;
  const z=SCR.crewAdd('zuzu',ZUZU,24,150);z.querySelector('.hel').style.display='none';
  AP.forEach((p,i)=>{const b=el('button','bhFix',`<span class="pic">${BH.alienSVG(p)}</span>`);b.style.left=(18+i*99)+'px';b.style.top='640px';ui.appendChild(b);
    tap(b,()=>{if(b.classList.contains('done')||V.busy)return;V.busy=1;b.classList.add('done');n++;const f=FIX[p.id];
      const num=el('div','bhNum',String(n));num.style.left=b.style.left;ui.appendChild(num);setTimeout(()=>num.remove(),1500);speak(NUMW[n-1]+'!');sfx.yip(p.pitch);
      setTimeout(()=>{V.fixed[f[0]]=1;snd.sparkle();const fx=el('div','bhHeart',f[1]);fx.style.left=(430+Math.random()*260)+'px';fx.style.top=(260+Math.random()*120)+'px';ui.appendChild(fx);setTimeout(()=>fx.remove(),1200);
        SCR.cap(p,f[2],{dur:2.6,speak:false});V.busy=0;if(n>=10)finish();},700);});});
  SCR.cap(ZUZU,'Tap my puppies one at a time, and count to 10! Each one will mend a different part of your ship.',{dur:6});
  async function finish(){V.busy=1;await SCR.wait(1800);snd.zap();SCR.flash(.6,'#fff7a0');await SCR.cap(ZUZU,'Ten! And now my antennae give the engine a zap... Bzzzt!',{dur:3.6});
    V.done=true;sfx.fanfare();SCR.big('Fixed!');const B=S();B.fixed=Date.now();save();
    await SCR.cap(ZUZU,'The Stargazer is mended! My puppies even made you a new lever.',{dur:4});SCR.close();show('world');
    const sh=BH.alien.ship;if(sh){const u=sh.userData;u.body.rotation.set(0,0,0);u.body.position.y=0;u.fins[1].rotation.z=-4.19;u.wm.color.set('#ff3a3a');u.hatch.rotation.z=-1.35;}
    AP.forEach(p=>{if(ENT[p.id])ENT[p.id].mode='wander';});if(Z)Z.mode='wander';
    card({art:starMap(),h:'Zuzu\'s star map',p:`Zuzu gives you a glowing star map. It shows the way home, back through the wormhole!`,btns:[['🚀 Fly home!','green',()=>{player.lock=true;BH.flyHome();}],['Not yet','white',()=>{player.lock=false;say('Tap 🚀 Fly home by the Stargazer when you are ready.');}]]});}}
function starMap(){let s='<svg viewBox="0 0 300 200" style="width:300px;height:200px"><rect x="4" y="4" width="292" height="192" rx="18" fill="#16205a" stroke="#26232e" stroke-width="6"/>';
  for(let i=0;i<40;i++)s+=`<circle cx="${14+(i*67)%272}" cy="${14+(i*41)%172}" r="${1+i%2}" fill="#fff" opacity=".7"/>`;
  s+='<path d="M240 150 Q200 120 160 100 Q110 80 70 52" fill="none" stroke="#fff27a" stroke-width="5" stroke-dasharray="10 8"/><circle cx="244" cy="152" r="18" fill="#ff9ee0" stroke="#26232e" stroke-width="4"/><circle cx="160" cy="100" r="16" fill="#000" stroke="#ffd27a" stroke-width="5"/>';
  s+='<g transform="translate(62 48)"><circle r="16" fill="#e8e0ff" opacity=".5"/><path d="M-12 -2 Q0 -14 12 -2 Q0 10 -12 -2" fill="#fff"/></g><text x="62" y="86" font-size="18" font-weight="900" text-anchor="middle" fill="#fff">HOME</text></svg>';return s;}

/* ================= fitting in with the rest of the game ================= */
const _ea=enterArea;enterArea=function(id){if(id==='alien')A.exits=S().done?[EXIT]:[];return _ea.apply(this,arguments);};
const _hud=hud;hud=function(){_hud.apply(this,arguments);if(W.area===A){const pl=$('#wPill');if(pl)pl.textContent+=`  👽 ${aFound()}/10`;}};
const _gh=goHome;goHome=function(){if(W.area===A&&!player.lock){player.lock=true;sfx.chime();fadeTo(()=>enterArea('village',(islandOf('planet')||{}).homePos||AREAS.village.dock,'Home again in Pawprint Village!'),['🌠','Zuzu\'s shooting star whooshes you home through the wormhole!']);return;}return _gh.apply(this,arguments);};
const _am=areaMap;areaMap=function(IS){const Mp=IS&&IS.map;if(!Mp||IS.id!=='planet'||!state.seen.alien)return _am.apply(this,arguments);
  Mp.nodes.alien=[80,58];Mp.links.push(['blackhole','alien']);try{return _am.apply(this,arguments);}finally{delete Mp.nodes.alien;Mp.links.pop();}};

{const st=document.createElement('style');st.textContent=`
.bhRock{position:absolute;width:190px;height:170px;border:0;background:none;padding:0;pointer-events:auto;transition:transform .15s}.bhRock svg{width:190px;height:170px}
.bhRock.lit{animation:bhLit .6s ease-out}@keyframes bhLit{0%{transform:scale(1.15) translateY(-14px);filter:brightness(1.5) drop-shadow(0 0 30px #fff)}100%{transform:none;filter:none}}
.bhPeek svg{width:150px;height:160px}
.bhCrys{position:absolute;width:100px;height:150px;border:0;background:none;padding:0;pointer-events:auto;transform:scale(var(--s,1))}.bhCrys svg{width:100px;height:150px}
.bhCrys .eyes{opacity:0}.bhCrys.sw .eyes{animation:bhBlink 2.6s infinite}@keyframes bhBlink{0%,62%,100%{opacity:0}66%,88%{opacity:1}}
.bhCrys.nope{animation:bhNope .4s}@keyframes bhNope{25%{transform:rotate(-8deg) scale(var(--s,1))}75%{transform:rotate(8deg) scale(var(--s,1))}}
.bhCrys.rainbow{width:150px;animation:bhHue 2s linear infinite}.bhCrys.rainbow svg{width:150px;height:158px}@keyframes bhHue{to{filter:hue-rotate(360deg)}}
.bhFix{position:absolute;width:94px;height:104px;border:4px solid #26232e;border-radius:20px;background:#fffdf5;padding:0;pointer-events:auto;box-shadow:0 5px 0 rgba(0,0,0,.3)}.bhFix svg{width:86px;height:92px}
.bhFix.done{opacity:.45;transform:translateY(8px)}
.bhNum{position:absolute;top:520px;width:94px;text-align:center;font-size:84px;font-weight:900;color:#fff27a;-webkit-text-stroke:6px #26232e;paint-order:stroke;animation:bhUp 1.5s ease-out forwards;pointer-events:none}`;document.head.appendChild(st);}
})();
