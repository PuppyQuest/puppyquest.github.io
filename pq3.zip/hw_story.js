/* ================================================================
   Halloween (25 Nov 2026; claude/halloween-design.md sections 2, 4, 9, 10, 15): the story.
   Monster sightings during the search, "brave enough" at nine Brave Paws, behind the curtain in
   Number Castle (Muddle unmasked, the Friendly Monster), the Trick-or-Treat Trail (a 2D trail round
   the nine islands, sharing treats fairly: the start of division), the Pumpkin Parade (Bravest
   Costume), 6 badges, the Halloween Hero certificate, the goodbye and the Summer Beach Party teaser.
   Nothing is a ghost: the little pup is a real puppy in a bedsheet, and the monster is Muddle.
   ================================================================ */
(function(){
const HW=window.HW,HL=window.HLOOK,PI=Math.PI,ORNG='#ff8a1a',GOLD='#ffd23f',PURP='#4b3a7a';
const X=()=>HW.GS(),F=()=>HW.pal().name,big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`,Cap=s=>s.charAt(0).toUpperCase()+s.slice(1);
const ps=(w,o)=>`<div class="fitsvg" style="width:${w||160}px">${HW.palSVG(o)}</div>`,mg=w=>`<div class="fitsvg" style="width:${w||150}px">${magpieSVG()}</div>`,mon=w=>`<div class="fitsvg" style="width:${w||170}px">${monsterSVG()}</div>`;
/* Muddle in his monster costume: googly eyes, a furry purple suit, feathers poking out, bird feet */
function monsterSVG(mask){const K=INK;let fur='';for(let i=0;i<26;i++){const a=PI+i/25*PI,x=100+Math.cos(a)*74,y=104+Math.sin(a)*78;fur+=`${i?'L':'M'}${x.toFixed(1)} ${y.toFixed(1)} L${(100+Math.cos(a+.06)*84).toFixed(1)} ${(104+Math.sin(a+.06)*88).toFixed(1)} `;}
  return `<svg viewBox="0 0 200 210" xmlns="http://www.w3.org/2000/svg"><path d="M26 64 q-26 -6 -20 -30 q14 12 28 16 Z M174 64 q26 -6 20 -30 q-14 12 -28 16 Z" fill="#2f4fa8" stroke="${K}" stroke-width="3"/>`+
   `<path d="M30 120 q-28 4 -26 -18 q16 8 30 4 Z" fill="#26232e" stroke="${K}" stroke-width="3"/><path d="M172 132 q28 6 26 -16 q-16 8 -30 2 Z" fill="#ffffff" stroke="${K}" stroke-width="3"/>`+
   `<path d="${fur} L174 170 Q100 196 26 170 Z" fill="#8a5ad8" stroke="${K}" stroke-width="4" stroke-linejoin="round"/><path d="M62 36 l-8 -22 l18 14 Z M138 36 l8 -22 l-18 14 Z" fill="#ffd23f" stroke="${K}" stroke-width="3"/>`+
   `<circle cx="74" cy="82" r="24" fill="#fff" stroke="${K}" stroke-width="4"/><circle cx="128" cy="78" r="28" fill="#fff" stroke="${K}" stroke-width="4"/><circle cx="80" cy="90" r="10" fill="${K}"/><circle cx="120" cy="88" r="12" fill="${K}"/>`+
   `<path d="M66 128 Q100 156 136 128" stroke="${K}" stroke-width="5" fill="#5a2a6a"/><path d="M84 132 l6 8 l6 -8 M104 132 l6 8 l6 -8" stroke="#fff" stroke-width="3" fill="#fff"/>`+
   [70,130].map(x=>`<path d="M${x} 184 l-14 18 M${x} 184 v22 M${x} 184 l14 18" stroke="#ff9a3a" stroke-width="6" stroke-linecap="round"/>`).join('')+`</svg>`;}
/* a bird's three-toed footprint, for the clue in the castle */
let PRT=null;function printTex(){if(PRT)return PRT;const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.strokeStyle='#ffd23f';g.lineWidth=14;g.lineCap='round';g.shadowColor='#ffb040';g.shadowBlur=16;
  g.beginPath();g.moveTo(64,110);g.lineTo(64,50);g.moveTo(64,50);g.lineTo(28,18);g.moveTo(64,50);g.lineTo(64,10);g.moveTo(64,50);g.lineTo(100,18);g.stroke();PRT=new THREE.CanvasTexture(c);texC['hwprint']=PRT;return PRT;}

/* ---------------- monster sightings during the search ---------------- */
const SEEN={4:'A pup whispers: "I saw a MONSTER by the pumpkins! Big googly eyes and a furry purple suit. It went BOO, and I hid!"',
 12:'Professor Hoot says: "The monster ran past my window. And I am quite sure I saw feathers sticking out of its fur!"',
 24:'A pup says: "The monster found our sweets and said, ooh, shiny! Then it only took the ones in shiny wrappers."',
 40:'Somebody heard the monster try to roar... but it came out as a squawk! "Does that sound like anyone we know?" whispers '};
const KS=[4,12,24,40];
function afterFind(p,n){const T=X();T.seen=T.seen||{};const k=KS.find(k=>n>=k&&!T.seen[k]);if(!k)return false;T.seen[k]=1;T.sneak=p.island;save();
  setTimeout(()=>{say(SEEN[k]+(k===40?F()+'.':''));HW.PAL.jump=.5;},300);return true;}
const sneak=()=>{const T=HW.G0();return T&&!T.unmask?T.sneak:null;};
/* ---------------- nine Brave Paws: brave enough ---------------- */
function onBrave(I,n){if(n<9)return;const T=X();setTimeout(()=>{player.lock=true;HW.snd.song(9,240);
  story([{art:ps(190),t:`${F()} stands up tall, with nine golden Brave Paws on ${HW.his()} sheet. "I'm brave enough now," ${HW.he()} says. "Let's find that monster!"`},
    {art:big('🐾🐾🐾'),t:'By the pumpkins there are footprints: big ones, with three long toes... just like a bird\'s! They lead all the way to the Number Kingdom, to the castle museum at night.'}],
    ()=>{player.lock=false;T.call=Date.now();save();card({art:big('🏰'),h:'To Number Castle!',p:'Shall we follow the footprints to Number Castle?',btns:[['🏰 Let\'s go!','green',()=>{player.lock=true;fadeTo(()=>enterArea('castle'),['🏰','Number Castle']);}],['Later','white',()=>say('Number Castle is in the Number Kingdom. Take the ferry from the village!')]]});});},900);}
/* ---------------- behind the curtain in Number Castle ---------------- */
let CU=null;
{const Ac=AREAS.castle,b=Ac.build;Ac.build=function(){b.apply(this,arguments);CU=null;if(!HW.on())return;const T=HW.G0();if(!T||!T.call||T.unmask)return;const A=Ac,s=A.start||[0,0],nr=window.HWORLD?HWORLD.near:(a,x,z)=>[x,z];
  const fx=-Math.sin(s[2]||0),fz=-Math.cos(s[2]||0),c=nr(A,s[0]-fx*16,s[1]-fz*16,3),x=c[0],z=c[1],y=gy(x,z),r=Math.atan2(s[0]-x,s[1]-z);
  const cur=grp();[-1,1].forEach(k=>{const m=mk('box','#6a2a8a',1.6,4.2,.25,k*.85,2.1,0,cur);m.userData.k=k;});mk('box',GOLD,3.6,.25,.35,0,4.3,0,cur);cur.position.set(x,y,z);cur.rotation.y=r;W.ag.add(cur);col(x,z,1.8);
  const mo=grp(),bd=mk('sph','#8a5ad8',1.2,1.4,1,0,1.5,0,mo);[[-.42,2.2,.8,.36],[.42,2.25,.8,.42]].forEach(q=>{mk('sph','#ffffff',q[3],q[3],.2,q[0],q[1],q[2],mo);mk('sph','#26232e',q[3]*.45,q[3]*.45,.1,q[0]+.05,q[1]-.08,q[2]+.12,mo);});
  mk('cone','#2f4fa8',.18,.9,.18,-1.2,1.8,0,mo).rotation.z=1.1;mk('cone','#ffffff',.18,.9,.18,1.2,1.6,0,mo).rotation.z=-1.1;mo.position.set(x-Math.sin(r)*1.3,y,z-Math.cos(r)*1.3);mo.rotation.y=r;mo.visible=false;W.ag.add(mo);
  const cl=[['hwprint','a big footprint with three long toes, just like a bird\'s!'],['🪶','a black and white feather... with a blue tip!'],['🍬','a sweet wrapper, a very shiny one!']].map((q,i)=>{const t=(i+1)/4,cx=s[0]+(x-s[0])*t+(i-1)*2.2,cz=s[1]+(z-s[1])*t,p=nr(A,cx,cz,1);
    if(q[0]==='hwprint')printTex();const sp=spr(q[0],1.6,p[0],gy(p[0],p[1])+.6,p[1]);const o={sp,x:p[0],z:p[1],got:false,say:q[1]};
    o.th={x:p[0],z:p[1],r:3,icon:i===0?'🐾':q[0],label:'A clue!',show:()=>!o.got,act:()=>{o.got=true;sfx.chime();HW.snd.twinkle();sp.scale.multiplyScalar(1.4);const left=CU.cl.filter(c=>!c.got).length;
      say(`A clue: ${q[1]}`+(left?` ${left} more ${left>1?'clues':'clue'} to find!`:` That's all three clues. Now go to the curtain!`));}};W.things.push(o.th);return o;});
  CU={cur,mo,cl,x,z};W.ticks.push(()=>{if(W.area!==A||!CU)return true;const t=W.t;cur.children.forEach(m=>{if(m.userData.k)m.rotation.z=Math.sin(t*3+m.userData.k)*.03*(Math.sin(t*.9)>.6?3:.4);});cl.forEach((o,i)=>{o.sp.position.y=gy(o.x,o.z)+.6+Math.sin(t*3+i)*.15;});});
  W.things.push({x:x+Math.sin(r)*2.6,z:z+Math.cos(r)*2.6,r:4,icon:'✊',label:'Knock knock',act:curtain});
  setTimeout(()=>{if(W.area===A&&!player.lock)say(`Shh! The curtain is twitching... Find the three clues on the floor first. ${F()} is right behind you!`);},2200);};}
function curtain(){if(player.lock||!CU)return;const left=CU.cl.filter(c=>!c.got).length;if(left){sfx.oops();say(`Find the ${left===3?'three':left} ${left>1?'clues':'clue'} on the floor first!`);return;}
  player.lock=true;hush();HW.snd.knock();say(`${F()} holds up ${HW.his()} pumpkin bucket and knocks: "Trick or treat?"`);
  setTimeout(()=>{CU.mo.visible=true;CU.cur.children.forEach(m=>{if(m.userData.k)m.position.x=m.userData.k*1.9;});sfx.giggle();unmask();},2200);}
function unmask(){const T=X();MUSIC.over='hmk';
  story([{art:mon(190),t:'The curtain swishes open, and there is the MONSTER! Big googly eyes, a furry purple suit... and feathers poking out everywhere.'},
    {art:ps(160),t:`${F()} trembles, but stands tall. "Excuse me, Mr Monster. You scared me on the way to the parade. Why did you say BOO?"`},
    {art:mon(150),t:'The monster looks at its feet. Then it takes off its big furry head...'},
    {art:mg(160),t:'It\'s MUDDLE! "I wanted to win Scariest Costume at the Pumpkin Parade," he says. "I practised my BOO so much. But when I made you cry, I felt terrible. I\'m so sorry."'},
    {art:ps(160),t:`${F()} smiles. "Your costume is brilliant, Muddle. But the best costumes make people smile."`},
    {art:mg(150)+big('🎃'),t:'Muddle\'s eyes light up. "Then I\'ll be the Friendly Monster! Can I come trick-or-treating with you all?"'}],
    ()=>{T.unmask=Date.now();save();MUSIC.over=null;if(CU){CU.mo.visible=false;const m=magpie3D();add(m,CU.x,CU.z);}player.lock=false;
      card({art:big('🎃🚪🍬'),h:'The Trick-or-Treat Trail',p:'Everyone goes trick-or-treating round all nine islands, and you share the treats out fairly. Ready?',btns:[['🍬 Let\'s go!','green',()=>trail()],['Later','white',()=>say('Come back to the village when you are ready for the Trick-or-Treat Trail!')]]});});}
/* ---------------- the Trick-or-Treat Trail ---------------- */
const LEGS=[['meadow',6,2],['snowy',8,2],['reef',9,3],['ninja',12,3],['number',12,4],['gadget',20,4],['rescue',15,5],['dino',30,5],['planet',40,10]];
const SWEETS=['🍬','🍭','🍫','🧁','🍪','🍎'];
let TR=null;
function trailUI(){if($('#htrail'))return;const d=el('div','screen',`<div id="htSky"></div><div id="htIsl"></div><div id="htParty"></div><div id="htDoor"></div><div id="htPanel"></div><button class="btn rnd white" id="htBack">◀</button><div class="pill" id="htPill"></div>`);d.id='htrail';
  const q=document.querySelector('#quiz');q.parentNode.insertBefore(d,q);
  tap('#htBack',()=>{sfx.boop();if(!TR)return;TR=null;MUSIC.over=null;show('world');player.lock=false;say('You can carry on the Trick-or-Treat Trail from the village whenever you are ready.');});}
function friends(n){const B=state.buddy&&pupById(state.buddy),L=[['Seb',`<div class="fitsvg">${sebSVG(true)}</div>`],[F(),`<div class="fitsvg">${HW.palSVG()}</div>`],['Muddle',`<div class="fitsvg">${magpieSVG()}</div>`]];
  if(B)L.push([B.name,`<div class="fitsvg">${critterSVG(HL.hp(B),{anim:false})}</div>`]);
  const more=ISLANDS.map(I=>I.pups[1]).filter(p=>p&&(!B||p.id!==B.id));let k=0;while(L.length<n){const p=more[k++%more.length];L.push([p.name,`<div class="fitsvg">${critterSVG(HL.hp(p),{anim:false})}</div>`]);}return L.slice(0,n);}
function trail(){trailUI();hush();player.lock=true;const T=X(),start=Math.min(LEGS.length-1,Math.max(0,T.leg||0));
  TR={i:start-1,busy:false};$('#htSky').innerHTML=`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice"><defs><linearGradient id="hts" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2a1f5a"/><stop offset=".75" stop-color="#ff9a5a"/></linearGradient></defs><rect width="1024" height="768" fill="url(#hts)"/><circle cx="860" cy="130" r="64" fill="#ffc98a"/><circle cx="860" cy="130" r="100" fill="#ffb070" opacity=".2"/>`+
    Array.from({length:40},(v,i)=>{const R=seed(i*7+3);return `<circle cx="${(R()*1024).toFixed(0)}" cy="${(R()*320).toFixed(0)}" r="${(1+R()*2).toFixed(1)}" fill="#fff" opacity="${(.4+R()*.5).toFixed(2)}"/>`;}).join('')+`<path d="M0 560 Q256 480 512 560 T1024 560 V768 H0 Z" fill="#3a2a50"/></svg>`;
  const B=state.buddy&&pupById(state.buddy);$('#htParty').innerHTML=[`<div class="htp fitsvg" style="width:96px">${sebSVG(true)}</div>`,`<div class="htp fitsvg" style="width:96px">${HW.palSVG()}</div>`,`<div class="htp fitsvg" style="width:92px">${magpieSVG()}</div>`].concat(B?[`<div class="htp fitsvg" style="width:96px">${critterSVG(HL.hp(B),{anim:false})}</div>`]:[]).join('');
  show('htrail');MUSIC.over='hvil';speak('Off we go! At every door, a pup in costume gives us treats. Help share them out fairly, so every friend gets the same.');setTimeout(nextLeg,1400);}
function nextLeg(){const R=TR;if(!R)return;R.i++;X().leg=R.i;save();if(R.i>=LEGS.length){endTrail();return;}const L=LEGS[R.i],I=islandOf(L[0]),p=I.pups[(R.i*3+2)%I.pups.length];
  $('#htPill').textContent=`🍬 ${R.i+1} of 9: ${I.name}`;$('#htPanel').innerHTML='';$('#htParty').classList.add('walk');
  $('#htIsl').innerHTML=`<div class="htisl"><span>${I.icon}</span><b>${I.name}</b></div>`;$('#htIsl').classList.remove('in');void $('#htIsl').offsetWidth;$('#htIsl').classList.add('in');
  $('#htDoor').innerHTML=`<div class="htdoor"><div class="htdf"></div><div class="htpup fitsvg">${critterSVG(HL.hp(p),{anim:false})}</div></div>`;
  setTimeout(()=>{if(TR!==R)return;$('#htParty').classList.remove('walk');HW.snd.knock();setTimeout(()=>{if(TR!==R)return;$('#htDoor .htdoor').classList.add('open');sfx.yip(p.pitch||1);share(L,p);},800);},2000);}
function share(L,p){const R=TR,n=L[1],k=L[2],each=n/k,fr=friends(k),sw=SWEETS[R.i%SWEETS.length];R.left=n;R.got=Array(k).fill(0);R.busy=false;R.solved=false;
  const opts=[each,each+1,Math.max(1,each-1),each*2].filter((v,i,a)=>a.indexOf(v)===i&&v!==n).slice(0,3).sort((a,b)=>a-b);
  $('#htPanel').innerHTML=`<div class="htq"><h2>${p.name} gives us ${n} ${sw}! Share them between ${k} friends. How many each?</h2>`+
    `<div class="htrow"><button class="htbask" id="htBask"><div class="htpile" style="font-size:${n<=12?38:n<=20?30:24}px">${Array(n).fill(sw).map(s=>`<i>${s}</i>`).join('')}</div><small>Tap to give everyone one each</small></button>`+
    `<div class="htbags">${fr.map((f,i)=>`<div class="htbag"><div class="htfr">${f[1]}</div><div class="htsack" data-i="${i}"></div><b>${f[0]}</b><em data-c="${i}">0</em></div>`).join('')}</div></div>`+
    `<div class="htans">${opts.map(v=>`<button class="opt" data-v="${v}">${v} each</button>`).join('')}</div></div>`;
  const m=`${p.name} gives us ${n} treats! Share them between ${k} friends. How many does each friend get? Tap the basket to give everyone one each.`;speak(m);
  tap('#htBask',()=>{if(R.busy||R.left<=0)return;round(L);});
  document.querySelectorAll('#htPanel .htans .opt').forEach(b=>tap(b,()=>{if(R.busy)return;const v=+b.dataset.v;
    if(v===each){b.classList.add('on');sfx.chime();if(R.left>0){R.busy=true;const go=()=>{if(TR!==R)return;if(R.left>0){round(L,true);setTimeout(go,420);}else{R.busy=false;win(L,p);}};say(`Yes! Let's check by sharing them out.`);setTimeout(go,500);}else win(L,p);}
    else{sfx.oops();b.classList.add('no');if(R.left>0){R.busy=true;say('Let\'s find out! Watch as we give everyone one each, again and again.');const go=()=>{if(TR!==R)return;if(R.left>0){round(L,true);setTimeout(go,700);}else{R.busy=false;reveal(L);}};setTimeout(go,900);}else reveal(L);}}));}
function round(L,quiet){const R=TR,k=L[2];for(let i=0;i<k&&R.left>0;i++){R.left--;R.got[i]++;const sk=document.querySelector(`#htPanel .htsack[data-i="${i}"]`),pile=document.querySelectorAll('#htPanel .htpile i');if(pile.length)pile[pile.length-1].remove();
    if(sk)sk.insertAdjacentHTML('beforeend',`<i>${SWEETS[R.i%SWEETS.length]}</i>`);const c=document.querySelector(`#htPanel em[data-c="${i}"]`);if(c)c.textContent=R.got[i];}
  HW.snd.note(Math.min(8,R.got[0]-1));if(!quiet&&R.left===0){say(`The basket is empty! Each friend got ${R.got[0]}. So how many each?`);document.querySelectorAll('#htPanel .htans .opt').forEach(b=>b.classList.toggle('hint',+b.dataset.v===R.got[0]));}}
function reveal(L){const each=L[1]/L[2];say(`Each friend got ${each}! ${L[1]} shared between ${L[2]} is ${each} each.`);document.querySelectorAll('#htPanel .htans .opt').forEach(b=>b.classList.toggle('hint',+b.dataset.v===each));}
function win(L,p){const R=TR;if(R.solved)return;R.solved=true;const each=L[1]/L[2];confetti(30);sfx.fanfare();const m=`${L[1]} shared between ${L[2]} is ${each} each. Fair for everyone! Thank you, ${p.name}!`;say(m);
  $('#htPanel .htq h2').textContent=`✅ ${L[1]} shared between ${L[2]} is ${each} each!`;setTimeout(()=>{if(TR===R){$('#htDoor .htdoor').classList.remove('open');nextLeg();}},3200);}
function endTrail(){const T=X(),first=!T.trail;TR=null;T.trail=Date.now();if(first){state.stars+=100;}save();hud();MUSIC.over=null;
  fadeTo(()=>{show('world');enterArea('village',[0,15,PI]);setTimeout(()=>parade(),900);},['🎃','The Pumpkin Parade']);}
/* ---------------- the Pumpkin Parade ---------------- */
function parade(){const T=X();if(T.done)return;if(!W.area||W.area.id!=='village'){fadeTo(()=>{enterArea('village',[0,15,PI]);setTimeout(parade,900);},['🎃','The Pumpkin Parade']);return;}
  player.lock=true;hush();MUSIC.over='hvil';const zu=window.BHQ&&state.bh&&state.bh.done?' Zuzu and her puppies have come in space costumes!':'';
  const rosette=`<svg viewBox="0 0 120 150" width="120"><path d="M40 90 L26 146 L46 132 L56 150 L60 96 Z M80 90 L94 146 L74 132 L64 150 L60 96 Z" fill="#e8423a" stroke="#26232e" stroke-width="3"/><circle cx="60" cy="60" r="46" fill="${GOLD}" stroke="#26232e" stroke-width="4"/><circle cx="60" cy="60" r="32" fill="#fff3c2" stroke="#26232e" stroke-width="3"/><text x="60" y="56" font-size="15" font-weight="900" text-anchor="middle" font-family="Arial" fill="#5a2a10">BRAVEST</text><text x="60" y="74" font-size="13" font-weight="900" text-anchor="middle" font-family="Arial" fill="#5a2a10">COSTUME</text></svg>`;
  story([{art:big('🎃🏡🎃'),t:`Back in Pawprint Village, every pumpkin is lit for the Pumpkin Parade! All the pups march round the plaza in their costumes, with Granny Paws, the guides and all nine unicorns.${zu}`},
    {art:mg(140)+big('🍬'),t:'And here comes Muddle, the Friendly Monster, handing out sweets from a pumpkin bucket. Everyone cheers, and Muddle does a happy little squawk.'},
    {art:`<div class="fitsvg" style="width:130px">${grannySVG()}</div>`,t:'Granny Paws climbs up to the stage. "And the prize for the Bravest Costume goes to..."'},
    {art:ps(150)+rosette,t:`"...${F()}!" Everyone claps. ${F()} was scared of the dark, but ${HW.he()} searched every island with Seb, and found the monster, and made a new friend.`},
    {art:`<div class="fitsvg" style="width:150px">${critterSVG(Object.assign({},state.buddy&&pupById(state.buddy)||PUPS.buttercup,{dressAs:'hwpump'}),{anim:false})}</div>`,t:'Granny Paws has a pumpkin suit for every pup (you can dress any pup in it at the Pup Spa), and there are carved pumpkins, bat bunting and a cauldron of sweets waiting in your Den!'}],
    ()=>{T.done=Date.now();state.stars+=100;state.costumes=state.costumes||{};state.costumes.hwpump=1;state.certs=state.certs||{};const c=CERTS.find(q=>q.id==='hwhero');if(c&&!state.certs[c.id])state.certs[c.id]=Date.now();save();hud();
      if(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray! +100 ⭐','green',goodbye]]}));}else goodbye();});}
const BEACH='<svg viewBox="0 0 300 200" width="300" xmlns="http://www.w3.org/2000/svg"><rect width="300" height="200" rx="18" fill="#1b2452"/><circle cx="236" cy="46" r="24" fill="#f6f0d0"/><path d="M0 118 Q150 104 300 118 V140 H0 Z" fill="#2a4a8a"/><path d="M0 128 q20 -6 40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0 t40 0" stroke="#8ab8ff" stroke-width="3" fill="none"/>'+
  '<path d="M0 140 Q150 128 300 140 V200 H0 Z" fill="#e8d0a0"/><path d="M226 118 L246 118" stroke="#f6f0d0" stroke-width="3" opacity=".5"/>'+
  '<g transform="translate(118 146)"><path d="M0 18 Q4 -10 30 -8 Q52 -6 50 18 Z" fill="#e87a4a" stroke="#26232e" stroke-width="3"/><path d="M8 4 Q26 -4 44 6" stroke="#c8502a" stroke-width="3" fill="none"/><path d="M-4 18 l-10 -10 M-2 12 l-12 -2 M54 18 l10 -10" stroke="#e8423a" stroke-width="4" stroke-linecap="round"/><circle cx="-14" cy="4" r="6" fill="#e8423a" stroke="#26232e" stroke-width="2"/><circle cx="-6" cy="-6" r="3" fill="#26232e"/><circle cx="2" cy="-8" r="3" fill="#26232e"/></g>'+
  '<g transform="translate(176 150) rotate(-8)"><rect x="0" y="0" width="46" height="30" rx="4" fill="#f6e2b0" stroke="#26232e" stroke-width="3"/><circle cx="4" cy="15" r="7" fill="#e8c890" stroke="#26232e" stroke-width="3"/><path d="M12 22 q8 -14 16 -4 t12 -6" stroke="#8a5a2a" stroke-width="2" stroke-dasharray="3 3" fill="none"/><path d="M34 6 l6 6 M40 6 l-6 6" stroke="#e8423a" stroke-width="3"/></g>'+
  '<path d="M170 172 q-14 0 -26 -4" stroke="#c8a870" stroke-width="2" stroke-dasharray="4 4" fill="none"/></svg>';
function goodbye(){const T=X(),left=HW.all().length-HW.nFound();
  story([{art:ps(170),t:`${F()} gives Seb a big hug. "Thank you for being brave with me. Whenever you play Halloween, I'll be right here in the village!"`+(left?` And there are still ${left} Halloween pups hiding on the islands!`:'')},
    {art:BEACH,t:'Later that night, on a moonlit beach far away, a little hermit crab scuttles across the sand... dragging a rolled-up treasure map!'+(window.SB?' Summer Beach Party is here!':' Coming soon: Summer Beach Party!')}],
    ()=>{player.lock=false;T.bye=Date.now();save();MUSIC.over=null;if(window.SB&&SB.fromHw){setTimeout(()=>{try{SB.fromHw();}catch(e){console.warn('sb from hw',e);}},700);return;}say(`Happy Halloween, Seb! ${F()} will stay in the village whenever Halloween is on.`);});}
/* ---------------- the village checks where the story is up to ---------------- */
function village(){const T=HW.G0();if(!T||!T.intro)return false;
  if(T.call&&!T.unmask){say(`${F()} says: "The three-toed footprints go to Number Castle, in the Number Kingdom. Let's go!"`);return true;}
  if(T.unmask&&!T.trail){card({art:big('🎃🚪🍬'),h:'The Trick-or-Treat Trail',p:'Muddle the Friendly Monster is ready to go trick-or-treating round all nine islands. Ready?',btns:[['🍬 Let\'s go!','green',()=>trail()],['Later','white']]});return true;}
  if(T.trail&&!T.done){parade();return true;}
  return false;}
/* ---------------- badges and the certificate ---------------- */
const hs=()=>(state&&state.sx&&state.sx.hw)||{};
MERITS.push(
 {id:'hwpal',icon:'🎃',name:'Brave Buddy',how:'Meet the little pup in the bedsheet in Halloween, and give it a name.',ok:()=>!!hs().pal},
 {id:'hwpick',icon:'🎃',name:'Pumpkin Picker',how:'Pick every pumpkin in the sunflower maze in Halloween.',ok:()=>!!(state.acts||{}).hwpick},
 {id:'hwbones',icon:'🦴',name:'Bone Band',how:'Play the Bone Xylophone at the Skeleton Disco in Halloween.',ok:()=>!!(state.acts||{}).hwbones},
 {id:'hwwatch',icon:'🔦',name:'Night Watch',how:'Collect the 10 glowing numbers in Number Town in Halloween.',ok:()=>!!(state.acts||{}).hwwatch},
 {id:'hwbp',icon:'🐾',name:'Nine Brave Paws',how:'Collect all nine Brave Paws from the unicorns in Halloween.',ok:()=>Object.keys(hs().bp||{}).length>=9},
 {id:'hwall',icon:'🍬',name:'Every Costume Found',how:'Find all 119 Halloween pups.',ok:()=>!!hs().found&&HW.nFound()>=HW.all().length});
CERTS.push({id:'hwhero',icon:'🎃',title:'Halloween Hero',get why(){return `for being brave in the dark with ${hs().pal?hs().pal.name+', the little pup in the bedsheet':'the little pup in the bedsheet'}, and sharing every treat fairly on the Trick-or-Treat Trail`;},ok:()=>!!hs().done});
const css=document.createElement('style');css.textContent=`#htrail{background:#2a1f5a;overflow:hidden}#htSky,#htSky svg{position:absolute;left:0;top:0;width:100%;height:100%}#htrail .btn.rnd{position:absolute;left:14px;top:10px;z-index:20}#htrail .pill{position:absolute;right:14px;top:14px;z-index:20}
#htParty{position:absolute;left:3%;bottom:4%;display:flex;align-items:flex-end;gap:2px;z-index:5}#htParty .htp svg{width:100%;height:auto}#htParty.walk .htp{animation:htWalk .5s ease-in-out infinite alternate}#htParty.walk .htp:nth-child(2n){animation-delay:.25s}
@keyframes htWalk{from{transform:translateY(0)}to{transform:translateY(-10px)}}
#htIsl{position:absolute;right:2%;bottom:2%;width:40%;height:24%;z-index:3}#htIsl .htisl{position:absolute;inset:0;background:#4a3a6a;border-radius:50% 50% 0 0;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;padding-top:8px;color:#fff;font-size:22px}#htIsl .htisl span{font-size:54px}
#htIsl.in .htisl{animation:htIn 2s ease-out}@keyframes htIn{from{transform:translateX(110%)}to{transform:translateX(0)}}
#htDoor{position:absolute;right:13%;bottom:17%;width:150px;height:210px;z-index:4}.htdoor{position:absolute;inset:0;background:#3a2a20;border:6px solid #26232e;border-radius:70px 70px 6px 6px;overflow:hidden}
.htdoor .htdf{position:absolute;inset:0;background:#8a4a2a;border-radius:64px 64px 0 0;transform-origin:left center;transition:transform .6s;z-index:2}.htdoor.open .htdf{transform:perspective(400px) rotateY(-80deg)}.htdoor .htpup{position:absolute;left:6px;right:6px;bottom:4px}.htdoor .htpup svg{width:100%;height:auto}
#htPanel{position:absolute;left:50%;top:118px;transform:translateX(-50%);width:min(900px,92%);z-index:10}.htq{background:#fff3e6;border:5px solid #26232e;border-radius:26px;padding:10px 16px;box-shadow:0 8px 0 rgba(0,0,0,.25)}.htq h2{margin:4px 0 8px;font-size:26px}
.htrow{display:flex;gap:12px;align-items:stretch}.htbask{background:#ffb040;border:4px solid #26232e;border-radius:20px;width:190px;min-height:150px;display:flex;flex-direction:column;align-items:center;justify-content:space-between;cursor:pointer;padding:6px;font-family:inherit}
.htbask small{font-size:15px;font-weight:800}.htpile{display:flex;flex-wrap:wrap;justify-content:center;gap:0;font-size:22px;line-height:1.05}.htbags{flex:1;display:flex;flex-wrap:wrap;gap:6px;justify-content:center}
.htbag{width:78px;display:flex;flex-direction:column;align-items:center;font-size:14px}.htbag .htfr{width:54px;height:54px}.htbag .htfr svg{width:100%;height:100%}.htsack{width:72px;min-height:46px;font-size:17px!important;background:#c8864a;border:3px solid #26232e;border-radius:10px 10px 18px 18px;display:flex;flex-wrap:wrap;justify-content:center;font-size:14px;line-height:1;padding:2px}
.htbag em{font-style:normal;font-weight:900;font-size:22px}.htans{display:flex;gap:12px;justify-content:center;margin-top:8px}.htans .opt{font-size:26px;padding:8px 20px}.htans .opt.on{background:#8ae05a}.htans .opt.no{opacity:.45}.htans .opt.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 5px #ffd23f}`;
document.head.appendChild(css);
window.HSTORY={afterFind,onBrave,village,sneak,trail,parade,goodbye,unmask,curtain,monsterSVG,_tr:()=>TR,_cu:()=>CU};
})();
