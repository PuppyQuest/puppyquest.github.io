/* Puppy Quest 3: 3D helpers and character models (from Puppy Quest 2) */
function angDiff(a,b){let d=(a-b)%(2*Math.PI);if(d>Math.PI)d-=2*Math.PI;if(d<-Math.PI)d+=2*Math.PI;return d;}
const lerpAng=(a,b,k)=>a+angDiff(b,a)*k;
function M(c,basic){const k=(basic?'b':'l')+c;return mats[k]||(mats[k]=basic?new THREE.MeshBasicMaterial({color:c}):new THREE.MeshLambertMaterial({color:c}));}
function mk(g,c,sx,sy,sz,x,y,z,par,basic){const m=new THREE.Mesh(G[g],M(c,basic));m.scale.set(sx,sy,sz);m.position.set(x,y,z);if(par)par.add(m);return m;}
function addInst(g,c,sx,sy,sz,x,y,z,rx,ry,rz,basic){const k=g+c+(basic?'b':'');(instMap[k]||(instMap[k]={g,c,basic,m:[]})).m.push(new THREE.Matrix4().compose(new THREE.Vector3(x,y,z),new THREE.Quaternion().setFromEuler(new THREE.Euler(rx||0,ry||0,rz||0,'YXZ')),new THREE.Vector3(sx,sy,sz)));}
function flushInst(){for(const k in instMap){const o=instMap[k],im=new THREE.InstancedMesh(G[o.g],M(o.c,o.basic),o.m.length);o.m.forEach((m,i)=>im.setMatrixAt(i,m));im.frustumCulled=false;scene.add(im);}}
function emojiTex(ch){if(texC[ch])return texC[ch];const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');x.font='96px serif';x.textAlign='center';x.textBaseline='middle';x.fillText(ch,64,70);return texC[ch]=new THREE.CanvasTexture(c);}
function sprite(ch,s){const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:emojiTex(ch),transparent:true,depthWrite:false}));sp.scale.set(s,s,1);return sp;}
function floatS(ch,x,y,z,s,life){const sp=sprite(ch,s||2.2);sp.position.set(x,y,z);scene.add(sp);W.fl.push({sp,t:0,life:life||1.3});}
/* ----- characters ----- */
let shadowMat=null;
function shadow(par,s){const m=new THREE.Mesh(G.disc,shadowMat);m.scale.set(s,1,s);m.position.y=.04;par.add(m);return m;}
/* ----- joining a model's parts: each moving group keeps its parts, drawn as one or two shapes (rigid skinning) ----- */
const BK={cache:new Map(),skels:new Set(),lam:null,bas:null,v:new THREE.Vector3(),n:new THREE.Vector3(),m:new THREE.Matrix4(),nm:new THREE.Matrix3(),inv:new THREE.Matrix4()};
function bakeKind(m){if(!m.isMesh||m.isSkinnedMesh||!m.visible||m.children.length||m.userData.noBake)return 0;const t=m.material,ge=m.geometry;
  if(!t||Array.isArray(t)||!ge||!ge.attributes||!ge.attributes.position||!ge.attributes.normal||t.transparent||t.map||t.vertexColors||t.side!==THREE.FrontSide||t.opacity<1||t.wireframe)return 0;
  if(t.type==='MeshLambertMaterial')return t.emissive&&(t.emissive.r||t.emissive.g||t.emissive.b)?0:1;if(t.type==='MeshBasicMaterial')return 2;return 0;}
function bakeGeo(list,bi,g,pad){let nv=0,ni=0;list.forEach(m=>{const ge=m.geometry;nv+=ge.attributes.position.count;ni+=ge.index?ge.index.count:ge.attributes.position.count;});
  const pos=new Float32Array(nv*3),nor=new Float32Array(nv*3),col=new Uint8Array(nv*3),si=new Uint8Array(nv*4),sw=new Uint8Array(nv*4),idx=nv>65000?new Uint32Array(ni):new Uint16Array(ni);
  BK.inv.copy(g.matrixWorld).invert();let vo=0,io=0;
  list.forEach(m=>{const ge=m.geometry,P=ge.attributes.position,N=ge.attributes.normal,c=m.material.color,bn=bi.get(m.parent),cr=Math.round(c.r*255),cg=Math.round(c.g*255),cb=Math.round(c.b*255);
    BK.m.multiplyMatrices(BK.inv,m.matrixWorld);BK.nm.getNormalMatrix(BK.m);const flip=BK.m.determinant()<0;
    for(let i=0;i<P.count;i++){const o=(vo+i)*3,o4=(vo+i)*4;BK.v.fromBufferAttribute(P,i).applyMatrix4(BK.m);BK.n.fromBufferAttribute(N,i).applyMatrix3(BK.nm).normalize();
      pos[o]=BK.v.x;pos[o+1]=BK.v.y;pos[o+2]=BK.v.z;nor[o]=BK.n.x;nor[o+1]=BK.n.y;nor[o+2]=BK.n.z;col[o]=cr;col[o+1]=cg;col[o+2]=cb;si[o4]=bn;sw[o4]=255;}
    const I=ge.index?ge.index.array:null,n=I?I.length:P.count;
    for(let i=0;i<n;i+=3){const a=I?I[i]:i,b2=I?I[i+1]:i+1,c2=I?I[i+2]:i+2;idx[io++]=a+vo;if(flip){idx[io++]=c2+vo;idx[io++]=b2+vo;}else{idx[io++]=b2+vo;idx[io++]=c2+vo;}}
    vo+=P.count;});
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));geo.setAttribute('normal',new THREE.BufferAttribute(nor,3));geo.setAttribute('color',new THREE.BufferAttribute(col,3,true));
  geo.setAttribute('skinIndex',new THREE.BufferAttribute(si,4));geo.setAttribute('skinWeight',new THREE.BufferAttribute(sw,4,true));geo.setIndex(new THREE.BufferAttribute(idx,1));
  geo.computeBoundingSphere();geo.boundingSphere.radius+=pad||1.5;return geo;}
function bakeModel(g,key,pad){
  if(!BK.lam){BK.lam=new THREE.MeshLambertMaterial({vertexColors:true,skinning:true});BK.bas=new THREE.MeshBasicMaterial({vertexColors:true,skinning:true});}
  g.updateMatrixWorld(true);const bones=[],bi=new Map(),Ls=[[],[]];
  g.traverse(o=>{const k=bakeKind(o);if(!k)return;const p=o.parent;if(!bi.has(p)){bi.set(p,bones.length);bones.push(p);}Ls[k-1].push(o);});
  const cap=typeof R3!=='undefined'&&R3&&R3.capabilities;if((!Ls[0].length&&!Ls[1].length)||bones.length>250||(cap&&!cap.floatVertexTextures&&bones.length>Math.floor((cap.maxVertexUniforms-20)/4)))return;
  let C=key?BK.cache.get(key):null;
  if(!C||C.nb!==bones.length||C.n0!==Ls[0].length||C.n1!==Ls[1].length){C={nb:bones.length,n0:Ls[0].length,n1:Ls[1].length,geos:Ls.map(l=>l.length?bakeGeo(l,bi,g,pad):null)};if(key)BK.cache.set(key,C);}
  C.t=performance.now();Ls.forEach(l=>l.forEach(m=>m.parent.remove(m)));
  const sk=new THREE.Skeleton(bones);C.geos.forEach((geo,i)=>{if(!geo)return;const sm=new THREE.SkinnedMesh(geo,i?BK.bas:BK.lam);g.add(sm);sm.bind(sk);});
  g.userData.skel=sk;BK.skels.add(g);}
/* free the bone pictures of models no longer in the world, and old joined shapes when there are lots */
function bakeSweep(){if(typeof scene==='undefined'||!scene)return;const live=new Set();scene.traverse(o=>{if(o.isSkinnedMesh)live.add(o.geometry);});
  BK.skels.forEach(g=>{let o=g;while(o.parent)o=o.parent;if(o!==scene){const sk=g.userData.skel;if(sk&&sk.dispose)sk.dispose();BK.skels.delete(g);}});
  if(BK.cache.size>60){const es=[...BK.cache.entries()].sort((a,b)=>a[1].t-b[1].t);for(const [k,C] of es){if(BK.cache.size<=40)break;if(C.geos.some(q=>q&&live.has(q)))continue;C.geos.forEach(q=>q&&q.dispose());BK.cache.delete(k);}}}

/* ----- breed shapes: leg length and snout length (1 = the usual pup) ----- */
const BREED_SHAPE=(()=>{const S={},put=(l,s,n)=>n.split(',').forEach(k=>S[k]=[l,s]);
  put(.7,1.35,'Dachshund,Sausage Dog');put(.72,1.15,'Corgi,Pembroke Welsh Corgi,Swedish Vallhund');put(.72,1.25,'Basset Hound');
  put(.78,1.1,'Lancashire Heeler,Skye Terrier');put(.8,1.3,'Scottish Terrier');put(.82,1.05,'Cairn Terrier,Norfolk Terrier,West Highland Terrier');
  put(.75,.55,'Pekingese,Shih Tzu');put(.8,.7,'Lhasa Apso');put(.72,.55,'British Bulldog');put(.8,.55,'French Bulldog,Pug');put(.85,.6,'Japanese Chin,Brussels Griffon,Affenpinscher');
  put(.88,.8,'Maltese,Havanese,Bichon Frise,Coton de Tulear');put(.9,.75,'Cavalier King Charles Spaniel,Pomeranian');put(.92,.7,'Chihuahua');put(.9,.85,'Yorkshire Terrier,Tibetan Terrier');
  put(1,.62,'Boston Terrier');put(1.05,.7,'Boxer');put(1,.78,'Bullmastiff');put(.95,.8,'Shar Pei,Chow Chow');put(1,.85,'Saint Bernard,St Bernard,Tibetan Mastiff,Newfoundland');
  put(1.4,1.5,'Greyhound,Saluki');put(1.35,1.45,'Whippet,Italian Greyhound,Scottish Deerhound');put(1.35,1.35,'Irish Wolfhound');put(1.35,1.2,'Great Dane');
  put(1.15,1.5,'Rough Collie,Smooth Collie');put(1.05,1.4,'Shetland Sheepdog');put(1.05,1.2,'Border Collie,Australian Shepherd');
  put(1,1.4,'Bull Terrier');put(1.15,1.4,'Bedlington Terrier');put(1.1,1.3,'German Shepherd,Belgian Malinois,White Swiss Shepherd');
  put(1,1.35,'Wire Fox Terrier,Toy Fox Terrier');put(1.15,1.35,'Airedale Terrier');put(1,1.3,'Welsh Terrier,Kerry Blue Terrier');
  put(1.15,1.3,'English Setter,Red Setter,German Shorthaired Pointer,Weimaraner,Vizsla');put(1.1,1.2,'Bracco Italiano,Spinone Italiano,Dalmatian');
  put(1.15,1.2,'Basenji,Thai Ridgeback');put(1.05,1.3,'Bloodhound,Black and Tan Coonhound,Otterhound');put(.95,1.15,'Beagle');
  put(1,1.15,'Labrador,Golden Retriever,Flat-coated Retriever,Curly-coated Retriever,Chesapeake Bay Retriever');
  put(1.05,1.15,'Siberian Husky,Husky,Alaskan Malamute');put(1.25,1.25,'Standard Poodle');put(1.1,1.1,'Chinese Crested');put(.9,1.15,'Jack Russell,Jack Russell Terrier,Border Terrier');put(.9,1.2,'Miniature Schnauzer');
  return S;})();
function breedShape(p,L){if(!p||L.kind||L.limbs!=='paws'||L.upright||L.seal||L.snout!=='dog')return{ll:1,sl:1};const b=BREED_SHAPE[p.breed];return {ll:L.legLen||(b?b[0]:1),sl:L.snoutLen||(b?b[1]:1)};}
function pup3D(p,sparkly){
  const L=Object.assign({},DEF,formLook(p)),g=new THREE.Group(),b=new THREE.Group();g.add(b);if(!G.sphH){G.sphH=new THREE.SphereGeometry(1,18,12);G.sphM=new THREE.SphereGeometry(1,9,6);}
  const BS=breedShape(p,L),ll=BS.ll,sl=BS.sl,lift=(ll-1)*.44,U={ears:[],knees:[],eyes:null,tongue:null,lift:0};
  const FX3=[],acc=L.acc,has=a=>acc.indexOf(a)>=0,fur=L.fur,bodyC=L.body||fur,headC=L.headC||fur,lg=L.long?1.75:1,bw=L.bw/44,hs=L.hw/58,spotC=L.spotC||'#3a3338',SC=k=>L.spotCs?L.spotCs[k%L.spotCs.length]:spotC,SGl=!!L.spotGlow;
  const fin=(legs,h,t,sh)=>{if(sparkly||L.legend){const sp=new THREE.Group();sp.position.y=1;const cs=L.legend?(L.legend==='all'||L.legend==='rainbow'?RBOW:[LT[L.legend].col]):[];for(let i=0;i<(sparkly&&L.legend?10:6);i++){const a=i*Math.PI/(sparkly&&L.legend?5:3),yc=sparkly&&(!L.legend||i%2)?'#ffd23f':cs[i%cs.length];mk('sph',yc,.07,.07,.07,Math.cos(a)*1.15,Math.sin(i*2)*.45,Math.sin(a)*1.15,sp,true);}b.add(sp);g.userData.spk=sp;}
    shadow(g,sh);Object.assign(g.userData,U,{float:L.atom&&L.atom.st==='gas'?.55:0,legs,head:h,tail:t,body:b,extra:FX3,s:L.scale*1.15*(L.legend?1.08:1),ph:Math.random()*6,jump:0,hp:h.position.clone(),noSit:L.limbs==='hooves'||!!(L.atom&&L.atom.st==='gas')});g.scale.setScalar(g.userData.s);
    bakeModel(g,'p|'+(sparkly?1:0)+'|'+ll+'|'+sl+'|'+JSON.stringify(L));if(U.tongue)U.tongue.scale.setScalar(.001);if(U.q&&!g.userData.noSit)g.userData.P=pupPoses(ll,lg,lift);return g;};
  if(L.kind==='octo'){
    const h=new THREE.Group();h.position.set(0,1.02,0);b.add(h);mk('sph',fur,.62,.58,.58,0,0,0,h);mk('sph',L.belly,.4,.3,.3,0,-.22,.3,h);
    [-1,1].forEach(s=>{mk('sph',L.eye,.1,.11,.06,s*.24,.02,.52,h,true);mk('sph','#ffffff',.035,.035,.02,s*.24-.04,.07,.575,h,true);mk('sph','#ff9aa8',.08,.055,.03,s*.4,-.14,.43,h);});
    mk('sph','#ff7fb8',.1,.08,.06,.2,.56,.1,h);mk('sph','#ff7fb8',.1,.08,.06,.4,.5,.1,h);
    const legs=[];for(let i=0;i<8;i++){const a=i*Math.PI/4+.39,l=new THREE.Group(),c=Math.cos(a),s=Math.sin(a);l.position.set(c*.34,.58,s*.34);b.add(l);
      mk('sph',fur,.13,.2,.13,c*.08,-.14,s*.08,l);mk('sph',fur,.11,.14,.11,c*.24,-.36,s*.24,l);mk('sph',fur,.1,.08,.1,c*.42,-.5,s*.42,l);legs.push(l);}
    return fin(legs,h,new THREE.Group(),.8);
  }
  const up=L.limbs==='wings'||!!L.upright,seal=!!L.seal;let hp;
  if(up){mk('sph',bodyC,.48*bw,.54,.44,0,.72,0,b);mk('sph',L.belly,.36*bw,.42,.32,0,.68,.15,b);hp=[0,1.38,.08];}
  else if(seal){mk('sph',bodyC,.46*bw,.4,.92,0,.42,-.15,b);mk('sph',L.belly,.36*bw,.3,.7,0,.34,-.05,b);hp=[0,.95,.6];}
  else{mk('sphH',bodyC,.5*bw,.45,.64*lg,0,.66,0,b);mk('sph',L.belly,.38*bw,.34,.5*lg,0,.56,.1,b);hp=[0,1.2+L.neck*.02,.46*lg+L.neck*.003];if(L.limbs!=='flippers'){U.lift=lift;U.q=true;b.position.y=lift;}
    if(!L.neck)mk('sph',bodyC,.27*Math.max(.85,bw),.27,.27,0,.97,.4*lg,b);}
  if(L.fluffy&&!up&&!seal)mk('sph',fur,.34,.32,.3,0,.84,.38*lg,b);
  if(L.wool)[[.4,.85,.2],[-.4,.85,.2],[.42,.8,-.3],[-.42,.8,-.3],[0,1.02,-.1],[0,.9,-.55]].forEach(q=>mk('sph',bodyC,.26,.24,.26,q[0]*bw,q[1],q[2],b));
  if(L.neck){mk('cyl',fur,.17,L.neck*.02+.3,.17,0,.95+L.neck*.01,.44,b);if(L.spots)[[.14,1.2,.5],[-.14,1.5,.46],[.1,1.75,.52]].forEach((q,k)=>mk('sph',SC(k),.07,.07,.07,q[0],q[1],q[2],b,SGl));}
  const legs=[];
  if(up){const fc=L.feetC||'#ff9a3c';[-1,1].forEach(s=>{const l=new THREE.Group();l.position.set(s*.18,.3,.02);b.add(l);mk('cyl',fc,.05,.3,.05,0,-.14,0,l);mk('sph',fc,.14,.05,.2,0,-.27,.08,l);legs.push(l);});legs.push(legs[0],legs[1]);
    const wc=L.limbs==='flippers'?(L.flipC||bodyC):(L.wingC||bodyC);[-1,1].forEach(s=>{mk('sph',wc,.08,.3,.2,s*.48*bw,.74,0,b).rotation.z=s*.28;});}
  else if(seal)[[-1,.3],[1,.3],[-1,-1],[1,-1]].forEach((q,i)=>{const l=new THREE.Group(),f=i<2;l.position.set(q[0]*(f?.42:.16)*bw,.2,q[1]);b.add(l);mk('sph',L.flipC||bodyC,f?.26:.14,.05,f?.16:.26,q[0]*(f?.14:.06),-.08,0,l);legs.push(l);});
  else{const pc=L.limbs==='hooves'?L.hoofC:(has('mittens')?'#e85d5d':(L.paw||bodyC)),fl=L.limbs==='flippers';
    const LL=.44*(fl?1:ll),la=LL*.5,lb=LL-la;
    [[-1,1],[1,1],[-1,-1],[1,-1]].forEach(q=>{const l=new THREE.Group();l.position.set(q[0]*.26*bw,.44,q[1]*.38*lg);b.add(l);
      if(fl)mk('sph',L.flipC||bodyC,.26,.06,.16,q[0]*.24,-.3,q[1]*.08,l);
      else{const k=new THREE.Group();k.position.set(0,-la,0);l.add(k);mk('cyl',bodyC,.135,la+.06,.135,0,-la/2+.01,0,l);mk('sphM',bodyC,.122,.12,.122,0,0,0,k);mk('cyl',bodyC,.112,lb-.04,.112,0,-(lb-.04)/2,0,k);mk('sph',pc,.16,.1,.21,0,-lb+.04,.05,k);U.knees.push(k);}legs.push(l);});}
  if(L.spots&&!up&&!L.noBodySpots)[[.74,.37,.56],[-.7,.5,-.5],[.3,.9,-.3],[-.5,.62,.6]].forEach((q,k)=>mk('sph',SC(k+2),.09,.09,.09,q[0]*(seal?.46:.5)*bw,(seal?.42:.66)+q[1]*(seal?.4:.45),q[2]*(seal?.8:.64)-(seal?.15:0),b,SGl));
  if(L.bodyPatch){mk('sph',L.bodyPatch,.2,.22,.26,.36*bw,.82,.1,b);mk('sph',L.bodyPatch,.2,.2,.24,-.36*bw,.62,-.26,b);}
  if(L.stripes)[-.32,0,.32].forEach(z=>{const f=Math.sqrt(1-(z/.64)*(z/.64))+.03;mk('ring',L.stripes,.5*bw*f,.45*f,1.4,0,.66,z,b);});
  if(has('shell')){mk('hemi',L.shellC,.6*bw,.62,.74,0,.52,-.02,b);[[0,1.1,0],[.3,.94,.3],[-.3,.94,.3],[.3,.94,-.34],[-.3,.94,-.34]].forEach(q=>mk('sph',L.shellC2,.13,.06,.13,q[0],q[1],q[2],b));}
  if(has('spikes')){mk('hemi',L.spikeC,.56*bw,.6,.7,0,.56,-.08,b);const u3=new THREE.Vector3(0,1,0);for(let i=0;i<18;i++){const a=i*2.4,e=.25+((i*7)%10)/10*1.1,n=new THREE.Vector3(Math.cos(a)*Math.sin(e),Math.cos(e),Math.sin(a)*Math.sin(e)).normalize();if(n.z>.5)continue;mk('cone',L.spikeC,.07,.36,.07,n.x*.56*bw,.56+n.y*.6,-.08+n.z*.7,b).quaternion.setFromUnitVectors(u3,n);}}
  if(has('dwings'))[-1,1].forEach(s=>{mk('cone',L.wingC||'#ffb3d4',.42,.8,.05,s*.56,1.15,-.25,b).rotation.z=-s;});
  if(has('dspikes'))[[1.14,-.12],[1.02,-.42],[.84,-.64]].forEach(q=>mk('cone','#ff8a4c',.08,.24,.08,0,q[0],q[1],b));
  // head
  const h=new THREE.Group();h.position.set(hp[0],hp[1],hp[2]);h.scale.setScalar(hs);b.add(h);
  mk('sphH',headC,.58,.52,.52,0,0,0,h);
  if(L.fluffy){mk('sph',headC,.3,.28,.3,-.42,-.16,.05,h);mk('sph',headC,.3,.28,.3,.42,-.16,.05,h);mk('sph',headC,.34,.26,.34,0,.36,-.02,h);}
  if(has('mane'))for(let i=0;i<9;i++){const a=i*Math.PI*2/9+.35;mk('sph',L.maneC,.24,.24,.2,Math.cos(a)*.52,Math.sin(a)*.46,-.14,h);}
  if(has('rmane'))(L.fire?FIRE:L.elec?ELEC:L.snack===true?SNACKP:RBOW).forEach((c,i)=>mk('sph',c,.16,.16,.16,-.07+(i%2)*.14,.52-i*.17,-.38-(i>2?.05:0),h));
  if(L.face){if(!L.faceLow)[-1,1].forEach(s=>mk('sph',L.face,.25,.27,.2,s*.22,.02,.33,h));mk('sph',L.face,.46,.3,.36,0,-.2,.2,h);}
  if(L.blaze)mk('sph',L.blaze,.1,.34,.3,0,.14,.26,h);
  if(L.patch)(L.patch.side?[L.patch.side]:[-1,1]).forEach(s=>mk('sph',L.patch.c||L.patch,.23,.25,.16,s*.25,.1,.36,h));
  if(L.spots&&!L.spotsBody)[[-.3,.34,.3],[.36,.32,.24],[.55,0,.15],[-.54,.12,-.1],[.05,.5,.05]].forEach((q,k)=>mk('sph',SC(k+3),.1,.1,.1,q[0],q[1],q[2],h,SGl));
  if(L.stripes)[-.15,0,.15].forEach(x=>mk('sph',L.stripes,.035,.11,.06,x,.42-Math.abs(x)*.3,.28,h));
  if(L.brows)[-1,1].forEach(s=>mk('sph',L.brows,.075,.05,.05,s*.2,.25,.43,h));
  const sn=L.snout,cat=sn==='cat';
  let mzD=.2,mzZ=.4,nzZ=.6;if(sn==='dog'){mzD=.2*sl;mzZ=Math.max(.4+.17*(sl-1),.565-mzD);nzZ=mzZ+mzD;}
  if(L.muzzle&&sn!=='trunk')mk('sphH',L.muzzle,L.muzzleBig?.3:(cat?.2:.24),cat?.15:.19,cat?.17:mzD,0,-.14,mzZ,h);
  else if(sn==='dog'&&sl>1.08)mk('sphH',headC,.22,.17,mzD,0,-.12,mzZ,h);
  if(sn==='dog'){const ny=-.07-Math.max(0,sl-1)*.08;mk('sph',L.nose,.085,.06,.06,0,ny,nzZ,h);if(L.tongue)mk('sph',L.tongueC||'#ff8fa3',.06,.03,.1,0,-.27,nzZ-.14,h);
    else if(!L.teeth&&!has('einstein')){const tg=new THREE.Group();tg.position.set(0,-.25,nzZ-.13);h.add(tg);mk('sph',L.tongueC||'#ff8fa3',.075,.035,.12,0,-.03,.06,tg);U.tongue=tg;}}
  else if(cat)mk('sph',L.noseC||'#ff8fa3',.055,.045,.045,0,-.08,.57,h);
  else if(sn==='beak'){const bb=L.beakBig?1.4:1;mk('cone',L.beakC,.11*bb,.28*bb,.1*bb,0,-.1,.6,h).rotation.x=Math.PI/2;}
  else if(sn==='bill')mk('sph',L.beakC,.2,.07,.2,0,-.12,.56,h);
  else if(sn==='pig'){mk('cyl','#ff9eb5',.16,.12,.13,0,-.1,.54,h).rotation.x=Math.PI/2;[-1,1].forEach(s=>mk('sph','#c9607a',.03,.045,.02,s*.06,-.1,.61,h));}
  else if(sn==='cow')[-1,1].forEach(s=>mk('sph',L.nose,.035,.05,.03,s*.1,-.1,.585,h));
  else if(sn==='trunk')[[-.1,.56,.16],[-.3,.66,.14],[-.5,.69,.12],[-.66,.63,.1]].forEach(q=>mk('sph',fur,q[2],q[2],q[2],0,q[0],q[1],h));
  if(L.teeth)mk('box','#ffffff',.07,.07,.02,0,-.24,.55,h);
  [-1,1].forEach(s=>mk('sph','#ff9aa8',.08,.055,.03,s*.36,-.12,.385,h));
  const er=L.eyeR/9.5,ex=.22*L.eyeD/.42,ez=.52*Math.sqrt(Math.max(.05,1-(ex/.58)*(ex/.58)-.018));
  if(L.fringe)mk('sph',L.fringe,.5,.24,.3,0,.14,.32,h);else{const eg=new THREE.Group();eg.position.set(0,.07,0);h.add(eg);U.eyes=eg;[-1,1].forEach(s=>{if(L.eyeWhite)mk('sph','#ffffff',.125*er,.125*er,.06,s*ex,0,ez-.045,eg);mk('sph',L.iris||L.eye,.095*er,.105*er,.06,s*ex,0,ez-.005,eg,true);if(L.iris)mk('sph',L.eye,.05*er,.055*er,.03,s*ex,0,ez+.045,eg,true);mk('sph','#ffffff',.032*er,.032*er,.02,s*ex-.035*er,.045*er,ez+.05,eg,true);});}
  const E=L.ears,es=L.earS,earC=L.ear==='rainbow'?'#ffb3d9':(L.ear||fur);
  const EP=(x,y,z,s,k)=>{const e=new THREE.Group();e.position.set(x,y,z);h.add(e);U.ears.push({g:e,s,k});return e;};
  if(E==='floppy'||E==='long'){const len=E==='long'?(L.earLen?.5:.42):.3;[-1,1].forEach(s=>{const e=EP(s*.5,.17,0,s,1);mk('sph',earC,.13,len,.2,s*.06,-.07-len*.6,0,e).rotation.z=s*.22;});}
  else if(E==='pointy'||E==='bat'){const big=E==='bat',H=big?.56:.4,x=s=>s*(big?.4:.32);[-1,1].forEach(s=>{const e=EP(x(s),(big?.56:.52)-H*.45,0,s,2);e.rotation.z=-s*.25;mk('cone',earC,big?.24:.18,H,.1,0,H*.45,0,e);mk('cone',L.earIn,big?.14:.1,big?.36:.24,.05,0,H*.45-.02,.07,e);});}
  else if(E==='fold')[-1,1].forEach(s=>{mk('cone',earC,.17,.3,.1,s*.44,.36,.06,h).rotation.z=-s*2;});
  else if(E==='pom'){[-1,1].forEach(s=>mk('sph',earC,.24,.24,.24,s*.62,-.02,0,h));mk('sph',earC,.22,.22,.22,0,.56,0,h);}
  else if(E==='round')[-1,1].forEach(s=>{mk('sph',earC,.2*es,.2*es,.1,s*.4,.42,-.02,h);mk('sph',L.earIn,.11*es,.11*es,.05,s*.4,.42,.06,h);});
  else if(E==='roundSide')[-1,1].forEach(s=>{mk('sph',earC,.18,.18,.08,s*.6,.02,0,h);mk('sph',L.earIn,.1,.1,.04,s*.6,.02,.06,h);});
  else if(E==='ele')[-1,1].forEach(s=>{mk('sph',earC,.36,.42,.07,s*.78,.02,-.1,h);mk('sph',L.earIn,.24,.3,.04,s*.78,.02,-.04,h);});
  else if(E==='bunny')[-1,1].forEach(s=>{mk('sph',earC,.11,.38,.07,s*.2,.78,-.02,h).rotation.z=-s*.12;mk('sph',L.earIn,.055,.28,.03,s*.2,.78,.04,h).rotation.z=-s*.12;});
  else if(E==='side'){const bg=L.earBig?1.2:1;[-1,1].forEach(s=>{const e=EP(s*.5,.22,0,s,3);mk('sph',earC,.26*bg,.11*bg,.06,s*.2,-.02,-.02,e).rotation.z=s*.4;mk('sph',L.earIn,.15*bg,.06*bg,.03,s*.2,-.02,.02,e).rotation.z=s*.4;});}
  if(has('gills'))[-1,1].forEach(s=>{for(let i=0;i<3;i++)mk('cone',L.gillC,.06,.4,.06,s*.66,.24-i*.17,-.04,h).rotation.z=-s*(1.15+i*.3);});
  if(has('horns'))[-1,1].forEach(s=>{const n=L.hornS||1,c=mk('cone',L.hornC,.07,.36*n,.07,s*.2,.5+.14*n,-.08,h);c.rotation.z=-s*.25;c.rotation.x=-.35;});
  if(has('antlers'))[-1,1].forEach(s=>{mk('cyl','#c9a070',.03,.34,.03,s*.2,.64,-.02,h);mk('cyl','#c9a070',.025,.16,.025,s*.27,.7,-.02,h).rotation.z=-s*.9;mk('cyl','#c9a070',.025,.14,.025,s*.14,.76,-.02,h).rotation.z=s*.8;});
  if(has('ossicones'))[-1,1].forEach(s=>{mk('cyl',fur,.04,.2,.04,s*.17,.58,0,h);mk('sph','#8a6238',.065,.065,.065,s*.17,.7,0,h);});
  if(has('unihorn'))mk('cone','#ffd86b',.08,.55,.08,0,.72,.16,h).rotation.x=.3;
  if(has('dhorns'))[-1,1].forEach(s=>{mk('cone','#fff3a8',.08,.26,.08,s*.3,.52,-.08,h).rotation.z=-s*.35;});
  if(has('dspikes'))mk('cone','#ff8a4c',.07,.2,.07,0,.58,-.05,h);
  if(has('einstein')){const W1='#f6f5f0',up=new THREE.Vector3(0,1,0);
    [[-1,.14,-.05,.27],[1,.14,-.05,.27],[-.8,.42,-.12,.25],[.8,.42,-.12,.25],[0,.5,-.2,.27],[-.4,.55,-.05,.22],[.4,.55,-.05,.22],[0,.3,-.42,.26]].forEach(q=>mk('sphL',W1,q[3]*1.1,q[3],q[3],q[0]*.6,q[1],q[2],h));
    for(let i=0;i<26;i++){const az=(i*137.5)*Math.PI/180,el=.3+((i*7)%13)/13*1.45,d=new THREE.Vector3(Math.sin(el)*Math.cos(az)*1.35,Math.cos(el)*.9,Math.sin(el)*Math.sin(az)*.8);if(d.z>.3)continue;d.normalize();
      const c=mk('cone',W1,.06,.34+((i*5)%4)*.07,.06,d.x*.72,d.y*.6,d.z*.5,h);const tw=new THREE.Vector3(d.x+Math.sin(i*2.1)*.35,d.y+Math.cos(i*1.7)*.25,d.z).normalize();c.quaternion.setFromUnitVectors(up,tw);c.position.addScaledVector(tw,.14);}
    [-1,1].forEach(s=>{const b2=mk('sph',W1,.13,.06,.07,s*.21,.29,.42,h);b2.rotation.z=-s*.35;mk('sph',W1,.13,.065,.08,s*.11,-.15,.56,h).rotation.z=s*.35;});
    mk('sph','#ff7f98',.075,.15,.04,0,-.34,.55,h).rotation.x=-.25;}
  if(has('tuft')){mk('cone',L.tuftC||headC,.07,.24,.07,0,.6,.04,h);mk('cone',L.tuftC||headC,.05,.18,.05,.1,.56,.04,h).rotation.z=-.5;}
  if(has('grad')){mk('box','#3a3640',.66,.05,.66,0,.56,0,h).rotation.y=.78;mk('sph','#ffd23f',.06,.06,.06,.32,.48,.3,h);}
  if(has('flower')){mk('sph','#ff9ecb',.13,.08,.13,.26,.48,.1,h);mk('sph','#ffd23f',.06,.06,.06,.26,.53,.1,h);}
  if(has('bow')){mk('sph','#ff7fb8',.1,.08,.06,.16,.5,.12,h);mk('sph','#ff7fb8',.1,.08,.06,.36,.48,.12,h);}
  const col=has('scarf')?L.scarfC:(L.collar||(has('daisy')?'#6fcf73':has('shellneck')?'#7fd3f0':has('barrel')?'#8a5326':has('moon')?'#9a86e8':null));
  if(col&&!up&&!seal){const k2=has('scarf')?1.12:1;mk('tor',col,.3*hs*k2,.3*hs*k2,(has('scarf')?.5:.3)*hs,0,.98,.4*lg,b).rotation.x=Math.PI/2-.5;if(has('scarf'))mk('box',col,.13,.36,.06,.17,.74,.4*lg+.3*hs,b);}
  const cz=.4*lg+.27*hs;
  if(!up&&!seal){
  if(has('barrel'))mk('cyl','#c98a4f',.1,.2,.1,0,.82,cz,b).rotation.z=Math.PI/2;
  if(has('daisy'))[-.14,0,.14].forEach(x=>mk('sph','#ffffff',.06,.06,.04,x,.86,cz,b));
  if(has('shellneck'))mk('sph','#ffc2d1',.09,.09,.04,0,.84,cz,b);
  if(has('moon'))mk('sph','#ffe066',.08,.08,.04,0,.84,cz,b,true);
  if(has('ring'))mk('tor','#ff6b6b',.54*bw,.68*lg,.6,0,.66,0,b).rotation.x=Math.PI/2;
  if(has('cap'))mk('hemi','#5b8def',.36,.28,.36,0,.4,0,h);
  if(has('leaves'))[[-.3,.42,.1],[.2,.5,0]].forEach(q=>mk('sph','#6fcf73',.11,.04,.06,q[0],q[1],q[2],h));
  if(has('flake'))mk('sph','#9bdcff',.08,.08,.08,.28,.48,.1,h,true);
  if(has('rainbow'))['#ff8fb3','#ffe066','#7fc8f0'].forEach((c,i)=>mk('sph',c,.07,.07,.07,(i-1)*.16,.54-(i!==1?.04:0),.1,h,true));
  if(has('fireflies'))[[.7,.5,.2],[-.75,.3,.1],[.5,.8,-.2]].forEach(q=>mk('sph','#fff27a',.05,.05,.05,q[0],q[1],q[2],h,true));
  }
  // tail
  const t=new THREE.Group();t.position.set(0,up?.5:seal?.4:.84,up?-.4:seal?-1:-.56*lg);b.add(t);
  const TT=L.tail,tf=L.tailFill==='rainbow'?(L.fire?'#ff9a3c':'#c9b6ff'):(L.tailC||fur);let tip=[0,.48,-.26];
  if(TT==='none')tip=null;
  else if(TT==='curl'){mk('tor',fur,.2,.2,.2,0,.22,-.06,t).rotation.y=Math.PI/2;tip=[0,.42,-.08];}
  else if(TT==='stub'){mk('sph',fur,.12,.12,.12,0,.04,-.08,t);tip=[0,.12,-.12];}
  else if(TT==='plume'||TT==='fox'){const k2=TT==='fox'?1.3:1;mk('sph',tf,.15*k2,.36*k2,.15*k2,0,.26*k2,-.14*k2,t).rotation.x=-.5;tip=[0,.54*k2,-.3*k2];if(L.tailFill==='rainbow')(L.fire?FIRE:L.elec?ELEC:L.snack===true?SNACKP:RBOW).forEach((c,i)=>mk('sph',c,.09,.09,.09,(i%2?.1:-.1),.12+i*.09,-.1-i*.05,t));}
  else if(TT==='bunny'){mk('sph',L.tailTip||fur,.17,.17,.17,0,0,-.08,t);tip=null;}
  else if(TT==='fin'){mk('sph',tf,.05,.3,.46,0,.02,-.36,t);tip=null;}
  else if(TT==='long'){mk('cyl',fur,.045,.8,.045,0,.3,-.2,t).rotation.x=-.6;tip=[0,.64,-.44];}
  else{const th=TT==='wag'?.07:.045;mk('cyl',fur,th,.56,th,0,.24,-.13,t).rotation.x=-.5;if(TT==='pom')mk('sph',fur,.15,.15,.15,tip[0],tip[1],tip[2],t);}
  if(tip){if(L.tailTip&&TT!=='bunny')mk('sph',L.tailTip,TT==='fox'?.15:.1,TT==='fox'?.15:.1,TT==='fox'?.15:.1,tip[0],tip[1],tip[2],t);if(L.tailTuft)mk('sph',L.tailTuft,.11,.11,.11,tip[0],tip[1],tip[2],t);if(has('glow'))mk('sph','#ffe066',.14,.14,.14,tip[0],tip[1],tip[2],t,true);if(has('startail'))mk('sph','#ffe066',.18,.18,.08,tip[0],tip[1]+.06,tip[2],t,true);}
  form3D(L,b,h,{bw,lg,hs,extra:FX3});
  return fin(legs,h,t,.75*bw);
}
/* ----- pup life: sit, lie down, sniff, play bow, roll over, swim, walking on bending legs, blinking, ears, panting, looking at Seb ----- */
const PP={
  stand:{by:0,bp:0,fh:0,fk:0,bh:0,bk:0,hx:0,hd:0,tl:.5,tw:10,ta:0},
  sit:{by:-.05,bp:-.5,fh:.5,fk:0,bh:-1.25,bk:2.05,hx:.45,hd:0,tl:.35,tw:8,ta:.35},
  lie:{by:0,bp:0,fh:-1.45,fk:.05,bh:-1.15,bk:2.25,hx:.05,hd:-.05,tl:.25,tw:6,ta:.55},
  sleep:{by:0,bp:0,fh:-1.45,fk:.05,bh:-1.15,bk:2.25,hx:.45,hd:-.22,tl:0,tw:1,ta:.6},
  sniff:{by:-.02,bp:.1,fh:-.1,fk:.12,bh:-.1,bk:.12,hx:.75,hd:-.12,tl:.28,tw:5,ta:0},
  bow:{by:-.05,bp:.42,fh:-1.05,fk:.25,bh:-.42,bk:0,hx:-.5,hd:0,tl:.7,tw:17,ta:-.55},
  swim:{by:.05,bp:-.12,fh:0,fk:0,bh:0,bk:0,hx:-.2,hd:0,tl:.2,tw:5,ta:0},
  roll:{by:0,bp:0,fh:-.6,fk:.6,bh:-.6,bk:.6,hx:0,hd:0,tl:.25,tw:9,ta:0}};
const PK=['by','bp','fh','fk','bh','bk','hx','hd','tl','tw','ta'];
function pupNext(u){const r=Math.random();if(u.it<1.2)return ['stand',.8+Math.random()];
  if(r<.4)return ['sit',4+Math.random()*5];if(r<.56)return ['sniff',1.8+Math.random()*1.5];if(r<.66)return ['bow',1.3];if(r<.86&&u.it>5)return ['lie',6+Math.random()*8];return ['stand',1.5+Math.random()*2];}
/* sit and play-bow angles worked out for each pup's leg and body length, so paws and bottoms meet the ground */
function pupPoses(ll,lg,lift){const ey=th=>.66*Math.cos(th)-Math.sqrt(Math.pow(.45*Math.cos(th),2)+Math.pow(.64*lg*Math.sin(th),2)),
    paw=th=>-ey(th)+.44*Math.cos(th)+.38*lg*Math.sin(th)-.44*ll-.06;
  let lo=.05,hi=.8;for(let i=0;i<18;i++){const m=(lo+hi)/2;if(paw(m)>0)hi=m;else lo=m;}const th=Math.max(.12,Math.min(.7,(lo+hi)/2));
  const tb=Math.max(.1,Math.min(.75,Math.asin(Math.max(.05,Math.min(.95,(.44*ll-.12)/(.76*lg)))))),byb=.44*ll-(.44*Math.cos(tb)+.38*lg*Math.sin(tb));
  return {sit:Object.assign({},PP.sit,{by:-ey(th)-.02-lift,bp:-th,fh:th,fk:0,bh:-1.35+th,bk:1.95,hx:th*.9}),
    bow:Object.assign({},PP.bow,{by:byb-lift,bp:tb,fh:-1.35-tb,fk:.1,bh:-tb,bk:0,hx:-tb-.25})};}
function pupTrick(g,kind){const u=g.userData;if(u.q&&!u.noSit&&kind==='roll'){u.trick=2.4;u.rs=Math.random()<.5?1:-1;}else u.jump=.6;}
function animPup(g,t,moving){const u=g.userData;if(!u.body)return;const tt=t+u.ph,dt=u.lt==null?.016:Math.max(0,Math.min(.1,t-u.lt));u.lt=t;
  const b=u.body,h=u.head,legs=u.legs,swim=!!(typeof W!=='undefined'&&W.area&&W.area.swim);
  let jy=0;if(u.jump>0){if(!u.j0||u.jump>u.j0)u.j0=u.jump;jy=Math.sin((1-u.jump/u.j0)*Math.PI)*.9*Math.min(1,u.j0/.6+.3);u.jump-=dt;if(u.jump<=0){u.jump=0;u.j0=0;}}
  /* what is the pup doing? */
  let st;if(u.trick>0){u.trick-=dt;st='roll';}
  else if(moving){st=swim?'swim':'walk';u.it=0;u.act=null;u.run=(u.run||0)+dt;}
  else{if(u.run>1.5)u.pant=5;u.run=0;if(u.nap)st='sleep';else if(swim)st='swim';else if(!u.q||u.noSit){st='stand';}else{u.it=(u.it||0)+dt;if(!u.act||u.at<=0){const a=pupNext(u);u.act=a[0];u.at=a[1];}u.at-=dt;st=u.act;}}
  u.pant=(u.pant||0)-dt;
  /* eyes: blink, sleepy, happy */
  if(u.eyes){u.bt=(u.bt==null?1+Math.random()*3:u.bt)-dt;let ey=1;if(u.bt<0){ey=.12;if(u.bt<-.13)u.bt=2.2+Math.random()*3.5;}if(st==='sleep')ey=.1;else if(st==='roll')ey=.4;
    u.ey=u.ey==null?1:u.ey+(ey-u.ey)*Math.min(1,dt*(ey<u.ey?30:12));u.eyes.scale.y=Math.max(.06,u.ey);}
  /* looking at Seb */
  let hy=0;if(st!=='walk'&&st!=='swim'&&st!=='sleep'&&typeof player!=='undefined'&&player.grp){const dx=player.x-g.position.x,dz=player.z-g.position.z;
    if(dx*dx+dz*dz<196)hy=Math.max(-.9,Math.min(.9,angDiff(Math.atan2(dx,dz),g.rotation.y)));else hy=Math.sin(tt*.4)*.5;}
  if(st==='sniff')hy=Math.sin(tt*2.6)*.35;u.hy=(u.hy||0)+(hy-(u.hy||0))*Math.min(1,dt*4);
  if(!u.q){/* birds, seals, octopus and other shapes keep the simple walk */
    const sw=moving?Math.sin(tt*11)*.7:0;legs[0].rotation.x=sw;legs[3].rotation.x=sw;legs[1].rotation.x=-sw;legs[2].rotation.x=-sw;
    let y=moving?Math.abs(Math.sin(tt*11))*.07:0;b.position.y=y+jy+(u.float?u.float+Math.sin(tt*2)*.12:0);
    u.tail.rotation.z=Math.sin(tt*12)*.45;h.rotation.z=Math.sin(tt*1.3)*.07;h.rotation.y=u.hy;
  }else{
    const T=(u.P&&u.P[st])||PP[st==='walk'?'stand':st],c=u.c||(u.c=Object.assign({},PP.stand)),k=Math.min(1,dt*(st==='roll'?9:5));
    for(const key of PK){let v=T[key];if(key==='by'&&(st==='lie'||st==='sleep'))v=-.2-u.lift;c[key]+=(v-c[key])*k;}
    const wv=(moving||st==='swim')?1:0;u.w=(u.w||0)+(wv-(u.w||0))*Math.min(1,dt*6);const w=u.w,ph=tt*(st==='swim'?8:11);
    for(let i=0;i<4;i++){const fr=i<2,sg=(i===0||i===3)?1:-1;let hip=(fr?c.fh:c.bh)+w*sg*Math.sin(ph)*(st==='swim'?(fr?.8:.45):.55),kn=(fr?c.fk:c.bk)+w*Math.max(0,-sg*Math.cos(ph))*.75;
      if(st==='roll'){hip+=Math.sin(tt*13+i*1.7)*.35;kn+=Math.sin(tt*11+i)*.25;}legs[i].rotation.x=hip;if(u.knees[i])u.knees[i].rotation.x=kn;}
    let ra=0;if(st==='roll'){const e=2.4-u.trick,s0=Math.min(1,e/.45,Math.max(0,u.trick)/.45);ra=Math.PI*.9*(s0*s0*(3-2*s0));}
    const ca=Math.cos(ra),cy=.66+u.lift,ty=cy+(.45-cy)*(1-ca)/2;
    b.rotation.x=c.bp;b.rotation.z=ra*(u.rs||1);b.position.x=.66*Math.sin(ra*(u.rs||1));
    b.position.y=(ra?ty-.66*ca:u.lift+c.by)+jy+w*Math.abs(Math.sin(ph))*(st==='swim'?.03:.07)+(st==='sleep'?Math.sin(tt*1.8)*.012:0)+(u.float?u.float+Math.sin(tt*2)*.12:0);
    h.rotation.x=c.hx;h.rotation.y=u.hy;h.rotation.z=st==='sleep'?.12:Math.sin(tt*1.3)*.07;h.position.y=u.hp.y+c.hd;h.position.z=u.hp.z+(st==='sniff'?.06:0);
    u.tp=(u.tp||0)+dt*c.tw;u.tail.rotation.z=Math.sin(u.tp)*c.tl;u.tail.rotation.x=c.ta;
    if(u.ears.length){u.et=(u.et||2)-dt;const tw=u.et<0?(u.et<-.18?(u.et=2+Math.random()*4,0):1):0;
      for(const e of u.ears){const s=e.s;if(e.k===2){e.g.rotation.x=-tw*.35;e.g.rotation.z=-s*(.25+(st==='sniff'?.15:0));}
        else{const fl=w*Math.abs(Math.sin(ph+.6))*(e.k===1?.35:.25)+(jy>.05?.45:0)+(st==='roll'?.5:0);e.g.rotation.z=s*fl;e.g.rotation.x=w*Math.sin(ph*2)*.12+(st==='sniff'?-.25:0);}}}
    if(u.tongue){const want=(u.pant>0||st==='roll'||st==='bow')&&st!=='sleep'?1:.001;u.tg=(u.tg||.001)+(want-(u.tg||.001))*Math.min(1,dt*8);const s=Math.max(.001,u.tg);
      u.tongue.scale.set(s,s*(1+(u.pant>0?Math.sin(tt*15)*.18:0)),s);}
  }
  if(u.spk)u.spk.rotation.y=tt*2;if(u.extra)for(const e of u.extra)e.rotation.y=tt*3;}
function seb3D(){
  if(!G.sphH){G.sphH=new THREE.SphereGeometry(1,18,12);G.sphM=new THREE.SphereGeometry(1,9,6);}if(!G.smile)G.smile=new THREE.TorusGeometry(1,.22,6,14,Math.PI);
  const g=new THREE.Group(),skin='#c9905f',skinD='#b07a4c',hair='#3a2416',gr='#3fae5a',gd='#2e8b47',sh='#7d6a52',shoe='#2f3e5c',G2=(p,x,y,z)=>{const q=new THREE.Group();q.position.set(x,y,z);p.add(q);return q;};
  const pel=G2(g,0,0,0),tor=G2(pel,0,1.05,0),legs=[],knees=[],arms=[],elbows=[];
  [-1,1].forEach(s=>{const l=G2(pel,s*.2,1.05,0);mk('cyl',sh,.175,.34,.175,0,-.13,0,l);mk('cyl',skin,.125,.24,.125,0,-.36,0,l);
    const k=G2(l,0,-.5,0);mk('sphM',skin,.122,.12,.122,0,0,0,k);mk('cyl',skin,.115,.3,.115,0,-.16,0,k);mk('cyl','#ffffff',.128,.11,.128,0,-.32,0,k);
    mk('sph',shoe,.155,.12,.25,0,-.4,.06,k);mk('sph','#f2f2f2',.168,.06,.28,0,-.47,.06,k);mk('sph','#f2f2f2',.11,.07,.08,0,-.42,.26,k);mk('box','#ffffff',.09,.02,.13,0,-.31,.13,k).rotation.x=-.5;
    legs.push(l);knees.push(k);});
  mk('sph',sh,.41,.27,.32,0,.18,0,tor);mk('sphH',gr,.43,.47,.335,0,.62,0,tor);mk('sph',gd,.385,.05,.33,0,.3,0,tor);
  mk('tor',gd,.19,.19,.22,0,1.02,0,tor).rotation.x=Math.PI/2;mk('cyl',skin,.13,.22,.13,0,1.1,0,tor);
  mk('sph','#ffd23f',.09,.09,.03,.17,.8,.31,tor,true);mk('sph','#ffffff',.04,.04,.02,.17,.8,.335,tor,true);
  mk('box',gd,.5,.56,.22,0,.7,-.4,tor);mk('sph',gd,.25,.12,.12,0,.97,-.42,tor);mk('box','#ffd23f',.36,.03,.04,0,.8,-.515,tor);mk('box',shade(gd,-.15),.34,.2,.08,0,.55,-.53,tor);
  [-1,1].forEach(s=>{mk('box',gd,.085,.05,.62,s*.21,1.0,-.04,tor);const st=mk('box',gd,.085,.46,.05,s*.21,.76,.31,tor);st.rotation.x=-.18;});
  [-1,1].forEach(s=>{const a=G2(tor,s*.48,.95,0);mk('sph',gr,.165,.17,.165,0,-.03,0,a);mk('cyl',gr,.14,.2,.14,0,-.13,0,a);mk('cyl',skin,.105,.2,.105,0,-.27,0,a);
    const e=G2(a,0,-.36,0);mk('sphM',skin,.1,.1,.1,0,0,0,e);mk('cyl',skin,.095,.24,.095,0,-.13,0,e);mk('sph',skin,.12,.135,.105,0,-.31,0,e);mk('sph',skin,.045,.075,.05,-s*.075,-.27,.06,e);
    arms.push(a);elbows.push(e);});
  const h=G2(tor,0,1.68,0);
  mk('sphH',skin,.54,.52,.5,0,0,0,h);mk('sph',skin,.47,.34,.43,0,-.15,.05,h);
  [-1,1].forEach(s=>{mk('sph',skin,.1,.13,.07,s*.53,-.05,0,h);mk('sph',skinD,.05,.075,.03,s*.565,-.05,.02,h);});
  mk('sphH',hair,.56,.47,.5,0,.05,-.1,h);[-1,1].forEach(s=>{mk('sph',hair,.12,.2,.14,s*.47,.07,.1,h);mk('sph',hair,.13,.08,.09,s*.33,.13,.36,h);mk('sph',hair,.2,.13,.13,s*.16,-.2,-.4,h);});
  mk('hemi',gr,.61,.5,.61,0,.14,-.02,h);mk('cyl',gd,.62,.05,.62,0,.16,-.02,h);const br=mk('cyl',gd,.35,.05,.32,0,.22,.5,h);br.rotation.x=-.12;mk('sph',gd,.07,.05,.07,0,.64,-.02,h);
  mk('sph','#ffffff',.11,.11,.04,0,.4,.52,h,true);mk('sph','#ffd23f',.05,.05,.02,0,.4,.555,h,true);
  const eg=G2(h,0,-.02,0);[-1,1].forEach(s=>{mk('sph','#2e211c',.078,.098,.05,s*.19,0,.47,eg,true);mk('sph','#ffffff',.03,.03,.02,s*.19-.03,.04,.51,eg,true);mk('sph','#ffffff',.014,.014,.01,s*.19+.025,-.035,.515,eg,true);});
  const bw=G2(h,0,.12,0);[-1,1].forEach(s=>{mk('sph',hair,.085,.028,.04,s*.19,0,.48,bw).rotation.z=-s*.18;});
  mk('sph',skinD,.055,.042,.045,0,-.1,.51,h);[-1,1].forEach(s=>mk('sph','#ff8f8f',.085,.05,.03,s*.33,-.17,.4,h));
  const sm=G2(h,0,-.235,.47);mk('smile','#7a3b2e',.1,.09,.09,0,0,0,sm).rotation.z=Math.PI;
  const om=G2(h,0,-.25,.465);mk('sph','#6b2626',.095,.08,.04,0,0,.01,om);mk('sph','#ff8f8f',.06,.03,.03,0,-.04,.03,om);
  const skis=[-1,1].map(s=>{const m=mk('box','#e8423a',.17,.05,2,s*.2,.03,.3,g);m.visible=false;return m;});shadow(g,.8);
  g.userData={legs,knees,arms,elbows,head:h,tor,pel,eyes:eg,brows:bw,sm,om,skis,c:{}};
  bakeModel(g,'seb',1.6);om.scale.setScalar(.001);return g;}
/* Seb's moves: walking on bending knees and elbows, idle fidgets, blinking, swimming strokes, ski crouch, a happy jump, waving and kneeling to pet */
function animSeb(P,dt,t){const g=P.grp,u=g.userData;if(!u.pel)return;const swim=!!(W.area&&W.area.swim),ski=!!P.ski,mv=P.moving&&!ski;
  if(!(typeof ovOpen==='function'&&ovOpen()))['cheer','wave','pet','wow'].forEach(k=>{P[k]=Math.max(0,(P[k]||0)-dt);});if(mv&&P.pet>0)P.pet=0;
  const w=P.wt*(swim?7:11),c=u.c,K=Math.min(1,dt*10),L=(k,v,r)=>{c[k]=c[k]==null?v:c[k]+(v-c[k])*(r?Math.min(1,dt*r):K);return c[k];};
  c.wk=L('wk',mv&&!swim?1:0,7);const wk=c.wk,cheer=P.cheer>0,kneel=P.pet>0&&!swim&&!ski,wave=P.wave>0&&!cheer&&!kneel;
  /* idle looking about and blinking */
  P.lookT=(P.lookT||0)-dt;if(P.lookT<0){P.lookT=2.5+Math.random()*3;let ly=(Math.random()-.5)*1.1;const f=followers&&followers[0];
    if(f&&Math.random()<.5){ly=Math.max(-.9,Math.min(.9,angDiff(Math.atan2(f.x-P.x,f.z-P.z),P.h)));}P.ly=ly;}
  u.bt=(u.bt==null?2:u.bt)-dt;let ey=1;if(u.bt<0){ey=.1;if(u.bt<-.13)u.bt=2+Math.random()*3.5;}if(cheer)ey=.5;
  /* legs */
  let pelY=0,torX=0,torZ=0,torY=0,headX=0,headY=mv||swim||ski?0:P.ly||0;const hip=[0,0],kn=[.05,.05],shX=[0,0],shZ=[-.1,.1],elX=[-.22,-.22],elZ=[0,0];
  for(let i=0;i<2;i++){const sg=i?-1:1;hip[i]=wk*sg*Math.sin(w)*.62;kn[i]=.05+wk*(.15+Math.max(0,-sg*Math.cos(w))*1.05);shX[i]=-wk*sg*Math.sin(w)*.7+(1-wk)*Math.sin(t*1.6+i)*.03;elX[i]=-.22-wk*(.3+Math.max(0,sg*Math.sin(w))*.3);}
  pelY=-wk*(.02+Math.abs(Math.cos(w))*.03);torX=wk*.1;torY=wk*Math.sin(w)*.1;headY+=-torY*.6;
  if(swim){if(P.moving){for(let i=0;i<2;i++){const sg=i?-1:1;hip[i]=Math.sin(t*14+i*Math.PI)*.3;kn[i]=.25;shX[i]=-((t*5.5+i*Math.PI)%(Math.PI*2));elX[i]=-.25;shZ[i]=sg*-.15;}headX=-.5;}
    else for(let i=0;i<2;i++){const s=i?1:-1;hip[i]=Math.sin(t*4+i*Math.PI)*.35-.2;kn[i]=.5+Math.sin(t*4+i*Math.PI)*.2;shX[i]=0;shZ[i]=s*(1.15+Math.sin(t*3)*.25);elX[i]=-.3;}}
  if(ski){const vx=(P.ski&&P.ski.vx)||0;for(let i=0;i<2;i++){const s=i?1:-1;hip[i]=-.38;kn[i]=.75;shX[i]=-.75;shZ[i]=s*.28;elX[i]=-.55;}pelY=-.08;torX=.28;torZ=Math.max(-.35,Math.min(.35,-vx*.05));}
  if(kneel){const pt=Math.sin(t*9);hip[0]=hip[1]=0;kn[0]=kn[1]=1.57;pelY=-.48;torX=.38;headX=.35;headY=0;shX[1]=-1.05+pt*.18;elX[1]=-.35;shZ[1]=.1;shX[0]=-.35;elX[0]=-.5;}
  if(cheer){for(let i=0;i<2;i++){const s=i?1:-1;shX[i]=0;shZ[i]=s*2.55;elX[i]=-.15;}headX=-.25;}
  if(wave){shX[1]=-.12;shZ[1]=2.55;elX[1]=0;elZ[1]=-.12+Math.sin(t*11)*.38;headX=-.1;}
  const sk=swim&&P.moving;for(let i=0;i<2;i++){const s=i?'1':'0';u.legs[i].rotation.x=L('hp'+s,hip[i]);u.knees[i].rotation.x=L('kn'+s,kn[i]);
    u.arms[i].rotation.x=sk?shX[i]:L('sx'+s,shX[i]);u.arms[i].rotation.z=L('sz'+s,shZ[i],8);u.elbows[i].rotation.x=L('ex'+s,elX[i]);u.elbows[i].rotation.z=wave&&i?elZ[i]:L('ez'+s,0);}
  u.pel.position.y=L('py',pelY,kneel||c.py<-.2?7:12);u.tor.rotation.x=L('tx',torX,6);u.tor.rotation.y=L('ty',torY,8);u.tor.rotation.z=L('tz',torZ,5);u.tor.position.y=1.05+(1-wk)*Math.sin(t*2)*.012;
  u.head.rotation.x=L('hx',headX,6);u.head.rotation.y=L('hy',headY,4);u.head.rotation.z=(1-wk)*Math.sin(t*.9)*.04;
  c.ey=c.ey==null?1:c.ey+(ey-c.ey)*Math.min(1,dt*(ey<c.ey?30:12));u.eyes.scale.y=Math.max(.06,c.ey);
  const mo=cheer||P.wow>0||(kneel&&Math.sin(t*3)>0)?1:0;const m=L('mo',mo,14);u.om.scale.setScalar(Math.max(.001,m));u.sm.scale.setScalar(Math.max(.001,1-m));
  u.brows.position.y=.12+L('bu',cheer||P.wow>0?.05:0,10);
  let jy=0;if(cheer){const e=1.25-P.cheer;if(e<.7)jy=Math.sin(e/.7*Math.PI)*.75;}else if(P.wow>0){const e=.8-P.wow;if(e<.35)jy=Math.sin(e/.35*Math.PI)*.25;}g.position.y+=jy;}
function granny3D(){const g=new THREE.Group();mk('cone','#c8b3f5',.8,2,.8,0,1,0,g);mk('sph','#ffffff',.4,.6,.2,0,.9,.38,g);mk('sph','#ff9ecb',.1,.1,.05,0,1,.57,g);
  [-1,1].forEach(s=>{mk('sph','#c8b3f5',.14,.4,.14,s*.5,1.4,0,g).rotation.z=s*.4;mk('sph','#f0c8a0',.11,.11,.11,s*.66,1.05,0,g);});
  mk('sph','#f0c8a0',.48,.46,.46,0,2.4,0,g);mk('sph','#e6e6ee',.5,.42,.48,0,2.52,-.1,g);mk('sph','#e6e6ee',.22,.22,.22,0,2.95,-.1,g);
  [-1,1].forEach(s=>{mk('sph','#2e211c',.06,.07,.04,s*.17,2.4,.43,g,true);mk('tor','#5b4636',.12,.12,.12,s*.17,2.4,.44,g);mk('sph','#ff8f8f',.07,.05,.03,s*.3,2.27,.36,g);});
  shadow(g,.9);return g;}

/* ----- hiding spots ----- */
function spot3D(kind){const g=new THREE.Group(),m=(a,b,c,d,e,f,gg,hh,i)=>mk(a,b,c,d,e,f,gg,hh,g,i);
  switch(kind){
  case'bush':m('sph','#5fbf5a',1.5,1.3,1.5,0,1,0);m('sph','#6fcf6a',1.1,1,1.1,-1.2,.7,.3);m('sph','#55b350',1.1,1,1.1,1.2,.7,-.2);m('sph','#ff5d6c',.18,.18,.18,.5,1.6,1.1);m('sph','#ff5d6c',.18,.18,.18,-.8,1.1,1.1);break;
  case'flowers':[[-.8,0,'#ff9ecb'],[0,.4,'#fff27a'],[.8,-.1,'#c9b6ff'],[.3,-.7,'#ffffff'],[-.4,.7,'#ff9ecb']].forEach(q=>{m('cyl','#4fae4a',.07,1.6,.07,q[0],.8,q[1]);m('sph',q[2],.36,.3,.36,q[0],1.7,q[1]);});m('sph','#5fbf5a',1.2,.5,1.2,0,.2,0);break;
  case'log':m('cyl','#b9814f',.9,3.2,.9,0,.9,0).rotation.z=Math.PI/2;m('cyl','#5b4636',.6,.1,.6,1.62,.9,0).rotation.z=Math.PI/2;m('sph','#6fcf73',.4,.15,.25,-.4,1.8,.2);break;
  case'rockpool':m('cyl','#7fd3f0',1.6,.2,1.6,0,.25,0,true);for(let k=0;k<7;k++){const a=k*.9;m('sph','#b7bcc9',.6+.2*(k%2),.5,.6,Math.cos(a)*1.8,.3,Math.sin(a)*1.8);}break;
  case'sandcastle':m('box','#f6d58a',2.4,1.2,2.4,0,.6,0);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>m('cyl','#f0c877',.5,2,.5,q[0]*1.1,1,q[1]*1.1));m('cyl','#5b4636',.05,1.4,.05,0,1.9,0);m('box','#ff6b6b',.7,.4,.05,.35,2.4,0);break;
  case'bucket':m('cyl','#ff8a8a',1,1.6,1,0,.8,0);m('cyl','#ffb3b3',1.12,.25,1.12,0,1.6,0);m('sph','#fff27a',.3,.3,.1,0,.9,.98);break;
  case'leafpile':m('sph','#f08c2e',1.6,1,1.6,0,.6,0);m('sph','#e8523a',1,.7,1,-1,.4,.5);m('sph','#ffd23f',1,.7,1,1,.4,-.4);m('sph','#c9532b',.7,.5,.7,.3,1.2,.3);break;
  case'boulder':m('sph','#d99a6c',1.7,1.4,1.5,0,.9,0);m('sph','#5b4636',.7,.7,.3,0,.7,1.3);break;
  case'tent':m('cone','#ffb347',1.9,2.8,1.9,0,1.4,0);m('cone','#5b4636',.7,1.5,.3,0,.75,1.25);break;
  case'drift':m('sph','#ffffff',2,1.1,1.7,0,.3,0);m('sph','#dcecf9',1.1,.8,1.1,1.1,.3,.6);break;
  case'igloo':m('hemi','#eef6fd',1.8,1.7,1.8,0,0,0);m('box','#5b4636',.9,1,.5,0,.5,1.6);break;
  case'pine':m('cyl','#8a5a3a',.25,.8,.25,0,.4,0);m('cone','#5fae8a',1.4,2,1.4,0,1.7,0);m('cone','#5fae8a',1.05,1.6,1.05,0,2.8,0);m('cone','#ffffff',.6,.8,.6,0,3.6,0);break;
  case'mushroom':m('cyl','#fff6e6',.45,1.4,.45,0,.7,0);m('hemi','#ff7fb8',1.5,1.1,1.5,0,1.3,0,true);[[.6,2,.6],[-.7,1.9,.3],[.1,2.25,-.5]].forEach(q=>m('sph','#ffffff',.2,.12,.2,q[0],q[1],q[2],true));break;
  case'stump':m('cyl','#7a5a48',1.1,1.5,1.1,0,.75,0);m('cyl','#b08a6a',1.12,.08,1.12,0,1.52,0);m('box','#2c2440',.7,.9,.3,0,.45,1);break;
  case'fern':for(let k=0;k<7;k++){const a=k*.9,c=m('cone','#3f9a78',.35,2.4,.14,Math.cos(a)*.7,1,Math.sin(a)*.7);c.rotation.z=-Math.cos(a)*.6;c.rotation.x=Math.sin(a)*.6;}m('sph','#fff27a',.12,.12,.12,.5,1.9,.5,true);break;
  case'schoolbag':m('box','#5b8def',2,2.2,1.2,0,1.1,0);m('box','#ffd86b',1.4,.9,.3,0,.8,.7);m('box','#3f6fd0',2.05,.5,1.25,0,2,0);m('tor','#3f6fd0',.5,.5,.5,0,2.5,0);break;
  case'books':m('box','#ff8a8a',2.4,.5,1.8,0,.25,0);m('box','#8fe39a',2.2,.5,1.7,.1,.75,0).rotation.y=.2;m('box','#9bdcff',2,.5,1.6,-.1,1.25,0).rotation.y=-.15;m('box','#ffd86b',1.8,.5,1.5,0,1.75,0).rotation.y=.3;m('sph','#e85d5d',.4,.4,.4,.2,2.35,0);break;
  case'toybox':m('box','#ff9ecb',2.6,1.6,1.8,0,.8,0);m('box','#ffd86b',2.7,.25,1.9,0,1.75,-.3).rotation.x=-.5;m('sph','#8fe39a',.5,.5,.5,-.6,1.9,.2);m('box','#9bdcff',.7,.7,.7,.5,1.9,.3);break;
  case'haybale':m('cyl','#f0d070',1.4,2.2,1.4,0,1.4,0).rotation.z=Math.PI/2;m('cyl','#d9b84f',1.42,.3,1.42,0,1.4,0).rotation.z=Math.PI/2;m('sph','#f0d070',.9,.3,.9,1.2,.2,.8);break;
  case'crate':m('box','#c98a4f',2.2,1.4,1.8,0,.7,0);[[-.6,.3],[0,-.2],[.6,.3],[.1,.5]].forEach(q=>m('sph','#e8423a',.42,.42,.42,q[0],1.55,q[1]));break;
  case'bananas':m('sph','#3fae5c',1.7,.5,1.7,0,.3,0);[[-.5,0,.4],[.2,.3,-.3],[.6,-.3,.5],[-.1,-.5,0]].forEach(q=>{m('sph','#ffd23f',.7,.25,.28,q[0],.9,q[1]).rotation.z=q[2];});m('sph','#58c070',.4,.1,1.3,0,1.3,.6).rotation.x=-.5;break;
  case'crater':{const rg=m('tor','#9aa0ad',1.6,1.6,.9,0,.15,0);rg.rotation.x=Math.PI/2;m('sph','#7d828f',1.4,.25,1.4,0,.05,0);m('sph','#b7bcc9',.5,.4,.5,.4,.3,.2);break;}
  case'meteor':m('sph','#6b5a52',1.5,1.2,1.3,0,.9,0);m('sph','#ff8a3c',.3,.3,.3,.6,1.5,.9,true);m('sph','#ff8a3c',.25,.25,.25,-.7,1.1,.9,true);m('sph','#4a3d3a',.5,.3,.4,-.3,1.8,.6);break;
  case'pod':m('sph','#f4f6fb',1.3,1.1,1.3,0,1,0);m('sph','#9bdcff',.6,.5,.2,0,1.2,1.15,true);m('tor','#e8423a',1.3,1.3,.5,0,.7,0).rotation.x=Math.PI/2;[0,2.1,4.2].forEach(a=>m('cyl','#8f97a8',.08,.9,.08,Math.sin(a)*.9,.25,Math.cos(a)*.9));break;
  case'satellite':m('box','#ffd23f',1.1,1.1,1.1,0,1.2,0);m('box','#5b8def',2,.06,.9,-1.6,1.2,0);m('box','#5b8def',2,.06,.9,1.6,1.2,0);m('cyl','#8f97a8',.08,1.2,.08,0,.6,0);m('hemi','#ffffff',.6,.3,.6,0,1.9,0);m('sph','#e8423a',.12,.12,.12,0,2.3,0,true);break;
  case'alien':[[-.6,0,1.8,'#ff7fb8'],[.5,.3,2.4,'#7fe0d0'],[0,-.6,1.5,'#c9b6ff'],[.7,-.4,1.2,'#fff27a']].forEach(q=>{m('cyl','#3fae5a',.1,q[2],.1,q[0],q[2]/2,q[1]);m('sph',q[3],.42,.42,.42,q[0],q[2]+.2,q[1],true);});m('sph','#2f9a54',1.1,.4,1.1,0,.15,0);break;
  case'crystal':[[0,0,2.6,'#ff9ecb'],[.7,.3,1.8,'#5ce0e6'],[-.6,.4,1.6,'#b58cff'],[.2,-.7,1.3,'#ffffff']].forEach(q=>{const c=m('pyr',q[3],.45,q[2],.45,q[0],q[2]/2,q[1],true);c.rotation.z=q[0]*.3;});m('sph','#c98bb5',1,.3,1,0,.1,0);break;
  case'pollen':{m('sph','#ffd23f',1.5,1.5,1.5,0,1.6,0);for(let k=0;k<14;k++){const th=Math.acos(1-2*(k+.5)/14),ph=k*2.4,d=[-Math.sin(th)*Math.cos(ph),Math.cos(th),Math.sin(th)*Math.sin(ph)];m('cone','#ffb000',.3,.7,.3,d[0]*1.45,1.6+d[1]*1.45,d[2]*1.45).rotation.set(0,ph,th);}break;}
  case'grain':m('sph','#f0dcb0',1.9,1.4,1.6,0,1.2,0);m('sph','#e6c896',1.1,.9,1,.9,1.9,.4);m('sph','#fff8ea',.5,.3,.4,-.6,2.3,.7,true);break;
  case'leaf':{const l=m('sph','#5cb85c',2.3,.35,1.3,0,.9,0);l.rotation.z=.35;m('box','#3f9a46',.12,.1,2.4,0,1.05,0).rotation.set(0,Math.PI/2,.35);const c=m('sph','#4caf50',1.6,.3,1,.6,1.6,.2);c.rotation.z=-.6;m('cyl','#3f9a46',.12,1,.12,-2.2,.5,0).rotation.z=1;break;}
  case'flake':for(let k=0;k<6;k++){const t=k*Math.PI/3;m('box','#d6efff',.3,2.4,.16,Math.sin(t)*1.2,2.6+Math.cos(t)*1.2,0).rotation.z=-t;for(const s of[-1,1]){const tt=t+s*.8;m('box','#eaf6ff',.2,.7,.12,Math.sin(t)*1.6+Math.sin(tt)*.3,2.6+Math.cos(t)*1.6+Math.cos(tt)*.3,0).rotation.z=-tt;}}m('sph','#ffffff',.5,.5,.3,0,2.6,0,true);m('cyl','#c4e6ff',1,.25,1,0,.12,0);break;
  case'bubble':{if(!mats.sbub)mats.sbub=new THREE.MeshLambertMaterial({color:'#cfefff',transparent:true,opacity:.38,depthWrite:false});const bb=new THREE.Mesh(G.sph,mats.sbub);bb.scale.setScalar(2);bb.position.y=2;g.add(bb);m('sph','#ffffff',.45,.28,.22,-.8,3.1,1.3,true);m('sph','#ffffff',.2,.14,.12,-.3,3.5,1.5,true);m('tor','#a8d8f0',1.2,1.2,.6,0,.15,0).rotation.x=Math.PI/2;break;}
  case'ladybug':m('hemi','#e8423a',1.6,1.3,1.9,0,.3,0);m('box','#2a2420',.08,.06,3.6,0,1.62,0);m('sph','#2a2420',.85,.7,.75,0,.8,1.9);[[.7,.5],[-.7,.4],[.8,-.7],[-.7,-.8],[.3,1.2],[-.3,-1.4]].forEach(q=>m('sph','#2a2420',.32,.14,.32,q[0],1.38-Math.abs(q[0])*.2,q[1]));[-1,1].forEach(s=>m('sph','#ffffff',.18,.2,.12,s*.32,1.05,2.5,true));break;
  case'stalagmite':m('cone','#7a6a62',.9,3.2,.9,0,1.6,0);m('cone','#8a7a70',.6,2.2,.6,.9,1.1,.3);m('cone','#6b5a52',.5,1.6,.5,-.8,.8,-.2);m('sph','#5a4a42',1.4,.4,1.4,0,.15,0);m('sph','#9bf0ff',.12,.12,.12,.2,2.4,.5,true);break;
  case'minecart':m('box','#8f97a8',1.6,1.1,2.3,0,1,0);m('box','#3a3640',1.4,.2,2.1,0,1.5,0);[[-.86,.75],[.86,.75],[-.86,-.75],[.86,-.75]].forEach(q=>{const w=m('cyl','#3a3640',.4,.2,.4,q[0],.42,q[1]);w.rotation.z=Math.PI/2;});[['#ff7fb8',-.3,.4],['#5ce0e6',.3,-.3],['#ffd23f',0,.1],['#b58cff',.35,.6]].forEach(q=>m('pyr',q[0],.3,.7,.3,q[1],1.85,q[2],true));break;
  case'sledge':m('box','#e85d5d',1.6,.2,3,0,.7,0);m('box','#8a5a3a',.15,.5,3.2,-.7,.3,0);m('box','#8a5a3a',.15,.5,3.2,.7,.3,0);m('sph','#ffffff',1.3,.7,1.2,0,1.1,-.2);break;
  default:m('sph','#e9defF',1.7,1.2,1.5,0,1,0,true);m('sph','#dccfff',1.2,.9,1.1,-1.3,.7,.2,true);m('sph','#dccfff',1.2,.9,1.1,1.3,.7,-.1,true);}
  return g;}
