/* ================================================================
   Puppy Families (26 Nov 2026, claude/puppy-families-design.md): the core.
   - opens after Spring Blossom is finished (Spring's goodbye leads straight in), or with the grown-ups switch;
   - the basket by the fire in Seb's Den: the buddy's three newborn puppies, which Seb names;
   - Granny Paws and her Pup Book; the Puppy Room door in the Den;
   - families live on the everyday islands (no season picked), so starting Puppy Families goes back to them.
   Save: state.pf = {inv, intro, basket:{pid,at}, fam:{<pupId>:{g:[t,t,t], how, st, c, n, b, bd, at}}, room, ...}
   ================================================================ */
(function(){
const PL=window.PFLOOK,PI=Math.PI;
const S=()=>{if(!state.pf)state.pf={fam:{}};if(!state.pf.fam)state.pf.fam={};return state.pf;};
const S0=()=>(typeof state!=='undefined'&&state&&state.pf)||null;
const spDone=()=>!!(state&&state.sx&&state.sx.sp&&state.sx.sp.done);
const opened=()=>!!(typeof state!=='undefined'&&state)&&(spDone()||!!(state.set&&state.set.pfOpen));
const begun=()=>!!(S0()&&S0().basket);
const P=id=>PUPS[id];
let IDS=null;const famIds=()=>IDS||(IDS=PL.all().map(p=>p.id));
const isFam=id=>famIds().indexOf(id)>=0;
const famOf=id=>{const X=S0();return X&&X.fam&&X.fam[id]||null;};
const got=(id,i)=>{const f=famOf(id);return !!(f&&f.g&&f.g[i]);};
const nGot=id=>{const f=famOf(id);return f&&f.g?f.g.filter(Boolean).length:0;};
const home=id=>nGot(id)>=3;
const homes=()=>famIds().filter(home);
const nPuppies=()=>famIds().reduce((a,id)=>a+nGot(id),0);
const nm=(id,i)=>{const f=famOf(id);return (f&&f.n&&f.n[i])||PL.nameOf(P(id),i);};
const names=id=>[0,1,2].map(i=>nm(id,i));
const girl=(id,i)=>{const f=famOf(id);return f&&f.b&&f.b[i]!=null?!!f.b[i]:PL.girlOf(P(id),i);};
const stg=id=>{const f=famOf(id);return f?(f.st||0):1;};
const list3=a=>`${a[0]}, ${a[1]} and ${a[2]}`;
const basketPid=()=>{const b=state.buddy;if(b&&PUPS[b]&&isFam(b))return b;return 'buttercup';};
const cleanName=s=>{s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,18);return s?s.charAt(0).toUpperCase()+s.slice(1):'';};
/* story art */
const big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`;
const gr=w=>`<div class="fitsvg" style="width:${w||140}px">${grannySVG()}</div>`;
const mg=w=>`<div class="fitsvg" style="width:${w||140}px">${magpieSVG()}</div>`;
const pupArt=(p,w)=>`<div class="fitsvg" style="width:${w||150}px;display:inline-block">${critterSVG(p,{anim:false})}</div>`;
function photo(id,o){o=o||{};const f=famOf(id)||{};return `<div class="pfphoto${o.cls?' '+o.cls:''}"${o.w?` style="width:${o.w}px"`:''}>${PL.famSVG(P(id),o.st!=null?o.st:stg(id),{names:names(id),bd:f.bd,faint:o.faint})}${o.cap!==false?`<div class="pfcap">${o.cap||P(id).name+'\'s family'}</div>`:''}</div>`;}
function basketArt(id,w,awake){const p=P(id),pz=[0,1,2].map(i=>`<div class="pfbz pfbz${i}">${PL.svg(p,i,0,{anim:false})}</div>`).join('');
  return `<div class="pfbasket" style="width:${w||300}px">${pz}<svg class="pfbk" viewBox="0 0 300 120"><path d="M20 30 Q150 70 280 30 L262 104 Q150 124 38 104 Z" fill="#c8925a" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/>`+
    [60,100,140,180,220].map(x=>`<path d="M${x} 44 L${x+6} 108" stroke="#a8743a" stroke-width="4"/>`).join('')+`<path d="M24 34 Q150 76 276 34" stroke="#ffffff" stroke-width="10" fill="none" opacity=".85"/></svg></div>`;}
function bookArt(w){return `<svg viewBox="0 0 220 170" width="${w||220}" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="14" width="180" height="142" rx="14" fill="#8a5a3a" stroke="${INK}" stroke-width="5"/><rect x="34" y="14" width="12" height="142" fill="#6a4228"/>`+
  `<rect x="60" y="34" width="120" height="70" rx="10" fill="#f6e6c8" stroke="${INK}" stroke-width="3"/><text x="120" y="78" text-anchor="middle" font-size="26" font-weight="900" font-family="Arial" fill="#6a4228">Pup Book</text>`+
  [[70,124],[110,132],[150,124]].map(q=>`<g fill="#f6e6c8" opacity=".85"><circle cx="${q[0]}" cy="${q[1]}" r="7"/><circle cx="${q[0]-8}" cy="${q[1]-9}" r="3.4"/><circle cx="${q[0]}" cy="${q[1]-12}" r="3.4"/><circle cx="${q[0]+8}" cy="${q[1]-9}" r="3.4"/></g>`).join('')+`</svg>`;}

/* ---------------- starting Puppy Families ---------------- */
/* families live on the everyday islands: starting puts Seb back on them */
function toEveryday(){if(!state.season)return false;state.season=null;save();try{if(window.XMAS&&XMAS.rebuildPack)XMAS.rebuildPack();}catch(e){}
  Object.values(window.SEASONS||{}).forEach(Q=>{if(Q.hide)try{Q.hide();}catch(e){}});return true;}
function ensureBasket(){const X=S();X.inv=X.inv||1;if(!X.basket){const pid=basketPid(),t=Date.now();X.basket={pid,at:t};X.fam[pid]={g:[t,t,t],how:'basket',st:0,c:0,at:t};}save();}
let SCN=false,WAS=false,FROMSP=false;
function begin(){ensureBasket();WAS=toEveryday()||WAS;player.lock=true;fadeTo(()=>{enterArea('den',[-7,-2,-PI/2],'');setTimeout(basketScene,800);},['🧺','Puppy Families']);}
function fromSp(){FROMSP=true;begin();}
function basketScene(){const X=S();if(SCN||X.intro)return;ensureBasket();SCN=true;player.lock=true;hush();const pid=X.basket.pid,p=P(pid),B=p.name;sfx.yip(1.7);
  story([].concat(FROMSP?[]:[{art:basketArt(pid,300),t:'Back in Seb\'s Den, the basket by the fire wobbles... Seb peeks in. Three tiny puppies, fast asleep, with their eyes shut tight!'}]).concat([
    {art:pupArt(p,130)+basketArt(pid,200),t:`${B} trots over, sniffs the basket, and curls round the puppies with a happy wag. They are ${B}'s puppies, born last night!`},
    {art:big('👀👂👃'),t:`Newborn puppies can't see or hear yet: their eyes and ears are shut. They find ${B} by smell!`}]),
    ()=>nameAll(pid,0,()=>grannyScene(pid)));}
function nameAll(pid,i,done){if(i>2)return done();nameCard(pid,i,()=>nameAll(pid,i+1,done));}
const ORD=['first','second','third'];
function nameCard(pid,i,done){const p=P(pid),f=S().fam[pid],taken=(f.n||[]).slice(0,i),sug=PL.NM[pid].filter(n=>taken.indexOf(n)<0);sfx.chime();
  card({art:`<div class="fitsvg" style="width:170px">${PL.svg(p,i,0,{anim:false})}</div>`,h:`Name the ${ORD[i]} puppy!`,
    p:`This puppy has ${PL.diffText(p,i)}. What shall we call it?<input id="pfName" maxlength="18" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Type a name..."><span class="xSug">${sug.map(s=>`<button class="opt">${s}</button>`).join('')}</span><span class="xSex"><button class="opt${PL.girlOf(p,i)?'':' on'}" data-g="0">👦 Boy</button><button class="opt${PL.girlOf(p,i)?' on':''}" data-g="1">👧 Girl</button></span>`,
    say:`This puppy has ${PL.diffText(p,i)}. Type a name, or pick one. Is it a boy or a girl?`,
    btns:[['✓ That\'s the name!','green',()=>{const n=cleanName($('#pfName').value)||sug[0]||PL.nameOf(p,i),g=+(document.querySelector('#celeCard .xSex .on')||{dataset:{g:0}}).dataset.g;
      f.n=f.n||[];f.b=f.b||[];f.n[i]=n;f.b[i]=g;save();sfx.yip(1.8);confetti(24);speak(n);done();}]]});
  const inp=$('#pfName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .xSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));
  document.querySelectorAll('#celeCard .xSex .opt').forEach(b=>tap(b,()=>{document.querySelectorAll('#celeCard .xSex .opt').forEach(q=>q.classList.toggle('on',q===b));sfx.boop();}));}
function grannyScene(pid){const X=S(),p=P(pid),B=p.name;
  story([{art:gr(140),t:'Knock knock! Granny Paws comes in, carrying a big old book with paw prints on the cover. "Oh, how lovely! Every pup on the islands has a little family now," she says.'},
    {art:bookArt(220),t:'"This is my Pup Book. Every new puppy in Pawprint Village has its photo in it. And tomorrow is the Puppy Parade, when all the new puppies come to the village!"'},
    {art:photo(pid,{w:300}),t:`Click! ${B}'s family goes on the very first page: ${list3(names(pid))}.`},
    {art:big('🚪🐶'),t:`"And look," says Granny, opening a little door in the corner of the Den. "A Puppy Room, all ready! You can look after ${B}'s puppies in there, and they will grow up with your help."`}],
    ()=>{X.intro=Date.now();save();SCN=false;player.lock=false;sfx.fanfare();confetti(40);
      enterArea('den',[player.x,player.z,player.h],'');
      setTimeout(()=>say(`Go through the 🐶 door to the Puppy Room, and look after ${B}'s puppies!`+(WAS?' The puppies live on the islands as they are, so the seasons are switched off for now. Shake the Season Globe in the plaza to visit a season any time.':'')),500);
      if(window.PFSTORY&&PFSTORY.onIntro)try{PFSTORY.onIntro();}catch(e){}});}

/* ---------------- Seb's Den: the hearth, the basket and the Puppy Room door ---------------- */
{const D=AREAS.den,_b=D.build;D.build=function(){_b.apply(this,arguments);if(!opened()&&!begun())return;const X=S0()||{};
  const hx=-13.4,hz=-2.2;I('box','#b8a89a',1.4,3.4,4,hx,1.7,hz);I('box','#8a7a6e',1.5,.4,4.4,hx,3.5,hz);I('box','#3a2a22',.4,1.6,2.2,hx+.6,1,hz);I('box','#c9905f',1.2,.3,1.2,hx+.6,.3,hz);
  const fi=spr('🔥',1.4,hx+.75,1.1,hz);W.ticks.push(()=>{fi.scale.set(1.4+Math.sin(W.t*9)*.08,1.4+Math.sin(W.t*7)*.12,1);});
  const bx=-11,bz=-2.2;I('cyl','#c8925a',1.3,.7,1,bx,.35,bz);I('cyl','#ffffff',1.15,.12,.88,bx,.72,bz);col(bx,bz,1.5);rect(hx-.8,hz-2.2,hx+.8,hz+2.2);
  if(X.basket&&!X.intro){const p=P(X.basket.pid);[0,1,2].forEach(i=>{const g=PL.p3(p,i,0);g.rotation.y=PI*(.4+i*.5);add(g,bx-.45+i*.45,bz+(i===1?.3:-.15),.78);W.ticks.push(()=>PL.anim(g,W.t,false));});
    const z=sprite('💤',.8);z.position.set(bx,2.3,bz);W.ag.add(z);W.ticks.push(()=>{z.position.y=2.1+Math.sin(W.t*1.5)*.2;});}
  if(X.intro){const dx=13.9,dz=6.5;I('box','#ffffff',.25,4.8,3.2,dx,2.4,dz);I('box','#ffd2e6',.3,4.3,2.6,dx-.05,2.15,dz);I('box','#ff9ecb',.32,1.4,1.8,dx-.05,3,dz);I('sph','#ffd23f',.25,.25,.25,dx-.25,2.1,dz-.9);
    const l=label('🐶 Puppy Room',4);l.position.set(dx-.6,5.4,dz);W.ag.add(l);W.things.push({x:12.4,z:dz,r:3.2,icon:'🐶',label:'Puppy Room',act:goRoom});}};}
function goRoom(){if(player.lock)return;sfx.chime();fadeTo(()=>enterArea('pfroom',null,''),['🐶','The Puppy Room']);}
/* the scene starts in the Den if Seb walks in before it has played; the invitation in the village */
const _ea=enterArea;enterArea=function(id,pos,msg){_ea.apply(this,arguments);if(!opened()||!state.intro)return;const X=S0();
  if(id==='den'&&!(X&&X.intro)&&!SCN){setTimeout(()=>{if(cur!=='world'||ovOpen()||SCN||!W.area||W.area.id!=='den'||(S0()&&S0().intro))return;ensureBasket();WAS=toEveryday()||WAS;if(WAS){enterArea('den',[player.x,player.z,player.h],'');}setTimeout(basketScene,WAS?600:0);},900);return;}
  if(id!=='village'||(X&&X.inv))return;
  if(Object.values(window.SEASONS||{}).some(Q=>Q.opened()&&!(state.sx&&state.sx[Q.id]&&state.sx[Q.id].inv)))return;
  setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village'||(S0()&&S0().inv))return;S().inv=1;save();invite();},2100);};
function invite(){player.lock=true;sfx.yip(1.7);
  card({art:big('🧺🐶'),h:'🐶 Something is wriggling!',p:'Come to your Den, Seb. The basket by the fire is wobbling, and something inside is squeaking!',
    btns:[['🏠 To my Den!','green',()=>{player.lock=false;begin();}],['Not now','white',()=>{player.lock=false;say('Visit your Den when you are ready. Something is wriggling in the basket by the fire!');}]]});}
/* the grown-ups switch */
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=$('#setCard');if(!c)return;const Q=state.set;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`🐶 Open Puppy Families early<div class="opts"><button class="opt${Q.pfOpen?'':' on'}" data-x="0">Off</button><button class="opt${Q.pfOpen?' on':''}" data-x="1">On</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=spDone()?'Puppy Families is already open, because Spring Blossom is finished.':'Puppy Families opens after Spring Blossom is finished. Turn this on to open it now: a little note arrives the next time Seb is in the village.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt').forEach(b=>tap(b,()=>{Q.pfOpen=b.dataset.x==='1';save();sfx.boop();const d=openSettings.dirty;openSettings();if(d)openSettings.dirty=d;}));};}

const css=document.createElement('style');css.textContent=`
.pfphoto{display:inline-block;background:#fff;border:3px solid #e6dccb;border-radius:8px;padding:8px 8px 4px;box-shadow:0 5px 0 rgba(0,0,0,.18);transform:rotate(-1.5deg);width:280px;max-width:100%}
.pfphoto svg{width:100%;height:auto;display:block;background:linear-gradient(#e8f6ff,#fff6e6);border-radius:4px}.pfphoto .pfcap{font-size:19px;font-weight:900;color:#6a4228;text-align:center;font-family:'Comic Sans MS','Chalkboard SE',cursive;padding:2px 0}
.pfbasket{position:relative;display:inline-block;height:auto}.pfbasket .pfbk{width:100%;height:auto;display:block;position:relative;z-index:2;margin-top:-30%}
.pfbasket .pfbz{position:relative;display:inline-block;width:33%;z-index:1;vertical-align:bottom}.pfbasket .pfbz svg{width:100%;height:auto;display:block}.pfbz1{margin:0 -4%;}
#celeCard #pfName{display:block;margin:10px auto;font-size:30px;padding:8px 14px;border-radius:14px;border:4px solid #8fd0ff;width:70%;text-align:center;font-family:inherit}`;
document.head.appendChild(css);

window.PF={S,S0,opened,begun,spDone,P,famIds,isFam,famOf,got,nGot,home,homes,nPuppies,nm,names,girl,stg,list3,photo,basketArt,bookArt,pupArt,big,gr,mg,begin,fromSp,goRoom,toEveryday,cleanName};
})();
