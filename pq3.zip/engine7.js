/* ================================================================
   Seb's Puppy Quest 3: Release 7 engine pieces.
   - gate looks: gap (a Sky pup floats a bridge across) and fog (a Star
     pup shines the way)
   - props: robot, fire engine, lighthouse, crane, rocket, conveyor,
     Seb's home-made flying machine, buoys, lobster pots
   - enrich() styles: gadget (metal bits, gears, crates) and coast
   ================================================================ */
GATE_LOOKS.gap=function(blk,grow){mk('box','#3a3338',7,.4,4.4,0,-.6,0,blk);[-3.2,3.2].forEach(s=>mk('box','#8a8f99',.5,1.4,4.4,s,.2,0,blk));mk('box','#ffd23f',6,.25,.25,0,1.2,2.1,blk);mk('box','#26232e',6,.25,.25,0,1.2,2.4,blk);
  for(let i=0;i<5;i++)mk('box','#c9905f',1.3,.2,4.2,-2.6+i*1.3,.25,0,grow);[-1.8,1.8].forEach(z=>mk('box','#9b6a43',6.4,.15,.15,0,.9,z,grow));for(let i=0;i<3;i++){const b=mk('sph',['#ff6b6b','#7fc8f0','#ffd23f'][i],.5,.6,.5,-2+i*2,3.4,0,grow);mk('cyl','#ffffff',.02,2.4,.02,-2+i*2,2.1,0,grow);}};
GATE_LOOKS.fog=function(blk,grow){for(let i=0;i<9;i++)mk('sph','#dfe6ee',1.6+(i%3)*.4,1.4+(i%2)*.4,1.4,-3+(i%5)*1.5,1+Math.floor(i/5)*1.6,(i%2)*.6-.3,blk);
  [-2.6,2.6].forEach(s=>{mk('cyl','#3a3338',.15,4,.15,s,2,1.2,grow);mk('box','#fff27a',.7,.7,.7,s,4.2,1.2,grow);const g=mk('cone','#fff6a0',1.2,3,1.2,s,2.4,1.2,grow);g.rotation.x=Math.PI;g.material=new THREE.MeshBasicMaterial({color:'#fff6a0',transparent:true,opacity:.35});W.disp.push(g.material);});};

/* ----------------- props ----------------- */
function robot3D(c,s){c=c||'#8a8f99';s=s||1;const g=grp();mk('box',c,1.4*s,1.6*s,1*s,0,1.6*s,0,g);mk('box','#c9c2b8',1*s,.8*s,.8*s,0,2.9*s,0,g);mk('box','#26232e',.8*s,.3*s,.1*s,0,3*s,.41*s,g);
  [-.2,.2].forEach(q=>mk('sph','#7fffe0',.1*s,.1*s,.05*s,q*s,3*s,.46*s,g));mk('cyl','#8a8f99',.04*s,.6*s,.04*s,0,3.6*s,0,g);mk('sph','#e8423a',.12*s,.12*s,.12*s,0,3.95*s,0,g);
  [-1,1].forEach(q=>{mk('cyl',c,.15*s,1*s,.15*s,q*.85*s,1.7*s,0,g).rotation.z=q*.3;mk('cyl','#5b6378',.2*s,.8*s,.2*s,q*.35*s,.4*s,0,g);});mk('box','#ffd23f',.5*s,.3*s,.05*s,0,1.8*s,.51*s,g);return g;}
function fireEngine3D(){const g=grp();mk('box','#e8423a',2.6,1.6,6,0,1.3,0,g);mk('box','#e8423a',2.6,1.2,2,0,2.6,2,g);mk('box','#9bdcff',2.4,.8,.1,0,2.7,3.01,g);mk('box','#c9c2b8',2.7,.3,6.1,0,.55,0,g);
  mk('box','#c9c2b8',.5,.2,5,-.7,2.3,-1,g);mk('box','#c9c2b8',.5,.2,5,.7,2.3,-1,g);for(let i=0;i<9;i++)mk('box','#c9c2b8',1.6,.12,.12,0,2.36,-3.3+i*.55,g);mk('cyl','#ffd23f',.18,.2,.18,-.9,3.3,2.2,g);mk('cyl','#3d8fe0',.18,.2,.18,.9,3.3,2.2,g);
  [[-1.3,-1.8],[1.3,-1.8],[-1.3,1.9],[1.3,1.9]].forEach(q=>mk('cyl','#26232e',.6,.4,.6,q[0],.6,q[1],g).rotation.z=Math.PI/2);mk('cyl','#ffd23f',.5,.3,.5,1.35,1.4,-1,g).rotation.z=Math.PI/2;mk('box','#ffffff',.05,.5,2.4,1.31,1.6,0,g);return g;}
function lighthouse(x,z,s){s=s||1;const y=gy(x,z);for(let i=0;i<6;i++)I('cyl',i%2?'#ffffff':'#e8423a',(2.2-i*.18)*s,2.2*s,(2.2-i*.18)*s,x,y+1.1*s+i*2.2*s,z);
  I('cyl','#3a3338',1.4*s,.4*s,1.4*s,x,y+13.4*s,z);I('cyl','#fff6a0',1*s,1.6*s,1*s,x,y+14.4*s,z,0,0,0,true);I('cone','#e8423a',1.4*s,1.4*s,1.4*s,x,y+15.9*s,z);
  const beam=new THREE.Mesh(G.cone,new THREE.MeshBasicMaterial({color:'#fff6a0',transparent:true,opacity:.25}));W.disp.push(beam.material);beam.scale.set(2.4*s,16*s,2.4*s);beam.rotation.z=Math.PI/2;const bg=grp();bg.add(beam);beam.position.x=8*s;bg.position.set(x,y+14.4*s,z);W.ag.add(bg);W.ticks.push(dt=>{bg.rotation.y+=dt*.6;});
  col(x,z,2.3*s);camBlock(x-2.2*s,z-2.2*s,x+2.2*s,z+2.2*s);}
function crane(x,z,rot){const y=gy(x,z),g=grp();for(let i=0;i<6;i++){mk('box','#ffd23f',.8,2,.8,0,1+i*2,0,g);mk('box','#26232e',.9,.1,.9,0,2+i*2,0,g);}const arm=grp();mk('box','#ffd23f',12,.6,.6,3,0,0,arm);mk('box','#8a8f99',2,1.2,1.2,-3.5,-.2,0,arm);mk('cyl','#26232e',.03,4,.03,8,-2,0,arm);mk('box','#e8423a',1,.8,1,8,-4.2,0,arm);arm.position.y=12.4;g.add(arm);
  g.rotation.y=rot||0;add(g,x,z,y);W.ticks.push(()=>{arm.rotation.y=Math.sin(W.t*.2)*.8;});col(x,z,.9);}
function rocket3D(c,s){s=s||1;const g=grp();mk('cyl','#ffffff',.8*s,5*s,.8*s,0,3*s,0,g);mk('cone',c||'#e8423a',.8*s,1.8*s,.8*s,0,6.4*s,0,g);mk('cyl','#9bdcff',.35*s,.12*s,.35*s,0,4.2*s,.75*s,g).rotation.x=Math.PI/2;
  [0,2.09,4.19].forEach(a=>{const f=mk('box',c||'#e8423a',.12*s,1.6*s,1.2*s,Math.cos(a)*.85*s,1.2*s,Math.sin(a)*.85*s,g);f.rotation.y=-a;});mk('cone','#ff8a3c',.5*s,.8*s,.5*s,0,.3*s,0,g).rotation.x=Math.PI;return g;}
function conveyor(x,z,len,rot){const y=gy(x,z),g=grp();mk('box','#3a3338',len,.3,2,0,1.2,0,g);for(let i=0;i<Math.floor(len/2);i++)mk('cyl','#8a8f99',.12,1,.12,-len/2+1+i*2,.6,.8,g),mk('cyl','#8a8f99',.12,1,.12,-len/2+1+i*2,.6,-.8,g);
  const boxes=[];for(let i=0;i<4;i++){const b=mk('box',['#c9905f','#7fc8f0','#ffd23f','#8fe39a'][i],.8,.7,.8,0,1.7,0,g);boxes.push(b);}g.rotation.y=rot||0;add(g,x,z,y);
  W.ticks.push(()=>boxes.forEach((b,i)=>{b.position.x=-len/2+((W.t*1.2+i*len/4)%len);}));rect(x-(Math.abs(Math.cos(rot||0))*len/2+Math.abs(Math.sin(rot||0)))-.2,z-(Math.abs(Math.sin(rot||0))*len/2+Math.abs(Math.cos(rot||0)))-.2,x+(Math.abs(Math.cos(rot||0))*len/2+Math.abs(Math.sin(rot||0)))+.2,z+(Math.abs(Math.sin(rot||0))*len/2+Math.abs(Math.cos(rot||0)))+.2);}
function gearSpin(x,y,z,r,c,rot,spd){const g=grp();mk('cyl',c||'#c9a86a',r,.3,r,0,0,0,g).rotation.x=Math.PI/2;for(let i=0;i<10;i++){const a=i/10*6.283;const t=mk('box',c||'#c9a86a',.35*r,.3*r,.3,Math.cos(a)*r*1.05,Math.sin(a)*r*1.05,0,g);t.rotation.z=a;}mk('cyl','#5b4636',r*.25,.4,r*.25,0,0,0,g).rotation.x=Math.PI/2;
  g.position.set(x,y,z);g.rotation.y=rot||0;W.ag.add(g);W.ticks.push(dt=>{g.rotation.z+=dt*(spd||.6);});return g;}
/* Seb's home-made flying machine: a crate cockpit, flapping wings, an umbrella and a propeller */
function flyMachine3D(){const g=grp();mk('box','#c9905f',2.4,1.4,2,0,1,0,g);mk('box','#9b6a43',2.5,.2,2.1,0,1.75,0,g);for(let i=0;i<3;i++)mk('box','#9b6a43',.1,1.4,2.05,-1+i,1,0,g);
  const wings=[-1,1].map(q=>{const w=grp();mk('box','#fff2b8',3.6,.08,1.6,q*1.8,0,0,w);for(let i=0;i<4;i++)mk('box','#9b6a43',.06,.1,1.6,q*(.4+i*.9),.05,0,w);w.position.set(q*1.1,1.6,0);g.add(w);return w;});
  mk('cyl','#5b4636',.06,2.6,.06,0,3,0,g);mk('cone','#3fae5a',1.8,.9,1.8,0,4.3,0,g);for(let i=0;i<8;i++){const a=i/8*6.283;mk('sph',i%2?'#3fae5a':'#ffd23f',.1,.1,.1,Math.cos(a)*1.75,3.9,Math.sin(a)*1.75,g);}
  const prop=grp();mk('box','#e8423a',2.2,.12,.3,0,0,0,prop);mk('box','#e8423a',.3,.12,2.2,0,0,0,prop);prop.position.set(0,4.9,0);g.add(prop);mk('cyl','#26232e',.4,.3,.4,0,.3,0,g);
  [-1,1].forEach(q=>mk('cyl','#26232e',.45,.15,.45,q*.9,.2,1.1,g).rotation.z=Math.PI/2);const fl=mk('box','#e8423a',.6,.4,.03,.6,2.5,1.03,g);
  g.userData.tick=t=>{prop.rotation.y=t*12;wings.forEach((w,i)=>{w.rotation.z=(i?-1:1)*Math.sin(t*5)*.25;});};return g;}
function buoy(x,z,c){const y=gy(x,z);I('cyl',c||'#e8423a',.5,1.2,.5,x,y+.6,z);I('cyl','#ffffff',.52,.3,.52,x,y+.7,z);I('cone',c||'#e8423a',.4,.6,.4,x,y+1.5,z);col(x,z,.6);}
function lobsterPot(x,z){const y=gy(x,z);I('cyl','#9b6a43',.6,.8,.6,x,y+.4,z,0,0,Math.PI/2);for(let i=0;i<4;i++)I('tor','#c9a86a',.42,.42,.42,x-.3+i*.2,y+.45,z,0,Math.PI/2,0);col(x,z,.7);}
function lifeRing(x,z,y,rot){I('tor','#ff6b6b',.6,.6,.6,x,(y==null?gy(x,z)+1.2:y),z,0,rot||0,0);}

/* ----------------- enrich styles: gadget and coast ----------------- */
(function(){const base=enrich;enrich=function(A){if(!A||A.noEnrich||(A.biome!=='gadget'&&A.biome!=='coast'))return base(A);
  const R=seed(A.id.length*977+13),Rn=R,ar=A.rect?(A.rect.x2-A.rect.x1)*(A.rect.z2-A.rect.z1):Math.PI*(A.R||40)*(A.R||40),k=Math.min(2.4,ar/9000),n=v=>Math.round(v*k);
  const spot=(clr,edge,minC,stC)=>{for(let t=0;t<30;t++){const a=R()*6.283,rr=(A.R||40)*(.2+R()*.72),x=Math.cos(a)*rr,z=Math.sin(a)*rr;if(A.keepOut&&A.keepOut(x,z))continue;
    if(W.cols.some(c=>Math.hypot(x-c.x,z-c.z)<c.r+clr))continue;if(W.rects.some(r=>x>r.x1-clr&&x<r.x2+clr&&z>r.z1-clr&&z<r.z2+clr))continue;if(W.spots.some(s=>Math.hypot(x-s.x,z-s.z)<(minC||4)))continue;
    if(W.things.some(t2=>Math.hypot(x-t2.x,z-t2.z)<(t2.r||4)))continue;if(W.exits.some(e=>Math.hypot(x-e.x,z-e.z)<9))continue;const st=A.start||[0,0];if(Math.hypot(x-st[0],z-st[1])<(stC||5))continue;return [x,z];}return null;};
  for(let i=0;i<n(180);i++){const p=spot(.2,0,5);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('coneL',A.biome==='coast'?pick(['#8fbf5a','#a8c86a','#c9c27a']):pick(['#5fae4a','#4f9e3a','#6fbf5a']),.08,.45+Rn()*.4,.08,p[0]+j*.15,y+.22,p[1]+(j%2)*.12,(j-1)*.3,0,(j-1)*.2);}
  for(let i=0;i<n(18);i++){const p=spot(1,3);if(p)flowerPatch(p[0],p[1],5+Math.round(Rn()*5),1.4,[pick(A.biome==='coast'?['#ff9ecb','#ffffff','#ffd23f','#c9b6ff']:['#ffd23f','#ff6b6b','#7fc8f0'])],Rn);}
  for(let i=0;i<n(10);i++){const p=spot(.7,3);if(p){const y=gy(p[0],p[1]);I('sphL',pick(['#9a9488','#b7bcc9','#8a8378']),.5+Rn()*.6,.35,.45,p[0],y+.12,p[1],0,Rn()*3,0);}}
  if(A.biome==='gadget'){
    for(let i=0;i<n(10);i++){const p=spot(.9,3);if(!p)continue;const y=gy(p[0],p[1]);if(Rn()<.5){I('box','#c9905f',1.1,1.1,1.1,p[0],y+.55,p[1],0,Rn()*3,0);I('box','#9b6a43',1.12,.12,1.12,p[0],y+.55,p[1],0,Rn()*3,0);}else{I('cyl',pick(['#3d8fe0','#e8423a','#3fae5a']),.5,1.2,.5,p[0],y+.6,p[1]);I('cyl','#26232e',.52,.1,.52,p[0],y+.9,p[1]);}col(p[0],p[1],.7);}
    for(let i=0;i<n(12);i++){const p=spot(.5,3);if(!p)continue;const y=gy(p[0],p[1]);I('tor',pick(['#c9a86a','#8a8f99']),.35,.35,.35,p[0],y+.08,p[1],Math.PI/2,0,0);I('cylL','#8a8f99',.06,.5,.06,p[0]+.6,y+.05,p[1],0,0,Math.PI/2);}
    for(let i=0;i<n(5);i++){const p=spot(.8,4);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#8a8f99',.12,3,.12,p[0],y+1.5,p[1]);I('box','#ffd23f',.7,.7,.3,p[0],y+3,p[1],0,0,Math.PI/4);col(p[0],p[1],.4);}
    for(let i=0;i<n(4);i++){const p=spot(1.8,5,4,14);if(p)tree(p[0],p[1],.9+Rn()*.3,pick(['#5fbf5a','#7fcf6a']));}
    butterflies(Math.max(3,n(5)),0,0,(A.R||40)*.6);birds(2,24,A.R||40);}
  else{
    for(let i=0;i<n(8);i++){const p=spot(.8,4);if(!p)continue;if(Rn()<.5)lobsterPot(p[0],p[1]);else buoy(p[0],p[1],pick(['#e8423a','#ffd23f','#3d8fe0']));}
    for(let i=0;i<n(10);i++){const p=spot(.5,3);if(!p)continue;spr(pick(['🐚','🦀','🐚']),.7,p[0],gy(p[0],p[1])+.35,p[1]);}
    for(let i=0;i<n(5);i++){const p=spot(1.4,4);if(p)bush(p[0],p[1],.7+Rn()*.4,pick(['#5fbf5a','#7fa858','#8fbf5a']),Rn()<.4?'#ff9ecb':null);}
    for(let i=0;i<n(3);i++){const p=spot(1.8,5,4,14);if(p)tree(p[0],p[1],.9+Rn()*.3,pick(['#4fae4a','#5fbf5a']),'pine');}
    const gulls=[0,1,2].map(()=>{const s=sprite('🕊️',1.3);W.ag.add(s);return s;});W.ticks.push(()=>gulls.forEach((s,i)=>{const a=W.t*.25+i*2;s.position.set(Math.cos(a)*30,16+i,Math.sin(a)*24);}));}
};})();
