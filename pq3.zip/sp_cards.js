/* ================================================================
   Spring Blossom: the spring cards (26 Nov 2026, claude/spring-blossom-design.md section 11)
   - a card for each of the 119 spring pups, the duckling (Season Friend) and the nine unicorns in
     flower crowns; on the Seasons shelf, one tab per island plus a 🌸 tab for the duckling, Primrose and Tulip;
   - stats and powers as on the main card (the saga's fixed scale); the everyday move gets a spring name;
   - the island's scene in spring, a petal and painted egg frame, a blossom badge, a blossom branch edge,
     and the spring-only Petal finish (cardlook.js rolls it, letter p);
   - packs per area, fresh green with a ribbon and a flower; the Pup House and binder spring look.
   Hooks: window.XCARDS, window.SEALOOK['p:'], window.SEAPACK.p_, CLOOK.EDGE.sp.
   ================================================================ */
(function(){
const SR=window.SPRING,SL=window.SPLOOK,sp=SL.sp,X=()=>(state&&state.sx&&state.sx.sp)||{};
const SMOVE={herd:'Bunny Hop',pull:'Bunny Hop',snow:'Bunny Hop',tug:'Bunny Hop',rescue:'Bunny Hop',dig:'Egg Roll',giant:'Egg Roll',guard:'Egg Roll',sniff:'Petal Twirl',point:'Petal Twirl',truffle:'Petal Twirl',wiggle:'Petal Twirl',
 zoom:'Puddle Jump',spots:'Puddle Jump',splash:'Puddle Jump',fetch:'Blossom Burst',rainbow:'Blossom Burst',cloud:'Blossom Burst',yodel:'Sunny Sprout',snore:'Sunny Sprout',cuddle:'Sunny Sprout'};
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const HOW={nest:'🪺 Found in a nest of painted eggs',bush:'🌸 Found peeking out of a blossom bush',flower:'🌷 Found inside a giant flower bud'};
const dstr=d=>d&&d>1e12?new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'';
const TM={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const hs=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;},cp=(v,a,b)=>Math.max(a,Math.min(b,v));
function scard(p,set,n,of,isl){const C=window.CARDS,B=C.breedOf(p.breed),T=C.TY(p.type),z=SZ[B.sz]||SZ.m,sh=p.shiny||p.season?10:0,st={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  st[C.STATS[hs(p.id)%4][0]]+=1;for(const k in st)st[k]=cp(st[k],1,10);
  const c={stats:st,zoom:cp(z[0]+sh,30,120),moves:[[SMOVE[B.g]||'Puddle Jump',1,z[1]],[TM[p.type]||'Pup Power',2,z[2]+sh]],col:T.col,bg:shade(T.col,.72)};
  Object.assign(c,{cid:'3:sp_'+p.id,game:3,set,n,of,src:p,base:p.id,name:p.name,breed:p.breed,type:p.type,rar:p.shiny||p.season?'sparkly':'common',fact:SL.FACT[p.id]||p.fact||'',sp:true,pisl:isl});
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return p.id==='tulip'?'the Blossom Festival, Pawprint Village':(A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>SR.xFound(p.id);c.foundAt=()=>{const v=(X().found||{})[p.id];return typeof v==='number'?v:0;};
  c.art=an=>critterSVG(sp(p),{anim:an,sparkly:!!(p.shiny||p.season)});
  c.hint=()=>SR.opened()?`${p.name} is hiding in ${AREAS[p.area]?AREAS[p.area].name:'the village'} in spring. ${p.hint||''}`:'Spring Blossom opens after Summer Beach Party is finished!';
  c.back=()=>{const d=c.foundAt(),h=(X().how||{})[p.id];return [`🌸 Found in spring${d?' on '+dstr(d):''}`,`📍 ${c.home()}`,HOW[h]||'🌸 Found at the Blossom Festival','🌷 Ready for the Blossom Festival'];};
  return c;}
function unicard(I,set,n,of){const u=I.boss.uni,C=window.CARDS,T=C.TY(I.type);const c={cid:'3:sp_'+u.id,game:3,set,n,of,src:u,base:u.id,name:u.name,breed:u.breed,type:I.type,rar:'unicorn',uni:true,sp:true,pisl:I.id,
  fact:`${u.name}'s spring lesson: ${SR.LESSON[u.id]||'Friends help each other grow.'}`,zoom:120,moves:[['Rainbow Gallop',1,30],['Blossom Bud',3,100]],col:T.col,bg:'#f0fff0',stats:{spd:9,brn:9,cud:10,brv:9}};
  c.home=()=>I.name;c.earned=()=>!!(X().bb||{})[I.id];c.foundAt=()=>(X().bb||{})[I.id]||0;c.art=an=>critterSVG(sp(u),{anim:an});
  c.hint=()=>`Find ${SR.NEED} spring pups on ${I.name}, and ${u.name} will give your duckling a blossom bud.`;
  c.back=()=>{const d=c.foundAt();return [`🌸 Gave a blossom bud${d?' on '+dstr(d):''}`,`🦄 ${I.name}`,`💬 ${SR.LESSON[u.id]||''}`];};return c;}
function palcard(set,n,of){const c={cid:'3:sp_pal',game:3,set,n,of,src:{id:'sppal'},base:'sppal',get name(){return SR.pal().name;},breed:'Duckling',type:'water',rar:'friend',sp:true,pisl:'meadow',
  fact:'Ducklings follow the first moving thing they see when they hatch, usually their mum. That is why this little duckling followed Seb everywhere!',zoom:100,moves:[['Waddle Wiggle',1,30],['Big Peep',3,90]],col:'#ffb020',bg:'#fffbe0',stats:{spd:6,brn:8,cud:10,brv:9}};
  c.home=()=>'the Lily Pond, Meadow Island';c.earned=()=>SR.named();c.foundAt=()=>SR.named()&&X().pal.at||0;c.art=()=>SR.duckSVG({crown:!!X().done}).replace('<svg ','<svg class="pup" ');
  c.hint=()=>'Meet the little duckling when Spring Blossom begins!';
  c.back=()=>[`🌸 Named by Seb${c.foundAt()?' on '+dstr(c.foundAt()):''}`,'📍 Hatched in Bluebell Wood',`🌸 ${SR.nBb()} of 9 blossom buds`,X().done?'🦆 Back with its mum at the Blossom Festival!':'🦆 Looking for its mum'];return c;}
/* the sets, one per island and a special one */
const SETS={};
function mkSet(key){if(SETS[key])return SETS[key];let S;const lock=()=>'Spring Blossom opens after Summer Beach Party is finished!';
  if(key==='sp'){const L=[];S={id:'3:p_sp',game:3,p:true,season:'sp',isl:'p_sp',name:'Spring Blossom',short:'Spring',icon:'🌸',open:()=>SR.opened(),lockSay:lock,cards:L};
    L.push(palcard(S.id,1,3),scard(SL.SPUPS.primrose,S.id,2,3,'meadow'),scard(SL.SPUPS.tulip,S.id,3,3,'meadow'));}
  else{const I=islandOf(key),P=SR.islX(I),of=P.length+1,L=P.map((p,i)=>scard(p,'3:p_'+key,i+1,of,key));L.push(unicard(I,'3:p_'+key,of,of));
    S={id:'3:p_'+key,game:3,p:true,season:'sp',isl:'p_'+key,name:`${I.name} in spring`,short:I.name.split(' ')[0],icon:I.icon,open:()=>SR.opened(),lockSay:lock,cards:L};}
  return (SETS[key]=S);}
const SPA=['village','windmill'],strip=k=>k.slice(5).replace(/^p(?=village|windmill)/,'');
function entry(key){const I=key!=='sp'&&islandOf(key),pups=key==='sp'?[SL.SPUPS.primrose,SL.SPUPS.tulip]:SR.islX(I),areas=key==='sp'?SPA:I.areas.map(a=>a.id).filter(a=>SR.areaX(a).some(p=>pups.indexOf(p)>=0));
  const mine=cid=>cid.indexOf('3:sp_')===0&&(cid==='3:sp_pal'?key==='sp':cid==='3:sp_'+(I&&I.boss.uni.id)||pups.some(p=>cid==='3:sp_'+p.id));
  const inSet=a=>SR.areaX(a).filter(p=>pups.indexOf(p)>=0);
  return {isl:'p_'+key,season:'sp',keys:()=>areas.map(a=>'x:sp:'+(key==='sp'?'p'+a:a)),set:()=>mkSet(key),
    ids(){if(!state)return [];const out=pups.filter(p=>SR.xFound(p.id)).map(p=>'3:sp_'+p.id);if(key==='sp'&&SR.named())out.unshift('3:sp_pal');if(I&&(X().bb||{})[I.id])out.push('3:sp_'+I.boss.uni.id);return out;},
    key(cid){if(!mine(cid))return undefined;if(cid==='3:sp_pal')return null;const id=cid.slice(5),p=SR.gpup(id);return p?'x:sp:'+(key==='sp'?'p'+p.area:p.area):null;},
    done(k){const a=strip(k);return inSet(a).every(p=>SR.xFound(p.id));},
    info(k){const a=strip(k),A=AREAS[a];return {k,isl:'p_'+key,icon:key==='sp'?'🌸':(A&&A.icon)||'🌸',name:`${A?A.name:'Spring'} in spring`,short:A?A.name:'Spring',sp:true};},
    say(k,c){const a=strip(k),A=AREAS[a],left=inSet(a).filter(p=>!SR.xFound(p.id)).length;return `${c.name}'s spring card is waiting in the ${A?A.name:''} blossom pack. Find ${left} more spring ${left>1?'pups':'pup'} there to open it!`;}};}
window.XCARDS=(window.XCARDS||[]).concat(['sp'].concat(ISLANDS.map(I=>I.id)).map(entry));

/* ---------------- the spring look ---------------- */
const K=INK;
const petalP=(x,y,s,o,c,r)=>`<ellipse cx="${x}" cy="${y}" rx="${3*s}" ry="${6*s}" transform="rotate(${r||30} ${x} ${y})" fill="${c||'#ffb8d0'}" opacity="${o}"/>`;
const eggP=(x,y,s,o,c)=>`<g opacity="${o}"><path d="M${x} ${y-7*s} C${x+5*s} ${y-7*s} ${x+6*s} ${y+1*s} ${x+5.4*s} ${y+3*s} C${x+5*s} ${y+7*s} ${x-5*s} ${y+7*s} ${x-5.4*s} ${y+3*s} C${x-6*s} ${y+1*s} ${x-5*s} ${y-7*s} ${x} ${y-7*s} Z" fill="${c||'#8ad0ff'}"/><path d="M${x-5.6*s} ${y+1*s} H${x+5.6*s}" stroke="#fff" stroke-width="${1.4*s}"/></g>`;
const flowerP=(x,y,r,o,c)=>`<g opacity="${o}">${[0,1,2,3,4].map(i=>{const a=-Math.PI/2+i*Math.PI*2/5;return `<circle cx="${(x+Math.cos(a)*r*.6).toFixed(1)}" cy="${(y+Math.sin(a)*r*.6).toFixed(1)}" r="${(r*.48).toFixed(1)}" fill="${c||'#ffb8d0'}"/>`;}).join('')}<circle cx="${x}" cy="${y}" r="${(r*.32).toFixed(1)}" fill="#ffe066"/></g>`;
const EC=['#ff9ac0','#8ad0ff','#ffe066','#9ae07a','#c8a8ff'];
const PATH=`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">${flowerP(15,16,8,.55)}${eggP(48,46,1,.5,'#8ad0ff')}${petalP(46,15,1,.5,'#ffd0e0',40)}${petalP(16,46,1,.45,'#ffb8d0',-20)}<circle cx="32" cy="30" r="1.6" fill="#fff" opacity=".6"/></svg>`;
function spring(i){const R=seed(i.length*41+7);let s=`<rect width="200" height="190" fill="#d6f0ff" opacity=".34"/><path d="M0 140 Q50 118 100 132 T200 124 V190 H0 Z" fill="#9ad870" opacity=".5"/>`;
  s+=`<circle cx="164" cy="36" r="20" fill="#fff6b0" opacity=".35"/><circle cx="164" cy="36" r="12" fill="#ffe680"/>`;
  s+=`<path d="M0 26 Q30 34 56 22" stroke="#7a5230" stroke-width="3" fill="none" opacity=".7"/>`+[[14,28],[30,30],[46,24]].map((q,k)=>flowerP(q[0],q[1],6,.85,k%2?'#ffd0e0':'#ff9ac0')).join('');
  for(let k=0;k<4;k++)s+=petalP(20+R()*160,40+R()*80,1,.7,k%2?'#ffd0e0':'#ffb8d0',R()*180);
  for(let k=0;k<3;k++)s+=eggP(24+R()*150,160+R()*20,1,1,EC[k%5]);
  return s;}
const EDGEP=()=>{let s=`<path d="M0 0 H400 V10 Q300 22 200 12 T0 14 Z" fill="#a8dcff" opacity=".85"/><path d="M0 8 Q100 22 200 12 T400 16" stroke="#7a5230" stroke-width="4" fill="none"/>`;
  for(let x=24;x<390;x+=44)s+=flowerP(x,12+Math.sin(x)*3,7,1,['#ff9ac0','#ffd0e0','#ffffff'][(x/44|0)%3]);
  let k=0;for(let y=50;y<540;y+=40){[7,393].forEach(x=>{s+=`<g class="twk" style="animation-delay:${(k%5)*.35}s">${k%2?eggP(x,y,.9,1,EC[k%5]):flowerP(x,y,6,1,['#ff9ac0','#ffd0e0','#ffffff'][k%3])}</g>`;k++;});}
  s+=`<path d="M0 548 Q50 538 100 548 T200 548 T300 548 T400 548 V564 H0 Z" fill="#9ad870"/>`;for(let x=30;x<380;x+=40){s+=flowerP(x,554,5,1,['#ffe066','#ffffff','#ff9ac0'][k%3]);k++;}
  return s;};
if(window.CLOOK&&CLOOK.EDGE)CLOOK.EDGE.sp=EDGEP;
function packSVG(s){const n=s.n!=null?s.n:(s.cards||[]).length;const R=seed((s.icon||'').length*7+n);let st='';for(let k=0;k<7;k++)st+=petalP(40+R()*120,90+R()*110,1.4,.55,'#ffffff',R()*180);
  return `<svg viewBox="0 0 200 270" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="20" width="160" height="236" rx="16" fill="#9ad870" stroke="#3f6a2a" stroke-width="5"/><rect x="20" y="20" width="160" height="62" rx="16" fill="#ffb8d0"/>`+
  `<path d="M20 74 q20 -8 40 0 t40 0 t40 0 t40 0 V84 H20 Z" fill="#ffffff" opacity=".85"/>${st}`+
  `<g class="spbow"><path d="M100 46 q-26 -22 -30 -2 q10 12 30 2 q26 -22 30 -2 q-10 12 -30 2" fill="#ff6a98" stroke="#3f6a2a" stroke-width="3"/>${flowerP(100,46,10,1,'#ffffff')}</g>`+
  `<circle cx="100" cy="150" r="36" fill="#fff" stroke="#3f6a2a" stroke-width="4"/><text x="100" y="166" text-anchor="middle" font-size="40">${s.icon||'🌸'}</text>`+
  `<rect x="34" y="214" width="132" height="34" rx="12" fill="#fff" stroke="#3f6a2a" stroke-width="4"/><text x="100" y="239" text-anchor="middle" font-size="21" font-weight="900" fill="#3f6a2a" font-family="Arial">${n} card${n===1?'':'s'}</text></svg>`;}
function openPack(P,pk2){SR.snd.rustle();setTimeout(()=>{const b=pk2&&pk2.querySelector('.spbow');if(b)b.classList.add('pop');SR.snd.pop();},450);}
window.SPCL={pat:()=>PATH,spring,packSVG,open:openPack,scard};
window.SEALOOK=Object.assign(window.SEALOOK||{},{'p:':{pat:()=>PATH,over:spring,edge:'sp',badge:'🌸'}});
window.SEAPACK=Object.assign(window.SEAPACK||{},{p_:{packSVG,open:openPack}});

/* the spring look for cards, the Pup House and the binder */
const PTL=(()=>{const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300">${[[40,50],[205,25],[150,150],[265,205],[70,250],[115,80],[250,110],[30,175],[185,265],[95,205]].map((q,i)=>i%3===0?flowerP(q[0],q[1],9,.4,'#ffffff'):petalP(q[0],q[1],1.6,.45,['#ffb8d0','#ffffff','#ffd0e0'][i%3],i*40)).join('')}</svg>`;return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';})();
const css=document.createElement('style');css.textContent=`
.mc.fin-p,.tc.fin-p{box-shadow:0 0 0 2px #fff inset}.mc.fin-p .finsh,.tc.fin-p .finsh{background:linear-gradient(115deg,rgba(255,255,255,0) 20%,rgba(255,200,220,.45) 35%,rgba(220,255,200,.4) 50%,rgba(255,240,250,.45) 65%,rgba(255,255,255,0) 80%);background-size:250% 100%;animation:spPetal 4.5s ease-in-out infinite alternate}
@keyframes spPetal{from{background-position:0 0}to{background-position:100% 0}}
.pq2pack .spbow{transform-origin:100px 46px;transition:transform .5s}.pq2pack .spbow.pop{transform:scale(1.4) rotate(-20deg) translateY(-12px)}
#book[data-sea=sp],#binder[data-sea=sp]{isolation:isolate}
#book[data-sea=sp]{background:linear-gradient(#f0fff0,#fff0f6)}#book[data-sea=sp] #bookH{color:#3f8a3a}
#binder[data-sea=sp]{background:#c86a90}#binder[data-sea=sp] .bcover{border-color:rgba(255,240,250,.7)}
#book[data-sea=sp]::before,#binder[data-sea=sp]::before{content:'';position:absolute;left:0;right:0;top:0;bottom:0;z-index:-1;background-image:${PTL};background-size:300px 300px;pointer-events:none;animation:spDrift 24s linear infinite}
@keyframes spDrift{from{background-position:0 0}to{background-position:60px 300px}}@media (prefers-reduced-motion:reduce){#book[data-sea=sp]::before,#binder[data-sea=sp]::before{animation:none}}
/* five seasons on the Seasons shelf make 16 binder tabs: let the tabs shrink a little more so they still fit in one row */
#bdTabs{gap:2px}#bdTabs .tab{min-width:50px;padding:0 3px}#bdTabs .tab.sea small{font-size:11px;letter-spacing:-.4px}
#book[data-sea=sp] .tab{opacity:1;background:#f6fff0}#book[data-sea=sp] .tab.sel{background:#ffc8dc}#binder[data-sea=sp] #bdTabs .tab.sel{background:#ffc8dc}`;
document.head.appendChild(css);
})();
