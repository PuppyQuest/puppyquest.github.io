/* ================================================================
   Snowy Summit: Region 1 (Snow pups), reached by the chairlift.
   Lift Station (start) opens two paths: the Green Run (needs skis
   from the ski hire hut) and the Mountain Hut (after 2 pups).
   Green Run leads to the Blue Run, the Hut to the Red Run (needs
   the snowboard). Snowdrifts that a Snow pup clears stand at the
   bottom of the runs, and both runs end at the Ice Cave (boss).
   Bonus: Eagle Peak, up an icy cliff where a Leaf pup grows a vine
   ladder, with a shiny pup and treasure.
   ================================================================ */
(function(){
const R=seed(7077),PINES=['#2f7a4a','#3a8a55','#2c6e45'];
const runGates=(n,z1,z2,amp,f)=>Array.from({length:n},(_,i)=>[Math.round(Math.sin(i*f+.6)*amp),Math.round(z1+(z2-z1)*i/(n-1))]);
function pinesOutside(B,n){for(let i=0;i<n;i++){const s=i%2?1:-1,x=s>0?B.x2+3+R()*18:B.x1-3-R()*18,z=B.z1+R()*(B.z2-B.z1);snowPine(x,z,1+R()*.6);}}
function pinesIn(B,n,keep){let k=0;for(let t=0;t<400&&k<n;t++){const x=(R()<.5?-1:1)*(B.x2-6-R()*8),z=B.z1+20+R()*(B.z2-B.z1-40);if(keep&&keep(x,z))continue;snowPine(x,z,.9+R()*.4);k++;}}
function snowEdgeTrees(Rad,gaps){for(let a=0;a<360;a+=7){if(gaps.some(g=>Math.abs(((a-g+540)%360)-180)<10))continue;for(let k=0;k<2;k++){const an=(a+R()*5)*D2R,r=Rad+4+k*6+R()*3;snowPine(Math.cos(an)*r,Math.sin(an)*r,1+R()*.5);}}}
function mountains(){[[-160,-260,60],[40,-300,80],[220,-240,55],[-280,-60,50],[300,40,60]].forEach(m=>{I('cone','#c9d6e6',m[2],m[2]*1.5,m[2],m[0],m[2]*.55-10,m[1]);I('cone','#ffffff',m[2]*.45,m[2]*.6,m[2]*.45,m[0],m[2]*1.15-10,m[1]);});}

/* ----- the 12 Snow pups ----- */
const PUPS12=[
 {id:'bobble',name:'Bobble',breed:'Japanese Spitz',area:'lift',pitch:1.3,spot:{x:30,z:-26,kind:'igloo'},hint:'Look by the igloo where the penguins play.',
  fact:'Japanese Spitz pups are fluffy and snowy white, like a little cloud with a smile!',rescue:{icon:'🐧',verb:'Shoo',say:'A penguin is sitting on Bobble! Tap to ask the penguin to move!'},
  look:{fur:'#ffffff',ears:'pointy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',scale:.9,acc:['scarf','flake'],scarfC:'#e8423a'}},
 {id:'teddy',name:'Teddy',breed:'Leonberger',area:'lift',pitch:.75,spot:{x:-30,z:20,kind:'drift'},hint:'Look in a big snowdrift near the ski hire hut.',
  fact:'Leonbergers are gentle giants with a lion-like mane, and they love the snow!',rescue:{icon:'⛏️',verb:'Dig',say:'Teddy is stuck in a snowdrift! Tap to dig him out!'},
  look:{fur:'#d9a25a',ear:'#3a3338',ears:'floppy',muzzle:'#3a3338',muzzleBig:true,belly:'#e8bf80',fluffy:true,tail:'plume',hw:62,hh:56,bw:50,bh:42,acc:['scarf','mittens'],scarfC:'#3d8fe0'}},
 {id:'muffin',name:'Muffin',breed:'Tibetan Terrier',area:'hut',pitch:1.15,spot:{x:16,z:14,kind:'sledge'},hint:'Look under the sledges by the Mountain Hut.',
  fact:'Tibetan Terriers have big flat paws like snowshoes, so they can walk on top of the snow!',rescue:{icon:'🛷',verb:'Lift',say:'Muffin is stuck under a sledge! Tap to lift it off!'},
  look:{fur:'#efe3cf',ear:'#c9b79a',ears:'long',fluffy:true,fringe:'#efe3cf',muzzle:'#ffffff',belly:'#ffffff',tail:'plume',eyeWhite:true,acc:['scarf'],scarfC:'#3fae5a'}},
 {id:'biscuit',name:'Biscuit',breed:'Swedish Vallhund',area:'hut',pitch:1.05,spot:{x:-20,z:18,kind:'drift'},tag:{x:24,z:-30,kind:'pine'},hint:'Biscuit plays tag. Look in a snowdrift, then under a pine tree.',
  fact:'Swedish Vallhunds were Viking farm dogs, and they have short legs like a corgi!',rescue:{icon:'🧤',verb:'Tug',say:'Biscuit has a mitten stuck on his nose! Tap to tug it off!'},
  look:{fur:'#9a9488',ear:'#7a7468',ears:'pointy',muzzle:'#e6e0d4',belly:'#e6e0d4',long:true,tail:'stub',acc:['mittens','scarf'],scarfC:'#ffd23f'}},
 {id:'juniper',name:'Juniper',breed:'Eurasier',area:'green',pitch:1.1,spot:{x:-30,z:-60,kind:'pine'},tag:{x:32,z:40,kind:'drift'},hint:'Juniper plays tag on the Green Run. Look by the pine trees, then in a snowdrift lower down.',
  fact:'Eurasiers have thick fluffy coats in lots of colours, and they are calm and friendly.',rescue:{icon:'🌲',verb:'Shake',say:'Juniper is covered in snow from a pine tree! Tap to shake it off!'},
  look:{fur:'#c97a3e',ear:'#7a4a2a',ears:'pointy',muzzle:'#3a2a25',belly:'#e0a46c',fluffy:true,tail:'curl',acc:['scarf'],scarfC:'#ff9ecb'}},
 {id:'sledge',name:'Sledge',breed:'Norwegian Elkhound',area:'green',pitch:.95,spot:{x:28,z:-20,kind:'sledge'},hint:'Look by a sledge on the Green Run.',
  fact:'Norwegian Elkhounds are brave hikers from the snowy mountains of Norway, with tails that curl over their backs.',rescue:{icon:'🚩',verb:'Untangle',say:'Sledge has his lead tangled round a ski flag! Tap to untangle it!'},
  look:{fur:'#a7a59f',ear:'#3a3838',ears:'pointy',muzzle:'#3a3838',belly:'#d9d7d0',tail:'curl',tailTip:'#3a3838',acc:['scarf'],scarfC:'#e8423a'}},
 {id:'snowdrop',name:'Snowdrop',breed:'American Eskimo Dog',area:'blue',pitch:1.35,spot:{x:-30,z:-30,kind:'drift'},hint:'Look in a snowdrift on the Blue Run.',
  fact:'American Eskimo Dogs are bright white and super clever. Long ago some did tricks in the circus!',rescue:{icon:'❄️',verb:'Brush',say:'Snowdrop is covered in snowflakes and can hardly see! Tap to brush them off!'},
  look:{fur:'#ffffff',ears:'pointy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',acc:['cap','flake']}},
 {id:'fjord',name:'Fjord',breed:'Icelandic Sheepdog',area:'blue',pitch:1.1,spot:{x:30,z:30,kind:'pine'},tag:{x:-28,z:100,kind:'igloo'},hint:'Fjord plays tag on the Blue Run. Look under a pine, then in an igloo near the bottom.',
  fact:'Icelandic Sheepdogs came to Iceland with the Vikings, and they have a curly tail and a big smile.',rescue:{icon:'🧊',verb:'Slide',say:'Fjord is stuck on a slippery patch of ice! Tap to help him slide off!'},
  look:{fur:'#e3b47a',ear:'#c99560',ears:'pointy',face:'#ffffff',faceLow:true,muzzle:'#ffffff',belly:'#ffffff',paw:'#ffffff',tail:'curl',fluffy:true,acc:['scarf'],scarfC:'#3d8fe0'}},
 {id:'yeti',name:'Yeti',breed:'Kuvasz',area:'red',pitch:.8,spot:{x:25,z:-90,kind:'drift'},hint:'Look in a snowdrift high up on the Red Run.',
  fact:'A Kuvasz is a big white guardian dog from Hungary, with a coat that keeps out the cold.',rescue:{icon:'⛏️',verb:'Dig',say:'Yeti is buried up to his nose in snow! Tap to dig him out!'},
  look:{fur:'#fbf7ee',ears:'floppy',ear:'#f0e8d8',muzzle:'#ffffff',belly:'#ffffff',fluffy:true,tail:'plume',hw:62,hh:56,bw:50,bh:42,acc:['scarf','mittens'],scarfC:'#e8423a'}},
 {id:'pinecone',name:'Pinecone',breed:'Keeshond',area:'red',pitch:1.15,spot:{x:-25,z:0,kind:'pine'},tag:{x:26,z:110,kind:'sledge'},hint:'Pinecone plays tag on the Red Run. Look under a pine tree, then by a sledge near the bottom.',
  fact:'Keeshonds have dark rings round their eyes that look like glasses, and they love to smile!',rescue:{icon:'🌰',verb:'Pick',say:'Pinecone has pine cones stuck in his fluffy fur! Tap to pick them out!'},
  look:{fur:'#a9aaa6',ear:'#3a3a3a',ears:'pointy',muzzle:'#3a3a3a',belly:'#d0d0cc',fluffy:true,tail:'curl',tailTip:'#3a3a3a',brows:'#3a3a3a',eyeWhite:true,acc:['cap']}},
 {id:'glacier',name:'Glacier',breed:'Alaskan Klee Kai',area:'cave',pitch:1.3,spot:{x:-26,z:-6,kind:'crystal'},hint:'Look by the glowing crystals in the Ice Cave.',
  fact:'Alaskan Klee Kai look like little huskies, and they love to chatter and howl!',rescue:{icon:'🔥',verb:'Warm',say:'Glacier\'s tail is frozen to the ice! Tap to warm it up!'},
  look:{fur:'#7d8794',ear:'#5d6774',ears:'pointy',face:'#ffffff',muzzle:'#ffffff',belly:'#ffffff',paw:'#ffffff',iris:'#7fc8f0',tail:'curl',acc:['scarf'],scarfC:'#ff9ecb',scale:.85}},
 {id:'twinkle',name:'Twinkle',breed:'Lhasa Apso',area:'cave',pitch:1.4,spot:{x:24,z:-6,kind:'stalagmite'},tag:{x:-12,z:-30,kind:'crystal'},hint:'Twinkle plays tag in the Ice Cave. Look by an icy pillar, then by the crystals at the back.',
  fact:'Lhasa Apsos come from the high mountains of Tibet, and they once guarded palaces!',rescue:{icon:'💎',verb:'Polish',say:'Twinkle is stuck behind a sparkly icicle! Tap to wiggle it loose!'},
  look:{fur:'#e9c890',ear:'#c99c5c',ears:'long',fluffy:true,muzzle:'#f3dcae',belly:'#f3dcae',tail:'plume',eyeWhite:true,scale:.85,acc:['bow','flake']}}];
const CRYSTAL={id:'crystal',name:'Crystal',breed:'White Swiss Shepherd',area:'eagle',pitch:1.05,spot:{x:-12,z:-8,kind:'boulder'},hint:'A sparkly pup is hiding at the very top of Eagle Peak.',
  fact:'Crystal is a sparkly pup! White Swiss Shepherds are gentle, clever and snowy white. You found a secret pup!',rescue:{icon:'🦅',verb:'Wave',say:'An eagle is guarding Crystal! Tap to wave hello so the eagle flies away!'},
  look:{fur:'#ffffff',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',tail:'plume',acc:['twinkle','flake','scarf'],scarfC:'#b58cff'}};
const FLURRY={id:'flurry',name:'Flurry',breed:'Snow Unicorn',uni:true,lv:1,pitch:1.2,fact:'Flurry makes the snow sparkle wherever she gallops.',
  look:{fur:'#f4fbff',ears:'side',earIn:'#bfe0ff',muzzle:'#ffffff',belly:'#ffffff',nose:'#8aa0c0',iris:'#5aa9dc',limbs:'hooves',hoofC:'#c9dbef',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','flake'],scale:.96}};

/* ----- areas ----- */
const SNOW={ground:'#f6fafd',ground2:'#dde8f2',sky:'#cbe5f7',fog:[60,200],fogC:'#e3eef8',hedgeC:'#eaf2f9'};
const lift=Object.assign({id:'lift',name:'Lift Station',icon:'🚡',R:56,start:[0,34,Math.PI],
  hf:(x,z)=>Math.sin(x*.08)*.6+Math.cos(z*.07)*.6-z*.04,
  hello:'Welcome to Snowy Summit! This is the Lift Station. Two pups are hiding here. Ski runs go down the mountain, but you will need skis!',how:'Take the chairlift from the village.',
  exits:[{x:-40,z:-38,to:'green',arrive:[0,-138,0],name:'Green Run',icon:'🟢',open:()=>!!state.gear.skis,lock:'You need skis for the Green Run! Look in the ski hire hut.'},
         {x:40,z:-38,to:'hut',arrive:[0,38,Math.PI],name:'Mountain Hut',icon:'🏠',open:()=>foundIn(areaPups('lift'))>=2,lock:()=>{const n=foundIn(areaPups('lift'));return `The path to the Mountain Hut is snowed in. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Lift Station to open it!`;}}],
  build(){mountains();snowfall();
    /* the chairlift top station, back to the village */
    {const y=gy(0,46);I('box','#8a8f99',8,4,5,0,y+2,46);I('box','#e8423a',8.6,.7,5.6,0,y+4.3,46);rect(-4,43.5,4,48.5);const l=label('🚡 Chairlift',6);l.position.set(0,y+7,46);W.ag.add(l);
      for(let z=56;z<120;z+=22){I('cyl','#8a8f99',.35,12,.35,0,gy(0,z)+6-((z-46)*.1),z);}
      W.things.push({x:0,z:40.5,r:4.5,icon:'🚡',label:'Go home',act:goHome});}
    /* ski hire hut with the skis */
    chalet(-24,-10,9,7,'#b9814f');sign(-17,-4,'⛷️ Ski hire',3,6);
    const skis=grp();[-.3,.3].forEach(s=>{mk('box','#e8423a',.18,.06,2.4,s,1.2,0,skis).rotation.x=-1.2;});mk('cyl','#c9c2b8',.04,1.6,.04,.7,.8,0,skis);const ss=sprite('⛷️',1.3);ss.position.y=2.6;skis.add(ss);add(skis,-24,-4.5);skis.visible=!state.gear.skis;W.ticks.push(()=>{skis.rotation.y+=.02;});
    W.things.push({x:-24,z:-4.5,r:3.6,icon:'⛷️',label:'Skis',show:()=>!state.gear.skis,act:()=>{state.gear.skis=true;state.stars+=5;save();hud();skis.visible=false;sfx.jingle();confetti(30);
      card({art:'<div style="font-size:110px;line-height:1">⛷️</div>',h:'You found skis!',p:'Now you can ski down the Green Run. Walk through the green arch, then tap the ski button at the top of the run!'});}});
    /* the igloo and the penguins, and Penguin Parade */
    {const ix=30,iz=-26;I('hemi','#f4fbff',4,3.4,4,ix-8,gy(ix-8,iz),iz-4);I('cyl','#f4fbff',1.4,2,1.4,ix-8,gy(ix-8,iz)+.9,iz,Math.PI/2,0,0);col(ix-8,iz-4,4.2);}
    const pens=[0,1,2,3,4,5].map(i=>{const p=penguin3D();W.ag.add(p);return p;});penguinWaddle(pens,18,-14,6);
    sign(10,-6,'🐧 Penguin Parade',3,7);W.things.push({x:12,z:-3,r:4,icon:'🐧',label:'Penguins',act:()=>{sfx.chime();startHerd('activity','penguins');}});
    snowman(-8,12);snowman(14,26,.8);snowRock(-36,-24);snowRock(34,10,1.3);snowRock(-12,-34);
    [[-44,6],[-38,30],[40,26],[44,-14],[-8,-44],[10,-46],[-46,-18]].forEach(p=>snowPine(p[0],p[1],1.1+R()*.4));
    sign(-30,-30,'⛷️ Ski runs',3,6);sign(30,-30,'🏠 Mountain Hut',3,6);
    snowEdgeTrees(56,[angOf(-40,-38),angOf(40,-38),90]);}},SNOW);

const hut=Object.assign({id:'hut',name:'Mountain Hut',icon:'🏠',R:50,start:[0,38,Math.PI],
  hf:(x,z)=>Math.sin(x*.09)*.5+Math.cos(z*.08)*.5,
  hello:'The Mountain Hut! It smells of hot chocolate. Two pups are hiding here, and one of them loves to play tag.',how:'Find 2 pups at the Lift Station to open the path.',
  exits:[{x:0,z:50,to:'lift',arrive:[34,-30,Math.PI*.75],name:'Lift Station',icon:'🚡'},
         {x:32,z:-38,to:'red',arrive:[0,-148,0],name:'Red Run',icon:'🔴',open:()=>!!state.gear.snowboard,lock:'The Red Run is very bumpy. You need the snowboard! Look by the Mountain Hut.'},
         {x:-50,z:-6,to:'eagle',arrive:[0,24,Math.PI],name:'Eagle Peak',icon:'🦅',gate:{type:'leaf',key:'eagle',look:'cliff',need:0,verb:'grows a vine ladder up the icy cliff',done:'A vine ladder! Now you can climb up to Eagle Peak!'},lock:'The icy cliff is too steep to climb. A Leaf pup could grow a vine ladder! Bring a Leaf pup from Meadow Island.'}],
  build(){mountains();snowfall();
    chalet(0,-16,14,10,'#9b6a43');I('box','#c9905f',14,.4,5,0,gy(0,-8)+.6,-8.5);for(let i=0;i<4;i++)I('cyl','#7a4f2a',.12,1,.12,-6+i*4,gy(0,-6)+.5,-6.2);
    const hl=label('🏠 Mountain Hut',7);hl.position.set(0,gy(0,-16)+11,-16);W.ag.add(hl);
    /* hot chocolate stand */
    I('box','#e8423a',4,2,2,-14,gy(-14,-2)+1,-2);I('box','#ffffff',4.4,.3,2.4,-14,gy(-14,-2)+3.2,-2);spr('☕',1.6,-14,gy(-14,-2)+2.6,-2);rect(-16,-3,-12,-1);
    sign(-14,3,'❄️ Snowflake Catch',3,7);W.things.push({x:-14,z:3,r:4,icon:'❄️',label:'Snowflakes',act:()=>{sfx.chime();startFlies('activity','flakes');}});
    /* the snowboard */
    const sb=grp();mk('box','#3d8fe0',.7,2.6,.12,0,1.4,0,sb).rotation.z=.15;mk('box','#ffd23f',.72,.3,.14,0,1.6,0,sb);const ss=sprite('🏂',1.3);ss.position.y=3.2;sb.add(ss);add(sb,9,-6);sb.visible=!state.gear.snowboard;W.ticks.push(()=>{sb.rotation.y+=.02;});
    W.things.push({x:9,z:-5,r:3.6,icon:'🏂',label:'Snowboard',show:()=>!state.gear.snowboard,act:()=>{state.gear.snowboard=true;state.stars+=5;save();hud();sb.visible=false;sfx.jingle();confetti(30);
      card({art:'<div style="font-size:110px;line-height:1">🏂</div>',h:'You found a snowboard!',p:'Now you can ride the bumpy Red Run. Its arch is behind the Mountain Hut!'});}});
    /* sledges, snowmen, pines */
    [[14,12],[18,16],[22,12]].forEach((p,i)=>{const y=gy(p[0],p[1]);I('box','#e8423a',1.2,.25,2.4,p[0],y+.6,p[1],0,i*.4,0);I('box','#8a8f99',1.4,.1,2.6,p[0],y+.25,p[1],0,i*.4,0);});
    snowman(-26,24);snowman(26,26,1.1);snowRock(-30,-26,1.2);snowRock(36,4);
    [[-38,14],[-30,34],[34,30],[40,-14],[-20,-38],[20,-40]].forEach(p=>snowPine(p[0],p[1],1.1+R()*.4));
    /* the icy cliff up to Eagle Peak */
    I('box','#b9c6d6',4,16,22,-54,gy(-50,-6)+7,-6);I('box','#ffffff',4.4,1,22.4,-54,gy(-50,-6)+15,-6);
    sign(-10,30,'🔴 Red Run this way',3,7);snowEdgeTrees(50,[angOf(32,-38),90,180]);}},SNOW);

function runArea(id,o){const B={x1:-o.w,z1:-o.len,x2:o.w,z2:o.len};
  return Object.assign({id,name:o.name,icon:o.icon,R:o.len,rect:B,start:o.start,camD:12,
    hf:(x,z)=>-z*o.slope+Math.sin(x*.12+z*.03)*1.1+Math.cos(z*.07)*1.4+Math.max(0,Math.abs(x)-(o.w-12))**2*.05+(o.moguls?Math.sin(x*.45)*Math.sin(z*.45)*.7:0),
    gmix:(x,z)=>(Math.sin(z*.05)+1)*.15+Math.max(0,Math.abs(x)-(o.w-14))*.05,
    ski:{key:id,name:o.name,start:[0,-o.len+16],end:o.len-14,vmax:o.vmax,turn:o.turn,board:o.board,gates:runGates(o.gates,-o.len+50,o.len-40,o.amp,o.freq)},
    hello:o.hello,how:o.how,exits:o.exits,
    build(){mountains();snowfall(400);pinesOutside(B,70);const S=this.ski;pinesIn(B,o.inside||8,(x,z)=>S.gates.some(g=>Math.abs(g[1]-z)<8)||Math.abs(z-B.z1)<30||Math.abs(z-B.z2)<30);
      for(let i=0;i<o.rocks;i++){const x=(R()<.5?-1:1)*(o.w-4-R()*6),z=B.z1+30+R()*(B.z2-B.z1-60);if(S.gates.some(g=>Math.abs(g[1]-z)<6))continue;snowRock(x,z,.9);}
      snowman(-o.w+8,B.z2-20);if(o.extra)o.extra(B);}},SNOW,{hedgeC:'#eef4fa'});}
const green=runArea('green',{name:'Green Run',icon:'🟢',w:40,len:150,slope:.2,vmax:15,turn:11,gates:10,amp:12,freq:.9,rocks:6,start:[0,-138,0],
  hello:'The Green Run! Tap the ski button at the top to ski down. Steer with your finger, and go between the flags for stars. Two pups are hiding by the sides of the run.',how:'You need skis from the ski hire hut at the Lift Station.',
  exits:[{x:0,z:-150,to:'lift',arrive:[-32,-30,Math.PI*1.25],name:'Lift Station',icon:'🚡'},
         {x:0,z:150,to:'blue',arrive:[0,-148,0],name:'Blue Run',icon:'🔵',gate:{type:'snow',key:'drift_blue',look:'drift',verb:'clears the giant snowdrift',done:'The snowdrift is gone! Ski on to the Blue Run!'}}]});
const blue=runArea('blue',{name:'Blue Run',icon:'🔵',w:40,len:160,slope:.25,vmax:18,turn:12,gates:12,amp:16,freq:1.25,rocks:10,inside:12,start:[0,-148,0],
  hello:'The Blue Run is faster! Steer round the trees and go through the flags. Two pups are hiding here.',how:'Clear the snowdrift at the bottom of the Green Run with a Snow pup.',
  exits:[{x:0,z:-160,to:'green',arrive:[0,136,Math.PI],name:'Green Run',icon:'🟢'},
         {x:0,z:160,to:'cave',arrive:[-18,26,Math.PI*.85],name:'Ice Cave',icon:'🧊',gate:{type:'snow',key:'drift_cave_b',look:'drift',verb:'clears the snow from the cave door',done:'The Ice Cave is open!'}}]});
const red=runArea('red',{name:'Red Run',icon:'🔴',w:34,len:170,slope:.3,vmax:20,turn:13,gates:12,amp:14,freq:1.5,rocks:12,inside:10,moguls:true,board:true,start:[0,-158,0],
  hello:'The Red Run is the steepest and bumpiest! Snowboard down and go through the flags. Two pups are hiding here.',how:'You need the snowboard from the Mountain Hut.',
  exits:[{x:0,z:-170,to:'hut',arrive:[26,-30,Math.PI*.75],name:'Mountain Hut',icon:'🏠'},
         {x:0,z:170,to:'cave',arrive:[18,26,Math.PI*1.15],name:'Ice Cave',icon:'🧊',gate:{type:'snow',key:'drift_cave_r',look:'drift',verb:'clears the snow from the cave door',done:'The Ice Cave is open!'}}]});

const cave={id:'cave',name:'Ice Cave',icon:'🧊',R:42,ground:'#dff1ff',ground2:'#a9d4f2',sky:'#7fb4dc',fog:[30,120],fogC:'#a9d0ee',hedgeC:'#bfe3ff',start:[-18,26,Math.PI*.85],
  hf:(x,z)=>Math.sin(x*.2)*.3+Math.cos(z*.2)*.3,
  hello:'The Ice Cave! Everything sparkles. Two pups are hiding here, and Flurry the Snow Unicorn lives at the back.',how:'Clear a snowdrift at the bottom of the Blue Run or the Red Run.',
  exits:[{x:-30,z:30,to:'blue',arrive:[0,146,Math.PI],name:'Blue Run',icon:'🔵'},{x:30,z:30,to:'red',arrive:[0,156,Math.PI],name:'Red Run',icon:'🔴'}],
  build(){const dome=new THREE.Mesh(G.hemi,new THREE.MeshLambertMaterial({color:'#cfe9ff',side:THREE.BackSide}));dome.scale.set(48,26,48);W.ag.add(dome);W.disp.push(dome.material);
    for(let i=0;i<40;i++){const a=R()*6.28,r=10+R()*30,x=Math.cos(a)*r,z=Math.sin(a)*r,h=Math.sqrt(Math.max(0,1-(r/48)**2))*26;I('cone','#e8f6ff',.4+R()*.5,2+R()*3,.4+R()*.5,x,h-1.5,z,Math.PI,0,0);}
    [[-30,-8],[-34,6],[30,-14],[34,8],[-8,-34],[12,-34],[-20,-26],[22,-26]].forEach((p,i)=>{const y=gy(p[0],p[1]),c=['#7fd3ff','#b58cff','#9be8ff','#ff9ecb'][i%4];for(let k=0;k<3;k++)I('cone',c,.5,2.2+k*.8,.5,p[0]+(k-1)*.7,y+1.1+k*.4,p[1],0,0,(k-1)*.3,true);col(p[0],p[1],1.2);});
    /* the frozen pool and Ice Steps */
    pond(0,6,9,'#bfeaff');sign(-6,18,'🧊 Ice Steps',3,6);W.things.push({x:0,z:17,r:4,icon:'🧊',label:'Ice Steps',act:()=>{sfx.chime();startStones('activity','icesteps');}});
    for(let i=0;i<6;i++)I('box','#e8f6ff',1.6,.6,1.6,-6+i*2.4,gy(0,6)+.3,6+Math.sin(i)*2);
    const ll=label('🧊 Ice Cave',6);ll.position.set(0,14,-30);W.ag.add(ll);}};

const eagle=Object.assign({id:'eagle',name:'Eagle Peak',icon:'🦅',R:34,start:[0,24,Math.PI],
  hf:(x,z)=>3*Math.exp(-(x*x+(z+6)*(z+6))/300)+Math.sin(x*.2)*.4,
  hello:'Eagle Peak! You can see the whole mountain from here. A secret sparkly pup and a treasure chest are hidden at the top!',how:'A Leaf pup grows a vine ladder up the icy cliff behind the Mountain Hut.',
  exits:[{x:0,z:34,to:'hut',arrive:[-40,-6,Math.PI*.5],name:'Mountain Hut',icon:'🏠'}],
  build(){mountains();snowfall(300);[[-20,-14,1.6],[18,-18,1.4],[-24,10,1.2],[22,12,1.5],[0,-26,1.8]].forEach(r=>snowRock(r[0],r[1],r[2]));
    /* the eagle's nest */
    I('cyl','#8a5a3a',2.4,.8,2.4,8,gy(8,-6)+.4,-6);I('sph','#ffffff',.3,.4,.3,7.4,gy(8,-6)+1,-6);I('sph','#ffffff',.3,.4,.3,8.6,gy(8,-6)+1,-5.6);col(8,-6,2.4);
    const eg=sprite('🦅',2.4);W.ag.add(eg);W.ticks.push(()=>{const a=W.t*.4;eg.position.set(Math.cos(a)*16,14+Math.sin(a*2),Math.sin(a)*16-4);});
    treasureChest(-6,-18,'eagle');
    [[-28,-2],[26,-4],[-14,26],[16,26]].forEach(p=>snowPine(p[0],p[1],1));}},SNOW,{noHedge:false});

/* ----- activity skins for this island ----- */
function penguinSVG(){const k=INK;return `<svg viewBox="0 0 90 90"><g stroke="${k}" stroke-width="3.5"><ellipse cx="45" cy="50" rx="24" ry="30" fill="#26232e"/><ellipse cx="45" cy="56" rx="16" ry="22" fill="#fff"/><circle cx="45" cy="24" r="16" fill="#26232e"/>
  <path d="M21 46 Q10 58 18 66 M69 46 Q80 58 72 66" fill="none" stroke-width="7" stroke-linecap="round"/><ellipse cx="37" cy="82" rx="8" ry="4" fill="#ffb347"/><ellipse cx="53" cy="82" rx="8" ry="4" fill="#ffb347"/></g>
  <path d="M41 28 L49 28 L45 35Z" fill="#ffb347"/><circle cx="39" cy="22" r="4" fill="#fff"/><circle cx="51" cy="22" r="4" fill="#fff"/><circle cx="40" cy="22" r="2" fill="${k}"/><circle cx="52" cy="22" r="2" fill="${k}"/></svg>`;}
function penBox(label,fill,rail,post){const k=INK,P=PEN;let s=`<rect x="${P.x1}" y="${P.y1}" width="${P.x2-P.x1}" height="${P.y2-P.y1}" fill="${fill}" opacity=".75"/>`;
  const r=(x1,y1,x2,y2)=>`<path d="M${x1} ${y1-10} L${x2} ${y2-10}" stroke="${k}" stroke-width="18" stroke-linecap="round"/><path d="M${x1} ${y1-10} L${x2} ${y2-10}" stroke="${rail}" stroke-width="11" stroke-linecap="round"/>`;
  s+=r(P.x1,P.y1,P.x2,P.y1)+r(P.x2,P.y1,P.x2,P.y2)+r(P.x1,P.y2,P.x2,P.y2)+r(P.x1,P.y1,P.x1,P.gy1)+r(P.x1,P.gy2,P.x1,P.y2);
  [[P.x1,P.gy1],[P.x1,P.gy2]].forEach(q=>s+=`<rect x="${q[0]-12}" y="${q[1]-34}" width="24" height="44" rx="6" fill="${post}" stroke="${k}" stroke-width="3"/>`);
  return s+`<g transform="translate(${P.x1+70} ${P.y1+40})"><rect x="-62" y="-30" width="124" height="40" rx="10" fill="#fff" stroke="${k}" stroke-width="4"/><text x="0" y="-2" font-size="24" font-weight="900" text-anchor="middle" fill="${k}">${label}</text></g>
  <path d="M${P.x1-70} ${(P.gy1+P.gy2)/2} l40 0 m-14 -14 l14 14 l-14 14" stroke="#fff" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity=".9"/>`;}
function snowPenSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="140" fill="#cbe5f7"/><path d="M0 120 L120 40 L240 110 L360 30 L520 120 L660 50 L820 120 L940 60 L1024 100 V140 H0Z" fill="#eef4fa" stroke="#bcd0e2" stroke-width="3"/><rect y="130" width="1024" height="638" fill="#f6fafd"/>`;
  for(let i=0;i<50;i++)s+=`<circle cx="${(i*151)%1010+8}" cy="${160+(i*83)%590}" r="${3+i%4}" fill="#dde8f2"/>`;
  s+=penBox('🧊 Igloo','#e3f2ff','#bfe3ff','#ffffff');s+=`<path d="M${PEN.x1+110} ${PEN.y2-40} a70 60 0 0 1 140 0Z" fill="#ffffff" stroke="${k}" stroke-width="4"/><path d="M${PEN.x1+160} ${PEN.y2-40} a20 24 0 0 1 40 0Z" fill="#9bb8d0" stroke="${k}" stroke-width="3"/>`;return s+'</svg>';}
function snowSkySVG(){let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="ssky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fa9d6"/><stop offset="1" stop-color="#cfe3f5"/></linearGradient></defs><rect width="1024" height="768" fill="url(#ssky)"/>`;
  [[150,560,140],[420,600,180],[760,570,160],[980,610,120]].forEach(m=>s+=`<path d="M${m[0]-m[2]} 768 L${m[0]} ${m[1]-m[2]} L${m[0]+m[2]} 768Z" fill="#eef4fa" stroke="#bcd0e2" stroke-width="4"/><path d="M${m[0]-m[2]*.35} ${m[1]-m[2]*.65} L${m[0]} ${m[1]-m[2]} L${m[0]+m[2]*.35} ${m[1]-m[2]*.65}Z" fill="#fff"/>`);
  for(let i=0;i<60;i++)s+=`<circle cx="${(i*131)%1020}" cy="${(i*71)%600+10}" r="${1.5+i%3}" fill="#fff" opacity=".7"/>`;
  return s+`<rect x="0" y="690" width="1024" height="78" fill="#f6fafd"/></svg>`;}
function icePoolSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#8fc6ea"/><rect width="1024" height="150" fill="#cfe9ff"/>`;
  for(let i=0;i<14;i++)s+=`<path d="M${i*76+10} 0 l18 ${60+(i%3)*30} l18 ${-60-(i%3)*30}Z" fill="#e8f6ff" stroke="#9fc7e6" stroke-width="2"/>`;
  for(let i=0;i<20;i++)s+=`<path d="M${(i*173)%980+20} ${200+(i*97)%540} l30 10" stroke="#e8f6ff" stroke-width="3" opacity=".7"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#e8f6ff" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#e8f6ff" stroke="${k}" stroke-width="5"/>`;
  return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🦄</text></svg>`;}
HERDS.penguins={k:'penguins',icon:'🐧',n:6,animal:()=>penguinSVG(),herder:()=>buddyPup(),bg:()=>snowPenSVG(),title:'All the penguins are home!',
  intro:p=>`The penguins are sliding all over the snow! Help ${p.name} herd them back to the igloo. Drag your finger and ${p.name} will follow. The penguins waddle away from ${p.name}!`};
CATCH.flakes={k:'flakes',icon:'❄️',need:15,bg:()=>snowSkySVG(),cls:'snow',inner:'<b>❄️</b>',art:'🫙❄️',fall:true,intro:'Catch the sparkly snowflakes! Tap a snowflake while it sparkles, and it will float into your jar. Catch 15!',tip:'Wait until it sparkles, then tap!',title:'You caught 15 sparkly snowflakes!'};
COUNTS.icesteps={k:'icesteps',icon:'🧊',rounds:[{step:3,word:'threes'},{step:4,word:'fours'},{step:6,word:'sixes'}],bg:()=>icePoolSVG(),cls:'ice',intro:'Help your pup hop across the frozen pool on the ice blocks!',title:'You counted across the icy pool!'};
regAct('penguins',{name:'Penguin Parade',icon:'🐧',island:'snowy',area:'lift',where:'the Lift Station',play:()=>startHerd('arcade','penguins')});
regAct('green',{name:'Green Run',icon:'🟢',island:'snowy',area:'green',where:'the Green Run',play:()=>arcadeTravel('green',[0,-136,0],startSki,'Ski time!')});
regAct('flakes',{name:'Snowflake Catch',icon:'❄️',island:'snowy',area:'hut',where:'the Mountain Hut',play:()=>startFlies('arcade','flakes')});
regAct('blue',{name:'Blue Run',icon:'🔵',island:'snowy',area:'blue',where:'the Blue Run',play:()=>arcadeTravel('blue',[0,-146,0],startSki,'Ski time!')});
regAct('red',{name:'Red Run',icon:'🔴',island:'snowy',area:'red',where:'the Red Run',play:()=>arcadeTravel('red',[0,-156,0],startSki,'Snowboard time!')});
regAct('icesteps',{name:'Ice Steps',icon:'🧊',island:'snowy',area:'cave',where:'the Ice Cave',play:()=>startStones('arcade','icesteps')});

regIsland({id:'snowy',name:'Snowy Summit',icon:'🏔️',type:'snow',rideName:'The chairlift',ride:'the chairlift',from:'chairlift station in the village',rideIcon:'🚡',rideSay:'Up, up, up the chairlift!',
  homeSay:'Down the chairlift to the village!',homePos:[31,27,2.2],
  badge:'Snow Badge',cert:'Seb, Snowy Summit Hero!',bossHint:'Flurry the Snow Unicorn is waiting in the Ice Cave!',
  nextSay:'Hooray! Snowy Summit is safe! Have you been to Coral Reef too?',
  map:{shape:'M90 400 L250 120 Q300 40 360 90 L430 20 L500 90 Q560 40 610 120 L780 400 Q600 460 430 450 Q260 460 90 400Z',
    nodes:{lift:[430,330],green:[220,250],hut:[640,250],blue:[170,95],red:[690,95],cave:[430,80],eagle:[765,335]},
    links:[['lift','green'],['lift','hut'],['green','blue'],['hut','red'],['blue','cave'],['red','cave'],['hut','eagle']]},
  boss:{area:'cave',x:0,z:-16,perch:0,uni:FLURRY,
    story:[['m','Muddle the Magpie skids across the ice. "Sorry, Seb! I slid down the Red Run on a tea tray, chasing a shiny icicle, and I scared all the pups!"'],
      ['u','Flurry the Snow Unicorn laughs. "Muddle, slow down and look where you are going! Now give back the shiny Snow Star."'],
      ['b','Muddle gives back the Snow Star, and all 12 Snow pups cheer! Flurry gives Seb the Snow Badge.']],
    after:['Flurry says: thank you for finding every pup on Snowy Summit!','Muddle says: I am never sliding on a tea tray again! Well, maybe once more.','Flurry says: did you see the snow sparkle?']},
  pups:PUPS12,bonus:[CRYSTAL],areas:[lift,hut,green,blue,red,cave,eagle]});
})();
