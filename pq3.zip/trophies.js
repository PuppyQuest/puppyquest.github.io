/* ================================================================
   Times Table Trophies (saga step 8, 26 Nov 2026): a Trophy Trial for each times table from 2 to 12.
   12 questions (that table times 1 to 12, mixed up), 4 big answers, a clue after a wrong answer, no timer.
   Bronze for finishing, silver for 10 right first time, gold for all 12 right first time.
   The best trophy for each table is kept in the game save and in the saga store (SAGA), so a trophy won
   in one game shows in every game and on the website's front page.
   Uses the quiz engine (engine5.js: Z.first and sk.done). A 🥇 tile in the Games Arcade, a 🏆 tab in the Pup House.
   Needs saga.js. Load after engine5.js, games.js, awards.js and game.js.
   ================================================================ */
(function(){
const TABLES=[2,3,4,5,6,7,8,9,10,11,12],NAME=['','bronze','silver','gold'];
let order=[];
const best=n=>Math.max(+(((state.trophies)||{})[n]||0),SAGA.trophy(n));
const count=lv=>TABLES.filter(n=>best(n)>=lv).length;
function cup(n,sz){return SAGA.cupSVG(best(n),n,sz);}
function bg(){const k=INK;let s=`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="768" fill="#ffe9c7"/>
  <rect y="520" width="1024" height="248" fill="#c98f5a"/><path d="M0 520 H1024" stroke="${k}" stroke-width="6"/>`;
  for(let i=0;i<9;i++)s+=`<path d="M${i*128} 0 L${i*128+64} 70 L${i*128+128} 0Z" fill="${['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff'][i%5]}" stroke="${k}" stroke-width="4"/>`;
  [[60,300],[880,300]].forEach(q=>{s+=`<rect x="${q[0]}" y="${q[1]}" width="90" height="16" rx="5" fill="#a9774d" stroke="${k}" stroke-width="4"/>`;});
  return s+`<g transform="translate(62 190) scale(.85)">${SAGA.cupSVG(3,'',100)}</g><g transform="translate(882 190) scale(.85)">${SAGA.cupSVG(2,'',100)}</g></svg>`;}
function make(n,i){const b=order[i],flip=i%3===2,ans=b*n,list=Array.from({length:b},(_,k)=>n*(k+1));
  return {q:`<b>${flip?n+' × '+b:b+' × '+n} = ?</b>`,say:flip?`What is ${n} times ${b}?`:`What is ${b} times ${n}?`,ans,
    opts:opts(ans,[ans+n,ans-n,ans+1,ans-1,ans+10,ans-10,ans+2*n],4),
    hint:b<=5?dotsPic(b,n):`<div class="ttCount">${list.join(', ')}</div>`,hintSay:`Count in ${n}s, ${b} times. ${list.join(', ')}.`};}
TABLES.forEach(n=>{QUIZ['tt'+n]={k:'tt'+n,name:`${n} Times Table Trophy`,icon:'🏆',n:12,bg,introMs:3600,
  intro:`The ${n} times table trophy! 12 questions. Get them all right first time for gold!`,
  make:i=>make(n,i),block:Q=>String(Q.ans),done:(Z,secs)=>end(n,Z.first||0,secs)};});
function play(n){order=shuffle(Array.from({length:12},(_,i)=>i+1));closeOv('menu');sfx.pop();startQuiz('trophy','tt'+n);}
function end(n,first,secs){const lv=first>=12?3:first>=10?2:1,was=best(n),wasGame=+((state.trophies||{})[n]||0);
  state.trophies=state.trophies||{};if(lv>wasGame)state.trophies[n]=lv;SAGA.setTrophy(n,lv);
  const up=lv>was,st=10+(up?20*(lv-was):0);state.stars+=st;save();hud();sfx.fanfare();confetti(up?90:50);hush();
  const next=lv===1?'Get 10 right first time for silver!':lv===2?'Get all 12 right first time for gold!':'';
  const h=lv===3?'🥇 Gold trophy!':lv===2?'🥈 Silver trophy!':'🥉 Bronze trophy!';
  card({art:`<div class="ttBig">${SAGA.cupSVG(lv,n,170)}</div>`,h,h3:`The ${n} times table`,
    p:`${first} of 12 right first time.${up&&was?`<br>⬆️ Better than your ${NAME[was]} trophy!`:''}${!up&&was>lv?`<br>Your best is still ${NAME[was]}.`:''}${next?'<br>'+next:''}<br>+${st} stars`,
    say:`${h.slice(3)} The ${n} times table. You got ${first} of 12 right first time.${up&&was?` That beats your ${NAME[was]} trophy!`:''} ${next}`,
    btns:[['Again ▶','green',()=>play(n)],['🏆 Trophies','',()=>shelf()],['Done','white',()=>backToWorld()]]});}
/* the shelf: a card of 11 trophies; tap one to play its trial */
function shelf(quiet){const c=$('#menuCard');c.className='card wide';const g=count(3);
  c.innerHTML=`<h2>🏆 Times Table Trophies</h2><p class="ttNote">Bronze for finishing. Silver for 10 right first time. Gold for all 12!</p>
    <div class="ttShelf">${TABLES.map(n=>`<button class="ttCup" data-n="${n}">${cup(n,92)}<small>${SAGA.MEDAL[best(n)].replace('Not yet','Try it')}</small></button>`).join('')}</div>
    <div class="btns"><button class="btn white" id="ttX">Close ✕</button></div>`;
  c.querySelectorAll('.ttCup').forEach(b=>tap(b,()=>play(+b.dataset.n)));tap('#ttX',()=>{sfx.boop();closeOv('menu');});
  $('#menu').classList.add('on');if(!quiet)speak(`Times Table Trophies! Pick a times table. You have ${g} gold ${g===1?'trophy':'trophies'}.`);}
/* the Games Arcade tile (on the Games tab) */
regAct('tttrophy',{icon:'🥇',name:'Times Table Trophies',need:()=>true,play:()=>shelf()});
const og=openGames;openGames=function(tab){og(tab);if(arcTab!=='games')return;const col=$('#menuCard .gcols');if(!col||col.querySelector('[data-g="tttrophy"]'))return;
  const b=el('button','grow',`<span class="gi">🥇</span><span class="gn">Times Table Trophies</span><span class="gb">🥇 ${count(3)}</span>`);b.dataset.g='tttrophy';col.appendChild(b);};
/* the Pup House tab: the same shelf, to look at (drawn over the badges page, with its words kept quiet) */
function addTab(){const tabs=$('#bookTabs');if(!tabs||tabs.querySelector('.ttTab'))return null;
  const t=el('button','tab ttTab',`🏆<small>${count(1)}/11</small>`);tap(t,()=>showBook('trophies'));
  const certs=[...tabs.children].find(x=>x.textContent.indexOf('📜')===0);if(certs&&certs.nextSibling)tabs.insertBefore(t,certs.nextSibling);else tabs.appendChild(t);return t;}
const ob=showBook;showBook=function(isl){const want=isl||bookIsl;if(want!=='trophies'){ob.apply(this,arguments);addTab();return;}
  const s0=say;say=function(){};try{ob.call(this,'badges');}finally{say=s0;}bookIsl='trophies';
  const t=addTab()||$('#bookTabs .ttTab');[...$('#bookTabs').children].forEach(x=>x.classList.toggle('sel',x===t));
  const gr=$('#bookGrid');gr.className='ttHouse';gr.innerHTML='';$('#bookPager').style.display='none';
  TABLES.forEach(n=>{const lv=best(n),b=el('button','ttCup',`${cup(n,128)}<small>${n} times table</small>`);
    tap(b,()=>{sfx.boop();card({art:`<div class="ttBig">${SAGA.cupSVG(lv,n,150)}</div>`,h:lv?`${NAME[lv][0].toUpperCase()+NAME[lv].slice(1)} trophy`:'Not won yet',h3:`The ${n} times table`,
      p:lv===3?'Gold! All 12 right first time.':`Win it in the Games Arcade: Times Table Trophies.${lv?' '+(lv===1?'10 right first time for silver.':'All 12 right first time for gold.'):''}`,btns:[['OK','green']]});});gr.appendChild(b);});
  say(`Your trophies. ${count(1)} of 11 times tables won, ${count(3)} of them gold.`);};
/* awards */
MERITS.push({id:'tt_first',icon:'🥉',name:'Trophy Winner',how:'Win any times table trophy in the Games Arcade.',ok:()=>count(1)>=1},
  {id:'tt_gold',icon:'🥇',name:'Golden Tables',how:'Win a gold times table trophy.',ok:()=>count(3)>=1},
  {id:'tt_five',icon:'🏆',name:'Trophy Cabinet',how:'Win trophies for 5 different times tables.',ok:()=>count(1)>=5});
CERTS.push({id:'ttgold',icon:'🏆',title:'Times Table Champion',why:'for winning a gold trophy for every times table from 2 to 12',ok:()=>count(3)>=11});
/* keep the saga store up to date with trophies brought back by a backup code */
function sync(){try{Object.keys(state.trophies||{}).forEach(n=>SAGA.setTrophy(+n,+state.trophies[n]));}catch(e){}}
setTimeout(sync,1500);
const css=document.createElement('style');css.textContent=`.ttShelf{display:grid;grid-template-columns:repeat(6,1fr);gap:10px;margin:8px 0 6px}
.ttCup{font:inherit;background:#fff8ea;border:4px solid ${INK};border-radius:22px;padding:6px 2px 4px;display:flex;flex-direction:column;align-items:center;color:${INK}}
.ttCup small{font-size:17px;font-weight:800}.ttNote{font-size:20px;font-weight:700;margin:0}
#bookGrid.ttHouse{grid-template-columns:repeat(6,1fr);grid-auto-rows:206px;gap:12px;align-content:start}#bookGrid.ttHouse .ttCup{justify-content:center}
#bookGrid.ttHouse .ttCup small{font-size:18px}
.ttBig svg{display:block;margin:0 auto}.ttCount{background:#fff;border:4px solid ${INK};border-radius:16px;padding:8px 16px;font-size:26px;font-weight:800;max-width:560px;text-align:center}`;
document.head.appendChild(css);
window.TROPHY={TABLES,best,count,play,shelf,sync};
})();
