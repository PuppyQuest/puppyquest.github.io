/* ================================================================
   Photo mode (saga step 8, 26 Nov 2026). The 📷 button in the world: the hero turns to the camera and
   strikes a pose (👋 wave, 🙌 cheer or 🧍 stand), the buddy and pack pups line up either side, a drag
   looks round, ➕ ➖ or a pinch zooms, and the big button snaps a photo. Press and hold the photo to save it
   (or 📤 Save where the iPad offers it). The last 9 photos of each game are kept in the device's own photo
   store (IndexedDB `pqPhotos`, never the game save), in the 🖼️ album.
   Load after game.js and models.js. Needs saga.js (the game's name for the photo's corner stamp).
   ================================================================ */
(function(){
const PH={on:false,yaw:0,dist:9,h:3,pose:0,pts:{},cx:0,cz:0};
const POSES=[['👋','wave'],['🙌','cheer'],['🧍','']];
const DBN=(window.LAB?'lab_':'')+'pqPhotos',KEEP=9,GAMEID=SAGA.ME.id;
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));

/* ---------- the buttons ---------- */
const wb=el('button','btn rnd white','📷');wb.id='wPhoto';wb.style.cssText='left:14px;top:280px';$('#world').appendChild(wb);
const ui=document.createElement('div');ui.id='phUI';
ui.innerHTML=`<div id="phPad"></div><div id="phFlash"></div><button class="btn green" id="phDone">✓ Done</button>
  <button class="btn rnd white" id="phAlbum" aria-label="Album">🖼️</button><button class="btn rnd white" id="phPose" aria-label="Pose">👋</button>
  <button class="btn rnd white" id="phIn" aria-label="Closer">➕</button><button class="btn rnd white" id="phOut" aria-label="Further">➖</button>
  <button id="phSnap" aria-label="Take a photo"><span></span></button><div id="phTip">👆 Drag to look round</div>`;
$('#world').appendChild(ui);
tap(wb,()=>start());tap('#phDone',()=>{sfx.boop();stop();});tap('#phSnap',()=>snap());
tap('#phPose',()=>{sfx.boop();PH.pose=(PH.pose+1)%POSES.length;$('#phPose').textContent=POSES[PH.pose][0];});
tap('#phIn',()=>{sfx.boop();PH.dist=clamp(PH.dist-1.5,4.5,16);});tap('#phOut',()=>{sfx.boop();PH.dist=clamp(PH.dist+1.5,4.5,16);});
tap('#phAlbum',()=>{sfx.boop();album();});

/* drag to look round, pinch to zoom (the walking joystick is kept out while photo mode is on) */
const pad=$('#phPad');
pad.addEventListener('pointerdown',e=>{e.stopPropagation();initAudio();PH.pts[e.pointerId]={x:e.clientX,y:e.clientY};try{pad.setPointerCapture(e.pointerId);}catch(er){}$('#phTip').style.opacity=0;});
pad.addEventListener('pointermove',e=>{const p=PH.pts[e.pointerId];if(!p)return;e.stopPropagation();const ids=Object.keys(PH.pts);
  if(ids.length>=2){const o=PH.pts[ids[0]===String(e.pointerId)?ids[1]:ids[0]],d0=Math.hypot(p.x-o.x,p.y-o.y),d1=Math.hypot(e.clientX-o.x,e.clientY-o.y);if(d0>10)PH.dist=clamp(PH.dist*d0/d1,4.5,16);}
  else{PH.yaw-=(e.clientX-p.x)*.009;PH.h=clamp(PH.h+(e.clientY-p.y)*.012,.8,8);}
  p.x=e.clientX;p.y=e.clientY;});
const up=e=>{delete PH.pts[e.pointerId];};pad.addEventListener('pointerup',up);pad.addEventListener('pointercancel',up);

/* ---------- photo mode on and off ---------- */
function start(){if(cur!=='world'||ovOpen()||PH.on)return;initAudio();
  if(player.ski||W.rescue||player.lock){sfx.oops();say('Photos in a moment! Finish what you are doing first.');return;}
  PH.on=true;PH.yaw=player.h;PH.dist=9;PH.h=3;PH.pts={};player.lock=true;joyReset();hush();sfx.pop();
  $('#world').classList.add('phOn');$('#phTip').style.opacity=1;$('#phPose').textContent=POSES[PH.pose][0];
  speak(followers.length?'Photo time! Everyone say cheese! Drag to look round, then press the big button.':'Photo time! Drag to look round, then press the big button.');}
function stop(){if(!PH.on)return;PH.on=false;player.lock=false;POSES.forEach(p=>{if(p[1])player[p[1]]=0;});W.camYaw=player.h+Math.PI;$('#world').classList.remove('phOn');}

/* the camera: in front of the hero, looking back at the group */
const cu=camUpdate;camUpdate=function(dt,snap){if(!PH.on)return cu.apply(this,arguments);if(cur!=='world'){stop();return cu.apply(this,arguments);}
  const P=player,gx=Math.sin(PH.yaw),gz=Math.cos(PH.yaw),D=typeof camRoom==='function'?camRoom(-gx,-gz,PH.dist):PH.dist;
  const tx=P.x+gx*D,tz=P.z+gz*D,ty=Math.max(P.y+PH.h,gy(tx,tz)+.8),k=snap?1:Math.min(1,(dt||.016)*7);
  cam.position.x+=(tx-cam.position.x)*k;cam.position.y+=(ty-cam.position.y)*k;cam.position.z+=(tz-cam.position.z)*k;cam.lookAt(P.x,P.y+2,P.z);PH.cx=cam.position.x;PH.cz=cam.position.z;
  P.h=lerpAng(P.h,Math.atan2(cam.position.x-P.x,cam.position.z-P.z),Math.min(1,(dt||.016)*6));P.ly=0;P.lookT=5;
  const pz=POSES[PH.pose][1];if(pz)P[pz]=1;};
/* the pups line up either side of the hero, facing the camera */
const SLOTS=[[-2,.5],[2,.5],[-3.7,-.6],[3.7,-.6]];
const uf=updateFollowers;updateFollowers=function(dt,t){if(!PH.on)return uf.apply(this,arguments);const P=player,fx=Math.sin(P.h),fz=Math.cos(P.h);
  followers.forEach((f,i)=>{const s=SLOTS[i%SLOTS.length];let x=P.x+fz*s[0]+fx*s[1],z=P.z-fx*s[0]+fz*s[1];const r=resolve(x,z);x=r[0];z=r[1];
    const dx=x-f.x,dz=z-f.z,d=Math.hypot(dx,dz);f.moving=d>.3;if(f.moving){const sp=Math.min(SPEED*1.2,d*4);f.x+=dx/d*sp*dt;f.z+=dz/d*sp*dt;f.h=lerpAng(f.h,Math.atan2(dx,dz),Math.min(1,dt*10));}
    else f.h=lerpAng(f.h,Math.atan2(PH.cx-f.x,PH.cz-f.z),Math.min(1,dt*6));
    f.y=W.area&&W.area.swim?(f.y==null?P.y:f.y):walkY(f.x,f.z);f.grp.visible=true;f.grp.position.set(f.x,f.y,f.z);f.grp.rotation.y=f.h;animPup(f.grp,t,f.moving);});};

/* ---------- snap ---------- */
function stamp(x,c){const s=c.width/1024,txt=`🐾 ${SAGA.ME.name}`,d=new Date().toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'});
  x.font=`900 ${Math.round(26*s)}px ui-rounded,"SF Pro Rounded",system-ui,sans-serif`;const w=Math.max(x.measureText(txt).width,(x.font=`700 ${Math.round(18*s)}px ui-rounded,system-ui,sans-serif`,x.measureText(d).width))+36*s;
  const bx=c.width-w-18*s,by=c.height-86*s,bh=68*s,r=18*s;x.fillStyle='rgba(255,255,255,.88)';x.strokeStyle=INK;x.lineWidth=4*s;
  x.beginPath();x.moveTo(bx+r,by);x.arcTo(bx+w,by,bx+w,by+bh,r);x.arcTo(bx+w,by+bh,bx,by+bh,r);x.arcTo(bx,by+bh,bx,by,r);x.arcTo(bx,by,bx+w,by,r);x.closePath();x.fill();x.stroke();
  x.fillStyle=INK;x.textBaseline='alphabetic';x.font=`900 ${Math.round(26*s)}px ui-rounded,"SF Pro Rounded",system-ui,sans-serif`;x.fillText(txt,bx+18*s,by+32*s);
  x.font=`700 ${Math.round(18*s)}px ui-rounded,system-ui,sans-serif`;x.fillText(d,bx+18*s,by+56*s);}
function grab(){R3.render(scene,cam);const src=R3.domElement,sc=Math.min(1,1600/src.width),c=document.createElement('canvas');c.width=Math.round(src.width*sc);c.height=Math.round(src.height*sc);
  const x=c.getContext('2d');x.drawImage(src,0,0,c.width,c.height);try{stamp(x,c);}catch(e){}return c.toDataURL('image/jpeg',.88);}
function snap(){if(!PH.on||ovOpen())return;initAudio();let url;try{url=grab();}catch(e){sfx.oops();say('The camera did not work that time. Try again!');return;}
  const fl=$('#phFlash');fl.classList.remove('go');void fl.offsetWidth;fl.classList.add('go');sfx.pop();setTimeout(()=>sfx.chime(),120);
  state.stats.photos=(state.stats.photos||0)+1;save();
  keep(url).then(()=>{}).catch(()=>{});setTimeout(()=>show1(url,null),450);}
/* one photo, big: press and hold to save; 📤 Save where sharing a picture works */
function show1(url,id){const canShare=!!(navigator.canShare&&window.File);
  const btns=[['📷 Another','green',()=>{}],['🖼️ Album','',()=>album()]];if(canShare)btns.splice(1,0,['📤 Save','',()=>share(url)]);
  if(id!=null)btns.push(['🗑️','white',()=>{forget(id).then(()=>album());}]);
  card({art:`<img class="phShot" src="${url}" alt="A Puppy Quest photo">`,h:id==null?'Click!':'Your photo',p:'Press and hold the photo to save it.',say:id==null?'Click! What a great photo! Press and hold it to save it.':'',btns});}
function share(url){try{const b=atob(url.split(',')[1]),a=new Uint8Array(b.length);for(let i=0;i<b.length;i++)a[i]=b.charCodeAt(i);
  const f=new File([a],'puppy-quest-photo.jpg',{type:'image/jpeg'});if(navigator.canShare({files:[f]}))navigator.share({files:[f]}).catch(()=>{});else say('Press and hold the photo to save it.');}catch(e){say('Press and hold the photo to save it.');}}

/* ---------- the album: the last 9 photos of this game, kept on this device ---------- */
function db(){return new Promise((ok,no)=>{if(!window.indexedDB)return no('none');const r=indexedDB.open(DBN,1);r.onupgradeneeded=()=>{const d=r.result;if(!d.objectStoreNames.contains('photos'))d.createObjectStore('photos',{keyPath:'id'});};r.onsuccess=()=>ok(r.result);r.onerror=()=>no(r.error);});}
function tx(mode,fn){return db().then(d=>new Promise((ok,no)=>{const t=d.transaction('photos',mode),s=t.objectStore('photos');const out=fn(s);t.oncomplete=()=>ok(out&&out.result!==undefined?out.result:out);t.onerror=()=>no(t.error);}));}
function list(){return tx('readonly',s=>s.getAll()).then(a=>(a||[]).filter(p=>p.game===GAMEID).sort((x,y)=>y.id-x.id));}
function keep(url){return tx('readwrite',s=>s.put({id:Date.now(),game:GAMEID,url})).then(list).then(a=>Promise.all(a.slice(KEEP).map(p=>forget(p.id))));}
function forget(id){return tx('readwrite',s=>s.delete(id));}
function album(){closeOv('cele');list().catch(()=>[]).then(a=>{const c=$('#menuCard');c.className='card wide';
  c.innerHTML=`<h2>🖼️ Photo Album</h2>${a.length?`<div class="phGrid">${a.map(p=>`<button class="phThumb" data-id="${p.id}"><img src="${p.url}" alt=""></button>`).join('')}</div>`
    :`<p style="font-size:24px;font-weight:700">No photos yet. Press the big button to take one!</p>`}
    <p class="phNote">The last ${KEEP} photos stay here on this iPad. Press and hold a photo to save it.</p><div class="btns"><button class="btn green" id="phAlbX">✓ OK</button></div>`;
  c.querySelectorAll('.phThumb').forEach(b=>tap(b,()=>{const p=a.find(q=>String(q.id)===b.dataset.id);if(p){closeOv('menu');show1(p.url,p.id);}}));tap('#phAlbX',()=>{sfx.boop();closeOv('menu');});
  $('#menu').classList.add('on');speak(a.length?`Your photo album. ${a.length} ${a.length===1?'photo':'photos'}.`:'No photos yet. Press the big button to take one!');});}

const css=document.createElement('style');css.textContent=`#phUI{display:none}#world.phOn #phUI{display:block}#world.phOn>*:not(#phUI){visibility:hidden}
#phPad{position:absolute;inset:0;z-index:10;touch-action:none;pointer-events:auto}
#phUI #phDone{position:absolute;left:auto;right:24px;top:20px;z-index:31}#phUI #phAlbum{position:absolute;left:14px;bottom:30px;z-index:31}#phUI #phPose{position:absolute;left:104px;bottom:30px;z-index:31}
#phUI #phIn{position:absolute;left:auto;right:24px;top:290px;z-index:31}#phUI #phOut{position:absolute;left:auto;right:24px;top:390px;z-index:31}
#phUI #phSnap{position:absolute;left:50%;bottom:26px;width:128px;height:128px;margin-left:-64px;border-radius:50%;border:8px solid ${INK};background:#fff;box-shadow:0 6px 0 ${INK};z-index:31;padding:0}
#phSnap span{display:block;width:84px;height:84px;margin:auto;border-radius:50%;background:#ff6b6b;border:5px solid ${INK}}#phSnap:active{transform:translateY(5px);box-shadow:0 1px 0 ${INK}}
#phTip{position:absolute;left:0;right:0;top:150px;text-align:center;font-size:30px;font-weight:900;color:#fff;text-shadow:0 3px 0 ${INK},2px 2px 0 ${INK},-2px 2px 0 ${INK},2px -2px 0 ${INK},-2px -2px 0 ${INK};z-index:31;pointer-events:none;transition:opacity .6s}
#phFlash{position:absolute;inset:0;background:#fff;opacity:0;pointer-events:none;z-index:32}#phFlash.go{animation:phFl .45s ease-out}@keyframes phFl{0%{opacity:.95}100%{opacity:0}}
.phShot{display:block;width:560px;max-width:100%;border:6px solid ${INK};border-radius:18px;margin:0 auto;-webkit-touch-callout:default;-webkit-user-select:auto;user-select:auto;pointer-events:auto}
.phGrid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:6px 0}.phThumb{padding:0;border:4px solid ${INK};border-radius:16px;overflow:hidden;background:#fff;height:170px}
.phThumb img{width:100%;height:100%;object-fit:cover;display:block}.phNote{font-size:18px;font-weight:700;margin:6px 0 0}`;
document.head.appendChild(css);
window.PHOTO={PH,start,stop,snap,album,list,grab};
})();
