/* ================================================================
   Christmas Snow: the Christmas cards (25 Nov 2026, claude/christmas-snow-design.md section 11a)
   - a Christmas card for each of the 119 Christmas pups, the reindeer (Season Friend) and the nine
     unicorns in Christmas looks; on a ❄️ Seasons shelf in the Card Binder, one tab per island
     plus a 🎄 tab for the reindeer, Holly and Tinsel;
   - stats and powers as on the main card; the everyday move gets a Christmas name;
   - the island's scene in winter, a snowflake and holly frame, a holly badge, an icicle edge with
     fairy lights, and the Christmas-only Frost finish (cardlook.js rolls it);
   - packs per area, wrapped like Christmas presents; a season switcher in the Pup House.
   Hooks: window.XCARDS (cards.js), window.XCL (cards.js and cardlook.js), CLOOK.EDGE.xmas, showBook.
   ================================================================ */
(function(){
const XM=window.XMAS,XL=window.XLOOK,xp=XL.xp,PI=Math.PI,X=()=>(state&&state.sx&&state.sx.xmas)||{};
const XMOVE={herd:'Sleigh Pull',pull:'Sleigh Pull',snow:'Sleigh Pull',tug:'Sleigh Pull',rescue:'Sleigh Pull',dig:'Snow Angel',giant:'Snow Angel',sniff:'Present Wrap',point:'Present Wrap',truffle:'Present Wrap',
 zoom:'Snowball Throw',spots:'Snowball Throw',fetch:'Snowball Throw',splash:'Snowball Throw',guard:'Carol Howl',yodel:'Carol Howl',snore:'Carol Howl',cuddle:'Tinsel Twirl',wiggle:'Tinsel Twirl',rainbow:'Tinsel Twirl',cloud:'Tinsel Twirl'};
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const HOW={present:'🎁 Found in a jingling present',prints:'🐾 Found by following its paw prints in the snow',gold:'🌟 Found in a golden present'};
const dstr=d=>d&&d>1e12?new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'';
/* the same numbers as the main card (cards.js card3), worked out here so the binder is not asked while it builds its sets */
const TM={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const hs=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;},cp=(v,a,b)=>Math.max(a,Math.min(b,v));
function xcard(p,set,n,of,isl){const C=window.CARDS,B=C.breedOf(p.breed),T=C.TY(p.type),z=SZ[B.sz]||SZ.m,sh=p.shiny||p.season?10:0,st={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  st[C.STATS[hs(p.id)%4][0]]+=1;for(const k in st)st[k]=cp(st[k],1,10);
  const c={stats:st,zoom:cp(z[0]+sh,30,120),moves:[[XMOVE[B.g]||'Snowball Throw',1,z[1]],[TM[p.type]||'Pup Power',2,z[2]+sh]],col:T.col,bg:shade(T.col,.72)};
  Object.assign(c,{cid:'3:xm_'+p.id,game:3,set,n,of,src:p,base:p.id,name:p.name,breed:p.breed,type:p.type,rar:p.shiny||p.season?'sparkly':'common',fact:XL.FACT[p.id]||p.fact||'',xmas:true,xisl:isl});
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return p.id==='holly'?'the Christmas market, Pawprint Village':(A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>XM.xFound(p.id);c.foundAt=()=>{const v=X().found[p.id];return typeof v==='number'?v:0;};
  c.art=an=>critterSVG(xp(p),{anim:an,sparkly:!!(p.shiny||p.season)});
  c.hint=()=>XM.opened()?`${p.name} is hiding in ${AREAS[p.area]?AREAS[p.area].name:'the village'} in Christmas Snow. ${p.hint||''}`:'Christmas Snow opens after the Great Pup Conga World Tour!';
  c.back=()=>{const d=c.foundAt(),h=(X().how||{})[p.id];return [`🎄 Found in Christmas Snow${d?' on '+dstr(d):''}`,`📍 ${c.home()}`,HOW[h]||'🎁 Found in Christmas Snow','🎁 Brought its present home to the reindeer\'s sack'];};
  return c;}
function unicard(I,set,n,of){const u=I.boss.uni,C=window.CARDS,T=C.TY(I.type);const c={cid:'3:xm_'+u.id,game:3,set,n,of,src:u,base:u.id,name:u.name,breed:u.breed,type:I.type,rar:'unicorn',uni:true,xmas:true,xisl:I.id,
  fact:`${u.name}'s Christmas lesson: ${XM.LESSON[u.id]||'Christmas is for sharing.'}`,zoom:120,moves:[['Rainbow Gallop',1,30],['Star Sparkle',3,100]],col:T.col,bg:'#efe6ff',stats:{spd:9,brn:9,cud:10,brv:9}};
  c.home=()=>I.name;c.earned=()=>!!(X().sp||{})[I.id];c.foundAt=()=>(X().sp||{})[I.id]||0;c.art=an=>critterSVG(xp(u),{anim:an});
  c.hint=()=>`Find ${XM.NEED} Christmas pups on ${I.name}, and ${u.name} will bring back a sparkle of the Christmas Star.`;
  c.back=()=>{const d=c.foundAt();return [`🌟 Brought back a sparkle of the Christmas Star${d?' on '+dstr(d):''}`,`🦄 ${I.name}`,`💬 ${XM.LESSON[u.id]||''}`];};return c;}
function deercard(set,n,of){const c={cid:'3:xm_deer',game:3,set,n,of,src:{id:'xdeer'},base:'xdeer',get name(){return XM.deer().name;},breed:'Reindeer',type:'snow',rar:'friend',xmas:true,xisl:'village',
  fact:'Reindeer eyes change colour, golden in summer and deep blue in winter. And reindeer are the only deer where the girls grow antlers too!',zoom:100,moves:[['Sleigh Pull',1,30],['Christmas Flight',3,90]],col:'#9a5a2e',bg:'#f3e6d6',stats:{spd:9,brn:7,cud:10,brv:7}};
  c.home=()=>'The North Pole reindeer school';c.earned=()=>XM.named();c.foundAt=()=>XM.named()&&X().deer.at||0;c.art=()=>XM.deerSVG().replace('<svg ','<svg class="pup" ');
  c.hint=()=>'Meet the young reindeer when Christmas Snow begins!';
  c.back=()=>[`🦌 Named by Seb${c.foundAt()?' on '+dstr(c.foundAt()):''}`,'📍 The North Pole reindeer school','🎓 On its very first practice flight',X().done?'🛷 Flew the Present Run with Seb!':'🌟 Getting braver with every sparkle'];return c;}
/* the sets, one per island and a special one */
const SETS={};
function mkSet(key){if(SETS[key])return SETS[key];let S;
  if(key==='xmas'){const L=[];S={id:'3:x_xmas',game:3,x:true,season:'xmas',isl:'x_xmas',name:'Christmas Snow',short:'Christmas',icon:'🎄',open:()=>XM.opened(),lockSay:()=>'Christmas Snow opens after the Great Pup Conga World Tour!',cards:L};
    L.push(deercard(S.id,1,3),xcard(XL.XPUPS.holly,S.id,2,3,'village'),xcard(XL.XPUPS.tinsel,S.id,3,3,'village'));}
  else{const I=islandOf(key),P=XM.islX(I),of=P.length+1,L=P.map((p,i)=>xcard(p,'3:x_'+key,i+1,of,key));L.push(unicard(I,'3:x_'+key,of,of));
    S={id:'3:x_'+key,game:3,x:true,season:'xmas',isl:'x_'+key,name:`${I.name} at Christmas`,short:I.name.split(' ')[0],icon:I.icon,open:()=>XM.opened(),lockSay:()=>'Christmas Snow opens after the Great Pup Conga World Tour!',cards:L};}
  return (SETS[key]=S);}
function entry(key){const I=key!=='xmas'&&islandOf(key),areas=key==='xmas'?['village']:I.areas.map(a=>a.id).filter(a=>XM.areaX(a).length),pups=key==='xmas'?[XL.XPUPS.holly,XL.XPUPS.tinsel]:XM.islX(I);
  const mine=cid=>cid.indexOf('3:xm_')===0&&(cid==='3:xm_deer'?key==='xmas':cid==='3:xm_'+(I&&I.boss.uni.id)||pups.some(p=>cid==='3:xm_'+p.id));
  return {isl:'x_'+key,season:'xmas',keys:()=>areas.map(a=>'x:xm:'+a),set:()=>mkSet(key),
    ids(){if(!state)return [];const out=pups.filter(p=>XM.xFound(p.id)).map(p=>'3:xm_'+p.id);if(key==='xmas'&&XM.named())out.unshift('3:xm_deer');if(I&&(X().sp||{})[I.id])out.push('3:xm_'+I.boss.uni.id);return out;},
    key(cid){if(!mine(cid))return undefined;const id=cid.slice(5),p=XM.xpup(id);return p&&XM.kindOf?'x:xm:'+p.area:null;},
    done(k){const a=k.slice(5);return XM.areaX(a).every(p=>XM.xFound(p.id));},
    info(k){const a=k.slice(5),A=AREAS[a];return {k,isl:'x_'+key,icon:a==='village'?'🎄':(A&&A.icon)||'🎁',name:`${A?A.name:'Christmas'} at Christmas`,short:A?A.name:'Christmas',xmas:true};},
    say(k,c){const a=k.slice(5),A=AREAS[a],left=XM.areaX(a).filter(p=>!XM.xFound(p.id)).length;return `${c.name}'s Christmas card is waiting in the ${A?A.name:''} Christmas pack. Find ${left} more Christmas ${left>1?'pups':'pup'} there to open it!`;}};}
window.XCARDS=(window.XCARDS||[]).concat(['xmas'].concat(ISLANDS.map(I=>I.id)).map(entry));

/* ---------------- the Christmas look ---------------- */
const K=INK,W='#ffffff';
const fl=(x,y,r,o)=>`<g stroke="${W}" stroke-width="${r/3.2}" stroke-linecap="round" opacity="${o}"><path d="M${x-r} ${y}h${2*r}M${x-r/2} ${y-r*.87}l${r} ${r*1.74}M${x+r/2} ${y-r*.87}l${-r} ${r*1.74}"/></g>`;
const holly=(x,y,s,o)=>`<g opacity="${o}" transform="translate(${x} ${y}) scale(${s})"><path d="M-12 0 L-8 -4 L-4 -2 L0 -6 L-4 2 L-8 4 Z" fill="#2f8a4a"/><path d="M12 0 L8 -4 L4 -2 L0 -6 L4 2 L8 4 Z" fill="#2f8a4a"/><circle cx="-2" cy="-5" r="2.6" fill="#e8302a"/><circle cx="2.5" cy="-4" r="2.6" fill="#e8302a"/></g>`;
const PATX=`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">${fl(14,14,7,.5)}${fl(46,44,5,.4)}${holly(46,16,.8,.6)}${holly(16,48,.7,.5)}</svg>`;
function snow(i){const R=seed(i.length*31+7);let s=`<path d="M0 166 Q50 154 100 164 T200 160 V190 H0Z" fill="#ffffff" opacity=".95"/><path d="M0 176 Q60 170 120 178 T200 174 V190 H0Z" fill="#eaf4ff"/>`;
  for(let k=0;k<14;k++)s+=`<circle cx="${(R()*200).toFixed(1)}" cy="${(R()*150).toFixed(1)}" r="${(1.2+R()*2).toFixed(1)}" fill="#fff" opacity=".9"/>`;
  if(i==='reef')s+=`<g transform="translate(160 160)">${[0,1,2,3].map(k=>`<path d="M0 0 l${-14+k*2} ${-20-k*12} M0 0 l${14-k*2} ${-20-k*12}" stroke="#ff7f9a" stroke-width="3" stroke-linecap="round"/>`).join('')}<circle cx="0" cy="-66" r="4" fill="#ffd23f"/></g>`;
  else s+=`<g transform="translate(176 166)"><path d="M0 -42 L-13 -14 H13 Z M0 -30 L-16 0 H16 Z" fill="#2f8a4a"/><rect x="-2.5" y="0" width="5" height="5" fill="#8a5a32"/><circle cx="0" cy="-43" r="3" fill="#ffd23f"/>`+[[-6,-20,'#ff4f5e'],[5,-12,'#5cb8ff'],[-4,-5,'#ffd23f']].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="2.2" fill="${q[2]}"/>`).join('')+'</g>';
  return s;}
const EDGEX=()=>{let s='',d='M0 0 H400 V8';for(let x=400;x>0;x-=16)d+=` L${x-8} ${16+((x/16)%3)*7} L${x-16} 8`;s+=`<path d="${d} Z" fill="#ffffff" stroke="#a8cce8" stroke-width="1.4"/>`;
  let w='M8 30';for(let y=30;y<540;y+=40)w+=` Q2 ${y+20} 8 ${y+40}`;s+=`<path d="${w}" fill="none" stroke="#2a3a2a" stroke-width="1.6"/><path d="${w.replace(/(\d+(\.\d+)?) /,'392 ').replace(/Q2 /g,'Q398 ').replace(/ 8 /g,' 392 ')}" fill="none" stroke="#2a3a2a" stroke-width="1.6"/>`;
  const B=['#ff4f5e','#ffd23f','#5cb8ff','#5fe07a','#ff7fd0'];let k=0;for(let y=50;y<540;y+=40){[6,394].forEach(x=>{s+=`<ellipse class="twk" style="animation-delay:${(k%5)*.3}s" cx="${x}" cy="${y}" rx="3.6" ry="5" fill="${B[k%5]}" stroke="${K}" stroke-width="1"/>`;k++;});}
  for(let x=30;x<380;x+=34){s+=`<ellipse class="twk" style="animation-delay:${(k%5)*.3}s" cx="${x}" cy="557" rx="4" ry="3.2" fill="${B[k%5]}" stroke="${K}" stroke-width="1"/>`;k++;}
  return s+[[14,24],[386,24]].map(q=>holly(q[0],q[1],1.3,1)).join('')+[[16,548],[384,548]].map(q=>fl(q[0],q[1],8,1)).join('');};
if(window.CLOOK&&CLOOK.EDGE)CLOOK.EDGE.xmas=EDGEX;
function packSVG(s){const n=s.n!=null?s.n:(s.cards||[]).length;return `<svg viewBox="0 0 200 270" xmlns="http://www.w3.org/2000/svg"><g class="xbow"><path d="M100 46 q-46 -40 -56 -8 q20 16 56 8 q46 -40 56 -8 q-20 16 -56 8" fill="#ffd23f" stroke="#5b4636" stroke-width="5" stroke-linejoin="round"/><circle cx="100" cy="44" r="12" fill="#ffd23f" stroke="#5b4636" stroke-width="5"/></g>`+
  `<rect x="20" y="56" width="160" height="200" rx="14" fill="#d9363e" stroke="#5b4636" stroke-width="5"/><rect x="88" y="56" width="24" height="200" fill="#ffd23f"/><rect x="20" y="140" width="160" height="24" fill="#ffd23f"/>`+
  [[44,86],[150,96],[46,214],[156,222],[62,124],[140,190]].map(q=>fl(q[0],q[1],7,.9)).join('')+`<circle cx="100" cy="152" r="36" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="168" text-anchor="middle" font-size="40">${s.icon||'🎄'}</text>`+
  `<rect x="34" y="226" width="132" height="34" rx="12" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="251" text-anchor="middle" font-size="21" font-weight="900" fill="#5b4636" font-family="Arial">${n} card${n===1?'':'s'}</text></svg>`;}
function openPack(P,pk){XM.snd.bells(10);setTimeout(()=>{const b=pk&&pk.querySelector('.xbow');if(b)b.classList.add('pop');XM.snd.bells(6);},500);}
window.XCL={pat:()=>PATX,snow,packSVG,open:openPack,xcard};
window.SEALOOK=Object.assign(window.SEALOOK||{},{'x:':{pat:()=>PATX,over:snow,edge:'xmas',badge:'🎄'}});window.SEAPACK=Object.assign(window.SEAPACK||{},{x_:{packSVG,open:openPack}});

/* ---------------- the Pup House season switcher ---------------- */
/* the Pup House season switcher (25 Nov: one picker for every season in window.SEASONS) */
let BS='';
const seasL=()=>Object.values(window.SEASONS||{}).sort((a,b)=>a.order-b.order).filter(S=>S.opened()||S.nFound());
const _sb=showBook;showBook=function(isl){_sb.apply(this,arguments);const host=$('#book');if(!host)return;let sw=$('#xBookStrip');const SL=seasL();if(BS&&!SL.some(S=>S.id===BS))BS='';
  const S=BS?window.SEASONS[BS]:null,look=()=>{host.dataset.sea=BS;$('#bookH').textContent=S?`${S.tag} Pup House`:'🏠 Pup House';};/* each season has its own Pup House look */
  if(!SL.length){if(sw)sw.remove();look();return;}
  /* 26 Nov: the islands and every open season are buttons down the left of the Pup House, one tap each (was a menu at the top right) */
  if(!sw){sw=el('div','','');sw.id='xBookStrip';host.appendChild(sw);}sw.innerHTML='';
  const tot=X=>{if(!X.book){const L=Object.values(PUPS).filter(p=>!p.sci);return `${L.filter(p=>isFound(p.id)).length}/${L.length}`;}return `${ISLANDS.reduce((a,I)=>a+X.book.islN(I),0)}/${ISLANDS.reduce((a,I)=>a+X.book.islX(I).length,0)}`;};
  [{id:'',icon:'🏝️',short:'Islands'}].concat(SL).forEach((X,i)=>{const b=el('button','xbs'+(X.id===BS?' sel':''),`<span class="i">${X.icon}</span><small>${X.short}</small><b>${tot(X)}</b>`);
    b.style.top=(196+i*78)+'px';tap(b,()=>{if(X.id===BS){sfx.boop();return;}BS=X.id;sfx.chime();showBook(bookIsl);});sw.appendChild(b);});
  look();if(!S)return;const B=S.book;
  const tabs=$('#bookTabs');ISLANDS.forEach(I=>{const b=[...tabs.children].find(t=>t.textContent.indexOf(I.icon)===0);if(b&&b.querySelector('small'))b.querySelector('small').textContent=`${B.islN(I)}/${B.islX(I).length}`;});
  const I=islandOf(bookIsl);if(!I)return;const gr=$('#bookGrid');gr.innerHTML='';gr.className='';
  B.islX(I).forEach(p=>{if(!B.found(p.id)){const b=el('button','pcard miss',`<div class="q">?</div><span>${B.tag} ${AREAS[p.area].name}</span>`);tap(b,()=>{sfx.boop();say(`A ${B.word} pup is still hiding in ${AREAS[p.area].name}, in ${S.name}.`);});gr.appendChild(b);return;}
    const b=el('button','pcard',`${pupBox(B.xp(p),{anim:false})}<span>${p.name}</span><small>${p.breed}</small><small>${B.tag} ${S.short}</small>`);
    tap(b,()=>card({art:pupBox(B.xp(p)),h:p.name,h3:`${B.tag} ${S.name} · ${p.breed}`,p:B.fact(p.id)||p.fact,btns:[['OK','green']]}));gr.appendChild(b);});
  say(`${B.isl(I)}. ${B.islN(I)} of ${B.islX(I).length} ${B.word} pups found.`);};


/* the Christmas Snow look: frosty blue with gentle falling snow (Pup House pale like its green, binder deep like its green) */
const FLK=(()=>{const f=(x,y,r,o)=>`<g transform="translate(${x} ${y})" stroke="#fff" stroke-width="${r/4}" stroke-linecap="round" opacity="${o}">${[0,60,120].map(a=>`<path transform="rotate(${a})" d="M0 ${-r}V${r}M${-r*.35} ${-r*.75}L0 ${-r*.45}L${r*.35} ${-r*.75}M${-r*.35} ${r*.75}L0 ${r*.45}L${r*.35} ${r*.75}"/>`).join('')}</g>`,
  d=(x,y,r,o)=>`<circle cx="${x}" cy="${y}" r="${r}" fill="#fff" opacity="${o}"/>`;
  const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300">${f(40,50,11,.95)+f(205,25,8,.8)+f(150,150,13,.9)+f(265,205,9,.85)+f(70,250,8,.8)+d(115,75,4,.9)+d(250,110,3.5,.8)+d(30,170,3.5,.85)+d(185,265,4,.9)+d(95,205,2.5,.7)+d(280,30,2.5,.7)}</svg>`;
  return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';})();
const BANK='url("data:image/svg+xml,'+encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="70" preserveAspectRatio="none"><path d="M0 40C90 14 170 18 250 34S420 58 520 32 700 8 800 30 950 52 1024 26V70H0Z" fill="#fff"/><path d="M0 52C120 36 230 40 330 50S560 62 680 48 900 40 1024 50V70H0Z" fill="#eaf5fd"/></svg>')+'")';
const css=document.createElement('style');css.textContent=`.wemb.xh{left:27px;background:#eaf6ff}.wemb.big.xh{left:48px}
.mc.fin-f .finsh,.tc.fin-f .finsh{background-image:radial-gradient(#fff 1.6px,transparent 2.2px),radial-gradient(#fff 1px,transparent 1.6px);background-size:26px 26px,17px 17px;background-position:0 0,8px 5px;animation:xfrost 7s linear infinite;opacity:.85}
@keyframes xfrost{from{background-position:0 0,8px 5px}to{background-position:26px 260px,-9px 175px}}
#bdTabs .tab.sea{background:#dff1ff}#bdTabs .tab.xs.sel{background:#d9f5ff}
.pq2pack .xbow{transform-origin:100px 44px;transition:transform .5s}.pq2pack .xbow.pop{transform:translateY(-70px) rotate(-30deg) scale(1.2);opacity:0;transition:transform .6s,opacity .6s .3s}
#xBookStrip{position:absolute;left:0;top:0;width:0;height:0;z-index:20}
.xbs{position:absolute;left:14px;width:80px;height:70px;border-radius:20px;border:4px solid #5b4636;background:#fff;box-shadow:0 4px 0 #5b4636;display:flex;flex-direction:column;align-items:center;justify-content:center;font:inherit;font-weight:900;color:#5b4636;padding:0;gap:1px}
.xbs .i{font-size:29px;line-height:1}.xbs small{font-size:12.5px;line-height:1.05;letter-spacing:-.3px;white-space:nowrap}.xbs b{font-size:11px;line-height:1;opacity:.75}
.xbs.sel{background:#fff2b8;box-shadow:0 0 0 4px #ffd23f,0 4px 0 4px #5b4636}.xbs:active{transform:translateY(3px);box-shadow:0 1px 0 #5b4636}
#book[data-sea=xmas]{background:${BANK} bottom/100% 60px no-repeat,linear-gradient(#b5daf3,#d9eefb)}
#binder[data-sea=xmas]{background:#2f6aa8}#binder[data-sea=xmas] .bcover{border-color:rgba(255,255,255,.6)}
#book[data-sea=xmas],#binder[data-sea=xmas]{isolation:isolate}
#book[data-sea=xmas]::before,#binder[data-sea=xmas]::before{content:'';position:absolute;z-index:-1;left:0;right:0;top:-300px;height:1068px;background-image:${FLK};background-size:300px 300px;pointer-events:none;animation:xsnowfall 16s linear infinite;will-change:transform}
#binder[data-sea=xmas]::before{opacity:.55}
@keyframes xsnowfall{from{transform:translateY(0)}to{transform:translateY(300px)}}
@media (prefers-reduced-motion:reduce){#book[data-sea=xmas]::before,#binder[data-sea=xmas]::before{animation:none}}
#book[data-sea=xmas] .tab{opacity:1;background:#eef6fc}#book[data-sea=xmas] .tab.sel{background:#ffd6dc}#binder[data-sea=xmas] #bdTabs .tab.sel{background:#ffd6dc}
`;document.head.appendChild(css);
})();
