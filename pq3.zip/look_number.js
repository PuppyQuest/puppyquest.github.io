/* Number Kingdom look (22 Nov 2026): a number museum inside a giant
   cube. Each area is a round gallery with a polished tiled floor, tall
   walls with pilasters and gold rails, framed numbers on the walls,
   giant numbers hanging from a skylight ceiling, and light beams. The
   camera stays inside the walls. The Secret Library is unchanged. */
(function(){
const TX={},MT={};
function artTex(key,draw){if(TX[key])return TX[key];const cv=document.createElement('canvas');cv.width=cv.height=256;const g=cv.getContext('2d');draw(g);return TX[key]=new THREE.CanvasTexture(cv);}
function numArt(str,fg,bg){return artTex('n'+str+fg+bg,g=>{g.fillStyle=bg;g.fillRect(0,0,256,256);g.fillStyle=fg;g.font=`bold ${str.length>2?110:str.length>1?150:190}px Arial Rounded MT Bold, Arial, sans-serif`;g.textAlign='center';g.textBaseline='middle';g.fillText(str,128,140);});}
function shapeArt(k,fg,bg){return artTex('s'+k+fg+bg,g=>{g.fillStyle=bg;g.fillRect(0,0,256,256);g.fillStyle=fg;g.strokeStyle='#3a3338';g.lineWidth=8;g.beginPath();
  if(k==='circle')g.arc(128,128,80,0,6.283);else if(k==='square')g.rect(52,52,152,152);else if(k==='triangle'){g.moveTo(128,40);g.lineTo(220,206);g.lineTo(36,206);g.closePath();}
  else if(k==='star'){for(let i=0;i<10;i++){const r=i%2?40:95,a=-Math.PI/2+i*Math.PI/5;g.lineTo(128+Math.cos(a)*r,135+Math.sin(a)*r);}g.closePath();}
  else if(k==='hexagon'){for(let i=0;i<6;i++){const a=i*Math.PI/3;g.lineTo(128+Math.cos(a)*90,128+Math.sin(a)*90);}g.closePath();}
  else{g.moveTo(128,30);g.lineTo(215,128);g.lineTo(128,226);g.lineTo(41,128);g.closePath();}g.fill();g.stroke();});}
function artMat(tex,side){const k=tex.uuid+(side||0);return MT[k]||(MT[k]=new THREE.MeshBasicMaterial({map:tex,side:side||THREE.FrontSide}));}
let PL=null;
/* framed pictures round the wall, giant numbers hanging from the ceiling, and beams of light */
function gallery(A,G0){const R=A.R+1.2,trim=G0.trim||'#c9a86a',art=G0.art,n=art.length;if(!PL)PL=new THREE.PlaneGeometry(1,1);
  for(let i=0;i<14;i++){const a=(i+.5)/14*Math.PI*2,x=Math.cos(a)*(R-.75),z=Math.sin(a)*(R-.75);if(W.exits.some(e=>Math.hypot(x-e.x,z-e.z)<9))continue;if((A.edgeGaps||[]).some(g=>Math.hypot(x-g[0],z-g[1])<g[2]+3))continue;
    const it=art[i%n],m=new THREE.Mesh(PL,artMat(it.s?shapeArt(it.s,it.fg,it.bg):numArt(it.t,it.fg,it.bg)));m.scale.set(6,6,1);m.position.set(x,11,z);m.lookAt(0,11,0);W.ag.add(m);
    const fx=Math.cos(a)*(R-.65),fz=Math.sin(a)*(R-.65);I('box',trim,6.8,6.8,.12,fx,11,fz,0,-a+Math.PI/2,0);I('box',trim,3,.5,.3,Math.cos(a)*(R-.8),6.8,Math.sin(a)*(R-.8),0,-a+Math.PI/2,0);}
  const hang=G0.hang||art;for(let i=0;i<5;i++){const a=i/5*6.283+.4,r=A.R*.42,x=Math.cos(a)*r,z=Math.sin(a)*r,y=15.5+(i%2)*1.5,it=hang[i%hang.length];
    const m=new THREE.Mesh(PL,artMat(it.s?shapeArt(it.s,it.fg,it.bg):numArt(it.t,it.fg,it.bg),THREE.DoubleSide));m.scale.set(5,5,1);m.position.set(x,y,z);W.ag.add(m);
    I('cyl','#8a8f99',.03,22-y-2.5,.03,x,y+2.5+(22-y-2.5)/2,z);W.ticks.push(()=>{m.rotation.y=W.t*.25+i;});}
  for(let i=0;i<4;i++){const a=i/4*6.283+.9,r=A.R*(.3+(i%2)*.3),x=Math.cos(a)*r,z=Math.sin(a)*r,b=new THREE.Mesh(G.cone,new THREE.MeshBasicMaterial({color:'#fff8dc',transparent:true,opacity:.09,depthWrite:false}));
    b.scale.set(3.4,21.6,3.4);b.position.set(x,10.8,z);W.ag.add(b);W.disp.push(b.material);}}
const D=(t,fg,bg)=>({t,fg,bg:bg||'#fffaf0'}),S=(s,fg,bg)=>({s,fg,bg:bg||'#fffaf0'});
const BOLD=['#e8423a','#3d8fe0','#3fae5a','#ffb000','#8a5ad8','#ff6b9a'];
const MUSEUM={indoor:true,hf:()=>0,light:'museum',biome:'museum',noEdgeTrees:true,fog:[80,260],gmix:(x,z)=>(Math.sin(x*.11+Math.sin(z*.07)*2.2)+1)*.3,hedgeC:'#c9a86a'};
const G={
  ntown:{wall:'#f0e6d2',floor:['#f4eee2','#e8dfcc'],grout:'#d2c6ae',art:[0,1,2,3,4,5,6,7,8,9].map(i=>D(String(i),BOLD[i%6]))},
  towers:{wall:'#dde8f4',floor:['#f2f5f8','#e2e8ee'],grout:'#c6ced8',art:[2,4,6,8,10,12,5,10,15,20,25,30].map((v,i)=>D(String(v),BOLD[i%6]))},
  river:{wall:'#d4eeea',floor:['#eef6f4','#ddebe8'],grout:'#bfd4d0',art:Array.from({length:14},(_,i)=>D(String(i*3),BOLD[i%6]))},
  shapes:{wall:'#e6def4',floor:['#f4f0fa','#e6e0f0'],grout:'#cec6dc',art:['circle','triangle','square','star','hexagon','diamond'].map((s,i)=>S(s,BOLD[i]))},
  bakery:{wall:'#f8e2cc',floor:['#faf0e4','#eedfcc'],grout:'#dcc8b0',art:['½','¼','¾','⅓','½','⅛'].map((t,i)=>D(t,BOLD[i]))},
  castle:{wall:'#a84444',trim:'#e0b84a',floor:['#efe4cc','#e2d4b6'],grout:'#c8b48c',skirt:'#5a2a2a',ceil:'#f2e6cc',
    art:['I','II','III','IV','V','VI','VII','VIII','IX','X','XI','XII'].map(t=>D(t,'#7a2a2a','#f6e6b8')),hang:[D('7','#e0b84a','#7a2a2a'),D('100','#e0b84a','#7a2a2a'),D('X','#e0b84a','#7a2a2a')]}};
Object.keys(G).forEach(id=>{const g=G[id],A=AREAS[id];if(!A)return;
  restyle(id,Object.assign({},MUSEUM,{sky:g.wall,fogC:g.wall,ground:g.floor[0],ground2:g.floor[1],grid:{step:3,c:g.grout,w:.07},
    edge:{style:'museum',wall:g.wall,trim:g.trim||'#c9a86a',skirt:g.skirt||'#7a4f2a',ceil:g.ceil||'#f6f1e6',h:22},edgeGaps:id==='ntown'?[[-21.9,48.5,4],[21.9,48.5,4]]:[]}),
    A2=>{gallery(A2,g);
      if(id==='ntown')[-1,1].forEach(k=>{const x=k*21.9,z=48.5,ry=-Math.atan2(z,x)+Math.PI/2;I('box','#26232e',12,6,7,x+k*6.5,3,z,0,0,0);I('box','#c9a86a',8,1,1.2,x,6.4,z,0,ry,0);[-1,1].forEach(q=>I('box','#c9a86a',1,6.4,1.2,x+Math.cos(-ry)*3.6*q,3.2,z-Math.sin(-ry)*3.6*q,0,ry,0));});});});
AREAS.ntown.hello='Welcome to Number Kingdom, a giant number museum inside a huge cube! Two pups are hiding in Number Town. Say hello to Professor Hoot!';
})();
