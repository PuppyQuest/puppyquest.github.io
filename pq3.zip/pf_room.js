/* ================================================================
   Puppy Families (26 Nov 2026, claude/puppy-families-design.md section 8): the Puppy Room.
   - a cosy room through a door in Seb's Den; four families out at once (Seb picks them);
   - care moments, three for each stage (any mix), then a nap scene and the puppies wake up bigger:
     snoozy newborn (cosy blanket, quiet time, weigh-in), wobbly puppy (soupy mash, first toys, Doctor Seb),
     bouncy big puppy (Puppy School, a family walk, bath and brush at the Pup Spa);
   - no clocks: nothing ever gets hungry or sad, and nothing goes wrong if Seb doesn't play;
   - Brahms's Lullaby (published 1868) as a music box.
   ================================================================ */
(function(){
const PL=window.PFLOOK,PF=window.PF,PI=Math.PI,P=id=>PUPS[id];
const X=()=>PF.S();
/* which families are out in the room: Seb's pick, or the basket family and the newest ones */
function roomIds(){const H=PF.homes(),X0=PF.S0()||{};let L=(X0.room||[]).filter(id=>H.indexOf(id)>=0);
  if(!L.length){L=H.slice().sort((a,b)=>((PF.famOf(b)||{}).at||0)-((PF.famOf(a)||{}).at||0));const b=X0.basket&&X0.basket.pid;if(b&&L.indexOf(b)>=0)L=[b].concat(L.filter(q=>q!==b));}
  return L.slice(0,4);}
const FP=[[-4.4,-3.4],[4.4,-3.4],[-4.4,2.2],[4.4,2.2]];
/* ---------------- the room ---------------- */
function roomBuild(){
  for(let i=0;i<12;i++)I('box',i%2?'#f6dfe6':'#fbe8ee',24,.05,1.55,0,.03,-8.4+i*1.55);
  const wc='#d6ecff';I('box',wc,24,7,.4,0,3.5,-9.4);I('box',wc,.4,7,19,-12.2,3.5,0);I('box',wc,.4,7,19,12.2,3.5,0);I('box','#ffffff',24.4,.5,.5,0,.25,-9.2);I('box','#ffffff',.5,.5,19,-12,.25,0);I('box','#ffffff',.5,.5,19,12,.25,0);
  for(let i=0;i<9;i++)I('sph',['#ffd23f','#ff9ecb','#8fd0ff'][i%3],.22,.22,.06,-10+i*2.5,6.2+Math.sin(i)*.3,-9.15,0,0,0,true);
  I('box','#9bdcff',4,3,.1,-1,4.2,-9.15,0,0,0,true);I('box','#ffffff',4.4,3.4,.08,-1,4.2,-9.2);I('box','#ffffff',.12,3,.15,-1,4.2,-9.1);
  rect(-12.6,-9.8,12.6,-9);rect(-12.6,-9.8,-11.8,9.8);rect(11.8,-9.8,12.6,9.8);rect(-12.6,9.2,12.6,9.8);
  /* the puppy pen: a soft rug and a low white fence */
  I('cyl','#fff0c8',9.5,.05,6.6,0,.06,-1.2);I('cyl','#ffd9a8',8.2,.06,5.6,0,.07,-1.2);
  for(let a=0;a<6.28;a+=.22){const x=Math.cos(a)*10.4,z=-1.2+Math.sin(a)*7.2;if(z>4.8&&Math.abs(x)<2.6)continue;I('box','#ffffff',.18,.9,.18,x,.45,z);}
  /* blankets, a toy box, the scales, the bookshelf and the Puppy School mat */
  FP.forEach((q,i)=>{I('cyl',['#c9b6ff','#9ae0b0','#ffb8d0','#a8dcff'][i],1.9,.08,1.5,q[0],.1,q[1]);});
  I('box','#ff9a3c',2,1.3,1.4,10,.65,-6.5);I('box','#e8423a',2.1,.2,1.5,10,1.35,-6.5);spr('🧸',.9,9.6,1.9,-6.5);spr('⚽',.6,10.4,1.8,-6.3);col(10,-6.5,1.3);
  I('box','#c9905f',2.4,1,1.4,9.5,.5,6);I('cyl','#e6e6ee',.9,.2,.9,9.5,1.1,6);I('cyl','#ffffff',.5,.4,.5,9.5,1.6,6.4,PI/2,0,0);col(9.5,6,1.4);
  I('box','#9b6a43',4,4,.9,-8.8,2,-8.8);for(let k=0;k<3;k++)I('box','#7a4f2a',3.8,.12,.8,-8.8,.9+k*1.2,-8.75);spr('📖',.9,-8.8,2.2,-8.3);['📕','📗','📘'].forEach((e,i)=>spr(e,.6,-10+i*.9,1.1,-8.3));rect(-10.8,-9.3,-6.8,-8.2);
  I('box','#9ae0b0',3.2,.06,2.4,-9,.06,5.6);spr('🔄',.9,-9,1.6,5.6);
  /* the door back to the Den */
  I('box','#ffffff',.25,4.8,3.2,-12,2.4,5);I('box','#c9905f',.3,4.3,2.6,-11.95,2.15,5);I('sph','#ffd23f',.25,.25,.25,-11.75,2.1,5.9);{const dl=label('🚪 Den',3);dl.position.set(-11.4,5.2,5);W.ag.add(dl);}
  W.things.push({x:3.8,z:6.6,r:3,icon:'💗',label:'Look after the puppies',act:()=>openCare()});
  W.things.push({x:-8.8,z:-6.8,r:3,icon:'📖',label:'Pup Book',act:()=>{if(window.PFBOOK)PFBOOK.open();}});
  W.things.push({x:-9,z:5.4,r:2.8,icon:'🔄',label:'Choose families',act:chooseFams});
  W.things.push({x:9.5,z:4.4,r:2.8,icon:'⚖️',label:'Scales',act:()=>{const L=fams(0);if(L.length)return run('weigh',L);say(window.PFR3&&PFR3.doctor?'The scales are for newborn puppies. Doctor Seb\'s check-up weighs the bigger ones!':'The scales are for newborn puppies.');}});
  {const l=label('💗 Puppy care',3.6);l.position.set(3.8,2.4,6.8);W.ag.add(l);I('cyl','#ff9ecb',.9,.6,.9,3.8,.3,6.8);spr('🧺',1,3.8,1.1,6.8);col(3.8,6.8,1);}
  if(window.PFR3&&PFR3.build)try{PFR3.build();}catch(e){console.warn('pf room extras',e);}
  /* the families */
  const R=seed(31);roomIds().forEach((id,k)=>{const p=P(id),f=PF.famOf(id),st=f.st||0,c=FP[k];
    const g=pup3D(p,p.shiny||bestFriend(id));g.rotation.y=PI*(.85+k*.1);if(st===0)g.userData.nap=true;add(g,c[0],c[1]);W.ticks.push(()=>animPup(g,W.t,false));col(c[0],c[1],1);
    const lb=label(`${p.name}'s family`,4.6);lb.position.set(c[0],st===2?3.3:3,c[1]);W.ag.add(lb);
    [0,1,2].forEach(i=>{const q=PL.p3(p,i,st,{bd:f.bd});if(st===0){const o=[[.95,.6],[1.15,-.1],[.75,-.8]][i];q.rotation.y=PI*(.2+i*.4);add(q,c[0]+o[0],c[1]+o[1]);W.ticks.push(()=>PL.anim(q,W.t,false));return;}
      const w={g:q,x:c[0]+Math.cos(i*2.1)*1.4,z:c[1]+Math.sin(i*2.1)*1.4,tx:0,tz:0,wait:R()*2,c,h:R()*6,flop:0};w.tx=w.x;w.tz=w.z;add(q,w.x,w.z);
      W.ticks.push(dt=>{w.wait-=dt;const dx=w.tx-w.x,dz=w.tz-w.z,d=Math.hypot(dx,dz);let mv=false;const sp=st===1?1.1:2.2;
        if(w.flop>0){w.flop-=dt;q.rotation.z=Math.min(1.3,(1.2-w.flop)*4);if(w.flop<=0)q.rotation.z=0;animPup(q,W.t,false);return;}
        if(d>.15){mv=true;w.x+=dx/d*sp*dt;w.z+=dz/d*sp*dt;w.h=lerpAng(w.h,Math.atan2(dx,dz),Math.min(1,dt*6));}
        else if(w.wait<0){const a=R()*6.28,r=1+R()*1.6;w.tx=c[0]+Math.cos(a)*r;w.tz=c[1]+Math.sin(a)*r;w.wait=1.5+R()*4;if(st===1&&R()<.18)w.flop=1.2;}
        q.position.set(w.x,0,w.z);q.rotation.y=w.h;PL.anim(q,W.t,mv);});});});}
AREAS.pfroom={id:'pfroom',name:'Puppy Room',icon:'🐶',R:12,rect:{x1:-12,z1:-9,x2:12,z2:9},noHedge:true,noEnrich:true,ground:'#fbe8ee',sky:'#fff3f6',fogC:'#fff3f6',fog:[80,300],camD:9,camH:4.8,start:[0,7.6,PI],hf:()=>0,
  hello:'This is the Puppy Room! Tap 💗 to look after the puppies. They grow up with your help.',
  exits:[{x:-12,z:5,to:'den',arrive:[11.6,6.5,-PI/2],name:'Back to the Den',icon:'🚪',noArch:true,noLabel:true}],build:roomBuild};

/* ---------------- care moments ---------------- */
const CARE={
  blanket:{st:[0],icon:'🧣',name:'Cosy blanket',how:'Tap each puppy to tuck it in under a cosy blanket.',fact:'Newborn puppies can\'t keep themselves warm yet, so they snuggle together and next to their mum.'},
  quiet:{st:[0],icon:'🤫',name:'Quiet time',how:'Newborn puppies need lots of sleep. Dim the lamp, and tiptoe!',fact:PL.FACT[0][2]},
  weigh:{st:[0],icon:'⚖️',name:'Weigh-in',how:'Put a puppy on the kitchen scales.',fact:PL.FACT[0][3]},
  mash:{st:[1],icon:'🥣',name:'Soupy mash',how:'Stir the warm puppy mash, then give every puppy a bowl.',fact:PL.FACT[1][3]},
  toys:{st:[1,2],icon:'⚽',name:'First toys',how:'Roll the ball, and watch the puppies chase it!',fact:'Playing helps puppies grow strong, and teaches them how to be gentle with their brothers and sisters.'}};
const CARE_ORDER=['blanket','quiet','weigh','mash','toys'];
const careFor=st=>CARE_ORDER.concat(window.PFR3?PFR3.order||[]:[]).filter(k=>(CARE[k]||(window.PFR3&&PFR3.CARE[k])).st.indexOf(st)>=0);
const careDef=k=>CARE[k]||(window.PFR3&&PFR3.CARE[k]);
const fams=st=>roomIds().filter(id=>(PF.famOf(id).st||0)===st);
const hearts=n=>'❤️'.repeat(Math.min(3,n))+'🤍'.repeat(Math.max(0,3-n));
function openCare(){if(player.lock)return;hush();const L=roomIds();if(!L.length){say('There are no families in the Puppy Room yet.');return;}sfx.chime();
  const c=$('#menuCard');c.className='card wide';const rows=[0,1,2].map(st=>{const F=fams(st);if(!F.length)return '';
    const who=F.map(id=>`<b>${P(id).name}'s</b>`).join(', ');return `<div class="pfcRow"><h3>${PL.STAGE[st].i} ${PL.STAGE[st].n}s: ${who}${st<2?` <span class="pfh">${F.map(id=>hearts(PF.famOf(id).c||0)).join(' ')}</span>`:''}</h3><div class="pfcBtns">${careFor(st).map(k=>{const d=careDef(k);return `<button class="decslot" data-k="${k}" data-s="${st}"><span class="di">${d.icon}</span><b>${d.name}</b></button>`;}).join('')}</div></div>`;}).join('');
  c.innerHTML=`<h2>💗 Puppy care</h2><p class="pfcTip">Three care moments help puppies grow to the next stage. Any mix is fine!</p>${rows}<div class="btns"><button class="btn white" data-k="">✓ Done</button></div>`;
  $('#menu').classList.add('on');speak('Puppy care! Pick a way to look after the puppies.');
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();sfx.boop();const k=b.dataset.k;closeOv('menu');c.onclick=null;if(!k)return;const st=+b.dataset.s,d=careDef(k);
    if(d.go)return d.go(fams(st),st);run(k,fams(st),st);};}
/* the care overlay */
function ui(){if($('#pfcare'))return;const d=el('div','ov','<div class="card" id="pfcCard"><h2 id="pfcH"></h2><p id="pfcP"></p><div id="pfcStage"></div><div id="pfcCtl"></div><p id="pfcMsg"></p><div class="btns"><button class="btn white" id="pfcBack">Back</button></div></div>');d.id='pfcare';document.body.appendChild(d);
  tap('#pfcBack',()=>{sfx.boop();closeCare();});}
function closeCare(){$('#pfcare').classList.remove('on');player.lock=false;CUR=null;hush();}
let CUR=null;
const units=F=>{const L=[];F.forEach(id=>[0,1,2].forEach(i=>L.push({id,i})));return L;};
function unitHTML(u,st,o){o=o||{};const p=P(u.id);return `<div class="pfu${o.cls?' '+o.cls:''}" data-k="${u.k}"><div class="pfsv">${PL.svg(p,u.i,st,{anim:false,bd:(PF.famOf(u.id)||{}).bd,sleep:o.sleep})}</div><div class="pfov"></div><b>${PF.nm(u.id,u.i)}</b></div>`;}
function run(key,F,st){if(!F||!F.length)return;ui();player.lock=true;hush();const d=careDef(key);st=st!=null?st:(PF.famOf(F[0]).st||0);CUR={key,F,st,tries:0};
  $('#pfcH').textContent=`${d.icon} ${d.name}`;$('#pfcP').textContent=d.how;$('#pfcMsg').textContent='';$('#pfcCtl').innerHTML='';$('#pfcStage').className='';
  const U=units(F).map((u,k)=>Object.assign(u,{k}));$('#pfcStage').innerHTML=U.map(u=>unitHTML(u,st,{sleep:key==='quiet'})).join('');$('#pfcStage').classList.toggle('many',U.length>6);
  $('#pfcare').classList.add('on');speak(d.how);
  const M=(d.mini||MINI[key]);M(U,F,st);}
const unitEl=k=>document.querySelector(`#pfcStage .pfu[data-k="${k}"]`);
function onUnits(fn){document.querySelectorAll('#pfcStage .pfu').forEach(e=>tap(e,()=>fn(+e.dataset.k,e)));}
const msg=t=>{$('#pfcMsg').textContent=t;speak(t);};
const MINI={
  blanket(U){const done={};onUnits((k,e)=>{if(done[k])return;done[k]=1;e.classList.add('tuck');e.querySelector('.pfov').innerHTML=BLANKET;sfx.pop();const u=U[k];msg(`Snug as a bug, ${PF.nm(u.id,u.i)}!`);if(Object.keys(done).length>=U.length)setTimeout(()=>finish(),900);});},
  quiet(U){const c=$('#pfcCtl');c.innerHTML='<button class="btn yellow pfbig" id="pfLamp">💡 Dim the lamp</button>';tap('#pfLamp',()=>{sfx.boop();$('#pfcStage').classList.add('dim');c.innerHTML='<div class="pfshh">🤫 Shh... tiptoe...</div>';
      U.forEach(u=>{const e=unitEl(u.k);if(e)e.querySelector('.pfov').innerHTML='<span class="pfzz">💤</span>';});msg('Shh... The puppies are breathing slowly in and out. Sweet dreams!');setTimeout(()=>finish(),3600);});},
  weigh(U,F){weighQ(F);},
  mash(U){const c=$('#pfcCtl');let n=0;c.innerHTML='<button class="btn yellow pfbig" id="pfBowl"><span class="pfspoon">🥄</span>🥣 Stir the mash <span id="pfStir">○○○</span></button>';
    tap('#pfBowl',()=>{if(n>=3)return;n++;sfx.pop();$('#pfStir').textContent='●'.repeat(n)+'○'.repeat(3-n);$('#pfBowl').classList.remove('stir');void $('#pfBowl').offsetWidth;$('#pfBowl').classList.add('stir');
      if(n<3)return;msg('Warm and soupy! Now tap each puppy to give it a bowl.');const fed={};onUnits((k,e)=>{if(fed[k])return;fed[k]=1;sfx.yip(1.9);e.classList.add('fed');e.querySelector('.pfov').innerHTML='<span class="pfbowl">🥣</span><i class="pfmess m1"></i><i class="pfmess m2"></i>';
        if(Object.keys(fed).length>=U.length){msg('Slurp, slurp! The puppies have mash on their noses. What a mess!');setTimeout(()=>finish(),1500);}});});},
  toys(U){const c=$('#pfcCtl');let n=0;c.innerHTML='<button class="btn yellow pfbig" id="pfBall">⚽ Roll the ball! <span id="pfRolls">○○○</span></button>';
    tap('#pfBall',()=>{if(n>=3||CUR.busy)return;n++;CUR.busy=1;sfx.boop();$('#pfRolls').textContent='●'.repeat(n)+'○'.repeat(3-n);const st=$('#pfcStage');st.classList.remove('roll','roll2');void st.offsetWidth;st.classList.add(n%2?'roll':'roll2');
      const fl=U[Math.floor(Math.random()*U.length)],e=unitEl(fl.k);setTimeout(()=>{if(e&&CUR.st===1){e.classList.add('flop');sfx.giggle();msg(`Oops! ${PF.nm(fl.id,fl.i)} fell over. Wobbly legs!`);setTimeout(()=>e.classList.remove('flop'),1100);}else{sfx.yip(1.8);msg('Woof! Off they go after the ball!');}},700);
      setTimeout(()=>{CUR.busy=0;if(n>=3)finish();},1700);});}};
const BLANKET='<svg viewBox="0 0 100 60" class="pfblk"><path d="M4 18 Q50 0 96 18 L92 56 Q50 64 8 56 Z" fill="#8fd0ff" stroke="#26232e" stroke-width="3"/><path d="M10 30 H90 M12 44 H88" stroke="#ffffff" stroke-width="4" stroke-dasharray="6 6"/></svg>';
/* the weigh-in: doubling, and reading the dial (grams) */
const BW={t:100,s:150,m:250,l:400,g:500};
function weighQ(F){const id=F[0],p=P(id),i=Math.floor(Math.random()*3),n=PF.nm(id,i),B=(window.CARDS&&CARDS.breedOf?CARDS.breedOf(p.breed):{sz:'m'}),b=BW[B.sz]||250,X0=X();X0.wq=(X0.wq||0)+1;const dbl=X0.wq%2===1;
  const v=dbl?b*2:b+50*(1+Math.floor(Math.random()*3)),ans=v,opts=dbl?[ans,b+100,ans+100]:[ans,ans+100,Math.max(50,ans-50)];
  const q=dbl?`Last week ${n} weighed <b>${b} g</b>. Newborn puppies double their weight in about a week. What does ${n} weigh now?`:`${n} is on the scales. What does the scale say?`;
  $('#pfcStage').innerHTML=`<div class="pfscale">${scaleSVG(dbl?null:v)}<div class="pfonscale">${PL.svg(p,i,PF.stg(id),{anim:false,sleep:true})}</div></div><div class="pfq">${q}<div class="pfans">${shuffle(opts).map(o=>`<button class="btn blue" data-v="${o}">${o} g</button>`).join('')}</div></div>`;
  speak(q.replace(/<[^>]+>/g,''));let tries=0;
  document.querySelectorAll('#pfcStage .pfans .btn').forEach(bt=>tap(bt,()=>{if(bt.classList.contains('nope')||CUR.won)return;const val=+bt.dataset.v;
    if(val===ans){CUR.won=1;bt.classList.add('win');sfx.chime();$('#pfcStage .pfscale').innerHTML=scaleSVG(ans)+$('#pfcStage .pfonscale').outerHTML;msg(dbl?`Yes! Double ${b} is ${ans}: ${b} add ${b}. ${n} weighs ${ans} grams!`:`Yes! ${n} weighs ${ans} grams.`);setTimeout(()=>finish(),2200);return;}
    tries++;bt.classList.add('nope');sfx.oops();msg(dbl?`Not quite. Double means two lots: ${b} add ${b}.`:'Not quite. Look where the arrow points, and count on in 50s from the number before it.');
    if(tries>=2)document.querySelectorAll('#pfcStage .pfans .btn').forEach(q2=>{if(+q2.dataset.v===ans)q2.classList.add('hint');});}));}
function scaleSVG(v){const max=1000,a=x=>PI*(1-x/max),pt=(x,r)=>[150+Math.cos(a(x))*r,150-Math.sin(a(x))*r];let s='';
  for(let x=0;x<=max;x+=50){const big=x%200===0,mid=x%100===0,p1=pt(x,118),p2=pt(x,big?96:mid?104:110);s+=`<line x1="${p1[0].toFixed(1)}" y1="${p1[1].toFixed(1)}" x2="${p2[0].toFixed(1)}" y2="${p2[1].toFixed(1)}" stroke="${INK}" stroke-width="${big?4:2}"/>`;
    if(big){const t=pt(x,80);s+=`<text x="${t[0].toFixed(1)}" y="${(t[1]+6).toFixed(1)}" text-anchor="middle" font-size="16" font-weight="900" font-family="Arial">${x}</text>`;}}
  const nd=v==null?'':(()=>{const p=pt(v,104);return `<line x1="150" y1="150" x2="${p[0].toFixed(1)}" y2="${p[1].toFixed(1)}" stroke="#e8423a" stroke-width="6" stroke-linecap="round"/>`;})();
  return `<svg viewBox="0 0 300 200" class="pfdial"><rect x="10" y="10" width="280" height="180" rx="24" fill="#f4f4fa" stroke="${INK}" stroke-width="5"/><path d="M28 150 A122 122 0 0 1 272 150" fill="#ffffff" stroke="${INK}" stroke-width="3"/>${s}${nd}<circle cx="150" cy="150" r="10" fill="${INK}"/><text x="150" y="182" text-anchor="middle" font-size="16" font-weight="900" font-family="Arial">grams</text></svg>`;}
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
/* a care moment is done: a heart for each family, and a nap when a family has three */
function finish(){if(!CUR||CUR.fin)return;CUR.fin=1;const {key,F,st}=CUR,d=careDef(key);closeCare();player.lock=true;state.stars+=2;
  const grow=[];F.forEach(id=>{const f=PF.famOf(id);f.cl=f.cl||{};f.cl[key]=(f.cl[key]||0)+1;f.c=(f.c||0)+1;if((f.st||0)<2&&f.c>=3)grow.push(id);});
  state.stats.pfcare=(state.stats.pfcare||0)+1;save();hud();sfx.chime();
  card({art:big(d.icon),h:'Lovely care!',p:`${d.fact}<br><span class="pfh">${F.map(id=>`${P(id).name}'s family ${(PF.famOf(id).st||0)<2?hearts(PF.famOf(id).c):'💖'}`).join('<br>')}</span>`,say:d.fact,
    btns:[['❤️ +2 ⭐','green',()=>{if(grow.length)return nap(grow);player.lock=false;}]]});}
const big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`;
function pile(id,st,sleep){const p=P(id);return `<div class="pfpile">${[0,1,2].map(i=>`<div>${PL.svg(p,i,st,{anim:false,sleep,bd:(PF.famOf(id)||{}).bd})}</div>`).join('')}</div>`;}
function nap(ids){const st=PF.famOf(ids[0]).st||0;MUSIC.over='pflull';
  card({art:`<div class="pfnap">${ids.map(id=>pile(id,st,true)).join('')}<span class="pfzz2">💤</span></div>`,h:'Shh... nap time!',p:'The puppies have had a busy day, and now they are fast asleep. Puppies grow while they sleep!',
    btns:[['🌙 Tiptoe away','blue',()=>setTimeout(()=>wake(ids,0),400)]]});}
function wake(ids,k){if(k>=ids.length){MUSIC.over=null;player.lock=false;enterArea('pfroom',[player.x,player.z,player.h],'');return;}const id=ids[k],f=PF.famOf(id),b=f.st||0;f.st=b+1;f.c=0;f.grew=Date.now();save();
  const n=PF.list3(PF.names(id)),pn=P(id).name;sfx.fanfare();confetti(50);
  const t=f.st===1?`Wow! ${n} are wobbly puppies now! Their eyes are open, and they are blue-grey, like every puppy's at first. Their legs are still a bit wobbly!`:`Wow! ${n} are bouncy big puppies now! Their eyes are the same colour as ${pn}'s, and they can run and play.${window.PFR3&&PFR3.school?' Puppy School is open!':''}`;
  card({art:`<div class="pfba">${pile(id,b,b===0)}<span>➜</span>${pile(id,f.st,false)}</div>`,h:f.st===1?'🐾 Wobbly puppies!':'⭐ Bouncy big puppies!',p:t,btns:[['🎉 Hooray!','green',()=>wake(ids,k+1)]]});}
/* choosing the four families in the room */
function chooseFams(){if(player.lock)return;const H=PF.homes();if(H.length<=1){say(H.length?'When you find more families, you can choose which ones play in the Puppy Room.':'');return;}
  hush();const c=$('#menuCard');c.className='card wide';let sel=roomIds();
  const draw=()=>{c.innerHTML=`<h2>🔄 Choose families</h2><p>Choose up to 4 families to play in the Puppy Room.</p><div class="pupgrid pfgrid">${H.map(id=>`<button class="pupsel${sel.indexOf(id)>=0?' on':''}" data-p="${id}"><div class="fitsvg">${PL.famSVG(P(id),PF.stg(id),{bd:PF.famOf(id).bd})}</div><b>${P(id).name}'s</b></button>`).join('')}</div><div class="btns"><button class="btn green" data-p="">✓ Done</button></div>`;};draw();
  $('#menu').classList.add('on');speak('Choose up to 4 families to play in the Puppy Room.');
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx.boop();const id=b.dataset.p;if(!id){X().room=sel;save();closeOv('menu');c.onclick=null;enterArea('pfroom',[player.x,player.z,player.h],'Welcome, puppies!');return;}
    const i=sel.indexOf(id);if(i>=0)sel.splice(i,1);else{if(sel.length>=4){say('Only 4 families fit in the Puppy Room. Tap a family again to take it out.');return;}sel.push(id);}draw();};}

/* ---------------- music: Brahms's Lullaby (published 1868) as a music box ---------------- */
TUNES.pflull={step:.24,mw:'triangle',mv:.36,hw:'sine',hv:.1,
  mel:tuneRow('E5 - E5 G5 - - E5 - E5 G5 - - E5 G5 C6 - B5 - A5 - A5 G5 - - D5 E5 F5 - D5 - D5 E5 F5 - - - D5 F5 B5 A5 G5 - B5 - C6 - - - C5 - C5 C6 - - A5 F5 G5 - - - E5 C5 F5 G5 - A5 G5 - - - - - C5 - C5 C6 - - A5 F5 G5 - - - E5 C5 F5 E5 - D5 C5 - - - - -'),
  bas:tuneRow('C3 . . G2 . . C3 . . G2 . . C3 . . E3 . . F2 . . C3 . . G2 . . G2 . . G2 . . G2 . . G2 . . G2 . . C3 . . . . . C3 . . F2 . . C3 . . . . . C3 . . G2 . . C3 . . . . . C3 . . F2 . . C3 . . . . . F2 . . G2 . . C3 . . . . .'),drm:''};
{const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;if(typeof W!=='undefined'&&W&&W.area&&W.area.id==='pfroom')return 'pflull';return _mk();};}

const css=document.createElement('style');css.textContent=`
#pfcare{z-index:60}#pfcCard{max-width:980px;width:96%;background:#fff6f8;padding-top:12px}#pfcCard h2{margin:0 0 2px}#pfcP{margin:2px 0 6px;font-size:22px}
#pfcStage{position:relative;display:flex;flex-wrap:wrap;justify-content:center;gap:8px;min-height:200px;border-radius:22px;background:#ffeef3;padding:10px;transition:background .8s}
#pfcStage.dim{background:#3a3456}#pfcStage.dim .pfu b{color:#fff}
.pfu{position:relative;width:180px;cursor:pointer;text-align:center}#pfcStage.many .pfu{width:120px}.pfu .pfsv svg{width:100%;height:auto;display:block}.pfu b{font-size:22px;color:#6a4228}
.pfu .pfov{position:absolute;left:0;right:0;top:0;bottom:22px;pointer-events:none}.pfu .pfblk{position:absolute;left:4%;width:92%;bottom:0;animation:xpop .4s}
.pfu.tuck .pfsv{filter:saturate(.95)}.pfzz{position:absolute;right:6px;top:4px;font-size:34px;animation:pfz 1.6s ease-in-out infinite}
@keyframes pfz{0%,100%{transform:translateY(0);opacity:.6}50%{transform:translateY(-12px);opacity:1}}
.pfbig{font-size:30px;min-height:76px;padding:0 26px}.pfshh{font-size:36px;font-weight:900;color:#6a5aa0;margin:8px}
#pfBowl.stir .pfspoon{display:inline-block;animation:pfstir .5s}@keyframes pfstir{from{transform:rotate(0)}to{transform:rotate(360deg)}}
.pfu .pfbowl{position:absolute;left:50%;bottom:-6px;transform:translateX(-50%);font-size:40px;animation:xpop .4s}.pfmess{position:absolute;width:16px;height:12px;border-radius:50%;background:#e8c890;border:2px solid #b89060}.pfmess.m1{left:46%;top:44%}.pfmess.m2{left:54%;top:50%;width:10px;height:8px}
#pfcStage.roll .pfu,#pfcStage.roll2 .pfu{animation:pfchase 1.4s ease-in-out}@keyframes pfchase{0%{transform:translateX(0)}30%{transform:translateX(26px) rotate(6deg)}60%{transform:translateX(-14px) rotate(-6deg)}100%{transform:translateX(0)}}
#pfcStage.roll::after,#pfcStage.roll2::after{content:'⚽';position:absolute;top:60%;font-size:44px;animation:pfball 1.4s linear}@keyframes pfball{from{left:-5%}to{left:100%}}
.pfu.flop .pfsv{transform:rotate(80deg) translateY(14px);transition:transform .3s}
.pfscale{position:relative;width:340px;display:inline-block;vertical-align:middle}.pfscale .pfdial{width:100%;height:auto}.pfonscale{position:absolute;left:30%;width:40%;top:-30%}.pfonscale svg{width:100%;height:auto}
.pfq{display:inline-block;vertical-align:middle;width:min(520px,90%);font-size:26px;font-weight:800;padding:8px}.pfq b{color:#c83a7a}.pfans{display:flex;gap:12px;justify-content:center;margin-top:12px}.pfans .btn{min-width:130px;min-height:72px;font-size:30px;font-weight:900}
.pfans .btn.nope{opacity:.4}.pfans .btn.win{background:#8ae05a}.pfans .btn.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
#pfcMsg{min-height:34px;font-size:24px;font-weight:800;margin:6px 0}
.pfcRow{background:#fff6f8;border:3px solid #ffd0dc;border-radius:18px;margin:8px 0;padding:6px 10px}.pfcRow h3{margin:4px 0;font-size:22px}.pfcBtns{display:flex;flex-wrap:wrap;gap:8px;justify-content:center}.pfcTip{font-size:20px;margin:0}.pfh{font-size:18px;white-space:nowrap}
.pfpile{display:inline-flex;align-items:flex-end;width:240px}.pfpile>div{width:36%;margin:0 -3%}.pfpile svg{width:100%;height:auto;display:block}
.pfnap{position:relative;display:inline-block;background:#3a3456;border-radius:22px;padding:14px 18px}.pfzz2{position:absolute;right:10px;top:6px;font-size:44px;animation:pfz 1.6s ease-in-out infinite}
.pfba{display:flex;align-items:center;justify-content:center;gap:10px}.pfba>span{font-size:54px;font-weight:900;color:#ff6fae}
.pfgrid .pupsel{width:150px}.pfgrid .pupsel .fitsvg svg{width:100%;height:auto}`;
document.head.appendChild(css);
window.PFROOM={roomIds,openCare,run,finish,careFor,careDef,CARE,units,unitHTML,onUnits,msg,closeCare,pile,nap,ui,scaleSVG,shuffle,hearts,chooseFams,get CUR(){return CUR;}};
})();
