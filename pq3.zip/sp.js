/* ================================================================
   Spring Blossom (Pup Seasons 5, 26 Nov 2026; claude/spring-blossom-design.md): the engine.
   A fresh spring day (soft sun, drifting blossom petals, butterflies), Seb's duckling (named by Seb;
   it hatched from Summer's egg and thinks Seb is its mum), the three hiding tricks (nests with painted
   eggs in rows; egg trails to a blossom bush; giant flower buds with seed pictures), finding a spring
   pup, the nine blossom buds from the unicorns, the opening, the invitation and the grown-ups switch.
   Shares window.SEASONS, the Season Globe and the spot planner grid with season.js.
   Save: state.sx.sp = {pal:{name,girl,at}, found:{id:time}, how:{id:kind}, tagged:{id:1},
   bb:{island:time}, inv, intro, ...}; created only once Spring Blossom is opened and started.
   ================================================================ */
(function(){
const PI=Math.PI,SL=window.SPLOOK,SP=SL.SPUPS,sp=SL.sp,FACT=SL.FACT,XM=window.XMAS,PINK='#ff9ac0',LEAF='#6abf4a',YEL='#ffd23f';
const EGGC=['#ff9ac0','#8ad0ff','#ffe066','#9ae07a','#c8a8ff'];
const G0=()=>(state&&state.sx&&state.sx.sp)||null;
const GS=()=>{if(!state.sx)state.sx={};const s=state.sx;if(!s.sp)s.sp={found:{},how:{},tagged:{},bb:{}};if(!s.sp.bb)s.sp.bb={};return s.sp;};
const on=()=>!!(state&&state.season==='sp');
const sbDone=()=>!!(state&&state.sx&&state.sx.sb&&state.sx.sb.done);
const opened=()=>sbDone()||!!(state&&state.set&&state.set.spOpen);
const named=()=>!!(G0()&&G0().pal);
let ALL=null;
const all=()=>ALL||(ALL=ISLANDS.reduce((a,I)=>a.concat(I.pups,I.bonus||[]),[]).concat([SP.primrose,SP.tulip]));
const gpup=id=>PUPS[id]||SP[id];
const xFound=id=>!!(G0()&&G0().found[id]);
const nFound=()=>G0()?all().filter(p=>xFound(p.id)).length:0;
const islX=I=>I.pups.concat(I.bonus||[]);
const islN=I=>islX(I).filter(p=>xFound(p.id)).length;
const areaX=a=>all().filter(p=>p.area===a);
const nBb=()=>Object.keys((G0()||{}).bb||{}).length;
const pal=()=>(G0()&&G0().pal)||{name:'the little duckling',girl:false};
const he=()=>pal().girl?'she':'he',his=()=>pal().girl?'her':'his',him=()=>pal().girl?'her':'him',He=()=>pal().girl?'She':'He';
const kindOf=p=>p.season==='sp'||p.bonus?'flower':p.tag?'bush':'nest';
const NEED=6;
const hsh=s=>{let h=7;for(const ch of String(s))h=(h*31+ch.charCodeAt(0))%100003;return h;};
const mixC=(a,b,k)=>{const c=new THREE.Color(a||'#888888');c.lerp(new THREE.Color(b),k);return '#'+c.getHexString();};

/* ---------------- sounds ---------------- */
const SCALE=[523,587,659,698,784,880,988,1047,1175];/* one note per bud */
const snd={
 cheep(){if(!fxOk())return;const t=AC.currentTime;tone(2500,t,.07,'sine',.06,null,3100);tone(2700,t+.1,.08,'sine',.06,null,3300);},
 quack(){if(!fxOk())return;const t=AC.currentTime;tone(420,t,.15,'sawtooth',.05,null,320);tone(400,t+.2,.16,'sawtooth',.05,null,300);},
 crack(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.05,.2,'highpass',2600);nzHit(t+.12,.06,.18,'highpass',2200);},
 rustle(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.35,.1,'bandpass',3200,null,.6);nzHit(t+.2,.3,.08,'bandpass',2600,null,.6);},
 pop(){if(!fxOk())return;const t=AC.currentTime;tone(500,t,.1,'sine',.12,null,1300);},
 wind(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,1.3,.1,'lowpass',700);nzHit(t+.3,1,.07,'bandpass',1400);},
 bird(){if(!fxOk())return;const t=AC.currentTime;[0,.11,.22].forEach((d,i)=>tone(3000+i*300,t+d,.06,'sine',.05,null,4000+i*200));},
 twinkle(){if(!fxOk())return;const t=AC.currentTime;[1319,1568,2093,2637].forEach((f,i)=>tone(f,t+i*.08,.22,'sine',.09));},
 note(i){if(!fxOk())return;const t=AC.currentTime,f=SCALE[i%9];tone(f,t,.4,'triangle',.13);tone(f*2,t,.2,'sine',.04);},
 song(n,gap){for(let i=0;i<n;i++)setTimeout(()=>snd.note(i),i*(gap||240));}};

/* ================= the spring look ================= */
const NOSP=new Set(['den','cave','glow','vault','ambercave','library','alien']);
const SPRL={sky:'#ffffff',gr:'#c8e8a0',hi:.8,dir:'#fff6e0',di:.58,pos:[60,100,40]};
const MUSEUM={sky:'#fffaf4',gr:'#e0ecc8',hi:.86,dir:'#fff6e6',di:.36,pos:[20,90,10]};
const sunny=A=>!!(A&&!NOSP.has(A.id)&&!A.indoor);
const museum=A=>!!(A&&A.indoor&&A.island==='number');
function lookFor(A){if(museum(A))return {light:Object.assign({},MUSEUM)};if(!sunny(A))return null;
  const space=(A.island||A.id)==='planet',o={light:Object.assign({},SPRL)};
  if(!space){o.sky=A.swim?'#4ab8e8':'#a8dcff';o.fogC=A.swim?'#4ab8e8':'#d6f0ff';o.fog=A.swim?[50,190]:[80,260];o.skyObj=Object.assign({},A.skyObj||{},{sun:{az:-40,el:24,size:56},moon:null,stars:false,flies:0});}
  if(A.swim){o.light.hi=.86;o.light.sky='#e0f6ff';}return o;}
let GLT=null,PETT=null,BFT=null,CLOUDT=null;
const canvasTex=(w,h,f)=>{const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'));return new THREE.CanvasTexture(c);};
function glowTex(){return GLT||(GLT=canvasTex(64,64,x=>{const g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.3,'rgba(255,255,255,.7)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);}));}
function petalTex(){return PETT||(PETT=canvasTex(64,64,x=>{x.fillStyle='#ffc4d8';x.strokeStyle='#ff8ab0';x.lineWidth=3;x.beginPath();x.ellipse(32,32,14,24,.6,0,PI*2);x.fill();x.stroke();x.fillStyle='rgba(255,255,255,.7)';x.beginPath();x.ellipse(27,26,4,9,.6,0,PI*2);x.fill();}));}
function bflyTex(){return BFT||(BFT=canvasTex(64,64,x=>{x.strokeStyle='#26232e';x.lineWidth=3;[[1,'#ffb020'],[-1,'#ffb020']].forEach(q=>{x.fillStyle=q[1];x.beginPath();x.ellipse(32+q[0]*13,24,12,14,q[0]*.4,0,PI*2);x.fill();x.stroke();x.fillStyle='#ff7aa8';x.beginPath();x.ellipse(32+q[0]*10,44,8,9,-q[0]*.4,0,PI*2);x.fill();x.stroke();});
  x.fillStyle='#26232e';x.fillRect(30,16,4,34);}));}
function cloudTex(){return CLOUDT||(CLOUDT=canvasTex(256,128,x=>{x.fillStyle='rgba(255,255,255,.95)';[[70,80,40],[120,62,52],[175,78,42],[100,88,36],[150,92,36]].forEach(q=>{x.beginPath();x.arc(q[0],q[1],q[2],0,PI*2);x.fill();});}));}
function glowMat(col,op){return new THREE.SpriteMaterial({map:glowTex(),color:col||'#fff2a0',transparent:true,opacity:op==null?.9:op,depthWrite:false,blending:THREE.AdditiveBlending,fog:false});}
/* blossom petals drifting down around Seb, as one points cloud */
function petals(A,n){const P=new Float32Array(n*3),B=[],R=seed(hsh(A.id)+7);for(let i=0;i<n;i++)B.push([R()*60-30,R()*60-30,R()*11,.5+R()*.6,R()*6]);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({size:.55,map:petalTex(),transparent:true,alphaTest:.3,depthWrite:false});
  const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);const wr=(v,s)=>((v%s)+s)%s;
  const tick=()=>{if(W.area!==A||!pts.parent)return true;const t=W.t,px=player.x,pz=player.z,gy0=walkY(px,pz);for(let i=0;i<n;i++){const b=B[i];
      P[i*3]=px-30+wr(b[0]-px+t*1.1+Math.sin(t*.7+b[4])*1.5+30,60);P[i*3+2]=pz-30+wr(b[1]-pz+Math.cos(t*.5+b[4])*1.2+30,60);P[i*3+1]=gy0+.3+wr(b[2]-t*b[3],11);}
    g.attributes.position.needsUpdate=true;};W.ticks.push(tick);tick();return pts;}
/* butterflies flitting low, as one points cloud */
function bflies(A,n){const P=new Float32Array(n*3),B=[],R=seed(hsh(A.id)+9);for(let i=0;i<n;i++)B.push([R()*PI*2,6+R()*22,1.4+R()*1.6,.25+R()*.3,R()*6,R()<.5?1:-1]);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({size:1.1,map:bflyTex(),transparent:true,alphaTest:.3,depthWrite:false});
  const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);
  const tick=()=>{if(W.area!==A||!pts.parent)return true;const t=W.t;for(let i=0;i<n;i++){const b=B[i],a=b[0]+t*b[3]*b[5],x=Math.cos(a)*b[1],z=Math.sin(a)*b[1];P[i*3]=x;P[i*3+2]=z;P[i*3+1]=gy(x,z)+b[2]+Math.sin(t*2.2+b[4])*.6;}
    m.size=.9+Math.abs(Math.sin(t*9))*.35;g.attributes.position.needsUpdate=true;};W.ticks.push(tick);tick();return pts;}
function clouds(A){const R=seed(hsh(A.id)+11),L=[];for(let i=0;i<5;i++){const m=new THREE.SpriteMaterial({map:cloudTex(),transparent:true,depthWrite:false,fog:false,opacity:.9}),s=new THREE.Sprite(m),a=R()*PI*2,d=230+R()*60;
    s.scale.set(70+R()*40,35+R()*20,1);s.position.set(Math.cos(a)*d,40+R()*30,Math.sin(a)*d);W.ag.add(s);W.disp.push(m);L.push({s,a,d});}
  W.ticks.push(dt=>{if(W.area!==A)return true;L.forEach(q=>{q.a+=dt*.004;q.s.position.x=Math.cos(q.a)*q.d;q.s.position.z=Math.sin(q.a)*q.d;});});}

/* ================= entering an area in spring ================= */
const _ea=enterArea;
enterArea=function(id,pos,msg){const A=AREAS[id];
  if(!A||!on())return _ea.apply(this,arguments);
  const o=lookFor(A),keep={};if(o)for(const k in o){keep[k]=[k in A,A[k]];A[k]=o[k];}
  if(!msg&&named()&&G0().intro){const L=areaX(id),left=L.filter(p=>!xFound(p.id)).length;if(L.length)msg=`${A.icon} ${A.name} in spring! `+(left?`${left===1?'One pup is':left+' pups are'} hiding here. Listen to ${pal().name}'s cheeps!`:'Every pup here is found!');}
  try{_ea.call(this,id,pos,msg);}finally{for(const k in keep){if(keep[k][0])A[k]=keep[k][1];else delete A[k];}}
  if(W.area!==A)return;
  if(sunny(A)&&(A.island||A.id)!=='planet'&&!A.swim){petals(A,A.id==='village'?70:50);bflies(A,A.id==='village'?7:5);clouds(A);}
  if(window.SPWORLD&&SPWORLD.after)try{SPWORLD.after(A);}catch(e){console.warn('sp after',e);}
  palEnter(A);hud();
  const I=A.island&&islandOf(A.island);if(I&&named()&&G0().intro&&islN(I)>=NEED&&!G0().bb[I.id])setTimeout(()=>{if(W.area===A&&!player.lock&&!ovOpen())bud(I);},1800);
  if(id==='village')setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village')return;if(window.SPSTORY&&SPSTORY.village)SPSTORY.village();},900);};
Object.values(AREAS).forEach(A=>{const b=A.build;if(typeof b!=='function')return;A.build=function(){b.apply(this,arguments);if(on()&&window.SPWORLD&&SPWORLD.build)try{SPWORLD.build(A);}catch(e){console.warn('sp build',e);}};});

/* ================= hiding spots ================= */
const _bs=buildSpots;buildSpots=function(A){if(!on())return _bs(A);if(SPRING.noSpots)return;sSpots(A);};
const _bb=buildBoss;buildBoss=function(IS){if(!on())return _bb(IS);uniHome(IS);};
const _ac=areaCount;areaCount=function(a){if(!on())return _ac(a);const L=areaX(a);return L.length?`🌷 ${L.filter(p=>xFound(p.id)).length}/${L.length}`:'';};
let PLAN=null,LIVE=[];
function spotFor(p,A){const S=(window.SPSPOTS||{})[p.id];if(S)return S;if(!PLAN||PLAN.area!==A.id){PLAN=plan(A);PLAN.area=A.id;}return PLAN.spots[p.id]||null;}
function sSpots(A){LIVE=[];areaX(A.id).forEach(p=>{const S=spotFor(p,A);if(!S)return;const k=S.k||kindOf(p);try{
    if(k==='nest')LIVE.push(nestSpot(p,S,A));else if(k==='flower')LIVE.push(flowerSpot(p,S,A));else if(k==='bush')LIVE.push(bushSpot(p,S,A));}catch(e){console.warn('sp spot',p.id,e);}});
  W.ticks.push(spotTick);}

/* ----- 1. nests with painted eggs in rows: which nest is the pup's? ----- */
const LEVEL=isl=>isl==='number'?'num':['ninja','gadget','rescue'].indexOf(isl)>=0?'mid':['dino','planet'].indexOf(isl)>=0?'steps':'easy';
function nestSpec(p,isl){const lv=LEVEL(isl),h=hsh(p.id+'n'),R=seed(h);let rows,cols,cand=[];
  const sw=(a,b)=>a[0]===b[1]&&a[1]===b[0];
  if(lv==='num'){let C=[2,3,4,5];if(typeof tablesOn==='function'){const tb=tablesOn();if(tb&&tb.length)C=tb.filter(v=>v>=2&&v<=10);if(!C.length)C=[2,3,4,5];}
    cols=C[h%C.length];rows=2+(h>>2)%3;for(let r=1;r<=5;r++)if(r!==rows)cand.push([r,cols]);}
  else{const RR=lv==='easy'?[2,3]:lv==='mid'?[2,3,4]:[2,3],CC=lv==='easy'?[2,3,4]:lv==='mid'?[2,3,4,5]:[2,5,10];
    rows=RR[h%RR.length];cols=CC[(h>>3)%CC.length];RR.concat(lv==='steps'?[]:[1]).forEach(r=>CC.forEach(c=>{const q=[r,c];if(!(r===rows&&c===cols)&&!sw(q,[rows,cols]))cand.push(q);}));}
  const n=lv==='easy'||lv==='num'?3:4,used=new Set([rows*cols]),pick2=[];
  for(let k=0;k<60&&pick2.length<n-1&&cand.length;k++){const i=Math.floor(R()*cand.length),q=cand[i];if(used.has(q[0]*q[1]))continue;used.add(q[0]*q[1]);pick2.push(q);cand.splice(i,1);}
  const nests=pick2.concat([[rows,cols]]);for(let i=nests.length-1;i>0;i--){const j=Math.floor(R()*(i+1));[nests[i],nests[j]]=[nests[j],nests[i]];}
  return {rows,cols,nests,right:nests.findIndex(q=>q[0]===rows&&q[1]===cols),num:lv==='num',lv};}
function nestSpot(p,S,A){const x=S.x,z=S.z,y=gy(x,z),found=xFound(p.id),R=seed(hsh(p.id));
  I('disc',A.swim?'#7ac8a8':'#8ad05a',3.2,1,3.2,x,y+.05,z);
  for(let k=0;k<3;k++){const a=k/3*PI*2+.4,nx=x+Math.cos(a)*1.7,nz=z+Math.sin(a)*1.7,ny=gy(nx,nz);
    I('tor','#9a6a3a',.85,.85,1.5,nx,ny+.28,nz,PI/2,0,0);I('disc','#6a4a2a',.72,1,.72,nx,ny+.2,nz);
    for(let e=0;e<3;e++){const ea=e/3*PI*2+R()*1.2;I('sph',EGGC[(k+e)%5],.15,.21,.15,nx+Math.cos(ea)*.32,ny+.4,nz+Math.sin(ea)*.32,0,0,(R()-.5)*.6);}}
  I('cyl','#ffffff',.04,2.2,.04,x-2.9,y+1.1,z+1.4);I('box',PINK,.7,.45,.04,x-2.54,y+1.95,z+1.4,0,0,0,true);
  const o=Object.assign({p,k:'nest',x,z,tries:0},nestSpec(p,A.island||'village'));
  if(!found)o.easy=spr('🪺',1.6,x,y+3.6,z);else markFound(o);
  W.things.push({x,z,r:4.6,icon:'🪺',label:'Which nest?',show:()=>!xFound(p.id),act:()=>openNests(o)});return o;}
/* ----- 3. a giant flower bud on a ring of fresh soil ----- */
function bud3D(par,s,open,col){const g=grp();g.scale.setScalar(s||1);par.add(g);col=col||'#ff8ab0';
  mk('cyl','#4a9a3a',.12,2.2,.12,0,1.1,0,g);[-1,1].forEach(q=>{const l=mk('sph','#5aaf4a',.5,.12,.22,q*.45,.8,0,g);l.rotation.z=-q*.5;});
  if(!open){mk('sph',col,.62,1.0,.62,0,2.7,0,g);mk('cone','#5aaf4a',.5,.5,.5,0,2.1,0,g).rotation.x=PI;for(let i=0;i<3;i++){const a=i/3*PI*2;mk('sph',mixC(col,'#ffffff',.25),.3,.8,.3,Math.cos(a)*.3,2.75,Math.sin(a)*.3,g);}}
  else{for(let i=0;i<6;i++){const a=i/6*PI*2,pt=mk('sph',col,.55,.12,.32,Math.cos(a)*.62,2.5,Math.sin(a)*.62,g);pt.rotation.y=-a;pt.rotation.z=.35;}mk('sph',YEL,.36,.2,.36,0,2.55,0,g);}
  return g;}
function flowerSpot(p,S,A){const found=xFound(p.id),y=gy(S.x,S.z),g=grp(),col=['#ff8ab0','#ff6a6a','#c88aff','#ffb020','#ff9ac0'][hsh(p.id)%5];bud3D(g,1.15,found,col);add(g,S.x,S.z);bakeModel(g,'spbud'+(found?1:0)+col);
  I('disc','#7a5a3a',3.1,1,3.1,S.x,y+.05,S.z);const R=seed(hsh(p.id));for(let i=0;i<14;i++){const a=i/14*PI*2,r=2.5;I('sph','#c8a060',.12,.08,.16,S.x+Math.cos(a)*r,y+.1,S.z+Math.sin(a)*r,0,R()*PI,0);}
  const m=new THREE.MeshBasicMaterial({color:'#fff2a0',transparent:true,opacity:.6,depthWrite:false}),ring=new THREE.Mesh(G.tor||G.sph,m);ring.scale.set(3.1,3.1,.3);ring.rotation.x=PI/2;ring.position.set(S.x,y+.14,S.z);W.ag.add(ring);W.disp.push(m);
  const o={p,k:'flower',x:S.x,z:S.z,ring,m,g,col};if(!A.ski)col2(S.x,S.z,1.2);
  if(found)markFound(o);else o.glow=spr('🌱',1.6,S.x,y+4.4,S.z);
  W.things.push({x:S.x,z:S.z,r:4.8,icon:'🌱',label:'The giant flower bud',show:()=>!xFound(p.id),act:()=>openFlower(o)});return o;}
const col2=(x,z,r)=>col(x,z,r);
function markFound(o){if(o.easy){W.ag.remove(o.easy);o.easy=null;}if(o.glow){W.ag.remove(o.glow);o.glow=null;}if(o.ring)o.m.opacity=.22;
  if(!o.mark)o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+(o.k==='flower'?4.6:3.4),o.z);}
/* ----- 2. a trail of painted eggs leads to a blossom bush ----- */
function eggTrail(pts,A){const step=1.5,out=[];for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.floor(d/step)),ang=Math.atan2(b[0]-a[0],b[1]-a[1]);
    for(let k=0;k<n;k++){const t=k/n,side=(out.length%2?1:-1)*.3;out.push([a[0]+(b[0]-a[0])*t+Math.cos(ang)*side,a[1]+(b[1]-a[1])*t-Math.sin(ang)*side,ang]);}}
  const m=new THREE.MeshLambertMaterial({color:'#ffffff'}),im=new THREE.InstancedMesh(G.sph,m,Math.max(1,out.length)),M4=new THREE.Matrix4(),q=new THREE.Quaternion(),s=new THREE.Vector3(.16,.22,.16),v=new THREE.Vector3(),e=new THREE.Euler(),c=new THREE.Color();
  out.forEach((p,i)=>{e.set(0,p[2],(i%3-1)*.25);q.setFromEuler(e);v.set(p[0],walkY(p[0],p[1])+.2,p[1]);M4.compose(v,q,s);im.setMatrixAt(i,M4);c.set(EGGC[i%5]);im.setColorAt(i,c);});
  if(im.instanceColor)im.instanceColor.needsUpdate=true;im.count=out.length;im.frustumCulled=false;W.ag.add(im);W.disp.push(m);return {im,m,n:out.length};}
const BUSHC=[['#ffb8d0','#ffffff'],['#ff9ac0','#ffe0ec'],['#ffffff','#ffb8d0'],['#ffc4a8','#ffffff'],['#e8b0ff','#ffffff']];
function bush3D(key){const g=grp(),c=BUSHC[hsh(key)%BUSHC.length],R=seed(hsh(key)+3);
  mk('sph','#5aa04a',1.0,.82,1.0,0,.8,0,g);mk('sph','#4a903a',.7,.6,.7,.55,.6,.3,g);mk('sph','#4a903a',.66,.58,.66,-.5,.62,-.25,g);
  for(let i=0;i<16;i++){const a=R()*PI*2,el=.15+R()*1.1,r=1.0;mk('sph',i%3?c[0]:c[1],.17,.13,.17,Math.cos(a)*Math.cos(el)*r,.8+Math.sin(el)*.82,Math.sin(a)*Math.cos(el)*r,g);}
  g.scale.setScalar(DS);return g;}
const DS=1.5;
function bushSpot(p,S,A){const tagged=!!(G0()&&G0().tagged[p.id]),found=xFound(p.id),to=tagged?S.c:S.b,path=tagged?S.bc:S.ab;
  const o={p,k:'bush',S,x:to[0],z:to[1],tagged};o.g=bush3D(p.id+(tagged?'c':'b'));add(o.g,o.x,o.z);o.g.rotation.y=hsh(p.id+(tagged?'c':'b'))%6;bakeModel(o.g,'spbush|'+hsh(p.id+(tagged?'c':'b'))%BUSHC.length);col(o.x,o.z,1.6);
  if(found){o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+3.8,o.z);return o;}
  o.pr=eggTrail(path||[[tagged?S.b[0]:S.a[0],tagged?S.b[1]:S.a[1]],to],A);o.easy=spr('🥚',1.6,o.x,gy(o.x,o.z)+4.2,o.z);
  o.th={x:o.x,z:o.z,r:3.9,icon:'👀',label:'Peek in the bush!',show:()=>!xFound(p.id)&&!o.busy,act:()=>peek(o)};W.things.push(o.th);return o;}
function spotTick(dt){const t=W.t,P=player;let near=null,nd=1e9;
  LIVE.forEach(o=>{if(o.easy){o.easy.visible=state.set.hsEasy;o.easy.position.y=gy(o.x,o.z)+(o.k==='bush'?4.3:3.7)+Math.sin(t*3)*.3;}if(o.glow)o.glow.position.y=gy(o.x,o.z)+4.4+Math.sin(t*2.5)*.25;
    if(o.ring&&!xFound(o.p.id)){o.m.opacity=.45+.3*Math.sin(t*2.6);o.ring.rotation.z=t*.3;}
    if(xFound(o.p.id))return;const d=Math.hypot(P.x-o.x,P.z-o.z);if(d<nd){nd=d;near=o;}});
  if(near&&nd<9&&t-(SPRING.jT||0)>2.8&&!P.lock&&!ovOpen()){SPRING.jT=t;if(near.k==='nest')snd.bird();else if(near.k==='flower')snd.twinkle();else{sfx.yip((near.p.pitch||1)*1.1);snd.rustle();}}
  if(near&&!P.lock&&t-W.findT>75&&t-W.hintT>75){W.hintT=t;sparkTrail(near);}}
function sparkTrail(o){W.trail.forEach(s=>W.ag.remove(s));W.trail=[];const P=player,dx=o.x-P.x,dz=o.z-P.z,d=Math.hypot(dx,dz),n=Math.min(10,Math.floor((d-3)/2.5));
  for(let i=1;i<=n;i++){const x=P.x+dx*i/(n+1.2),z=P.z+dz*i/(n+1.2);W.trail.push(spr('🌸',1.1,x,gy(x,z)+.6,z));}
  PAL.jump=.7;snd.cheep();say(`${pal().name} is cheeping like mad! Follow the blossom, Seb!`);}

/* ----- the nest picker: count the rows, then pick the nest ----- */
const NESTF=[['🐦','A robin pops up: "Not my nest!"'],['🐸','A frog! Ribbit!'],['🦔','A sleepy hedgehog!'],['🐰','A bunny! Twitch, twitch.'],['🦉','A sleepy owl: "Hoo? Not here!"'],['🐌','A snail says a slow hello.'],['🐤','A chick! Cheep!']];
function nestSVG(r,c,o){o=o||{};const W2=150,H2=120,ew=Math.min(21,124/c),eh=Math.min(ew*1.3,64/r),s=Math.min(ew/20,eh/26);
  let g='';for(let i=0;i<r;i++){let row='';const y=56-(r-1)*eh/2*1.02+i*eh*1.02;for(let j=0;j<c;j++){const x=75-(c-1)*ew/2+j*ew;row+=SL.egg2D(+x.toFixed(1),+y.toFixed(1),s*.95,EGGC[(i+j)%5],(i+j)%3);}g+=`<g class="sprow" data-r="${i}">${row}</g>`;}
  return `<svg viewBox="0 0 ${W2} ${H2}" class="spnest"><ellipse cx="75" cy="94" rx="70" ry="20" fill="#6a4a2a"/>${g}<path d="M5 92 Q75 128 145 92 Q140 112 75 116 Q10 112 5 92 Z" fill="#9a6a3a" stroke="#5b3e22" stroke-width="3"/>`+
    `<path d="M14 98 l18 6 M40 106 l20 2 M70 110 l22 -2 M100 106 l20 -4 M124 100 l14 -6 M24 104 l-6 -8 M118 104 l8 -8" stroke="#c8925a" stroke-width="3" stroke-linecap="round"/>${o.top||''}</svg>`;}
let PK=null;
function pickUI(){if($('#sppick'))return;const d=el('div','ov','<div class="card" id="sppCard"><h2 id="sppH"></h2><div id="sppClue"></div><div id="sppNests"></div><p id="sppMsg"></p><div class="btns"><button class="btn white" id="sppBack">Back</button></div></div>');d.id='sppick';document.body.appendChild(d);
  tap('#sppBack',()=>{sfx.boop();closePick();});}
function closePick(){$('#sppick').classList.remove('on');player.lock=false;PK=null;hush();}
const clueOf=o=>o.num?`${o.rows*o.cols} eggs, in rows of ${o.cols}`:`${o.rows} rows of ${o.cols} eggs`;
const steps=(c,r)=>Array.from({length:r},(v,i)=>(i+1)*c).join(', ');
function openNests(o){if(player.lock||xFound(o.p.id))return;pickUI();player.lock=true;hush();snd.bird();PK=o;o.tries=0;o.done={};
  const F=pal().name,clue=clueOf(o);
  $('#sppH').textContent=o.num?'🔢 Work out the rows, then pick the nest!':'🪺 Which nest is it?';
  $('#sppClue').innerHTML=`<div class="spface">🐾</div><div class="spbub">A note from a hiding pup: "My nest has <b>${clue}</b>!"</div>`;
  $('#sppNests').innerHTML=o.nests.map((q,i)=>`<button class="spn${o.nests.length>3?' n4':''}" data-i="${i}">${nestSVG(q[0],q[1])}</button>`).join('');
  $('#sppMsg').textContent=o.num?`Count in ${o.cols}s, one row at a time!`:'Count the rows, then how many eggs in each row!';
  speak(o.num?`A note from a hiding pup: my nest has ${o.rows*o.cols} eggs, in rows of ${o.cols}. How many rows is that? Count in ${o.cols}s!`:`A note from a hiding pup: my nest has ${o.rows} rows of ${o.cols} eggs. Which nest is it? ${F} says: count the rows!`);
  document.querySelectorAll('#sppNests .spn').forEach(b=>tap(b,()=>tapNest(o,+b.dataset.i,b)));
  $('#sppick').classList.add('on');}
function lightRows(b,r){b.querySelectorAll('.sprow').forEach(g=>g.classList.remove('lit'));for(let i=0;i<r;i++)setTimeout(()=>{const g=b.querySelector(`.sprow[data-r="${i}"]`);if(g)g.classList.add('lit');snd.note(i);},300+i*420);}
function tapNest(o,i,b){if(PK!==o||o.done[i])return;const q=o.nests[i];
  if(i===o.right){o.done[i]=1;sfx.yip(o.p.pitch);b.classList.add('win');b.insertAdjacentHTML('beforeend',`<div class="sppup">${critterSVG(sp(o.p),{anim:false})}</div>`);$('#sppMsg').textContent=`That's the one! It's ${o.p.name}!`;
    setTimeout(()=>{closePick();markFound(o);found(o.p,'nest',o);},1400);return;}
  o.done[i]=1;o.tries++;const S=NESTF[(hsh(o.p.id)+o.tries*3+i)%NESTF.length];sfx.oops();b.classList.add('nope');b.insertAdjacentHTML('beforeend',`<span class="spwho">${S[0]}</span>`);lightRows(b,q[0]);
  let m=`${S[1]} That nest has ${q[0]} ${q[0]>1?'rows':'row'} of ${q[1]}: ${steps(q[1],q[0])}. That's ${q[0]*q[1]} eggs.`;
  m+=o.num?` We need ${o.rows*o.cols} eggs in rows of ${o.cols}: ${steps(o.cols,o.rows)}. That's ${o.rows} rows!`:` We need ${o.rows} rows of ${o.cols}: ${steps(o.cols,o.rows)}.`;
  if(o.tries>=2){const r=$('#sppNests').querySelector(`.spn[data-i="${o.right}"]`);if(r)r.classList.add('hint');m+=' Look, that nest is sparkling!';}
  $('#sppMsg').textContent=m;speak(m);}
/* tag pups: the first peek makes them giggle and run to another bush along a fresh egg trail */
function peek(o){if(player.lock||xFound(o.p.id))return;player.lock=true;o.busy=true;hush();snd.rustle();say('Rustle, rustle! Anybody in the blossom bush?');o.g.scale.set(DS*1.06,DS*.94,DS*1.06);floatS('🌸',o.x,gy(o.x,o.z)+2.6,o.z,1.2);
  setTimeout(()=>{o.g.scale.setScalar(DS);if(!o.tagged){runOff(o);return;}o.busy=false;player.lock=false;found(o.p,'bush',o);},1100);}
function runOff(o){const p=o.p,S=o.S,g=pup3D(p,p.shiny),A=W.area;add(g,o.x,o.z);sfx.giggle();say(`Hee hee! ${p.name} giggles and runs off to another blossom bush! Follow the new egg trail!`);
  GS().tagged[p.id]=1;save();const path=(S.bc||[S.b,S.c]).slice();let seg=0,k=0;
  if(o.pr){W.ag.remove(o.pr.im);o.pr=null;}if(o.easy){W.ag.remove(o.easy);o.easy=null;}
  W.ticks.push(function run(dt){if(W.area!==A)return true;const a=path[seg],b=path[seg+1];if(!b){W.ag.remove(g);W.ag.remove(o.g);const n=bushSpot(p,S,A);LIVE=LIVE.filter(q=>q!==o);LIVE.push(n);W.things=W.things.filter(t=>t!==o.th);flushTo(W.ag);player.lock=false;return true;}
    const d=Math.hypot(b[0]-a[0],b[1]-a[1])||.01;k+=dt*14/d;const e=Math.min(1,k),x=a[0]+(b[0]-a[0])*e,z=a[1]+(b[1]-a[1])*e;g.position.set(x,walkY(x,z)+Math.abs(Math.sin(W.t*16))*.35,z);g.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);animPup(g,W.t,true);
    if(e>=1){seg++;k=0;}});}

/* ================= seed pictures for the giant flower buds (tap the seeds in order) ================= */
const daisyPts=(()=>{const o=[];for(let i=0;i<16;i++){const a=-PI/2+i*PI/8,r=i%2?13:27;o.push([+(50+Math.cos(a)*r).toFixed(1),+(38+Math.sin(a)*r).toFixed(1)]);}return o;})();
const eggPts=(()=>{const o=[];for(let i=0;i<12;i++){const a=-PI/2+i*PI/6,ry=Math.sin(a)<0?28:22,rx=Math.sin(a)<0?17-Math.abs(Math.sin(a))*3:20;o.push([+(50+Math.cos(a)*rx).toFixed(1),+(42+Math.sin(a)*ry).toFixed(1)]);}return o;})();
const SHAPES={
 tulip:[[50,62],[38,58],[32,48],[32,34],[34,20],[42,30],[50,16],[58,30],[66,20],[68,34],[68,48],[62,58]],
 daisy:daisyPts,
 butterfly:[[50,26],[40,16],[24,14],[16,24],[22,36],[34,40],[22,46],[20,58],[32,64],[44,54],[50,60],[56,54],[68,64],[80,58],[78,46],[66,40],[78,36],[84,24],[76,14],[60,16]],
 egg:eggPts,
 leaf:[[50,68],[36,58],[28,44],[30,28],[40,16],[50,10],[60,16],[70,28],[72,44],[64,58]]};
const SHC={tulip:'#ff8ab0',daisy:'#ffffff',butterfly:'#ffc04a',egg:'#8ad0ff',leaf:'#8ad05a'};
const STEP={meadow:1,snowy:1,reef:2,ninja:2,number:3,gadget:5,rescue:5,dino:10,planet:10,village:2};
let CP=null;
function seedUI(){if($('#spseed'))return;const d=el('div','ov','<div class="card" id="spsCard"><h2 id="spsH"></h2><div id="spsBox"></div><p id="spsMsg"></p><div class="btns"><button class="btn white" id="spsBack">Back</button></div></div>');d.id='spseed';document.body.appendChild(d);
  tap('#spsBack',()=>{sfx.boop();closeSeed();});}
function closeSeed(){$('#spseed').classList.remove('on');if(CP&&CP.lock!==false)player.lock=false;const cb=CP&&CP.cancel;CP=null;hush();if(cb)cb();}
function seedDot(x,y,r){return `<ellipse cx="${x}" cy="${y}" rx="${r*.75}" ry="${r}" fill="#a87a4a" stroke="#5b3e22" stroke-width=".35" transform="rotate(20 ${x} ${y})"/><path d="M${x-r*.2} ${y-r*.5} q${r*.3} ${r*.5} 0 ${r}" stroke="#d8b080" stroke-width=".3" fill="none"/>`;}
function seedPuzzle(o){seedUI();const pts=o.pts,step=o.step||1,start=o.start!=null?o.start:step,lab=i=>start+i*step,n=pts.length,fill=o.fill||'#ffb8d0';CP={o,i:0,lock:o.lock,cancel:o.cancel};$('#spsBack').style.display=o.noBack?'none':'';
  $('#spsBox').innerHTML=`<svg viewBox="0 0 100 75" id="spsSvg"><rect width="100" height="75" rx="4" fill="#c8eaa0"/><rect width="100" height="10" fill="#bfe4ff"/><path d="M0 10 q10 -3 20 0 t20 0 t20 0 t20 0 t20 0 V14 H0 Z" fill="#a8d888"/><circle cx="90" cy="5" r="3" fill="#ffe066"/>`+
    `<g opacity=".5"><path d="M6 72 q2 -6 4 0 M14 70 q2 -6 4 0 M84 72 q2 -6 4 0 M92 70 q2 -6 4 0" stroke="#5aaf4a" stroke-width="1" fill="none"/></g>`+
    `<g id="spsLines"></g><g id="spsPic" opacity="0">${o.pic||''}</g>`+
    pts.map((p,i)=>`<g class="spsd" data-i="${i}"><circle cx="${p[0]}" cy="${p[1]}" r="5.4" fill="transparent"/><circle class="spsg" cx="${p[0]}" cy="${p[1]}" r="2.4" fill="#ffffff" opacity=".35"/>${seedDot(p[0],p[1],1.5)}<text x="${p[0]+(p[0]>88?-3.4:2.2)}" y="${p[1]+(p[1]<12?4.8:-2)}" font-size="3.4" font-weight="900" fill="#ffffff" stroke="#3a5a20" stroke-width=".55" paint-order="stroke" font-family="Arial" text-anchor="${p[0]>88?'end':'start'}">${lab(i)}</text></g>`).join('')+`</svg>`;
  $('#spsH').textContent=o.title||'🌱 Plant the seeds in order!';const intro=o.say||`Tap the seeds in order: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;$('#spsMsg').textContent=step===1?'Start at 1 and keep going!':`Count in ${step}s: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;speak(intro);
  const mark=()=>document.querySelectorAll('#spsSvg .spsd').forEach(g=>g.classList.toggle('next',+g.dataset.i===CP.i));mark();
  const line=(a,b)=>`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#3f8f3a" stroke-width="1.3" stroke-linecap="round" stroke-dasharray="1.6 1"/>`;
  document.querySelectorAll('#spsSvg .spsd').forEach(g=>tap(g,()=>{if(!CP||CP.o!==o)return;const i=+g.dataset.i;
    if(i!==CP.i){if(i<CP.i)return;sfx.oops();const m=`Look for ${lab(CP.i)}.`;$('#spsMsg').textContent=m;speak(m);g.classList.remove('nope');void g.getBBox();g.classList.add('nope');return;}
    snd.note(i);g.classList.add('done');if(i>0)$('#spsLines').insertAdjacentHTML('beforeend',line(pts[i-1],pts[i]));
    CP.i++;if(CP.i<n){mark();$('#spsMsg').textContent=`${lab(i)}! Next: ${lab(CP.i)}`;return;}
    if(o.loop!==false){$('#spsLines').insertAdjacentHTML('beforeend',line(pts[n-1],pts[0]));$('#spsLines').insertAdjacentHTML('afterbegin',`<polygon class="spslit" points="${pts.map(p=>p.join(',')).join(' ')}" fill="${fill}" stroke="#26232e" stroke-width=".6"/>`);}
    mark();$('#spsSvg').classList.add('win');$('#spsPic').setAttribute('opacity','1');snd.pop();snd.twinkle();confetti(24);const m=o.win||'A flower picture!';$('#spsMsg').textContent=m;speak(m);
    const done=o.done;CP.cancel=null;setTimeout(()=>{if(!$('#spseed').classList.contains('on'))return;$('#spseed').classList.remove('on');if(o.lock!==false)player.lock=false;CP=null;if(done)done();},o.hold||1900);}));
  $('#spseed').classList.add('on');}
function shapeFor(p){return p.id==='primrose'?'daisy':p.id==='tulip'?'tulip':['tulip','daisy','butterfly','egg','leaf'][hsh(p.id)%5];}
function picFor(sh){if(sh==='tulip')return '<path d="M50 62 V74" stroke="#3f8f3a" stroke-width="2.4"/><path d="M50 70 q-8 -6 -12 -2 q6 4 12 2 Z" fill="#5aaf4a"/>';if(sh==='daisy')return '<path d="M50 50 V74" stroke="#3f8f3a" stroke-width="2.4"/><circle cx="50" cy="38" r="7" fill="#ffd23f" stroke="#26232e" stroke-width=".6"/>';
  if(sh==='butterfly')return '<rect x="48.6" y="22" width="2.8" height="38" rx="1.4" fill="#26232e"/><path d="M49 22 q-4 -6 -6 -8 M51 22 q4 -6 6 -8" stroke="#26232e" stroke-width=".8" fill="none"/>';if(sh==='egg')return '<path d="M32 46 q4.5 -4 9 0 t9 0 t9 0 t9 0" stroke="#ffffff" stroke-width="2" fill="none"/><circle cx="44" cy="32" r="2" fill="#fff"/><circle cx="57" cy="36" r="2" fill="#fff"/><circle cx="48" cy="56" r="2" fill="#fff"/>';
  return '<path d="M50 68 Q50 40 50 12" stroke="#3f8f3a" stroke-width="1.2" fill="none"/><path d="M50 30 l-10 -6 M50 42 l-14 -8 M50 30 l10 -6 M50 42 l14 -8 M50 54 l-12 -6 M50 54 l12 -6" stroke="#3f8f3a" stroke-width=".8"/>';}
function openFlower(o){if(player.lock||xFound(o.p.id))return;player.lock=true;hush();snd.twinkle();const isl=o.p.island,sh=shapeFor(o.p);
  let step=STEP[isl]||1;if(isl==='number'&&typeof tablesOn==='function'){const tb=tablesOn();if(tb&&tb.length)step=pick(tb);}
  seedPuzzle({pts:SHAPES[sh],step,fill:SHC[sh],pic:picFor(sh),title:'🌱 Plant the seeds in order!',
    say:`A giant flower bud! Plant the seeds in order to make a picture.${step>1?` Count in ${step}s!`:''}`,win:'A picture made of seeds! The giant bud is opening...',
    done:()=>{snd.pop();confetti(30);setTimeout(()=>{markFound(o);found(o.p,'flower',o);},700);}});}

/* ================= finding a spring pup ================= */
function found(p,how,o){const X=GS();if(X.found[p.id])return;X.found[p.id]=Date.now();X.how[p.id]=how;state.stars+=10;W.findT=W.t;W.trail.forEach(t=>W.ag.remove(t));W.trail=[];save();hud();
  const P=player,dx=P.x-o.x,dz=P.z-o.z,d=Math.hypot(dx,dz)||1,g=pup3D(p,p.shiny);add(g,o.x+dx/d*1.9,o.z+dz/d*1.9);g.rotation.y=Math.atan2(-dx,-dz)+PI;g.userData.jump=.8;
  player.cheer=1.3;player.wave=2.4;sfx.jingle();confetti(36);W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});
  if(o.k==='flower'&&o.g){W.ag.remove(o.g);const g2=grp();bud3D(g2,1.15,true,o.col);add(g2,o.x,o.z);o.g=g2;}
  const n=nFound(),where={nest:'in a nest of painted eggs',bush:'peeking out of a blossom bush',flower:'inside a giant flower bud'}[how]||'';
  card({art:pupBox(sp(p)),h:`You found ${p.name}!`,h3:`🌸 Spring · ${p.breed} ${typeBadge(p.type)}`,p:FACT[p.id]||p.fact,say:`You found ${p.name}, ${where}! ${FACT[p.id]||''}`,
    btns:[['🌸 Hooray!','green',()=>{W.ag.remove(g);PAL.jump=.8;setTimeout(()=>after(p,n),500);}]]});
  if(window.SPSTORY&&SPSTORY.onFind)try{SPSTORY.onFind(p);}catch(e){}}
function after(p,n){const I=islandOf(p.island);
  if(I&&islN(I)>=NEED&&!GS().bb[I.id]){setTimeout(()=>bud(I),400);return;}
  if(window.SPSTORY&&SPSTORY.afterFind&&SPSTORY.afterFind(p,n))return;
  if(n===all().length){say(`Every single spring pup is found! All ${n} of them! Egg-cellent, Seb!`);return;}
  const A=W.area,L=areaX(A.id),left=L.filter(q=>!xFound(q.id)).length;
  say(`${n} of ${all().length} spring pups found! `+(left?`${left} more ${left>1?'pups':'pup'} hiding in ${A.name}.`:`Every spring pup in ${A.name} is found!`)+(I&&!GS().bb[I.id]?` Find ${NEED-islN(I)} more on ${I.name} for a blossom bud!`:''));}

/* ================= the nine blossom buds ================= */
const LESSON={blossom:'A seed needs time, sunshine and water to grow. So do you, so be patient with yourself.',flurry:'Even after the coldest winter, spring always comes back. Hard times don\'t last for ever.',pearl:'Every baby animal needs a safe place to grow, so be gentle with nests and burrows.',
 emberuni:'Blossom only lasts a little while, so stop and enjoy it with your friends.',tally:'Look closely and you\'ll find patterns everywhere. Count the petals on a flower!',gizmouni:'Living things need light, water and care. Look after them, and they will grow.',
 beaconuni:'If you find an egg or a baby animal on its own, leave it where it is and tell a grown-up. Its mum is probably close by.',amberuni:'Even the biggest dinosaur started as a tiny egg. Everybody starts small.',nebulauni:'The Moon tree seeds flew all the way round the Moon and still grew. You can grow wherever you are.'};
/* the duckling's blossom branch: nine buds, opening as they come home */
function budBranch(n,o){o=o||{};const L=ISLANDS.map(I=>I.id),got=(G0()||{}).bb||{};let s=`<svg viewBox="0 0 200 120" xmlns="http://www.w3.org/2000/svg"><rect x="2" y="2" width="196" height="116" rx="14" fill="#eaf7ff" stroke="#9ac8e8" stroke-width="3"/>`+
  `<path d="M10 92 Q60 70 100 74 T192 48" stroke="#7a5230" stroke-width="7" fill="none" stroke-linecap="round"/>`;
  const BY=[88,80,76,74,74,74,68,60,50],P=BY.map((y,i)=>[18+i*20.75,y+(i%2?13:-13)]);
  L.forEach((id,i)=>{const q=P[i],has=o.all||(n!=null?i<n:!!got[id]);s+=`<path d="M${q[0]} ${BY[i]} L${q[0]} ${q[1]}" stroke="#7a5230" stroke-width="3"/>`;
    if(has)s+=SL.flower2D(q[0],q[1],12,i%2?'#ffd0e0':'#ff9ac0','#ff6a98')+`<text x="${q[0]}" y="${i%2?q[1]+21:q[1]-13}" font-size="9" text-anchor="middle">${ISLANDS[i].icon}</text>`;
    else s+=`<ellipse cx="${q[0]}" cy="${q[1]}" rx="5" ry="7" fill="#c8d8c0" stroke="#8aa080" stroke-width="1.5" stroke-dasharray="3 2"/>`;});
  return s+'</svg>';}
function bud(I){const u=I.boss.uni,P=player,X=GS();player.lock=true;hush();
  const a=P.h+.7,x=P.x+Math.sin(a)*4.5,z=P.z+Math.cos(a)*4.5,g=pup3D(u,true);add(g,x,z);g.rotation.y=Math.atan2(P.x-x,P.z-z);g.userData.jump=.9;snd.twinkle();confetti(30);floatS('🌸',x,gy(x,z)+4,z,3);
  W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});const n=nBb()+1,F=pal().name;
  story([{art:`<div class="fitsvg">${critterSVG(sp(u))}</div>`,t:`${u.name} trots up in a flower crown! "You found ${NEED} spring pups on ${I.name}, and ${F} waddled along behind you all the way."`},
    {art:`<div class="fitsvg">${critterSVG(sp(u))}</div><div style="font-size:64px;line-height:1">🌸</div>`,t:`"The March wind blew this pink bud right into my mane! Here is something to remember, ${F}: ${LESSON[u.id]||'Friends help each other grow.'}"`},
    {art:`<div class="fitsvg" style="width:260px">${budBranch(n)}</div>`,t:`${F} tucks the bud onto the blossom branch. ${n} of 9 buds!`+(n===9?' The branch is full at last!':` ${F} flaps ${his()} little wings with joy.`)}],
    ()=>{X.bb[I.id]=Date.now();save();W.ag.remove(g);player.lock=false;PAL.jump=1;sfx.fanfare();snd.song(n);confetti(40);hud();
      if(window.SPSTORY&&SPSTORY.onBud)try{SPSTORY.onBud(I,n);}catch(e){}
      if(n<9)say(`${n} of 9 blossom buds! Find ${NEED} spring pups on each island to collect them all.`);});}
function uniHome(IS){const B=IS.boss;if(!B||!B.uni||!(G0()&&G0().bb[IS.id]))return;if(W.bossUp===IS.id)return;W.bossUp=IS.id;const u=pup3D(B.uni,true);u.rotation.y=Math.atan2(-B.x,-B.z)+PI;add(u,B.x,B.z);col(B.x,B.z,1.4);
  W.ticks.push(()=>{animPup(u,W.t,false);});W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(`${B.uni.name} says: "${LESSON[B.uni.id]} Happy spring, Seb!"`);}});}

/* ================= Seb's duckling ================= */
const PAL={g:null,x:0,z:0,h:0,jump:0,step:0};
function duck3D(crown){const g=grp(),b=grp();g.add(b);const Y='#ffd84a',Y2='#ffe680',O='#ff9a2a';
  mk('sph',Y,.36,.32,.42,0,.36,0,b);mk('sph',Y2,.26,.2,.3,0,.3,.12,b);mk('sph',Y,.25,.25,.25,0,.78,.2,b);
  const bk=mk('box',O,.2,.06,.18,0,.74,.46,b);bk.rotation.x=.1;
  [-1,1].forEach(s=>{mk('sph','#26232e',.045,.05,.045,s*.12,.84,.4,b);mk('sph','#ffffff',.015,.015,.015,s*.12+.01,.86,.44,b);const w=mk('sph',Y,.1,.2,.26,s*.33,.4,-.02,b);w.rotation.z=s*.4;
    mk('box',O,.14,.03,.18,s*.12,.02,.08,b);});
  mk('cone',Y,.07,.16,.07,0,.66,-.4,b).rotation.x=-1.2;
  if(!crown){const sh=mk('hemi','#ffffff',.2,.13,.2,0,.98,.18,b);sh.rotation.x=.25;for(let i=0;i<5;i++){const a=i/5*PI*2,c=mk('cone','#ffffff',.05,.09,.05,Math.cos(a)*.17,1.0,.18+Math.sin(a)*.17,b);c.rotation.x=0;}}
  else{const r=mk('tor','#6abf4a',.22,.22,.25,0,.98,.2,b);r.rotation.x=PI/2;for(let i=0;i<6;i++){const a=i/6*PI*2;mk('sph',i%2?'#ffffff':'#ffd0e0',.06,.04,.06,Math.cos(a)*.22,1.0,.2+Math.sin(a)*.22,b);}}
  bakeModel(g,crown?'sppal2':'sppal');g.scale.setScalar(1.6);Object.assign(g.userData,{body:b});g.traverse(o=>{o.frustumCulled=false;});return g;}
function usePal(g){if(PAL.g&&PAL.g!==g&&PAL.g.parent)PAL.g.parent.remove(PAL.g);PAL.g=g;if(!g.parent)scene.add(g);}
function palEnter(A){if(!named()){if(PAL.g)PAL.g.visible=false;return;}
  const big=!!(G0()&&G0().done);if(!PAL.g||PAL.big!==big){usePal(duck3D(big));PAL.big=big;}PAL.g.visible=true;const P=player;PAL.x=P.x-Math.sin(P.h)*1.6;PAL.z=P.z-Math.cos(P.h)*1.6;PAL.h=P.h;
  W.things.push({x:PAL.x,z:PAL.z,r:3.2,icon:'💬',label:pal().name,ppal:1,show:()=>!followers.some(f=>Math.hypot(f.x-player.x,f.z-player.z)<2.3),act:palTalk});
  W.ticks.push(palTick);}
function palHide(){if(PAL.g)PAL.g.visible=false;}
/* after the Blossom Festival the duckling wears a daisy crown from its mum */
function palCrown(){const big=!!(G0()&&G0().done);if(!PAL.g||PAL.big===big)return;const old=PAL.g,vis=old.visible,x=old.position.x,y=old.position.y,z=old.position.z,h=old.rotation.y;usePal(duck3D(big));PAL.big=big;PAL.g.visible=vis;PAL.g.position.set(x,y,z);PAL.g.rotation.y=h;}
function nearest(){let best=null,bd=1e9;LIVE.forEach(o=>{if(xFound(o.p.id))return;const d=Math.hypot(player.x-o.x,player.z-o.z);if(d<bd){bd=d;best=o;}});return best?{o:best,d:bd}:null;}
function palTick(dt){if(!PAL.g||!on())return true;if(!PAL.g.visible||PAL.script)return;const P=player,t=W.t,u=PAL.g.userData;
  /* ducklings follow right behind their mum: here, right behind Seb */
  const fx=Math.sin(P.h),fz=Math.cos(P.h),tx=P.x-fx*1.7+fz*.3,tz=P.z-fz*1.7-fx*.3,dx=tx-PAL.x,dz=tz-PAL.z,d=Math.hypot(dx,dz),mv=d>.2;
  if(d>.05){PAL.x+=dx*Math.min(1,dt*3.6);PAL.z+=dz*Math.min(1,dt*3.6);}if(d>26){PAL.x=tx;PAL.z=tz;}
  PAL.h=lerpAng(PAL.h,mv?Math.atan2(dx,dz):P.h,Math.min(1,dt*6));if(PAL.jump>0)PAL.jump-=dt;PAL.step+=mv?dt*13:0;
  const hop=PAL.jump>0?Math.sin(PAL.jump*PI*1.6)*.6:0;
  PAL.g.position.set(PAL.x,walkY(PAL.x,PAL.z)+hop+(W.area&&W.area.swim?1:0),PAL.z);PAL.g.rotation.y=PAL.h;
  const th=W.things.find(q=>q.ppal);if(th){th.x=PAL.x;th.z=PAL.z;}
  /* warmer and colder: the duckling waddles and cheeps faster near a hiding pup */
  const n=nearest(),k=n?Math.max(0,Math.min(1,1-n.d/45)):0;u.body.rotation.z=mv?Math.sin(PAL.step)*.14:Math.sin(t*(3+14*k))*.07;u.body.position.y=Math.abs(Math.sin(t*(3+14*k)))*.05*k;
  if(n&&n.d<10&&t-(PAL.dingT||0)>3.4&&!P.lock&&!ovOpen()){PAL.dingT=t;snd.cheep();}
  if(t-(PAL.factT||0)>140&&!P.lock&&!ovOpen()&&t-W.msgT>20){PAL.factT=t;say(`${pal().name} says: "${pick(PFACT)}"`);}}
const PFACT=['Did you know? Ducklings follow the first moving thing they see when they hatch. That\'s why I follow you!','Did you know? A duckling has a tiny bump on its beak, called an egg tooth, for cracking out of its egg.','Did you know? A duck\'s egg takes about 28 days to hatch.',
 'Did you know? Ducklings can walk and swim just a few hours after they hatch.','Did you know? Grown-up ducks have waterproof feathers, so the water rolls right off them.','Peep! I wonder if my real mum is looking for me.','Did you know? Ducks have webbed feet, like little paddles, for swimming.'];
function dir(o){const P=player,a=Math.atan2(o.x-P.x,o.z-P.z),r=angDiff(a,W.camYaw),d=Math.hypot(o.x-P.x,o.z-P.z);
  const w=Math.abs(r)<.6?'straight ahead':Math.abs(r)>2.4?'behind you':r>0?'over to your left':'over to your right';return `${w}, ${d<12?'really close':d<30?'not far away':'a long way off'}`;}
function palTalk(){if(player.lock)return;snd.cheep();PAL.jump=.6;const F=pal().name,n=nearest(),A=W.area;
  if(n){const o=n.o,w=dir(o);say(o.k==='nest'?`${F} says: "Peep! I can see nests with painted eggs, ${w}!"`:o.k==='flower'?`${F} says: "There's a giant flower bud, ${w}!"`:`${F} says: "A trail of painted eggs! It goes ${w}. Let's follow it!"`);return;}
  const I=A.island&&islandOf(A.island),more=I?I.areas.filter(a=>areaX(a.id).some(p=>!xFound(p.id))):[];
  if(more.length)say(`${F} says: "Every pup here is found! Shall we try ${more[0].name}?"`);
  else if(I)say(`${F} says: "Every spring pup on ${I.name} is found! Let's try another island."`);
  else{const left=ISLANDS.find(I2=>islX(I2).some(p=>!xFound(p.id)));say(left?`${F} says: "Let's look for spring pups on ${left.name}!"`:`${F} says: "Happy spring, Seb! Peep!"`);}}
/* a picture of the duckling, for cards and story scenes */
function duckSVG(o){o=o||{};const K=INK,Y='#ffd84a',O='#ff9a2a';
  const shell=o.shell?`<path d="M72 46 L80 34 L88 44 L96 30 L104 44 L112 32 L120 46 Q118 22 96 20 Q74 22 72 46 Z" fill="#ffffff" stroke="${K}" stroke-width="4" stroke-linejoin="round"/><circle cx="86" cy="30" r="2.6" fill="#d8d0c0"/><circle cx="106" cy="28" r="2.2" fill="#d8d0c0"/>`:'';
  const crown=o.crown?`<path d="M68 48 Q96 34 124 48" stroke="#6abf4a" stroke-width="6" fill="none" stroke-linecap="round"/>`+[[72,46],[84,40],[96,38],[108,40],[120,46]].map((q,i)=>SL.flower2D(q[0],q[1],10,i%2?'#ffd0e0':'#ffffff')).join(''):'';
  const egg=o.egg?`<path d="M40 150 L52 138 L62 150 L74 136 L86 150 L98 138 L110 150 L122 136 L134 150 L146 138 L160 150 Q160 188 100 190 Q40 188 40 150 Z" fill="#ffffff" stroke="${K}" stroke-width="4" stroke-linejoin="round"/>`:'';
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">`+
    (o.egg?'':[-1,1].map(g=>`<path d="M${100+g*20} 168 l${g*-4} 14 l${g*14} 4 l${g*4} -6 l${g*8} 6 l${g*2} -10 Z" fill="${O}" stroke="${K}" stroke-width="3.4" stroke-linejoin="round"/>`).join(''))+
    `<ellipse cx="104" cy="134" rx="52" ry="40" fill="${Y}" stroke="${K}" stroke-width="4"/><path d="M150 120 q22 -6 26 -20 q-4 16 -18 26 Z" fill="${Y}" stroke="${K}" stroke-width="3.4" stroke-linejoin="round"/>`+
    `<path d="M${o.flap?78:84} 122 q${o.flap?-30:-16} ${o.flap?-30:6} ${o.flap?-22:-8} ${o.flap?-6:30} q14 2 24 -14 Z" fill="#ffe680" stroke="${K}" stroke-width="3.4" stroke-linejoin="round"/>`+
    `<circle cx="96" cy="76" r="38" fill="${Y}" stroke="${K}" stroke-width="4"/><path d="M80 52 q4 -10 10 -6 q-2 -8 8 -6" stroke="${K}" stroke-width="3" fill="none" stroke-linecap="round"/>`+
    `<path d="M112 84 Q140 80 146 90 Q140 100 112 96 Z" fill="${O}" stroke="${K}" stroke-width="3.6" stroke-linejoin="round"/><path d="M114 90 H140" stroke="${K}" stroke-width="2"/>`+
    `<circle cx="102" cy="70" r="7" fill="${K}"/><circle cx="104" cy="67.5" r="2.4" fill="#fff"/><circle cx="80" cy="72" r="6" fill="${K}"/><circle cx="81.6" cy="69.6" r="2" fill="#fff"/>`+
    `<circle cx="74" cy="86" r="6" fill="#ff9ec0" opacity=".7"/><circle cx="114" cy="104" r="5" fill="#ff9ec0" opacity=".5"/>${egg}${shell}${crown}</svg>`;}

/* ================= the opening ================= */
const SUG=['Waddle','Dibble','Dabble','Quackers','Puffball','Splosh'];
const cleanName=s=>{s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,18);return s?s.charAt(0).toUpperCase()+s.slice(1):'';};
const big=e=>`<div style="font-size:100px;line-height:1">${e}</div>`,dsv=(w,o)=>`<div class="fitsvg" style="width:${w||170}px">${duckSVG(o)}</div>`;
function intro(){const X=GS();X.inv=1;save();player.lock=true;hush();
  story([{art:big('🌸🌷'),t:'Spring has come to Pawprint Village! The blossom is opening, the birds are singing, and today is the Blossom Festival!'},
    {art:`<div class="fitsvg" style="width:150px">${grannySVG()}</div>`,t:'"When the Festival Tree blossoms," says Granny Paws, "everyone plants the Festival Garden together. But look: the tree\'s nine special buds have gone! Somebody must have picked them."'},
    {art:big('🥚🐶'),t:'"The pups have gone off to play Egg Hunt Hide-and-Seek all over the islands. Egg Hunt rules: every hider takes painted eggs to hide with!"'},
    {art:big('🪺🌳'),t:'"And somebody saw a strange new nest in Bluebell Wood, made of twigs and pink buds. Would you go and look, Seb?"'}],
    ()=>{state.season='sp';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='sp'&&S.hide)try{S.hide();}catch(e){}});fadeTo(()=>{enterArea('wood');arrive();},['🌸','Spring Blossom']);});}
function nest3D(o){o=o||{};const g=grp();const t=mk('tor','#9a6a3a',.85,.85,1.6,0,.3,0,g);t.rotation.x=PI/2;mk('disc','#6a4a2a',.72,1,.72,0,.22,0,g);
  const buds=[];if(o.buds)for(let i=0;i<9;i++){const a=i/9*PI*2,b=mk('sph',i%2?'#ff9ac0':'#ffb8d0',.18,.22,.18,Math.cos(a)*.88,.55,Math.sin(a)*.88,g);buds.push(b);}
  if(o.reeds)for(let i=0;i<10;i++){const a=i/10*PI*2+.3,r=1.4+(i%3)*.2;mk('cyl','#6a9a3a',.04,1.4+(i%4)*.3,.04,Math.cos(a)*r,.7,Math.sin(a)*r,g);}
  return {g,buds};}
function arrive(){const P=player;player.lock=true;const a=W.camYaw+.42,x=P.x+Math.sin(a)*5.2,z=P.z+Math.cos(a)*5.2,N=nest3D({buds:1});add(N.g,x,z);
  const egg=mk('sph','#f4f0e8',.3,.4,.3,0,.62,0,N.g),D=duck3D(false);usePal(D);PAL.big=false;D.visible=true;PAL.script=true;PAL.x=x;PAL.z=z;D.position.set(x,walkY(x,z)+.25,z);D.rotation.y=Math.atan2(P.x-x,P.z-z);D.scale.setScalar(.01);
  ARR={N,x,z};let t=0,cr=0;
  W.ticks.push(dt=>{t+=dt;if(t<2.4){egg.rotation.z=Math.sin(t*(t<1.2?10:22))*.25;if(t>1.2&&!cr){cr=1;snd.crack();}}else if(egg.parent){N.g.remove(egg);snd.crack();snd.cheep();floatS('🐣',x,gy(x,z)+2.4,z,1.6);}
    const k=Math.max(0,Math.min(1,(t-2.4)/.5));D.scale.setScalar(1.6*(.01+.99*k));if(t>2.4)D.position.y=walkY(x,z)+.25+Math.abs(Math.sin((t-2.4)*8))*.2*(1-Math.min(1,(t-2.4)/1.5));
    if(t>3.6){meet();return true;}});}
let ARR=null;
function meet(){story([{art:dsv(190,{shell:1}),t:'CRACK! Out pops a fluffy yellow duckling, with a bit of eggshell still on its head! It blinks... and the first thing it sees is YOU. "Mum!" it peeps.'},
    {art:dsv(190,{shell:1,flap:1}),t:'Ducklings follow the first moving thing they see when they hatch. So now this little duckling thinks Seb is its mum!'}],()=>nameCard(()=>whoosh()));}
function nameCard(done){sfx.chime();
  card({art:dsv(160,{shell:1}),h:'Name the duckling!',p:`The little duckling doesn't have a name yet. What would you like to call it?<input id="spName" maxlength="18" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Type a name..."><span class="xSug">${SUG.map(s=>`<button class="opt">${s}</button>`).join('')}</span><span class="xSex"><button class="opt on" data-g="0">👦 Boy</button><button class="opt" data-g="1">👧 Girl</button></span>`,
    say:'The little duckling does not have a name yet. Type a name, or pick one. Is your duckling a boy or a girl?',
    btns:[['✓ That\'s the name!','green',()=>{const n=cleanName($('#spName').value)||pick(SUG),g=!!+(document.querySelector('#celeCard .xSex .on')||{dataset:{g:0}}).dataset.g;
      GS().pal={name:n,girl:g,at:Date.now()};save();sfx.fanfare();confetti(50);player.cheer=1.6;if(done)done();}]]});
  const inp=$('#spName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .xSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));
  document.querySelectorAll('#celeCard .xSex .opt').forEach(b=>tap(b,()=>{document.querySelectorAll('#celeCard .xSex .opt').forEach(q=>q.classList.toggle('on',q===b));sfx.boop();}));}
function blowBuds(){if(!ARR)return;const L=ARR.N.buds.slice();snd.wind();let t=0;W.ticks.push(dt=>{t+=dt;L.forEach((b,i)=>{b.position.y+=dt*(2+i*.3);b.position.x+=dt*(3+Math.sin(i)*2);b.position.z+=dt*Math.cos(i*1.7)*2;b.rotation.z+=dt*4;});
    if(t>3){L.forEach(b=>{if(b.parent)b.parent.remove(b);});return true;}});}
function whoosh(){const F=pal().name;blowBuds();
  story([{art:dsv(170),t:`"I'm ${F}!" peeps ${F}... and WHOOSH! A gust of March wind blows through the wood. The pink buds fly out of the nest and away over the islands!`},
    {art:`<div class="fitsvg" style="width:260px">${budBranch(0)}</div>`,t:`"Those are the Festival Tree's nine special buds!" Without them, the tree can't blossom for the festival. "Oh no!" says ${F}. "Maybe the unicorns can catch them."`},
    {art:big('🪺🥚🌷'),t:'The pups are hiding in nests of painted eggs (count the rows!), in blossom bushes at the end of egg trails, and inside giant flower buds.'},
    {art:dsv(150)+big('🦄'),t:`Find 6 pups on an island, and its unicorn will give ${F} a blossom bud. Collect all nine, and the Festival Tree can blossom! ${F} cheeps faster when a hidden pup is near. And who is ${F}'s real mum? Keep your eyes open!`}],
    ()=>{const X=GS();X.intro=Date.now();save();player.lock=false;PAL.script=false;if(ARR&&ARR.N.g.parent)W.ag.remove(ARR.N.g);ARR=null;palEnter(W.area);hud();say(`Let's find the spring pups! You're on Meadow Island already, so let's start here. ${F} will waddle along behind you!`);
      if(window.SPSTORY&&SPSTORY.onIntro)try{SPSTORY.onIntro();}catch(e){}});}
/* the invitation, once Spring Blossom is open (earlier seasons' invitations go first);
   also when Seb is still in a finished Summer Beach Party */
const seaFree=()=>!state.season||(state.season==='sb'&&sbDone());
const _ea3=enterArea;enterArea=function(id,pos,msg){_ea3.apply(this,arguments);if(!seaFree()||id!=='village'||!opened()||!state.intro)return;
  if(Object.values(window.SEASONS).some(S=>S.order<5&&S.opened()&&!(state.sx&&state.sx[S.id]&&state.sx[S.id].inv)))return;const X=G0();if(X&&(X.inv||X.pal))return;
  setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!seaFree()||!W.area||W.area.id!=='village')return;GS().inv=1;save();invite();},1900);};
function invite(){player.lock=true;sfx.chime();
  card({art:big('🌸✨'),h:'🌸 Spring Blossom is here!',p:'Spring has come to Pawprint Village, and today is the Blossom Festival! But the Festival Tree\'s special buds have gone. Shall we go and see?',
    btns:[['🌸 Yes, let\'s go!','green',()=>{player.lock=false;intro();}],['Not now','white',()=>{player.lock=false;say('Shake the Season Globe in the plaza whenever you want to play Spring Blossom!');}]]});}
function fromSb(){if(named()){XM.setSeason('sp');return;}intro();}
/* the grown-ups switch */
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=$('#setCard');if(!c)return;const S=state.set;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`🌸 Open Spring Blossom early<div class="opts"><button class="opt${S.spOpen?'':' on'}" data-x="0">Off</button><button class="opt${S.spOpen?' on':''}" data-x="1">On</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=sbDone()?'Spring Blossom is already open, because Summer Beach Party is finished. Shake the Season Globe in the village plaza to switch seasons.':'Spring Blossom opens after Summer Beach Party is finished. Turn this on to open it now: an invitation arrives the next time Seb is in the village.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt').forEach(b=>tap(b,()=>{S.spOpen=b.dataset.x==='1';if(!S.spOpen&&!sbDone()&&state.season==='sp'){state.season=null;XM.rebuildPack();palHide();openSettings.dirty='season';}save();sfx.boop();const d=openSettings.dirty;openSettings();if(d)openSettings.dirty=d;}));};}

/* ================= the Flower Board (the Season Calendar for Spring Blossom) ================= */
function board(){if(player.lock)return;sfx.chime();const n=nFound(),X=G0()||{bb:{}};
  const rows=ISLANDS.map(I=>`<div class="spbRow"><b>${I.icon}</b>${islX(I).map(p=>`<i class="${xFound(p.id)?'lit':''}">🌷</i>`).join('')}<em>${X.bb&&X.bb[I.id]?'🌸':''}</em></div>`).join('')+
    `<div class="spbRow"><b>🌟</b>${[SP.primrose,SP.tulip].map(p=>`<i class="${xFound(p.id)?'lit':''}">🌷</i>`).join('')}<em></em></div>`;
  card({cls:'spboard',h:`🌷 The Flower Board: ${n} of ${all().length}`,p:`A flower blooms for every spring pup you find. 🌸 means that island's blossom bud is home.<div class="spbGrid">${rows}</div>`,
    say:`${n} of ${all().length} spring pups found, and ${nBb()} of 9 blossom buds.`,btns:[['OK','green']]});}

/* ================= planning hiding spots (offline for sp_spots.js, and as a fallback) ================= */
function plan(A){const out={spots:{}};const L=areaX(A.id);if(!L.length)return out;const Gd=XM.grid(A,1),R=seed(hsh(A.id)+57),chosen=[];
  const avoid=[];(W.exits||[]).forEach(e=>avoid.push([e.x,e.z,9]));W.things.forEach(t=>{if(!t.hpal&&!t.spal&&!t.ppal&&!t.gfly&&!t.xdeer)avoid.push([t.x,t.z,4.5]);});if(A.start)avoid.push([A.start[0],A.start[1],9]);
  L.forEach(p=>{if(p.spot)avoid.push([p.spot.x,p.spot.z,5]);if(p.tag)avoid.push([p.tag.x,p.tag.z,5]);
    [(window.XSPOTS||{})[p.id],(window.GSPOTS||{})[p.id],(window.HSPOTS||{})[p.id],(window.SBSPOTS||{})[p.id]].forEach(xs=>{if(!xs)return;if(xs.x!=null)avoid.push([xs.x,xs.z,6]);['b','c'].forEach(k=>{if(xs[k])avoid.push([xs[k][0],xs[k][1],5]);});});});
  const okAt=(p,sep)=>{if(avoid.some(a=>Math.hypot(p[0]-a[0],p[1]-a[1])<a[2]))return false;if(chosen.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<sep))return false;return true;};
  const st=A.start?Gd.snap(A.start[0],A.start[1],1):Gd.snap(0,0,1);if(st<0)return out;const B0=Gd.bfs(st);
  const best=(B,mc,sep,lo,hi,ideal)=>{let bk=-1,bs=-1e9;for(let k=0;k<Gd.N;k++){if(Gd.clr[k]<mc||B.D[k]>=1e9||B0.D[k]>=1e9)continue;const d=B.D[k];if(d<lo||d>hi)continue;const p=Gd.xz(k);if(!okAt(p,sep))continue;
      const sp2=chosen.length?Math.min(30,Math.min(...chosen.map(q=>Math.hypot(p[0]-q[0],p[1]-q[1])))):30,s=sp2*.6-Math.abs(d-ideal)*.25+R()*6;if(s>bs){bs=s;bk=k;}}return bk;};
  L.forEach(p=>{const k=kindOf(p);
    if(k==='bush'){let a=p.spot?Gd.snap(p.spot.x,p.spot.z,1):-1;if(a<0||B0.D[a]>=1e9)a=st;const Ba=Gd.bfs(a),b=best(Ba,2,10,15,40,26);if(b<0)return;chosen.push(Gd.xz(b));
      const Bb=Gd.bfs(b);let c2=-1,bs=-1e9;const pa=Gd.xz(a);for(let q=0;q<Gd.N;q++){if(Gd.clr[q]<2||Bb.D[q]>=1e9)continue;const d=Bb.D[q];if(d<14||d>34)continue;const pq=Gd.xz(q);if(Math.hypot(pq[0]-pa[0],pq[1]-pa[1])<10||!okAt(pq,10))continue;const s=-Math.abs(d-22)*.3+R()*6;if(s>bs){bs=s;c2=q;}}
      if(c2<0)return;chosen.push(Gd.xz(c2));const P2=k2=>Gd.xz(k2).map(v=>+v.toFixed(1));
      out.spots[p.id]={k:'bush',a:P2(a),b:P2(b),c:P2(c2),ab:Gd.path(Ba,b),bc:Gd.path(Bb,c2)};}
    else{const kk=best(B0,3,12,12,140,40);if(kk<0)return;const q=Gd.xz(kk);chosen.push(q);out.spots[p.id]={k,x:+q[0].toFixed(1),z:+q[1].toFixed(1)};}});
  return out;}

/* ================= look and API ================= */
const css=document.createElement('style');css.textContent=`
#sppick,#spseed{z-index:60}#sppCard{max-width:980px;width:96%;background:#f6fff0;padding-top:12px;padding-bottom:10px}#sppCard h2{margin:0 0 4px}
#sppClue{display:flex;align-items:center;justify-content:center;gap:12px;margin:2px 0 6px}#sppClue .spface{font-size:56px;line-height:1}
.spbub{font-size:28px;font-weight:900;background:#fff;border:4px solid #6a9a3a;border-radius:20px;padding:8px 18px;line-height:1.2}.spbub b{color:#e8427a;font-size:32px}
#sppNests{display:flex;gap:10px;justify-content:center;flex-wrap:wrap}.spn{position:relative;width:260px;height:208px;padding:4px;border:4px solid #9ac870;border-radius:22px;background:#eaf8dc;cursor:pointer}
.spn.n4{width:200px;height:166px}.spn svg{width:100%;height:100%;display:block}.spn.nope{background:#f0f0e8;border-color:#c8c8b8}.spn.win{background:#fff6c8;border-color:#ffd23f}.spn.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
.spn .spwho{position:absolute;left:50%;top:6px;transform:translateX(-50%);font-size:54px;animation:xpop .5s}.spn .sppup{position:absolute;left:18%;right:18%;top:-4px;animation:xpop .6s}.spn .sppup svg{width:100%;height:auto;display:block}
.spnest .sprow{transition:filter .3s}.spnest .sprow.lit{filter:drop-shadow(0 0 4px #ffd23f) brightness(1.15)}
#sppMsg,#spsMsg{min-height:34px;font-size:24px;font-weight:800;margin:6px 0}
#spsCard{max-width:980px;width:96%;background:#f6fff0}#spsBox svg{width:620px;max-width:100%;height:auto;display:block;margin:4px auto;border-radius:18px}#spsCard h2{margin:0}#spsCard{padding-top:14px;padding-bottom:12px}
#spsSvg .spsd{cursor:pointer}#spsSvg .spsd.next .spsg{opacity:1;fill:#ffd23f;animation:spPulse 1s ease-in-out infinite;transform-box:fill-box;transform-origin:center}#spsSvg .spsd.done .spsg{opacity:.9;fill:#9ae07a}
#spsSvg .spsd.nope{animation:spNo .4s}#spsSvg .spslit{opacity:0;transition:opacity 1s}#spsSvg.win .spslit{opacity:.95;filter:drop-shadow(0 0 2px #ffd23f)}#spsPic{transition:opacity 1s}
@keyframes spPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.6)}}@keyframes spNo{0%,100%{transform:translateX(0)}30%{transform:translateX(-1px)}60%{transform:translateX(1px)}}
#spName{display:block;width:420px;margin:12px auto 8px;font-size:30px;font-weight:900;padding:10px 16px;border:4px solid #26232e;border-radius:18px;text-align:center;font-family:inherit;color:#26232e}
.spbGrid{margin-top:8px}.spbRow{display:flex;align-items:center;gap:2px;justify-content:center;margin:1px 0}.spbRow b{width:34px;font-size:24px}.spbRow em{width:30px;font-style:normal}
.spbRow i{width:24px;height:24px;font-style:normal;font-size:18px;line-height:24px;display:inline-block;filter:grayscale(1) opacity(.35)}.spbRow i.lit{filter:none;text-shadow:0 0 8px #ffd23f}`;
document.head.appendChild(css);
window.SEASONS.sp={id:'sp',order:5,name:'Spring Blossom',short:'Spring',icon:'🌸',tag:'🌸',card:['🌸','Spring Blossom cards'],lockShort:'After Summer',
  on,opened,named,nFound,total:()=>all().length,invite,hide:palHide,
  book:{xp:sp,found:xFound,islX,islN,fact:id=>FACT[id],tag:'🌸',word:'spring',isl:I=>`${I.name} in spring`}};
const SPRING=window.SPRING={on,opened,named,GS,G0,all,gpup,xFound,nFound,islN,islX,areaX,nBb,pal,he,his,him,He,found,duckSVG,duck3D,usePal,PAL,snd,plan,board,intro,fromSb,invite,
  seedPuzzle,SHAPES,SHC,bud3D,bush3D,nest3D,eggTrail,nestSVG,nestSpec,budBranch,glowMat,glowTex,palEnter,palHide,palCrown,LIVE:()=>LIVE,NEED,LESSON,kindOf,noSpots:false,SCALE,mixC,NESTF,bud,EGGC,steps};
})();
