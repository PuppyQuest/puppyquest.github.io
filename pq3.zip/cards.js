/* ================================================================
   Seb's Puppy Quest 3: Pup Trading Cards and the Card Binder
   Every pup Seb finds gets a card. Cards live in the Card Binder
   (its own button under the Pup House book): a set for each island,
   the science pups, and a shelf for Puppy Quest 2 cards brought
   across with a PQ2 backup code (one pack per level to open).
   Seb keeps 9 favourites in his Special Tin.
   Save: state.cards = {seen, tin, intro, pq2:{f, rd, buddy, open, at}}.
   Everything else is worked out from the rest of the save.
   ================================================================ */
(function(){

/* ---------- breed table: size, Speed, Brains, Cuddles, Bravery, everyday move ---------- */
const BREEDS={};
`Affenpinscher t 5 6 7 8 dig
Afghan Hound l 9 4 5 6 zoom
Airedale Terrier l 7 8 7 9 dig
Akita l 6 7 5 9 guard
Alaskan Klee Kai s 8 7 6 6 snow
Alaskan Malamute g 6 6 7 8 snow
American Eskimo Dog s 7 8 8 7 snow
American Water Spaniel m 7 7 8 7 splash
Australian Cattle Dog m 8 9 6 9 herd
Australian Shepherd m 8 9 8 8 herd
Barbet m 6 7 9 7 splash
Basenji m 8 5 5 7 yodel
Basset Hound m 2 5 9 6 sniff
Beagle s 6 6 9 7 sniff
Bedlington Terrier m 8 7 8 8 dig
Belgian Malinois l 9 9 6 10 guard
Bernese Mountain Dog g 4 7 10 7 pull
Bichon Frise t 5 7 10 6 cuddle
Black and Tan Coonhound l 7 6 8 8 sniff
Bloodhound l 5 6 9 7 sniff
Border Collie m 9 10 7 8 herd
Border Terrier s 7 7 8 9 dig
Boston Terrier s 6 7 9 7 cuddle
Boxer l 8 7 9 9 wiggle
Boykin Spaniel m 7 7 9 7 splash
Bracco Italiano l 7 7 9 7 point
Brittany m 8 8 8 7 point
British Bulldog m 2 5 10 9 snore
Brussels Griffon t 5 7 9 7 cuddle
Bull Terrier m 7 6 8 9 tug
Bullmastiff g 5 6 8 10 guard
Cairn Terrier s 7 7 8 9 dig
Cavalier King Charles Spaniel s 5 7 10 5 cuddle
Cavapoo s 6 8 10 5 cuddle
Chesapeake Bay Retriever l 7 8 7 9 splash
Chihuahua t 5 6 8 8 cuddle
Chinese Crested t 6 6 9 5 cuddle
Chow Chow l 4 5 4 8 guard
Cloud Pup m 9 7 9 6 cloud
Cockapoo s 6 8 10 6 cuddle
Cocker Spaniel m 7 7 9 6 fetch
Pembroke Welsh Corgi s 7 8 8 8 herd
Coton de Tulear t 5 7 10 6 cuddle
Croatian Sheepdog m 8 8 7 8 herd
Curly-coated Retriever l 7 7 8 8 splash
Dachshund s 4 6 8 9 dig
Dalmatian l 8 7 8 8 spots
English Setter l 8 7 9 7 point
Eurasier m 6 7 8 6 snow
Finnish Lapphund m 7 8 8 7 herd
Flat-coated Retriever l 8 7 9 7 splash
French Bulldog s 3 6 10 7 snore
German Shepherd l 8 10 7 10 guard
German Shorthaired Pointer l 9 8 8 8 point
Golden Retriever l 7 9 10 7 fetch
Goldendoodle l 7 8 10 6 fetch
Great Dane g 6 6 9 8 giant
Greyhound l 10 6 8 5 zoom
Havanese t 5 7 10 6 cuddle
Siberian Husky l 8 6 8 7 snow
Icelandic Sheepdog m 7 8 8 7 herd
Irish Water Spaniel l 7 7 8 7 splash
Irish Wolfhound g 8 6 9 9 zoom
Italian Greyhound t 8 6 9 4 zoom
Jack Russell Terrier s 8 7 7 10 dig
Japanese Chin t 4 6 9 5 cuddle
Japanese Spitz s 6 7 9 7 snow
Kai Ken m 7 7 6 8 guard
Keeshond m 6 7 9 7 snow
Kerry Blue Terrier m 7 8 7 9 dig
Kishu m 7 7 6 8 guard
Kokoni s 6 7 9 6 cuddle
Kuvasz g 6 7 6 9 guard
Labradoodle l 7 8 10 6 cuddle
Labrador l 7 9 10 7 splash
Lagotto Romagnolo m 6 8 8 7 truffle
Lancashire Heeler s 7 8 7 8 herd
Landseer g 5 7 9 9 splash
Leonberger g 5 7 9 8 splash
Lhasa Apso s 4 7 7 8 guard
Maltese t 5 7 10 5 cuddle
Mini Sausage Dog t 4 6 9 8 dig
Miniature Schnauzer s 7 8 8 8 dig
Newfoundland g 4 8 10 9 splash
Norfolk Terrier s 6 7 8 9 dig
Norwegian Elkhound m 7 7 7 9 snow
Nova Scotia Duck Tolling Retriever m 8 8 8 7 splash
Old English Sheepdog l 6 7 9 7 herd
Otterhound l 6 6 8 7 splash
Papillon t 7 9 8 6 cuddle
Pekingese t 2 5 8 8 cuddle
Polish Lowland Sheepdog m 7 8 8 7 herd
Pomeranian t 6 7 9 7 cuddle
Poodle m 8 10 9 6 splash
Portuguese Water Dog m 7 8 8 8 splash
Pug s 3 6 10 6 snore
Puli m 7 8 7 8 herd
Pyrenean Mountain Dog g 5 6 8 9 guard
Rainbow Pup m 8 8 10 8 rainbow
Red Setter l 9 7 9 6 point
Rottweiler l 6 9 8 10 guard
Rough Collie l 7 9 9 8 herd
Saint Bernard g 4 7 10 9 rescue
Saluki l 10 6 6 6 zoom
Samoyed m 7 7 10 6 snow
Scottish Deerhound g 9 6 9 7 zoom
Scottish Terrier s 5 7 6 9 dig
Shar Pei m 5 6 6 8 guard
Shetland Sheepdog s 8 10 8 6 herd
Shiba Inu s 7 7 5 8 guard
Shih Tzu t 3 5 10 6 cuddle
Shikoku m 7 7 6 8 guard
Skye Terrier s 5 7 7 9 dig
Smooth Collie l 8 9 8 8 herd
Spanish Water Dog m 7 8 8 8 splash
Spinone Italiano l 6 7 9 7 point
Springer Spaniel m 8 8 9 7 fetch
Standard Poodle l 8 10 8 7 splash
Swedish Lapphund m 7 8 8 7 herd
Swedish Vallhund s 7 8 8 8 herd
Thai Ridgeback l 7 7 6 9 guard
Tibetan Mastiff g 5 6 5 10 guard
Tibetan Terrier m 6 7 9 6 snow
Toy Fox Terrier t 8 8 8 8 dig
Vizsla l 9 8 10 7 point
Weimaraner l 9 8 8 7 point
Welsh Terrier s 7 7 8 9 dig
West Highland Terrier s 6 7 8 9 dig
Whippet m 10 7 9 5 zoom
White Swiss Shepherd l 8 9 8 8 herd
Wire Fox Terrier s 8 7 7 9 dig
Yorkshire Terrier t 6 7 8 8 dig
Bolognese s 5 7 9 6 cuddle
Schipperke s 7 8 6 9 guard
Redbone Coonhound l 8 6 8 7 sniff
Australian Kelpie m 10 9 6 8 herd
Borzoi g 10 5 6 6 zoom
Silken Windhound m 9 6 8 6 zoom
Clumber Spaniel l 4 6 9 6 snore
Löwchen s 6 7 9 7 cuddle
Azawakh l 10 6 5 7 zoom
Miniature Pinscher t 8 7 6 9 wiggle
Bluetick Coonhound l 7 6 8 7 sniff
Pumi m 8 9 6 8 herd
Biewer Terrier t 6 6 9 7 cuddle
Plott Hound l 8 7 7 9 sniff
Mudi m 8 9 7 8 herd
Bergamasco l 5 7 8 8 herd
Dogue de Bordeaux g 4 6 8 9 guard
Norwegian Lundehund s 7 7 7 7 dig
Canaan Dog m 8 8 6 8 guard
Komondor g 5 7 7 10 guard
Catahoula Leopard Dog l 8 8 6 8 spots
Xoloitzcuintli m 7 8 8 7 cuddle
Neapolitan Mastiff g 3 6 8 9 snore
Rhodesian Ridgeback l 9 7 6 9 guard
Pharaoh Hound l 9 7 7 6 zoom
Cirneco dell'Etna m 8 7 7 7 sniff
Treeing Walker Coonhound l 8 7 7 8 sniff
Sussex Spaniel m 4 7 9 7 snore
Mongolian Bankhar g 6 7 7 10 guard
American Foxhound l 9 7 7 8 sniff
Polish Hound l 8 7 7 8 sniff
Field Spaniel m 6 7 9 7 fetch
Mixed breed m 7 8 8 9 fetch`.split('\n').forEach(l=>{const t=l.trim().split(' '),g=t.pop(),n=t.splice(-5);BREEDS[t.join(' ')]={sz:n[0],spd:+n[1],brn:+n[2],cud:+n[3],brv:+n[4],g};});
const ALIAS={'Jack Russell':'Jack Russell Terrier','Husky':'Siberian Husky','St Bernard':'Saint Bernard','Corgi':'Pembroke Welsh Corgi','Sausage Dog':'Dachshund','Rainbow Dalmatian':'Dalmatian'};
const breedOf=b=>BREEDS[b]||BREEDS[ALIAS[b]]||{sz:'m',spd:6,brn:6,cud:7,brv:6,g:'fetch'};
const MOVE1={herd:'Round-up',dig:'Dig Dig Dig',sniff:'Super Sniff',zoom:'Zoomies Dash',splash:'Splash Dive',fetch:'Fetch!',point:'Paw Point',snow:'Sled Pull',pull:'Cart Pull',
  guard:'Brave Bark',cuddle:'Puppy Eyes',snore:'Big Snore',tug:'Tug of War',giant:'Giant Paw',spots:'Spotty Sprint',rescue:'Snow Rescue',truffle:'Truffle Hunt',yodel:'Yodel',
  cloud:'Cloud Hop',rainbow:'Rainbow Glow',wiggle:'Wiggle Jump'};
/* Zoomies, everyday move power and big move power by size */
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const TMOVE={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const UMOVE={blossom:'Flower Shower',flurry:'Snowflake Storm',pearl:'Pearl Wave',emberuni:'Ember Glow',tally:'Number Magic',gizmouni:'Gadget Zap',beaconuni:'Lighthouse Beam',
  midnight:'Silent Leap',dazzle:'Every Power',jingle:'Sleigh Ride',orbit:'Moon Gallop',cinder:'Campfire Mane',quark:'Quark Spin',relish:'Ketchup Splash',twirl:'Quick Change',glitterball:'Disco Dazzle',amberuni:'Fossil Spiral',nebulauni:'Comet Tail'};
const RAR={friend:['Season Friend','🦌'],common:['Common','🐾'],rare:['Rare','⭐'],sparkly:['Sparkly','✨'],legend:['Legend','🎓'],unicorn:['Unicorn','🦄'],alien:['Alien','👽']};
const STATS=[['spd','💨','Speed'],['brn','💡','Brains'],['cud','💖','Cuddles'],['brv','🛡️','Bravery']];
const LAND_TYPE={school:'spark',beach:'water',farm:'leaf',jungle:'fire',ski:'snow',star:'star'};
const LV2={1:['Puppy Rescue','🐶'],2:['Ninja Pups','🥷'],3:['Legendary Pups','✨'],4:['Christmas Pups','🎄'],5:['Space Pups','🚀'],6:['Lava Pups','🌋'],7:['Atom Pups','⚛️'],8:['Hot Dog Pups','🌭'],9:['Fancy Dress Pups','🎭'],10:['Disco Pups','🪩']};
const PQ2_TOTAL=411,TIN=9;
const ICON=c=>`<svg class="cico${c?' '+c:''}" viewBox="0 0 64 64"><rect x="7" y="11" width="30" height="42" rx="6" transform="rotate(-14 22 32)" fill="#ff9ecb" stroke="#5b4636" stroke-width="4"/><g transform="rotate(10 39 30)"><rect x="24" y="9" width="30" height="42" rx="6" fill="#8fe39a" stroke="#5b4636" stroke-width="4"/><g fill="#fff" stroke="#5b4636" stroke-width="2"><ellipse cx="39" cy="35" rx="7" ry="6"/><circle cx="31" cy="25" r="3"/><circle cx="36" cy="21" r="3"/><circle cx="42" cy="21" r="3"/><circle cx="47" cy="25" r="3"/></g></g></svg>`;
const hsh=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;};
const cap=(v,a,b)=>Math.max(a,Math.min(b,v));
const TY=t=>TYPES[t]||{name:'Star',icon:'⭐',col:'#b26fe0',power:'shines the way'};
/* the Zoomies Battle type chart (agreed 24 Nov 2026): every type beats 2 and is beaten by 2; alien pups are neutral */
const BEATS={fire:['leaf','comet'],water:['fire','stone'],leaf:['water','stone'],snow:['sky','spark'],spark:['water','star'],
  stone:['fire','spark'],sky:['star','leaf'],star:['snow','comet'],comet:['sky','snow']};

/* ---------- save ---------- */
function CS(){if(!state.cards)state.cards={};const c=state.cards;c.seen=c.seen||{};c.tin=c.tin||[];return c;}

/* ---------- making a card ---------- */
function mkStats(breed,id,nudge){const B=breedOf(breed),s={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  for(const k in nudge||{})if(k in s)s[k]+=nudge[k];const bump=STATS[hsh(id)%4][0];s[bump]+=1;for(const k in s)s[k]=cap(s[k],1,10);return s;}
function card3(p,set,n,of){const B=breedOf(p.breed),z=SZ[B.sz],sci=!!p.sci,rar=sci?'legend':p.shiny?'sparkly':'common',T=TY(p.type);
  const c={cid:'3:'+p.id,game:3,set,n,of,src:p,base:p.id,name:p.name,breed:p.breed,type:p.type,rar,fact:p.fact||'',
    stats:mkStats(p.breed,p.id,sci?{brn:2}:null),zoom:cap(z[0]+(sci?20:0)+(p.shiny?10:0),30,120),
    moves:[[sci?'Big Idea':MOVE1[B.g],1,z[1]],[sci&&p.expName?p.expName:TMOVE[p.type]||'Pup Power',2,z[2]+(sci?20:0)+(p.shiny?10:0)]],
    col:T.col,bg:shade(T.col,.72)};
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return (A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>isFound(p.id);
  c.foundAt=()=>{const v=state.found[p.id];return typeof v==='number'&&v>1e12?v:0;};
  c.art=an=>critterSVG(p,{anim:an,sparkly:!!(p.shiny||bf(p.id))});
  c.hint=()=>{const I=islandOf(p.island),A=AREAS[p.area];if(I&&!islOpen(I.id))return islLockSay(I.id);
    if(sci)return `A science pup is hiding in ${A.name}. ${p.hint||''}`;
    return state.seen[p.area]?`This pup is hiding in ${A.name}. ${p.hint||''}`:`This pup is hiding somewhere on ${I.name}. Have you been to ${A.name} yet?`;};
  return c;}
function cardUni3(I,set,n,of){const u=I.boss.uni,T=TY(I.type),A=AREAS[I.boss.area];
  const c={cid:'3:'+u.id,game:3,set,n,of,src:u,base:u.id,name:u.name,breed:u.breed,type:I.type,rar:'unicorn',fact:u.fact||'',uni:true,
    stats:mkStats('',u.id,null),zoom:120,moves:[['Rainbow Gallop',1,30],[UMOVE[u.id]||'Unicorn Magic',3,100]],col:T.col,bg:'#efe6ff'};
  c.stats={spd:9,brn:9,cud:9,brv:9};c.stats[STATS[hsh(u.id)%4][0]]=10;
  c.home=()=>(A?A.name+', ':'')+I.name;c.earned=()=>!!state.islDone[I.id];c.foundAt=()=>0;
  c.art=an=>critterSVG(u,{anim:an});c.hint=()=>islOpen(I.id)?`Find every pup on ${I.name}, then meet the unicorn in ${A?A.name:'the last area'} to win this card!`:islLockSay(I.id);
  return c;}
function card2(p,lv,set,n,of){const A=window.PQ2ART,B=breedOf(p.breed),z=SZ[B.sz],uni=!!p.uni,rd=lv===0,spec=rd||lv===10||['frankie','lumi','nimbus'].indexOf(p.id)>=0;
  const type=uni?'star':LAND_TYPE[p.land]||'star',T=TY(type),key=p.id+'@'+lv;
  const nud={2:{spd:1},3:{brv:1},4:{cud:1},5:{brn:1},6:{brv:1},7:{brn:1},8:{cud:1},9:{},10:{spd:1},0:{cud:1}}[lv]||{};
  let m2=TMOVE[type];if(uni)m2=UMOVE[p.id]||'Unicorn Magic';else if(rd)m2='Rainbow Spots';else if(p.id==='frankie')m2='Hot Dog Hop';
  else if(lv===2)m2='Ninja Roll';else if(lv===3)m2=(A.LT[p.lt]||{}).pow||'Legend Power';else if(lv===4)m2='Jingle Bells';else if(lv===5)m2='Jetpack Boost';else if(lv===6)m2='Helmet Lamp';
  else if(lv===7)m2=p.part==='p'?'Proton Push':p.part==='n'?'Neutron Nudge':p.el?p.el.name+' Power':'Atom Power';else if(lv===8)m2='Food Truck Feast';
  else if(lv===9)m2=(A.COS[p.cos]?A.COS[p.cos].n:'Costume')+' Power';else if(lv===10)m2='Disco Groove';
  const c={cid:'2:'+key,game:2,set,n,of,src:p,lv,base:p.id,name:p.name,breed:p.breed,type,fact:p.fact||'',uni,
    stats:uni?{spd:9,brn:9,cud:9,brv:9}:mkStats(p.breed,key,nud),col:T.col};
  if(uni)c.stats[STATS[hsh(p.id)%4][0]]=10;
  const extra=(p.rare?10:0)+(spec?10:0)+(lv===3?10:0);
  c.zoom=uni?120:cap(z[0]+extra,30,120);
  c.moves=uni?[['Rainbow Gallop',1,30],[m2,3,100]]:[[MOVE1[B.g],1,z[1]],[m2,2,z[2]+extra]];
  c.rar0=uni?'unicorn':spec?'sparkly':(p.rare||lv===3)?'rare':'common';
  Object.defineProperty(c,'rar',{get(){const f=foundVal2(c);return f===2&&(c.rar0==='common'||c.rar0==='rare')?'sparkly':c.rar0;}});
  const L=landName2(p,lv);c.bg=(rd&&p.col)||L.col||shade(T.col,.72);c.home=()=>rd?'Followed the rainbow paw prints':L.name;
  c.earned=()=>!!foundVal2(c);c.foundAt=()=>0;
  c.art=an=>A.svg(p,{anim:an,sparkly:foundVal2(c)===2||rd});
  c.hint=()=>'Find this pup in Puppy Quest 2, then bring your cards across again!';
  return c;}
function foundVal2(c){const P=CS().pq2;if(!P)return 0;if(c.lv===0)return P.rd[c.base]?1:0;const F=P.f[c.lv];return F&&F[c.base]||0;}
function landName2(p,lv){const A=window.PQ2ART,i=A.LANDS.findIndex(l=>l.id===p.land),L=lv===5?A.SPACE:lv===6?A.CAVES:lv===7?A.MICRO:lv===10?A.DISCO_LANDS:A.LANDS;return L[i]||A.LANDS[i]||{name:'Puppy Park'};}
const bf=id=>typeof bestFriend==='function'&&bestFriend(id);

/* ---------- the sets ---------- */
let S3=null,S2=null;
function sets3(){if(S3&&S3.n===ISLANDS.length+SCIL().length+XC().length)return S3.s;const s=[];
  ISLANDS.forEach(I=>{const L=I.pups.concat(I.bonus||[]),of=L.length+(I.boss&&I.boss.uni?1:0),id='3:'+I.id;
    const cards=L.map((p,i)=>card3(p,id,i+1,of));if(I.boss&&I.boss.uni)cards.push(cardUni3(I,id,of,of));
    s.push({id,game:3,name:I.name,icon:I.icon,cards,open:()=>islOpen(I.id),isl:I.id});});
  const SC=SCIL();if(SC.length)s.push({id:'3:sci',game:3,name:'Science Legends',icon:'🔬',cards:SC.map((p,i)=>card3(p,'3:sci',i+1,SC.length)),open:()=>true});
  XC().forEach(x=>{const X=x.set();if(X)s.push(X);});
  s.forEach(S=>S.cards.forEach(c=>{const raw=c.earned;c.found=raw;c.earned=()=>raw()&&rev(c);}));
  S3={n:ISLANDS.length+SC.length+XC().length,s};return s;}
const SCIL=()=>typeof SCI!=='undefined'?SCI:[];
/* extra card sets from side quests (window.XCARDS, e.g. the Black Hole quest's alien pups) */
const XC=()=>window.XCARDS||[],XK=k=>XC().find(x=>x.keys().indexOf(k)>=0);
function sets2(){if(S2)return S2;const A=window.PQ2ART;if(!A)return [];const s=[];
  [1,2,3,4,5,6,7,8,9,10].forEach(lv=>{const L=A.ALL[lv].filter(p=>!p.uni).concat(A.ALL[lv].filter(p=>p.uni)),id='2:'+lv;
    s.push({id,game:2,lv,name:`Level ${lv}: ${LV2[lv][0]}`,short:'Level '+lv,icon:LV2[lv][1],cards:L.map((p,i)=>card2(p,lv,id,i+1,L.length)),open:()=>true});});
  const R=A.ALL[0];s.push({id:'2:rd',game:2,lv:0,name:'Rainbow Dalmatians',icon:'🌈',cards:R.map((p,i)=>card2(p,0,'2:rd',i+1,R.length)),open:()=>true});
  return (S2=s);}
const allSets=()=>sets3().concat(CS().pq2?sets2():[]);
function cardById(cid){for(const s of allSets())for(const c of s.cards)if(c.cid===cid)return c;return null;}
/* cards earned, without needing the Puppy Quest 2 drawings */
function earnedIds(){const ids=rawIds3().filter(revId);
  const P=CS().pq2;if(P){for(const lv in P.f)for(const id in P.f[lv])ids.push('2:'+id+'@'+lv);for(const id in P.rd)ids.push('2:'+id+'@0');}
  return ids;}
const newCount=()=>{const S=CS().seen;return earnedIds().filter(c=>!S[c]).length+readyPacks().length;};

/* ---------- area packs (24 Nov): a found pup's card waits in its area's pack until every pup there is found ---------- */
function rawIds3(){const ids=Object.keys(state.found).filter(id=>PUPS[id]).map(id=>'3:'+id);
  ISLANDS.forEach(I=>{if(state.islDone[I.id]&&I.boss&&I.boss.uni)ids.push('3:'+I.boss.uni.id);});XC().forEach(x=>x.ids().forEach(id=>ids.push(id)));return ids;}
function APS(){const C=CS();C.ap=C.ap||{};C.rv=C.rv||{};C.ann=C.ann||{};
  if(!C.apv){C.apv=1;rawIds3().forEach(id=>{C.rv[id]=1;});}return C;}
/* which pack a PQ3 card comes in: its area (if that area has pups to find), or its island's unicorn pack */
function packKey(cid){for(const x of XC()){const xk=x.key(cid);if(xk!==undefined)return xk;}const id=cid.slice(2),p=PUPS[id];if(p){const L=areaPups(p.area);return L.length?p.area:null;}
  const I=ISLANDS.find(I=>I.boss&&I.boss.uni&&I.boss.uni.id===id);return I?'u:'+I.id:null;}
function revId(cid){if(cid[0]!=='3')return true;const C=APS();if(C.rv[cid])return true;const k=packKey(cid);return !k||!!C.ap[k];}
const rev=c=>revId(c.cid);
function packDone(k){if(k.slice(0,2)==='x:'){const x=XK(k);return !!x&&x.done(k);}if(k.slice(0,2)==='u:')return !!state.islDone[k.slice(2)];const L=areaPups(k);return L.length>0&&L.every(p=>isFound(p.id));}
function packCards(k){return rawIds3().filter(id=>packKey(id)===k&&!APS().rv[id]).map(cardById).filter(Boolean);}
function packInfo(k){if(k.slice(0,2)==='x:')return XK(k).info(k);if(k.slice(0,2)==='u:'){const I=islandOf(k.slice(2));return {k,isl:I.id,icon:'🦄',name:I.boss.uni.name,short:I.boss.uni.name,uni:true};}
  const A=AREAS[k];return {k,isl:A.island,icon:A.icon||'🎁',name:A.name,short:A.name};}
/* packs ready to open, in island and area order */
function readyPacks(isl){if(!state)return [];const C=APS(),out=[];
  ISLANDS.forEach(I=>{if(isl&&I.id!==isl)return;const keys=I.areas.map(a=>a.id).concat(I.boss&&I.boss.uni?['u:'+I.id]:[]);
    keys.forEach(k=>{if(C.ap[k]||!packDone(k))return;const L=packCards(k);if(!L.length){C.ap[k]=1;return;}out.push(Object.assign(packInfo(k),{cards:L,n:L.length}));});});
  XC().forEach(x=>{if(isl&&x.isl!==isl)return;x.keys().forEach(k=>{if(C.ap[k]||!packDone(k))return;const L=packCards(k);if(!L.length){C.ap[k]=1;return;}out.push(Object.assign(packInfo(k),{cards:L,n:L.length}));});});
  return out;}
function packSay(c){const k=packKey(c.cid);if(!k)return c.hint();if(packDone(k))return 'This card is in a pack that is ready to open. Tap the pack!';
  if(k.slice(0,2)==='x:')return XK(k).say(k,c);if(k[1]===':')return 'This card is in the unicorn pack. Meet the unicorn to open it!';const A=AREAS[k],left=areaPups(k).filter(p=>!isFound(p.id)).length;
  return `${c.name}'s card is waiting in the ${A.name} pack. Find ${left} more ${left>1?'pups':'pup'} in ${A.name} to open it!`;}
function areaPackPage(s,P,speakIt){const Lp=$('#bdL'),Rp=$('#bdR');$('#bdH').textContent=`${s.icon} ${s.name}`;
  Lp.innerHTML=`<button class="pq2pack wig2" id="bdPack">${packSVG(P)}</button>`;
  const more=readyPacks(s.isl).length-1;
  Rp.innerHTML=`<div class="note"><h3>${P.uni?'A unicorn pack!':'A new pack!'}</h3><p>${P.uni?`You finished ${esc(islandOf(P.isl).name)}! ${esc(P.name)} is inside.`:`You found every pup in ${esc(P.name)}! ${P.n} ${P.n>1?'cards are':'card is'} inside.`}</p>`+
    (more>0?`<p>${more} more ${more>1?'packs':'pack'} after this one!</p>`:'')+`<p class="pulse" style="font-size:30px">👆 Tap the pack to open it!</p></div>`;
  tap('#bdPack',()=>openAreaPack(P));
  if(speakIt)say(P.uni?`A unicorn pack! Tap it to open it.`:`You found every pup in ${P.name}! A new pack of cards. Tap the pack to open it!`);}
function openAreaPack(P){const C=APS();if(C.ap[P.k])return;const pk=$('#bdPack');pk.classList.remove('wig2');pk.classList.add('shake');sfx.giggle();if(SPK(P))SPK(P).open(P,pk);
  setTimeout(()=>{pk.classList.add('burst');sfx.jingle();confetti(50);const Rp=$('#bdR');Rp.innerHTML='';const fan=el('div','fan','');Rp.appendChild(fan);
    const show=P.cards.slice(0,5);show.forEach((c,i)=>{const b=el('div','fc',miniHTML(c,{force:1}));b.style.setProperty('--i',i-(show.length-1)/2);b.style.animationDelay=(i*.18)+'s';fan.appendChild(b);});
    const msg=P.uni?`Wow! ${P.name}, the unicorn card!`:`Wow! ${P.cards.map(c=>c.name).join(' and ')}!`;say(window.CLOOK?CLOOK.packSay(show,msg):msg);
    setTimeout(()=>{C.ap[P.k]=1;save();badge();render();},2600);},700);}
/* a toast by the binder button */
function toast(html){const t=el('div','pktoast',html);$('#fx').appendChild(t);setTimeout(()=>t.classList.add('on'),30);setTimeout(()=>{t.classList.remove('on');setTimeout(()=>t.remove(),400);},3400);}
function flyThing(html,cls){const f=el('div','flycard '+(cls||''),html);$('#fx').appendChild(f);setTimeout(()=>f.classList.add('go'),40);
  setTimeout(()=>{f.remove();const b=$('#wCards');if(b){b.classList.remove('bump');void b.offsetWidth;b.classList.add('bump');}},1300);}
function announce(){const C=APS();readyPacks().forEach((P,i)=>{if(C.ann[P.k])return;C.ann[P.k]=1;save();
    setTimeout(()=>{flyThing(`<div class="flypack">${packSVG(P)}</div>`,'pk');sfx.jingle();toast(`🎁 New card pack: <b>${esc(P.name)}</b>!`);},400+i*900);});badge();}
const totalCards=()=>sets3().reduce((n,s)=>n+s.cards.length,0)+(CS().pq2?(S2?S2.reduce((n,s)=>n+s.cards.length,0):PQ2_TOTAL):0);

/* ---------- drawing cards ---------- */
const esc=s=>String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;');
const bones=n=>'🦴'.repeat(n);
function rarOf(c){return c.rar;}
function miniHTML(c,o){o=o||{};
  if(!o.force&&c.game===3&&!c.earned()&&c.found&&c.found()){const k=packKey(c.cid),A=k&&k[1]!==':'?AREAS[k]:k&&k[0]==='x'?{name:packInfo(k).short}:null;
    return `<div class="mc packed" style="--tc:${c.col}"><div class="pkd">🎁</div><b>#${c.n}</b><i>${A?esc(A.name)+' pack':'Unicorn pack'}</i></div>`;}
  if(!o.force&&!c.earned())return `<div class="mc miss" style="--tc:${c.col}"><div class="mart sil">${c.art(false)}</div><b>#${c.n}</b><i>?</i></div>`;
  const T=TY(c.type),r=rarOf(c),fav=CS().tin.indexOf(c.cid)>=0,best=c.game===3&&bf(c.base),LK=window.CLOOK?CLOOK.mini(c,r,best):null;
  return `<div class="mc r-${r}${best?' bf':''}${LK?LK.cls:''}" style="--tc:${c.col};--ta:${c.bg}${LK?';'+LK.style:''}"><div class="mart">${LK?LK.scene:''}${c.art(false)}</div><b${c.name.length>13?' class="ln"':c.name.length>10?' class="md"':''}>${esc(c.name)}</b><span>${T.icon} ${c.zoom}</span>`+
    (o.isNew?'<em>NEW</em>':'')+(fav?'<u>💖</u>':'')+(r!=='common'?`<s>${RAR[r][1]}</s>`:'')+(LK?LK.extra:'')+'</div>';}
function nameSize(n){return n.length>17?19:n.length>13?22:n.length>10?26:30;}
function factSize(f){return f.length>230?12.5:f.length>170?13:f.length>110?14:15;}
function bigHTML(c){const T=TY(c.type),r=rarOf(c),best=c.game===3&&bf(c.base),s=c.stats,set=setById(c.set),LK=window.CLOOK?CLOOK.big(c,r,best):null;
  const front=`<div class="face front"${LK?` style="${LK.style}"`:''}><div class="in"><div class="hd"><b class="${c.name.length>13?'two':''}" style="font-size:${nameSize(c.name)}px">${esc(c.name)}</b><span class="zm"><small>Zoomies</small>${c.zoom}</span><span class="ty" style="background:${T.col}">${T.icon}</span></div>
    <div class="art" style="background:${c.bg}">${LK?LK.scene:''}${c.art(true)}</div>
    <div class="strip">${esc(c.breed)} · ${esc(c.home())}</div>
    ${c.moves.map(m=>`<div class="mv"><span class="cost">${bones(m[1])}</span><b>${esc(m[0])}</b><span class="pw">${m[2]}</span></div>`).join('')}
    <div class="st">${STATS.map(q=>`<span>${q[1]} ${q[2]} <b>${s[q[0]]}</b></span>`).join('')}</div>
    <div class="fact" style="font-size:${factSize(c.fact)}px">${esc(c.fact)}</div>
    <div class="ft"><span>${RAR[r][1]} ${best?'Best Friend 💛':RAR[r][0]}${LK&&LK.fname?` <b class="fintag">· ${LK.fname}</b>`:''}</span><span>${set?set.short||set.name.split(' ')[0]:''} ${c.n}/${c.of}</span></div></div>${LK?LK.extra:''}</div>`;
  const BK=window.CLOOK&&CLOOK.back?CLOOK.back(c,r,best):null;/* 26 Nov: the back matches the front's frame */
  return `<div class="tc r-${r}${best?' bf':''}${c.fact.length>200?' long':''}${LK?LK.cls:''}" style="--tc:${c.col}">${front}<div class="face back"${BK?` style="${BK.style}"`:''}>${backHTML(c,BK&&BK.panel)}${BK?BK.extra:''}</div></div>`;}
function backHTML(c,panel){const T=TY(c.type),L=[];
  if(c.back){c.back().forEach(x=>L.push(x));}
  else if(c.game===3){const d=c.foundAt();L.push(c.uni?`🦄 Met in ${esc(c.home())}`:`🔍 Found ${d?'on '+new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'by Seb'}`);
    if(!c.uni)L.push(`📍 ${esc(c.home())}`);
    if(!c.uni){const fr=(state.friend||{})[c.base]||0;L.push(`💖 Friendship ${fr} of 10${fr>=10?', best friends!':''}`);}
    if(state.buddy===c.base)L.push('⭐ Seb\'s buddy');else if((state.pack||[]).indexOf(c.base)>=0)L.push('🐾 In Seb\'s pack');
    if(c.src.who)L.push(`🔬 Inspired by ${esc(c.src.who)}`);}
  else{const P=CS().pq2||{};L.push('🎁 From Puppy Quest 2');L.push(c.lv?`${LV2[c.lv][1]} Level ${c.lv}: ${LV2[c.lv][0]}`:'🌈 A Rainbow Dalmatian');L.push(`📍 ${esc(c.home())}`);
    if(foundVal2(c)===2)L.push('✨ Found sparkly!');if(P.buddy===c.base+'@'+c.lv)L.push('⭐ Seb\'s buddy in Puppy Quest 2');}
  L.push(`${T.icon} ${T.name} power: ${T.power}.`);
  {const bt=BEATS[c.type];if(bt)L.push(`💥 Super against ${bt.map(x=>TY(x).icon+' '+TY(x).name).join(' and ')}`);else if(c.type==='alien')L.push('💥 No type is Super against an alien pup!');}
  return `<div class="bk"${panel?` style="background-color:${panel}"`:''}><div class="logo">🐾<b>Puppy Quest</b><small>Pup Trading Cards</small></div><h3>Seb and ${esc(c.name)}</h3>${L.map(x=>`<p>${x}</p>`).join('')}<div class="tapme">Tap to turn over</div></div>`;}
const setById=id=>allSets().find(s=>s.id===id);

/* ---------- screens ---------- */
let curSet='3:meadow',shelf=3,page=0,from='world',vw=null,swiped=false;
function build(){const st=$('#stage');
  const B=el('div','screen','');B.id='binder';B.innerHTML=`<div class="bcover"></div><button class="btn rnd white" id="bdBack" style="position:absolute;left:14px;top:10px;z-index:20">◀</button>
    <h2 id="bdH">Card Binder</h2><div class="pill" id="bdCount"></div><div id="bdTabs"></div>
    <div id="bdPages"><div class="page" id="bdL"></div><div class="rings"><i></i><i></i><i></i></div><div class="page" id="bdR"></div></div>
    <button class="bdArrow" id="bdPrev">◀</button><button class="bdArrow" id="bdNext">▶</button>`;
  st.insertBefore(B,$('#bubble'));
  const V=el('div','ov','');V.id='cardv';V.innerHTML=`<button class="btn rnd white" id="cvX" style="position:absolute;left:14px;top:10px">✕</button><div id="cvTilt"><div id="cvCard"></div></div>
    <button class="bdArrow" id="cvPrev">◀</button><button class="bdArrow" id="cvNext">▶</button><div id="cvBtns"></div><div id="cvNum"></div><div id="cvStrip"></div>`;
  st.insertBefore(V,$('#cele'));
  const wb=el('button','btn rnd white',ICON()+'<i class="nb"></i>');wb.id='wCards';wb.style.cssText='left:14px;top:100px';$('#world').appendChild(wb);
  const bb=el('button','btn rnd white',ICON()+'<i class="nb"></i>');bb.id='bkCards';bb.style.cssText='position:absolute;left:14px;top:100px;z-index:20';$('#book').appendChild(bb);
  tap(wb,()=>openBinder(null,'world'));tap(bb,()=>openBinder(null,'book'));tap('#bdBack',leave);
  tap('#bdPrev',()=>turn(-1));tap('#bdNext',()=>turn(1));tap('#cvX',closeView);tap('#cvPrev',()=>step(-1));tap('#cvNext',()=>step(1));
  swipe($('#bdPages'),d=>turn(d));swipe($('#cvTilt'),d=>step(d),()=>flip());tilt();
  setInterval(badge,1500);badge();}
function swipe(e,fn,tapFn){let x0=null,y0=0,t0=0;e.addEventListener('pointerdown',ev=>{x0=ev.clientX;y0=ev.clientY;t0=Date.now();});
  e.addEventListener('pointerup',ev=>{if(x0==null)return;const dx=ev.clientX-x0,dy=ev.clientY-y0;x0=null;const s=typeof scale==='number'?scale:1;
    if(Math.abs(dx)>60*s&&Math.abs(dx)>Math.abs(dy)){swiped=true;setTimeout(()=>{swiped=false;},60);fn(dx<0?1:-1);}else if(tapFn&&Math.abs(dx)<12*s&&Math.abs(dy)<12*s&&Date.now()-t0<600)tapFn();});
  e.addEventListener('pointercancel',()=>{x0=null;});}
function badge(){if(!state)return;const n=newCount();['#wCards','#bkCards'].forEach(s=>{const b=$(s+' .nb');if(b){b.textContent=n>99?'99+':n;b.style.display=n?'block':'none';}});}

function openBinder(setId,src,thenView){sfx.boop();closeOv('menu');document.querySelectorAll('.pktoast').forEach(t=>t.remove());from=src||from;
  const go=()=>{const R=readyPacks();if(setId){curSet=setId;shelf=setId[0]==='2'?2:isSea(setId)?'s':3;page=0;}else if(R.length){curSet='3:'+R[0].isl;shelf=isSea(curSet)?'s':3;page=0;}else if(!setById(curSet))curSet='3:meadow';show('binder');render();
    if(thenView)openView(thenView);else if(!CS().intro){CS().intro=true;save();setTimeout(()=>card({art:`<div style="width:130px">${ICON('xl')}</div>`,h:'Your Card Binder!',
      p:'Every pup you find gets a trading card. Find every pup in an area to win a pack of its cards! Tap a card to see it big and turn it over. Keep your 9 favourite cards in your Special Tin!'}),300);}};
  if(CS().pq2&&!window.PQ2ART)loadArt(go,true);else go();if(window.CLOOK)CLOOK.onBinder();}
function leave(){sfx.boop();badge();if(from==='book'){showBook();return;}if(W.area){show('world');syncFollowers(true);hud();}else showTitle();}

function tabs(){const T=$('#bdTabs');T.innerHTML='';const C=CS(),mk=(html,sel,cls,fn)=>{const b=el('button','tab'+(sel?' sel':'')+(cls?' '+cls:''),html);tap(b,fn);T.appendChild(b);};
  mk(`💖<small>${C.tin.length}/${TIN}</small>`,curSet==='tin','',()=>pickSet('tin'));
  const SEA=sets3().filter(s=>s.season),SO=window.SEASONS||{},seaOpen=k=>{const S=SO[k],L=SEA.filter(s=>s.season===k);return !!((S&&S.opened())||L.some(s=>s.cards.some(c=>c.earned())));};
  const nwSet=s=>s.cards.some(c=>c.earned()&&!C.seen[c.cid])||(s.isl&&readyPacks(s.isl).length>0);
  const seaKeys=[...new Set(SEA.map(s=>s.season))].filter(seaOpen);
  const cs=(setById(curSet)||{}).season||(setById(lastSea)||{}).season||seaKeys[0];
  /* 26 Nov: the collections are bookmarks down the left edge of the binder (Islands, each Pup Season, Puppy Families, Puppy Quest 2),
     and the row along the top shows only the sets of the collection that is open, plus the Special Tin */
  const marks=[{icon:'🏝️',name:'Islands',sel:shelf===3,nw:sets3().filter(s=>!s.season).some(nwSet),go:()=>{shelf=3;pickSet(lastPQ3||'3:meadow');}}];
  seaKeys.forEach(k=>{const S=SO[k],L=SEA.filter(s=>s.season===k);marks.push({icon:S?S.icon:'✨',name:S?S.short:k,sel:shelf==='s'&&cs===k,nw:L.some(nwSet),go:()=>{shelf='s';pickSet(lastSeaBy[k]||L[0].id);}});});
  marks.push({icon:'🎁',name:'PQ2',sel:shelf===2,nw:!!C.pq2&&sets2().some(s=>!C.pq2.open[s.id]||s.cards.some(c=>c.earned()&&!C.seen[c.cid])),go:()=>{shelf=2;pickSet(C.pq2?(lastPQ2||'2:1'):'pq2');}});
  shelfMarks(marks);
  const setTab=(s,cls)=>{const g=s.cards.filter(c=>c.earned()).length;
    if(!s.open())mk(`${s.icon}<small>🔒</small>`,false,'lock',()=>{sfx.oops();say(s.lockSay?s.lockSay():s.isl&&!s.season?islLockSay(s.isl):'Coming soon!');});
    else mk(`${s.icon}<small>${g}/${s.cards.length}</small>${nwSet(s)?'<em></em>':''}`,curSet===s.id,cls,()=>pickSet(s.id));};
  if(shelf==='s'){SEA.filter(s=>s.season===cs).forEach(s=>setTab(s,'xs'));return;}
  if(shelf===3){sets3().filter(s=>!s.season).forEach(s=>setTab(s,''));return;}
  if(C.pq2)sets2().forEach(s=>{const g=s.cards.filter(c=>c.earned()).length,nw=C.pq2.open[s.id]&&s.cards.some(c=>c.earned()&&!C.seen[c.cid]);
    mk(`${s.icon}<small>${C.pq2.open[s.id]?g+'/'+s.cards.length:'📦'}</small>${nw||!C.pq2.open[s.id]?'<em></em>':''}`,curSet===s.id,'',()=>pickSet(s.id));});}
/* the left-hand bookmarks: up to 4 above the page-back arrow and the rest below it, like the game bookmarks on the right */
function shelfMarks(marks){let H=$('#bdShelf');if(!H){H=el('div','','');H.id='bdShelf';$('#binder').appendChild(H);}H.innerHTML='';
  if(marks.length<2)return;
  marks.forEach((m,i)=>{const b=el('button','bdLMark'+(m.sel?' sel':''),`<span class="i">${m.icon}</span><small>${esc(m.name)}</small>${m.nw?'<em></em>':''}`);
    b.style.top=(i<4?176+i*55:518+(i-4)*55)+'px';b.setAttribute('aria-label',m.name);
    tap(b,()=>{if(m.sel){sfx.boop();return;}m.go();});H.appendChild(b);});}
let lastPQ2=null,lastPQ3=null,lastSea=null;const lastSeaBy={};
const isSea=id=>{const S=id&&setById(id);return !!(S&&S.season);};
function pickSet(id){sfx.boop();curSet=id;page=0;if(id[0]==='2')lastPQ2=id;if(isSea(id)){lastSea=id;lastSeaBy[setById(id).season]=id;}else if(id[0]==='3')lastPQ3=id;render(true);}

function render(speakIt){const C=CS(),Lp=$('#bdL'),Rp=$('#bdR');tabs();$('#bdCount').innerHTML=ICON('s')+' '+earnedIds().length;
  $('#binder').dataset.sea=shelf==='s'?((setById(curSet)||{}).season||''):(curSet[0]==='2'||curSet==='pq2')?'pq2':'';/* 25 Nov: the season's own look on the Seasons shelf (CSS in the season's file) */
  Lp.innerHTML=Rp.innerHTML='';Lp.className=Rp.className='page';$('#bdPrev').style.visibility=$('#bdNext').style.visibility='hidden';
  if(curSet==='tin')return tinPage(speakIt);
  if(curSet==='pq2')return importPage(speakIt);
  const s=setById(curSet);if(!s){curSet='3:meadow';return render();}
  if(s.game===2&&!C.pq2.open[s.id])return packPage(s,speakIt);
  if(s.game===3&&s.isl){const R=readyPacks(s.isl);if(R.length)return areaPackPage(s,R[0],speakIt);}
  $('#bdH').textContent=`${s.icon} ${s.name}`;
  const per=18,pages=Math.ceil(s.cards.length/per);page=cap(page,0,pages-1);
  const L=s.cards.slice(page*per,page*per+per),fresh=[];
  [Lp,Rp].forEach((P,k)=>{const g=el('div','grid','');L.slice(k*9,k*9+9).forEach(c=>{const isNew=c.earned()&&!C.seen[c.cid];if(isNew)fresh.push(c.cid);
      const b=el('button','pocket',miniHTML(c,{isNew}));tap(b,()=>{if(swiped)return;if(!c.earned()){sfx.boop();say(c.found&&c.found()?packSay(c):c.hint());return;}openView(c.cid);});g.appendChild(b);});
    P.appendChild(g);const pn=page*2+k+1;if(pages>1||k===0)P.appendChild(el('div','pnum',''+pn));});
  $('#bdPrev').style.visibility=page>0?'visible':'hidden';$('#bdNext').style.visibility=page<pages-1?'visible':'hidden';
  if(fresh.length){fresh.forEach(id=>{C.seen[id]=1;});save();badge();tabs();}
  if(speakIt){const g=s.cards.filter(c=>c.earned()).length;say(`${s.name}. You have ${g} of ${s.cards.length} cards.`+(g===s.cards.length?' The whole set!':''));}}
function turn(d){const s=setById(curSet);if(!s||curSet==='tin')return;const pages=Math.ceil(s.cards.length/18);const np=cap(page+d,0,pages-1);if(np===page)return;page=np;sfx.pop();
  const P=$('#bdPages');P.classList.remove('tl','tr');void P.offsetWidth;P.classList.add(d>0?'tl':'tr');render();}

/* ---------- the Special Tin ---------- */
function tinPage(speakIt){const C=CS(),Lp=$('#bdL'),Rp=$('#bdR');$('#bdH').textContent='💖 Special Tin';Lp.classList.add('tinpg');
  const g=el('div','grid tin','');for(let i=0;i<TIN;i++){const id=C.tin[i],c=id&&cardById(id);
    if(c){const b=el('button','pocket',miniHTML(c));tap(b,()=>{if(swiped)return;openView(c.cid,'tin');});g.appendChild(b);}
    else g.appendChild(el('div','pocket empty','<div class="mc slot">💖</div>'));}
  Lp.appendChild(el('div','tinlid','💖 Seb\'s Special Tin'));Lp.appendChild(g);
  const team=C.tin.map(cardById).filter(Boolean),z=team.reduce((n,c)=>n+c.zoom,0);
  Rp.innerHTML=`<div class="note"><h3>Your 9 favourite cards</h3><p>Tap any card in your binder, then tap <b>💖 Put in my tin</b> to keep it here.</p>
    <p>Your tin holds 9 cards. Tap a card in the tin to take it out.</p>${team.length?`<div class="tz">⚡ Team Zoomies: <b>${z}</b></div>`:''}</div>`;
  if(speakIt)say(team.length?`Your Special Tin has ${team.length} of 9 favourite cards.`:'This is your Special Tin. Tap a card in your binder, then tap the heart button to keep it here.');}
function toggleTin(c){const C=CS(),i=C.tin.indexOf(c.cid);
  if(i>=0){C.tin.splice(i,1);save();sfx.boop();say(`${c.name} went back in the binder.`);openView(c.cid,vw&&vw.mode);return;}
  if(C.tin.length<TIN){C.tin.push(c.cid);save();sfx.chime();floatHeart();say(`${c.name} is in your Special Tin! ${C.tin.length} of 9.`);openView(c.cid,vw&&vw.mode);return;}
  sfx.oops();say('Your tin is full! Choose a card to swap out.');swapPick(c);}
function swapPick(c){const S=$('#cvStrip');S.innerHTML='<div class="sh">Tap a card to swap it for '+esc(c.name)+'</div>';S.classList.add('on');
  CS().tin.forEach(id=>{const o=cardById(id);if(!o)return;const b=el('button','pocket',miniHTML(o));tap(b,()=>{const C=CS(),k=C.tin.indexOf(id);C.tin[k]=c.cid;save();sfx.chime();floatHeart();S.classList.remove('on');say(`${c.name} swapped in for ${o.name}!`);openView(c.cid,vw&&vw.mode);});S.appendChild(b);});
  const x=el('button','btn white','✕');tap(x,()=>{sfx.boop();S.classList.remove('on');});S.appendChild(x);}
function floatHeart(){const f=el('div','fl','💖');f.style.left='560px';f.style.top='330px';$('#fx').appendChild(f);setTimeout(()=>f.remove(),1200);}

/* ---------- looking at one card ---------- */
function listFor(c,mode){if(mode==='tin')return CS().tin.map(cardById).filter(Boolean);const s=setById(c.set);return s?s.cards.filter(q=>q.earned()):[c];}
function openView(cid,mode){const c=cardById(cid);if(!c)return;vw={cid,mode:mode||(curSet==='tin'?'tin':null)};const C=CS();C.seen[cid]=1;save();badge();
  $('#cvCard').innerHTML=bigHTML(c);$('#cvTilt').style.transform='';$('#cvStrip').classList.remove('on');
  const L=listFor(c,vw.mode),i=L.findIndex(q=>q.cid===cid);$('#cvNum').textContent=L.length>1?`${i+1} / ${L.length}`:'';
  $('#cvPrev').style.visibility=i>0?'visible':'hidden';$('#cvNext').style.visibility=i>=0&&i<L.length-1?'visible':'hidden';
  const B=$('#cvBtns');B.innerHTML='';const inTin=C.tin.indexOf(cid)>=0,btn=(h,cls,fn)=>{const b=el('button','btn '+cls,h);tap(b,fn);B.appendChild(b);};
  btn(inTin?'💔 Take out of tin':'💖 Put in my tin',inTin?'white':'pink',()=>toggleTin(c));
  btn('🔄 Turn over','white',flip);btn('🔊 Read it','white',()=>readCard(c));
  const looks=looksOf(c);if(looks.length>1)btn(`👗 ${looks.length} looks`,'white',()=>showLooks(c,looks));
  if(c.game===3&&!c.uni&&!c.src.sci&&state.buddy!==c.base)btn('⭐ Make buddy','green',()=>{if(state.buddy)state.pack=[state.buddy].concat((state.pack||[]).filter(q=>q!==c.base)).slice(0,2);else state.pack=(state.pack||[]).filter(q=>q!==c.base);state.buddy=c.base;save();sfx.chime();say(`${c.name} is your buddy now!`);openView(cid,vw.mode);});
  $('#cardv').classList.add('on');speak(`${c.name}! ${c.fact}`);}
function closeView(){sfx.boop();$('#cardv').classList.remove('on');vw=null;hush();if(cur==='binder')render();}
function step(d){if(!vw)return;const c=cardById(vw.cid),L=listFor(c,vw.mode),i=L.findIndex(q=>q.cid===vw.cid),n=L[i+d];if(!n)return;sfx.pop();
  openView(n.cid,vw.mode);const k=$('#cvCard .tc');if(k){k.classList.add(d>0?'inR':'inL');}}
function flip(){const k=$('#cvCard .tc');if(!k||k.classList.contains('half'))return;sfx.pop();k.classList.add('half');
  setTimeout(()=>{k.classList.toggle('flip');void k.offsetWidth;k.classList.remove('half');},300);}
function readCard(c){const T=TY(c.type),s=c.stats;
  say(`${c.name}, a ${T.name} ${c.uni?'unicorn':'pup'} with ${c.zoom} Zoomies. ${c.moves[0][0]}, power ${c.moves[0][2]}. ${c.moves[1][0]}, power ${c.moves[1][2]}. Speed ${s.spd}, Brains ${s.brn}, Cuddles ${s.cud}, Bravery ${s.brv}. ${c.fact}`);}
function looksOf(c){const out=[];allSets().forEach(s=>s.cards.forEach(q=>{if(q.base===c.base&&q.breed===c.breed)out.push(q);}));return out;}
function showLooks(c,L){sfx.boop();const S=$('#cvStrip');S.innerHTML=`<div class="sh">${esc(c.name.split(' ').pop())} in every game and level</div>`;S.classList.add('on');
  L.forEach(o=>{const b=el('button','pocket',miniHTML(o));tap(b,()=>{if(!o.earned()){sfx.boop();say(o.hint());return;}S.classList.remove('on');openView(o.cid,null);});S.appendChild(b);});
  const x=el('button','btn white','✕');tap(x,()=>{sfx.boop();S.classList.remove('on');});S.appendChild(x);
  say(`${L.filter(o=>o.earned()).length} of ${L.length} looks collected.`);}
function tilt(){const t=$('#cvTilt');t.addEventListener('pointermove',e=>{const r=t.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
    t.style.transform=`perspective(900px) rotateY(${x*18}deg) rotateX(${-y*14}deg)`;t.style.setProperty('--sx',(x*100+50)+'%');t.style.setProperty('--sy',(y*100+50)+'%');});
  ['pointerleave','pointerup','pointercancel'].forEach(k=>t.addEventListener(k,()=>{t.style.transform='';}));}

/* ---------- Puppy Quest 2 cards ---------- */
function loadArt(cb,always){if(window.PQ2ART)return cb();const s=document.createElement('script');s.src='pq2cards.js';s.onload=()=>{S2=null;cb();};s.onerror=()=>{s.remove();say('Sorry, the Puppy Quest 2 cards could not load. Try again in a moment.');if(always)cb();};document.head.appendChild(s);}
function bringCards(code,done){const j=readCode(code,'PQ2:');if(!j||j.v!==1||!j.L)return false;
  loadArt(()=>{const A=window.PQ2ART,C=CS(),old=C.pq2,P={at:Date.now(),f:{},rd:{},buddy:j.buddy&&j.buddy.id?j.buddy.id+'@'+j.buddy.lv:(old&&old.buddy)||null,open:old?old.open:{}};
    let before=0,after=0;
    if(old){for(const lv in old.f){P.f[lv]=Object.assign({},old.f[lv]);before+=Object.keys(old.f[lv]).length;}Object.assign(P.rd,old.rd);before+=Object.keys(old.rd).length;}
    for(let lv=1;lv<=10;lv++){const F=(j.L[lv]||{}).found||{},ok=new Set(A.ALL[lv].map(p=>p.id));P.f[lv]=P.f[lv]||{};
      for(const id in F){if(!ok.has(id))continue;const v=F[id]&&F[id].sparkly?2:1;P.f[lv][id]=Math.max(P.f[lv][id]||0,v);}}
    const R=(j.rd&&j.rd.found)||{},okR=new Set(A.ALL[0].map(p=>p.id));for(const id in R)if(okR.has(id))P.rd[id]=1;
    for(const lv in P.f)after+=Object.keys(P.f[lv]).length;after+=Object.keys(P.rd).length;
    C.pq2=P;S2=null;save();badge();if(done)done(after,after-before);});
  return true;}
function welcomePQ2(total,added){closeOv('settings');
  const art=`<div class="fitsvg" style="width:170px">${packSVG({icon:'🎁',short:'Puppy Quest 2',n:total})}</div>`;
  card({cls:'cert',art,h:added===total?`${total} Puppy Quest 2 cards!`:added?`${added} new Puppy Quest 2 cards!`:'Your Puppy Quest 2 cards are up to date',
    p:added===total?'They are waiting in 11 packs on the Puppy Quest 2 shelf of your Card Binder. Tap a pack to open it!':added?`You now have ${total} Puppy Quest 2 cards in your binder.`:'Every card was already in your binder.',
    btns:[[ICON('b')+' Open my binder','green',()=>{shelf=2;openBinder(CS().pq2.open['2:1']?'2:1':'2:1',cur==='binder'?from:(W.area?'world':'title'));}]]});}
function importPage(speakIt){const Lp=$('#bdL'),Rp=$('#bdR');$('#bdH').textContent='🎁 Puppy Quest 2';
  Lp.innerHTML=`<div class="note big"><div class="fitsvg" style="width:200px;margin:0 auto">${packSVG({icon:'🎁',short:'Puppy Quest 2',n:PQ2_TOTAL})}</div><h3>Your Puppy Quest 2 pups can come too!</h3><p>Every pup you found in Puppy Quest 2 can have a card here: ${PQ2_TOTAL} cards in 11 packs.</p></div>`;
  Rp.innerHTML=`<div class="note"><h3>For grown-ups</h3><p>In Puppy Quest 2, hold the ⚙️ cog for 3 seconds, tap <b>Backup code</b>, then <b>Copy</b>. Paste the code here. Puppy Quest 2 is not changed.</p>
    <textarea id="bdCode" spellcheck="false" autocapitalize="off" autocorrect="off" autocomplete="off" placeholder="PQ2:..."></textarea><div class="msg" id="bdMsg"></div><button class="btn green" id="bdGo">🎁 Bring my cards</button></div>`;
  tap('#bdGo',()=>{if(!bringCards($('#bdCode').value,(t,a)=>{welcomePQ2(t,a);render();})){sfx.oops();$('#bdMsg').textContent='That does not look like a Puppy Quest 2 code. It starts with PQ2:';}else $('#bdMsg').textContent='Loading the cards...';});
  if(speakIt)say('Your Puppy Quest 2 pups can have cards too! Ask a grown-up to bring them across.');}

/* a foil pack */
const SPK=s=>s&&s.isl&&window.SEAPACK&&SEAPACK[String(s.isl).slice(0,2)];
function packSVG(s){if(SPK(s))return SPK(s).packSVG(s);const n=s.n!=null?s.n:s.cards.length;return `<svg viewBox="0 0 200 270"><defs><linearGradient id="pkf" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffd86b"/><stop offset=".35" stop-color="#ff9ecb"/><stop offset=".65" stop-color="#9bdcff"/><stop offset="1" stop-color="#8fe39a"/></linearGradient></defs>
  <path d="M14 18 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 l9 -10 l9 10 V252 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 l-9 10 l-9 -10 Z" fill="url(#pkf)" stroke="#5b4636" stroke-width="5" stroke-linejoin="round"/>
  <path d="M30 40 L60 230" stroke="#fff" stroke-width="10" opacity=".35"/><rect x="34" y="40" width="132" height="34" rx="14" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="64" text-anchor="middle" font-size="18" font-weight="900" fill="#5b4636" font-family="inherit">Pup Cards</text>
  <text x="100" y="152" text-anchor="middle" font-size="78">${s.icon}</text><rect x="26" y="186" width="148" height="56" rx="16" fill="#fff" stroke="#5b4636" stroke-width="4"/>
  <text x="100" y="210" text-anchor="middle" font-size="17" font-weight="900" fill="#5b4636" font-family="inherit">${esc(s.short||s.name)}</text><text x="100" y="232" text-anchor="middle" font-size="15" font-weight="800" fill="#5b4636" font-family="inherit">${n} cards</text></svg>`;}
function packPage(s,speakIt){const Lp=$('#bdL'),Rp=$('#bdR'),g=s.cards.filter(c=>c.earned()).length;$('#bdH').textContent=`${s.icon} ${s.name}`;
  Lp.innerHTML=`<button class="pq2pack wig2" id="bdPack">${packSVG(s)}</button>`;
  Rp.innerHTML=`<div class="note"><h3>A new pack!</h3><p>${g} ${esc(s.short||s.name)} cards are inside.</p><p class="pulse" style="font-size:30px">👆 Tap the pack to open it!</p></div>`;
  tap('#bdPack',()=>openPack(s));if(speakIt)say(`A new pack of ${s.name} cards! Tap the pack to open it.`);}
function openPack(s){const C=CS();if(C.pq2.open[s.id])return;const pk=$('#bdPack');pk.classList.remove('wig2');pk.classList.add('shake');sfx.giggle();
  setTimeout(()=>{pk.classList.add('burst');sfx.jingle();confetti(50);const Rp=$('#bdR');Rp.innerHTML='';const fan=el('div','fan','');Rp.appendChild(fan);
    const got=s.cards.filter(c=>c.earned());const show=[got.find(c=>c.uni)].concat(got.filter(c=>!c.uni).sort((a,b)=>hsh(a.cid)-hsh(b.cid)).slice(0,4)).filter(Boolean).slice(0,5);
    show.forEach((c,i)=>{const b=el('div','fc',miniHTML(c));b.style.setProperty('--i',i-(show.length-1)/2);b.style.animationDelay=(i*.18)+'s';fan.appendChild(b);});
    say(`Wow! ${got.length} ${s.short||''} cards!`);
    setTimeout(()=>{C.pq2.open[s.id]=1;save();render();},2600);},700);}

/* ---------- a new card flies to the binder when a pup is found ---------- */
let flyQ=[];
const _free=freePup;freePup=function(p){flyQ.push('3:'+p.id);return _free.apply(this,arguments);};
new MutationObserver(()=>{if($('#cele').classList.contains('on'))return;const q=flyQ.splice(0);setTimeout(()=>{if(cur!=='world'||ovOpen()){badge();return;}q.forEach((id,i)=>setTimeout(()=>fly(id),i*300));setTimeout(announce,q.length*300+200);},250);}).observe($('#cele'),{attributes:true,attributeFilter:['class']});
function fly(cid){badge();if(cur!=='world'||ovOpen())return;const c=cardById(cid);if(!c)return;
  if(!c.earned()){const k=packKey(cid);if(k&&packDone(k))return;const A=k&&AREAS[k];flyThing(`<div class="mc back" style="background:${c.col}"><div class="pkd">🐾</div></div>`,'bk');sfx.pop();if(A)toast(`${ICON('s')} Card saved for the <b>${esc(A.name)}</b> pack`);return;}
  const f=el('div','flycard',miniHTML(c));$('#fx').appendChild(f);sfx.pop();
  setTimeout(()=>f.classList.add('go'),40);setTimeout(()=>{f.remove();const b=$('#wCards');b.classList.remove('bump');void b.offsetWidth;b.classList.add('bump');},1300);}

/* ---------- links from the Pup House and the grown-ups panel ---------- */
const _detail=pupDetail;pupDetail=function(p){_detail.apply(this,arguments);if(!p||p.guest||!PUPS[p.id]||!isFound(p.id))return;
  const B=$('#celeCard .btns');if(!B)return;const b=el('button','btn white',ICON('b')+' See card');tap(b,()=>{sfx.boop();closeOv('cele');const c=cardById('3:'+p.id);if(c)openBinder(c.set,'book',c.earned()?c.cid:null);});B.appendChild(b);};
const _set=openSettings;openSettings=function(){_set.apply(this,arguments);const n=$('#pq2Go');if(!n)return;const row=n.closest('.srow'),note=row&&row.nextElementSibling;if(!note)return;
  const r=el('div','srow','🎁 Bring my Puppy Quest 2 cards<div class="opts"><button class="opt" id="pq2Cards">Bring my cards</button></div>');r.style.border='0';
  const t=el('div','snote','Paste a Puppy Quest 2 backup code in the box above, then tap "Bring my cards". Every pup found in Puppy Quest 2 gets a card in the Card Binder. You can do it again later to add new ones.');
  note.after(r);r.after(t);tap('#pq2Cards',()=>{if(!bringCards($('#bkTxt').value,welcomePQ2)){sfx.oops();$('#bkMsg').textContent='Paste a Puppy Quest 2 backup code (it starts with PQ2:) in the box first.';}});};

/* ---------- badges ---------- */
MERITS.push(
  {id:'cards50',icon:'🎴',name:'Card Collector',how:'Collect 50 cards in your Card Binder.',ok:()=>!!state&&earnedIds().length>=50},
  {id:'tin9',icon:'💖',name:'Special Tin',how:'Fill your Special Tin with 9 favourite cards.',ok:()=>!!state&&CS().tin.length>=TIN},
  {id:'pq2cards',icon:'🎁',name:'Old Friends',how:'Bring your Puppy Quest 2 cards across.',ok:()=>!!state&&!!CS().pq2},
  {id:'fullset',icon:'📚',name:'Full Set',how:'Collect every card in one island set, unicorn included.',ok:()=>!!state&&sets3().some(s=>s.isl&&!s.x&&s.cards.every(c=>c.earned()))});

build();
/* settle which cards an old save has already seen, before any new pup is found */
const _play=play;play=function(){if(state)APS();return _play.apply(this,arguments);};
window.CARDS={RAR,isSea,CS,sets3,sets2,allSets,cardById,earnedIds,newCount,openBinder,openView,bringCards,loadArt,render,BREEDS,breedOf,totalCards,readyPacks,packKey,APS,announce,flip,
  bigHTML,miniHTML,TY,LV2,STATS,setById,ICON,esc,BEATS};
})();
