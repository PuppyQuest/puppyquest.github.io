/* ================================================================
   Puppy Families (26 Nov 2026, claude/puppy-families-design.md sections 4 and 12): the story.
   - the Puppy Bus: Muddle collected the puppies for the Puppy Parade but never counted, and they wriggled off;
   - the bus stays on the plaza with the Puppy Count board (a pictogram: each 🐶 is a family of 3 puppies);
   - sightings of Muddle learning to count (12, 36, 72 and 108 puppies home);
   - nine Parade Rosettes: Tally sends Seb to Muddle at the Puppy Bus.
   ================================================================ */
(function(){
const PL=window.PFLOOK,PF=window.PF,H=window.PFHUNT,PI=Math.PI,P=id=>PUPS[id];
const S=()=>PF.S(),S0=()=>PF.S0()||{};
const big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`,mg=w=>`<div class="fitsvg" style="width:${w||140}px;display:inline-block">${magpieSVG()}</div>`,gr=w=>`<div class="fitsvg" style="width:${w||130}px;display:inline-block">${grannySVG()}</div>`;
const nHome=()=>PF.nPuppies()-3;
function busSVG(o){o=o||{};const K=INK;return `<svg viewBox="0 0 320 170" width="${o.w||300}" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="30" width="270" height="104" rx="22" fill="#ffd23f" stroke="${K}" stroke-width="5"/><rect x="270" y="70" width="32" height="56" rx="10" fill="#ffd23f" stroke="${K}" stroke-width="5"/>`+
  [44,98,152,206].map(x=>`<rect x="${x}" y="46" width="44" height="34" rx="8" fill="#bfe8ff" stroke="${K}" stroke-width="4"/>`).join('')+`<rect x="258" y="46" width="22" height="50" rx="6" fill="#bfe8ff" stroke="${K}" stroke-width="4"/>`+
  `<text x="150" y="116" text-anchor="middle" font-size="24" font-weight="900" font-family="Arial" fill="${K}">${o.sign||'PUPPY BUS'}</text>`+
  [80,240].map(x=>`<circle cx="${x}" cy="136" r="20" fill="#3a3338" stroke="${K}" stroke-width="4"/><circle cx="${x}" cy="136" r="8" fill="#c8c2b8"/>`).join('')+
  (o.empty?'':'')+`<circle cx="296" cy="112" r="6" fill="#fff6c0" stroke="${K}" stroke-width="3"/></svg>`;}
/* ---------------- the Puppy Bus arrives ---------------- */
let BUSY=false;
function busScene(){const X=S();if(BUSY||X.bus)return;BUSY=true;player.lock=true;hush();try{const t=AC.currentTime;tone(392,t,.18,'square',.2);tone(392,t+.24,.3,'square',.2);}catch(e){}
  story([{art:busSVG({w:300}),t:'Parp parp! A little yellow bus rolls into the plaza, with Muddle at the wheel in a peaked cap. On the side it says PUPPY BUS.'},
    {art:mg(120)+big('🧸'),t:'Muddle opens the door... and out falls one squeaky toy. The bus is empty!'},
    {art:mg(140),t:'"I wanted to help with the Puppy Parade," says Muddle, "so I drove round all nine islands to collect the puppies. But every time I opened the door for more puppies, some wriggled off to explore. And I never counted them!"'},
    {art:gr(130),t:'"Oh dear!" says Granny Paws. "The puppies are only a few weeks old. Their eyes are open now, and they love to explore. Their mums and dads will be so worried!"'},
    {art:big('💭🐶🐶🐶'),t:'Every pup on the islands is looking for its own three puppies. Look for a pup with a 💭 thought bubble, and help it sniff out its family! The puppies are hiding in all sorts of places.'},
    {art:big('🦄🏵️'),t:`When ${H.NEED} families on an island are home, its unicorn will bring a Parade Rosette for the puppy float. Collect all nine, and the Puppy Parade can begin!`}],
    ()=>{X.bus=Date.now();save();BUSY=false;player.lock=false;sfx.fanfare();enterArea('village',[player.x,player.z,player.h],'');setTimeout(()=>say('Let\'s find the puppies! Look for a pup with a 💭 thought bubble on the islands.'),400);});}
const busAt=()=>(window.PFSPOTS&&PFSPOTS._bus)||[-16,14,0];
function bus3D(){const g=grp(),K='#ffd23f';mk('box',K,4.2,2.6,7.4,0,1.9,0,g);mk('box','#3a3338',4.3,.5,7.5,0,.75,0,g);
  [-2.3,-.6,1.1].forEach(z=>[-1,1].forEach(s=>mk('box','#bfe8ff',.1,1,1.2,s*2.12,2.5,z,g,true)));mk('box','#bfe8ff',3.4,1,.1,0,2.5,3.72,g,true);
  [[-1.7,-2.4],[1.7,-2.4],[-1.7,2.4],[1.7,2.4]].forEach(q=>{const w=mk('cyl','#26232e',.65,.5,.65,q[0]+(q[0]>0?.15:-.15),.65,q[1],g);w.rotation.z=PI/2;});
  mk('sph','#fff6c0',.25,.25,.1,-1.3,1.4,3.72,g,true);mk('sph','#fff6c0',.25,.25,.1,1.3,1.4,3.72,g,true);return g;}
function busBuild(){const b=busAt(),g=bus3D();g.rotation.y=b[2]||0;add(g,b[0],b[1]);col(b[0],b[1],3.6);
  const sg=label('🚌 PUPPY BUS',4.6);sg.position.set(b[0],gy(b[0],b[1])+4.4,b[1]);W.ag.add(sg);
  const m=magpie3D();m.scale.setScalar(.8);add(m,b[0],b[1],gy(b[0],b[1])+3.2);W.ticks.push(()=>{m.rotation.y=Math.sin(W.t*.7)*1.2;m.position.y=gy(b[0],b[1])+3.2+Math.abs(Math.sin(W.t*2))*.15;});
  const fx=b[0]+Math.cos(b[2]||0)*4.2,fz=b[1]-Math.sin(b[2]||0)*4.2;
  I('box','#9b6a43',.2,2.2,.2,fx,1.1,fz);I('box','#fff6e0',2.4,1.6,.15,fx,2.4,fz);spr('📊',1,fx,2.4,fz+.12);
  W.things.push({x:fx,z:fz,r:3,icon:'📊',label:'Puppy Count',act:board});
  W.things.push({x:b[0],z:b[1],r:4.6,icon:'🐦',label:'Muddle',act:muddleTalk});}
function board(){if(player.lock)return;sfx.chime();const rows=ISLANDS.map(I=>{const n=H.famIsl(I),r=!!(S0().ros||{})[I.id];return `<button class="pfpicrow" data-i="${I.id}"><b>${I.icon}</b><span>${'🐶'.repeat(n)||'<i>none yet</i>'}</span>${r?'<em>🏵️</em>':''}</button>`;}).join('');
  card({art:'',h:'📊 The Puppy Count',p:`<span class="pfkey">Key: 🐶 = a family of 3 puppies</span><span class="pfpic">${rows}</span><span class="pfkey">${nHome()} puppies are home. Tap a row to count it!</span>`,say:`The Puppy Count. Each dog picture means a family of 3 puppies. ${nHome()} puppies are home.`,btns:[['OK','green']]});
  document.querySelectorAll('#celeCard .pfpicrow').forEach(b=>tap(b,()=>{const I=islandOf(b.dataset.i),n=H.famIsl(I);sfx.boop();speak(n?`${I.name}: ${n} ${n>1?'families':'family'}. ${n} threes ${n>1?'are':'is'} ${n*3}. That's ${n*3} puppies!`:`${I.name}: no families home yet.`);}));}
const TALK=['"I\'m practising counting in threes: 3, 6, 9, 12!"','"Every time I count, I count everyone. Even the wriggly ones!"','"One puppy, two puppies, three puppies... that\'s a family!"','"Have you seen a pup with a thought bubble? It needs your help!"'];
function muddleTalk(){if(player.lock)return;const X=S0();if(X.call&&!X.met&&window.PFSTORY.meet)return PFSTORY.meet();if(X.met&&!X.counted&&PFSTORY.count)return PFSTORY.count();if(X.counted&&!X.done&&PFSTORY.parade)return PFSTORY.parade();if(X.done){sfx.yip(1.4);return say('Muddle says: "Thank you for teaching me to count, Seb! Every family counts!"');}
  sfx.yip(1.4);say('Muddle says: '+TALK[Math.floor(Math.random()*TALK.length)]);}
/* ---------------- sightings ---------------- */
const SEEN=[[12,()=>({art:mg(120)+big('🪨'),t:'Muddle is sitting on the roof of the Puppy Bus, counting pebbles in threes. "3, 6, 9... 11? No! 12!"'})],
  [36,()=>({art:mg(120)+big('🧦'),t:'Muddle flies over with a tiny striped sock in his beak. "I found this on the bus. Does it belong to a puppy?" (Puppies don\'t wear socks, Muddle!)'})],
  [72,()=>({art:mg(120)+big('✏️'),t:'Muddle has drawn a tally chart on the bus window: a line for every puppy that is home, in groups of five. "Counting is fun when you do it properly!"'})],
  [108,()=>({art:busSVG({w:260,sign:'COUNT EVERYONE!'}),t:'A new sign on the Puppy Bus says COUNT EVERYONE! "I will never forget again," says Muddle.'})]];
let ST=null;function afterHome(){clearTimeout(ST);let tries=0;const go=()=>{const X=S();X.seen=X.seen||{};const n=nHome(),q=SEEN.find(s=>n>=s[0]&&!X.seen[s[0]]);if(!q)return;
  if(player.lock||ovOpen()||cur!=='world'){if(++tries<8)ST=setTimeout(go,1500);return;}X.seen[q[0]]=1;save();player.lock=true;story([q[1]()],()=>{player.lock=false;});};ST=setTimeout(go,600);}
/* ---------------- nine rosettes ---------------- */
function call(){const X=S();if(X.call)return;X.call=Date.now();save();const T=islandOf('number');player.lock=true;sfx.chime();
  story([{art:`<div class="pfuni">${H.uniArt(T,130)}</div>`+big('🏵️'),t:'All nine Parade Rosettes! The puppy float is ready for the Puppy Parade.'},
    {art:`<div class="pfuni">${H.uniArt(T,120)}</div>`+mg(110),t:'"Muddle is waiting by the Puppy Bus in the plaza," says Tally. "He has something to show you!"'}],()=>{player.lock=false;say('Go to the Puppy Bus in the village plaza, and talk to Muddle!');});}
/* the village: the bus arrives once, then stays */
const _ea=enterArea;enterArea=function(id,pos,msg){_ea.apply(this,arguments);const X=S0();if(id!=='village'||!PF.begun()||!X.intro||state.season)return;
  if(!X.bus){setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village'||S0().bus)return;busScene();},1500);return;}
  if(X.call&&!X.met)setTimeout(()=>{if(cur==='world'&&!ovOpen()&&!player.lock)say('Muddle is waiting by the Puppy Bus. Go and talk to him!');},1800);};
{const V=AREAS.village,_b=V.build;V.build=function(){_b.apply(this,arguments);const X=S0();if(PF.begun()&&X.bus&&!state.season&&!X.gone)try{busBuild();}catch(e){console.warn('pf bus',e);}};}
const css=document.createElement('style');css.textContent=`.pfpic{display:block;margin:6px auto;max-width:640px;text-align:left}.pfpicrow{display:flex;align-items:center;gap:10px;width:100%;background:#fff8ec;border:3px solid #ffd9a8;border-radius:14px;margin:4px 0;padding:2px 10px;min-height:46px;font-size:26px;cursor:pointer}
.pfpicrow b{font-size:30px;width:40px}.pfpicrow span{flex:1;letter-spacing:2px;word-break:break-all}.pfpicrow i{font-size:18px;color:#a08868}.pfpicrow em{font-style:normal}.pfkey{display:block;font-size:20px;font-weight:800;margin:4px}`;document.head.appendChild(css);
window.PFSTORY=Object.assign(window.PFSTORY||{},{busScene,busSVG,bus3D,board,afterHome,call,onFind:()=>{},SEEN});
})();

/* ================================================================
   Puppy Families finale (26 Nov 2026, claude/puppy-families-design.md sections 4.2 scenes 10 to 14, and 12):
   Muddle's Puppy Counter at the bus; the Puppy Count (nine carriages: counting in threes, the 3 times table,
   sharing into threes and a pictogram, with the grown-ups' table in two carriages if it is set); the Puppy
   Parade (certificate, bandanas for every family, 100 stars); Granny's old photo of five-year-old Seb with a
   star-marked pup ("Coming soon: Puppy Quest 1!"); and the last frame, where Zuzu's star map flickers.
   ================================================================ */
(function(){
const PL=window.PFLOOK,PF=window.PF,H=window.PFHUNT,P=id=>PUPS[id],ST=window.PFSTORY;
const S=()=>PF.S(),S0=()=>PF.S0()||{};
const big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`,mg=w=>`<div class="fitsvg" style="width:${w||140}px;display:inline-block">${magpieSVG()}</div>`,gr=w=>`<div class="fitsvg" style="width:${w||130}px;display:inline-block">${grannySVG()}</div>`;
const hasMap=()=>!!(state.bh&&(state.bh.fixed||state.bh.done));
function abacus(w,lit){let s='';for(let r=0;r<4;r++){s+=`<line x1="10" y1="${22+r*26}" x2="190" y2="${22+r*26}" stroke="#7a4f2a" stroke-width="4"/>`;for(let b=0;b<3;b++)s+=`<circle cx="${lit&&r<lit?120+b*24:24+b*24}" cy="${22+r*26}" r="10" fill="${['#ff6b6b','#ffd23f','#8fd0ff','#9ae07a'][r]}" stroke="#26232e" stroke-width="2.5"/>`;}
  return `<svg viewBox="0 0 200 120" width="${w||200}"><rect x="2" y="4" width="196" height="112" rx="12" fill="none" stroke="#9b6a43" stroke-width="7"/>${s}</svg>`;}
function meet(){const X=S();if(X.met||player.lock)return;player.lock=true;hush();sfx.yip(1.4);
  story([{art:mg(140),t:'Muddle hops down from the Puppy Bus. "Thank you, Seb. Every family is home because of you." He flies to every grown-up pup and says sorry for losing their puppies.'},
    {art:mg(110)+`<span class="fitsvg" style="width:190px;display:inline-block">${abacus(190,4)}</span>`,t:'"Look what I made: a Puppy Counter! Every row has 3 beads, one for each puppy in a family. Now I will never forget to count."'},
    {art:ST.busSVG({w:280,sign:'PUPPY PARADE'}),t:'"The puppy float has nine carriages, one for each island. Will you help me count the families on board, so we know everyone is there?"'}],
    ()=>{X.met=Date.now();save();player.lock=false;card({art:big('🧮'),h:'The Puppy Count',p:'Shall we count the families onto the puppy float now?',btns:[['🧮 Let\'s count!','green',()=>count()],['Later','white',()=>say('Talk to Muddle at the Puppy Bus when you are ready to count!')]]});});}
/* ---------------- the Puppy Count ---------------- */
let CQ=null;
function qFor(k){const I=ISLANDS[k],n=Math.max(H.NEED,H.famIsl(I)),tb=typeof tablesOn==='function'?(tablesOn()||[]).filter(v=>v>=2&&v<=12&&v!==3):[],R=seed(k*17+n);
  const opt=(a,L)=>{const s=[...new Set([a].concat(L))].filter(v=>v>0).slice(0,3);while(s.length<3)s.push(a+s.length*2+1);return s.sort((x,y)=>x-y);};
  if(tb.length&&(k===5||k===7)){const t=tb[Math.floor(R()*tb.length)],r=3+Math.floor(R()*4);
    return k===5?{I,kind:'tab',q:`Each carriage has rows of <b>${t}</b> seats. <b>${r}</b> rows: how many seats?`,say:`Each carriage has rows of ${t} seats. ${r} rows: how many seats?`,ans:r*t,opts:opt(r*t,[r*t-t,r*t+t]),groups:r,per:t,em:'💺'}
      :{I,kind:'tab',q:`<b>${r*t}</b> bandanas come in packs of <b>${t}</b>. How many packs?`,say:`${r*t} bandanas come in packs of ${t}. How many packs?`,ans:r,opts:opt(r,[r-1,r+1]),groups:r,per:t,em:'🎀',loose:true};}
  if(k<3)return {I,kind:'threes',q:`<b>${n}</b> families of 3 puppies. How many puppies?`,say:`${n} families of 3 puppies. How many puppies?`,ans:n*3,opts:opt(n*3,[n*3-3,n*3+3]),groups:n,per:3,em:'🐶'};
  if(k<6)return {I,kind:'table',q:`<b>${n}</b> families. Each family has 3 puppies. How many puppies?`,say:`${n} families. Each family has 3 puppies. How many puppies?`,ans:n*3,opts:opt(n*3,[n+3,n*3+3]),groups:n,per:3,em:'🐕',parents:true};
  if(k<8)return {I,kind:'share',q:`<b>${n*3}</b> puppies, in families of 3. How many families?`,say:`${n*3} puppies, in families of 3. How many families?`,ans:n,opts:opt(n,[n-1,n+1]),groups:n,per:3,em:'🐶',loose:true};
  return {I,kind:'pict',q:`🐶 means a family of 3 puppies. ${I.name}'s row has <b>${n}</b> 🐶. How many puppies?`,say:`Each dog picture means a family of 3 puppies. ${I.name}'s row has ${n} pictures. How many puppies?`,ans:n*3,opts:opt(n*3,[n,n*3+3]),groups:n,per:3,em:'🐶',pict:true};}
function cui(){if($('#pfcount'))return;const d=el('div','ov pfov2','<div class="card pftrick" id="pfcntCard"><h2>🧮 The Puppy Count</h2><div id="pfcTrain"></div><div id="pfcQ" class="pfsay"></div><div id="pfcVis"></div><div id="pfcAns" class="pfans"></div><p class="pfmsg" id="pfcntMsg"></p><div class="btns"><button class="btn white" id="pfcntBack">Later</button></div></div>');d.id='pfcount';document.body.appendChild(d);
  tap('#pfcntBack',()=>{sfx.boop();d.classList.remove('on');player.lock=false;CQ=null;MUSIC.over=null;say('Talk to Muddle at the Puppy Bus to finish the Puppy Count.');});}
function train(i){return `<svg viewBox="0 0 960 90" class="pftrain">${ISLANDS.map((I,k)=>{const x=10+k*105,done=k<i,cur=k===i;return `<g><rect x="${x}" y="10" width="94" height="56" rx="12" fill="${done?'#ffe680':cur?'#ffffff':'#f4ece0'}" stroke="${cur?'#ff6fae':'#7a4f2a'}" stroke-width="${cur?6:4}"/><circle cx="${x+22}" cy="72" r="11" fill="#3a3338"/><circle cx="${x+72}" cy="72" r="11" fill="#3a3338"/><text x="${x+47}" y="50" text-anchor="middle" font-size="30">${done?'🐶':I.icon}</text>${(S0().ros||{})[I.id]?`<text x="${x+84}" y="24" font-size="18">🏵️</text>`:''}</g>`;}).join('')}<path d="M0 82 H960" stroke="#7a4f2a" stroke-width="4"/></svg>`;}
function vis(q){if(q.pict)return `<div class="pfvpict"><span class="pfkey">Key: 🐶 = 3 puppies</span><div class="pfvrow"><b>${q.I.icon}</b>${'<i class="pfg">🐶</i>'.repeat(q.groups)}</div></div>`;
  if(q.loose)return `<div class="pfvloose">${Array.from({length:q.groups*q.per},(v,i)=>`<i class="pfl" data-g="${Math.floor(i/q.per)}">${q.em}</i>`).join('')}</div>`;
  if(q.parents)return `<div class="pfvgr">${Array.from({length:q.groups},(v,i)=>`<i class="pfg pfpar1">${q.em}</i>`).join('')}</div>`;
  return `<div class="pfvgr">${Array.from({length:q.groups},()=>`<i class="pfg">${q.em.repeat(q.per)}</i>`).join('')}</div>`;}
function count(){const X=S();if(!X.met){meet();return;}cui();player.lock=true;hush();MUSIC.over='pfbus';X.count=X.count||0;$('#pfcount').classList.add('on');ask();}
function ask(){const X=S(),i=X.count||0;if(i>=ISLANDS.length)return done();const q=qFor(i);CQ={q,w:0,busy:0};$('#pfcTrain').innerHTML=train(i);
  $('#pfcQ').innerHTML=`<span class="pfci">${q.I.icon} ${q.I.name}'s carriage</span><br>${q.q}`;$('#pfcVis').innerHTML=vis(q);$('#pfcntMsg').textContent='';speak(q.say);
  $('#pfcAns').innerHTML=q.opts.map(v=>`<button class="btn blue" data-v="${v}">${v}</button>`).join('');
  document.querySelectorAll('#pfcAns .btn').forEach(b=>tap(b,()=>pick(b,+b.dataset.v)));}
function countAloud(q,cb){const G=[...document.querySelectorAll('#pfcVis .pfg')],L=[...document.querySelectorAll('#pfcVis .pfl')];CQ.busy=1;let k=0;const n=q.groups;
  const step=()=>{if(!CQ)return;if(k>=n){CQ.busy=0;if(cb)cb();return;}if(G[k])G[k].classList.add('lit');L.filter(e=>+e.dataset.g===k).forEach(e=>e.classList.add('lit'));try{tone(880+k*30,AC.currentTime,.08,'square',.12);}catch(e){}
    speak(String((k+1)*q.per));$('#pfcntMsg').textContent=Array.from({length:k+1},(v,j)=>(j+1)*q.per).join(', ');k++;setTimeout(step,650);};step();}
function pick(b,v){if(!CQ||CQ.busy||b.classList.contains('nope'))return;const q=CQ.q;
  if(v===q.ans){b.classList.add('win');sfx.chime();CQ.busy=1;countAloud(q,()=>{$('#pfcntMsg').textContent=`${q.ans}! All aboard ${q.I.name}'s carriage!`;speak(`${q.ans}! All aboard!`);sfx.yip(1.8);
      setTimeout(()=>{const X=S();X.count=(X.count||0)+1;save();ask();},1500);});return;}
  CQ.w++;b.classList.add('nope');sfx.oops();
  countAloud(q,()=>{$('#pfcntMsg').textContent=q.kind==='share'||(q.kind==='tab'&&q.loose)?`Count the groups: ${q.groups}!`:`Count on in ${q.per}s: ${Array.from({length:q.groups},(v,j)=>(j+1)*q.per).join(', ')}.`;
    document.querySelectorAll('#pfcVis .lit').forEach(e=>e.classList.remove('lit'));if(CQ.w>=2)document.querySelectorAll('#pfcAns .btn').forEach(x=>{if(+x.dataset.v===q.ans)x.classList.add('hint');});});}
function done(){const X=S();$('#pfcount').classList.remove('on');CQ=null;const first=!X.counted;X.counted=X.counted||Date.now();if(first){state.stars+=100;}save();hud();sfx.fanfare();confetti(80);
  card({art:big('🚂🐶🐶🐶'),h:'Everyone is on board!',p:`All nine carriages are full, and every family is counted. ${first?'+100 ⭐ ':''}Muddle beams: "Counting is the best!" Let the Puppy Parade begin!`,btns:[['🎉 The Puppy Parade!','green',()=>parade()]]});}
/* ---------------- the Puppy Parade ---------------- */
function parade(){const X=S(),b=X.basket&&X.basket.pid,H2=PF.homes(),zu=window.BHQ&&state.bh&&state.bh.done?' Zuzu has come all the way from her planet to watch!':'';player.lock=true;MUSIC.over='disco' in TUNES?'disco':null;
  const row=H2.slice(0,4).map(id=>`<span class="fitsvg" style="width:150px;display:inline-block">${PL.famSVG(P(id),PF.stg(id),{bd:1})}</span>`).join('');
  story([{art:row,t:`The plaza is full of bunting and sunshine. Here comes the Puppy Parade! Every family marches past, behind Seb and ${b?P(b).name+'\'s puppies':'the puppies'}.`},
    {art:`<div class="pfuni">${H.uniArt(islandOf('meadow'),110)}${H.uniArt(islandOf('snowy'),110)}</div>`,t:`Granny Paws waves from the stage, with the guides and all nine unicorns and their foals.${zu} And Muddle drives the puppy float, honking the horn: parp parp!`},
    {art:`<div class="pfpile2">${b?`<span class="fitsvg" style="width:170px;display:inline-block">${PL.famSVG(P(b),PF.stg(b),{bd:1})}</span>`:''}</div>`+big('🎀'),t:'Granny Paws gives every family matching bandanas, a grown-up one and three little ones. You can see them in the Puppy Room and on the islands!'}],
    ()=>{H2.forEach(id=>{PF.famOf(id).bd=1;});state.certs=state.certs||{};const c=CERTS.find(q=>q.id==='pfhero');if(c&&!state.certs[c.id])state.certs[c.id]=Date.now();X.para=X.para||Date.now();save();hud();
      if(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray!','green',photoScene]]}));}else photoScene();});}
/* ---------------- the old photo ---------------- */
function starPup(){const L={fur:'#f6f2ea',belly:'#ffffff',muzzle:'#ffffff',ears:'floppy',ear:'#e8dcc8',tail:'wag',acc:[]};const s=critterSVG({id:'oldpup',name:'',breed:'',look:L},{anim:false}).replace(/^<svg[^>]*>/,'<svg x="166" y="108" width="86" height="90" viewBox="0 0 200 210">');
  return s.replace(/<\/svg>$/,`<path d="M100 38 l6 12 l13 2 l-9 9 l2 13 l-12 -6 l-12 6 l2 -13 l-9 -9 l13 -2 Z" fill="#ffd23f" stroke="#c8a020" stroke-width="2"/></svg>`);}
function oldPhoto(){const seb=sebSVG().replace(/^<svg[^>]*>/,'<svg x="88" y="26" width="134" height="184" viewBox="0 0 200 260">');
  return `<div class="pfold"><svg viewBox="0 0 340 260" xmlns="http://www.w3.org/2000/svg"><rect x="0" y="0" width="340" height="260" rx="6" fill="#f6efe0"/><rect x="14" y="14" width="312" height="196" fill="#cfe4ee"/><rect x="14" y="110" width="312" height="40" fill="#8fbcd0"/>`+
    `<path d="M14 150 Q100 140 180 150 T326 148 V210 H14 Z" fill="#b8b0a4"/>${Array.from({length:22},(v,i)=>`<ellipse cx="${24+(i*37)%300}" cy="${170+(i*13)%34}" rx="${8+(i%3)*3}" ry="${5+(i%2)*2}" fill="${['#9a9288','#c8c0b4','#a8a094'][i%3]}"/>`).join('')}`+
    `<circle cx="280" cy="50" r="18" fill="#fff6c0"/>${seb}${starPup()}`+
    `<text x="30" y="240" font-size="20" font-family="'Comic Sans MS','Chalkboard SE',cursive" fill="#5a4636">Seb, aged 5, and</text><ellipse cx="225" cy="234" rx="44" ry="9" fill="#a89880" opacity=".55"/><ellipse cx="236" cy="236" rx="22" ry="6" fill="#c8b8a0" opacity=".6"/></svg></div>`;}
function photoScene(){const X=S();player.lock=true;MUSIC.over=null;
  story([{art:PF.bookArt(200)+gr(110),t:'Granny Paws opens her Pup Book at the very back, to stick in a photo of the Puppy Parade. And look: the stuck page has come free!'},
    {art:oldPhoto(),t:'An old photo slides out. It\'s Seb, aged five, on Pebble Ridge, with a little puppy that has a star on its forehead!'},
    {art:oldPhoto(),t:'"That\'s me!" says Seb. "But I don\'t remember that puppy at all." Under the photo, in Granny\'s writing, it says "Seb, aged 5, and..." but the name has faded away.'},
    {art:gr(140),t:'Granny Paws looks up at the sky and smiles. "You had a very special friend once," she says. "But that\'s a story for another day."'},
    {art:`<div class="pfpq1"><div>🌟</div><b>Coming soon:</b><strong>Puppy Quest 1</strong><em>The First Wish</em></div>`,t:'Coming soon: Puppy Quest 1!'}],
    ()=>{X.done=X.done||Date.now();save();flicker();});}
/* ---------------- the last frame ---------------- */
function nightArt(){const X=S0(),b=X.basket&&X.basket.pid,map=hasMap();const st=[[60,40],[90,70],[130,32],[160,80],[200,46],[230,92],[110,110],[180,120],[70,100],[215,20]];
  const mapS=map?`<g transform="translate(470 40)"><rect width="250" height="150" rx="10" fill="#1c2450" stroke="#c8a860" stroke-width="5"/>${st.map((q,i)=>`<circle cx="${q[0]-40}" cy="${q[1]+10}" r="${i===3?5:3}" fill="#fff6c0" ${i===3?'class="pfflick"':''}/>`).join('')}<path d="M20 50 L50 80 L90 42 L120 90" stroke="#8fd0ff" stroke-width="2" stroke-dasharray="5 5" fill="none"/></g>`
    :`<g transform="translate(470 40)"><rect width="250" height="150" rx="75" fill="#1c2450" stroke="#ffffff" stroke-width="6"/>${st.slice(0,7).map((q,i)=>`<circle cx="${q[0]}" cy="${q[1]}" r="${i===3?5:2.5}" fill="#fff6c0" ${i===3?'class="pfflick"':''}/>`).join('')}</g>`;
  const pups=b?[0,1,2].map(i=>PL.svg(P(b),i,PF.stg(b),{anim:false,sleep:true,bd:1}).replace(/^<svg[^>]*>/,`<svg x="${250+i*58}" y="250" width="70" height="74" viewBox="0 0 200 210">`)).join(''):'';
  return `<svg viewBox="0 0 760 340" class="pfnight" xmlns="http://www.w3.org/2000/svg"><rect width="760" height="340" rx="22" fill="#2a2648"/><rect x="0" y="290" width="760" height="50" fill="#3a3060"/>${mapS}`+
    `<rect x="40" y="200" width="190" height="90" rx="12" fill="#5a4a7a"/><rect x="40" y="186" width="190" height="34" rx="12" fill="#7a6aa0"/><circle cx="80" cy="186" r="20" fill="#f0c8a0"/><text x="120" y="170" font-size="26" fill="#c8c0ff">z z z</text>`+
    `<ellipse cx="340" cy="312" rx="120" ry="18" fill="#8a6a4a"/>${pups}</svg>`;}
function flicker(){const X=S();player.lock=true;sfx.chime();
  card({art:nightArt(),p:' ',say:false,cls:'pfnightc',btns:[['🌙','blue',()=>{X.flick=X.flick||Date.now();save();player.lock=false;MUSIC.over=null;
    if(W.area&&W.area.id!=='den')enterArea('den',[0,4,Math.PI],'');setTimeout(()=>say('Goodnight, Seb! Your puppy families are safe and sound. There are '+(PF.famIds().length-PF.homes().length)+' more families to find, whenever you like.'),700);}]]});}
/* the village and Muddle */
const _ea=enterArea;enterArea=function(id,pos,msg){_ea.apply(this,arguments);const X=S0();if(id!=='village'||!PF.begun()||state.season)return;
  if(X.met&&!X.counted)setTimeout(()=>{if(cur==='world'&&!ovOpen()&&!player.lock)say('Muddle is ready to count the families onto the float. Talk to him at the Puppy Bus!');},1800);};
/* the certificate */
CERTS.push({id:'pfhero',icon:'👪',title:'Puppy Families Hero',get why(){return 'for helping every pup sniff out its puppies, teaching Muddle to count everyone in threes, and bringing the Puppy Parade to Pawprint Village';},ok:()=>!!S0().para});
/* the Den: Zuzu's star map on the wall after the parade */
{const D=AREAS.den,_b=D.build;D.build=function(){_b.apply(this,arguments);const X=S0();if(!X.done||!hasMap())return;I('box','#c8a860',.1,2.4,3.4,13.9,4.4,-4.6);I('box','#1c2450',.12,2.1,3.1,13.85,4.4,-4.6,0,0,0,true);
  [[-1,.5],[0,.8],[1,.2],[-.6,-.5],[.7,-.6]].forEach(q=>I('sph','#fff6c0',.08,.08,.08,13.75,4.4+q[1],-4.6+q[0],0,0,0,true));const l=label('🗺️ Zuzu\'s star map',4);l.position.set(13.2,6,-4.6);W.ag.add(l);}};
const css=document.createElement('style');css.textContent=`
.pftrain{width:100%;height:auto;display:block;margin:0 0 4px}#pfcQ{margin:4px auto;max-width:860px}.pfci{font-size:20px;color:#a07850}
#pfcVis{min-height:150px;display:flex;align-items:center;justify-content:center;margin:6px 0}.pfvgr,.pfvloose{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;max-width:900px}
.pfg{font-style:normal;font-size:30px;background:#fff8ec;border:3px solid #ffd9a8;border-radius:14px;padding:4px 6px;transition:background .3s}.pfpar1{font-size:42px}.pfl{font-style:normal;font-size:34px;transition:transform .3s}
.pfg.lit{background:#ffe680;border-color:#ffb020}.pfl.lit{transform:scale(1.3)}.pfvpict .pfvrow{display:flex;align-items:center;gap:8px;background:#fff8ec;border:3px solid #ffd9a8;border-radius:14px;padding:6px 12px}.pfvpict b{font-size:34px}
#pfcAns .btn{min-width:120px;min-height:76px;font-size:38px;font-weight:900}#pfcAns .btn.nope{opacity:.4}#pfcAns .btn.win{background:#8ae05a}#pfcAns .btn.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
.pfold{display:inline-block;width:340px;max-width:100%;transform:rotate(-3deg);box-shadow:0 8px 0 rgba(0,0,0,.2)}.pfold svg{width:100%;height:auto;display:block;filter:sepia(.55) saturate(.8)}
.pfpq1{display:inline-flex;flex-direction:column;align-items:center;background:linear-gradient(#1c2450,#3a3a8a);color:#fff;border-radius:22px;padding:14px 40px}.pfpq1 div{font-size:60px}.pfpq1 b{font-size:22px}.pfpq1 strong{font-size:44px;color:#ffe680}.pfpq1 em{font-size:24px}
.pfnightc{background:#1a1830}.pfnight{width:100%;max-width:760px;height:auto}.pfflick{animation:pfflk 3.2s ease-in-out .8s 1 forwards}@keyframes pfflk{0%{opacity:1}15%{opacity:.1}30%{opacity:1}45%{opacity:.1}60%{opacity:1}100%{opacity:1}}`;
document.head.appendChild(css);
Object.assign(window.PFSTORY,{meet,count,parade,photoScene,oldPhoto,flicker,qFor,_cq:()=>CQ});
})();
