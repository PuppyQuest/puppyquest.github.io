/* ================================================================
   Night Glow (25 Nov 2026; claude/night-glow-design.md sections 6, 7, 12): the world at night.
   The village (lanterns, the Star Map board, the telescope, the Star Party after the finale),
   each island's night touches and surprise (moonflowers, the Northern Lights, the Moon Clock,
   Tinker's light show, the lighthouse switch-on, glowing fossil footprints, glowing mushrooms),
   the three spotlights (the Glowing Bay with Glow Swim, the Lantern Festival with Lantern
   Light-up, the Meteor Shower with Meteor Catch), the night quiz in the Lab, the Den,
   Arcade entries and the night tunes (Twinkle Twinkle, Au clair de la lune, Brahms' Lullaby).
   ================================================================ */
(function(){
const GW=window.GLOW,XM=window.XMAS,PI=Math.PI,LIME='#d8ff5a',GOLD='#ffd23f',NAVY='#1b2452',LC=['#ffb347','#ff7fb8','#7fd0ff','#c8ff4a','#ff6a5a'];
const G=()=>GW.GS(),acts=()=>{const s=G();s.acts=s.acts||{};return s.acts;},F=()=>GW.fly().name;
function sayOnce(k,m,ms){const a=acts();if(a['s_'+k])return;a['s_'+k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say(m);},ms||1600);}
/* a free spot near a point (after the area is built), from the season planner's grid */
let GRD=null;function near(A,x,z,c){if(!GRD||GRD.id!==A.id){GRD=XM.grid(A,1);GRD.id=A.id;}const k=GRD.snap(x,z,c||2);return k<0?[x,z]:GRD.xz(k);}
function lantern(x,z,col,h){const y=gy(x,z);h=h||2.4;I('cyl','#3a3338',.06,h,.06,x,y+h/2,z);I('box','#3a3338',.5,.05,.06,x+.22,y+h,z);I('sph',col||LC[0],.32,.36,.32,x+.44,y+h-.42,z,0,0,0,true);I('cyl','#26232e',.16,.06,.16,x+.44,y+h-.04,z);}
function shroom(x,z,s,col){const y=gy(x,z);I('cyl','#e8e0d0',.08*s,.5*s,.08*s,x,y+.25*s,z);I('hemi',col||'#7ff4ff',.3*s,.22*s,.3*s,x,y+.48*s,z,0,0,0,true);}
function card2(art,h,p,sayT){card({art,h,p,say:sayT||p,btns:[['OK','green']]});}
const big=e=>`<div style="font-size:96px;line-height:1">${e}</div>`;

/* ================= Pawprint Village at night ================= */
function villageG(A){
  for(let i=0;i<12;i++){const a=i/12*PI*2+.26,x=Math.cos(a)*12.6,z=4+Math.sin(a)*12.6;if(Math.hypot(x+5.5,z-9)<2.5)continue;lantern(x,z,LC[i%5]);}
  starBoard(-9,-18);telescope(-12.8,-25.8);
  if(G().done)starParty();
  sayOnce('village',`Welcome to Night Glow! The village is dark without the fireflies. Look at the Star Map by the plaza: a star lights up for every pup you find.`);}
function starBoard(x,z){const y=gy(x,z);[-2.1,2.1].forEach(d=>I('box','#5a4030',.22,3.8,.22,x+d,y+1.9,z));I('box',NAVY,4.5,2.9,.2,x,y+2.7,z);I('box',GOLD,4.7,.16,.26,x,y+4.18,z);I('box',GOLD,4.7,.16,.26,x,y+1.22,z);
  const R=seed(91),n=Math.min(60,Math.round(GW.nFound()/119*60)),P=new Float32Array(Math.max(1,n)*3);for(let i=0;i<n;i++){P[i*3]=x-2+R()*4;P[i*3+1]=y+1.5+R()*2.4;P[i*3+2]=z+.13;}
  if(n){const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({color:GOLD,size:.28,map:GW.glowTex(),transparent:true,depthWrite:false,blending:THREE.AdditiveBlending});W.ag.add(new THREE.Points(g,m));W.disp.push(g,m);}
  const l=label('🗺️ Star Map',4.5,'#fffdf5');l.position.set(x,y+5,z);W.ag.add(l);rect(x-2.4,z-.3,x+2.4,z+.3);
  W.things.push({x,z:z+2.2,r:3.6,icon:'🗺️',label:'Star Map',act:()=>GW.starMap()});}
function telescope(x,z){const y=gy(x,z);[0,2.1,4.2].forEach(a=>{const l=I('cyl','#6a4a2a',.07,2.2,.07,x+Math.cos(a)*.5,y+1,z+Math.sin(a)*.5);});
  I('cyl','#3a4a8a',.32,2.6,.32,x+.5,y+2.6,z-.3,0,0,-.9);I('cyl',GOLD,.36,.14,.36,x+1.5,y+3.3,z-.3,0,0,-.9);I('cyl','#26232e',.14,.4,.14,x-.5,y+1.95,z-.3,0,0,-.9);
  col(x,z,.8);const l=label('🔭 Telescope',4.2,'#fffdf5');l.position.set(x,y+4.6,z);W.ag.add(l);
  W.things.push({x:x+1.4,z:z+1.6,r:3.4,icon:'🔭',label:'Telescope',act:scope});}
const EYE=(inner)=>`<svg viewBox="0 0 220 220" width="230"><circle cx="110" cy="110" r="104" fill="#060a20" stroke="#26232e" stroke-width="8"/>${inner}<circle cx="110" cy="110" r="104" fill="none" stroke="#3a4a8a" stroke-width="10"/></svg>`;
const VIEWS=[
 [EYE(`<circle cx="110" cy="110" r="70" fill="#d8d4c4"/>${[[85,85,14],[130,95,9],[105,140,18],[140,135,7],[75,125,8]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="${q[2]}" fill="#b8b2a0"/><circle cx="${q[0]-2}" cy="${q[1]-2}" r="${q[2]*.7}" fill="#c8c2b0"/>`).join('')}`),'The Moon','The Moon is covered in craters, made by space rocks crashing into it long, long ago.'],
 [EYE(`<ellipse cx="110" cy="110" rx="92" ry="22" fill="none" stroke="#e8d8a8" stroke-width="10" transform="rotate(-18 110 110)"/><circle cx="110" cy="110" r="40" fill="#e8c88a"/><path d="M74 100 H146 M72 116 H148" stroke="#c8a868" stroke-width="5"/><path d="M28 132 Q110 100 192 88" stroke="#e8d8a8" stroke-width="10" fill="none" transform="rotate(0 110 110)"/>`),'Saturn','Saturn\'s rings are made of billions of chunks of ice and rock. Saturn is so light for its size, it would float in a giant bath!'],
 [EYE(`<circle cx="110" cy="110" r="38" fill="#e8c8a0"/><path d="M74 98 H146 M72 112 H148 M76 124 H144" stroke="#c88a5a" stroke-width="6"/><circle cx="124" cy="122" r="6" fill="#c8603a"/>${[30,58,166,192].map(x=>`<circle cx="${x}" cy="${110+(x%3)}" r="4" fill="#fff"/>`).join('')}`),'Jupiter and its moons','Jupiter is the biggest planet. Through a telescope you can see its four biggest moons, first spotted by Galileo more than 400 years ago.'],
 [EYE(`<ellipse cx="110" cy="110" rx="70" ry="52" fill="#ff7fb8" opacity=".35"/><ellipse cx="104" cy="104" rx="44" ry="34" fill="#a98bff" opacity=".45"/><ellipse cx="114" cy="112" rx="22" ry="16" fill="#7ff4ff" opacity=".5"/>${[[100,104],[112,110],[106,118],[118,100]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="2.6" fill="#fff"/>`).join('')}`),'A star nursery','This fuzzy glow is a star nursery: a huge cloud of gas and dust where new stars are being born.']];
function scope(){if(player.lock)return;sfx.chime();player.lock=true;let i=0;const show=()=>{const v=VIEWS[i];card({art:v[0],h:`🔭 ${v[1]}`,p:v[2],say:`${v[1]}! ${v[2]}`,btns:i<VIEWS.length-1?[['Look at the next one ▶','green',()=>{i++;show();}],['Done','white',()=>{player.lock=false;}]]:[['Done','green',()=>{player.lock=false;const a=acts();if(!a.scope){a.scope=1;save();}}]]});};show();}
function starParty(){[[6,15,'#e8423a'],[-5,16,'#5b8def'],[11,9,'#3fae5a'],[-10,10,'#ffb347']].forEach(q=>{const y=gy(q[0],q[1]);I('box',q[2],3,.06,2.2,q[0],y+.04,q[1]);I('box','#ffffff',3,.07,.3,q[0],y+.05,q[1]-.6);});}

/* ================= the islands at night ================= */
const ISL={};
/* Meadow: moonflowers by the pond, glow-worms in the grass */
ISL.pond=A=>{const p=near(A,(A.start||[0,0])[0]+5,(A.start||[0,0])[1]-8,2),P=[];for(let i=0;i<6;i++){const a=i*1.05,x=p[0]+Math.cos(a)*1.6,z=p[1]+Math.sin(a)*1.6,y=gy(x,z);I('cyl','#3a7a44',.05,.9,.05,x,y+.45,z);P.push([x,y+.95,z]);}
  const flw=P.map(q=>{const m=mk('sph','#ffffff',.3,.08,.3,q[0],q[1],q[2],null,true);m.scale.set(.08,.04,.08);W.ag.add(m);return m;});
  W.things.push({x:p[0],z:p[1]+2.4,r:3.6,icon:'🌸',label:'Moonflowers',act:()=>{if(player.lock)return;sfx.chime();GW.snd.twinkle();let t=0;W.ticks.push(dt=>{t+=dt;const k=Math.min(1,t/1.4);flw.forEach((m,i)=>m.scale.set(.08+.24*k,.04+.04*k,.08+.24*k));return t>1.4;});
    const a=acts();if(!a.moonflower){a.moonflower=1;save();state.stars+=5;hud();}
    setTimeout(()=>card2(big('🌸🌙'),'The moonflowers open!','Some flowers open in the evening and glow pale in the moonlight. Moths fly to them in the dark to drink their nectar.'),900);}});};
ISL.windmill=A=>{for(let i=0;i<6;i++){const p=near(A,(A.start||[0,0])[0]+Math.cos(i)*9,(A.start||[0,0])[1]-6+Math.sin(i)*9,1);shroom(p[0],p[1],.6,LIME);}};
/* Snowy Summit: the Northern Lights */
let AURT=null;function auroraTex(){if(AURT)return AURT;const c=document.createElement('canvas');c.width=256;c.height=128;const x=c.getContext('2d');
  for(let i=0;i<40;i++){const px=i*6.4+Math.random()*4,g=x.createLinearGradient(0,0,0,128);g.addColorStop(0,'rgba(169,139,255,0)');g.addColorStop(.35,'rgba(169,139,255,.45)');g.addColorStop(.6,'rgba(92,255,176,.8)');g.addColorStop(1,'rgba(92,255,176,0)');x.fillStyle=g;x.fillRect(px,10+Math.random()*20,4,98);}
  AURT=new THREE.CanvasTexture(c);return AURT;}
function aurora(A,boost){const L=[];[[-60,-180,240],[90,-200,200],[-150,-120,160]].forEach((q,i)=>{const m=new THREE.MeshBasicMaterial({map:auroraTex(),transparent:true,opacity:.55,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide,fog:false}),pl=new THREE.Mesh(G.plane,m);
    pl.scale.set(q[2],70,1);pl.position.set(q[0],95+i*12,q[1]);pl.lookAt(0,95,0);W.ag.add(pl);W.disp.push(m);L.push({pl,m,i});});
  const o={L,boost:boost||0};W.ticks.push(dt=>{if(W.area!==A)return true;o.boost=Math.max(0,o.boost-dt*.08);o.L.forEach(q=>{q.m.opacity=.4+.2*Math.sin(W.t*.6+q.i*2)+o.boost;q.pl.position.x+=Math.sin(W.t*.3+q.i)*dt*2;});});return o;}
['lift','hut','green','blue','red','eagle'].forEach(id=>{ISL[id]=A=>{const o=aurora(A);if(id!=='eagle')return;const p=near(A,(A.start||[0,0])[0],(A.start||[0,0])[1]-7,2);
  W.things.push({x:p[0],z:p[1],r:3.8,icon:'🌌',label:'Northern Lights',act:()=>{if(player.lock)return;o.boost=.7;GW.snd.twinkle();const a=acts();if(!a.aurora){a.aurora=1;state.stars+=5;save();hud();}
    card2(big('🌌'),'The Northern Lights!','Tiny bits blown from the Sun crash into the air high above the Earth and make it glow, green and purple. In Finnish they are called fox fires!');}});};});
/* Coral Reef: the Glowing Bay */
function plankton(A){const n=60,P=new Float32Array(n*3),age=new Float32Array(n).fill(9),g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));
  const m=new THREE.PointsMaterial({color:'#7ff4ff',size:.3,map:GW.glowTex(),transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}),pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);
  let k=0,lx=player.x,lz=player.z;W.ticks.push(dt=>{if(W.area!==A)return true;const mv=Math.hypot(player.x-lx,player.z-lz);lx=player.x;lz=player.z;
    if(mv>.01)for(let s=0;s<3;s++){const i=k++%n;age[i]=0;P[i*3]=player.x+(Math.random()-.5)*1.6;P[i*3+1]=(player.y||walkY(player.x,player.z))+.5+Math.random()*1.4;P[i*3+2]=player.z+(Math.random()-.5)*1.6;}
    for(let i=0;i<n;i++){age[i]+=dt;if(age[i]>2.2)P[i*3+1]=-999;}g.attributes.position.needsUpdate=true;m.opacity=.9;});}
function jelly(x,y,z,col){const g=grp();mk('hemi',col,.7,.5,.7,0,0,0,g,true);for(let i=0;i<5;i++){const a=i/5*PI*2;mk('cyl',col,.03,.9,.03,Math.cos(a)*.35,-.45,Math.sin(a)*.35,g,true);}g.position.set(x,y,z);W.ag.add(g);return g;}
ISL.lagoon=A=>{plankton(A);const J=[];const s=A.start||[0,30];for(let i=0;i<6;i++){const a=i*1.1,x=s[0]+Math.cos(a)*(10+i*3),z=s[1]-14+Math.sin(a)*8;J.push(jelly(x,gy(x,z)+3+(i%3),z,['#ff7fe0','#7ff4ff','#c8ff4a'][i%3]));}
  W.ticks.push(()=>{if(W.area!==A)return true;J.forEach((g,i)=>{g.position.y+=Math.sin(W.t*1.2+i)*.004;g.scale.y=1+Math.sin(W.t*2+i)*.08;});});
  const p=near(A,s[0]+4,s[1]-6,2);W.things.push({x:p[0],z:p[1],r:4,icon:'💙',label:'Glow Swim',act:()=>startGlow('glowswim')});
  sayOnce('lagoon','The Glowing Bay! Tiny plankton glow when the water moves. Swim about and watch them sparkle!');};
['kelp','coral','ship','trench','palace','garden'].forEach(id=>{ISL[id]=A=>plankton(A);});
/* Ninja Mountains: the Lantern Festival */
ISL.dojo=A=>{for(let i=0;i<14;i++){const a=i/14*PI*2,p=near(A,Math.cos(a)*15,Math.sin(a)*15,1);lantern(p[0],p[1],LC[i%5],2.8);}
  const p=near(A,-1,-8,2);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🏮',label:'Lantern Festival',act:lanternFest});
  sayOnce('dojo','The Lantern Festival is tonight! Talk to the lanterns sign to help Sensei Mochi light them.');};
['bamboo','peak','thunder'].forEach(id=>{ISL[id]=A=>{for(let i=0;i<8;i++){const a=i/8*PI*2,p=near(A,Math.cos(a)*12,Math.sin(a)*12,1);lantern(p[0],p[1],LC[i%5],2.6);}};});
let LF=null;
function lanternFest(){if(player.lock||W.act||LF)return;const A=W.area,first=!(state.acts||{}).lanterns,tb=typeof tablesOn==='function'?tablesOn():[2];
  const step=first?1:pick([2,5,10].concat(tb||[])),n=8,L=[];sfx.chime();
  for(let i=0;i<n;i++){const a=i/n*PI*2+.4,p=near(A,player.x+Math.cos(a)*9,player.z+Math.sin(a)*9,1),g=grp(),y=gy(p[0],p[1]);mk('cyl','#3a3338',.06,2.6,.06,0,1.3,0,g);const lm=new THREE.MeshBasicMaterial({color:'#5a4a3a'}),b=new THREE.Mesh(G.sph,lm);b.scale.set(.42,.48,.42);b.position.set(0,2.9,0);g.add(b);
    g.position.set(p[0],y,p[1]);W.ag.add(g);W.disp.push(lm);const l=label(String((i+1)*step),2.4,'#fffdf5');l.position.set(p[0],y+4.1,p[1]);W.ag.add(l);L.push({g,b,lm,l,x:p[0],z:p[1],n:(i+1)*step,on:false});}
  LF={L,i:0,t0:W.t,step,A};say(`Sensei Mochi says: "Light the lanterns in order: ${step}, ${2*step}, ${3*step}... Walk to each one and tap it!"`);
  L.forEach(q=>{q.th={x:q.x,z:q.z,r:3,icon:'🔥',label:'Light '+q.n,show:()=>LF&&!q.on,act:()=>lightOne(q)};W.things.push(q.th);});}
function lightOne(q){if(!LF)return;const nx=LF.L[LF.i];if(q!==nx){sfx.oops();say(`Find lantern ${nx.n} first!`);return;}
  q.on=true;q.lm.color.set(LC[LF.i%5]);sfx.chime();GW.snd.note(LF.i);LF.i++;if(LF.i<LF.L.length){say(`${q.n}! Next: ${LF.L[LF.i].n}`);return;}
  const F=LF,secs=W.t-F.t0;LF=null;say('Every lantern is lit! Watch them float up into the sky!');confetti(40);let t=0;
  W.ticks.push(dt=>{t+=dt;F.L.forEach((q,i)=>{q.g.position.y+=dt*(1.6+i*.15);q.l.position.y+=dt*(1.6+i*.15);});if(t>4.5||W.area!==F.A){F.L.forEach(q=>{W.ag.remove(q.g);W.ag.remove(q.l);});W.things=W.things.filter(th=>!F.L.some(q=>q.th===th));
    if(t>4.5)finishAct('lanterns',secs,big('🏮'),'Every lantern is lit! What a beautiful Lantern Festival!',()=>lanternFest());return true;}});}
/* Number Kingdom: the Moon Clock */
function moonSVG(p,s){s=s||60;const r=s*.42,c=s/2,k=Math.cos(p*2*PI),wax=p<.5,rx=Math.max(.01,Math.abs(k)*r);
  const lit=`M${c} ${c-r} A${r} ${r} 0 0 ${wax?1:0} ${c} ${c+r} A${rx} ${r} 0 0 ${(wax?k>0:k<0)?0:1} ${c} ${c-r} Z`;
  return `<svg viewBox="0 0 ${s} ${s}" width="${s}" height="${s}"><circle cx="${c}" cy="${c}" r="${r}" fill="#2a3060" stroke="#26232e" stroke-width="2"/><path d="${lit}" fill="#f6f0d0"/></svg>`;}
const PH=[[0,'New moon',0],[.125,'Crescent',4],[.25,'First quarter (half)',7],[.375,'Gibbous',11],[.5,'Full moon',15],[.625,'Gibbous',18],[.75,'Last quarter (half)',22],[.875,'Crescent',26]];
function moonClock(){if(player.lock)return;sfx.chime();const ph=GW.phase(),near8=Math.round(ph*8)%8;
  card({h:'🌙 The Moon Clock',p:`The Moon takes about 29 and a half days to go through its shapes. Tap the moons in order!<div class="gmc">${PH.map((q,i)=>`<button class="gmcb${i===near8?' now':''}" data-i="${i}">${moonSVG(q[0],64)}<small>Day ${q[2]}</small></button>`).join('')}</div><div id="gmcMsg">Tonight's Moon is ringed in gold.</div>`,
    say:'The Moon Clock! The Sun always lights half of the Moon. As the Moon goes round the Earth, we see more or less of its sunny side. Tap the moons in order!',btns:[['OK','green',()=>{const a=acts();if(!a.moonclock){a.moonclock=1;state.stars+=5;save();hud();}}]]});
  document.querySelectorAll('#celeCard .gmcb').forEach(b=>tap(b,()=>{const q=PH[+b.dataset.i];sfx.boop();const m=`${q[1]}, about day ${q[2]}.`;$('#gmcMsg').textContent=m;speak(m);}));}
ISL.ntown=A=>{W.things.push({x:3.5,z:-1.5,r:3.6,icon:'🌙',label:'Moon Clock',act:moonClock});};
/* Gadget Island: Tinker's light show in the Light Lab */
function neon(pts,col){const m=new THREE.MeshBasicMaterial({color:'#3a3a48'}),im=new THREE.InstancedMesh(G.sph,m,pts.length),M4=new THREE.Matrix4();pts.forEach((p,i)=>{M4.makeScale(.22,.22,.22);M4.setPosition(p[0],p[1],p[2]);im.setMatrixAt(i,M4);});im.frustumCulled=false;W.ag.add(im);W.disp.push(m);return {m,col};}
ISL.lightlab=A=>{const s=A.start||[0,0],c=near(A,s[0],s[1]-12,3),R=[];for(let k=0;k<4;k++){const pts=[];for(let i=0;i<18;i++){const a=i/18*PI*2;pts.push([c[0]+Math.cos(a)*(3+k*1.6),gy(c[0],c[1])+6+k*1.2,c[1]+Math.sin(a)*(3+k*1.6)]);}R.push(neon(pts,['#ff7fe0','#5cf0ff','#c8ff4a','#ffd23f'][k]));}
  const lit=()=>R.forEach(r=>r.m.color.set(r.col));if(acts().lightshow)lit();
  W.things.push({x:c[0],z:c[1]+2,r:4,icon:'💡',label:'Light show',act:()=>{if(player.lock)return;player.lock=true;R.forEach(r=>r.m.color.set('#3a3a48'));let k=0;const nxt=()=>{if(k<R.length){R[k].m.color.set(R[k].col);GW.snd.note(k*2);k++;setTimeout(nxt,550);return;}
    player.lock=false;confetti(30);const a=acts();if(!a.lightshow){a.lightshow=1;state.stars+=5;save();hud();}card2(big('💡🤖'),'Tinker\'s light show!','LED lights use much less electricity than old bulbs. Tinker switched on the rings one at a time: pink, blue, green and gold!');};nxt();}});};
['workshop','robotyard','factory'].forEach(id=>{ISL[id]=A=>{const s=A.start||[0,0];for(let i=0;i<5;i++){const p=near(A,s[0]+Math.cos(i*1.3)*10,s[1]-8+Math.sin(i*1.3)*10,1);I('box',['#ff7fe0','#5cf0ff','#c8ff4a'][i%3],1.6,.12,.12,p[0],gy(p[0],p[1])+2.6,p[1],0,0,0,true);}};});
/* Rescue Bay: the lighthouse */
ISL.lighthouse=A=>{const x=0,z=-22,y=gy(x,z)+13.6,m=new THREE.MeshBasicMaterial({color:'#fff6b0',transparent:true,opacity:.22,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide}),b=new THREE.Mesh(G.cone,m);
  b.scale.set(3,40,3);b.rotation.z=PI/2;const g=grp();g.add(b);b.position.set(20,0,0);g.position.set(x,y,z);g.visible=!!acts().light;W.ag.add(g);W.disp.push(m);W.ticks.push(dt=>{if(W.area!==A)return true;g.rotation.y+=dt*.7;});
  const l=mk('sph','#fff6b0',1.1,1.1,1.1,x,y,z,null,true);l.visible=g.visible;W.ag.add(l);
  W.things.push({x:x+4,z:z+5,r:4,icon:'💡',label:'Lighthouse',act:()=>{if(player.lock)return;if(acts().light){say('Every lighthouse flashes its own pattern, so sailors know which one they are looking at, just like fireflies!');return;}
    player.lock=true;let n=10;const tick=()=>{say(String(n));sfx.boop();if(n>1){n--;setTimeout(tick,800);return;}setTimeout(()=>{g.visible=true;l.visible=true;GW.snd.twinkle();confetti(40);player.lock=false;const a=acts();a.light=1;state.stars+=5;save();hud();
      card2(big('🗼✨'),'The lighthouse is shining!','Every lighthouse flashes its own pattern, so sailors can tell which lighthouse they are looking at. Fireflies do the same to find their friends!');},700);};
    say('Let\'s count down from 10 and switch on the lighthouse!');setTimeout(tick,1800);}});};
['harbour','townsq','firestation'].forEach(id=>{ISL[id]=A=>{const s=A.start||[0,0];for(let i=0;i<6;i++){const p=near(A,s[0]+Math.cos(i)*11,s[1]-8+Math.sin(i)*11,1);lantern(p[0],p[1],'#fff6b0',2.6);}};});
/* Dino Valley: glowing mushrooms and Dr Digby's ultraviolet torch */
ISL.fernforest=A=>{const s=A.start||[0,0];for(let i=0;i<16;i++){const p=near(A,s[0]+Math.cos(i*.9)*(6+i),s[1]-6+Math.sin(i*.9)*(6+i),1);shroom(p[0],p[1],.6+(i%3)*.3,['#7ff4ff','#c8ff4a','#ff7fe0'][i%3]);}};
ISL.swamp=ISL.fernforest;
ISL.digcamp=A=>{const P=[];for(let i=0;i<9;i++){const x=2+i*1.6,z=4+Math.sin(i*.8)*1.5;P.push([x,z]);}
  const m=new THREE.MeshBasicMaterial({color:'#c8ff4a',transparent:true,opacity:0,depthWrite:false,blending:THREE.AdditiveBlending}),F3=P.map(q=>{const f=new THREE.Mesh(G.disc||G.plane,m);f.scale.set(.6,.6,.6);f.rotation.x=-PI/2;f.position.set(q[0],walkY(q[0],q[1])+.06,q[1]);W.ag.add(f);return f;});W.disp.push(m);
  if(acts().uv)m.opacity=.75;
  W.things.push({x:-3.5,z:1,r:3.6,icon:'🔦',label:'UV torch',act:()=>{if(player.lock)return;GW.snd.twinkle();let t=0;W.ticks.push(dt=>{t+=dt;m.opacity=Math.min(.8,t*.6);return t>1.4;});
    const a=acts();if(!a.uv){a.uv=1;state.stars+=5;save();hud();}
    card2(big('🔦🦖'),'Glowing footprints!','Dr Digby\'s ultraviolet torch makes hidden fossil footprints glow! Some fossils glow under ultraviolet light, which helps scientists see tiny details.');}});};
/* Planet Hop: the Meteor Shower */
function meteors(A,every){const L=[];W.ticks.push(dt=>{if(W.area!==A)return true;if(Math.random()<dt/(every||1.6)){const m=new THREE.MeshBasicMaterial({color:'#fff6c2',transparent:true,opacity:.9,depthWrite:false,blending:THREE.AdditiveBlending,fog:false}),s=new THREE.Mesh(G.cyl,m);
    s.scale.set(.25,14,.25);const x=player.x-60+Math.random()*120,z=player.z-140+Math.random()*60,y=70+Math.random()*30;s.position.set(x,y,z);s.rotation.z=.9+Math.random()*.3;W.ag.add(s);L.push({s,m,t:0,vx:-38-Math.random()*20,vy:-24});}
    for(let i=L.length-1;i>=0;i--){const q=L[i];q.t+=dt;q.s.position.x+=q.vx*dt;q.s.position.y+=q.vy*dt;q.m.opacity=Math.max(0,.9-q.t*.9);if(q.t>1){W.ag.remove(q.s);q.m.dispose();L.splice(i,1);}}});}
ISL.moon=A=>{meteors(A,1.1);const s=A.start||[0,0],p=near(A,s[0]+4,s[1]-8,2);W.things.push({x:p[0],z:p[1],r:4,icon:'🌠',label:'Meteor shower',act:()=>startGlow('meteor')});
  sayOnce('moon','A meteor shower over Moon Base! Shooting stars are bits of space dust burning up. Find the meteor sign to catch some star dust!');};
['mars','europa','rings','station'].forEach(id=>{ISL[id]=A=>meteors(A,3.5);});
/* the Den: glow stars, a moon lamp and a telescope, after the finale */
ISL.den=A=>{if(!G().done)return;const R=seed(5);for(let i=0;i<26;i++){const x=-10+R()*20,z=-8+R()*14,y=5+R()*.6;I('sph',i%3?'#fff6c2':LIME,.14,.14,.14,x,y,z,0,0,0,true);I('cyl','#c8c8d0',.01,.6,.01,x,y+.32,z);}
  I('cyl','#8a8f99',.18,1.2,.18,9,.6,-8.5);I('sph','#f6f0d0',.7,.7,.7,9,1.6,-8.5,0,0,0,true);telescope(-9,-8);};

/* ================= the collect activities: Glow Swim and Meteor Catch ================= */
(function(){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d'),gr=g.createRadialGradient(64,64,4,64,64,60);gr.addColorStop(0,'#ffffff');gr.addColorStop(.3,'#7ff4ff');gr.addColorStop(1,'rgba(127,244,255,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);texC['🔹']=new THREE.CanvasTexture(c);})();
COLLECT.glowswim={k:'glowswim',area:'lagoon',icon:'🔹',size:1.5,items:[],start:[0,30,PI],thing:'glowing spark',art:'💙',
  intro:'Glow Swim in the Glowing Bay! Swim round the Lagoon and collect 8 glowing sparks of plankton.',title:'Every spark collected! The whole bay is glowing!'};
COLLECT.meteor={k:'meteor',area:'moon',icon:'🌟',size:1.7,h:3,items:[],start:null,thing:'bit of star dust',art:'🌠',
  intro:'Meteor Catch! Shooting stars are bits of space dust burning up high above. Catch 8 glowing bits of star dust!',title:'You caught all the star dust! Make a wish!'};
function prep(k){const C=COLLECT[k],A=W.area,s=A.start||[0,0],Gd=XM.grid(A,1),st=Gd.snap(s[0],s[1],1);if(st<0)return;const B=Gd.bfs(st),R=seed(Math.floor(Math.random()*9999)),out=[];
  for(let tries=0;tries<4000&&out.length<8;tries++){const kk=Math.floor(R()*Gd.N);if(Gd.clr[kk]<2||B.D[kk]>=1e9||B.D[kk]<8||B.D[kk]>55)continue;const p=Gd.xz(kk);if(out.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<7))continue;out.push(A.swim?[p[0],p[1],2.2]:[p[0],p[1]]);}
  C.items=out;}
function startGlow(k){if(player.lock||W.act)return;if(!W.area||W.area.id!==COLLECT[k].area)return;prep(k);if(COLLECT[k].items.length<4){say('Let\'s try that again in a moment!');return;}sfx.chime();startCollect(k);}
function gTravel(area,pos,start,msg){if(!GW.on()){state.season='glow';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='glow'&&S.hide)try{S.hide();}catch(e){}});}arcadeTravel(area,pos,start,msg);}
regAct('meteor',{name:'Meteor Catch',icon:'🌠',island:'planet',area:'moon',where:'Night Glow, on Moon Base',lockSay:'Find the meteor shower on Moon Base in Night Glow, and play it there first!',play:()=>gTravel('moon',null,()=>startGlow('meteor'),'The meteor shower is starting!')});
regAct('glowswim',{name:'Glow Swim',icon:'💙',island:'reef',area:'lagoon',where:'Night Glow, in the Lagoon',lockSay:'Find Glow Swim in the Lagoon in Night Glow, and play it there first!',play:()=>gTravel('lagoon',[0,30,PI],()=>startGlow('glowswim'),'The Glowing Bay!')});
regAct('lanterns',{name:'Lantern Light-up',icon:'🏮',island:'ninja',area:'dojo',where:'Night Glow, at the Dojo',lockSay:'Find the Lantern Festival at the Dojo in Night Glow, and play it there first!',play:()=>gTravel('dojo',null,()=>lanternFest(),'The Lantern Festival!')});

/* ================= the Lab: a night science quiz ================= */
const NQ=[['Why do stars twinkle?','The air above us is always moving, and it bends the starlight a tiny bit this way and that, so stars seem to twinkle.',['Moving air bends their light','They switch on and off','They are winking at us'],'Moving air bends their light'],
 ['How does a firefly make its light?','Fireflies mix a chemical called luciferin with oxygen inside their tails. Their light is cold light: it hardly makes any heat.',['By mixing chemicals in its tail','With a tiny battery','By eating light bulbs'],'By mixing chemicals in its tail'],
 ['Why does the Moon change shape?','The Sun always lights half of the Moon. As the Moon goes round the Earth, we see more or less of that sunny half.',['We see different amounts of its sunny side','Something takes bites out of it','Clouds cover parts of it'],'We see different amounts of its sunny side'],
 ['What is a shooting star?','Shooting stars are bits of space dust, many no bigger than a grain of sand, burning up as they zoom into the air.',['A bit of space dust burning up','A star falling down','A rocket'],'A bit of space dust burning up'],
 ['What makes the Northern Lights?','Tiny bits blown from the Sun crash into the air high above the Earth and make it glow.',['Bits from the Sun make the air glow','Giant torches','Moonlight on the snow'],'Bits from the Sun make the air glow'],
 ['How do owls see in the dark?','An owl\'s eyes are huge for the size of its head, so they catch lots of light. Owls can find food just by listening, too.',['Huge eyes that catch lots of light','Night-vision goggles','They glow in the dark'],'Huge eyes that catch lots of light']];
const nightBG=()=>`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="768" fill="#14204a"/>`+Array.from({length:60},(v,i)=>{const R=seed(i*13+1);return `<circle cx="${(R()*1024).toFixed(0)}" cy="${(R()*600).toFixed(0)}" r="${(1+R()*2.5).toFixed(1)}" fill="#fff" opacity="${(.4+R()*.6).toFixed(2)}"/>`;}).join('')+`<circle cx="860" cy="130" r="60" fill="#f6f0d0"/><circle cx="890" cy="110" r="56" fill="#14204a"/></svg>`;
QUIZ.night={k:'night',name:'Night Science',icon:'🌙',n:6,bg:nightBG,introMs:3400,intro:'Professor Fizz has a night-time science quiz! Stars, fireflies, the Moon and more. Let\'s find out!',
  make:i=>{const q=NQ[i%NQ.length],o=q[2].slice().sort(()=>Math.random()-.5);return {q:q[0],say:q[0]+' '+o.join(', or ')+'?',pic:'<div style="font-size:110px;line-height:1">🌙✨</div>',ans:q[3],opts:o,hintSay:q[1],after:`<div style="font-size:26px;font-weight:800;padding:10px">${q[1]}</div>`};},
  block:()=>'🌙',title:'Brilliant! You are a night science star!'};
if(typeof openLab==='function'){const base=openLab;openLab=function(){base.apply(this,arguments);if(!GW.on())return;setTimeout(()=>{if(document.querySelector('#lab .gwin'))return;const host=document.querySelector('#lab');if(!host)return;
  const b=el('button','btn green gwin','🌙 Night science');b.style.cssText='position:absolute;right:24px;bottom:24px;z-index:30;font-size:24px';tap(b,()=>{sfx.pop();startQuiz('lab','night');});host.appendChild(b);},50);};}

/* ================= music ================= */
const C1=s=>tuneRow(s);
TUNES.gtwinkle={step:.3,mw:'sine',mv:.5,mel:C1('C5 - C5 - G5 - G5 - A5 - A5 - G5 - - - F5 - F5 - E5 - E5 - D5 - D5 - C5 - - - G5 - G5 - F5 - F5 - E5 - E5 - D5 - - - G5 - G5 - F5 - F5 - E5 - E5 - D5 - - - C5 - C5 - G5 - G5 - A5 - A5 - G5 - - - F5 - F5 - E5 - E5 - D5 - D5 - C5 - - -'),
  bas:C1('C3 - - - - - - - F3 - - - C3 - - - F3 - - - C3 - - - G2 - - - C3 - - - C3 - - - F3 - - - C3 - - - G2 - - - C3 - - - F3 - - - C3 - - - G2 - - - C3 - - - - - - - F3 - - - C3 - - - F3 - - - C3 - - - G2 - - - C3 - - -'),hw:'sine',hv:.1};
TUNES.gmoon={step:.26,mw:'triangle',mv:.45,mel:C1('C5 - C5 - C5 - D5 - E5 - - - D5 - - - C5 - E5 - D5 - D5 - C5 - - - - - - - C5 - C5 - C5 - D5 - E5 - - - D5 - - - C5 - E5 - D5 - D5 - C5 - - - - - - - D5 - D5 - D5 - D5 - A4 - - - A4 - - - D5 - C5 - B4 - A4 - G4 - - - - - - - C5 - C5 - C5 - D5 - E5 - - - D5 - - - C5 - E5 - D5 - D5 - C5 - - - - - - -'),
  bas:C1('C3 - - - - - - - G2 - - - C3 - - - C3 - - - G2 - - - C3 - - - - - - - C3 - - - - - - - G2 - - - C3 - - - C3 - - - G2 - - - C3 - - - - - - - D3 - - - - - - - A2 - - - - - - - D3 - - - G2 - - - - - - - - - - - C3 - - - - - - - G2 - - - C3 - - - C3 - - - G2 - - - C3 - - - - - - -'),drm:'k...h...'};
TUNES.glull={step:.3,mw:'sine',mv:.5,mel:C1('E5 E5 G5 - - - E5 E5 G5 - - - E5 G5 C6 - B5 - A5 - A5 G5 - - D5 E5 F5 - D5 - D5 E5 F5 - - - D5 F5 B5 A5 G5 - B5 - C6 - - - - -'),
  bas:C1('C3 - - - - - C3 - - - - - C3 - - - - - F3 - - - - - G2 - - - - - G2 - - - - - G2 - - - - - C3 - - - - -'),hw:'sine',hv:.12};
const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;if(GW.on()&&typeof W!=='undefined'&&W&&W.area){if(W.area.id==='village')return G().done?'glull':'gtwinkle';}return _mk();};
const _ps=playStep;playStep=function(T,i,t){_ps(T,i,t);if(!GW.on()||!AC)return;if(i%4===0&&T!==TUNES.gmoon){try{const d=musF;tone(2093+(i%8)*120,t,.12,'sine',.025,d);}catch(e){}}};

/* ================= build hooks ================= */
window.GWORLD={build(A){if(A.id==='village')try{villageG(A);}catch(e){console.warn('glow village',e);}},
  after(A){GRD=null;if(LF&&LF.A!==A)LF=null;try{if(ISL[A.id]){ISL[A.id](A);flushTo(W.ag);}}catch(e){console.warn('glow island',A.id,e);}
    /* the real meteor-shower nights (the Perseids in August, the Geminids in December): extra shooting stars over the village */
    if(A.id==='village'){const d=new Date(),m=d.getMonth(),dd=d.getDate();if((m===7&&dd>=11&&dd<=13)||(m===11&&dd>=13&&dd<=15)){meteors(A,1.4);sayOnce('shower'+d.getFullYear()+m,'Tonight is a real meteor shower night! Look up: shooting stars are streaking over the village. Make a wish!',2600);}}
    if(A.id==='village'&&window.GSTORY&&GSTORY.villageAfter)try{GSTORY.villageAfter(A);}catch(e){}},
  lantern,telescope,scope,moonSVG,aurora,meteors,plankton,lanternFest,startGlow};
const css=document.createElement('style');css.textContent=`.gmc{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:10px 0}.gmcb{background:#1b2452;border:4px solid #26232e;border-radius:16px;padding:6px;display:flex;flex-direction:column;align-items:center;color:#fff;font-family:inherit}
.gmcb small{font-size:15px;font-weight:800}.gmcb.now{box-shadow:0 0 0 5px #ffd23f}#gmcMsg{min-height:34px;font-size:24px;font-weight:800}`;document.head.appendChild(css);
})();
