/* Number Kingdom refresh (25 Nov 2026; every recommendation chosen in claude/gadget-number-refresh.md):
   a floor colour for each gallery and a giant floor puzzle to walk on that reads out what Seb stands on (a hundred
   square in Number Town with a Hundred Hunt, a times grid in Times Table Towers, a number line by Skip-Count River,
   tessellating tiles in the Shape Garden, fraction circles in the Pizza Bakery, a royal carpet with Roman numerals in
   Number Castle), King Ten and Queen Hundred with Royal Riddles and the Number Knight certificate, a "How big is big?"
   exhibit and the googol ribbon round the castle, Miss Sums and her class of 8 on a school trip with Line Up!, ten
   number creatures (Countipillars, Spotbugs and Number Snails), a number fountain and a balance scale.
   Loaded after gadget2.js. */
(function(){
const PI=Math.PI;
const beep=(f,d,ty,v,dl)=>{try{if(fxOk())tone(f,AC.currentTime+(dl||0),d||.1,ty||'sine',v||.1);}catch(e){}};
const KEY=['0️⃣','1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
const BR=['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff','#ff9ecb'];
const FONT=w=>`900 ${w}px ui-rounded,"Arial Rounded MT Bold",system-ui,sans-serif`;
const inZ=(Z,x,z)=>Z.some(q=>q.r!=null?Math.hypot(x-q.x,z-q.z)<q.r:(x>q.x1&&x<q.x2&&z>q.z1&&z<q.z2));
const segZ=(a,b,w)=>{const Z=[],n=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/2);for(let i=0;i<=n;i++)Z.push({x:a[0]+(b[0]-a[0])*i/n,z:a[1]+(b[1]-a[1])*i/n,r:w});return Z;};
function clearZ(Z){for(const k in instMap){const o=instMap[k];o.m=o.m.filter(m=>{const e=m.elements;return !inZ(Z,e[12],e[14]);});}W.cols=W.cols.filter(c=>!inZ(Z,c.x,c.z));}
/* a canvas texture that is thrown away when Seb leaves the area */
function tex(w,h,draw){const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);t.anisotropy=4;W.disp.push(t);return t;}
function decal(t,x,z,w,d,ry,dy,cut){const m=new THREE.Mesh(G.plane,new THREE.MeshLambertMaterial(cut?{map:t,alphaTest:.5}:{map:t}));m.scale.set(w,1,d);m.rotation.y=ry||0;m.position.set(x,gy(x,z)+(dy||.06),z);W.ag.add(m);W.disp.push(m.material);return m;}
function txt(g,s,x,y,px,col,al){g.font=FONT(px);g.fillStyle=col||INK;g.textAlign=al||'center';g.textBaseline='middle';g.fillText(s,x,y);}
const DIG={};/* number bubbles for the fountain and the balance (kept between visits; small) */
function digTex(s,bg){const k=s+bg;if(DIG[k])return DIG[k];const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.fillStyle=bg;g.strokeStyle=INK;g.lineWidth=8;g.beginPath();g.arc(64,64,56,0,7);g.fill();g.stroke();
  txt(g,s,64,70,s.length>2?46:s.length>1?62:80,'#ffffff');g.lineWidth=4;g.strokeStyle=INK;g.strokeText(s,64,70);return DIG[k]=new THREE.CanvasTexture(c);}
function digSprite(s,bg,sz){const sp=new THREE.Sprite(new THREE.SpriteMaterial({map:digTex(s,bg),transparent:true,depthWrite:false}));sp.scale.set(sz||1,sz||1,1);W.disp.push(sp.material);return sp;}
const busy=()=>{const b=$('#bubble');return b&&b.classList.contains('on');};

/* ================= floors that read out what Seb stands on ================= */
let ZS=[],curCell=null,stay=0,spoke=false,HL=null,POP=null,popT=0;
function popSprite(){const c=document.createElement('canvas');c.width=512;c.height=128;const t=new THREE.CanvasTexture(c),m=new THREE.SpriteMaterial({map:t,transparent:true,depthWrite:false}),s=new THREE.Sprite(m);
  s.visible=false;W.ag.add(s);W.disp.push(t,m);
  return {s,set(str,bg){const g=c.getContext('2d');g.clearRect(0,0,512,128);g.font=FONT(70);const w=Math.min(500,Math.max(150,g.measureText(str).width+70));s.userData.w=w/512;
    g.fillStyle=bg||'#ffffff';g.strokeStyle=INK;g.lineWidth=9;rr(g,256-w/2+5,8,w-10,112,44);g.fill();g.stroke();let fs=70;while(g.measureText(str).width>w-40&&fs>30){fs-=4;g.font=FONT(fs);}txt(g,str,256,70,fs);t.needsUpdate=true;}};}
function hiMesh(){const t=tex(128,128,g=>{g.strokeStyle='#fff27a';g.lineWidth=14;g.strokeRect(7,7,114,114);g.strokeStyle='#ff8a3c';g.lineWidth=5;g.strokeRect(16,16,96,96);});
  const m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({map:t,transparent:true,depthWrite:false}));m.visible=false;W.ag.add(m);W.disp.push(m.material);return m;}
function floorZones(){if(!ZS.length)return;HL=hiMesh();POP=popSprite();curCell=null;
  W.ticks.push(dt=>{const P=player;let c=null;for(const Z of ZS){c=Z.cell(P.x,P.z);if(c){c.zone=Z.id;break;}}
    if(!c){if(curCell){curCell=null;HL.visible=false;POP.s.visible=false;}return;}
    if(!curCell||c.k!==curCell.k){curCell=c;stay=0;spoke=false;popT=0;
      if(c.w){HL.visible=true;HL.position.set(c.x,gy(c.x,c.z)+.1,c.z);HL.scale.set(c.w,1,c.d);HL.rotation.y=c.ry||0;}else HL.visible=false;
      POP.set(c.t,c.bg);POP.s.position.set(P.x,gy(c.x,c.z)+4.4,P.z);POP.s.visible=true;beep(c.f||600,.13,'triangle',.07);}
    stay+=dt;popT+=dt;const k=Math.min(1,popT/.15);POP.s.scale.set(5.2*k,1.3*k,1);POP.s.position.x+=(P.x-POP.s.position.x)*Math.min(1,dt*6);POP.s.position.z+=(P.z-POP.s.position.z)*Math.min(1,dt*6);
    if(!spoke&&stay>.5&&c.s){spoke=true;if(!busy()&&!HUNT)speak(c.s);}});}

/* ---- Number Town: the giant hundred square ---- */
const HQ={x0:-10,z0:-37,c:2};
function hundredSquare(){const {x0,z0,c}=HQ;
  const t=tex(1024,1024,(g)=>{const s=102.4;for(let j=0;j<10;j++)for(let i=0;i<10;i++){const n=j*10+i+1;g.fillStyle=i===9?shade(BR[j%7],-.08):BR[j%7];g.globalAlpha=i===9?1:.72;g.fillRect(i*s,j*s,s,s);g.globalAlpha=1;
      g.fillStyle='#ffffff';g.globalAlpha=.55;g.fillRect(i*s+8,j*s+8,s-16,s-16);g.globalAlpha=1;txt(g,String(n),i*s+s/2,j*s+s/2+4,n>99?40:48);}
    g.strokeStyle=INK;g.lineWidth=4;for(let k=0;k<=10;k++){g.beginPath();g.moveTo(k*s,0);g.lineTo(k*s,1024);g.stroke();g.beginPath();g.moveTo(0,k*s);g.lineTo(1024,k*s);g.stroke();}g.lineWidth=12;g.strokeRect(6,6,1012,1012);});
  decal(t,x0+10*c/2,z0+10*c/2,10*c,10*c);
  ZS.push({id:'h100',cell:(x,z)=>{const i=Math.floor((x-x0)/c),j=Math.floor((z-z0)/c);if(i<0||j<0||i>9||j>9)return null;const n=j*10+i+1;
    return {k:'h'+n,n,x:x0+i*c+c/2,z:z0+j*c+c/2,w:c,d:c,t:String(n),s:String(n),f:220+n*8};}});
  sign(-13,-22,'💯 Hundred Hunt',3,6.5);W.things.push({x:-12.5,z:-19.5,r:3.4,icon:'💯',label:'Hundred Hunt',show:()=>!HUNT,act:()=>{sfx.chime();startHunt('activity');}});}

/* the Hundred Hunt: six numbers to find by standing on them */
let HUNT=null,huntSign=null,huntStar=null;
function huntLabel(){if(huntSign)return huntSign;const c=document.createElement('canvas');c.width=1024;c.height=192;const t=new THREE.CanvasTexture(c),m=new THREE.SpriteMaterial({map:t,transparent:true,depthWrite:false}),s=new THREE.Sprite(m);
  s.scale.set(12,2.25,1);s.position.set(0,gy(0,-27)+8.5,-38);s.visible=false;W.ag.add(s);W.disp.push(t,m);
  huntSign={s,set(str){const g=c.getContext('2d');g.clearRect(0,0,1024,192);g.fillStyle='#fff27a';g.strokeStyle=INK;g.lineWidth=12;rr(g,10,10,1004,172,70);g.fill();g.stroke();let fs=96;g.font=FONT(fs);while(g.measureText(str).width>940&&fs>40){fs-=6;g.font=FONT(fs);}txt(g,str,512,100,fs);t.needsUpdate=true;}};return huntSign;}
function startHunt(mode){if(!W.area||W.area.id!=='ntown')return;hush();HUNT={mode,i:0,t0:performance.now(),tgt:null};huntLabel();huntNext();}
function huntNext(){const H=HUNT;if(!H)return;if(huntStar){huntStar.visible=false;}
  if(H.i>=6){const secs=(performance.now()-H.t0)/1000;HUNT=null;if(huntSign)huntSign.s.visible=false;finishAct('hhunt',secs,pupBox(buddyPup()),'Hundred Square Hunter!',()=>startHunt(H.mode),false,'You found all six numbers on the hundred square.');return;}
  const on=curCell&&curCell.zone==='h100'?curCell.n:0,R=(a,b)=>{let v;do{v=rint(a,b);}while(Math.abs(v-on)<3);return v;};let tgt,s,b;
  switch(H.i){case 0:tgt=R(11,99);s=`Can you find ${tgt}? Stand on it!`;b=`Find ${tgt}`;break;
    case 1:b=R(12,88);tgt=b+1;s=`Find the number that is one more than ${b}!`;b=`1 more than ${b}`;break;
    case 2:b=R(12,79);tgt=b+10;s=`Find the number that is ten more than ${b}! Ten more is one row down.`;b=`10 more than ${b}`;break;
    case 3:b=R(13,89);tgt=b-1;s=`Find the number that is one less than ${b}!`;b=`1 less than ${b}`;break;
    case 4:b=R(22,89);tgt=b-10;s=`Find the number that is ten less than ${b}! Ten less is one row up.`;b=`10 less than ${b}`;break;
    default:if(on===100){tgt=1;s='Last one! Find the smallest number on the hundred square!';b='The smallest number!';}else{tgt=100;s='Last one! Find the biggest number on the hundred square!';b='The biggest number!';}}
  if(tgt===on&&!H.retry){H.retry=1;return huntNext();}H.retry=0;
  H.tgt=tgt;H.ts=0;H.hinted=false;huntSign.set(`🔎 ${b}`);huntSign.s.visible=true;sfx.chime();say(`Hundred Hunt! ${s}`);}
function huntTick(dt){const H=HUNT;if(!H)return;if(!W.area||W.area.id!=='ntown'){HUNT=null;return;}if(H.tgt==null)return;H.ts+=dt;
  if(curCell&&curCell.zone==='h100'&&curCell.n===H.tgt&&stay>.25){const n=H.tgt;H.tgt=null;H.i++;state.stats.sums=(state.stats.sums||0)+1;sfx.jingle&&sfx.jingle();floatS('⭐',curCell.x,gy(0,0)+3,curCell.z,2,1.2);
    say(pick(['Yes!','Brilliant!','You found it!','Super!'])+` That is ${n}!`);setTimeout(()=>{if(HUNT===H)huntNext();},1700);return;}
  if(!H.hinted&&H.ts>14){H.hinted=true;const n=H.tgt,row=Math.floor((n-1)/10)*10+1,i=(n-1)%10,j=Math.floor((n-1)/10);
    if(!huntStar){huntStar=sprite('✨',1.8);W.ag.add(huntStar);}huntStar.visible=true;huntStar.position.set(HQ.x0+i*HQ.c+1,gy(0,0)+1.4,HQ.z0+j*HQ.c+1);
    say(`Here is a clue. ${n} is in the row that starts with ${row}. Look for the sparkle!`);}
  if(huntStar&&huntStar.visible)huntStar.scale.setScalar(1.5+Math.sin(W.t*6)*.3);}

/* ---- Times Table Towers: the times grid ---- */
const TG={x0:13.65,z0:-34.35,c:1.7};
function timesGrid(){const {x0,z0,c}=TG,n=11;
  const t=tex(1024,1024,g=>{const s=1024/n;for(let j=0;j<n;j++)for(let i=0;i<n;i++){const x=i*s,y=j*s,hd=!i||!j;
      g.fillStyle=hd?'#3d6fb8':i===j?'#ffd23f':['#dce9fb','#eaf2fd'][(i+j)%2];g.fillRect(x,y,s,s);
      const v=!i&&!j?'×':!i?j:!j?i:i*j;txt(g,String(v),x+s/2,y+s/2+3,hd?50:(i*j>99?32:40),hd?'#ffffff':INK);}
    g.strokeStyle=INK;g.lineWidth=3;for(let k=0;k<=n;k++){g.beginPath();g.moveTo(k*s,0);g.lineTo(k*s,1024);g.stroke();g.beginPath();g.moveTo(0,k*s);g.lineTo(1024,k*s);g.stroke();}g.lineWidth=12;g.strokeRect(6,6,1012,1012);});
  decal(t,x0+n*c/2,z0+n*c/2,n*c,n*c);
  ZS.push({id:'times',cell:(x,z)=>{const i=Math.floor((x-x0)/c),j=Math.floor((z-z0)/c);if(i<0||j<0||i>10||j>10)return null;const X=x0+i*c+c/2,Z=z0+j*c+c/2;
    if(!i&&!j)return {k:'t0',x:X,z:Z,w:c,d:c,t:'×',s:'Times!',f:500};
    if(!i||!j){const v=i||j;return {k:'th'+i+'_'+j,x:X,z:Z,w:c,d:c,t:`× ${v}`,s:`The ${v} times table.`,f:300+v*40,bg:'#cfe0f8'};}
    return {k:'t'+i+'_'+j,x:X,z:Z,w:c,d:c,t:`${j} × ${i} = ${i*j}`,s:`${j} times ${i} is ${i*j}.`,f:240+i*j*7,bg:i===j?'#fff27a':null};}});
  sign(12,-14.5,'✖️ Times grid',3,6);W.things.push({x:12,z:-17,r:3,icon:'✖️',label:'Times grid',act:()=>{sfx.chime();say('The times grid! Walk across it. Each square is a times table sum. The gold squares are square numbers, like 3 times 3 is 9.');}});}

/* ---- Skip-Count River: the number line ---- */
function numberLine(){const xs=-24,dx=2.4,z=-24,W2=50.4,D=8;
  const t=tex(2048,320,g=>{const px=2048/W2,cx=n=>(n*dx+1.2)*px,yT=(z-1.3-(z-D/2))/D*320,yB=(z+1.3-(z-D/2))/D*320;
    g.fillStyle='#e8f8f4';g.fillRect(0,yT-6,2048,yB-yT+12);
    for(let n=0;n<=20;n++){g.fillStyle=n%5===0?'#5fc4f0':'#ffffff';g.fillRect(cx(n)-px*1.1,yT,px*2.2,yB-yT);g.strokeStyle=INK;g.lineWidth=4;g.strokeRect(cx(n)-px*1.1,yT,px*2.2,yB-yT);txt(g,String(n),cx(n),(yT+yB)/2+3,56);}
    const arc=(a,b,up,col,lab)=>{const m=(cx(a)+cx(b))/2,r=(cx(b)-cx(a))/2,y0=up?yT-6:yB+6;g.strokeStyle=col;g.lineWidth=7;g.beginPath();g.ellipse(m,y0,r,up?yT*.75:(320-yB)*.75,0,up?PI:0,up?2*PI:PI);g.stroke();
      if(lab){txt(g,lab,m,up?y0-yT*.5:y0+(320-yB)*.5,26,col);}};
    for(let n=0;n<20;n+=2)arc(n,n+2,true,'#3d8fe0','+2');for(let n=0;n<20;n+=5)arc(n,n+5,false,'#ff8a3c','+5');});
  decal(t,0,z,W2,D,0,.06,true);
  ZS.push({id:'line',cell:(x,zz)=>{if(Math.abs(zz-z)>1.3)return null;const n=Math.round((x-xs)/dx);if(n<0||n>20||Math.abs(x-(xs+n*dx))>1.2)return null;return {k:'l'+n,x:xs+n*dx,z,w:2.2,d:2.6,t:String(n),s:String(n),f:300+n*32};}});
  sign(-27.6,-26.5,'📏 Number line',3,6);W.things.push({x:-27.2,z:-23.5,r:3,icon:'📏',label:'Number line',act:()=>{sfx.chime();say('A number line from 0 to 20! Walk along it and count. The blue jumps count in 2s, and the orange jumps count in 5s.');}});}

/* ---- Shape Garden: tessellating tiles ---- */
function tessFloor(){const cx=30,cz=-10,R=8,NM=['Triangles','Squares','Hexagons'],SAY=['Triangles! They fit together with no gaps.','Squares! They fit together with no gaps.','Hexagons! Bees build honeycombs from hexagons.'];
  const t=tex(1024,1024,g=>{const C=512,S=1024/(2*R),cols=[['#ff6b6b','#ffd23f'],['#7fc8f0','#8fe39a'],['#c9b6ff','#ff9ecb']];
    for(let k=0;k<3;k++){g.save();g.beginPath();g.moveTo(C,C);g.arc(C,C,R*S,-PI/2+k*2*PI/3,-PI/2+(k+1)*2*PI/3);g.closePath();g.clip();g.strokeStyle=INK;g.lineWidth=4;
      if(k===0){const a=70,h=a*.866;for(let r=-8;r<9;r++)for(let q=-10;q<11;q++){const x=C+q*a/2,y=C+r*h,up=(q+r)%2===0;g.beginPath();if(up){g.moveTo(x,y-h/2);g.lineTo(x+a/2,y+h/2);g.lineTo(x-a/2,y+h/2);}else{g.moveTo(x,y+h/2);g.lineTo(x+a/2,y-h/2);g.lineTo(x-a/2,y-h/2);}g.closePath();g.fillStyle=up?cols[0][0]:cols[0][1];g.fill();g.stroke();}}
      if(k===1){const a=64;for(let r=-9;r<9;r++)for(let q=-9;q<9;q++){g.fillStyle=cols[1][(q+r+40)%2];g.fillRect(C+q*a,C+r*a,a,a);g.strokeRect(C+q*a,C+r*a,a,a);}}
      if(k===2){const a=38,w=a*1.732;for(let r=-9;r<10;r++)for(let q=-9;q<10;q++){const x=C+q*w+(r&1?w/2:0),y=C+r*a*1.5;g.beginPath();for(let i=0;i<6;i++){const an=PI/6+i*PI/3;g.lineTo(x+Math.cos(an)*a,y+Math.sin(an)*a);}g.closePath();g.fillStyle=cols[2][(q+r*2+60)%2];g.fill();g.stroke();}}
      g.restore();}
    g.strokeStyle=INK;g.lineWidth=12;g.beginPath();g.arc(C,C,R*S-6,0,7);g.stroke();for(let k=0;k<3;k++){const a=-PI/2+k*2*PI/3;g.beginPath();g.moveTo(C,C);g.lineTo(C+Math.cos(a)*R*S,C+Math.sin(a)*R*S);g.stroke();}});
  decal(t,cx,cz,2*R,2*R,0,.06,true);
  ZS.push({id:'tess',cell:(x,z)=>{const dx=x-cx,dz=z-cz;if(Math.hypot(dx,dz)>R-.3)return null;let a=Math.atan2(dz,dx)+PI/2;a=(a%(2*PI)+2*PI)%(2*PI);const k=Math.min(2,Math.floor(a/(2*PI/3)));return {k:'s'+k,x,z,w:0,t:NM[k],s:SAY[k],f:[523,659,784][k]};}});
  sign(30,.6,'🔷 Tessellation',3,6.5);W.things.push({x:27,z:-.5,r:3,icon:'🔷',label:'Tessellation',act:()=>{sfx.chime();say('Tessellation means shapes that fit together with no gaps. Triangles, squares and hexagons all tessellate. Circles do not!');}});}

/* ---- Pizza Bakery: fraction circles ---- */
function fractionCircles(){const X=[-25,-18.5,-12,-5.5],z=26,r=2.8,N=[2,3,4,8],T=['½','⅓','¼','⅛'],S=['One half','One third','One quarter','One eighth'];
  const t=tex(1024,256,g=>{const sx=1024/27,ox=-28.5;X.forEach((x,k)=>{const cx=(x-ox)*sx,cy=128,rr2=r*sx,n=N[k];
    for(let i=0;i<n;i++){g.beginPath();g.moveTo(cx,cy);g.arc(cx,cy,rr2,-PI/2+i*2*PI/n,-PI/2+(i+1)*2*PI/n);g.closePath();g.fillStyle=i%2?'#ffd23f':'#ff9a4d';g.fill();g.strokeStyle=INK;g.lineWidth=5;g.stroke();
      const am=-PI/2+(i+.5)*2*PI/n;txt(g,T[k],cx+Math.cos(am)*rr2*.6,cy+Math.sin(am)*rr2*.6+2,n>4?24:40);}
    g.lineWidth=9;g.beginPath();g.arc(cx,cy,rr2-4,0,7);g.stroke();});});
  decal(t,-15,z,27,6.75,0,.06,true);
  ZS.push({id:'frac',cell:(x,zz)=>{for(let k=0;k<4;k++){const dx=x-X[k],dz=zz-z;if(Math.hypot(dx,dz)<r-.2){let a=Math.atan2(dz,dx)+PI/2;a=(a%(2*PI)+2*PI)%(2*PI);const i=Math.floor(a/(2*PI/N[k]));return {k:'f'+k+'_'+i,x:X[k],z,w:0,t:T[k],s:S[k],f:[392,494,587,784][k]};}}return null;}});
  sign(-30.5,24.5,'🍕 Fractions',3,5.5);W.things.push({x:-29.5,z:27.5,r:3,icon:'🍕',label:'Fractions',act:()=>{sfx.chime();say('Fraction circles! They are cut into halves, thirds, quarters and eighths. The more slices you cut, the smaller each slice gets.');}});}

/* ---- Number Castle: the royal carpet with Roman numerals ---- */
const ROM=['I','II','III','IV','V','VI','VII','VIII','IX','X'];
function royalCarpet(){const z1=26,z2=-17.5,L=z1-z2,zk=k=>24-k*4.3;
  const t=tex(128,1392,(g,w,h)=>{g.fillStyle='#b8282e';g.fillRect(0,0,w,h);g.fillStyle='#e0b84a';g.fillRect(0,0,12,h);g.fillRect(w-12,0,12,h);g.fillStyle='#7a1a1e';g.fillRect(14,0,4,h);g.fillRect(w-18,0,4,h);
    ROM.forEach((s,k)=>{const y=(zk(k)-z2)/L*h;g.fillStyle='#7a1a1e';g.beginPath();g.arc(w/2,y,46,0,7);g.fill();txt(g,s,w/2,y+3,s.length>3?30:s.length>2?38:48,'#ffd23f');});});
  decal(t,0,(z1+z2)/2,4,L,0,.08);
  const t2=tex(128,192,(g,w,h)=>{g.fillStyle='#b8282e';g.fillRect(0,0,w,h);g.fillStyle='#e0b84a';g.fillRect(0,0,12,h);g.fillRect(w-12,0,12,h);txt(g,'👑',w/2,h/2,64);});
  decal(t2,0,-24.4,4,4.2,0,.08);
  ZS.push({id:'rom',cell:(x,z)=>{if(Math.abs(x)>2)return null;for(let k=0;k<10;k++)if(Math.abs(z-zk(k))<1.4)return {k:'r'+k,x:0,z:zk(k),w:3.6,d:2.6,t:`${ROM[k]} = ${k+1}`,s:`Roman number ${k+1}.`,f:330+k*45,bg:'#fff0c0'};return null;}});}

/* ================= Number Town: the number fountain ================= */
function numberFountain(fx,fz){const y=gy(fx,fz);
  I('cyl','#e2dbcd',3.5,.9,3.5,fx,y+.45,fz);I('band','#c9a86a',3.5,3.5,3.5,fx,y+.92,fz,PI/2,0,0);I('cyl','#7fd3f0',3.15,.1,3.15,fx,y+.86,fz,0,0,0,true);
  I('cyl','#e2dbcd',.55,1.9,.55,fx,y+1.7,fz);I('cyl','#e2dbcd',1.2,.3,1.2,fx,y+2.7,fz);I('cyl','#7fd3f0',1.02,.06,1.02,fx,y+2.86,fz,0,0,0,true);I('cone','#bfeaff',.28,.9,.28,fx,y+3.3,fz,0,0,0,true);col(fx,fz,3.6);
  const lb=label('⛲ Number fountain',6);lb.position.set(fx,y+6.4,fz);W.ag.add(lb);
  const D=[...Array(6)].map((_,k)=>({sp:null,u:k/6,a:k*1.05,n:k}));D.forEach(d=>{d.sp=digSprite(String(d.n),BR[d.n%7],1);W.ag.add(d.sp);});
  let show=null;const setD=(d,n,big)=>{d.n=n;d.sp.material.map=digTex(String(n),BR[n%7]);d.sp.material.needsUpdate=true;d.big=big;};
  W.ticks.push(dt=>{if(!lb.parent)return true;
    if(show){show.t+=dt;if(show.t>.6&&show.i<10){show.t=0;show.i++;const d=D[show.i%6];setD(d,show.i,true);d.u=0;d.a=show.i*.63;beep(392*Math.pow(2,(show.i-1)/12*1.2),.18,'triangle',.12);}
      if(show.i>=10&&show.t>1.5){show=null;say('Ten! The number fountain counted to ten. Splash!');}}
    D.forEach((d,k)=>{d.u+=dt*(d.big?.55:.42);if(d.u>=1){d.u-=1;d.a+=2.2+Math.random();if(!show)setD(d,Math.floor(Math.random()*10),false);}
      const u=d.u,h=d.big?4.6:2.6,r=d.big?3:2.4,sx=fx,sy=y+3.4,ex=fx+Math.cos(d.a)*r,ez=fz+Math.sin(d.a)*r,ey=y+.95;
      d.sp.position.set(sx+(ex-sx)*u,sy+(ey-sy)*u+4*h*u*(1-u),fz+(ez-fz)*u);const s=(d.big?1.6:1.05)*(u<.1?u*10:u>.9?(1-u)*10:1);d.sp.scale.set(s,s,1);});});
  W.things.push({x:fx,z:fz+4.6,r:3.4,icon:'⛲',label:'Number fountain',act:()=>{if(show)return;sfx.chime();say('Watch the number fountain count to ten!');show={i:0,t:0};}});}

/* ================= Times Table Towers: the balance scale ================= */
function balanceScale(x,z){const y=gy(x,z),PY=5.6,L=4.5,MAXT=.123;
  I('cyl','#c9a86a',1.4,.3,1.4,x,y+.15,z);I('cyl','#8a8f99',.25,PY,.25,x,y+PY/2,z);I('sph','#ffd23f',.42,.42,.42,x,y+PY,z);col(x,z,.8);
  const lb=label('⚖️ Balance It!',6);lb.position.set(x,y+PY+2.4,z);W.ag.add(lb);
  const beam=grp();beam.position.set(x,y+PY,z);W.ag.add(beam);mk('box','#c9a86a',L*2+.6,.35,.35,0,0,0,beam);mk('cone','#ffd23f',.3,.7,.3,0,.5,0,beam);[-1,1].forEach(s=>mk('sph','#ffd23f',.25,.25,.25,s*L,0,0,beam));
  const pans=[-1,1].map(s=>{const p=grp();W.ag.add(p);mk('cyl','#e2dbcd',1.8,.16,1.8,0,0,0,p);mk('band','#c9a86a',1.8,1.8,1.8,0,.1,0,p).rotation.x=PI/2;mk('cyl','#8a8f99',.05,5,.05,0,2.5,0,p);
    const w=grp();p.add(w);p.userData.w=w;return p;});
  let tilt=0,P=null,onPan=0,said=false;
  const weight=(pan,n,i,c)=>{const g=grp();pan.userData.w.add(g);const k=pan.userData.w.children.length-1;g.position.set((k%2?.55:-.55)*(i?1:0),.5,0);mk('box',c,.9,.7,.9,0,0,0,g);const s=digSprite(String(n),c,1.05);s.position.set(0,.95,0);g.add(s);return g;};
  const fresh=()=>{pans.forEach(p=>{const w=p.userData.w;while(w.children.length)w.remove(w.children[0]);});const T=rint(6,20),a=rint(1,T-2);P={T,a,ans:T-a,done:false};weight(pans[0],T,0,'#3d8fe0');weight(pans[1],a,1,'#ff8a3c');};
  fresh();
  const ask=()=>{if(P.done)fresh();const o=opts(P.ans,[P.ans+1,P.ans-1,P.ans+2,P.ans-2],3);
    card({art:'<div style="font-size:110px;line-height:1">⚖️</div>',h:'Balance It!',p:`The left pan has <b>${P.T}</b>. The right pan has <b>${P.a}</b>.<br>Which weight makes the scale balance?`,say:`The left pan has ${P.T}. The right pan has ${P.a}. Which weight makes the scale balance?`,
      btns:o.map(v=>[`⚖️ ${v}`,'white',()=>answer(v)])});};
  const answer=v=>{if(v===P.ans){P.done=true;const g=weight(pans[1],v,2,'#3fae5a');g.position.y=3;g.userData.drop=1;state.stats.sums=(state.stats.sums||0)+1;save();sfx.chime();confetti(30);
      say(`Balanced! ${P.a} and ${v} make ${P.T}. Tap the scale for another one.`);}
    else{sfx.oops();P.wob=1.2;P.wv=v;say(`Not quite. ${P.a} and ${v} make ${P.a+v}, ${P.a+v>P.T?'too heavy':'too light'}. Try again!`);setTimeout(()=>{if(W.area&&W.area.id==='towers')ask();},2600);}};
  W.things.push({x,z:z+3.2,r:3.4,icon:'⚖️',label:'Balance It!',act:()=>{sfx.boop();ask();}});
  W.ticks.push(dt=>{if(!beam.parent)return true;const px=player.x,pz=player.z;let want;
    const dl=Math.hypot(px-(x-L),pz-z),dr=Math.hypot(px-(x+L),pz-z);onPan=dr<2.4?1:dl<2.4?-1:0;
    if(onPan){want=onPan*MAXT;if(!said&&(dr<1.6||dl<1.6)){said=true;say('Whoa! Seb is heavier than all the number weights! The scale tips right down.');}}
    else{const R2=P.a+(P.done?P.ans:0);want=P.wob>0?(Math.max(-MAXT,Math.min(MAXT,(P.a+P.wv-P.T)*.03))):Math.max(-MAXT,Math.min(MAXT,(R2-P.T)*.03));}
    if(P.wob>0)P.wob-=dt;tilt+=(want-tilt)*Math.min(1,dt*2.5);beam.rotation.z=-tilt;
    pans.forEach((p,i)=>{const s=i?1:-1,ey=PY-s*L*Math.sin(tilt);p.position.set(x+s*L*Math.cos(tilt),y+ey-5,z);p.userData.w.children.forEach(g=>{if(g.userData.drop){g.position.y=Math.max(.5,g.position.y-dt*6);if(g.position.y<=.5)g.userData.drop=0;}});});});}

/* ================= people: Seb's classmates and Miss Sums ================= */
function kid3D(c){if(!G.sphH){G.sphH=new THREE.SphereGeometry(1,18,12);G.sphM=new THREE.SphereGeometry(1,9,6);}if(!G.smile)G.smile=new THREE.TorusGeometry(1,.22,6,14,PI);
  const g=new THREE.Group(),skin=c.skin,hair=c.hair,gr=c.top,gd=shade(c.top,-.18),sh=c.legs,shoe=c.shoe||'#2f3e5c',lg=c.trousers?sh:skin,G2=(p,x,y,z)=>{const q=new THREE.Group();q.position.set(x,y,z);p.add(q);return q;};
  const pel=G2(g,0,0,0),tor=G2(pel,0,1.05,0),legs=[],knees=[],arms=[],elbows=[];
  [-1,1].forEach(s=>{const l=G2(pel,s*.2,1.05,0);mk('cyl',sh,.175,.34,.175,0,-.13,0,l);mk('cyl',lg,.125,.24,.125,0,-.36,0,l);
    const k=G2(l,0,-.5,0);mk('sphM',lg,.122,.12,.122,0,0,0,k);mk('cyl',lg,.115,.3,.115,0,-.16,0,k);if(!c.trousers)mk('cyl','#ffffff',.128,.11,.128,0,-.32,0,k);
    mk('sph',shoe,.155,.12,.25,0,-.4,.06,k);mk('sph','#f2f2f2',.168,.06,.28,0,-.47,.06,k);legs.push(l);knees.push(k);});
  mk('sph',sh,.41,.27,.32,0,.18,0,tor);if(c.skirt)mk('cone',c.skirt,.52,.55,.45,0,.12,0,tor);
  mk('sphH',gr,.43,.47,.335,0,.62,0,tor);mk('sph',gd,.385,.05,.33,0,.3,0,tor);mk('tor',gd,.19,.19,.22,0,1.02,0,tor).rotation.x=PI/2;mk('cyl',skin,.13,.22,.13,0,1.1,0,tor);
  if(c.adult){mk('box','#ffffff',.2,.26,.04,.14,.6,.34,tor);mk('box','#3d8fe0',.03,.42,.03,.08,.85,.32,tor).rotation.z=.3;}else mk('box',shade(c.top,.25),.44,.08,.34,0,.72,0,tor);
  [-1,1].forEach(s=>{const a=G2(tor,s*.48,.95,0);mk('sph',gr,.165,.17,.165,0,-.03,0,a);mk('cyl',gr,.14,.2,.14,0,-.13,0,a);mk('cyl',c.adult?gr:skin,.105,.2,.105,0,-.27,0,a);
    const e=G2(a,0,-.36,0);mk('sphM',skin,.1,.1,.1,0,0,0,e);mk('cyl',c.adult?gr:skin,.095,.24,.095,0,-.13,0,e);mk('sph',skin,.12,.135,.105,0,-.31,0,e);arms.push(a);elbows.push(e);});
  const h=G2(tor,0,1.68,0);mk('sphH',skin,.54,.52,.5,0,0,0,h);mk('sph',skin,.47,.34,.43,0,-.15,.05,h);[-1,1].forEach(s=>mk('sph',skin,.1,.13,.07,s*.53,-.05,0,h));
  mk('sphH',hair,.57,.52,.52,0,.07,-.08,h);mk('sph',hair,.44,.15,.2,0,.36,.3,h);const st=c.style;
  if(st==='long'){mk('sph',hair,.5,.72,.26,0,-.38,-.3,h);[-1,1].forEach(s=>mk('sph',hair,.15,.42,.18,s*.5,-.24,.02,h));}
  if(st==='bunches'||st==='puffs')[-1,1].forEach(s=>{mk('sph',hair,.25,.25,.25,s*.62,.12,-.12,h);if(st==='bunches')mk('sph','#ff6b9a',.09,.09,.09,s*.47,.14,-.1,h);});
  if(st==='curly')for(let i=0;i<8;i++){const a=i/8*PI*2;mk('sph',hair,.17,.17,.17,Math.cos(a)*.44,.4+Math.sin(a*2)*.04,Math.sin(a)*.32-.06,h);}
  if(st==='bun')mk('sph',hair,.27,.27,.27,0,.46,-.36,h);
  const eg=G2(h,0,-.02,0);[-1,1].forEach(s=>{mk('sph','#2e211c',.078,.098,.05,s*.19,0,.47,eg,true);mk('sph','#ffffff',.03,.03,.02,s*.19-.03,.04,.51,eg,true);});
  if(c.glasses)[-1,1].forEach(s=>mk('tor','#3a3338',.14,.14,.14,s*.19,-.01,.49,h,true));
  [-1,1].forEach(s=>mk('sph',shade(hair,-.1),.085,.028,.04,s*.19,.13,.48,h));mk('sph',shade(skin,-.12),.055,.042,.045,0,-.1,.51,h);[-1,1].forEach(s=>mk('sph','#ff8f8f',.085,.05,.03,s*.33,-.17,.4,h));
  const sm=G2(h,0,-.235,.47);mk('smile','#7a3b2e',.1,.09,.09,0,0,0,sm).rotation.z=PI;
  shadow(g,.8);g.userData={legs,knees,arms,elbows,head:h,eg,ph:Math.random()*6,ph0:Math.random()*6};bakeModel(g,'kid_'+c.n,1.6);g.scale.setScalar(c.adult?1.22:(c.s||1));return g;}
function kidPose(g,dt,mv,t,wave,look){const u=g.userData;u.ph+=dt*(mv?9:0);u.wk=(u.wk||0)+((mv?1:0)-(u.wk||0))*Math.min(1,dt*8);const w=u.ph,wk=u.wk;
  for(let i=0;i<2;i++){const sg=i?-1:1;u.legs[i].rotation.x=wk*sg*Math.sin(w)*.6;u.knees[i].rotation.x=.05+wk*(.15+Math.max(0,-sg*Math.cos(w))*.9);
    u.arms[i].rotation.x=-wk*sg*Math.sin(w)*.6+(1-wk)*Math.sin(t*1.6+i+u.ph0)*.03;u.arms[i].rotation.z=(i?1:-1)*.1;u.elbows[i].rotation.x=-.22-wk*.25;u.elbows[i].rotation.z=0;}
  if(wave){u.arms[1].rotation.x=-.1;u.arms[1].rotation.z=2.5;u.elbows[1].rotation.x=0;u.elbows[1].rotation.z=Math.sin(t*11)*.4;}
  u.head.rotation.y+=((look||0)-u.head.rotation.y)*Math.min(1,dt*4);u.head.rotation.z=(1-wk)*Math.sin(t*.9+u.ph0)*.04;
  u.bt=(u.bt==null?2+u.ph0:u.bt)-dt;let ey=1;if(u.bt<0){ey=.1;if(u.bt<-.13)u.bt=2+Math.random()*3.5;}u.eg.scale.y=ey;}
const KIDS=[
 {n:'Ava',skin:'#f2c8a0',hair:'#e0b040',top:'#e8423a',legs:'#3a4a6a',style:'bunches',s:.97},
 {n:'Leo',skin:'#8a5a3a',hair:'#26201c',top:'#3d8fe0',legs:'#5b4636',style:'short',s:1.02},
 {n:'Mia',skin:'#f0c0a0',hair:'#8a3a1a',top:'#ff9ecb',legs:'#8a5ad8',style:'long',skirt:'#8a5ad8',s:.95},
 {n:'Noah',skin:'#d9a070',hair:'#4a3020',top:'#ffd23f',legs:'#3a4a6a',style:'short',s:1},
 {n:'Zara',skin:'#6a4028',hair:'#1a1410',top:'#8a5ad8',legs:'#3a3338',style:'puffs',s:.98},
 {n:'Alfie',skin:'#f6d0b0',hair:'#c86a2a',top:'#ff8a3c',legs:'#3a4a6a',style:'curly',s:.96},
 {n:'Isla',skin:'#e8b890',hair:'#3a2416',top:'#3fc4b0',legs:'#5b4636',style:'long',s:1.01},
 {n:'Ravi',skin:'#b07a4c',hair:'#1a1410',top:'#6b7586',legs:'#3a3338',style:'short',s:1.03}];
const TEACHER={n:'Miss Sums',skin:'#e8b890',hair:'#6a3a20',top:'#7a4fd0',legs:'#3a3338',style:'bun',adult:1,glasses:1,trousers:1,shoe:'#5b2a1e'};
const CLASS_PATH=[[-15,15],[-16,4],[-16,-10],[-12,-15.2],[0,-15.2],[12,-15.2],[16,-10],[16,-2],[16,6],[9,15],[0,15.4],[-8,15.4]];
const STOPS=[{v:4,look:[0,-27],line:'Miss Sums says: look, class! A giant hundred square. Every number is ten more than the one above it! Leo says: 34, 44, 54. The tens go up!'},
  {v:7,look:[0,-6],line:'Miss Sums says: the clock tower has the numbers 1 to 12. There are 60 minutes in an hour. Noah says: I can tell the time!'},
  {v:10,look:[0,10],line:'Miss Sums says: the number fountain! The numbers jump out of the water. Mia says: I counted 6 jumps!'}];
function schoolTrip(){const V=CLASS_PATH,n=V.length,cum=[0];for(let i=0;i<n;i++){const a=V[i],b=V[(i+1)%n];cum.push(cum[i]+Math.hypot(b[0]-a[0],b[1]-a[1]));}const TOT=cum[n];
  const at=s=>{s=((s%TOT)+TOT)%TOT;let i=0;while(i<n-1&&s>cum[i+1])i++;const a=V[i],b=V[(i+1)%n],f=(s-cum[i])/(cum[i+1]-cum[i]);return [a[0]+(b[0]-a[0])*f,a[1]+(b[1]-a[1])*f,Math.atan2(b[0]-a[0],b[1]-a[1])];};
  const T=kid3D(TEACHER),K=KIDS.map(k=>kid3D(k)),all=[T].concat(K),cols=all.map(()=>({x:0,z:0,r:.45}));all.forEach(g=>W.ag.add(g));cols.forEach(c=>W.cols.push(c));
  let s=cum[1]+2,stop=null,stopT=0,lastLine=-99,hello=false,passed=new Set();const lb=label('👩‍🏫 Miss Sums',4.4);W.ag.add(lb);
  const th={x:0,z:0,r:3.4,icon:'💬',label:'Miss Sums',act:()=>{sfx.chime();
    card({art:`<div style="display:flex;justify-content:center;gap:4px">${KIDS.slice(0,4).map((k,i)=>`<div class="fitsvg" style="width:78px">${kidSVG(k,[3,7,1,9][i])}</div>`).join('')}</div>`,h:'Miss Sums and her class',
      p:'Hello Seb! We are on a school trip to Number Kingdom. Each of us holds a number card. Can you help us line up in the right order?',btns:[['🧒 Play Line Up!','green',()=>startLineUp('activity')],['Not now','white']]});}};W.things.push(th);
  const place=(t)=>{const sT=s;const P=player;
    all.forEach((g,k)=>{const q=at(sT-(k?1.15+k*1.45:0));g.position.set(q[0],gy(q[0],q[1]),q[1]);const st=stop?Math.atan2(stop.look[0]-q[0],stop.look[1]-q[1]):q[2];let d=st-g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));g.rotation.y+=d*Math.min(1,.12);
      cols[k].x=q[0];cols[k].z=q[1];const dp=Math.hypot(P.x-q[0],P.z-q[1]);let look=0;if(dp<7){let a=Math.atan2(P.x-q[0],P.z-q[1])-g.rotation.y;a=Math.atan2(Math.sin(a),Math.cos(a));look=Math.max(-.9,Math.min(.9,a));}
      kidPose(g,1/60,!stop&&!g.userData.wait,t,stop&&dp<5&&k%3===1,look);});};
  place(0);
  W.ticks.push(dt=>{if(!T.parent)return true;const t=W.t,P=player;
    if(stop){stopT-=dt;if(stopT<=0){stop=null;s+=.05;}}
    else{const q=at(s+dt*1.5),blocked=Math.hypot(P.x-q[0],P.z-q[1])<1.25;T.userData.wait=blocked;
      if(!blocked){const s0=s;s+=dt*1.5;STOPS.forEach(S0=>{const sv=cum[S0.v];const a=((s0%TOT)+TOT)%TOT,b=((s%TOT)+TOT)%TOT;if(a<sv&&b>=sv&&b>a){stop=S0;stopT=7.5;s=s0+(sv-a);
        if(Math.hypot(P.x-q[0],P.z-q[1])<12&&t-lastLine>16){lastLine=t;say(S0.line);}}});}}
    all.forEach((g,k)=>{g.userData.wait=T.userData.wait;});
    const sT=s;all.forEach((g,k)=>{const q=at(sT-(k?1.15+k*1.45:0));g.position.set(q[0],gy(q[0],q[1]),q[1]);const want=stop?Math.atan2(stop.look[0]-q[0],stop.look[1]-q[1]):q[2];let d=want-g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));g.rotation.y+=d*Math.min(1,dt*6);
      cols[k].x=q[0];cols[k].z=q[1];const dp=Math.hypot(P.x-q[0],P.z-q[1]);let look=0;if(dp<7){let a=Math.atan2(P.x-q[0],P.z-q[1])-g.rotation.y;a=Math.atan2(Math.sin(a),Math.cos(a));look=Math.max(-.9,Math.min(.9,a));}
      kidPose(g,dt,!stop&&!g.userData.wait,t,!!stop&&dp<5&&k%3===1,look);});
    th.x=T.position.x;th.z=T.position.z;lb.position.set(T.position.x,T.position.y+3.6,T.position.z);
    const dT=Math.hypot(P.x-T.position.x,P.z-T.position.z);if(!hello&&dT<6){hello=true;if(t-lastLine>6){lastLine=t;say("Hello Seb! I'm Miss Sums, and this is my class. Tap me to play Line Up!");}}});}

/* the classmates in 2D (from Seb's picture, without his cap), each holding a number card */
function kidSVG(c,num){let s=sebSVG(false);
  s=s.replace('<path d="M26 44 Q26 10 60 10 Q94 10 94 44 Z" fill="#3fae5a"/>',`<path d="M23 54 Q20 14 60 14 Q100 14 97 54 Q90 34 72 30 Q60 40 48 30 Q30 34 23 54Z" fill="${c.hair}"/>`)
   .replace('<path d="M22 44 Q60 34 98 44 Q104 54 60 50 Q16 54 22 44Z" fill="#2e8b47"/>','').replace('<circle cx="60" cy="26" r="9" fill="#fff"/>','')
   .replace(/<g fill="#2e8b47"><circle cx="60" cy="28" r="3.6"\/>.*?<\/g>/,'');
  s=s.split('#c9905f').join(c.skin).split('#3a2416').join(c.hair).split('#3fae5a').join(c.top).split('#2e8b47').join(shade(c.top,-.18)).split('#8a7355').join(c.skirt||c.legs);
  let back='',front='';
  if(c.style==='long')back=`<path d="M26 50 Q16 104 34 116 L86 116 Q104 104 94 50 Z" fill="${c.hair}" stroke="${INK}" stroke-width="3.5"/>`;
  if(c.style==='bunches'||c.style==='puffs')front=[22,98].map(x=>`<circle cx="${x}" cy="42" r="12" fill="${c.hair}" stroke="${INK}" stroke-width="3.5"/>`+(c.style==='bunches'?`<circle cx="${x+(x<60?7:-7)}" cy="46" r="4" fill="#ff6b9a"/>`:'')).join('');
  if(c.style==='curly')front=[30,42,54,66,78,90].map((x,i)=>`<circle cx="${x}" cy="${i%2?17:21}" r="9" fill="${c.hair}" stroke="${INK}" stroke-width="3"/>`).join('');
  s=s.replace('stroke-linecap="round">','stroke-linecap="round">'+back);
  if(num!=null)front+=`<g transform="translate(60 116)"><rect x="-32" y="-26" width="64" height="46" rx="9" fill="#fff" stroke="${INK}" stroke-width="4"/><text x="0" y="10" font-size="${num>99?24:34}" font-weight="900" text-anchor="middle" fill="${INK}" font-family="ui-rounded,Arial Rounded MT Bold,system-ui,sans-serif">${num}</text>
    <circle cx="-32" cy="2" r="7" fill="${c.skin}" stroke="${INK}" stroke-width="3"/><circle cx="32" cy="2" r="7" fill="${c.skin}" stroke="${INK}" stroke-width="3"/></g>`;
  return s.replace(/<\/svg>\s*$/,front+'</svg>');}

/* ================= Line Up! ================= */
(function(){const st=document.createElement('style');st.textContent=`
#lineup .btn.rnd{position:absolute;z-index:20}#lineup .pill{z-index:20}
#luBg{background:linear-gradient(#f6edd8 0,#f6edd8 50%,#e9d9a8 50%,#f2e3b6 100%)}
#luQ.hint{background:#fff7c2}
#luQ{position:absolute;left:110px;right:230px;top:12px;min-height:64px;display:flex;align-items:center;justify-content:center;text-align:center;font-size:36px;font-weight:800;background:#fff;border:5px solid #5b4636;border-radius:28px;padding:10px 16px;z-index:4;line-height:1.2}
#luLine{position:absolute;left:12px;right:12px;top:146px;height:236px;display:flex;justify-content:center;gap:8px;z-index:3}
.luSlot{width:118px;height:228px;border:5px dashed #c9a86a;border-radius:22px;display:flex;align-items:flex-end;justify-content:center;font-size:30px;font-weight:900;color:#c9a86a;position:relative}
.luSlot>span{position:absolute;top:6px;left:0;right:0;text-align:center}
#luKids{position:absolute;left:6px;right:6px;bottom:30px;height:300px;display:flex;justify-content:center;align-items:flex-end;gap:10px;z-index:5}
.luKid{width:122px;background:none;border:none;padding:0;position:relative}.luKid .fitsvg{width:118px}.luSlot .luKid{width:112px}.luSlot .luKid .fitsvg{width:108px}
.luKid.gone{visibility:hidden}.luSlot .luKid{animation:pop .35s ease-out}
.luKid.hint{filter:drop-shadow(0 0 12px #fff27a) drop-shadow(0 0 6px #ffb000)}`;document.head.appendChild(st);
  const host=$('#quiz')&&$('#quiz').parentNode;if(!host)return;const d=document.createElement('div');d.id='lineup';d.className='screen';
  d.innerHTML='<div class="bg" id="luBg"></div><button class="btn rnd white" id="luBack" style="left:14px;top:10px">◀</button><div class="pill" id="luInfo"></div><div id="luQ"></div><div id="luLine"></div><div id="luKids"></div>';host.insertBefore(d,$('#quiz'));
  tap('#luBack',()=>{if(!LU)return;sfx.boop();const m=LU.mode;LU=null;backToWorld(m==='activity'?'You can play Line Up! with Miss Sums any time.':null);});})();
let LU=null;
const LU_ROUNDS=[
 {say:'Put us in order. Smallest number first!',mk:()=>shuffle([...Array(20)].map((_,i)=>i+1)).slice(0,5),ord:1},
 {say:'Now count in 2s! Line us up: 2, 4, 6 and on.',mk:()=>[2,4,6,8,10,12],step:2},
 {say:'Smallest number first again. These numbers are bigger!',mk:()=>shuffle([...Array(90)].map((_,i)=>i+10)).slice(0,6),ord:1},
 {say:'Count in 5s! Line us up: 5, 10, 15 and on.',mk:()=>[5,10,15,20,25,30],step:5},
 {say:'Last one! Count in 10s.',mk:()=>[10,20,30,40,50,60,70],step:10}];
function startLineUp(mode){hush();joyReset&&joyReset();LU={mode,r:0,t0:performance.now()};show('lineup');luRound();}
function luRound(){const L=LU;if(!L)return;if(L.r>=LU_ROUNDS.length){const secs=(performance.now()-L.t0)/1000;LU=null;
    finishAct('lineup',secs,`<div style="display:flex;justify-content:center;gap:4px">${KIDS.slice(4,7).map((k,i)=>`<div class="fitsvg" style="width:84px">${kidSVG(k,[10,20,30][i])}</div>`).join('')}</div>`,'Everyone is lined up!',()=>startLineUp(L.mode),true,'Miss Sums says: thank you, Seb! You are a brilliant line leader.');return;}
  const R=LU_ROUNDS[L.r],nums=R.mk().sort((a,b)=>a-b),who=shuffle(KIDS.slice()).slice(0,nums.length),crowd=shuffle(nums.map((v,i)=>({v,k:who[i]})));L.nums=nums;L.next=0;L.wrong=0;L.R=R;
  $('#luInfo').textContent=`Round ${L.r+1} of ${LU_ROUNDS.length}`;luSay(R.say);
  $('#luLine').innerHTML=nums.map((_,i)=>`<div class="luSlot"><span>${i+1}</span></div>`).join('');
  const box=$('#luKids');box.innerHTML='';crowd.forEach(q=>{const b=document.createElement('button');b.className='luKid';b.dataset.v=q.v;b.innerHTML=`<div class="fitsvg">${kidSVG(q.k,q.v)}</div>`;tap(b,()=>luTap(b));box.appendChild(b);});
  }
function luSay(t,hint){const q=$('#luQ');q.textContent=t;q.classList.toggle('hint',!!hint);speak(t);}
function luTap(b){const L=LU;if(!L||b.classList.contains('gone'))return;const v=+b.dataset.v,want=L.nums[L.next];
  if(v===want){beep(330+L.next*70,.15,'triangle',.14);document.querySelectorAll('.luKid.hint').forEach(e=>e.classList.remove('hint'));
    $('#luQ').classList.remove('hint');$('#luQ').textContent=L.R.say;const slot=$('#luLine').children[L.next],cp=b.cloneNode(true);cp.disabled=true;slot.innerHTML='';slot.appendChild(cp);b.classList.add('gone');speak(String(v));L.next++;L.wrong=0;
    if(L.next>=L.nums.length){state.stats.sums=(state.stats.sums||0)+1;sfx.chime();document.querySelectorAll('#luLine .luKid').forEach((e,i)=>setTimeout(()=>anim(e,'t-jump',600),i*90));
      setTimeout(()=>{if(LU!==L)return;luSay(`Well done! ${L.nums.join(', ')}!`);setTimeout(()=>{if(LU!==L)return;L.r++;luRound();},2400);},500);}}
  else{sfx.oops();anim(b,'shake',400);L.wrong++;const last=L.next?L.nums[L.next-1]:null,R=L.R;
    luSay(R.step?(last==null?`We are counting in ${R.step}s. Who has ${R.step}?`:`We are counting in ${R.step}s. What comes after ${last}?`):(L.wrong>1?`Here is a clue. ${want} is the smallest number left.`:'Not yet! Look for the smallest number left.'),true);
    if(L.wrong>1){const h=[...document.querySelectorAll('#luKids .luKid')].find(e=>+e.dataset.v===want);if(h)h.classList.add('hint');}}}

/* ================= the ten number creatures ================= */
const CRE={
 1:{kind:'snail',area:'river',home:[-16,-36],c:'#ff9ecb',fact:"I'm 1! I'm the very first counting number. Any number times 1 stays the same!"},
 2:{kind:'bug',area:'ntown',home:[22,-8],c:'#e8423a',fact:"I'm 2! 2 is 1 and 1. 2 is the smallest even number."},
 3:{kind:'snail',area:'towers',home:[-28,-14],c:'#8fe39a',fact:"I'm 3! 3 is 2 and 1. A triangle has 3 sides."},
 4:{kind:'pill',area:'shapes',home:[-34,6],c:['#c9b6ff','#8a5ad8'],fact:"I'm 4! 4 is 2 and 2. A square has 4 sides."},
 5:{kind:'pill',area:'ntown',home:[-22,-4],c:['#8fe39a','#3fae5a'],fact:"I'm 5! You have 5 fingers on one hand. 5 is 3 and 2."},
 6:{kind:'bug',area:'river',home:[36,8],c:'#3d8fe0',fact:"I'm 6! 6 is 3 and 3. Double 3 is 6."},
 7:{kind:'pill',area:'bakery',home:[24,8],c:['#ffb347','#ff8a3c'],fact:"I'm 7! There are 7 days in a week. 7 is 4 and 3."},
 8:{kind:'bug',area:'towers',home:[-36,8],c:'#ffd23f',fact:"I'm 8! 8 is 4 and 4. A spider has 8 legs!"},
 9:{kind:'snail',area:'bakery',home:[-26,-10],c:'#7fc8f0',fact:"I'm 9! 9 is 3 lots of 3. 9 is also 5 and 4."},
 10:{kind:'pill',area:'castle',home:[-30,-6],c:['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff'],fact:"I'm 10! 10 is 5 and 5. Your two hands have 10 fingers!"}};
const KNAME={pill:'Countipillar',bug:'Spotbug',snail:'Number Snail'};
function eyes(par,x,y,z,s){[-1,1].forEach(q=>{mk('sph','#ffffff',.15*s,.18*s,.08*s,q*x,y,z,par,true);mk('sph','#26232e',.08*s,.1*s,.05*s,q*x,y-.02*s,z+.05*s,par,true);mk('sph','#ffffff',.03*s,.03*s,.02*s,q*x-.03*s,y+.03*s,z+.08*s,par,true);});}
function pill3D(n,cols){const g=grp(),parts=[];for(let i=0;i<n;i++){const s=grp();g.add(s);const c=cols[i%cols.length];mk('sph',c,.42,.42,.42,0,.42,0,s);mk('sph',shade(c,.3),.17,.08,.17,0,.8,.05,s);[-1,1].forEach(q=>mk('sph','#3a3338',.09,.09,.11,q*.24,.06,0,s));parts.push(s);}
  const h=grp();g.add(h);mk('sph',cols[0],.52,.5,.5,0,.56,0,h);const eg=grp();h.add(eg);eyes(eg,.18,.7,.4,1);mk('smile','#26232e',.12,.1,.1,0,.44,.46,h).rotation.z=PI;
  [-1,1].forEach(q=>{mk('sph','#ff8f8f',.08,.05,.03,q*.32,.5,.4,h);const a=mk('cyl','#3a3338',.03,.55,.03,q*.2,1.15,0,h);a.rotation.z=-q*.35;mk('sph',cols[cols.length-1],.11,.11,.11,q*.32,1.4,0,h);});
  bakeModel(g,'pill'+n+cols.join(''),1.5);return {g,parts,h,eg};}
function bug3D(n,c){const g=grp(),b=grp();g.add(b);mk('sph','#3a3338',.7,.22,.86,0,.2,0,b);mk('hemi',c,.76,.58,.92,0,.22,0,b);
  const parts=[],sp=[];const per=Math.floor(n/2),odd=n%2;for(let k=0;k<per;k++){const zz=per>1?.45-k*(.95/(per-1)):0;[-1,1].forEach(q=>sp.push([q*.36,zz]));}if(odd)sp.push([0,per>2?-.05:.5]);
  sp.forEach(p=>{const s=grp();b.add(s);const x=p[0],z=p[1],yy=.22+.58*Math.sqrt(Math.max(.02,1-(x/.76)**2-(z/.92)**2));s.position.set(x,yy,z);mk('sph','#26232e',.14,.07,.14,0,0,0,s);parts.push(s);});
  [-.42,0,.42].forEach(z=>[-1,1].forEach(q=>mk('sph','#26232e',.07,.07,.13,q*.66,.08,z,b)));
  const h=grp();b.add(h);h.position.set(0,.3,.86);mk('sph','#26232e',.36,.3,.3,0,0,0,h);const eg=grp();h.add(eg);eyes(eg,.15,.08,.24,.85);mk('smile','#ffffff',.08,.07,.07,0,-.1,.27,h).rotation.z=PI;
  [-1,1].forEach(q=>{const a=mk('cyl','#26232e',.025,.45,.025,q*.12,.38,.05,h);a.rotation.z=-q*.4;a.rotation.x=.3;mk('sph','#26232e',.07,.07,.07,q*.22,.58,.12,h);});
  bakeModel(g,'bug'+n+c,1.5);return {g,parts,h,eg,b};}
function snail3D(n,c){const g=grp(),b=grp();g.add(b);const skin='#e8d6a8';mk('sph',skin,.36,.26,1.0,0,.24,.15,b);
  const h=grp();b.add(h);h.position.set(0,.42,.95);mk('sph',skin,.3,.32,.3,0,.1,0,h);const eg=grp();h.add(eg);[-1,1].forEach(q=>{const st=mk('cyl',skin,.05,.5,.05,q*.12,.5,0,eg);st.rotation.z=-q*.2;mk('sph','#ffffff',.11,.11,.11,q*.17,.78,0,eg,true);mk('sph','#26232e',.06,.06,.05,q*.17,.78,.08,eg,true);});
  mk('smile','#7a4a2a',.1,.08,.08,0,.02,.28,h).rotation.z=PI;[-1,1].forEach(q=>mk('sph','#ff8f8f',.06,.04,.03,q*.18,.08,.26,h));
  const sh=grp();b.add(sh);sh.position.set(0,.88,-.15);mk('sph',c,.38,.64,.64,0,0,0,sh);[-1,1].forEach(q=>{mk('tor',shade(c,-.28),.42,.42,.42,q*.3,0,0,sh).rotation.y=PI/2;mk('tor',shade(c,-.28),.2,.2,.2,q*.36,.06,.04,sh).rotation.y=PI/2;});
  bakeModel(g,'snail'+n+c,1.5);return {g,parts:[sh],h,eg,b,sh};}
function creature(n){const C=CRE[n],[hx,hz]=C.home,M=C.kind==='pill'?pill3D(n,C.c):C.kind==='bug'?bug3D(n,C.c):snail3D(n,C.c);add(M.g,hx,hz);
  const lb=label(String(n),2.8,'#fff27a');W.ag.add(lb);const cl={x:hx,z:hz,r:.6};W.cols.push(cl);
  const rr2=C.kind==='snail'?2:2.6,v=C.kind==='snail'?.35:C.kind==='bug'?.7:.55;let th=Math.random()*6,count=null,ph=Math.random()*6,face=0;
  const pos=a=>[Math.cos(a)*rr2,Math.sin(a)*rr2];
  const thing={x:hx,z:hz,r:3.2,icon:C.kind==='pill'?'🐛':C.kind==='bug'?'🐞':'🐌',label:`${KNAME[C.kind]} ${n}`,show:()=>!count,act:()=>{sfx.chime();count={i:0,t:.2};}};W.things.push(thing);
  W.ticks.push(dt=>{if(!M.g.parent)return true;const P=player;ph+=dt;const hp=pos(th),wx=hx+hp[0],wz=hz+hp[1],dp=Math.hypot(P.x-wx,P.z-wz),still=dp<4||count;
    if(!still)th+=dt*v/rr2;const dir=Math.atan2(-Math.sin(th),Math.cos(th));let want=dir;if(still){want=Math.atan2(P.x-wx,P.z-wz);}
    if(C.kind==='pill'){M.h.position.set(hp[0],0,hp[1]);let d=want-face;d=Math.atan2(Math.sin(d),Math.cos(d));face+=d*Math.min(1,dt*5);M.h.rotation.y=face;
      M.parts.forEach((s,i)=>{const a=th-(i+1)*.78/rr2,q=pos(a),bump=count&&count.i===i+1?.5*Math.max(0,1-count.t*3):0;s.position.set(q[0],(still?0:Math.abs(Math.sin(ph*6-i*.8))*.1)+bump,q[1]);s.rotation.y=Math.atan2(-Math.sin(a),Math.cos(a));});}
    else{M.g.position.set(wx,gy(wx,wz),wz);let d=want-M.g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));M.g.rotation.y+=d*Math.min(1,dt*4);M.b.position.y=still?0:Math.abs(Math.sin(ph*(C.kind==='bug'?9:3)))*.05;
      if(C.kind==='bug')M.parts.forEach((s,i)=>{const on=count&&count.i>i;s.scale.setScalar(on?1.25+(count.i===i+1?Math.max(0,.6-count.t*2):0):1);});
      else{M.eg.rotation.z=Math.sin(ph*1.3)*.08;M.sh.rotation.x=count&&count.t<.3?Math.sin(count.t*30)*.15:0;}}
    if(C.kind!=='pill'){cl.x=wx;cl.z=wz;}else{cl.x=hx+hp[0];cl.z=hz+hp[1];}
    lb.position.set(cl.x,gy(cl.x,cl.z)+(C.kind==='snail'?2.3:2),cl.z);thing.x=cl.x;thing.z=cl.z;
    M.eg.scale.y=(ph%4<.12)?.15:1;
    if(count){count.t+=dt;if(count.t>.45&&count.i<n){count.t=0;count.i++;beep(330*Math.pow(2,(count.i-1)/12*1.5),.16,'triangle',.12);floatS(KEY[count.i],cl.x,gy(cl.x,cl.z)+2.8,cl.z,1.5,1.1);}
      if(count.i>=n&&count.t>.7){count=null;state.ncre=state.ncre||{};const first=!state.ncre[n];state.ncre[n]=1;if(first)save();const k=Object.keys(state.ncre).length;
        say(C.fact+(first?(k>=10?' You have met all 10 number creatures!':` You have met ${k} of the 10 number creatures.`):''));if(first&&k>=10){confetti(60);sfx.fanfare();}}}});}

/* ================= Number Castle: King Ten and Queen Hundred ================= */
function lion3D(o){const g=grp(),b=grp();g.add(b);const fur=o.fur,mane=o.mane,cream='#fff2d8';
  mk('cone',o.robe,1.15,2.2,1.0,0,1.95,0,b);mk('sph',o.robe,1.0,.5,.9,0,1.1,.1,b);mk('tor','#ffffff',.56,.56,.42,0,2.92,0,b).rotation.x=PI/2;
  for(let k=0;k<6;k++){const a=k/6*PI*2+.3;mk('sph','#26232e',.05,.07,.05,Math.cos(a)*.6,2.92,Math.sin(a)*.45,b);}
  [-1,1].forEach(s=>{mk('sph',fur,.28,.2,.42,s*.4,.14,1.0,b);mk('sph',o.robe,.3,.62,.3,s*.86,2.25,.3,b).rotation.x=.5;mk('sph',fur,.25,.22,.27,s*.62,1.62,.85,b);});
  if(o.queen)for(let k=0;k<5;k++){const a=(k-2)*.32;mk('sph','#ffffff',.08,.08,.08,Math.sin(a)*.55,2.72-Math.cos(a)*.08,.48+Math.cos(a)*.05,b);}
  const sc=grp();b.add(sc);sc.position.set(.62,1.62,.95);mk('cyl','#ffd23f',.06,1.9,.06,0,.75,0,sc);mk('sph',o.gem,.17,.17,.17,0,1.75,0,sc,true);if(!o.queen)mk('cone','#ffd23f',.14,.3,.14,0,2.0,0,sc);
  const h=grp();b.add(h);h.position.set(0,3.65,.2);const ms=o.queen?.86:1;
  mk('sph',mane,1.05*ms,1.0*ms,.72,0,0,-.15,h);for(let k=0;k<12;k++){const a=k/12*PI*2;mk('sph',mane,.33*ms,.33*ms,.3,Math.cos(a)*1.0*ms,Math.sin(a)*.96*ms,-.08,h);}
  mk('sph',fur,.72,.68,.62,0,-.05,.22,h);[-1,1].forEach(s=>{mk('sph',fur,.2,.2,.13,s*.56,.58,.12,h);mk('sph','#f2b8a0',.1,.12,.06,s*.56,.58,.2,h);
    mk('sph',cream,.25,.19,.21,s*.15,-.3,.72,h);mk('sph','#ff9f8f',.12,.07,.04,s*.42,-.16,.66,h);mk('sph',shade(mane,-.25),.12,.035,.04,s*.26,.32,.76,h).rotation.z=s*.2;});
  mk('sph',cream,.2,.14,.16,0,-.47,.64,h);mk('sph','#5a3a2a',.17,.11,.11,0,-.16,.84,h);mk('smile','#5a3a2a',.12,.1,.1,0,-.36,.8,h).rotation.z=PI;
  const eg=grp();h.add(eg);eg.position.set(0,.12,0);[-1,1].forEach(s=>{mk('sph','#ffffff',.14,.16,.06,s*.26,0,.74,eg,true);mk('sph','#2e211c',.09,.11,.05,s*.26,-.02,.79,eg,true);mk('sph','#ffffff',.03,.03,.02,s*.26-.03,.03,.83,eg,true);});
  if(o.queen)[-1,1].forEach(s=>[0,1,2].forEach(k=>mk('box','#2e211c',.02,.08,.02,s*(.33+k*.04),.18+k*.01,.78,eg).rotation.z=s*(.4+k*.3)));
  const cy=1.0;mk('cyl','#ffd23f',.55,.38,.55,0,cy,0,h);for(let k=0;k<5;k++){const a=k/5*PI*2+PI/2;mk('cone','#ffd23f',.13,.34,.13,Math.cos(a)*.5,cy+.35,Math.sin(a)*.5,h);mk('sph',['#e8423a','#3d8fe0','#3fae5a','#8a5ad8','#ff9ecb'][k],.06,.06,.06,Math.cos(a)*.5,cy+.54,Math.sin(a)*.5,h,true);}
  const nt=tex(256,128,(gg)=>{gg.fillStyle='#fff6c9';gg.strokeStyle='#b8860b';gg.lineWidth=10;rr(gg,8,8,240,112,30);gg.fill();gg.stroke();txt(gg,o.num,128,68,o.num.length>2?76:92,'#7a1a1e');});
  const np=new THREE.Mesh(new THREE.PlaneGeometry(.78,.39),new THREE.MeshBasicMaterial({map:nt,transparent:true}));np.position.set(0,cy,.57);h.add(np);W.disp.push(np.geometry,np.material);
  bakeModel(g,'lion'+(o.queen?'Q':'K'),2.5);return {g,b,h,eg};}
function throne(x,z,cc){const y=gy(x,z),gold='#d4a72c';I('box',gold,2.8,.95,2.4,x,y+.475,z);I('box',cc,2.5,.25,2.1,x,y+1.07,z+.05);I('box',gold,2.8,5.6,.45,x,y+2.8,z-1.1);I('box',cc,2.1,3.4,.1,x,y+3.2,z-.85);
  I('sph',gold,.55,.55,.25,x,y+5.75,z-1.1);[-1,1].forEach(s=>{I('box',gold,.35,1.0,2.2,x+s*1.4,y+1.45,z);I('sph',gold,.24,.24,.24,x+s*1.4,y+2.0,z+1.05);I('cone',gold,.18,.5,.18,x+s*1.25,y+5.85,z-1.1);});col(x,z,1.7);}
function royals(){const y=gy(0,-27.5);I('box','#7a2a2a',22,.24,5,0,y+.12,-27.6);I('box','#e0b84a',22.2,.06,5.2,0,y+.03,-27.6);
  throne(-6.5,-27.5,'#b8282e');throne(6.5,-27.5,'#7a4fd0');
  const K=lion3D({fur:'#e8b45a',mane:'#c8742a',robe:'#b8282e',gem:'#e8423a',num:'10'}),Q=lion3D({fur:'#f0c470',mane:'#e8a050',robe:'#7a4fd0',gem:'#ff9ecb',num:'100',queen:1});
  add(K.g,-6.5,-27.4,y+.2);add(Q.g,6.5,-27.4,y+.2);
  [[K,-6.5,'👑 King Ten'],[Q,6.5,'👑 Queen Hundred']].forEach(q=>{const l=label(q[2],5);l.position.set(q[1],y+7.6,-27.5);W.ag.add(l);});
  let hello=false;const knight=()=>!!(state.acts||{}).riddles;
  W.things.push({x:0,z:-24.2,r:4.6,icon:'👑',label:'King and Queen',act:()=>{sfx.fanfare();
    card({art:'<div style="font-size:84px;line-height:1">🦁👑🦁</div>',h:'King Ten and Queen Hundred',
      p:knight()?'Welcome back, Sir Seb the Number Knight! Would you like more Royal Riddles?':'Welcome to Number Castle, Seb! Answer our 8 Royal Riddles and we will make you a Number Knight!',
      btns:[['👑 Royal Riddles','green',()=>startQuiz('activity','riddles')],['💎 Crown Jewels','white',()=>{if(typeof startCollect==='function')startCollect('jewels');}],['Not now','white']]});}});
  W.ticks.push(dt=>{if(!K.g.parent)return true;const P=player,t=W.t;
    [[K,-6.5],[Q,6.5]].forEach((q,i)=>{const L=q[0],a=Math.atan2(P.x-q[1],P.z+27.4),d=Math.hypot(P.x-q[1],P.z+27.4);const want=d<26?Math.max(-.8,Math.min(.8,a)):Math.sin(t*.3+i)*.2;
      L.h.rotation.y+=(want-L.h.rotation.y)*Math.min(1,dt*3);L.h.rotation.z=Math.sin(t*.8+i*2)*.04;L.b.scale.y=1+Math.sin(t*1.6+i)*.012;L.eg.scale.y=((t+i*1.7)%4.5<.13)?.12:1;});
    if(!hello&&Math.hypot(P.x,P.z+26)<13){hello=true;say(knight()?'King Ten roars: welcome back, Sir Seb the Number Knight!':'King Ten roars: welcome, Seb! I am King Ten, and this is Queen Hundred. Tap us for our Royal Riddles!');}});}

/* Royal Riddles: eight number riddles from the King and Queen */
function royalSVG(){let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#a84444"/><rect y="560" width="1024" height="208" fill="#e9cf92"/>`;
  for(let i=0;i<8;i++)s+=`<path d="M${40+i*130} 0 h70 v170 l-35 -30 l-35 30Z" fill="${i%2?'#e0b84a':'#7a4fd0'}" opacity=".85"/>`;for(let i=0;i<16;i++)s+=`<path d="M${i*64+32} 600 l18 18 l-18 18 l-18 -18Z" fill="#c9a227" opacity=".5"/>`;return s+'</svg>';}
const SH=[['triangle',3],['square',4],['pentagon',5],['hexagon',6],['octagon',8]];
QUIZ.riddles={k:'riddles',name:'Royal Riddles',icon:'👑',n:8,bg:royalSVG,introMs:3600,intro:'Royal Riddles! King Ten and Queen Hundred have 8 number riddles for you. Answer them all to become a Number Knight!',
  make:i=>{const k=['more','double','less','sides','tens','half','between','lots'][i%8];let q,ans,hint,pic=`<div style="font-size:120px;line-height:1">${i%2?'🦁':'👑'}</div>`;
    if(k==='more'){const a=rint(3,12),b=rint(2,8);ans=a+b;q=`I am <b>${b} more</b> than <b>${a}</b>.`;hint=`Start at ${a} and count on ${b} more.`;}
    if(k==='double'){const a=rint(2,10);ans=2*a;q=`I am <b>double ${a}</b>.`;hint=`Double means two lots. ${a} and ${a} more.`;}
    if(k==='less'){const a=rint(8,20),b=rint(2,6);ans=a-b;q=`I am <b>${b} less</b> than <b>${a}</b>.`;hint=`Start at ${a} and count back ${b}.`;}
    if(k==='sides'){const S=pick(SH);ans=S[1];q=`I am the number of sides on a <b>${S[0]}</b>.`;hint='Count the straight sides, one at a time, going round the shape.';pic=shapeSVG(S[1],pick(BR),170);}
    if(k==='tens'){const a=rint(11,79);ans=a+10;q=`I am <b>10 more</b> than <b>${a}</b>.`;hint='Ten more makes the tens go up by one. The ones stay the same.';}
    if(k==='half'){const a=pick([4,6,8,10,12,14,16,18,20]);ans=a/2;q=`I am <b>half of ${a}</b>.`;hint=`Share ${a} into two equal groups.`;}
    if(k==='between'){const a=rint(3,40);ans=a+1;q=`I am <b>between ${a} and ${a+2}</b>.`;hint=`Count: ${a}, then what comes next?`;}
    if(k==='lots'){const T=tablesOn(),t=pick(T),b=rint(2,6);ans=t*b;q=`I am <b>${b} lots of ${t}</b>.`;hint=`Count in ${t}s, ${b} times.`;}
    const plain=q.replace(/<[^>]+>/g,'');return {q:`${q}<br>What number am I?`,say:`${i%2?'Queen Hundred':'King Ten'} asks: ${plain} What number am I?`,pic,ans,opts:opts(ans,[ans+1,ans-1,ans+2,ans-2,ans+10],4),hintSay:hint};},
  block:()=>'👑',title:'Arise, Sir Seb, Number Knight!'};

/* ================= Number Castle: how big is big? and the googol ribbon ================= */
function cubes(x0,y0,z0,nx,ny,nz,cA,cB,shell){const s=.5,p=.54;for(let i=0;i<nx;i++)for(let j=0;j<ny;j++)for(let k=0;k<nz;k++){if(shell&&i>0&&j>0&&k>0&&i<nx-1&&j<ny-1&&k<nz-1)continue;I('box',(i+j+k)%2?cA:cB,s,s,s,x0+i*p,y0+j*p+s/2,z0+k*p);}}
function bigNumbers(){const x=33,y=gy(x,0),FACTS=[
  ['1',-18,'One cube. Counting starts at one!'],
  ['10',-12.5,'Ten cubes make a ten stick. Ten is 1 with one zero.'],
  ['100',-5,'Ten tens make one hundred. That is 1 with two zeros!'],
  ['1,000',4,'Ten hundreds make one thousand. That is 1 with three zeros, and 1,000 little cubes!'],
  ['1,000,000',14,'A million dots! That is 1 with six zeros. Each coloured square has ten thousand tiny dots, and there are 100 squares. If you counted one dot every second, without stopping, it would take you more than 11 days!']];
  I('box','#ffffff',1.2,1,1.2,x,y+.5,-18);I('box','#c9a86a',1.3,.1,1.3,x,y+1.02,-18);cubes(x,y+1.07,-18,1,1,1,'#ffd23f','#f2c21f');col(x,-18,.9);
  I('box','#ffffff',1.2,.4,1.2,x,y+.2,-12.5);cubes(x,y+.4,-12.5,1,10,1,'#3d8fe0','#2f78c8');col(x,-12.5,.9);
  I('box','#ffffff',1.2,.4,6,x,y+.2,-5);cubes(x,y+.4,-5-2.43,1,10,10,'#3fae5a','#2f9a4a');rect(x-.7,-8,x+.7,-2);
  cubes(x-2.43,y,4-2.43,10,10,10,'#ff8a3c','#f07020',true);rect(x-2.8,1.3,x+2.8,6.7);
  const mt=tex(1000,1000,g=>{const im=g.createImageData(1000,1000),d=im.data,C=[[255,107,107],[255,179,71],[255,210,63],[143,227,154],[127,200,240],[201,182,255],[255,158,203]];for(let y=0;y<1000;y++)for(let x=0;x<1000;x++){const c=C[((x/100|0)+(y/100|0)*3)%7],f=(x+y)&1?1:.78,k=(y*1000+x)*4;d[k]=c[0]*f;d[k+1]=c[1]*f;d[k+2]=c[2]*f;d[k+3]=255;}g.putImageData(im,0,0);});mt.magFilter=THREE.NearestFilter;
  const mw=new THREE.Mesh(new THREE.PlaneGeometry(7,7),new THREE.MeshBasicMaterial({map:mt}));mw.rotation.y=-PI/2;mw.position.set(x+1.6,y+4.6,14);W.ag.add(mw);W.disp.push(mw.geometry,mw.material);
  I('box','#d4a72c',.3,7.6,7.6,x+1.8,y+4.6,14);[-1,1].forEach(s=>I('box','#d4a72c',.5,1.2,.5,x+1.8,y+.6,14+s*3));rect(x+1.3,10,x+2.3,18);
  FACTS.forEach((f,i)=>{const ty=[2.6,7,7.5,7.4,9.2][i];const l=label(f[0],[2,2.4,2.8,3.6,5.6][i]);l.position.set(x,y+ty,f[1]);W.ag.add(l);
    W.things.push({x:x-3.4,z:f[1],r:3,icon:'🔢',label:f[0],act:()=>{sfx.chime();say(f[2]);}});});
  const gs=sign(30.5,20.5,'🎗️ The googol',3,5.5);let gk=0;
  W.things.push({x:29.5,z:19.5,r:3,icon:'🎗️',label:'The googol',act:()=>{sfx.chime();say(gk++%2===0?
    'A googol is 1 with 100 zeros! Look up at the googol ribbon. It goes all the way round the castle. The gold tags count the zeros in tens. A 9 year old boy called Milton gave the googol its name. A googol is more than all the tiny bits of stuff in the whole universe!':
    'Google is named after the googol, but it was spelled differently by mistake. And a googolplex is 1 with a googol of zeros. It is too long to write, even if the whole universe was paper!');}});}
function googolRibbon(A){const r=A.R+.35,y0=3.95,y1=5.35,ty0=5.45,ty1=6.05,dw=1.6,deg=PI/180;
  const t=tex(1024,512,g=>{g.fillStyle='#fffdf4';g.fillRect(0,0,1024,256);g.fillStyle='#d4a72c';g.fillRect(0,0,1024,10);g.fillRect(0,118,1024,10);g.fillRect(0,128,1024,10);g.fillRect(0,246,1024,10);
    for(let k=0;k<10;k++)txt(g,'0',51.2+k*102.4,68,96);txt(g,'1',51.2,196,96,'#b8282e');txt(g,'A googol is',576,196,72,'#7a1a1e');
    for(let k=0;k<10;k++){g.fillStyle='#d4a72c';rr(g,k*102.4+6,262,90,52,22);g.fill();txt(g,String((k+1)*10),k*102.4+51,290,34,'#ffffff');}});
  const items=[{len:8,u:[.125,1],v:[.5,.75],gap:.8},{len:dw,u:[0,.1],v:[.5,.75],gap:.5}];for(let k=0;k<10;k++)items.push({len:10*dw,u:[0,1],v:[.75,1],gap:2.2,tag:k});
  const arcs=[[-58,28],[50,130],[152,240]].map(a=>[a[0]*deg,a[1]*deg]);let ai=0,pos=arcs[0][0]*r;const P=[],UV=[],IX=[];
  const quad=(a0,a1,ya,yb,u,v)=>{const n=Math.max(2,Math.ceil((a1-a0)*r/1.2)),b=P.length/3;for(let i=0;i<=n;i++){const a=a0+(a1-a0)*i/n,c=Math.cos(a)*r,s=Math.sin(a)*r,uu=u[0]+(u[1]-u[0])*i/n;P.push(c,ya,s,c,yb,s);UV.push(uu,v[0],uu,v[1]);}
    for(let i=0;i<n;i++){const q=b+i*2;IX.push(q,q+1,q+2,q+1,q+3,q+2);}};
  items.forEach(it=>{if(pos+it.len>arcs[ai][1]*r){ai++;if(ai>=arcs.length)return;pos=arcs[ai][0]*r;}const a0=pos/r,a1=(pos+it.len)/r;quad(a0,a1,y0,y1,it.u,it.v);
    if(it.tag!=null){const am=(a0+a1)/2,hw=1.2/r;quad(am-hw,am+hw,ty0,ty1,[it.tag/10,(it.tag+1)/10],[.375,.5]);}pos+=it.len+it.gap;});
  const ge=new THREE.BufferGeometry();ge.setAttribute('position',new THREE.Float32BufferAttribute(P,3));ge.setAttribute('uv',new THREE.Float32BufferAttribute(UV,2));ge.setIndex(IX);ge.computeBoundingSphere();
  const m=new THREE.Mesh(ge,new THREE.MeshBasicMaterial({map:t,side:THREE.DoubleSide}));m.position.y=gy(0,0);W.ag.add(m);W.disp.push(ge,m.material);}

/* ================= put it together ================= */
const FLOOR={ntown:['#f7e6a6','#f1db8c'],towers:['#cfe0f5','#c2d6ee'],river:['#c6ebe1','#b5e0d3'],shapes:['#e2d6f4','#d5c6ec'],bakery:['#f8d4b6','#f1c5a1'],castle:['#f2dca8','#e9cf92']};
const ZONES={
 ntown:[{x1:-11.5,z1:-38,x2:11.5,z2:-16},{x:-13,z:-21,r:3},{x:0,z:10,r:5},{x:22,z:-8,r:4},{x:-22,z:-4,r:4}],
 towers:[{x1:12.6,z1:-35.4,x2:33.4,z2:-14.6},{x:12,z:-15,r:2},{x:-30,z:22,r:7},{x:-28,z:-14,r:3.6},{x:-36,z:8,r:4}],
 river:[{x1:-29,z1:-28.5,x2:26,z2:-19.5},{x:-16,z:-36,r:3.4},{x:36,z:8,r:4}],
 shapes:[{x:30,z:-10,r:9},{x:29,z:0,r:2.5},{x:-34,z:6,r:4}],
 bakery:[{x1:-31.5,z1:22,x2:-2.3,z2:30},{x:24,z:8,r:4},{x:-26,z:-10,r:3.4}],
 castle:[{x1:-2.6,z1:-30,x2:2.6,z2:27},{x1:-12,z1:-31,x2:12,z2:-22},{x1:27.5,z1:-21,x2:39,z2:22},{x:-30,z:-6,r:4}]};
for(let i=0;i<CLASS_PATH.length;i++)ZONES.ntown.push(...segZ(CLASS_PATH[i],CLASS_PATH[(i+1)%CLASS_PATH.length],1.6));
Object.keys(FLOOR).forEach(id=>{const A=AREAS[id];if(!A)return;const F=FLOOR[id],props={ground:F[0],ground2:F[1]};if(A.grid)props.grid=Object.assign({},A.grid,{c:shade(F[0],-.16)});
  restyle(id,props,function(){ZS=[];curCell=null;HUNT=null;huntSign=null;huntStar=null;
    if(id==='ntown'){clearZ([{x:0,z:10,r:2.9}]);W.ag.children.forEach(o=>{if(o.isSprite&&Math.hypot(o.position.x,o.position.z-10)<.6&&o.position.y<5)o.visible=false;});
      hundredSquare();numberFountain(0,10);schoolTrip();W.ticks.push(dt=>{huntTick(dt);});}
    if(id==='towers'){timesGrid();balanceScale(-30,22);}
    if(id==='river')numberLine();
    if(id==='shapes')tessFloor();
    if(id==='bakery')fractionCircles();
    if(id==='castle'){royalCarpet();royals();bigNumbers();googolRibbon(this);}
    Object.keys(CRE).forEach(n=>{if(CRE[n].area===id)creature(+n);});
    floorZones();});
  const Z=ZONES[id],k0=A.keepOut;A.keepOut=(x,z)=>inZ(Z,x,z)||(k0?k0(x,z):false);});
AREAS.ntown.hello='Welcome to Number Kingdom, a giant number museum! A school class is visiting today. Two pups are hiding in Number Town. Say hello to Professor Hoot!';
AREAS.castle.hello='Number Castle! King Ten and Queen Hundred sit by the castle door. Two pups are hiding in the courtyard, and the crown jewels are scattered everywhere!';
const _ea=enterArea;enterArea=function(){HUNT=null;return _ea.apply(this,arguments);};

/* ================= the arcade, badges and the certificate ================= */
regAct('hhunt',{name:'Hundred Hunt',icon:'💯',island:'number',area:'ntown',where:'Number Town',play:()=>arcadeTravel('ntown',[0,-13,PI],()=>startHunt('arcade'),'The Hundred Hunt is about to start!')});
regAct('lineup',{name:'Line Up!',icon:'🧒',island:'number',area:'ntown',where:'Number Town',lockSay:'Tap Miss Sums in Number Town and play Line Up! there first. Then you can play it here too!',play:()=>startLineUp('arcade')});
regAct('riddles',{name:'Royal Riddles',icon:'👑',island:'number',area:'castle',where:'Number Castle',lockSay:'Tap King Ten and Queen Hundred in Number Castle and play Royal Riddles there first. Then you can play it here too!',play:()=>startQuiz('arcade','riddles')});
MERITS.push(
  {id:'ncreatures',icon:'🐛',name:'Creature Counter',how:'Meet all 10 number creatures in Number Kingdom.',ok:()=>Object.keys(state.ncre||{}).length>=10},
  {id:'hhunt',icon:'💯',name:'Hundred Hunter',how:'Finish the Hundred Hunt in Number Town.',ok:()=>!!(state.acts||{}).hhunt},
  {id:'lineup',icon:'🧒',name:'Line Leader',how:'Play Line Up! with Miss Sums and her class.',ok:()=>!!(state.acts||{}).lineup});
CERTS.push({id:'numknight',icon:'🛡️',title:'Number Knight',why:'for answering the Royal Riddles of King Ten and Queen Hundred',ok:()=>!!(state.acts||{}).riddles});
window.NUMBER2={CRE,KIDS,TEACHER,kidSVG,kid3D,startHunt,startLineUp,HQ,TG,cell:()=>curCell,hunt:()=>HUNT};
})();
