/* Rescue Bay look (22 Nov 2026): a bright seaside town. Golden sand,
   a turquoise sea all round the beaches, painted cottages round the
   Fire Station and the Town Square, green mountains with snowy tops
   behind, and a pine forest at the Ranger Station. */
(function(){
const SEA='#5fc4f0',flat=()=>0,paving=(x,z)=>{const a=Math.floor((x+200)/3),b=Math.floor((z+200)/3);return ((a*5+b*3)%4)/5;};
const MTN={style:'mountains',arc:[190,350]};
const BRIGHT={light:'sunny',sky:'#7fd0ff',fogC:'#c6ecff',fog:[70,260],noEdgeTrees:true};
/* the land runs down into the sea beyond the edge, and under the sea inside the area */
function coast(id,drop,rects){const A=AREAS[id],h0=A.hf||flat,R=A.R;A.hf=(x,z)=>{let t=Math.max(0,Math.min(1,(Math.hypot(x,z)-(R-.5))/5));
  (rects||[]).forEach(q=>{const dx=Math.max(q[0]-x,0,x-q[2]),dz=Math.max(q[1]-z,0,z-q[3]);t=Math.max(t,1-Math.min(1,Math.hypot(dx,dz)/4));});return h0(x,z)*(1-t)+drop*t;};}
restyle('firestation',Object.assign({},BRIGHT,{hf:flat,ground:'#dccfbc',ground2:'#cdbfab',gmix:paving,grid:{step:3,c:'#b9ac98'},edge:{style:'cottages'},edgeGaps:[[0,56,8]],backdrop:MTN,biome:'seatown',hedgeC:'#c9905f'}),
  A=>{const m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:SEA}));m.scale.set(16,1,30);m.position.set(0,.02,68);W.ag.add(m);W.disp.push(m.material);
    for(let i=0;i<10;i++)[-1,1].forEach(k=>I('sphL',pick(['#8a8378','#9a9488']),.9,.5,.8,k*(8.4+Math.random()),.1,54+i*2.4));});
restyle('harbour',Object.assign({},BRIGHT,{ground:'#f0d27a',ground2:'#e6c166',edge:{style:'dunes'},sea:{y:-.5,c:SEA},backdrop:MTN,biome:'beach',hedgeC:'#c9905f'}));coast('harbour',-1.6);
restyle('townsq',Object.assign({},BRIGHT,{hf:flat,ground:'#dccfbc',ground2:'#cdbfab',gmix:paving,grid:{step:3,c:'#b9ac98'},edge:{style:'cottages'},backdrop:MTN,biome:'seatown',hedgeC:'#c9905f'}));
restyle('lighthouse',Object.assign({},BRIGHT,{ground:'#9fd86a',ground2:'#f0d27a',gmix:(x,z)=>Math.max(0,Math.min(1,(Math.hypot(x,z+20)-22)/10)),edge:{style:'dunes'},sea:{y:-.5,c:SEA},seaDip:true,backdrop:MTN,biome:'beach',hedgeC:'#c9905f'}));coast('lighthouse',-1.6,[[-50,-50,50,-38]]);
restyle('ranger',{light:'sunny',sky:'#8fd4ff',fogC:'#d4ecf0',fog:[60,230],ground:'#6f9a4a',ground2:'#8a7048',backdrop:{style:'mountains',snow:true},biome:'pinewood',hedgeC:'#2f5a3a'});
restyle('bigrescue',Object.assign({},BRIGHT,{sky:'#8fd4ff',ground:'#f0d27a',ground2:'#e6c166',edge:{style:'dunes'},sea:{y:-.5,c:SEA},seaDip:true,backdrop:MTN,biome:'beach',hedgeC:'#c9905f'}));coast('bigrescue',-1.6,[[-48,-48,48,-36]]);
restyle('cove',Object.assign({},BRIGHT,{edge:{style:'dunes'},sea:{y:-.5,c:SEA},seaDip:true,backdrop:MTN,hedgeC:'#c9905f'}));coast('cove',-1.6,[[-32,-32,10,-18]]);
})();
