/* Seb's Puppy Quest 3: start up */
(function(){
  load();
  function fit(){const w=innerWidth,h=innerHeight,s=Math.min(w/1024,h/768);scale=s;$('#stage').style.transform=`translate(-50%,-50%) scale(${s})`;
    $('#rotate').classList.toggle('on',h>w*1.05&&!rotOk);resize3D();}
  addEventListener('resize',fit);fit();
  $('#rotPup').innerHTML=critterSVG(PUPS.buttercup);tap('#rotOk',()=>{rotOk=true;fit();});
  $('#titlePups').innerHTML=['honey','poppy'].map(id=>pupBox(PUPS[id])).join('')+`<div class="fitsvg seb">${sebSVG(true)}</div>`+['buttercup','bluebell'].map(id=>pupBox(PUPS[id])).join('');
  tap('#playBtn',()=>{sfx.boop();play();});
  tap('#wBook',()=>showBook(W.area&&W.area.island||bookIsl));tap('#wMap',openMap);tap('#wPack',()=>showBook('pack'));tap('#actBtn',doAction);
  tap('#bookBack',leaveBook);tap('#labBack',()=>{sfx.boop();backToWorld();});tap('#sciBack',()=>{sfx.boop();openLab();});tap('#shopBack',()=>{sfx.boop();backToWorld();});tap('#spaBack',()=>{sfx.boop();spaClose();backToWorld();});tap('#bubble',()=>{if(lastSay)speak(lastSay);});
  hold('#cogT',openSettings);hold('#cogB',openSettings);hold('#cogS',settingsFromSleep);
  if('speechSynthesis' in window){pickVoice();try{speechSynthesis.onvoiceschanged=pickVoice;}catch(e){}}
  if(state.guest)loadPQ2Friends(()=>{});
  document.addEventListener('visibilitychange',()=>{if(document.hidden){save();quiet();}});
  setInterval(()=>{if(sleepOn&&!(state.sleepUntil>Date.now()))hideSleep();},5000);
  requestAnimationFrame(frame);
  $('#loading').style.display='none';$('#playBtn').style.display='inline-flex';
  window.PQ3={state:()=>state,W,player,enterArea,PUPS,AREAS};
})();
