/* ================================================================
   Night Glow (Pup Seasons 2, 25 Nov 2026; claude/night-glow-design.md): the engine.
   Night looks (moonlight, stars, tonight's real Moon shape), Seb's little firefly (named by Seb),
   the three hiding tricks (where the fireflies gather, glowing paw prints, star puzzles),
   finding a Night Glow pup, the nine flashes of the Glow Song from the unicorns, the opening,
   the invitation and the grown-ups switch. Shares window.SEASONS, the Season Globe and the
   spot planner grid with season.js.
   Save: state.sx.glow = {fly:{name,girl,at}, found:{id:time}, how:{id:kind}, tagged:{id:1},
   fl:{island:time}, inv, intro, ...}; created only once Night Glow is opened and started.
   ================================================================ */
(function(){
const PI=Math.PI,GL=window.GLOOK,GP=GL.GPUPS,gp=GL.gp,FACT=GL.FACT,XM=window.XMAS,LIME='#d8ff5a';
const G0=()=>(state&&state.sx&&state.sx.glow)||null;
const GS=()=>{if(!state.sx)state.sx={};const s=state.sx;if(!s.glow)s.glow={found:{},how:{},tagged:{},fl:{}};return s.glow;};
const on=()=>!!(state&&state.season==='glow');
const xmasDone=()=>!!(state&&state.sx&&state.sx.xmas&&state.sx.xmas.done);
const opened=()=>xmasDone()||!!(state&&state.set&&state.set.glowOpen);
const named=()=>!!(G0()&&G0().fly);
let ALL=null;
const all=()=>ALL||(ALL=ISLANDS.reduce((a,I)=>a.concat(I.pups,I.bonus||[]),[]).concat([GP.foxfire,GP.dusk]));
const gpup=id=>PUPS[id]||GP[id];
const xFound=id=>!!(G0()&&G0().found[id]);
const nFound=()=>G0()?all().filter(p=>xFound(p.id)).length:0;
const islX=I=>I.pups.concat(I.bonus||[]);
const islN=I=>islX(I).filter(p=>xFound(p.id)).length;
const areaX=a=>all().filter(p=>p.area===a);
const nFl=()=>Object.keys((G0()||{}).fl||{}).length;
const fly=()=>(G0()&&G0().fly)||{name:'the firefly',girl:true};
const he=()=>fly().girl?'she':'he',his=()=>fly().girl?'her':'his',him=()=>fly().girl?'her':'him';
const kindOf=p=>p.season==='glow'||p.bonus?'stars':p.tag?'trail':'swarm';
const NEED=6;
const hsh=s=>{let h=7;for(const ch of String(s))h=(h*31+ch.charCodeAt(0))%100003;return h;};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

/* ---------------- sounds ---------------- */
const SONG=[523,523,784,784,880,880,784,698,698];/* the Glow Song: the first nine notes of Twinkle, Twinkle, Little Star */
const snd={
 blink(){if(!fxOk())return;const t=AC.currentTime;tone(1568,t,.12,'sine',.06);tone(2093,t+.07,.16,'sine',.05);},
 hoot(){if(!fxOk())return;const t=AC.currentTime;tone(392,t,.28,'sine',.16,null,350);tone(330,t+.36,.45,'sine',.14,null,300);},
 pop(){if(!fxOk())return;const t=AC.currentTime;tone(600,t,.08,'square',.06,null,1200);nzHit(t,.04,.08,'highpass',3000);},
 chirp(){if(!fxOk())return;const t=AC.currentTime;for(let i=0;i<6;i++)tone(4200,t+i*.05,.025,'square',.018);},
 whoosh(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.5,.12,'bandpass',900,null,1.2);},
 twinkle(){if(!fxOk())return;const t=AC.currentTime;[1760,2093,2637,3136].forEach((f,i)=>tone(f,t+i*.08,.25,'sine',.1));},
 note(i){if(!fxOk())return;const t=AC.currentTime,f=SONG[i%9];tone(f,t,.42,'sine',.15);tone(f*2,t,.25,'sine',.04);},
 song(n,gap){for(let i=0;i<n;i++)setTimeout(()=>snd.note(i),i*(gap||340));}};

/* ================= the night look ================= */
const NOGLOW=new Set(['den','cave','glow','vault','ambercave','library','alien']);
const NIGHT={sky:'#93a2e8',gr:'#2e3060',hi:.64,dir:'#c8d4ff',di:.36,pos:[-60,80,-90],lantern:1.5};
const mixC=(a,b,k)=>{const c=new THREE.Color(a||'#888888');c.lerp(new THREE.Color(b),k);return '#'+c.getHexString();};
const night=A=>!!(A&&!NOGLOW.has(A.id)&&!A.indoor);
function lookFor(A){if(!night(A))return null;const space=(A.island||A.id)==='planet';const o={light:Object.assign({},NIGHT),skyObj:Object.assign({},A.skyObj||{},{stars:true,sun:null})};
  if(!space){o.sky=A.swim?'#0e2a52':'#1b2452';o.fogC=o.sky;o.fog=[48,200];o.ground=mixC(A.ground,'#2a3a6a',.28);o.ground2=mixC(A.ground2||A.ground,'#2a3a6a',.28);}
  if(A.swim){o.light.hi=.74;o.light.sky='#86c0ee';}return o;}
/* tonight's real Moon shape, from the iPad's date */
const phase=()=>{const d=(Date.now()-Date.UTC(2000,0,6,18,14))/864e5,L=29.530588853;return ((d%L)+L)%L/L;};
let MOONT=null,GLOWT=null;
function moonTex(){if(MOONT)return MOONT;const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d'),r=50,p=phase(),k=Math.cos(p*2*PI);
  x.fillStyle='rgba(60,70,110,.55)';x.beginPath();x.arc(64,64,r,0,PI*2);x.fill();x.fillStyle='#f6f0d0';x.beginPath();
  if(p<.5)x.arc(64,64,r,-PI/2,PI/2,false);else x.arc(64,64,r,PI/2,PI*1.5,false);
  x.ellipse(64,64,Math.max(.01,Math.abs(k)*r),r,0,p<.5?PI/2:-PI/2,p<.5?-PI/2:PI/2,p<.5?k>0:k>0);x.fill();
  [[50,52,7],[76,74,9],[70,44,5],[54,82,6]].forEach(q=>{x.fillStyle='rgba(150,140,110,.35)';x.beginPath();x.arc(q[0],q[1],q[2],0,PI*2);x.fill();});
  MOONT=new THREE.CanvasTexture(c);return MOONT;}
function glowTex(){if(GLOWT)return GLOWT;const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d'),g=x.createRadialGradient(32,32,0,32,32,32);
  g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.25,'rgba(255,255,255,.8)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);GLOWT=new THREE.CanvasTexture(c);return GLOWT;}
function glowMat(col,op){return new THREE.SpriteMaterial({map:glowTex(),color:col||LIME,transparent:true,opacity:op==null?.9:op,depthWrite:false,blending:THREE.AdditiveBlending,fog:false});}
function moonSky(A){if((A.island||A.id)==='planet')return;const m=new THREE.Sprite(new THREE.SpriteMaterial({map:moonTex(),transparent:true,depthWrite:false,fog:false}));m.scale.set(44,44,1);m.position.set(-150,190,-230);W.ag.add(m);W.disp.push(m.material);
  const h=new THREE.Sprite(glowMat('#c8d4ff',.35));h.scale.set(110,110,1);h.position.copy(m.position);W.ag.add(h);W.disp.push(h.material);}
/* a cloud of fireflies: one points cloud, drifting round a centre */
function swarmPts(x,z,n,o){o=o||{};const P=new Float32Array(n*3),B=[],R=seed(Math.round(x*7+z*13)+5);for(let i=0;i<n;i++)B.push([R()*PI*2,.6+R()*(o.r||1.8),.4+R()*(o.h||1.6),R()*6]);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({color:o.c||LIME,size:o.size||.32,map:glowTex(),transparent:true,depthWrite:false,blending:THREE.AdditiveBlending});
  const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);const A=W.area,y0=o.y!=null?o.y:gy(x,z);
  const tick=()=>{if(W.area!==A||!pts.parent)return true;const t=W.t;for(let i=0;i<n;i++){const b=B[i],a=b[0]+t*(.4+(i%3)*.15);P[i*3]=pts.userData.x+Math.cos(a)*b[1];P[i*3+1]=y0+b[2]+Math.sin(t*1.7+b[3])*.35;P[i*3+2]=pts.userData.z+Math.sin(a)*b[1];}
    m.opacity=.65+.35*Math.sin(t*3.1);g.attributes.position.needsUpdate=true;};
  pts.userData.x=x;pts.userData.z=z;W.ticks.push(tick);tick();return pts;}

/* ================= entering an area in Night Glow ================= */
const _ea=enterArea;
enterArea=function(id,pos,msg){const A=AREAS[id];
  if(!A||!on())return _ea.apply(this,arguments);
  const o=lookFor(A),keep={};if(o)for(const k in o){keep[k]=[k in A,A[k]];A[k]=o[k];}
  try{_ea.apply(this,arguments);}finally{for(const k in keep){if(keep[k][0])A[k]=keep[k][1];else delete A[k];}}
  if(W.area!==A)return;
  if(night(A)){moonSky(A);if(G0()&&G0().done&&!A.swim)swarmPts(0,0,46,{r:A.R?A.R*.7:20,h:4,size:.3});}
  if(window.GWORLD&&GWORLD.after)try{GWORLD.after(A);}catch(e){console.warn('glow after',e);}
  flyEnter(A);hud();
  const I=A.island&&islandOf(A.island);if(I&&named()&&G0().intro&&islN(I)>=NEED&&!G0().fl[I.id])setTimeout(()=>{if(W.area===A&&!player.lock&&!ovOpen())flash(I);},1800);
  if(id==='village')setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village')return;if(window.GSTORY&&GSTORY.village)GSTORY.village();},900);};
Object.values(AREAS).forEach(A=>{const b=A.build;if(typeof b!=='function')return;A.build=function(){b.apply(this,arguments);if(on()&&window.GWORLD&&GWORLD.build)try{GWORLD.build(A);}catch(e){console.warn('glow build',e);}};});

/* ================= hiding spots ================= */
const _bs=buildSpots;buildSpots=function(A){if(!on())return _bs(A);if(GLOW.noSpots)return;gSpots(A);};
const _bb=buildBoss;buildBoss=function(IS){if(!on())return _bb(IS);uniHome(IS);};
const _ac=areaCount;areaCount=function(a){if(!on())return _ac(a);const L=areaX(a);return L.length?`🌙 ${L.filter(p=>xFound(p.id)).length}/${L.length}`:'';};
let PLAN=null,LIVE=[];
function spotFor(p,A){const S=(window.GSPOTS||{})[p.id];if(S)return S;if(!PLAN||PLAN.area!==A.id){PLAN=plan(A);PLAN.area=A.id;}return PLAN.spots[p.id]||null;}
function gSpots(A){LIVE=[];areaX(A.id).forEach(p=>{const S=spotFor(p,A);if(!S)return;const k=S.k||kindOf(p);try{
    if(k==='swarm')LIVE.push(swarm(p,S,A));else if(k==='stars')LIVE.push(starSpot(p,S,A));else if(k==='trail')LIVE.push(trail(p,S,A));}catch(e){console.warn('glow spot',p.id,e);}});
  W.ticks.push(spotTick);}
/* the hiding places on each island (3D builders and 2D pictures) */
const PLACES={meadow:['bush','hay','log'],snowy:['drift','drift','pine'],reef:['clam','rock','clam'],ninja:['slant','bamboo','slant'],number:['ncrate','ncrate','ncrate'],gadget:['crate','barrel','crate'],
  rescue:['lpot','buoy','lpot'],dino:['fern','boulder','fern'],planet:['mrock','mrock','crater'],village:['bush','log','hay']};
function place3D(k,par,s,R){const g=grp();g.scale.setScalar(s);par.add(g);switch(k){
  case'bush':mk('sph','#2f6a3a',.9,.75,.9,0,.6,0,g);mk('sph','#3a7a44',.6,.55,.6,.5,.85,.2,g);mk('sph','#2a5a34',.55,.5,.55,-.45,.8,-.2,g);break;
  case'hay':mk('cyl','#d8b860',.75,.9,.75,0,.45,0,g).rotation.z=PI/2;mk('cyl','#b89848',.77,.12,.77,0,.45,0,g).rotation.z=PI/2;break;
  case'log':{const l=mk('cyl','#7a5a3a',.42,1.6,.42,0,.42,0,g);l.rotation.z=PI/2;mk('cyl','#c8a070',.4,.04,.4,.81,.42,0,g).rotation.z=PI/2;break;}
  case'drift':mk('hemi','#eef4fb',1.1,.8,1,0,0,0,g);mk('hemi','#e4ecf6',.7,.55,.7,.6,0,.3,g);break;
  case'pine':mk('cone','#2a5a40',.7,1.6,.7,0,.9,0,g);mk('cone','#f0f6fb',.5,.4,.5,0,1.55,0,g);break;
  case'clam':mk('hemi','#f3c8d8',.8,.45,.7,0,0,0,g);{const t=mk('hemi','#f8dce6',.8,.4,.7,0,.08,-.15,g);t.rotation.x=-.5;}mk('sph','#ffffff',.18,.18,.18,0,.22,.1,g);break;
  case'rock':mk('sph','#7a8aa0',.8,.6,.8,0,.4,0,g);break;
  case'slant':mk('box','#9a9a9a',.5,.9,.5,0,.45,0,g);mk('pyr','#7a7a7a',.6,.35,.6,0,1.05,0,g);mk('box','#ffd27a',.32,.3,.32,0,.75,0,g,true);break;
  case'bamboo':mk('cyl','#a8643a',.45,.6,.45,0,.3,0,g);for(let i=0;i<3;i++)mk('cyl','#5aa83a',.08,1.6,.08,-.15+i*.15,1.1,(i%2)*.1,g);break;
  case'ncrate':mk('box','#c89a5a',1,.9,1,0,.45,0,g);mk('box','#a87a3a',1.04,.12,1.04,0,.88,0,g);break;
  case'crate':mk('box','#8a6a4a',1,.9,1,0,.45,0,g);mk('box','#6a4a2a',1.04,.1,.1,0,.45,.5,g);break;
  case'barrel':mk('cyl','#6a8aa8',.5,1.1,.5,0,.55,0,g);mk('cyl','#3a4a5a',.52,.08,.52,0,.3,0,g);mk('cyl','#3a4a5a',.52,.08,.52,0,.8,0,g);break;
  case'lpot':mk('cyl','#8a6a3a',.6,.7,.6,0,.35,0,g);mk('hemi','#a8844a',.6,.45,.6,0,.7,0,g);break;
  case'buoy':mk('sph','#e8423a',.55,.55,.55,0,.55,0,g);mk('cyl','#ffffff',.57,.2,.57,0,.55,0,g);break;
  case'fern':for(let i=0;i<6;i++){const f=mk('cone','#3a8a4a',.18,1.3,.06,Math.cos(i)*.3,.55,Math.sin(i)*.3,g);f.rotation.z=Math.cos(i*1.1)*.6;f.rotation.x=Math.sin(i*1.1)*.6;}break;
  case'boulder':mk('sph','#8a7a6a',.9,.7,.85,0,.45,0,g);break;
  case'mrock':mk('sph','#b8bcc8',.8,.6,.75,0,.35,0,g);break;
  case'crater':mk('tor','#a8acb8',.8,.8,.5,0,.08,0,g).rotation.x=PI/2;mk('sph','#c8ccd8',.5,.3,.5,0,.15,0,g);break;}return g;}
const PSVG={bush:'<ellipse cx="60" cy="88" rx="46" ry="28" fill="#2f6a3a"/><circle cx="40" cy="70" r="24" fill="#3a7a44"/><circle cx="76" cy="66" r="26" fill="#2a5a34"/><circle cx="58" cy="56" r="22" fill="#448a4e"/>',
 hay:'<rect x="14" y="54" width="92" height="56" rx="18" fill="#d8b860"/><path d="M30 60 v44 M50 58 v48 M70 58 v48 M90 60 v44" stroke="#b89848" stroke-width="4"/>',
 log:'<rect x="10" y="66" width="96" height="40" rx="20" fill="#7a5a3a"/><ellipse cx="102" cy="86" rx="12" ry="20" fill="#c8a070"/><ellipse cx="102" cy="86" rx="6" ry="10" fill="none" stroke="#9a7a4a" stroke-width="2"/>',
 drift:'<path d="M8 108 Q20 50 60 52 Q100 50 112 108 Z" fill="#eef4fb"/><path d="M60 52 Q84 46 100 70" stroke="#c8d8ea" stroke-width="4" fill="none"/>',
 pine:'<path d="M60 18 L100 100 H20 Z" fill="#2a5a40"/><path d="M60 18 L80 58 H40 Z" fill="#f0f6fb"/><rect x="54" y="100" width="12" height="12" fill="#6a4a2a"/>',
 clam:'<path d="M14 92 Q60 30 106 92 Z" fill="#f3c8d8"/><path d="M14 92 Q60 120 106 92 Z" fill="#f8dce6"/><path d="M60 40 V92 M38 50 L50 92 M82 50 L70 92" stroke="#e0a8bc" stroke-width="3"/>',
 rock:'<path d="M14 104 L24 64 L58 46 L94 58 L108 104 Z" fill="#7a8aa0"/><path d="M58 46 L54 104" stroke="#6a7a90" stroke-width="3"/>',
 slant:'<rect x="40" y="56" width="40" height="52" fill="#9a9a9a"/><rect x="48" y="64" width="24" height="22" fill="#ffd27a"/><path d="M30 58 L60 30 L90 58 Z" fill="#7a7a7a"/>',
 bamboo:'<path d="M30 76 H90 L84 110 H36 Z" fill="#a8643a"/><path d="M46 76 V14 M60 76 V6 M74 76 V20" stroke="#5aa83a" stroke-width="8"/>',
 ncrate:'<rect x="16" y="40" width="88" height="70" rx="4" fill="#c89a5a"/><rect x="16" y="40" width="88" height="12" fill="#a87a3a"/>',
 crate:'<rect x="16" y="40" width="88" height="70" rx="4" fill="#8a6a4a"/><path d="M16 40 L104 110 M104 40 L16 110" stroke="#6a4a2a" stroke-width="6"/>',
 barrel:'<rect x="28" y="30" width="64" height="80" rx="14" fill="#6a8aa8"/><path d="M28 50 H92 M28 90 H92" stroke="#3a4a5a" stroke-width="6"/>',
 lpot:'<path d="M20 108 V70 Q60 30 100 70 V108 Z" fill="#a8844a"/><path d="M20 80 H100 M20 94 H100 M40 52 V108 M60 44 V108 M80 52 V108" stroke="#7a5a2a" stroke-width="3"/>',
 buoy:'<circle cx="60" cy="74" r="38" fill="#e8423a"/><rect x="22" y="64" width="76" height="20" fill="#ffffff"/>',
 fern:'<path d="M60 110 Q30 70 14 40 M60 110 Q50 60 46 20 M60 110 Q74 60 80 22 M60 110 Q92 72 106 44" stroke="#3a8a4a" stroke-width="10" fill="none" stroke-linecap="round"/>',
 boulder:'<ellipse cx="60" cy="82" rx="50" ry="34" fill="#8a7a6a"/><path d="M40 66 q10 -8 22 -2" stroke="#6a5a4a" stroke-width="4" fill="none"/>',
 mrock:'<path d="M12 106 L22 70 L50 54 L90 62 L108 106 Z" fill="#b8bcc8"/><circle cx="44" cy="82" r="6" fill="#a0a4b0"/><circle cx="78" cy="90" r="8" fill="#a0a4b0"/>',
 crater:'<ellipse cx="60" cy="90" rx="52" ry="20" fill="#a8acb8"/><ellipse cx="60" cy="88" rx="34" ry="11" fill="#8a8e9a"/>'};
const DOTS=n=>{const L=[[0,0],[-14,-8],[14,-8],[-14,8],[14,8],[0,-16],[0,16],[-26,0],[26,0],[-26,-14],[26,-14],[-26,14],[26,14]];return L.slice(0,n);};
function placeSVG(k,n,num,big){const w=big?132:116,dots=DOTS(n).map(q=>`<circle cx="${60+q[0]}" cy="${28+q[1]*.8}" r="9" fill="${LIME}" opacity=".35"/><circle cx="${60+q[0]}" cy="${28+q[1]*.8}" r="4.6" fill="${LIME}"/>`).join('');
  return `<svg viewBox="0 0 120 120" width="${w}" height="${w}"><g>${PSVG[k]||PSVG.bush}</g>${num!=null?`<circle cx="94" cy="98" r="15" fill="#fff" stroke="#26232e" stroke-width="3"/><text x="94" y="105" font-size="20" font-weight="900" text-anchor="middle" font-family="Arial" fill="#26232e">${num}</text>`:''}${dots}</svg>`;}
const NUMK=['0️⃣','1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
/* 1. where the fireflies gather */
function swarm(p,S,A){const isl=A.island||'village',kinds=PLACES[isl]||PLACES.meadow,R=seed(hsh(p.id)+7),n=4+(hsh(p.id)%2),G0=grp(),ps=[],right=hsh(p.id+'r')%n,num=isl==='number',found=xFound(p.id);
  for(let i=0;i<n;i++){const a=i/n*PI*2+R()*.5,r=i?1.6+R()*.4:.2,s=.7+R()*.35,k=kinds[(hsh(p.id)+i)%kinds.length],g=place3D(k,G0,s,R);g.position.set(Math.cos(a)*r,0,Math.sin(a)*r);g.rotation.y=R()*PI;ps.push({g,k,s});}
  add(G0,S.x,S.z);bakeModel(G0,'gswarm'+n+'|'+p.id);if(!A.ski)col(S.x,S.z,1.3);
  /* how many fireflies rest on each place: all different, the pup's place has N */
  const lo=isl==='meadow'||isl==='snowy'||isl==='village'?2:3,hi=isl==='meadow'||isl==='snowy'?6:9,R2=seed(hsh(p.id)+3),used={},cnt=ps.map(()=>{let v;do{v=lo+Math.floor(R2()*(hi-lo+1));}while(used[v]);used[v]=1;return v;});
  const o={p,k:'swarm',x:S.x,z:S.z,g:G0,ps,right,n,cnt,num,tries:0};
  if(!found){o.cloud=swarmPts(S.x,S.z,16,{r:2.3,h:2.4});o.easy=spr('✨',1.6,S.x,gy(S.x,S.z)+4,S.z);}else markFound(o);
  W.things.push({x:S.x,z:S.z,r:4.4,icon:'✨',label:'Fireflies!',show:()=>!xFound(p.id),act:()=>openSwarm(o)});return o;}
/* 3. star puzzles: a ring of starlight on the ground */
function starSpot(p,S,A){const found=xFound(p.id),y=gy(S.x,S.z),m=new THREE.MeshBasicMaterial({color:'#fff2a8',transparent:true,opacity:.75,depthWrite:false}),ring=new THREE.Mesh(G.tor||G.sph,m);
  ring.scale.set(1.6,1.6,.4);ring.rotation.x=PI/2;ring.position.set(S.x,y+.12,S.z);W.ag.add(ring);W.disp.push(m);
  const o={p,k:'stars',x:S.x,z:S.z,ring,m};if(!A.ski)col(S.x,S.z,.6);
  if(found)markFound(o);else{o.glow=spr('🌟',1.9,S.x,y+2.4,S.z);}
  W.things.push({x:S.x,z:S.z,r:4,icon:'⭐',label:'Join the stars',show:()=>!xFound(p.id),act:()=>openStars(o)});return o;}
function markFound(o){if(o.easy){W.ag.remove(o.easy);o.easy=null;}if(o.glow){W.ag.remove(o.glow);o.glow=null;}if(o.cloud){W.ag.remove(o.cloud);o.cloud=null;}if(o.ring)o.m.opacity=.25;
  if(!o.mark)o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+3.4,o.z);}
/* 2. glowing paw prints */
let pawT=null;
function pawTex(){if(pawT)return pawT;const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle='#ffffff';x.shadowColor='#ffffff';x.shadowBlur=8;
  x.beginPath();x.ellipse(32,40,13,11,0,0,PI*2);x.fill();[[16,22],[27,15],[39,15],[50,22]].forEach(q=>{x.beginPath();x.ellipse(q[0],q[1],6,7.5,0,0,PI*2);x.fill();});pawT=new THREE.CanvasTexture(c);return pawT;}
function prints(pts,col){const step=1.25,out=[];for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.floor(d/step));
    for(let k=0;k<n;k++){const t=k/n,x=a[0]+(b[0]-a[0])*t,z=a[1]+(b[1]-a[1])*t,h=Math.atan2(b[0]-a[0],b[1]-a[1]),side=(out.length%2?1:-1)*.32;out.push([x+Math.cos(h)*side,z-Math.sin(h)*side,h]);}}
  const m=new THREE.MeshBasicMaterial({map:pawTex(),color:col||LIME,transparent:true,opacity:.9,depthWrite:false,blending:THREE.AdditiveBlending}),im=new THREE.InstancedMesh(G.plane,m,Math.max(1,out.length)),M4=new THREE.Matrix4(),q=new THREE.Quaternion(),s=new THREE.Vector3(.62,1,.62),v=new THREE.Vector3(),e=new THREE.Euler();
  out.forEach((p,i)=>{e.set(0,p[2]+PI,0);q.setFromEuler(e);v.set(p[0],walkY(p[0],p[1])+.07,p[1]);M4.compose(v,q,s);im.setMatrixAt(i,M4);});im.count=out.length;im.frustumCulled=false;W.ag.add(im);W.disp.push(m);return {im,m,n:out.length};}
function hideObj(A,key){const isl=A.island||'village',k=(PLACES[isl]||PLACES.meadow)[hsh(key)%3],g=grp();place3D(k,g,1.2);return g;}
function trail(p,S,A){const tagged=!!(G0()&&G0().tagged[p.id]),found=xFound(p.id),to=tagged?S.c:S.b,path=tagged?S.bc:S.ab;
  const o={p,k:'trail',S,x:to[0],z:to[1],tagged};o.g=hideObj(A,p.id+(tagged?'c':'b'));add(o.g,o.x,o.z);bakeModel(o.g,'ghide|'+(A.island||'v')+(hsh(p.id+(tagged?'c':'b'))%3));
  if(found){o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+3,o.z);return o;}
  o.pr=prints(path||[[tagged?S.b[0]:S.a[0],tagged?S.b[1]:S.a[1]],to],A.swim?'#7ff4ff':LIME);o.easy=spr('✨',1.6,o.x,gy(o.x,o.z)+3.2,o.z);
  o.th={x:o.x,z:o.z,r:3.8,icon:'🔍',label:'Look',show:()=>!xFound(p.id)&&!o.busy,act:()=>searchHide(o)};W.things.push(o.th);return o;}
function spotTick(dt){const t=W.t,P=player;let near=null,nd=1e9;
  LIVE.forEach(o=>{if(o.easy){o.easy.visible=state.set.hsEasy;o.easy.position.y=gy(o.x,o.z)+4+Math.sin(t*3)*.3;}if(o.glow)o.glow.position.y=gy(o.x,o.z)+2.4+Math.sin(t*2.5)*.25;
    if(o.pr)o.pr.m.opacity=.5+.45*(.5+.5*Math.sin(t*3));if(o.ring&&!xFound(o.p.id)){o.m.opacity=.5+.35*Math.sin(t*2.4);o.ring.rotation.z=t*.4;}
    if(xFound(o.p.id))return;const d=Math.hypot(P.x-o.x,P.z-o.z);if(d<nd){nd=d;near=o;}});
  if(near&&nd<9&&t-(GLOW.jT||0)>2.8&&!P.lock&&!ovOpen()){GLOW.jT=t;if(near.k==='swarm')snd.blink();else if(near.k==='stars')snd.twinkle();else{sfx.yip((near.p.pitch||1)*1.1);floatS('🐾',near.x,gy(near.x,near.z)+2.6,near.z,1.2);}}
  if(near&&!P.lock&&t-W.findT>75&&t-W.hintT>75){W.hintT=t;sparkTrail(near);}}
function sparkTrail(o){W.trail.forEach(s=>W.ag.remove(s));W.trail=[];const P=player,dx=o.x-P.x,dz=o.z-P.z,d=Math.hypot(dx,dz),n=Math.min(10,Math.floor((d-3)/2.5));
  for(let i=1;i<=n;i++){const x=P.x+dx*i/(n+1.2),z=P.z+dz*i/(n+1.2);W.trail.push(spr('✨',1.1,x,gy(x,z)+.6,z));}
  FLY.jump=.7;snd.twinkle();say(`${fly().name} is glowing like mad! Follow the sparkles, Seb!`);}

/* ----- the firefly picker ----- */
const SURP=[['🦉','Whooo? Just a sleepy owl!'],['🦔','A hedgehog! It curls up into a prickly ball.'],['🐸','Ribbit! A frog jumps out.'],['🐌','A slow little snail.'],['🐭','A sleepy mouse, yawning.'],['🦋','A fluttery moth!'],['🦗','A cricket! Chirp chirp!']];
function numClue(n){const R=Math.random(),a=1+Math.floor(Math.random()*(n-1));if(n%2===0&&R<.3)return `double ${n/2}`;if(R<.65)return `${a} add ${n-a}`;const b=1+Math.floor(Math.random()*4);return `${n+b} take away ${b}`;}
let PK=null;
function pickUI(){if($('#gpick'))return;const d=el('div','ov','<div class="card" id="gpCard"><h2 id="gpH"></h2><div id="gpRow"></div><p id="gpMsg"></p><div class="btns"><button class="btn white" id="gpBack">Back</button></div></div>');d.id='gpick';document.body.appendChild(d);
  tap('#gpBack',()=>{sfx.boop();closePick();});}
function closePick(){$('#gpick').classList.remove('on');player.lock=false;PK=null;hush();}
function openSwarm(o){if(player.lock||xFound(o.p.id))return;pickUI();player.lock=true;hush();snd.blink();PK=o;o.tries=0;o.opened={};
  const F=fly().name,row=$('#gpRow');row.innerHTML='';$('#gpMsg').textContent='';const N=o.cnt[o.right];
  const order=o.ps.map((q,i)=>i);order.sort((a,b)=>hsh(o.p.id+a)%7-hsh(o.p.id+b)%7);
  order.forEach(i=>{const q=o.ps[i],b=el('button','gpr',placeSVG(q.k,o.cnt[i],null,q.s>.9));b.dataset.i=i;tap(b,()=>tapPlace(o,i,b));row.appendChild(b);});
  if(o.num){o.clue=numClue(N);$('#gpH').textContent=`🔢 Where the fireflies make ${o.clue}!`;speak(`${F} says: the puppy is hiding where the fireflies make ${o.clue}. Count the fireflies! Which one is it?`);}
  else{$('#gpH').textContent=`✨ Find the place with ${N} fireflies!`;speak(`${F} says: the puppy is hiding where ${N} fireflies are resting. Count the fireflies on each one!`);}
  $('#gpick').classList.add('on');}
function tapPlace(o,i,b){if(o.opened[i]||PK!==o)return;o.opened[i]=1;b.classList.remove('hint');b.classList.add('open');const N=o.cnt[o.right];
  if(i===o.right){snd.twinkle();sfx.yip(o.p.pitch);b.innerHTML=`<div class="gpup">${critterSVG(gp(o.p),{anim:false})}</div>`;$('#gpMsg').textContent=`${N} fireflies! It's ${o.p.name}!`;
    setTimeout(()=>{closePick();markFound(o);found(o.p,'swarm',o);},1100);return;}
  o.tries++;const S=SURP[(hsh(o.p.id)+o.tries*3+i)%SURP.length];if(S[0]==='🦉')snd.hoot();else if(S[0]==='🦗')snd.chirp();else sfx.boop();sfx.oops();
  b.innerHTML=`<div class="gsur"><span>${S[0]}</span><small>${o.cnt[i]} fireflies</small></div>`;
  let m=S[1]+(o.num?` Remember: where the fireflies make ${o.clue}.`:` That one had ${o.cnt[i]} fireflies. Look for ${N}!`);
  if(o.tries>=2){$('#gpRow').querySelectorAll('.gpr').forEach(e=>{if(+e.dataset.i===o.right)e.classList.add('hint');});m+=` Look, one of them is glowing!`;}
  $('#gpMsg').textContent=m;speak(m);}
/* tag pups: the first look makes them giggle and run, leaving fresh glowing prints */
function searchHide(o){if(player.lock||xFound(o.p.id))return;player.lock=true;o.busy=true;hush();snd.blink();o.g.scale.set(1.12,.86,1.12);
  setTimeout(()=>{o.g.scale.set(1,1,1);if(!o.tagged){runOff(o);return;}o.busy=false;player.lock=false;found(o.p,'prints',o);},800);}
function runOff(o){const p=o.p,S=o.S,g=pup3D(p,p.shiny),A=W.area;add(g,o.x,o.z);sfx.giggle();say(`Hee hee! ${p.name} giggles and dashes off into the night! Follow the new glowing paw prints!`);
  GS().tagged[p.id]=1;save();const path=(S.bc||[S.b,S.c]).slice();let seg=0,k=0;
  if(o.pr){W.ag.remove(o.pr.im);o.pr=null;}W.ag.remove(o.g);if(o.easy){W.ag.remove(o.easy);o.easy=null;}
  W.ticks.push(function run(dt){if(W.area!==A)return true;const a=path[seg],b=path[seg+1];if(!b){W.ag.remove(g);const n=trail(p,S,A);LIVE=LIVE.filter(q=>q!==o);LIVE.push(n);W.things=W.things.filter(t=>t!==o.th);flushTo(W.ag);player.lock=false;return true;}
    const d=Math.hypot(b[0]-a[0],b[1]-a[1])||.01;k+=dt*14/d;const e=Math.min(1,k),x=a[0]+(b[0]-a[0])*e,z=a[1]+(b[1]-a[1])*e;g.position.set(x,walkY(x,z)+Math.abs(Math.sin(W.t*16))*.35,z);g.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);animPup(g,W.t,true);
    if(e>=1){seg++;k=0;}});}

/* ================= star puzzles (also used by the finale) ================= */
/* pup shapes to draw with stars, in a 100 x 75 box */
const SHAPES={
 sit:[[16,34],[24,27],[29,19],[34,9],[39,21],[46,30],[62,31],[74,33],[86,17],[81,39],[78,50],[80,64],[66,64],[44,64],[34,50],[24,41]],
 run:[[84,30],[78,22],[72,12],[68,24],[60,28],[40,28],[26,22],[14,14],[20,30],[24,40],[12,58],[22,58],[36,44],[54,44],[66,58],[76,58],[70,42],[78,38]],
 head:[[50,70],[34,62],[26,46],[16,12],[34,26],[50,22],[66,26],[84,12],[74,46],[66,62]],
 fox:[[16,36],[24,22],[28,12],[34,22],[42,30],[60,32],[74,28],[90,14],[94,30],[84,44],[70,48],[66,62],[48,62],[40,48],[26,44]]};
const STEP={meadow:1,snowy:1,reef:2,ninja:2,number:3,gadget:5,rescue:5,dino:10,planet:10,village:3};
let SP=null;
function starUI(){if($('#gstar'))return;const d=el('div','ov','<div class="card" id="gsCard"><h2 id="gsH"></h2><div id="gsBox"></div><p id="gsMsg"></p><div class="btns"><button class="btn white" id="gsBack">Back</button></div></div>');d.id='gstar';document.body.appendChild(d);
  tap('#gsBack',()=>{sfx.boop();closeStars();});}
function closeStars(){$('#gstar').classList.remove('on');if(SP&&SP.lock!==false)player.lock=false;const cb=SP&&SP.cancel;SP=null;hush();if(cb)cb();}
function starPuzzle(o){starUI();const pts=o.pts,step=o.step||1,start=o.start!=null?o.start:step,lab=i=>start+i*step,n=pts.length;SP={o,i:0,lock:o.lock,cancel:o.cancel};$('#gsBack').style.display=o.noBack?'none':'';
  const bg=Array.from({length:40},(v,i)=>{const R=seed(i*7+3);return `<circle cx="${(R()*100).toFixed(1)}" cy="${(R()*75).toFixed(1)}" r="${(.2+R()*.35).toFixed(2)}" fill="#fff" opacity="${(.3+R()*.5).toFixed(2)}"/>`;}).join('');
  $('#gsBox').innerHTML=`<svg viewBox="0 0 100 75" id="gsSvg"><rect width="100" height="75" rx="4" fill="#141a3c"/>${bg}<g id="gsLines"></g><g id="gsPic" opacity="0">${o.pic||''}</g>`+
    pts.map((p,i)=>`<g class="gst" data-i="${i}"><circle cx="${p[0]}" cy="${p[1]}" r="5.4" fill="transparent"/><circle class="gsg" cx="${p[0]}" cy="${p[1]}" r="2" fill="#ffe680" opacity=".22"/><path d="M${p[0]} ${p[1]-1.6} L${p[0]+.5} ${p[1]-.5} L${p[0]+1.6} ${p[1]} L${p[0]+.5} ${p[1]+.5} L${p[0]} ${p[1]+1.6} L${p[0]-.5} ${p[1]+.5} L${p[0]-1.6} ${p[1]} L${p[0]-.5} ${p[1]-.5} Z" fill="#fff8d0"/><text x="${p[0]+(p[0]>88?-3.4:2.2)}" y="${p[1]+(p[1]<6?4.8:-2)}" font-size="3.4" font-weight="900" fill="#ffffff" font-family="Arial" text-anchor="${p[0]>88?'end':'start'}">${lab(i)}</text></g>`).join('')+`</svg>`;
  $('#gsH').textContent=o.title||'⭐ Join the stars!';const intro=o.say||`Tap the stars in order: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;$('#gsMsg').textContent=step===1?'Start at 1 and keep going!':`Count in ${step}s: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;speak(intro);
  const mark=()=>document.querySelectorAll('#gsSvg .gst').forEach(g=>g.classList.toggle('next',+g.dataset.i===SP.i));mark();
  document.querySelectorAll('#gsSvg .gst').forEach(g=>tap(g,()=>{if(!SP||SP.o!==o)return;const i=+g.dataset.i;
    if(i!==SP.i){if(i<SP.i)return;sfx.oops();const m=`Look for ${lab(SP.i)}.`;$('#gsMsg').textContent=m;speak(m);g.classList.remove('nope');void g.getBBox();g.classList.add('nope');return;}
    snd.note(i);g.classList.add('done');if(i>0){const a=pts[i-1],b=pts[i];$('#gsLines').insertAdjacentHTML('beforeend',`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#fff2a8" stroke-width=".8" stroke-linecap="round"/>`);}
    SP.i++;if(SP.i<n){mark();$('#gsMsg').textContent=`${lab(i)}! Next: ${lab(SP.i)}`;return;}
    if(o.loop!==false){const a=pts[n-1],b=pts[0];$('#gsLines').insertAdjacentHTML('beforeend',`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#fff2a8" stroke-width=".8" stroke-linecap="round"/>`);}
    if(o.loop!==false)$('#gsLines').insertAdjacentHTML('afterbegin',`<polygon points="${pts.map(p=>p.join(',')).join(' ')}" fill="#d8ff5a" opacity=".14"/>`);mark();$('#gsSvg').classList.add('win');$('#gsPic').setAttribute('opacity','1');snd.twinkle();confetti(24);const m=o.win||'You joined all the stars!';$('#gsMsg').textContent=m;speak(m);
    const done=o.done;SP.cancel=null;setTimeout(()=>{if(!$('#gstar').classList.contains('on'))return;$('#gstar').classList.remove('on');if(o.lock!==false)player.lock=false;SP=null;if(done)done();},o.hold||1900);}));
  $('#gstar').classList.add('on');}
function openStars(o){if(player.lock||xFound(o.p.id))return;player.lock=true;hush();snd.twinkle();const isl=o.p.island,sh=o.p.id==='foxfire'?'fox':['sit','run','head'][hsh(o.p.id)%3];
  let step=STEP[isl]||1;if(isl==='number'&&typeof tablesOn==='function'){const tb=tablesOn();if(tb&&tb.length)step=pick(tb);}
  starPuzzle({pts:SHAPES[sh],step,title:o.p.id==='foxfire'?'⭐ Join the stars to make a fox!':'⭐ Join the stars to make a pup!',
    say:`Starlight! Join the stars in order to draw a picture in the sky.${step>1?` Count in ${step}s!`:''}`,win:o.p.id==='foxfire'?'A fox in the stars, sweeping its tail!':'A pup in the stars! Look, it is pointing down at the ground...',
    done:()=>{beam(o.x,o.z);setTimeout(()=>{markFound(o);found(o.p,'stars',o);},900);}});}
function beam(x,z){const m=new THREE.MeshBasicMaterial({color:'#fff6c2',transparent:true,opacity:.0,depthWrite:false,blending:THREE.AdditiveBlending}),b=new THREE.Mesh(G.cyl,m);b.scale.set(1.4,40,1.4);b.position.set(x,gy(x,z)+20,z);W.ag.add(b);W.disp.push(m);
  let t=0;W.ticks.push(dt=>{t+=dt;m.opacity=t<.5?t*1.2:Math.max(0,.6-(t-.5)*.35);if(t>2.3){W.ag.remove(b);return true;}});snd.whoosh();}

/* ================= finding a Night Glow pup ================= */
function found(p,how,o){const X=GS();if(X.found[p.id])return;X.found[p.id]=Date.now();X.how[p.id]=how;state.stars+=10;W.findT=W.t;W.trail.forEach(t=>W.ag.remove(t));W.trail=[];save();hud();
  const P=player,dx=P.x-o.x,dz=P.z-o.z,d=Math.hypot(dx,dz)||1,g=pup3D(p,p.shiny);add(g,o.x+dx/d*1.9,o.z+dz/d*1.9);g.rotation.y=Math.atan2(-dx,-dz)+PI;g.userData.jump=.8;
  player.cheer=1.3;player.wave=2.4;sfx.jingle();confetti(36);W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});
  const n=nFound(),where={swarm:'where the fireflies gathered',prints:'at the end of its glowing paw prints',stars:'under the starlight'}[how]||'';
  card({art:pupBox(gp(p)),h:`You found ${p.name}!`,h3:`🌙 Night Glow · ${p.breed} ${typeBadge(p.type)}`,p:FACT[p.id]||p.fact,say:`You found ${p.name}, ${where}! ${FACT[p.id]||''}`,
    btns:[['✨ Fireflies, come home!','green',()=>{W.ag.remove(g);flyHome(o);setTimeout(()=>after(p,n),900);}]]});
  if(window.GSTORY&&GSTORY.onFind)try{GSTORY.onFind(p);}catch(e){}}
function flyHome(o){if(!FLY.g)return;const A=W.area,L=[];for(let i=0;i<5;i++){const s=new THREE.Sprite(glowMat(LIME,.95));s.scale.set(.6,.6,1);scene.add(s);L.push(s);}let k=0;const x0=o.x,z0=o.z;
  W.ticks.push(dt=>{k+=dt*.9;const e=Math.min(1,k);L.forEach((s,i)=>{const q=Math.max(0,Math.min(1,e*1.3-i*.06)),x=x0+(FLY.x-x0)*q+Math.sin(W.t*5+i)*.4,z=z0+(FLY.z-z0)*q+Math.cos(W.t*4+i)*.4;s.position.set(x,gy(x,z)+2+Math.sin(q*PI)*3+i*.2,z);});
    if(e>=1||W.area!==A){L.forEach(s=>{scene.remove(s);s.material.dispose();});if(e>=1){snd.blink();FLY.boost=1.5;FLY.jump=.5;}return true;}});}
function after(p,n){const I=islandOf(p.island);
  if(I&&islN(I)>=NEED&&!GS().fl[I.id]){setTimeout(()=>flash(I),400);return;}
  if(window.GSTORY&&GSTORY.afterFind&&GSTORY.afterFind(p,n))return;
  if(n===all().length){say(`Every single Night Glow pup is found! All ${n} of them! You are a star, Seb!`);return;}
  const A=W.area,L=areaX(A.id),left=L.filter(q=>!xFound(q.id)).length;
  say(`${n} of ${all().length} Night Glow pups found! `+(left?`${left} more ${left>1?'pups':'pup'} hiding in ${A.name}.`:`Every Night Glow pup in ${A.name} is found!`)+(I&&!GS().fl[I.id]?` Find ${NEED-islN(I)} more on ${I.name} for ${I.boss.uni.name}'s flash!`:''));}

/* ================= the nine flashes of the Glow Song ================= */
const LESSON={blossom:'Even the smallest light helps someone find their way.',flurry:'The dark is only the sky resting, and the stars come out to keep you company.',pearl:'You shine brightest when you are being yourself.',
 emberuni:'Being brave means being scared, and going anyway.',tally:'There are more stars than anyone can count, and every one of them matters.',gizmouni:'Sharing your light never makes it smaller.',
 beaconuni:'Look out for others in the dark, like a lighthouse.',amberuni:'Some lights travel a very long way to reach you, so be patient.',nebulauni:'Every star began as a little cloud of dust, so dream big.'};
function flash(I){const u=I.boss.uni,P=player,X=GS();player.lock=true;hush();
  const a=P.h+.7,x=P.x+Math.sin(a)*4.5,z=P.z+Math.cos(a)*4.5,g=pup3D(u,true);add(g,x,z);g.rotation.y=Math.atan2(P.x-x,P.z-z);g.userData.jump=.9;snd.twinkle();confetti(30);floatS('✨',x,gy(x,z)+4,z,3);
  W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});const n=nFl()+1,F=fly().name;
  story([{art:`<div class="fitsvg">${critterSVG(gp(u))}</div>`,t:`${u.name} is here, glowing softly. "Fireflies talk in flashes. You found ${NEED} night pups on ${I.name}, so I will teach ${F} a flash of the Glow Song, the call that every firefly answers."`},
    {art:`<div class="fitsvg">${critterSVG(gp(u))}</div><div style="font-size:64px;line-height:1">✨</div>`,t:`"And here is a night-time lesson to keep: ${LESSON[u.id]||'Every light matters.'}"`},
    {art:`<div class="fitsvg" style="width:170px">${flySVG({glow:n})}</div><div class="gnotes">${'✨'.repeat(Math.min(n,9))}${'·'.repeat(9-Math.min(n,9))}</div>`,t:`${F} flashes the new note: blink! ${n} of 9 flashes learned.`+(n===9?` ${F} knows the whole Glow Song!`:` ${F}'s light grows a little brighter.`)}],
    ()=>{X.fl[I.id]=Date.now();save();W.ag.remove(g);player.lock=false;FLY.jump=1;sfx.fanfare();snd.song(n);confetti(40);hud();
      if(window.GSTORY&&GSTORY.onFlash)try{GSTORY.onFlash(I,n);}catch(e){}
      if(n<9)say(`${n} of 9 flashes of the Glow Song! Find ${NEED} Night Glow pups on each island to learn every flash.`);});}
function uniHome(IS){const B=IS.boss;if(!B||!B.uni||!(G0()&&G0().fl[IS.id]))return;if(W.bossUp===IS.id)return;W.bossUp=IS.id;const u=pup3D(B.uni,true);u.rotation.y=Math.atan2(-B.x,-B.z)+PI;add(u,B.x,B.z);col(B.x,B.z,1.4);
  W.ticks.push(()=>{animPup(u,W.t,false);});W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(`${B.uni.name} says: "${LESSON[B.uni.id]} Goodnight, Seb!"`);}});}

/* ================= Seb's firefly ================= */
const FLY={g:null,x:0,z:0,y:0,h:0,jump:0,boost:0,halo:null,tail:null,wings:[]};
function fly3D(){const g=grp(),b=grp();g.add(b);
  mk('sph','#5a4030',.22,.2,.32,0,0,0,b);mk('sph','#e8603a',.18,.12,.13,0,.07,.24,b);mk('sph','#3a2a20',.15,.14,.14,0,.02,.36,b);
  [-1,1].forEach(s=>{mk('sph','#ffffff',.065,.075,.05,s*.085,.06,.45,b,true);mk('sph','#26232e',.035,.045,.03,s*.088,.06,.49,b);const a=mk('cyl','#3a2a20',.015,.26,.015,s*.07,.2,.42,b);a.rotation.z=-s*.5;a.rotation.x=.4;});
  bakeModel(g,'gfly');
  const wm=new THREE.MeshLambertMaterial({color:'#eef6ff',transparent:true,opacity:.6,depthWrite:false}),wings=[-1,1].map(s=>{const w=new THREE.Mesh(G.sph,wm);w.scale.set(.05,.16,.3);w.position.set(s*.15,.17,-.02);b.add(w);return w;});
  const tm=new THREE.MeshBasicMaterial({color:LIME}),tail=new THREE.Mesh(G.sph,tm);tail.scale.set(.2,.18,.21);tail.position.set(0,-.04,-.28);b.add(tail);
  const halo=new THREE.Sprite(glowMat(LIME,.85));halo.scale.set(1.6,1.6,1);halo.position.set(0,-.04,-.3);b.add(halo);
  g.scale.setScalar(1.25);Object.assign(g.userData,{body:b,wings,tail,halo,wm,tm});g.traverse(o=>{o.frustumCulled=false;});return g;}
function useFly(g){FLY.g=g;FLY.wings=g.userData.wings;FLY.tail=g.userData.tail;FLY.halo=g.userData.halo;if(!g.parent)scene.add(g);}
function flyEnter(A){if(!named()){if(FLY.g)FLY.g.visible=false;return;}
  if(!FLY.g)useFly(fly3D());FLY.g.visible=true;const P=player,a=P.h+PI/2;FLY.x=P.x+Math.sin(a)*1.6;FLY.z=P.z+Math.cos(a)*1.6;FLY.h=P.h;
  W.things.push({x:FLY.x,z:FLY.z,r:3.2,icon:'💬',label:fly().name,gfly:1,show:()=>!followers.some(f=>Math.hypot(f.x-player.x,f.z-player.z)<2.3),act:flyTalk});
  W.ticks.push(flyTick);}
function flyHide(){if(FLY.g)FLY.g.visible=false;}
function nearest(){let best=null,bd=1e9;LIVE.forEach(o=>{if(xFound(o.p.id))return;const d=Math.hypot(player.x-o.x,player.z-o.z);if(d<bd){bd=d;best=o;}});return best?{o:best,d:bd}:null;}
function flyTick(dt){if(!FLY.g||!on())return true;if(!FLY.g.visible||FLY.script)return;const P=player,t=W.t,u=FLY.g.userData;
  const fx=Math.sin(P.h),fz=Math.cos(P.h),tx=P.x+fz*1.5-fx*.6,tz=P.z-fx*1.5-fz*.6,dx=tx-FLY.x,dz=tz-FLY.z,d=Math.hypot(dx,dz);
  if(d>.05){FLY.x+=dx*Math.min(1,dt*3.2);FLY.z+=dz*Math.min(1,dt*3.2);}if(d>26){FLY.x=tx;FLY.z=tz;}
  FLY.h=lerpAng(FLY.h,d>.3?Math.atan2(dx,dz):P.h,Math.min(1,dt*5));if(FLY.jump>0)FLY.jump-=dt;
  FLY.y=walkY(FLY.x,FLY.z)+2.5+Math.sin(t*2.2)*.3+(FLY.jump>0?Math.sin(FLY.jump*PI*1.6)*.8:0)+(W.area&&W.area.swim?.2:0);
  FLY.g.position.set(FLY.x+Math.sin(t*1.3)*.15,FLY.y,FLY.z);FLY.g.rotation.y=FLY.h;u.body.rotation.z=Math.sin(t*2)*.12;
  u.wings.forEach((w,i)=>{w.rotation.z=(i?1:-1)*(.3+Math.sin(t*38)*.5);});
  const th=W.things.find(q=>q.gfly);if(th){th.x=FLY.x;th.z=FLY.z;}
  /* warmer and colder: the tail glows faster near a hiding pup; brighter with every flash */
  const n=nearest(),k=n?Math.max(0,Math.min(1,1-n.d/45)):0,pl=.5+.5*Math.sin(t*(2+12*k)),lv=nFl();if(FLY.boost>0)FLY.boost-=dt;
  const sz=1.2+lv*.14+pl*(.3+.9*k)+(FLY.boost>0?FLY.boost:0);u.halo.scale.set(sz,sz,1);u.halo.material.opacity=.55+.4*pl;u.tail.scale.setScalar(.19*(1+.25*pl*k));
  if(n&&n.d<10&&t-(FLY.dingT||0)>3.2&&!P.lock&&!ovOpen()){FLY.dingT=t;snd.blink();}
  if(t-(FLY.factT||0)>140&&!P.lock&&!ovOpen()&&t-W.msgT>20){FLY.factT=t;say(`${fly().name} says: "${pick(FFACT)}"`);}}
const FFACT=['Did you know? Fireflies are beetles, not flies!','Did you know? My light is cold light: it hardly makes any heat at all.','Did you know? I make my light by mixing a special chemical called luciferin with oxygen, right inside my tail.',
 'Did you know? Every kind of firefly flashes its own pattern, like a secret code.','Did you know? In some places, thousands of fireflies flash all together at exactly the same moment!','Did you know? Baby fireflies glow too.'];
function dir(o){const P=player,a=Math.atan2(o.x-P.x,o.z-P.z),r=angDiff(a,W.camYaw),d=Math.hypot(o.x-P.x,o.z-P.z);
  const w=Math.abs(r)<.6?'straight ahead':Math.abs(r)>2.4?'behind you':r>0?'over to your left':'over to your right';return `${w}, ${d<12?'really close':d<30?'not far away':'a long way off'}`;}
function flyTalk(){if(player.lock)return;snd.blink();FLY.jump=.6;const F=fly().name,n=nearest(),A=W.area;
  if(n){const o=n.o,w=dir(o);say(o.k==='swarm'?`${F} says: "I can see fireflies gathering ${w}!"`:o.k==='stars'?`${F} says: "Starlight is shining on the ground ${w}!"`:`${F} says: "Glowing paw prints! They go ${w}. Let's follow them!"`);return;}
  const I=A.island&&islandOf(A.island),more=I?I.areas.filter(a=>areaX(a.id).some(p=>!xFound(p.id))):[];
  if(more.length)say(`${F} says: "Every pup here is found! I think I can see fireflies in ${more[0].name}."`);
  else if(I)say(`${F} says: "Every Night Glow pup on ${I.name} is found! Let's try another island."`);
  else{const left=ISLANDS.find(I2=>islX(I2).some(p=>!xFound(p.id)));say(left?`${F} says: "Let's look for Night Glow pups on ${left.name}!"`:`${F} says: "Goodnight, Seb! Sleep tight!"`);}}
/* a picture of the firefly, for cards and story scenes */
function flySVG(o){o=o||{};const K=INK,g=Math.min(9,o.glow==null?nFl():o.glow),r=34+g*2.2;
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><defs><radialGradient id="gfg"><stop offset="0" stop-color="#f4ffb0"/><stop offset=".45" stop-color="${LIME}" stop-opacity=".75"/><stop offset="1" stop-color="${LIME}" stop-opacity="0"/></radialGradient></defs>`+
   `<circle class="gfh" cx="100" cy="142" r="${r+26}" fill="url(#gfg)"/>`+
   `<ellipse cx="70" cy="74" rx="22" ry="44" transform="rotate(-38 70 74)" fill="#eef6ff" opacity=".75" stroke="${K}" stroke-width="3"/><ellipse cx="130" cy="74" rx="22" ry="44" transform="rotate(38 130 74)" fill="#eef6ff" opacity=".75" stroke="${K}" stroke-width="3"/>`+
   `<ellipse cx="100" cy="140" rx="30" ry="28" fill="${LIME}" stroke="${K}" stroke-width="4"/><path d="M74 128 Q100 138 126 128" stroke="#a8d83a" stroke-width="4" fill="none"/>`+
   `<ellipse cx="100" cy="104" rx="36" ry="30" fill="#5a4030" stroke="${K}" stroke-width="4"/><path d="M100 76 V132" stroke="#3a2a20" stroke-width="3"/>`+
   `<path d="M66 66 Q100 44 134 66 Q128 82 100 82 Q72 82 66 66 Z" fill="#e8603a" stroke="${K}" stroke-width="4"/>`+
   `<circle cx="100" cy="56" r="30" fill="#3a2a20" stroke="${K}" stroke-width="4"/><path d="M86 30 Q76 10 62 12 M114 30 Q124 10 138 12" stroke="${K}" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="62" cy="12" r="5" fill="#3a2a20"/><circle cx="138" cy="12" r="5" fill="#3a2a20"/>`+
   `<circle cx="88" cy="54" r="11" fill="#fff"/><circle cx="112" cy="54" r="11" fill="#fff"/><circle cx="90" cy="56" r="6" fill="#26232e"/><circle cx="114" cy="56" r="6" fill="#26232e"/><circle cx="92" cy="53" r="2.2" fill="#fff"/><circle cx="116" cy="53" r="2.2" fill="#fff"/>`+
   `<path d="M92 70 Q100 76 108 70" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="78" cy="66" r="4" fill="#ff8fb3" opacity=".7"/><circle cx="122" cy="66" r="4" fill="#ff8fb3" opacity=".7"/></svg>`;}

/* ================= the opening ================= */
const SUG=['Flicker','Blink','Wink','Beam','Glint','Ziggy'];
const cleanName=s=>{s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,18);return s?s.charAt(0).toUpperCase()+s.slice(1):'';};
const big=e=>`<div style="font-size:100px;line-height:1">${e}</div>`,fsv=(w,o)=>`<div class="fitsvg" style="width:${w||170}px">${flySVG(o)}</div>`;
function intro(){const X=GS();X.inv=1;save();player.lock=true;hush();
  story([{art:big('🌙🏡'),t:'After Christmas, the decorations are packed away, and night falls on Pawprint Village.'},
    {art:`<div class="fitsvg" style="width:150px">${grannySVG()}</div>`,t:'"Every night the Glow, our family of fireflies from Bluebell Wood, lights the paths down to the sea," says Granny Paws. "But tonight there isn\'t a single firefly! And the pups were playing glow tag... now they have run off into the dark!"'},
    {art:big('🌑'),t:'The village is very, very dark. Then, by the fountain, something tiny blinks...'}],
    ()=>{state.season='glow';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='glow'&&S.hide)try{S.hide();}catch(e){}});fadeTo(()=>{enterArea('village',[-5,17,PI]);arrive();},['🌙','Night Glow']);});}
function arrive(){const P=player,x=0,z=8;player.lock=true;W.camYaw=Math.atan2(x-P.x,z-P.z);P.h=W.camYaw;const s=new THREE.Sprite(glowMat(LIME,.95));s.scale.set(1,1,1);scene.add(s);let t=0;
  W.ticks.push(dt=>{t+=dt;const k=Math.min(1,t/3),bx=x+(P.x-x)*k*.7,bz=z+(P.z-z)*k*.7;s.position.set(bx+Math.sin(t*5)*.8*(1-k),gy(bx,bz)+5-k*2.4+Math.sin(t*7)*.3,bz);s.material.opacity=.5+.45*Math.sin(t*9);
    if(Math.floor(t*2.5)!==Math.floor((t-dt)*2.5))snd.blink();if(t>3.2){scene.remove(s);s.material.dispose();meet(bx,bz);return true;}});}
function meet(x,z){const D=fly3D();useFly(D);D.visible=true;FLY.x=x;FLY.z=z;FLY.y=gy(x,z)+2.6;D.position.set(x,FLY.y,z);D.rotation.y=Math.atan2(player.x-x,player.z-z);FLY.script=true;snd.blink();
  story([{art:fsv(190,{glow:0}),t:'It\'s a little firefly, wobbling in the air, with the tiniest glow you have ever seen!'},
    {art:fsv(190,{glow:0}),t:'"Swish, clink!" it squeaks. "Something swished past with a jar, and my whole family vanished! I was hiding in a flower, and my light was so small that nobody noticed me."'}],()=>nameCard(()=>scatter()));}
function nameCard(done){sfx.chime();
  card({art:fsv(160,{glow:0}),h:'Name your firefly!',p:`The little firefly doesn't have a name yet. What would you like to call it?<input id="gName" maxlength="18" autocomplete="off" placeholder="Type a name..."><span class="xSug">${SUG.map(s=>`<button class="opt">${s}</button>`).join('')}</span><span class="xSex"><button class="opt on" data-g="1">👧 Girl</button><button class="opt" data-g="0">👦 Boy</button></span>`,
    say:'The little firefly does not have a name yet. Type a name, or pick one. Is your firefly a girl or a boy?',
    btns:[['✓ That\'s the name!','green',()=>{const n=cleanName($('#gName').value)||pick(SUG),g=!!+(document.querySelector('#celeCard .xSex .on')||{dataset:{g:1}}).dataset.g;
      GS().fly={name:n,girl:g,at:Date.now()};save();sfx.fanfare();confetti(50);player.cheer=1.6;if(done)done();}]]});
  const inp=$('#gName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .xSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));
  document.querySelectorAll('#celeCard .xSex .opt').forEach(b=>tap(b,()=>{document.querySelectorAll('#celeCard .xSex .opt').forEach(q=>q.classList.toggle('on',q===b));sfx.boop();}));}
function scatter(){const F=fly().name;
  story([{art:fsv(170),t:`"Hello Seb! I'm ${F}!" ${F} wants to find the Glow, and the pups who ran off into the dark. Seb promises to help. ${F}'s tail glows faster when a hidden pup is near!`},
    {art:big('✨🐾⭐'),t:'A few fireflies got away, and they are keeping the hidden pups company: look for where the fireflies gather, and count them! Some pups leave glowing paw prints. Some wait under the starlight: join the stars to find them.'},
    {art:fsv(150)+big('🦄'),t:`Find 6 pups on an island, and its unicorn will teach ${F} a flash of the Glow Song, the call that every firefly answers.`}],
    ()=>{const X=GS();X.intro=Date.now();save();player.lock=false;FLY.script=false;flyEnter(W.area);hud();say(`Let's find the Night Glow pups! Take the ferry to Meadow Island, or any island you like. ${F} will come too!`);
      if(window.GSTORY&&GSTORY.onIntro)try{GSTORY.onIntro();}catch(e){}});}
/* the invitation, once Night Glow is open (Christmas Snow's invitation goes first) */
const _ea3=enterArea;enterArea=function(id,pos,msg){_ea3.apply(this,arguments);if(state.season||id!=='village'||!opened()||!state.intro)return;
  const xs=window.SEASONS.xmas;if(xs&&xs.opened()&&!(state.sx&&state.sx.xmas&&state.sx.xmas.inv))return;const X=G0();if(X&&(X.inv||X.fly))return;
  setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||state.season||!W.area||W.area.id!=='village')return;GS().inv=1;save();invite();},1700);};
function invite(){player.lock=true;sfx.chime();
  card({art:big('🌙✨'),h:'🌙 Night Glow is here!',p:'Night is falling on Pawprint Village, and something strange has happened to the fireflies. Shall we go and see?',
    btns:[['🌙 Yes, let\'s go!','green',()=>{player.lock=false;intro();}],['Not now','white',()=>{player.lock=false;say('Shake the Season Globe in the plaza whenever you want to play Night Glow!');}]]});}
function fromXmas(){if(named()){XM.setSeason('glow');return;}intro();}
/* the grown-ups switch */
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=$('#setCard');if(!c)return;const S=state.set;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`🌙 Open Night Glow early<div class="opts"><button class="opt${S.glowOpen?'':' on'}" data-x="0">Off</button><button class="opt${S.glowOpen?' on':''}" data-x="1">On</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=xmasDone()?'Night Glow is already open, because Christmas Snow is finished. Shake the Season Globe in the village plaza to switch seasons.':'Night Glow opens after Christmas Snow is finished. Turn this on to open it now: an invitation arrives the next time Seb is in the village.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt').forEach(b=>tap(b,()=>{S.glowOpen=b.dataset.x==='1';if(!S.glowOpen&&!xmasDone()&&state.season==='glow'){state.season=null;XM.rebuildPack();flyHide();openSettings.dirty='season';}save();sfx.boop();const d=openSettings.dirty;openSettings();if(d)openSettings.dirty=d;}));
  if(window.SEASONLOG&&state.slog&&state.slog.length){const h=document.createElement('div');h.className='snote';h.style.opacity='.75';h.textContent='Season history (for Claude): '+SEASONLOG.text(4);note.after(h);}};}

/* ================= the Star Map (the Season Calendar for Night Glow) ================= */
function starMap(){if(player.lock)return;sfx.chime();const n=nFound(),X=G0()||{fl:{}};
  const rows=ISLANDS.map(I=>`<div class="gmRow"><b>${I.icon}</b>${islX(I).map(p=>`<i class="${xFound(p.id)?'lit':''}">★</i>`).join('')}<em>${X.fl&&X.fl[I.id]?'✨':''}</em></div>`).join('')+
    `<div class="gmRow"><b>🌟</b>${[GP.foxfire,GP.dusk].map(p=>`<i class="${xFound(p.id)?'lit':''}">★</i>`).join('')}<em></em></div>`;
  card({cls:'gmap',h:`🗺️ The Star Map: ${n} of ${all().length}`,p:`A star lights up for every Night Glow pup you find. ✨ means that island's flash of the Glow Song is learned.<div class="gmGrid">${rows}</div>`,
    say:`${n} of ${all().length} Night Glow pups found, and ${nFl()} of 9 flashes of the Glow Song.`,btns:[['OK','green']]});}

/* ================= planning hiding spots (offline for glow_spots.js, and as a fallback) ================= */
function plan(A){const out={spots:{}};const L=areaX(A.id);if(!L.length)return out;const Gd=XM.grid(A,1),R=seed(hsh(A.id)+23),chosen=[];
  const avoid=[];(W.exits||[]).forEach(e=>avoid.push([e.x,e.z,9]));W.things.forEach(t=>{if(!t.gfly&&!t.xdeer)avoid.push([t.x,t.z,4.5]);});if(A.start)avoid.push([A.start[0],A.start[1],9]);
  L.forEach(p=>{if(p.spot)avoid.push([p.spot.x,p.spot.z,5]);if(p.tag)avoid.push([p.tag.x,p.tag.z,5]);const xs=(window.XSPOTS||{})[p.id];if(xs&&xs.x!=null)avoid.push([xs.x,xs.z,6]);});
  const okAt=(p,sep)=>{if(avoid.some(a=>Math.hypot(p[0]-a[0],p[1]-a[1])<a[2]))return false;if(chosen.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<sep))return false;return true;};
  const st=A.start?Gd.snap(A.start[0],A.start[1],1):Gd.snap(0,0,1);if(st<0)return out;const B0=Gd.bfs(st);
  const best=(B,mc,sep,lo,hi,ideal)=>{let bk=-1,bs=-1e9;for(let k=0;k<Gd.N;k++){if(Gd.clr[k]<mc||B.D[k]>=1e9||B0.D[k]>=1e9)continue;const d=B.D[k];if(d<lo||d>hi)continue;const p=Gd.xz(k);if(!okAt(p,sep))continue;
      const sp=chosen.length?Math.min(30,Math.min(...chosen.map(q=>Math.hypot(p[0]-q[0],p[1]-q[1])))):30,s=sp*.6-Math.abs(d-ideal)*.25+R()*6;if(s>bs){bs=s;bk=k;}}return bk;};
  L.forEach(p=>{const k=kindOf(p);
    if(k==='trail'){let a=p.spot?Gd.snap(p.spot.x,p.spot.z,1):-1;if(a<0||B0.D[a]>=1e9)a=st;const Ba=Gd.bfs(a),b=best(Ba,2,10,15,40,26);if(b<0)return;chosen.push(Gd.xz(b));
      const Bb=Gd.bfs(b);let c2=-1,bs=-1e9;const pa=Gd.xz(a);for(let q=0;q<Gd.N;q++){if(Gd.clr[q]<2||Bb.D[q]>=1e9)continue;const d=Bb.D[q];if(d<14||d>34)continue;const pq=Gd.xz(q);if(Math.hypot(pq[0]-pa[0],pq[1]-pa[1])<10||!okAt(pq,10))continue;const s=-Math.abs(d-22)*.3+R()*6;if(s>bs){bs=s;c2=q;}}
      if(c2<0)return;chosen.push(Gd.xz(c2));const P2=k2=>Gd.xz(k2).map(v=>+v.toFixed(1));
      out.spots[p.id]={k:'trail',a:P2(a),b:P2(b),c:P2(c2),ab:Gd.path(Ba,b),bc:Gd.path(Bb,c2)};}
    else{const kk=best(B0,k==='swarm'?3:2,12,12,140,40);if(kk<0)return;const q=Gd.xz(kk);chosen.push(q);out.spots[p.id]={k,x:+q[0].toFixed(1),z:+q[1].toFixed(1)};}});
  return out;}

/* ================= look and API ================= */
const css=document.createElement('style');css.textContent=`
#gpick,#gstar{z-index:60}#gpCard{max-width:960px;width:94%;background:#f3f5ff}#gpRow{display:flex;flex-wrap:wrap;justify-content:center;gap:14px;margin:12px 0}
#gpRow .gpr{background:#1b2452;border:4px solid #26232e;border-radius:22px;padding:6px;width:150px;height:160px;display:flex;align-items:flex-end;justify-content:center;cursor:pointer;transform-origin:50% 90%}
#gpRow .gpr.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #d8ff5a}#gpRow .gpr.open{background:#2a3470}
#gpRow .gpr .gsur{font-size:70px;line-height:1;animation:xpop .5s;color:#fff;display:flex;flex-direction:column;align-items:center}#gpRow .gpr .gsur small{font-size:16px;font-weight:800}
#gpRow .gpr .gpup{width:130px;animation:xpop .6s}#gpRow .gpr .gpup svg{width:100%;height:auto}#gpMsg,#gsMsg{min-height:34px;font-size:26px;font-weight:800}
#gsCard{max-width:980px;width:96%;background:#e9ecff}#gsBox svg{width:620px;max-width:100%;height:auto;display:block;margin:4px auto;border-radius:18px}#gsCard h2{margin:0}#gsCard{padding-top:14px;padding-bottom:12px}
#gsSvg .gst{cursor:pointer}#gsSvg .gst.next .gsg{opacity:1;animation:gsPulse 1s ease-in-out infinite;transform-box:fill-box;transform-origin:center}#gsSvg .gst.done .gsg{opacity:.9;fill:#d8ff5a}
#gsSvg .gst.nope{animation:gsNo .4s}#gsSvg.win line{stroke:#d8ff5a;filter:drop-shadow(0 0 1px #d8ff5a)}#gsPic{transition:opacity 1s}
@keyframes gsPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.6)}}@keyframes gsNo{0%,100%{transform:translateX(0)}30%{transform:translateX(-1px)}60%{transform:translateX(1px)}}
#gName{display:block;width:420px;margin:12px auto 8px;font-size:30px;font-weight:900;padding:10px 16px;border:4px solid #26232e;border-radius:18px;text-align:center;font-family:inherit;color:#26232e}
.gnotes{font-size:40px;line-height:1;letter-spacing:2px;color:#8a8fa8}.gfh{animation:gfPulse 1.6s ease-in-out infinite;transform-box:fill-box;transform-origin:center}@keyframes gfPulse{0%,100%{opacity:.75}50%{opacity:1}}
.gmGrid{margin-top:8px}.gmRow{display:flex;align-items:center;gap:3px;justify-content:center;margin:2px 0}.gmRow b{width:34px;font-size:24px}.gmRow em{width:28px;font-style:normal}
.gmRow i{width:22px;height:22px;font-style:normal;font-size:20px;line-height:22px;color:#3a4270;display:inline-block}.gmRow i.lit{color:#ffd23f;text-shadow:0 0 8px #ffd23f}`;
document.head.appendChild(css);
window.SEASONS.glow={id:'glow',order:2,name:'Night Glow',short:'Night Glow',icon:'🌙',tag:'🌙',card:['🌙','Night Glow cards'],lockShort:'After Christmas Snow',
  on,opened,named,nFound,total:()=>all().length,invite,hide:flyHide,
  book:{xp:gp,found:xFound,islX,islN,fact:id=>FACT[id],tag:'🌙',word:'Night Glow',isl:I=>`${I.name} at night`}};
const GLOW=window.GLOW={on,opened,named,GS,G0,all,gpup,xFound,nFound,islN,islX,areaX,nFl,fly,he,his,him,found,flySVG,fly3D,useFly,FLY,snd,plan,starMap,intro,fromXmas,invite,
  starPuzzle,SHAPES,swarmPts,glowMat,glowTex,beam,flyEnter,flyHide,LIVE:()=>LIVE,NEED,LESSON,kindOf,noSpots:false,SONG,phase};
})();
