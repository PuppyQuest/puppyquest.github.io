/* ===== Ground surfaces: Seb and the pups stand on paths, plazas, pads and steps instead of sinking into them =====
   groundPass(A) runs once after each area is built (from enterArea):
   1. Flat coloured patches lying on the ground (paths, plazas, rugs, crossings, floors) are bent to follow the
      drawn ground if it slopes, and remembered so gy() lifts anyone standing on one.
   2. Thin details lying on the ground (cobbles, stepping stones, road lines, drain covers, planks, puddles) are
      pressed flat and tilted to lie on the slope, so they no longer hide feet. Big thin pads stay level and are
      remembered as something to stand on.
   3. Low wide blocks near the ground (steps, slabs, pallets, launch pads) are remembered as something to stand on.
   The ground height itself (gy in game.js) follows the drawn ground mesh exactly, so characters also stop
   sinking where the ground is steep (the Rescue Bay beaches). */
const WATER_C=['#6cc6ef','#7fd3f0','#5fc4f0','#bfeeff','#9bdcff'];
function surfLift(x,z,b){let L=0;for(const s of W.lift){if(x<s.bx1||x>s.bx2||z<s.bz1||z>s.bz2)continue;let d;
    if(s.r!=null)d=Math.hypot(x-s.x,z-s.z)-s.r;
    else{const dx=x-s.x,dz=z-s.z,u=dx*s.c+dz*s.s,v=-dx*s.s+dz*s.c;d=Math.max(Math.abs(u)-s.hu,Math.abs(v)-s.hv);}
    if(d>=.35)continue;const h=s.top!=null?s.top-b:s.off;if(h<=0)continue;const v=d<=0?h:h*(1-d/.35);if(v>L)L=v;}return L;}
function surfRec(x,z,ry,hu,hv,r){const c=Math.cos(ry),s=Math.sin(ry);if(r!=null)return {x,z,r,bx1:x-r-.4,bx2:x+r+.4,bz1:z-r-.4,bz2:z+r+.4};
  const e=Math.abs(hu*c)+Math.abs(hv*s)+.4,f=Math.abs(hu*s)+Math.abs(hv*c)+.4;return {x,z,c:Math.cos(-ry),s:Math.sin(-ry),hu,hv,bx1:x-e,bx2:x+e,bz1:z-f,bz2:z+f};}
const yawOf=q=>Math.atan2(2*(q.w*q.y+q.x*q.z),1-2*(q.y*q.y+q.x*q.x));
function groundPass(A){
  W.lift=null;const lift=[],up=new THREE.Vector3(),q=new THREE.Quaternion(),sc=new THREE.Vector3(),ps=new THREE.Vector3(),M4=new THREE.Matrix4(),nrm=new THREE.Vector3(),qt=new THREE.Quaternion(),Y=new THREE.Vector3(0,1,0);
  W.ag.updateMatrixWorld(true);
  /* 1. flat patches */
  for(const m of W.ag.children){
    if(!m.isMesh||m.isInstancedMesh||!m.geometry||!m.material||Array.isArray(m.material))continue;const t=m.geometry.type;
    if(t!=='PlaneGeometry'&&t!=='CircleGeometry')continue;const mt=m.material;
    if(mt.type!=='MeshLambertMaterial'||mt.transparent||mt.map||mt.vertexColors)continue;if(WATER_C.includes('#'+mt.color.getHexString()))continue;
    const N0=m.geometry.attributes.normal;if(!N0||N0.getY(0)<.98)continue;up.set(0,1,0).transformDirection(m.matrixWorld);if(up.y<.98)continue;
    m.matrixWorld.decompose(ps,q,sc);const pr=m.geometry.parameters,off=ps.y-gy(ps.x,ps.z);if(off<-.05||off>.2)continue;
    const ry=yawOf(q),o=Math.max(.035,off);let rec,hu,hv;
    if(t==='CircleGeometry'){const r=(pr.radius||1)*Math.max(sc.x,sc.z);if(r>40)continue;rec=surfRec(ps.x,ps.z,0,0,0,r);}
    else{hu=(pr.width||1)*sc.x/2;hv=(pr.height||1)*sc.z/2;if(hu*hv>1200)continue;rec=surfRec(ps.x,ps.z,ry,hu,hv);}
    rec.off=o;
    /* bend it to follow the ground if the ground under it is not flat */
    const c=Math.cos(ry),s=Math.sin(ry),pts=rec.r!=null?[[rec.r,0],[-rec.r,0],[0,rec.r],[0,-rec.r],[rec.r*.7,rec.r*.7],[-rec.r*.7,-rec.r*.7],[rec.r*.5,0],[0,-rec.r*.5]]:[[hu,hv],[-hu,hv],[hu,-hv],[-hu,-hv],[0,hv],[0,-hv],[0,hv*.5],[0,-hv*.5]];
    let dev=Math.abs(off-o);const g0=gy(ps.x,ps.z);for(const p of pts){const x=ps.x+(rec.r!=null?p[0]:p[0]*c+p[1]*s),z=ps.z+(rec.r!=null?p[1]:-p[0]*s+p[1]*c);dev=Math.max(dev,Math.abs(gy(x,z)-g0));}
    if(dev>.015){let geo;if(rec.r!=null){geo=new THREE.RingGeometry(.001,1,32,Math.max(2,Math.ceil(rec.r/1.2)));if(pr.radius)geo.scale(pr.radius,pr.radius,1);}
      else geo=new THREE.PlaneGeometry(pr.width||1,pr.height||1,Math.max(1,Math.ceil(hu*2/.9)),Math.max(1,Math.ceil(hv*2/.9)));
      geo.rotateX(-Math.PI/2);/* lie flat like the original, then set each corner to the ground height in the mesh's own space */
      const P=geo.attributes.position,inv=new THREE.Matrix4().copy(m.matrixWorld).invert(),v=new THREE.Vector3();
      for(let i=0;i<P.count;i++){v.set(P.getX(i),P.getY(i),P.getZ(i)).applyMatrix4(m.matrixWorld);v.y=gy(v.x,v.z)+o;v.applyMatrix4(inv);P.setXYZ(i,v.x,v.y,v.z);}
      geo.computeVertexNormals();m.geometry=geo;W.disp.push(geo);}
    else if(o>off)m.position.y+=o-off;
    lift.push(rec);}
  W.lift=lift;/* paths count from here on, so details on a path lie on the path */
  /* 2 and 3. thin details and low wide blocks (instanced boxes and cylinders) */
  for(const m of W.ag.children){if(!m.isInstancedMesh||!m.material||m.material.transparent)continue;const t=m.geometry.type;if(t!=='BoxGeometry'&&t!=='CylinderGeometry')continue;
    if(!m.geometry.boundingBox)m.geometry.computeBoundingBox();const bb=m.geometry.boundingBox,gh=bb.max.y-bb.min.y,gw=bb.max.x-bb.min.x,gd=bb.max.z-bb.min.z;let ch=false;
    for(let i=0;i<m.count;i++){m.getMatrixAt(i,M4);M4.decompose(ps,q,sc);if(Math.abs(q.x)>.05||Math.abs(q.z)>.05)continue;
      const h=gh*sc.y,w=gw*sc.x,d=gd*sc.z,g=gy(ps.x,ps.z),top=ps.y+h/2,mn=Math.min(w,d);
      if(h<=.09&&mn<3.2&&top-g>=.025&&top-g<=.22){
        /* press flat and lie on the slope */
        const e=Math.max(.4,Math.min(w,d)/2);nrm.set(gy(ps.x-e,ps.z)-gy(ps.x+e,ps.z),2*e,gy(ps.x,ps.z-e)-gy(ps.x,ps.z+e)).normalize();
        qt.setFromUnitVectors(Y,nrm);q.premultiply(qt);sc.y=Math.max(.001,.018/gh);ps.y=g+.014;M4.compose(ps,q,sc);m.setMatrixAt(i,M4);ch=true;}
      else if(h<=.45&&mn>=.8){/* a low wide block or pad, maybe part buried in a slope: stand on it where it is above the ground */
        const ry=yawOf(q),c=Math.cos(ry),s2=Math.sin(ry),hw=w/2*.9,hd=d/2*.9;let lo=g,hi=g;
        for(const k of [[hw,hd],[-hw,hd],[hw,-hd],[-hw,-hd]]){const gg=gy(ps.x+k[0]*c+k[1]*s2,ps.z-k[0]*s2+k[1]*c);lo=Math.min(lo,gg);hi=Math.max(hi,gg);}
        if(top-lo>=.025&&top-hi<=.45)lift.push(Object.assign(surfRec(ps.x,ps.z,ry,w/2,d/2,t==='CylinderGeometry'?mn/2:null),{top}));}}
    if(ch)m.instanceMatrix.needsUpdate=true;}
  W.lift=lift.length?lift:null;}
