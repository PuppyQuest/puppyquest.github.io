/* Ninja Mountains look (22 Nov 2026): day to night as Seb climbs.
   Dojo and Bamboo Forest: red rock canyon in daylight. Ice, Fire and
   Thunder Temples: sunset. Dragon Peak: night, with the moon, stars,
   fireflies and a lantern for Seb. The Glow Cave is unchanged. */
(function(){
const strata=(x,z)=>{const v=Math.sin(x*.05+z*.11)*.5+Math.sin(z*.23+x*.02)*.3+.5;return v>.62?1:v<.32?0:(v-.32)/.3;};
const RED={c:['#b5564a','#a04a3e','#c9805a'],band:'#e8a878',h:[6,11]};
const SUN={az:218,el:7,size:80};
restyle('dojo',{ground:'#b8664a',ground2:'#d4946a',gmix:strata,sky:'#a8d4f0',fogC:'#f0d8c4',fog:[70,240],light:'canyon',edge:Object.assign({style:'cliff'},RED),backdrop:{style:'mesas'},biome:'canyon',hedgeC:'#8a4a3a',noEdgeTrees:true});
restyle('bamboo',{ground:'#a8664a',ground2:'#7a8a4a',gmix:(x,z)=>{const v=Math.sin(x*.09)*Math.cos(z*.08)*.6+.5;return v>.7?1:v<.4?0:(v-.4)/.3;},sky:'#b4dcf0',fogC:'#ecdcc6',fog:[60,220],light:'canyon',
  edge:Object.assign({style:'cliff'},RED),backdrop:{style:'mesas'},hedgeC:'#8a4a3a',noEdgeTrees:true});
restyle('icet',{sky:'#f4ae8a',fogC:'#f8c6a6',fog:[60,220],light:'sunset',edge:{style:'cliff',c:['#8a8f99','#9aa0a8','#7a8088'],band:'#b6bcc6',cap:'#ffffff',h:[6,10]},
  mtnCols:['#c0a8bc','#b098ae'],skyObj:{sun:SUN},hedgeC:'#7a8088',noEdgeTrees:true});
restyle('firet',{ground:'#5e4844',ground2:'#70544a',sky:'#e8744a',fogC:'#f0946a',fog:[55,200],light:{sky:'#ffbc94',gr:'#6a3040',hi:.6,dir:'#ff7a40',di:.66,pos:[-90,22,-70]},
  edge:{style:'cliff',c:['#3a3338','#4a3a40','#2e2630'],band:'#7a2e2a',h:[6,11]},skyObj:{sun:{az:218,el:5,size:100}},hedgeC:'#4a3a40',noEdgeTrees:true});
restyle('thunder',{ground:'#8a8494',ground2:'#9a94a4',gmix:strata,sky:'#7e5e8e',fogC:'#8e6e9c',fog:[55,200],light:'storm',biome:'canyon',
  pal:{grass:['#8a8a6a','#7a7a5a','#9a9a7a'],rock:['#6b6478','#7a7488','#8a8378'],tree:['#a8506a','#8a4a7a'],hoodoo:['#6b6478','#8a8a98','#5b5468'],crack:'#3a3448',bush:['#6a7a5a','#5a6a4a']},
  edge:{style:'cliff',c:['#6b6478','#5b5468','#7a7488'],band:'#9a8aa8',h:[6,11]},mtnCols:['#4a4058','#5a4a68'],hedgeC:'#5b5468',noEdgeTrees:true});
restyle('peak',{ground:'#5a5a70',ground2:'#6a6a80',gmix:strata,sky:'#141a3c',fogC:'#1e2650',fog:[45,210],light:'night',biome:'canyon',cloudC:'#2c3466',
  pal:{grass:['#5a6a5a','#4a5a4a','#6a7a6a'],rock:['#4a4560','#5a5570','#3a3550'],tree:['#a03040'],hoodoo:['#3a3550','#5a5070','#4a4560'],crack:'#22203a',bush:['#3a4a3a','#4a5a4a'],pine:'#2a4a3a'},
  edge:{style:'cliff',c:['#3a3550','#2f2a44','#4a4560'],band:'#5a5070',cap:'#c8d0e8',h:[5,9]},backdrop:{style:'mesas',c:['#262444','#2e2a4e','#22203c'],band:'#34305a'},
  skyObj:{moon:{az:250,el:26,size:52},stars:true,flies:40},hedgeC:'#3a3550',noEdgeTrees:true},
  A=>{/* glowing lanterns round the golden shrine */[[-8.5,-26],[8.5,-26],[-8.5,-34],[8.5,-34]].forEach(p=>{const y=gy(p[0],p[1]);I('box','#a9a399',.8,.3,.8,p[0],y+.15,p[1]);I('box','#a9a399',.3,1.4,.3,p[0],y+1,p[1]);I('box','#ffd27a',.6,.6,.6,p[0],y+2,p[1],0,0,0,true);I('pyr','#8a8378',.75,.5,.75,p[0],y+2.6,p[1],0,Math.PI/4,0);col(p[0],p[1],.5);});});
})();
