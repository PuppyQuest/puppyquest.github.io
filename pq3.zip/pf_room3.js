/* ================================================================
   Puppy Families (26 Nov 2026, claude/puppy-families-design.md sections 8, 14 and 16): growing up and extras.
   - care for wobbly puppies: Doctor Seb's check-up (eyes, heartbeat, counting the teeth: 12 + 4 + 12);
   - care for big puppies: Puppy School lessons (a hand signal, a try, a treat straight away), a family walk,
     bath and brush (the Pup Spa's own screen is closed code, so these happen in the Puppy Room);
   - the Puppy School Show (a memory game of tricks: 3, then 4, then 5) gives the family bandanas;
   - big-puppy families play beside their parent on their home island (3 families an area at most);
   - one big puppy can tag along behind Seb (picked in the Pup Book);
   - the sleepy break shows the puppies asleep; three Arcade activities; 8 badges; the Den's photo frame and
     Pup Book; "Puppy Bus Boogie" (an original tune) in the village while the bus is there.
   ================================================================ */
(function(){
const PL=window.PFLOOK,PF=window.PF,R=window.PFROOM,PI=Math.PI,P=id=>PUPS[id];
const S=()=>PF.S(),S0=()=>PF.S0()||{};
const big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`;
const unitEl=k=>document.querySelector(`#pfcStage .pfu[data-k="${k}"]`);
const msg=t=>R.msg(t);
let ARC=null;/* an Arcade run: {k,t0} */
function arcDone(k,title,art){if(!ARC||ARC.k!==k)return false;const secs=(Date.now()-ARC.t0)/1000;ARC=null;setTimeout(()=>finishAct(k,secs,art||big('🎓'),title,()=>ACTS[k].play(),false),300);return true;}
const mark=k=>{state.acts=state.acts||{};if(!state.acts[k]){state.acts[k]=1;save();}};
/* ---------------- Doctor Seb's check-up ---------------- */
function doctor(U,F){const c=$('#pfcCtl');let step=0;const T0=Date.now();
  const steps=[['🔦 Look in the eyes','Blue-grey eyes: just right for a young puppy! Their real colour shows at about 10 weeks old.'],['🩺 Listen to the heart','Thump-thump, thump-thump! A strong, fast little heartbeat.'],['🦷 Count the teeth','']];
  const go=()=>{if(step<2){c.innerHTML=`<button class="btn yellow pfbig" id="pfDoc">${steps[step][0]}</button>`;tap('#pfDoc',()=>{sfx.boop();const s=step;
      if(s===0)document.querySelectorAll('#pfcStage .pfu').forEach(e=>{e.querySelector('.pfov').innerHTML='<span class="pftorch">✨</span>';});
      else{document.querySelectorAll('#pfcStage .pfu').forEach(e=>{e.querySelector('.pfov').innerHTML='<span class="pfbeat">💓</span>';});try{const t=AC.currentTime;for(let i=0;i<3;i++){tone(70,t+i*.5,.12,'sine',.5);tone(60,t+i*.5+.16,.12,'sine',.4);}}catch(e){}}
      msg(steps[s][1]);step++;setTimeout(go,1800);});return;}
    const opts=R.shuffle([28,24,32]);c.innerHTML=`<div class="pfq">Puppies have <b>12</b> little front teeth, <b>4</b> pointy ones and <b>12</b> at the back. 12 add 4 add 12: how many teeth?<div class="pfans">${opts.map(v=>`<button class="btn blue" data-v="${v}">${v}</button>`).join('')}</div></div>`;
    speak('Puppies have 12 little front teeth, 4 pointy ones and 12 at the back. 12 add 4 add 12: how many teeth?');let w=0;
    c.querySelectorAll('.pfans .btn').forEach(b=>tap(b,()=>{if(b.classList.contains('nope'))return;const v=+b.dataset.v;if(v===28){b.classList.add('win');sfx.chime();msg('Yes! 28 baby teeth. Grown-up dogs have 42! Healthy and happy!');F.forEach(id=>{PF.famOf(id).doc=1;});mark('pfdoc');
        setTimeout(()=>{if(ARC&&ARC.k==='pfdoc'){R.closeCare();arcDone('pfdoc','Doctor Seb!',big('🩺'));return;}R.finish();},2000);return;}
      w++;b.classList.add('nope');sfx.oops();msg('Try 12 add 12 first: that makes 24. Then add the 4 pointy ones!');if(w>=2)c.querySelectorAll('.pfans .btn').forEach(q=>{if(+q.dataset.v===28)q.classList.add('hint');});}));};go();}
/* ---------------- Puppy School ---------------- */
const TRICKS=[['sit','Sit','✊','sits down'],['paw','Paw','🤚','gives a paw'],['down','Down','👇','lies down'],['spin','Spin','👆','spins round'],['roll','Roll over','🔄','rolls over'],['come','Come','👋','comes running']];
const OOPS=['rolls over instead!','sneezes!','chases its tail!','sits on its sister!','yawns a big yawn!','licks your hand!'];
function school(U,F){const c=$('#pfcCtl');const st=$('#pfcStage');
  c.innerHTML=`<div class="pftricks">${TRICKS.map(q=>`<button class="pftk" data-t="${q[0]}"><span>${q[2]}</span><b>${q[1]}</b></button>`).join('')}</div>`;msg('Pick a trick to teach. Show the hand signal!');
  c.querySelectorAll('.pftk').forEach(b=>tap(b,()=>{const k=b.dataset.t,T=TRICKS.find(q=>q[0]===k);sfx.boop();lesson(T);}));
  function lesson(T){let go=0;c.innerHTML=`<div class="pfsig">${T[2]} <b>${T[1]}!</b></div><button class="btn yellow pfbig" id="pfShow">${T[2]} Show the signal</button> <button class="btn green pfbig" id="pfTreat" style="display:none">🦴 Treat!</button>`;
    tap('#pfShow',()=>{sfx.boop();go++;$('#pfShow').style.display='none';
      if(go===1){const u=U[Math.floor(Math.random()*U.length)],e=unitEl(u.k);if(e){e.classList.add('flop');setTimeout(()=>e.classList.remove('flop'),900);}sfx.giggle();msg(`Oops! ${PF.nm(u.id,u.i)} ${OOPS[Math.floor(Math.random()*OOPS.length)]} Show the signal again.`);setTimeout(()=>{$('#pfShow').style.display='';},900);return;}
      st.classList.remove('t-'+T[0]);void st.offsetWidth;st.classList.add('t-'+T[0]);msg(`The puppies ${T[3].replace(/s /,' ').replace(/^(\w+)s\b/,'$1')}! Quick, give a treat straight away!`);$('#pfTreat').style.display='';});
    tap('#pfTreat',()=>{sfx.yip(1.9);$('#pfTreat').style.display='none';document.querySelectorAll('#pfcStage .pfu .pfov').forEach(o=>{o.innerHTML='<span class="pfbowl">🦴</span>';});
      if(go>=3){F.forEach(id=>{const f=PF.famOf(id);f.tr=f.tr||{};f.tr[T[0]]=1;});save();msg(`Clever puppies! They have learned "${T[1]}"!`);setTimeout(()=>R.finish(),1600);return;}
      msg('Good puppies! Rewarding straight away helps them learn. One more time!');setTimeout(()=>{st.classList.remove('t-'+T[0]);document.querySelectorAll('#pfcStage .pfu .pfov').forEach(o=>{o.innerHTML='';});$('#pfShow').style.display='';},1100);});}}
/* ---------------- a family walk; bath and brush ---------------- */
function walk(U){const c=$('#pfcCtl'),st=$('#pfcStage');let n=0,stop=null;st.classList.add('walky');c.innerHTML='<button class="btn yellow pfbig" id="pfWalk">🦮 Walk on! <span id="pfWk">○○○</span></button>';
  tap('#pfWalk',()=>{if(stop!=null)return msg(`Wait! ${PF.nm(U[stop].id,U[stop].i)} has stopped to sniff. Tap the puppy to call it!`);n++;sfx.boop();$('#pfWk').textContent='●'.repeat(n)+'○'.repeat(3-n);st.classList.remove('step');void st.offsetWidth;st.classList.add('step');
    if(n>=3){msg('Home again! Walks help puppies learn about the world: new sounds, new smells and new friends.');setTimeout(()=>R.finish(),1800);return;}
    stop=Math.floor(Math.random()*U.length);const e=unitEl(stop);setTimeout(()=>{if(e){e.classList.add('sniff');e.querySelector('.pfov').innerHTML='<span class="pfbowl">🌼</span>';}msg(`${PF.nm(U[stop].id,U[stop].i)} stops to sniff a flower. Tap the puppy to call it!`);},500);});
  R.onUnits((k,e)=>{if(k!==stop)return;sfx.yip(2);e.classList.remove('sniff');e.querySelector('.pfov').innerHTML='';stop=null;msg('Come! Good puppy! Walk on!');});}
function bath(U){const c=$('#pfcCtl');const n={};c.innerHTML='<div class="pfshh">🫧 Tap each puppy to make bubbles!</div>';
  R.onUnits((k,e)=>{n[k]=(n[k]||0)+1;if(n[k]>3)return;sfx.pop();const b=document.createElement('span');b.className='pfbub2';b.textContent='🫧';b.style.left=(20+Math.random()*50)+'%';b.style.top=(10+Math.random()*50)+'%';e.querySelector('.pfov').appendChild(b);
    if(Object.keys(n).length>=U.length&&Object.values(n).every(v=>v>=3)){msg('Squeaky clean! Now the towel and the brush.');c.innerHTML='<button class="btn yellow pfbig" id="pfTowel">🧺 Towel and brush</button>';
      tap('#pfTowel',()=>{sfx.chime();document.querySelectorAll('#pfcStage .pfu').forEach(q=>{q.querySelector('.pfov').innerHTML='<span class="pfsparkle">✨</span>';q.classList.add('fluffy');});msg('Fluffy and soft! Warm water and gentle puppy shampoo keep a puppy\'s coat clean.');setTimeout(()=>R.finish(),1800);});}});}
const CARE={doctor:{st:[1,2],icon:'🩺',name:'Doctor Seb',how:'Check the puppies with your vet kit: eyes, heart and teeth!',fact:'Puppies have 28 baby teeth, and grown-up dogs have 42. Baby teeth fall out, just like yours!',mini:doctor},
  school:{st:[2],icon:'🎓',name:'Puppy School',how:'Teach the puppies a trick: show the hand signal, then give a treat straight away!',fact:PL.FACT[2][2],mini:school},
  walk:{st:[2],icon:'🦮',name:'Family walk',how:'Take the family for a walk. Puppies love to stop and sniff!',fact:'Walks help puppies learn about the world: new sounds, new smells and new friends.',mini:walk},
  bath:{st:[2],icon:'🫧',name:'Bath and brush',how:'A warm, bubbly bath, then a towel and a brush.',fact:'Warm water and gentle puppy shampoo keep a puppy\'s coat clean and soft.',mini:bath}};
/* ---------------- the Puppy School Show: a memory game of tricks ---------------- */
function ui(){if($('#pfshow'))return;const d=el('div','ov pfov2','<div class="card pftrick" id="pfsCard"><h2>🎪 The Puppy School Show</h2><p id="pfsTip"></p><div id="pfsStage"></div><div class="pftricks" id="pfsBtns"></div><p class="pfmsg" id="pfsMsg"></p><div class="btns"><button class="btn white" id="pfsBack">Back</button></div></div>');d.id='pfshow';document.body.appendChild(d);
  tap('#pfsBack',()=>{sfx.boop();d.classList.remove('on');player.lock=false;SH=null;ARC=null;});}
let SH=null;
function showFams(){const L=R.roomIds().filter(id=>PF.stg(id)===2);return L.length?L:PF.homes().filter(id=>PF.stg(id)===2);}
function openShow(arc){const F=showFams();if(!F.length&&!arc){say('The Puppy School Show is for bouncy big puppies!');return;}ui();player.lock=true;hush();if(arc)ARC={k:'pfshow',t0:Date.now()};
  const id=(F[0]||PF.homes()[0]||'buttercup'),p=P(id);SH={id,F,len:3,seq:[],pos:0,busy:0,slow:1};
  $('#pfsStage').innerHTML=`<div class="pfstar"><div class="pfshowpup">${PL.svg(p,0,2,{anim:false,bd:1})}</div><div class="pfsigbig" id="pfsSig"></div></div>`;
  $('#pfsBtns').innerHTML=TRICKS.map(q=>`<button class="pftk" data-t="${q[0]}"><span>${q[2]}</span><b>${q[1]}</b></button>`).join('');
  $('#pfshow').classList.add('on');$('#pfsTip').textContent=`${PF.nm(id,0)} will do some tricks. Watch carefully, then tap the hand signals in the same order!`;
  document.querySelectorAll('#pfsBtns .pftk').forEach(b=>tap(b,()=>press(b.dataset.t)));setTimeout(round,900);}
function round(){if(!SH)return;SH.seq=[];for(let i=0;i<SH.len;i++){let t;do{t=TRICKS[Math.floor(Math.random()*TRICKS.length)][0];}while(i&&t===SH.seq[i-1]);SH.seq.push(t);}SH.pos=0;play();}
function play(){if(!SH)return;SH.busy=1;$('#pfsMsg').textContent=`Watch! ${SH.len} tricks...`;speak(`Watch! ${SH.len} tricks.`);const pup=document.querySelector('#pfsStage .pfstar'),sig=$('#pfsSig'),gap=1100*SH.slow;
  SH.seq.forEach((t,i)=>setTimeout(()=>{if(!SH)return;const T=TRICKS.find(q=>q[0]===t);sig.innerHTML=`${T[2]}<b>${T[1]}</b>`;pup.classList.remove(...TRICKS.map(q=>'t-'+q[0]));void pup.offsetWidth;pup.classList.add('t-'+t);sfx.boop();},i*gap+300));
  setTimeout(()=>{if(!SH)return;sig.innerHTML='❓';pup.classList.remove(...TRICKS.map(q=>'t-'+q[0]));SH.busy=0;$('#pfsMsg').textContent='Your turn! Tap the signals in the same order.';speak('Your turn!');},SH.seq.length*gap+500);}
function press(t){if(!SH||SH.busy)return;const want=SH.seq[SH.pos],T=TRICKS.find(q=>q[0]===t),pup=document.querySelector('#pfsStage .pfstar');
  if(t===want){SH.pos++;sfx.pop();pup.classList.remove(...TRICKS.map(q=>'t-'+q[0]));void pup.offsetWidth;pup.classList.add('t-'+t);$('#pfsSig').innerHTML=`${T[2]}<b>${T[1]}</b>`;
    if(SH.pos>=SH.seq.length){sfx.chime();confetti(30);if(SH.len>=5)return won();SH.len++;SH.slow=1;$('#pfsMsg').textContent=`Brilliant! Now ${SH.len} tricks!`;speak(`Brilliant! Now ${SH.len} tricks!`);SH.busy=1;setTimeout(round,1600);}return;}
  sfx.giggle();SH.busy=1;pup.classList.add('flopx');$('#pfsMsg').textContent='The puppy flops over, giggling! Watch again, a bit slower.';speak('Watch again, a bit slower.');SH.slow=1.4;SH.pos=0;setTimeout(()=>{pup.classList.remove('flopx');play();},1400);}
function won(){const F=SH.F;F.forEach(id=>{PF.famOf(id).bd=1;});mark('pfshow');save();const was=SH;SH=null;$('#pfshow').classList.remove('on');player.lock=false;
  if(arcDone('pfshow','The Puppy School Show!',big('🎪')))return;
  sfx.fanfare();confetti(60);card({art:F.length?`<div class="pfpile2">${F.slice(0,2).map(id=>R.pile(id,2,false)).join('')}</div>`:big('🎀'),h:'⭐ Puppy School Stars!',p:F.length?`Five tricks in a row! ${F.map(id=>P(id).name+'\'s puppies').join(' and ')} get their Puppy School bandanas!`:'Five tricks in a row! What a show!',btns:[['🎉 Hooray!','green',()=>{if(W.area&&W.area.id==='pfroom')enterArea('pfroom',[player.x,player.z,player.h],'');}]]});}
/* ---------------- the Puppy Room extras: the school mat ---------------- */
function build(){I('box','#ffe680',3.4,.06,2.6,8.6,.06,-2.4);spr('🎓',1,8.6,1.6,-2.4);const l=label('🎓 Puppy School',3.8);l.position.set(8.6,2.6,-2.4);W.ag.add(l);
  W.things.push({x:8.6,z:-2.4,r:2.8,icon:'🎓',label:'Puppy School',act:schoolMenu});
  I('box','#ffffff',1.2,.8,.9,-10.6,.4,-2);spr('🩺',.9,-10.6,1.3,-2);W.things.push({x:-10.2,z:-2,r:2.6,icon:'🩺',label:'Doctor Seb',act:()=>{const L=R.roomIds().filter(id=>PF.stg(id)>=1);if(!L.length)return say('Doctor Seb\'s check-up is for puppies with their eyes open.');R.run('doctor',L.slice(0,2),PF.stg(L[0]));}});}
function schoolMenu(){if(player.lock)return;const L=R.roomIds().filter(id=>PF.stg(id)===2);if(!L.length)return say('Puppy School is for bouncy big puppies. Look after the puppies, and they will grow!');
  card({art:big('🎓'),h:'Puppy School',p:'Teach a trick in a lesson, or put on the Puppy School Show: a memory game of tricks. Do the show to win the family bandanas!',
    btns:[['📚 A lesson','green',()=>R.run('school',L,2)],['🎪 The show','blue',()=>openShow(false)],['Not now','white']]});}
/* ---------------- big-puppy families out on their islands ---------------- */
const _bs=buildSpots;buildSpots=function(A){_bs(A);if(state.season||!PF.begun()||!A.island)return;try{out(A);}catch(e){console.warn('pf out',e);}};
let LASTOUT=0;function out(A){const L=PL.all().filter(p=>p.area===A.id&&PF.home(p.id)&&PF.stg(p.id)===2&&R.roomIds().indexOf(p.id)<0).slice(0,3),Rn=seed(77);LASTOUT=L.length;
  L.forEach(p=>{const Q=(window.PFSPOTS||{})[p.id];if(!Q)return;const c=Q.a,f=PF.famOf(p.id),g=pup3D(p,p.shiny||bestFriend(p.id));g.rotation.y=Rn()*6;add(g,c[0],c[1]);col(c[0],c[1],.9);W.ticks.push(()=>animPup(g,W.t,false));
    [0,1,2].forEach(i=>{const q=PL.p3(p,i,2,{bd:f.bd}),w={x:c[0]+Math.cos(i*2.1)*1.5,z:c[1]+Math.sin(i*2.1)*1.5,tx:0,tz:0,wait:Rn()*2,h:0};w.tx=w.x;w.tz=w.z;add(q,w.x,w.z);
      W.ticks.push(dt=>{w.wait-=dt;const dx=w.tx-w.x,dz=w.tz-w.z,d=Math.hypot(dx,dz);let mv=false;if(d>.15){mv=true;w.x+=dx/d*2.2*dt;w.z+=dz/d*2.2*dt;w.h=lerpAng(w.h,Math.atan2(dx,dz),Math.min(1,dt*6));}
        else if(w.wait<0){const a=Rn()*6.28,r=1+Rn()*1.8,t=resolve(c[0]+Math.cos(a)*r,c[1]+Math.sin(a)*r);w.tx=t[0];w.tz=t[1];w.wait=1.5+Rn()*4;}
        q.position.set(w.x,gy(w.x,w.z),w.z);q.rotation.y=w.h;PL.anim(q,W.t,mv);});});});}
/* ---------------- a puppy tags along ---------------- */
const tagOf=()=>{const t=S0().tag;if(!t)return null;const [id,i]=t.split(':');return PF.home(id)&&PF.stg(id)===2?{id,i:+i}:null;};
const _ea=enterArea;enterArea=function(id,pos,msg2){_ea.apply(this,arguments);const T=tagOf();if(!T||!W.area||W.area.swim||cur==='title')return;try{tagAlong(T);}catch(e){console.warn('pf tag',e);}};
let TAGON=0;function tagAlong(T){TAGON++;const p=P(T.id),q=PL.p3(p,T.i,2,{bd:(PF.famOf(T.id)||{}).bd});let x=player.x-1.5,z=player.z-1.5,h=0;add(q,x,z);
  W.ticks.push(dt=>{const a=player.h||0,tx=player.x-Math.sin(a)*2.6+Math.cos(a)*1.4,tz=player.z-Math.cos(a)*2.6-Math.sin(a)*1.4,dx=tx-x,dz=tz-z,d=Math.hypot(dx,dz);let mv=false;
    if(d>12){x=tx;z=tz;}else if(d>.4){mv=true;const sp=Math.min(d*3,11)*dt;x+=dx/d*sp;z+=dz/d*sp;h=lerpAng(h,Math.atan2(dx,dz),Math.min(1,dt*8));}
    q.position.set(x,gy(x,z),z);q.rotation.y=h;PL.anim(q,W.t,mv);});}
function tagBtn(id){if(PF.stg(id)!==2)return '';const T=tagOf();return T&&T.id===id?'<button class="btn white" id="pfbTag">🐾 Stop tagging along</button>':'<button class="btn blue" id="pfbTag">🐾 Tag along</button>';}
function tagHook(id){const b=$('#pfbTag');if(!b)return;tap(b,()=>{const T=tagOf();sfx.boop();if(T&&T.id===id){S().tag=null;save();say('Back to the Puppy Room!');PFBOOK.draw();return;}
  const c=document.createElement('div');c.className='pfren2';c.innerHTML=`<div class="pfrenBox"><h3>🐾 Which puppy would like to tag along?</h3><div class="pfbPups">${[0,1,2].map(i=>`<button class="pfbPup" data-i="${i}"><div class="fitsvg">${PL.svg(P(id),i,2,{anim:false,bd:PF.famOf(id).bd})}</div><b>${PF.nm(id,i)}</b></button>`).join('')}</div><div class="btns"><button class="btn white" id="pfTgNo">Cancel</button></div></div>`;
  $('#pfbCard').appendChild(c);tap('#pfTgNo',()=>{sfx.boop();c.remove();});c.querySelectorAll('.pfbPup').forEach(q=>tap(q,()=>{const i=+q.dataset.i;S().tag=id+':'+i;save();sfx.yip(2);c.remove();PFBOOK.close();say(`${PF.nm(id,i)} will tag along behind you!`);if(W.area)enterArea(W.area.id,[player.x,player.z,player.h],'');}));});}
function tricks(id){const f=PF.famOf(id)||{},L=TRICKS.filter(q=>(f.tr||{})[q[0]]);return `<p class="pfbStk">Tricks: ${L.length?L.map(q=>`<span title="${q[1]}">${q[2]}</span>`).join(''):'<i>none yet</i>'}${f.bd?' · 🎀 bandanas':''}</p>`;}
/* ---------------- the sleepy break ---------------- */
{const base=showSleep;showSleep=function(){base.apply(this,arguments);if(!PF.begun())return;const id=R.roomIds()[0];if(!id)return;const a=$('#sleepArt');if(!a)return;const d=document.createElement('div');d.className='pfsleep';d.innerHTML=R.pile(id,PF.stg(id),true);a.appendChild(d);
  let cp=$('#pfSleepCap');if(!cp){cp=document.createElement('div');cp.id='pfSleepCap';a.parentNode.appendChild(cp);}cp.textContent='Puppies need lots of sleep to grow, and so do you!';};}
/* ---------------- Arcade activities ---------------- */
const where='the Puppy Room in Seb\'s Den';
regAct('pfshow',{name:'Puppy School Show',icon:'🎪',island:'meadow',area:'pfroom',where,lockSay:'Put on the Puppy School Show with some bouncy big puppies in the Puppy Room first!',play:()=>arcadeTravel('pfroom',null,()=>openShow(true),'Puppy School Show!')});
regAct('pfpiles',{name:'Puppy Piles',icon:'🧺',island:'meadow',area:'pfroom',where,lockSay:'Sort a puppy pile on the islands in Puppy Families first!',need:()=>PF.famIds().some(id=>(PF.famOf(id)||{}).how==='pile'),
  play:()=>arcadeTravel('pfroom',null,()=>{const H=PF.homes().slice().sort(()=>Math.random()-.5).slice(0,Math.min(3,Math.max(2,PF.homes().length)));const t0=Date.now();
    PFHUNT.openPile({L:H.map(P)},{practice:true,done:s=>finishAct('pfpiles',s,big('🧺'),'Puppy pile sorted!',()=>ACTS.pfpiles.play(),false)});},'Puppy Piles!')});
regAct('pfdoc',{name:'Doctor Seb',icon:'🩺',island:'meadow',area:'pfroom',where,lockSay:'Give some puppies a check-up in the Puppy Room first!',play:()=>arcadeTravel('pfroom',null,()=>{const L=PF.homes().filter(id=>PF.stg(id)>=1);if(!L.length)return say('No puppies to check yet!');ARC={k:'pfdoc',t0:Date.now()};R.run('doctor',[L[Math.floor(Math.random()*L.length)]]);},'Doctor Seb!')});
/* ---------------- badges ---------------- */
const how=k=>PF.famIds().some(id=>(PF.famOf(id)||{}).how===k);
MERITS.push(
 {id:'pflittle',icon:'🧺',name:'Little Ones',how:'Name the three puppies in the basket in Seb\'s Den.',ok:()=>!!S0().intro},
 {id:'pffirst',icon:'👪',name:'First Family Home',how:'Help a pup find its three puppies on the islands.',ok:()=>how('peek')||how('trail')||how('pile')},
 {id:'pftrail',icon:'🔢',name:'Trail of Threes',how:'Count along the stepping stones to a puppy family.',ok:()=>how('trail')},
 {id:'pfpilesort',icon:'🧺',name:'Puppy Pile Sorter',how:'Sort a puppy pile: every puppy to its own family.',ok:()=>how('pile')},
 {id:'pfdoctor',icon:'🩺',name:'Doctor Seb',how:'Give the puppies a check-up: eyes, heart and teeth.',ok:()=>!!(state.acts||{}).pfdoc},
 {id:'pfstar',icon:'🎪',name:'Puppy School Star',how:'Put on the Puppy School Show: five tricks in a row.',ok:()=>!!(state.acts||{}).pfshow},
 {id:'pfros',icon:'🏵️',name:'Nine Rosettes',how:'Collect all nine Parade Rosettes from the unicorns.',ok:()=>Object.keys(S0().ros||{}).length>=9},
 {id:'pfall',icon:'🐾',name:'Every Family Home',how:'Bring all 117 puppy families home.',ok:()=>PF.homes().length>=PF.famIds().length});
/* ---------------- the Den: Granny's Pup Book on the shelf, and a family photo ---------------- */
{const D=AREAS.den,_b=D.build;D.build=function(){_b.apply(this,arguments);const X=S0();if(!X.intro)return;
  W.things.push({x:1.5,z:-8.6,r:2.6,icon:'📖',label:'Pup Book',act:()=>PFBOOK.open()});spr('📖',.8,2.6,3.4,-9.9);
  const b=X.basket&&X.basket.pid;if(b){I('box','#9b6a43',2.6,2,.1,-13.9,4.6,-2.2,0,PI/2,0);I('box','#ffffff',2.3,1.7,.1,-13.85,4.6,-2.2,0,PI/2,0);spr('🖼️',1.2,-13.6,4.6,-2.2);const l=label(`${P(b).name}'s family`,4);l.position.set(-13.2,6,-2.2);W.ag.add(l);}};}
/* ---------------- "Puppy Bus Boogie", an original tune, in the village while the bus is there ---------------- */
TUNES.pfbus={step:.17,mw:'square',mv:.26,
  mel:tuneRow('C5 . E5 G5 A5 . G5 E5 C5 . D5 E5 D5 . . . E5 . G5 A5 C6 . A5 G5 E5 . D5 C5 D5 . . . C5 . E5 G5 A5 . G5 E5 F5 . A5 G5 F5 . E5 . D5 . G5 . E5 D5 C5 - - .'),
  bas:tuneRow('C3 . G2 . C3 . G2 . F2 . C3 . G2 . C3 . C3 . G2 . F2 . C3 . G2 . D3 . G2 . . . C3 . G2 . C3 . G2 . F2 . C3 . F2 . C3 . G2 . D3 . G2 . C3 . . .'),drm:'k.h.s.h.'};
{const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;const X=S0();if(!state.season&&X.bus&&!X.gone&&!X.done&&typeof W!=='undefined'&&W&&W.area&&W.area.id==='village')return 'pfbus';return _mk();};}
const css=document.createElement('style');css.textContent=`
.pftorch,.pfbeat,.pfsparkle{position:absolute;left:50%;top:20%;transform:translateX(-50%);font-size:46px;animation:pfz 1s ease-in-out infinite}
.pftricks{display:flex;gap:10px;justify-content:center;flex-wrap:wrap;margin:6px 0}.pftk{width:132px;height:110px;border:4px solid #8fd0ff;border-radius:20px;background:#eef8ff;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center}.pftk span{font-size:48px;line-height:1}.pftk b{font-size:20px}
.pfsig{display:inline-block;font-size:40px;font-weight:900;margin-right:12px;vertical-align:middle}
#pfcStage.t-sit .pfsv,.pfstar.t-sit .pfshowpup{transform:scaleY(.8) translateY(14px)}#pfcStage.t-paw .pfsv,.pfstar.t-paw .pfshowpup{transform:rotate(-10deg)}#pfcStage.t-down .pfsv,.pfstar.t-down .pfshowpup{transform:scaleY(.65) translateY(30px)}
#pfcStage.t-spin .pfsv,.pfstar.t-spin .pfshowpup{animation:pfspin .7s}#pfcStage.t-roll .pfsv,.pfstar.t-roll .pfshowpup{animation:pfroll .9s}#pfcStage.t-come .pfsv,.pfstar.t-come .pfshowpup{animation:pfcome .7s}
.pfsv,.pfshowpup{transition:transform .3s}@keyframes pfspin{to{transform:rotate(360deg)}}@keyframes pfroll{50%{transform:rotate(180deg) translateY(-10px)}100%{transform:rotate(360deg)}}@keyframes pfcome{50%{transform:scale(1.25)}}
#pfcStage.walky{background:linear-gradient(#cdeeff 60%,#9ad870 60%)}#pfcStage.step .pfu{animation:pfstep .9s}@keyframes pfstep{30%{transform:translateX(18px) translateY(-6px)}60%{transform:translateX(-6px)}}
.pfu.sniff .pfsv{transform:rotate(18deg) translateY(10px)}.pfbub2{position:absolute;font-size:32px;animation:xpop .4s}.pfu.fluffy .pfsv{filter:brightness(1.08) saturate(1.1)}
.pfstar{position:relative;display:inline-flex;align-items:center;gap:30px;background:#fff6c8;border:5px solid #ffd23f;border-radius:30px;padding:10px 30px}.pfshowpup{width:180px}.pfshowpup svg{width:100%;height:auto}.pfstar.flopx .pfshowpup{transform:rotate(85deg) translateY(20px)}
.pfsigbig{font-size:80px;width:200px;text-align:center;line-height:1}.pfsigbig b{display:block;font-size:30px}#pfsTip{font-size:22px;margin:2px 0 6px}
.pfpile2{display:flex;gap:6px;justify-content:center}.pfsleep{display:inline-block;width:240px;vertical-align:bottom}.pfsleep .pfpile{width:100%}#pfSleepCap{font-size:26px;font-weight:900;color:#fff;text-align:center;margin-top:8px}`;
document.head.appendChild(css);
window.PFR3={_sh:()=>SH,lastOut:()=>LASTOUT,tagOn:()=>TAGON,CARE,order:['doctor','school','walk','bath'],build,tricks,tagBtn,tagHook,openShow,schoolMenu,school:true,doctor:true,TRICKS,out,tagOf};
})();
