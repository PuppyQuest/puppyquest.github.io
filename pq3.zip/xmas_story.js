/* ================================================================
   Christmas Snow: the story's end (25 Nov 2026, claude/christmas-snow-design.md, scenes 8 to 12)
   - Muddle seen on the islands as the pups come home; with all nine sparkles, the reindeer spots a
     glint on Eagle Peak, where Muddle sits with the star wrapped in paper;
   - the tree lighting in the village at dusk, with a countdown from 10;
   - the Present Run on Christmas Eve: a 2D flight round the nine islands, dropping presents down
     chimneys and counting them in, flying through rings of snowflakes;
   - Christmas morning: three presents, a letter from the North Pole, the certificate and 100 stars;
   - goodbye, and a firefly in the dark: Night Glow is coming.
   Save (state.sx.xmas): peak, lit, run, done. Badges and the certificate are added here.
   ================================================================ */
(function(){
const XM=window.XMAS,PI=Math.PI,X=()=>XM.XS(),D=()=>XM.deer().name;
const mg=w=>`<div class="fitsvg" style="width:${w||150}px">${magpieSVG()}</div>`,dr=(w,o)=>`<div class="fitsvg" style="width:${w||180}px">${XM.deerSVG(o)}</div>`,big=e=>`<div style="font-size:96px;line-height:1">${e}</div>`;

/* ---------------- Muddle sightings and the call to Eagle Peak ---------------- */
const SEEN={4:'Granny Paws says: "I saw Muddle flying over the village with something shiny, all wrapped up in paper!"',12:'Sensei Mochi says: "A magpie flew past the Dojo carrying a funny shiny parcel. He looked very worried!"',
 24:'Tinker the robot says: "Beep! Muddle zoomed past with a shiny parcel. My sensors say he went up a mountain!"',40:'Chief Woofles says: "Muddle was spotted on Snowy Summit, holding a shiny present. Brrr, he looked cold!"'};
function afterFind(p,n){if(SEEN[n]){say(`${n} presents are home! ${SEEN[n]}`);return true;}return false;}
function onSparkle(I,n){if(n<9)return;const T=X();setTimeout(()=>{player.lock=true;
  story([{art:dr(180)+big('🌟'),t:`All nine sparkles of the Christmas Star are home! They swirl round ${D()}'s antlers, and now ${XM.he()} can fly!`},
    {art:big('🏔️✨'),t:`${D()} looks up. Far away, at the very top of Snowy Summit, something is glinting on Eagle Peak... "Is that Muddle?"`}],
    ()=>{player.lock=false;T.call=1;save();card({art:big('🏔️'),h:'To Eagle Peak!',p:`Shall we go to Eagle Peak and find Muddle?`,btns:[['🏔️ Let\'s go!','green',()=>{player.lock=true;fadeTo(()=>enterArea('eagle'),['🏔️','Eagle Peak']);}],['Later','white',()=>say('Eagle Peak is at the top of Snowy Summit. Ride the chairlift, then go past the Mountain Hut.')]]});});},700);}
/* Muddle waits on Eagle Peak, once all nine sparkles are home */
{const E=AREAS.eagle,b=E.build;E.build=function(){b.apply(this,arguments);if(!XM.on()||XM.nSp()<9||X().peak)return;const x=-8,z=-14,y=gy(x,z);
  I('cyl','#8a5a32',1.3,.5,1.3,x,y+.25,z);for(let i=0;i<10;i++){const a=i*.63;I('cyl','#a8743a',.08,1.6,.08,x+Math.cos(a)*1.2,y+.45,z+Math.sin(a)*1.2,0,a,PI/2.4);}
  const m=magpie3D();m.scale.setScalar(1.2);add(m,x,z,y+.3);const pr=XM.present3D(['#c9b08a','#d9363e'],.7);add(pr.g,x+1.5,z+.8);I('sph','#ffd23f',.35,.35,.15,x+1.5,y+1.2,z+.8,0,0,0,true);
  col(x,z,1.8);W.ticks.push(()=>{m.position.y=y+.3+Math.abs(Math.sin(W.t*1.5))*.15;m.rotation.y=Math.sin(W.t*.7)*.4;});
  W.things.push({x,z:z+2.6,r:4.5,icon:'💬',label:'Muddle',act:muddleScene});
  setTimeout(()=>{if(W.area===E)say('Look! Muddle is huddled in a little nest up here, holding a parcel. Go and talk to him!');},2400);};}
function muddleScene(){if(player.lock)return;player.lock=true;hush();sfx.chime();const T=X();
  story([{art:mg(160)+big('🎁'),t:'Muddle is shivering in a little nest of twigs. He is holding the Christmas Star, wrapped up in crumpled paper and string.'},
    {art:mg(160),t:'"I wanted to give Seb the best present ever," sniffs Muddle. "I thought the shiniest thing in the world must be the best present. But now the lights are out, the presents are lost, and I\'ve spoiled Christmas!"'},
    {art:dr(170),t:`"The best presents aren't the shiniest," says ${D()} kindly. "They're the ones made with love. And being Seb's friend is a present already!"`},
    {art:mg(140)+big('⭐'),t:'Muddle\'s eyes go wide. "Made with love..." He unwraps the star and gives it back. "Sorry, everyone. Let\'s put it back on the tree!"'}],
    ()=>{T.peak=Date.now();save();player.lock=false;fadeTo(()=>{enterArea('village',[0,17,PI]);},['🌙','Christmas Eve']);});}

/* ---------------- the village: lighting the tree, then the Present Run ---------------- */
function village(){const T=X();if(!T.intro)return false;
  if(T.peak&&!T.lit){setTimeout(lighting,500);return true;}
  if(T.lit&&!T.run){setTimeout(()=>{if(cur!=='world'||ovOpen())return;card({art:dr(170,{sack:true})+big('🛷'),h:'🎄 Christmas Eve!',p:`The tree is lit and ${D()} is ready. Time for the Present Run: fly the sleigh round every island and drop the presents down the chimneys!`,
    btns:[['🛷 Let\'s fly!','green',()=>presentRun()],['Not yet','white',()=>say('Come back to the village when you are ready for the Present Run!')]]});},700);return true;}
  if(T.run&&!T.done){setTimeout(()=>morning(true),600);return true;}
  return false;}
let SKY=null;
function nightSky(){scene.background.set('#18204a');scene.fog.color.set('#18204a');scene.fog.near=55;scene.fog.far=190;if(W.hemi){W.hemi.color.set('#9ab0f0');W.hemi.groundColor.set('#2a2c58');W.hemi.intensity=.5;}
  const dl=scene.children.find(o=>o.isDirectionalLight);if(dl){dl.color.set('#c9d6ff');dl.intensity=.3;}
  if(!SKY){const n=320,p=new Float32Array(n*3);let sd=1225;const R=()=>((sd=(sd*9301+49297)%233280)/233280);for(let i=0;i<n;i++){const az=R()*PI*2,el=.1+R()*1.3,d=420;p[i*3]=Math.cos(az)*Math.cos(el)*d;p[i*3+1]=Math.sin(el)*d;p[i*3+2]=Math.sin(az)*Math.cos(el)*d;}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));SKY=new THREE.Points(g,new THREE.PointsMaterial({color:'#ffffff',size:2.2,sizeAttenuation:false,fog:false}));}
  W.ag.add(SKY);const mn=sprite('🌕',40);mn.position.set(-150,190,-230);mn.material.fog=false;W.ag.add(mn);}
function lighting(){if(!W.area||W.area.id!=='village'||!XWORLD.tree)return;const T=X(),P=player,tr=XWORLD.tree;nightSky();player.lock=true;hush();
  P.x=0;P.z=15;P.h=PI;W.camYaw=PI;camUpdate(0,true);MUSIC.over='xtree';
  story([{art:mg(130)+dr(150),t:'Back in Pawprint Village, as the sun goes down, everyone gathers round the giant tree: the pups, Granny Paws, and Muddle too.'},
    {art:big('🔟'),t:`Let's count down from 10, and ${D()} will fly the star to the top of the tree! Ready?`}],()=>{let n=10;
    const tk=()=>{speak(String(n));floatS(['🔟','9️⃣','8️⃣','7️⃣','6️⃣','5️⃣','4️⃣','3️⃣','2️⃣','1️⃣'][10-n],0,gy(0,5)+6,9,3,1);sfx.boop();n--;if(n>0){setTimeout(tk,950);return;}setTimeout(fly,900);};tk();});
  function fly(){XM.DEER.script=true;const S=sprite('⭐',2.4);scene.add(S);const top=tr.top,x0=XM.DEER.x,z0=XM.DEER.z;let k=0;XM.snd.bells(10);
    W.ticks.push(dt=>{k+=dt*.45;const e=Math.min(1,k),x=x0+(top[0]-x0)*e,z=z0+(top[2]-z0)*e,y=walkY(x0,z0)+2+(top[1]-2)*e+Math.sin(e*PI)*4;
      if(XM.DEER.g){XM.DEER.x=x;XM.DEER.z=z;XM.DEER.g.position.set(x,y-1.6,z);}S.position.set(x,y+.6,z);
      if(e>=1){XM.DEER.script=false;scene.remove(S);if(tr.st)tr.st.visible=true;if(tr.L)tr.L.set(true);XWORLD.lights().forEach(L=>L.set(true));T.lit=Date.now();save();sfx.fanfare();confetti(90);XM.snd.twinkle();
        for(let i=0;i<9;i++)setTimeout(()=>floatS('✨',top[0]+Math.cos(i)*3,top[1]-2+i*.3,top[2]+Math.sin(i)*3,2.4,1.6),i*160);
        setTimeout(()=>{story([{art:big('🎄✨'),t:'The star shines on top of the tree, and all nine sparkles swirl into it. The whole tree lights up!'},
          {art:`<div style="font-size:60px;line-height:1.3">${ISLANDS.map(I=>I.icon).join(' ')}</div>`,t:'Across the sea, every light on every island switches on, one after another. Christmas is saved!'},
          {art:dr(170,{sack:true})+big('🛷'),t:`"Now I know the way!" says ${D()}. "It's Christmas Eve. Will you help me deliver the presents, Seb?"`}],
          ()=>{MUSIC.over=null;player.lock=false;presentRun();});},1800);return true;}});}}

/* ---------------- the Present Run (a 2D flight) ---------------- */
const STOPS=[['meadow','Blossom',3],['snowy','The penguins',4],['reef','Pearl',5],['ninja','Sensei Mochi','d3'],['number','Professor Hoot','d4'],['gadget','Tinker','2x5'],['rescue','Chief Woofles','3x2'],['dino','Dr Digby','t'],['planet','Captain Nibbles','2x4']];
const ISC={meadow:['#8fd170','#5fae4a'],snowy:['#f2f7fb','#c9d6e6'],reef:['#f0dca8','#3fb0d0'],ninja:['#c8664a','#8a3a2a'],number:['#f7e6a6','#c9a86a'],gadget:['#b6c4d4','#6a707a'],rescue:['#f0d27a','#d8c09a'],dino:['#8aa04a','#5a7a3a'],planet:['#cfd2da','#8e929c']};
let RN=null;
function need(s){const k=s[2];if(typeof k==='number')return {n:k,q:`${k} presents`};if(k[0]==='d'){const a=+k.slice(1);return {n:a*2,q:`double ${a} presents`};}
  if(k==='t'){const t=tablesOn().filter(v=>v<=5),a=t.length?t[Math.floor(Math.random()*t.length)]:2,b=a>3?2:3;return {n:a*b,q:`${b} lots of ${a} presents`};}const q=k.split('x');return {n:q[0]*q[1],q:`${q[0]} lots of ${q[1]} presents`};}
function svgImg(s){if(!/xmlns=/.test(s))s=s.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"');const i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s);return i;}
function runUI(){if($('#xrun'))return;const d=el('div','screen','<canvas id="xrCv" width="1024" height="768"></canvas><button class="btn rnd white" id="xrBack">◀</button><div class="pill" id="xrPill"></div>');d.id='xrun';
  const q=document.querySelector('#quiz');q.parentNode.insertBefore(d,q);const cv=$('#xrCv');
  const pos=e=>{const r=cv.getBoundingClientRect();return [(e.clientX-r.left)*1024/r.width,(e.clientY-r.top)*768/r.height];};
  cv.addEventListener('pointerdown',e=>{initAudio();if(!RN)return;RN.down=true;const p=pos(e);RN.ty=p[1];if(RN.ph==='drop')drop();});cv.addEventListener('pointermove',e=>{if(!RN)return;RN.ty=pos(e)[1];});
  ['pointerup','pointercancel'].forEach(k=>cv.addEventListener(k,()=>{if(RN)RN.down=false;}));
  tap('#xrBack',()=>{sfx.boop();if(!RN)return;RN.over=true;RN=null;MUSIC.over=null;show('world');player.lock=false;say('You can fly the Present Run again from the village whenever you are ready.');});}
function presentRun(){runUI();hush();player.lock=true;const B=state.buddy&&pupById(state.buddy);
  RN={i:-1,ph:'fly',t:0,sy:300,ty:300,rings:[],drops:[],got:0,need:0,x0:0,sx:220,stars:Array.from({length:120},()=>[Math.random()*1024,Math.random()*520,Math.random()]),
    img:{deer:svgImg(XM.deerSVG()),seb:svgImg(sebSVG(true)),bud:B?svgImg(critterSVG(window.XLOOK.xp(B),{anim:false})):null},hill:0,last:performance.now(),over:false};
  show('xrun');MUSIC.over='xwish';say(`Hold on tight! Drag up and down to steer the sleigh through the snowflake rings. Over each island, tap to drop presents down the chimney!`);nextLeg();requestAnimationFrame(runFrame);}
function nextLeg(){const R=RN;R.i++;if(R.i>=STOPS.length){R.ph='end';R.t=0;return;}R.ph='fly';R.t=0;R.rings=[];for(let k=0;k<3;k++)R.rings.push({x:1150+k*380,y:200+Math.random()*260,hit:false});R.isl={x:1150+3*380+200};
  R.doneDrop=false;const s=STOPS[R.i],I=islandOf(s[0]);$('#xrPill').textContent=`🛷 ${R.i+1} of 9: ${I?I.name:''}`;}
function drop(){const R=RN;if(R.doneDrop||R.drops.some(d=>!d.done&&d.vy<0))return;if(R.got>=R.need)return;R.drops.push({x:R.sx+70,y:R.sy+50,vy:0,done:false});sfx.pop();}
function runFrame(now){const R=RN;if(!R||R.over)return;requestAnimationFrame(runFrame);if(cur!=='xrun')return;const dt=Math.min(.05,(now-R.last)/1000);R.last=now;R.t+=dt;
  const cv=$('#xrCv'),g=cv.getContext('2d');
  /* steering */
  if(R.ph==='fly'){R.sx+=(220-R.sx)*Math.min(1,dt*1.2);R.sy+=(Math.max(120,Math.min(520,R.ty-40))-R.sy)*Math.min(1,dt*5);const sp=260*dt;R.rings.forEach(r=>{r.x-=sp;if(!r.hit&&Math.abs(r.x-(R.sx+60))<50&&Math.abs(r.y-(R.sy+40))<70){r.hit=true;XM.snd.bells(4);sfx.chime();}});R.isl.x-=sp;
    if(R.isl.x<640){R.ph='drop';R.isl.x=640;R.t=0;const s=STOPS[R.i],nd=need(s);R.need=nd.n;R.got=0;R.drops=[];R.q=`${s[1]} ${s[1].slice(0,4)==='The '?'need':'needs'} ${nd.q}!`;speak(R.q+' Tap to drop them down the chimney.');
      if(s[0]==='planet')R.santa=0;}}
  if(R.ph==='drop'){R.sx=610+Math.sin(R.t*.8)*150;R.sy+=(220-R.sy)*Math.min(1,dt*3);
    R.drops.forEach(d=>{if(d.done)return;d.vy+=900*dt;d.y+=d.vy*dt;const cx=R.isl.x+40,top=470;if(!d.bounce&&Math.abs(cx-d.x)<130)d.x+=(cx-d.x)*Math.min(1,dt*2.6);
      if(d.vy>0&&d.y>=top-10){if(Math.abs(d.x-cx)<38){d.done=true;R.got++;speak(String(R.got));XM.snd.bells(3);if(R.got>=R.need&&!R.doneDrop){R.doneDrop=true;sfx.fanfare();say(`Yes! ${R.need} presents for ${STOPS[R.i][1]}! Happy Christmas!`);setTimeout(()=>{if(RN===R)nextLeg();},2400);}}
        else{d.vy=-520;d.bounce=true;sfx.boop();}}
      if(d.bounce&&d.vy>=0&&d.y<R.sy+40){d.done=true;}});
    if(R.got>=R.need){R.isl.x-=0;}}
  if(R.ph==='fly'&&R.i>0&&R.t<.1){}
  if(R.ph==='end'){if(R.t>1.5&&!R.fin){R.fin=true;RN=null;MUSIC.over=null;X().run=Date.now();save();fadeTo(()=>{show('world');enterArea('village',[0,15,PI]);},['☀️','Christmas morning']);return;}}
  /* drawing */
  const sky=g.createLinearGradient(0,0,0,768);sky.addColorStop(0,'#0b1236');sky.addColorStop(1,'#2a3a7a');g.fillStyle=sky;g.fillRect(0,0,1024,768);
  R.stars.forEach(s=>{g.fillStyle=`rgba(255,255,255,${.4+.6*Math.abs(Math.sin(R.t*2+s[2]*9))})`;g.fillRect((s[0]-R.t*8*s[2]+1024*4)%1024,s[1],2,2);});
  g.fillStyle='#fff6c9';g.beginPath();g.arc(860,120,60,0,PI*2);g.fill();
  if(R.ph==='drop'&&STOPS[R.i]&&STOPS[R.i][0]==='planet'){R.santa=(R.santa||0)+dt;const k=(R.santa%6)/6,x=760+k*200,y=135-Math.sin(k*PI)*30;g.fillStyle='#0b1236';for(let q=0;q<2;q++){const rx=x+18+q*20;g.fillRect(rx-7,y-4,14,6);g.fillRect(rx+5,y-10,3,8);g.fillRect(rx-6,y+2,2,6);g.fillRect(rx+4,y+2,2,6);}g.fillRect(x-26,y-4,22,8);g.fillRect(x-28,y+5,26,2);}
  R.hill=(R.hill+(R.ph==='fly'?260*dt:0))%1024;g.fillStyle='#1a2a5a';for(let k=-1;k<3;k++){const ox=k*512-R.hill*.5;g.beginPath();g.moveTo(ox,768);g.quadraticCurveTo(ox+256,560,ox+512,768);g.fill();}
  /* the island and the house */
  if(R.isl&&STOPS[R.i]){const s=STOPS[R.i],c=ISC[s[0]]||['#8fd170','#5fae4a'],x=R.isl.x;g.fillStyle=c[1];g.beginPath();g.ellipse(x+40,700,300,120,0,PI,0);g.fill();g.fillStyle=c[0];g.beginPath();g.ellipse(x+40,712,270,96,0,PI,0);g.fill();
    g.fillStyle='#ffffff';g.beginPath();g.ellipse(x+40,612,240,20,0,0,PI*2);g.fill();
    g.fillStyle='#c8844a';g.fillRect(x-60,520,200,110);g.fillStyle='#d9363e';g.beginPath();g.moveTo(x-80,525);g.lineTo(x+40,450);g.lineTo(x+160,525);g.fill();g.fillStyle='#ffffff';g.fillRect(x-82,520,244,10);
    g.fillStyle='#8a4a2a';g.fillRect(x+18,455,44,60);g.fillStyle='#fff';g.fillRect(x+14,452,52,10);g.fillStyle='#ffd86a';g.fillRect(x-40,560,40,36);g.fillRect(x+80,560,40,36);
    g.font='54px Arial';g.textAlign='center';const I=islandOf(s[0]);g.fillText(I?I.icon:'',x+40,710);
    if(R.ph==='drop'){g.fillStyle='rgba(255,255,255,.95)';g.strokeStyle='#26232e';g.lineWidth=4;const w=Math.min(900,g.measureText(R.q).width*.62+60);g.beginPath();g.roundRect?g.roundRect(512-w/2,150,w,64,18):g.rect(512-w/2,150,w,64);g.fill();g.stroke();
      g.fillStyle='#26232e';g.font='bold 30px Arial';g.fillText(R.q,512,193);g.font='bold 44px Arial';g.lineWidth=7;g.strokeStyle='#26232e';g.strokeText(`🎁 ${R.got} / ${R.need}`,x+40,430);g.fillStyle='#ffffff';g.fillText(`🎁 ${R.got} / ${R.need}`,x+40,430);}}
  /* rings */
  R.rings.forEach(r=>{if(r.x<-80||r.x>1100)return;g.strokeStyle=r.hit?'#ffd23f':'#bfefff';g.lineWidth=8;g.beginPath();g.ellipse(r.x,r.y,34,70,0,0,PI*2);g.stroke();g.font='26px Arial';g.textAlign='center';for(let k=0;k<6;k++){const a=k*PI/3+R.t;g.fillText('❄️',r.x+Math.cos(a)*34,r.y+Math.sin(a)*70+9);}});
  /* the sleigh */
  const sx=R.sx,sy=R.sy+Math.sin(R.t*3)*6;if(R.img.deer.complete)g.drawImage(R.img.deer,sx+120,sy-20,110,110);
  g.strokeStyle='#c9a070';g.lineWidth=3;g.beginPath();g.moveTo(sx+100,sy+50);g.lineTo(sx+160,sy+50);g.stroke();
  if(R.img.seb.complete)g.drawImage(R.img.seb,sx+10,sy-30,70,84);if(R.img.bud&&R.img.bud.complete)g.drawImage(R.img.bud,sx+52,sy-4,58,58);
  g.fillStyle='#d9363e';g.strokeStyle='#26232e';g.lineWidth=4;g.beginPath();g.moveTo(sx,sy+30);g.lineTo(sx+110,sy+30);g.lineTo(sx+100,sy+78);g.lineTo(sx+14,sy+78);g.closePath();g.fill();g.stroke();
  g.strokeStyle='#ffd23f';g.lineWidth=5;g.beginPath();g.moveTo(sx-6,sy+92);g.lineTo(sx+118,sy+92);g.quadraticCurveTo(sx+132,sy+92,sx+128,sy+78);g.stroke();
  g.font='30px Arial';g.fillText('🎁',sx+20,sy+34);
  R.drops.forEach(d=>{if(d.done&&!d.bounce)return;if(d.done)return;g.font='34px Arial';g.textAlign='center';g.fillText('🎁',d.x,d.y);});
  if(R.ph==='fly'&&R.t<2.5){g.fillStyle='#fff';g.font='bold 30px Arial';g.textAlign='center';g.fillText('Drag up and down to steer through the rings!',512,740);}}

/* ---------------- Christmas morning ---------------- */
function morning(ok){const T=X();if(T.done)return;if(!ok||!W.area||W.area.id!=='village'){fadeTo(()=>{enterArea('village',[0,15,PI]);},['☀️','Christmas morning']);return;}
  player.lock=true;hush();const B=state.buddy&&pupById(state.buddy),bn=B?B.name:'your buddy';const zu=window.BHQ&&state.bh&&state.bh.done?' Zuzu and her puppies have come too!':'';
  story([{art:big('☀️🎄🎁'),t:`Christmas morning! Fresh snow sparkles in the sunshine. Everyone gathers round the tree: the pups, Granny Paws, the guides and all nine unicorns.${zu}`},
    {art:dr(170)+big('🔔'),t:`The first present is from ${D()}: a silver sleigh bell from ${XM.his()} collar. "So you'll always remember our Christmas flight!"`},
    {art:`<div class="fitsvg" style="width:140px">${grannySVG()}</div>`+(B?`<div class="fitsvg" style="width:160px">${critterSVG(Object.assign({},B,{dressAs:'xjumper'}),{anim:false})}</div>`:''),t:`The second present is from Granny Paws: a knitted Christmas jumper and bobble hat for ${bn}! (You can dress any pup in it at the Pup Spa.)`},
    {art:mg(150)+big('🪵✨'),t:'The last present is from Muddle. It\'s a decoration he made himself, from twigs and shiny sweet wrappers. "It\'s not very shiny... well, a little bit shiny. But I made it for you!"'},
    {art:big('💌'),t:`A letter arrives from the North Pole: "Dear Seb, thank you for helping ${D()}. ${XM.he()[0].toUpperCase()+XM.he().slice(1)} has passed ${XM.his()} very first flight with flying colours! Happy Christmas, from everyone at the Reindeer School."`}],
    ()=>{T.done=Date.now();state.stars+=100;state.costumes=state.costumes||{};state.costumes.xjumper=1;state.certs=state.certs||{};const c=CERTS.find(q=>q.id==='xmashero');if(c&&!state.certs[c.id])state.certs[c.id]=Date.now();save();hud();
      if(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray! +100 ⭐','green',goodbye]]}));}else goodbye();});}
function goodbye(){const T=X(),left=XM.all().length-XM.nFound();
  story([{art:dr(170),t:`${D()} gives you a big reindeer hug. "Whenever you play Christmas Snow, I'll come and visit!"`+(left?` And there are still ${left} Christmas pups hiding on the islands!`:'')},
    {art:`<svg viewBox="0 0 300 200" width="300"><rect width="300" height="200" rx="18" fill="#0b1236"/><circle cx="150" cy="110" r="14" fill="#fff27a" opacity=".35"/><circle cx="150" cy="110" r="6" fill="#fff9b0"/><path d="M144 104 q-14 -14 -6 -18 q6 8 6 18 M156 104 q14 -14 6 -18 q-6 8 -6 18" fill="#cfe8ff" opacity=".7"/></svg>`,t:window.GLOW?'That night, the lights go out one by one... and a tiny glow blinks in the dark. A firefly! Night Glow is here!':'That night, the lights go out one by one... and a tiny glow blinks in the dark. A firefly! Coming soon: Night Glow!'}],
    ()=>{player.lock=false;T.bye=Date.now();save();
      /* 25 Nov: Night Glow follows straight on, or later from the Season Globe */
      if(window.GLOW&&!GLOW.named()){card({art:'<div style="font-size:100px;line-height:1">🌙✨</div>',h:'🌙 Night Glow is here!',p:'Something strange is happening to the fireflies... Shall we play Night Glow now?',
        btns:[['🌙 Yes, let\'s go!','green',()=>{const g=GLOW.GS();g.inv=1;save();GLOW.intro();}],['Not now','white',()=>{const g=GLOW.GS();g.inv=1;save();say(`Happy Christmas, Seb! Shake the Season Globe in the plaza whenever you want to play Night Glow.`);}]]});return;}
      say(`Happy Christmas, Seb! ${D()} will stay in the village whenever Christmas Snow is on.`);});}

/* ---------------- badges and the certificate ---------------- */
const xs=()=>(state&&state.sx&&state.sx.xmas)||{},xa=()=>xs().acts||{};
MERITS.push(
 {id:'xdeer',icon:'🦌',name:'Reindeer Friend',how:'Meet the young reindeer in Christmas Snow, and give it a name.',ok:()=>!!xs().deer},
 {id:'xsleigh',icon:'🛷',name:'Sleigh Rider',how:'Ride the Sleigh Run at the Mountain Hut in Christmas Snow.',ok:()=>!!(state.acts||{}).sleighrun},
 {id:'xtoys',icon:'📦',name:'Toy Maker',how:'Help Tinker with Toy Packing in the Christmas toy factory.',ok:()=>!!(state.acts||{}).toypack},
 {id:'xsnowman',icon:'⛄',name:'Snowman Builder',how:'Build a snowman on Meadow Island in Christmas Snow.',ok:()=>!!xa().snowman},
 {id:'xstar',icon:'🌟',name:'Star Keeper',how:'Bring home all nine sparkles of the Christmas Star.',ok:()=>Object.keys(xs().sp||{}).length>=9},
 {id:'xall',icon:'🎁',name:'Every Present Home',how:'Find all 119 Christmas pups in Christmas Snow.',ok:()=>!!xs().found&&XM.nFound()>=XM.all().length});
CERTS.push({id:'xmashero',icon:'🎄',title:'Christmas Snow Hero',get why(){return `for saving Christmas with ${xs().deer?xs().deer.name+' the reindeer':'the young reindeer'}, and flying the Present Run round all nine islands`;},ok:()=>!!xs().done});

const css=document.createElement('style');css.textContent=`#xrun{background:#0b1236}#xrun canvas{position:absolute;left:0;top:0;width:100%;height:100%;touch-action:none}#xrun .btn.rnd{position:absolute;left:14px;top:10px;z-index:20}#xrun .pill{position:absolute;right:14px;top:14px;z-index:20}`;document.head.appendChild(css);
window.XSTORY={afterFind,onSparkle,village,lighting,presentRun,morning,muddleScene,award:()=>{},_rn:()=>RN};
})();
