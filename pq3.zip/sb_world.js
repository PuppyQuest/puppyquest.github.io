/* ================================================================
   Summer Beach Party (26 Nov 2026; claude/summer-beach-design.md sections 6, 7, 10, 12, 13): the world in summer.
   The village (parasols, deck chairs, beach balls, bunting, a sand pit and the Shell Board), parasols and
   towels on every island, the island surprises (the ice cream van, the snowman keeping cool, wind chimes,
   the sundial, Tinker's solar ice lolly machine, the dino paddling pool, Captain Nibbles' tides), the
   spotlights (the Lifeguard Rescue and the Sandcastle Contest in Rescue Bay, the Snorkel Treasure Hunt
   at the Shipwreck), the summer quiz in the Lab, the Den after the party, Arcade entries, two original
   tunes (a calypso for the village, a sea-shanty jig for Seal Cove and the Treasure Dig) and the
   real-date sandcastle at midsummer.
   ================================================================ */
(function(){
const SB=window.SB,XM=window.XMAS,PI=Math.PI,SAND='#f2d896',SEA='#2fb3d8',GOLD='#ffd23f';
const COLS=['#ff7fb8','#ffd23f','#5ab8ff','#8ae05a','#ff8a3c','#b88aff'];
const G=()=>SB.GS(),acts=()=>{const s=G();s.acts=s.acts||{};return s.acts;},F=()=>SB.pal().name;
function sayOnce(k,m,ms){const a=acts();if(a['s_'+k])return;a['s_'+k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say(m);},ms||1600);}
let GRD=null;function near(A,x,z,c){if(!GRD||GRD.id!==A.id){GRD=XM.grid(A,1);GRD.id=A.id;}const k=GRD.snap(x,z,c||2);return k<0?[x,z]:GRD.xz(k);}
/* a free place near (x,z): on walkable ground, clear of the summer hiding spots, things and exits */
function spotsOf(A){const out=[];SB.areaX(A.id).forEach(p=>{const S=(window.SBSPOTS||{})[p.id];if(!S)return;if(S.x!=null)out.push([S.x,S.z,6.5]);['b','c'].forEach(k=>{if(S[k])out.push([S[k][0],S[k][1],5]);});});
  W.things.forEach(t=>{if(!t.spal&&!t.hpal)out.push([t.x,t.z,4]);});(W.exits||[]).forEach(e=>out.push([e.x,e.z,7]));return out;}
function place(A,x,z,c){const L=spotsOf(A),ok=p=>!L.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<q[2]);let p=near(A,x,z,c);if(ok(p))return p;
  for(let r=3;r<=24;r+=3)for(let i=0;i<10;i++){const a=i/10*PI*2+r,q=near(A,x+Math.cos(a)*r,z+Math.sin(a)*r,c);if(ok(q))return q;}return p;}
const big=e=>`<div style="font-size:96px;line-height:1">${e}</div>`;
function card2(art,h,p,sayT){card({art,h,p,say:sayT||p,btns:[['OK','green']]});}
function reward(k,n){const a=acts();if(a[k])return;a[k]=1;state.stars+=n||5;save();hud();}
/* summer props from instanced parts */
function parasol(x,z,c1,c2){const y=gy(x,z);I('cyl','#ffffff',.06,2.6,.06,x,y+1.3,z);for(let i=0;i<8;i++){const a=i/8*PI*2;I('box',i%2?c1:c2,1.3,.06,.5,x+Math.cos(a)*.62,y+2.55,z+Math.sin(a)*.62,0,-a,-.32);}I('sph','#ffffff',.12,.12,.12,x,y+2.72,z);}
function chair(x,z,c,r){const y=gy(x,z);I('box',c,.8,.06,1.3,x,y+.45,z,-.5,r||0,0);I('box','#c98a4f',.06,.45,.06,x-.38,y+.22,z-.4);I('box','#c98a4f',.06,.45,.06,x+.38,y+.22,z-.4);I('box','#c98a4f',.06,.25,.06,x-.38,y+.12,z+.5);I('box','#c98a4f',.06,.25,.06,x+.38,y+.12,z+.5);}
function towel(x,z,c,r){const y=gy(x,z);I('box',c,1,.03,1.9,x,y+.03,z,0,r||0,0);I('box','#ffffff',1,.032,.18,x,y+.031,z+.6,0,r||0,0);}
function ball(x,z,s){const y=gy(x,z);s=s||.45;I('sph','#ffffff',s,s,s,x,y+s,z);I('sph','#e8423a',s*1.01,s*.5,s*.3,x,y+s,z);I('sph','#5ab8ff',s*.3,s*.5,s*1.01,x,y+s,z);}
function bucket(x,z,c){const y=gy(x,z);I('cyl',c||'#ff6a6a',.22,.34,.22,x,y+.17,z);I('cyl','#aab3c0',.03,.5,.03,x+.3,y+.25,z,0,0,.4);}
function flags(cx,cz,r,y0,n){for(let i=0;i<n;i++){const a=i/n*PI*2,x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r,y=y0+Math.sin(i*PI/2)*.25;I('box',COLS[i%COLS.length],.5,.32,.04,x,y,z,0,-a,0);}}
function castle(x,z,s){const y=gy(x,z);s=s||1;I('box','#e8c87a',1.2*s,.6*s,1.2*s,x,y+.3*s,z);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>{I('cyl','#d8b468',.25*s,.9*s,.25*s,x+q[0]*.55*s,y+.45*s,z+q[1]*.55*s);I('cone','#e8c87a',.28*s,.3*s,.28*s,x+q[0]*.55*s,y+1.05*s,z+q[1]*.55*s);});I('box','#ff6a6a',.2*s,.14*s,.02,x+.1*s,y+1.5*s,z);I('cyl','#ffffff',.015,.5*s,.015,x,y+1.3*s,z);}

/* ================= Pawprint Village in summer ================= */
function villageS(A){
  const R=seed(77);for(let i=0;i<7;i++){const a=i/7*PI*2+.4,p=place(A,Math.cos(a)*13.4,4+Math.sin(a)*13.4,1);if(Math.hypot(p[0]+5.5,p[1]-9)<3)continue;parasol(p[0],p[1],COLS[i%6],'#ffffff');chair(p[0]+1.4,p[1]+.6,COLS[(i+2)%6],-a);if(i%2)ball(p[0]-1.3,p[1]+1,.4);}
  flags(0,4,9.5,4.6,30);
  {const p=place(A,9,-10,1);mk('plane',SAND,6,1,4,p[0],gy(p[0],p[1])+.05,p[1],W.ag);castle(p[0]-1,p[1],1);bucket(p[0]+1.5,p[1]+.6);bucket(p[0]+2,p[1]-.8,'#5ab8ff');}
  shellBoard(-9,-18);
  sayOnce('village',`Welcome to the Summer Beach Party! Look at the Shell Board by the plaza: a shell shines for every summer pup you find.`);}
function shellBoard(x,z){const y=gy(x,z);[-2.1,2.1].forEach(d=>I('box','#c98a4f',.22,3.8,.22,x+d,y+1.9,z));I('box',SEA,4.5,2.9,.2,x,y+2.7,z);I('box',SAND,4.7,.16,.26,x,y+4.18,z);I('box',SAND,4.7,.16,.26,x,y+1.22,z);
  const n=Math.min(60,Math.round(SB.nFound()/SB.all().length*60));for(let i=0;i<60;i++){const c=i%12,r=Math.floor(i/12);I('sph',i<n?'#ffd2a8':'#5a8aa8',.13,.11,.06,x-1.9+c*.345,y+3.75-r*.48,z+.13,0,0,0,i<n);}
  const l=label('🐚 Shell Board',4.5,'#fff8e0');l.position.set(x,y+5,z);W.ag.add(l);rect(x-2.4,z-.3,x+2.4,z+.3);
  W.things.push({x,z:z+2.2,r:3.6,icon:'🐚',label:'Shell Board',act:()=>SB.board()});}

/* ================= the islands in summer ================= */
const ISL={};
function decor(A){if(!A.island||A.indoor||A.swim||A.island==='planet')return;const s=A.start||[0,0],R=seed(A.id.length*19+5);
  for(let i=0;i<2;i++){const a=R()*PI*2,d=9+R()*6,p=place(A,s[0]+Math.cos(a)*d,s[1]-4+Math.sin(a)*d,2);parasol(p[0],p[1],COLS[(i*2+A.id.length)%6],'#ffffff');towel(p[0]+1.2,p[1]+.4,COLS[(i*3+1)%6],a);if(i===0)bucket(p[0]-.9,p[1]+.9);}}
/* Meadow: the ice cream van at Windmill Hill */
const FLAV=[['🍓','Strawberry'],['🍫','Chocolate'],['🍦','Vanilla'],['🍋','Lemon sorbet']];
ISL.windmill=A=>{const s=A.start||[0,0],p=place(A,s[0]+7,s[1]-8,3),x=p[0],z=p[1],y=gy(x,z);
  I('box','#ffffff',3.4,1.9,1.8,x,y+1.25,z);I('box','#ff9ecb',3.42,.5,1.82,x,y+.55,z);I('box','#5ab8ff',1.2,.9,1.84,x+1,y+1.5,z,0,0,0,true);I('box','#ffffff',1.2,.9,1.6,x+1.9,y+.95,z);
  [-1.1,1.1].forEach(dx=>[-.9,.9].forEach(dz=>I('cyl','#26232e',.34,.24,.34,x+dx,y+.34,z+dz,PI/2,0,0)));I('cone','#e8c08a',.32,.7,.32,x-.6,y+2.6,z,PI,0,0);I('sph','#ff9ecb',.4,.4,.4,x-.6,y+3.05,z);col(x,z,2.2);
  W.things.push({x,z:z+2.6,r:3.8,icon:'🍦',label:'Ice cream van',act:()=>{if(player.lock)return;sfx.chime();
    card({h:'🍦 The ice cream van is here!',p:`Ding-a-ling! Which flavour would you like?<div class="sbrow">${FLAV.map((f,i)=>`<button class="opt sbf" data-i="${i}"><span style="font-size:54px">${f[0]}</span>${f[1]}</button>`).join('')}</div>`,say:'Ding a ling! The ice cream van is here! Which flavour would you like?',btns:[['Back','white']]});
    document.querySelectorAll('#celeCard .sbf').forEach(b=>tap(b,()=>{const f=FLAV[+b.dataset.i];sfx.fanfare();confetti(24);reward('icecream');
      card2(big(f[0]+'🍦'),`${f[1]}! Yum!`,`Eat it quickly! Ice cream melts in the sunshine, because the Sun's heat warms it up. ${F()} gets a tiny lick too.`);}));}});
  sayOnce('van','Ding-a-ling! Can you hear the ice cream van on Windmill Hill?',2600);};
/* Snowy Summit: the snowman in sunglasses keeps cool in a paddling pool */
const JOKES=[['What do snowmen do on hot days?','They chill out!'],['Why did the crab never share?','Because he was a little shellfish!'],['What did the sea say to the beach?','Nothing, it just waved!'],['What is a snowman\'s favourite summer treat?','An ice lolly, of course!'],['Why do fish live in salt water?','Because pepper makes them sneeze!']];
ISL.lift=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-7,2),x=p[0],z=p[1],y=gy(x,z);I('cyl','#5ab8ff',1.7,.4,1.7,x,y+.2,z);I('cyl','#bfeeff',1.55,.41,1.55,x,y+.21,z,0,0,0,true);
  I('sph','#ffffff',1,.9,1,x,y+.9,z);I('sph','#ffffff',.75,.7,.75,x,y+2.2,z);I('sph','#ffffff',.52,.52,.52,x,y+3.25,z);I('cone','#ff8a3c',.1,.45,.1,x,y+3.25,z+.72,PI/2,0,0);
  [-1,1].forEach(k=>I('box','#26232e',.24,.16,.06,x+k*.2,y+3.42,z+.48));I('box','#26232e',.2,.04,.04,x,y+3.45,z+.5);I('cyl','#f2d27a',.85,.04,.85,x,y+3.7,z);I('cyl','#f2d27a',.42,.28,.42,x,y+3.86,z);I('cyl','#ff7fb8',.43,.07,.43,x,y+3.76,z);col(x,z,1.9);
  W.things.push({x,z:z+2.4,r:3.8,icon:'⛄',label:'Snowman',act:()=>{if(player.lock)return;const a=acts(),j=JOKES[(a.joke||0)%JOKES.length];a.joke=(a.joke||0)+1;save();sfx.chime();
    card({art:big('⛄😎'),h:'The snowman is keeping cool!',p:`"${j[0]}"<br><br><b>"${j[1]}"</b>`,say:`${j[0]} ... ${j[1]}`,btns:[['😂 Ha ha!','green',()=>{reward('snowman');}]]});}});};
/* Ninja Mountains: glass wind chimes by the Dojo */
ISL.dojo=A=>{const s=A.start||[0,0],p=place(A,s[0]+7,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('box','#8a3a2a',.18,3,.18,x-1.4,y+1.5,z);I('box','#8a3a2a',.18,3,.18,x+1.4,y+1.5,z);I('box','#8a3a2a',3.2,.2,.24,x,y+3,z);
  const cols=['#9be8ff','#ffb4c8','#c8ff9a'],bells=[];cols.forEach((c,i)=>{const bx=x-.9+i*.9;I('cyl','#ffffff',.01,.5,.01,bx,y+2.65,z);const b=mk('hemi',c,.26,.3,.26,bx,y+2.1,z,W.ag,true);b.rotation.x=PI;bells.push(b);I('box','#ffffff',.18,.4,.02,bx,y+1.65,z);});col(x,z,1.4);
  let ring=0;W.ticks.push(dt=>{if(W.area!==A)return true;if(ring>0)ring-=dt;bells.forEach((b,i)=>{b.rotation.z=Math.sin(W.t*(ring>0?9:1.4)+i)*(ring>0?.35:.05);});});
  W.things.push({x,z:z+2.2,r:3.6,icon:'🎐',label:'Wind chimes',act:()=>{if(player.lock)return;ring=3;if(fxOk()){const t=AC.currentTime;[2093,2637,3136,2349,2794].forEach((f,i)=>tone(f,t+i*.18,.8,'sine',.07));}reward('chimes');
    setTimeout(()=>card2(big('🎐'),'Tinkle, tinkle!','In Japan, people hang glass wind chimes called fūrin in summer. When the breeze rings them, the tinkly sound is meant to help you feel cool.'),1200);}});};
/* Number Kingdom: the sundial in Number Town */
function sundialSVG(){const hrs=[6,'',9,'',12,'',3,'',6];return `<svg viewBox="0 0 320 200" width="320"><rect width="320" height="200" rx="16" fill="#bfe8ff"/><circle cx="280" cy="36" r="20" fill="#ffd23f"/><ellipse cx="160" cy="150" rx="140" ry="38" fill="#e8dcc0" stroke="#5b4636" stroke-width="4"/>`+
  hrs.map((h,i)=>{const a=PI+i/8*PI,x=160+Math.cos(a)*118,y=150+Math.sin(a)*30;return `<text x="${x.toFixed(0)}" y="${(y+6).toFixed(0)}" font-size="15" font-weight="900" text-anchor="middle" fill="#5b4636" font-family="Arial">${h}</text>`;}).join('')+
  `<path d="M160 150 L160 84 L230 150 Z" fill="#c9a86a" stroke="#5b4636" stroke-width="3"/><path d="M160 150 L96 128" stroke="#5a4a3a" stroke-width="8" stroke-linecap="round" opacity=".55"/></svg>`;}
ISL.ntown=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-7,2),x=p[0],z=p[1],y=gy(x,z);I('cyl','#c8bca8',1.6,.7,1.6,x,y+.35,z);I('cyl','#e8dcc0',1.5,.08,1.5,x,y+.74,z);I('box','#c9a86a',.08,.9,1.2,x,y+1.2,z,0,0,0);
  for(let i=0;i<12;i++){const a=i/12*PI*2;I('box','#5b4636',.06,.02,.3,x+Math.cos(a)*1.25,y+.79,z+Math.sin(a)*1.25,0,-a,0);}col(x,z,1.7);
  W.things.push({x,z:z+2.4,r:3.6,icon:'☀️',label:'Sundial',act:()=>{if(player.lock)return;sfx.chime();reward('sundial');
    card2(`<div class="fitsvg" style="width:320px">${sundialSVG()}</div>`,'The sundial','The Sun moves across the sky, so the shadow moves round the dial like a clock hand. Before there were clocks, people told the time with sundials. This one says about 8 o\'clock!');}});};
/* Gadget Island: Tinker's solar ice lolly machine */
ISL.workshop=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('box','#b8c0cc',1.8,1.8,1.2,x,y+.9,z);I('box','#5ab8ff',1.4,.6,.05,x,y+1.3,z+.62,0,0,0,true);
  I('box','#26324a',2.4,.06,1.4,x,y+2.1,z,.35,0,0);for(let i=0;i<4;i++)I('box','#4a6aa8',.5,.07,1.2,x-.84+i*.56,y+2.12,z,.35,0,0);[0,1,2].forEach(i=>I('cyl',COLS[i],.12,.4,.08,x-.4+i*.4,y+.5,z+.65));col(x,z,1.6);
  W.things.push({x,z:z+2.4,r:3.6,icon:'🍧',label:'Ice lolly machine',act:()=>{if(player.lock)return;sfx.chime();reward('solar');
    card2(big('☀️🔋🍧'),'Tinker\'s solar ice lolly machine!','"Sunshine falls on the solar panels on the roof," says Tinker, "and they turn it into electricity. That runs the freezer. So the hotter and sunnier it is, the more ice lollies I can make!"');}});};
/* Dino Valley: the baby triceratops splash in a paddling pool */
ISL.digcamp=A=>{const s=A.start||[0,0],p=place(A,s[0]+7,s[1]-9,4),x=p[0],z=p[1],y=gy(x,z);I('cyl','#ff9ecb',2.6,.5,2.6,x,y+.25,z);I('cyl','#7fd3f0',2.45,.51,2.45,x,y+.26,z,0,0,0,true);col(x,z,2.7);
  const babies=[];if(window.DINO&&DINO.trike3D)[0,1].forEach(i=>{const g=DINO.trike3D(i?'#7ab85a':'#e0a05a',i?'#ff9a3a':'#5fae9a',true);bakeModel(g,'sbtrike'+i);g.scale.setScalar(.5);g.position.set(x-.8+i*1.6,y+.1,z);g.rotation.y=i?-.6:2.4;W.ag.add(g);babies.push(g);});
  let splash=0;W.ticks.push(dt=>{if(W.area!==A)return true;if(splash>0)splash-=dt;babies.forEach((g,i)=>{g.position.y=y+.1+(splash>0?Math.abs(Math.sin(W.t*8+i*2))*.6:Math.abs(Math.sin(W.t*1.5+i))*.06);});});
  W.things.push({x,z:z+3.4,r:4.2,icon:'💦',label:'Paddling pool',act:()=>{if(player.lock)return;splash=3;SB.snd.splash();floatS('💦',x,y+2,z,2.4);reward('dinopool');
    setTimeout(()=>card2(big('🦕💦'),'Splash!','The baby triceratops love the paddling pool! Big animals today, like elephants and hippos, keep cool on hot days by splashing in water and rolling in mud.'),1300);}});};
/* Planet Hop: Captain Nibbles shows how the Moon makes the tides */
function tideSVG(){return `<svg viewBox="0 0 320 200" width="320"><rect width="320" height="200" rx="16" fill="#0b1030"/>${Array.from({length:18},(v,i)=>`<circle cx="${(i*53)%320}" cy="${(i*37)%200}" r="1.4" fill="#fff"/>`).join('')}`+
  `<ellipse cx="120" cy="100" rx="76" ry="58" fill="#3a8ae8" opacity=".85"/><circle cx="120" cy="100" r="50" fill="#5ab85a"/><path d="M95 80 q20 -12 36 2 q10 14 -8 22 q-20 6 -28 -8 Z" fill="#8ad86a"/>`+
  `<circle cx="282" cy="100" r="18" fill="#d8d8e0"/><path d="M200 100 H256" stroke="#ffd23f" stroke-width="4" stroke-dasharray="8 6"/><path d="M256 100 l-10 -6 v12 Z" fill="#ffd23f"/>`+
  `<text x="120" y="190" font-size="15" font-weight="900" text-anchor="middle" fill="#fff" font-family="Arial">the sea bulges towards the Moon</text></svg>`;}
ISL.moon=A=>{const s=A.start||[0,0],p=place(A,s[0]-6,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('box','#c8d0dc',2.4,1.6,.2,x,y+1.4,z);I('box','#0b1030',2.1,1.3,.22,x,y+1.4,z,0,0,0,true);I('sph','#3a8ae8',.4,.34,.05,x-.3,y+1.4,z+.13,0,0,0,true);I('sph','#d8d8e0',.15,.15,.05,x+.7,y+1.4,z+.13,0,0,0,true);
  [-1,1].forEach(k=>I('box','#8a92a0',.1,.8,.1,x+k*1,y+.4,z));col(x,z,1.4);
  W.things.push({x,z:z+2.2,r:3.6,icon:'🌊',label:'The Moon and the tides',act:()=>{if(player.lock)return;sfx.chime();reward('tides');
    card2(`<div class="fitsvg" style="width:320px">${tideSVG()}</div>`,'Captain Nibbles: the Moon makes the tides!','The Moon\'s gravity pulls on the sea, so the water bulges towards it. As the Earth spins, beaches move through the bulges, so most beaches get two high tides and two low tides every day.');}});};

/* ================= the spotlights ================= */
function prep(k){const C=COLLECT[k],A=W.area,s=[player.x,player.z],Gd=XM.grid(A,1),st=Gd.snap(s[0],s[1],1);C.items=[];if(st<0)return;const B=Gd.bfs(st),R=seed(Math.floor(Math.random()*9999)),out=[],n=C.n||8;
  for(let tries=0;tries<6000&&out.length<n;tries++){const kk=Math.floor(R()*Gd.N);if(Gd.clr[kk]<2||B.D[kk]>=1e9||B.D[kk]<6||B.D[kk]>60)continue;const p=Gd.xz(kk);if(out.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<6))continue;out.push(C.swimH!=null?[p[0],p[1],C.swimH]:[p[0],p[1]]);}
  C.items=out;}
COLLECT.sbrescue={k:'sbrescue',area:'bigrescue',icon:'🛟',size:2.2,h:1.2,items:[],start:null,thing:'swim ring',art:'🛟',n:8,
  intro:'Lifeguard Rescue! The waves have carried off the swim rings. Run along the beach and bring back all 8!',title:'Every swim ring is safe! Remember: swim between the red and yellow flags, where the lifeguards can see you.'};
const TREAS=['🪙','👑','🧭','🦪','🗝️','💎','🪙','⚓'];
COLLECT.sbsnorkel={k:'sbsnorkel',area:'ship',icon:'🪙',size:2,swimH:1.4,items:[],start:null,thing:'treasure',art:'🤿',n:8,
  intro:'Snorkel Treasure Hunt! There are 8 treasures hidden on the sea floor round the shipwreck. Find them all!',title:'All 8 treasures found! It is easier to float in the sea than in a pool, because salty water holds you up better.'};
function startSpot(k){if(player.lock||W.act)return;if(!W.area||W.area.id!==COLLECT[k].area)return;prep(k);if(COLLECT[k].items.length<5){say('Let\'s try that again in a moment!');return;}sfx.chime();startCollect(k);
  if(k==='sbsnorkel'&&W.act)W.act.items.forEach((it,i)=>{W.ag.remove(it.sp);it.sp=spr(TREAS[i%TREAS.length],2,it.x,it.y,it.z);});}
ISL.bigrescue=A=>{const s=A.start||[0,0],p=place(A,s[0]+5,s[1]-6,2);sign(p[0]+1.6,p[1]-1.6,'🛟 Lifeguard Rescue',3,6.4);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🛟',label:'Lifeguard Rescue',act:()=>startSpot('sbrescue')});
  [[-6,-3],[6,-3]].forEach((q,i)=>{const f=place(A,s[0]+q[0],s[1]+q[1]-10,1),y=gy(f[0],f[1]);I('cyl','#ffffff',.06,3,.06,f[0],y+1.5,f[1]);I('box','#e8423a',.7,.35,.04,f[0]+.36,y+2.8,f[1],0,0,0,true);I('box','#ffd23f',.7,.35,.04,f[0]+.36,y+2.45,f[1],0,0,0,true);});
  {const c=place(A,s[0]-7,s[1]-6,2),y=gy(c[0],c[1]);I('box','#e8423a',1.6,.2,1.6,c[0],y+2.2,c[1]);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>I('box','#ffffff',.12,2.2,.12,c[0]+q[0]*.7,y+1.1,c[1]+q[1]*.7));I('box','#ffd23f',1.2,.6,.06,c[0],y+2.7,c[1],0,0,0,true);col(c[0],c[1],1.2);}
  sayOnce('lifeguard','Chief Woofles is the lifeguard today! Find the Lifeguard Rescue sign on the beach.',2600);};
ISL.ship=A=>{const s=A.start||[0,0],p=place(A,s[0]+5,s[1]-6,2);sign(p[0]+1.6,p[1]-1.6,'🤿 Treasure Hunt',3,6.4);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🤿',label:'Snorkel Treasure Hunt',act:()=>startSpot('sbsnorkel')});
  sayOnce('snorkel','There is treasure hidden round the shipwreck! Find the Treasure Hunt sign.',2600);};
/* the Sandcastle Contest at the Harbour */
ISL.harbour=A=>{const s=A.start||[0,0],p=place(A,s[0]-5,s[1]-7,2),x=p[0],z=p[1];sign(x+1.6,z-1.6,'🏰 Sandcastle Contest',3,6.6);mk('plane',SAND,5,1,4,x+3,gy(x+3,z+2)+.05,z+2,W.ag);castle(x+2,z+2,.9);castle(x+4.2,z+1.6,.6);bucket(x+3.4,z+3.4);
  W.things.push({x,z,r:3.8,icon:'🏰',label:'Sandcastle Contest',act:()=>contest()});
  sayOnce('contest','It\'s the Sandcastle Contest at the Harbour! Find the sign and build a sandcastle for Chief Woofles.',2600);};
const ORDERS=[
 {say:'3 towers, 2 flags and 5 shells',t:3,f:2,s:5},
 {say:'4 towers, 4 flags and 6 shells',t:4,f:4,s:6},
 {say:'double 3 towers, 1 flag, and 2 shells on every tower',t:6,f:1,s:12,hint:'Double 3 is 6 towers. 2 shells on each of 6 towers is 6 lots of 2: 12 shells.'},
 {say:'5 towers with a flag on every tower, and 10 take away 3 shells',t:5,f:5,s:7,hint:'A flag on each of 5 towers is 5 flags. 10 take away 3 is 7 shells.'},
 {say:'4 towers with 3 shells on each, and 2 flags',t:4,f:2,s:12,hint:'4 lots of 3 shells is 12 shells.'}];
let SC=null;
function sandUI(){if($('#sbsand'))return;const d=el('div','ov','<div class="card" id="sbsCard"><h2 id="sbsH"></h2><div id="sbsOrder"></div><div id="sbsBox"></div><div id="sbsBtns"></div><p id="sbsMsg"></p><div class="btns"><button class="btn white" id="sbsBack">Back</button></div></div>');d.id='sbsand';document.body.appendChild(d);
  tap('#sbsBack',()=>{sfx.boop();$('#sbsand').classList.remove('on');player.lock=false;SC=null;});}
function castleSVG(c){const t=Math.max(1,c.t),w=Math.min(64,420/t);let s=`<svg viewBox="0 0 480 240" id="sbsSvg"><rect width="480" height="240" rx="18" fill="#bfe8ff"/><rect y="150" width="480" height="90" fill="${SAND}"/><rect x="30" y="140" width="420" height="60" rx="6" fill="#e8c87a" stroke="#a8784a" stroke-width="3"/>`;
  for(let i=0;i<c.t;i++){const x=240-(c.t*w)/2+i*w+w*.1,tw=w*.8;s+=`<rect x="${x}" y="72" width="${tw}" height="70" fill="#d8b468" stroke="#a8784a" stroke-width="3"/><path d="M${x} 72 h${tw*.25} v-10 h${tw*.25} v10 h${tw*.25} v-10 h${tw*.25} v10" fill="#d8b468" stroke="#a8784a" stroke-width="3"/>`;
    if(i<c.f)s+=`<path d="M${x+tw/2} 62 V28" stroke="#5b4636" stroke-width="3"/><path d="M${x+tw/2} 28 l22 7 l-22 7 Z" fill="${COLS[i%6]}" stroke="#5b4636" stroke-width="2"/>`;}
  for(let i=0;i<c.s;i++){const x=48+(i%14)*29,y=160+Math.floor(i/14)*24;s+=`<g transform="translate(${x} ${y})"><path d="M-9 5 Q-11 -7 0 -9 Q11 -7 9 5 Q0 10 -9 5 Z" fill="${['#ffd2a8','#ffffff','#ffb4c8'][i%3]}" stroke="#8a5a3a" stroke-width="1.6"/></g>`;}
  if(c.f>c.t)for(let i=c.t;i<c.f;i++)s+=`<text x="${440}" y="${40+(i-c.t)*20}" font-size="18">🚩</text>`;
  return s+'</svg>';}
function contest(){if(player.lock||W.act)return;sandUI();player.lock=true;hush();const first=!(state.acts||{}).sbsand;SC={r:0,t0:W.t,order:first?[0,1,2]:[0,1,2,3,4].sort(()=>Math.random()-.5).slice(0,3)};round();$('#sbsand').classList.add('on');}
function round(){const O=ORDERS[SC.order[SC.r]],c={t:0,f:0,s:0};SC.c=c;SC.O=O;SC.tries=0;
  $('#sbsH').textContent=`🏰 Sandcastle ${SC.r+1} of 3`;$('#sbsOrder').innerHTML=`<div class="sbord">📋 Chief Woofles wants: <b>${O.say}</b></div>`;
  const draw=()=>{$('#sbsBox').innerHTML=castleSVG(c);$('#sbsBtns').querySelectorAll('[data-n]').forEach(e=>{e.textContent=c[e.dataset.n];});};
  $('#sbsBtns').innerHTML=[['t','🏰','Tower'],['f','🚩','Flag'],['s','🐚','Shell']].map(q=>`<div class="sbsb"><button class="btn white sbminus" data-k="${q[0]}">−</button><button class="btn green sbplus" data-k="${q[0]}">${q[1]} ${q[2]}</button><b data-n="${q[0]}">0</b></div>`).join('')+`<button class="btn pink" id="sbsDone">✓ Finished!</button>`;
  document.querySelectorAll('#sbsBtns .sbplus').forEach(b=>tap(b,()=>{const k=b.dataset.k;if(c[k]>=20)return;c[k]++;SB.snd.dig();draw();}));
  document.querySelectorAll('#sbsBtns .sbminus').forEach(b=>tap(b,()=>{const k=b.dataset.k;if(c[k]<=0)return;c[k]--;sfx.boop();draw();}));
  tap('#sbsDone',()=>check());draw();const m=`Chief Woofles wants ${O.say}. Tap the buttons to build it!`;$('#sbsMsg').textContent='Tap the buttons to build it!';speak(m);}
function check(){const O=SC.O,c=SC.c;
  if(c.t===O.t&&c.f===O.f&&c.s===O.s){sfx.fanfare();confetti(30);const m=`Perfect! ${O.t} towers, ${O.f} ${O.f===1?'flag':'flags'} and ${O.s} shells. A gold rosette!`;$('#sbsMsg').textContent=m;speak(m);SC.r++;
    setTimeout(()=>{if(!SC)return;if(SC.r<3){round();return;}const secs=W.t-SC.t0;$('#sbsand').classList.remove('on');player.lock=false;SC=null;finishAct('sbsand',secs,big('🏰🏅'),'Sandcastle Champion! Chief Woofles gives you three gold rosettes.',()=>contest());},2000);return;}
  SC.tries++;sfx.oops();const bits=[];if(c.t!==O.t)bits.push(`${c.t} ${c.t===1?'tower':'towers'}, but we need ${O.t}`);if(c.f!==O.f)bits.push(`${c.f} ${c.f===1?'flag':'flags'}, but we need ${O.f}`);if(c.s!==O.s)bits.push(`${c.s} shells, but we need ${O.s}`);
  const m=`Nearly! You have ${bits.join('; ')}.`+(O.hint?' '+O.hint:'');$('#sbsMsg').textContent=m;speak(m);}
function sTravel(area,pos,start,msg){if(!SB.on()){state.season='sb';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='sb'&&S.hide)try{S.hide();}catch(e){}});}arcadeTravel(area,pos,start,msg);}
regAct('sbrescue',{name:'Lifeguard Rescue',icon:'🛟',island:'rescue',area:'bigrescue',where:'Summer Beach Party, at the Big Rescue beach',lockSay:'Find the Lifeguard Rescue on the Big Rescue beach in Summer Beach Party, and play it there first!',play:()=>sTravel('bigrescue',null,()=>startSpot('sbrescue'),'Lifeguard Rescue!')});
regAct('sbsand',{name:'Sandcastle Contest',icon:'🏰',island:'rescue',area:'harbour',where:'Summer Beach Party, at the Harbour',lockSay:'Find the Sandcastle Contest at the Harbour in Summer Beach Party, and play it there first!',play:()=>sTravel('harbour',null,()=>contest(),'The Sandcastle Contest!')});
regAct('sbsnorkel',{name:'Snorkel Treasure Hunt',icon:'🤿',island:'reef',area:'ship',where:'Summer Beach Party, at the Shipwreck',lockSay:'Find the Snorkel Treasure Hunt at the Shipwreck in Summer Beach Party, and play it there first!',play:()=>sTravel('ship',null,()=>startSpot('sbsnorkel'),'Snorkel Treasure Hunt!')});
/* the Den: a sandcastle, a parasol and deck chair, a beach towel, a bucket and spade, after the party */
ISL.den=A=>{if(!G().done)return;castle(-7,-5,1.1);parasol(7,-5,'#ff7fb8','#ffffff');chair(8.4,-4.2,'#5ab8ff',-.4);towel(5.5,-3,'#ffd23f',.3);bucket(-5.4,-3.6);bucket(-4.6,-4.4,'#5ab8ff');};

/* ================= the Lab: a summer science quiz ================= */
const SQ=[['Why is the sea salty?','Rain washes tiny bits of salt out of rocks, and rivers carry it down to the sea. When sea water dries up into clouds, the salt stays behind.',['Rivers carry salt from rocks','Fish make it salty','Somebody pours salt in'],'Rivers carry salt from rocks'],
 ['What makes the tides?','The Moon\'s gravity pulls on the sea, so the water bulges towards it. The Sun pulls a little too.',['The Moon pulling the sea','The wind','Whales swimming'],'The Moon pulling the sea'],
 ['How many high tides do most beaches get each day?','Most beaches get two high tides and two low tides every day.',['Two','One','Ten'],'Two'],
 ['Why do we wear sun cream?','Sun cream protects our skin from the Sun\'s ultraviolet light, which can burn even when you cannot feel it.',['To protect our skin from the Sun','To smell nice','To swim faster'],'To protect our skin from the Sun'],
 ['What is sand made of?','Sand is tiny bits of rock and shell, worn down by waves, wind and water over a very long time.',['Tiny bits of rock and shell','Sugar','Crumbs'],'Tiny bits of rock and shell'],
 ['Why is it easier to float in the sea than in a pool?','Salty water is heavier than fresh water, so it holds you up better.',['Salty water holds you up better','The sea is warmer','Pools have holes'],'Salty water holds you up better']];
const beachBG=()=>`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="768" fill="#9fdcff"/><circle cx="860" cy="140" r="70" fill="#ffe066"/><rect y="470" width="1024" height="110" fill="${SEA}"/>`+
  `<path d="M0 580 q64 -18 128 0 t128 0 t128 0 t128 0 t128 0 t128 0 t128 0 t128 0 V768 H0 Z" fill="${SAND}"/></svg>`;
QUIZ.summer={k:'summer',name:'Summer Science',icon:'🌊',n:6,bg:beachBG,introMs:3400,intro:'Professor Fizz has a summer science quiz! The sea, the tides, the Sun and sand. Let\'s find out!',
  make:i=>{const q=SQ[i%SQ.length],o=q[2].slice().sort(()=>Math.random()-.5);return {q:q[0],say:q[0]+' '+o.join(', or ')+'?',pic:'<div style="font-size:110px;line-height:1">🌊🐚</div>',ans:q[3],opts:o,hintSay:q[1],after:`<div style="font-size:26px;font-weight:800;padding:10px">${q[1]}</div>`};},
  block:()=>'🐚',title:'Brilliant! You are a summer science star!'};
if(typeof openLab==='function'){const base=openLab;openLab=function(){base.apply(this,arguments);if(!SB.on())return;setTimeout(()=>{if(document.querySelector('#lab .sbin'))return;const host=document.querySelector('#lab');if(!host)return;
  const b=el('button','btn green sbin','🌊 Summer science');b.style.cssText='position:absolute;right:24px;bottom:24px;z-index:30;font-size:24px';tap(b,()=>{sfx.pop();startQuiz('lab','summer');});host.appendChild(b);},50);};}

/* ================= music (both tunes are original) ================= */
const C1=s=>tuneRow(s);
/* a steel-drum style calypso for the village */
TUNES.sbvil={step:.2,mw:'triangle',mv:.42,hw:'sine',hv:.16,
  mel:C1('G5 . E5 G5 . E5 C5 . D5 E5 . F5 E5 . D5 . G5 . E5 G5 . E5 C5 . D5 . B4 . C5 - - . A5 . F5 A5 . F5 D5 . E5 F5 . G5 F5 . E5 . D5 . B4 D5 . G5 F5 . E5 . C5 . C5 - - .'),
  har:C1('E5 G5 C6 G5 E5 G5 C6 G5 F5 A5 C6 A5 G5 B5 D6 B5'),
  bas:C1('C3 . . C3 . . G3 . F3 . . F3 . . G3 . C3 . . C3 . . E3 . G3 . . G3 . . G3 .'),drm:'k.hsk.hsk.hsk.ho'};
/* a jolly sea-shanty jig for Seal Cove and the Treasure Dig */
TUNES.sbjig={step:.18,mw:'square',mv:.3,
  mel:C1('D5 . A4 D5 . F#5 A5 . F#5 D5 . F#5 E5 . C#5 A4 . . D5 . A4 D5 . F#5 A5 . B5 A5 . F#5 E5 . D5 D5 . . G5 . B5 G5 . B5 F#5 . A5 F#5 . A5 E5 . G5 E5 . C#5 D5 . F#5 E5 . C#5 D5 - - .'),
  bas:C1('D3 . . A2 . . D3 . . A2 . . G2 . . A2 . . D3 . . A2 . . D3 . . F#2 . . G2 . . A2 . . D3 . .'),drm:'k.hk.h'};
const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;if(SB.on()&&typeof W!=='undefined'&&W&&W.area){const id=W.area.id;if(id==='village')return 'sbvil';const T=SB.G0();if(id==='cove'&&T&&T.call&&!T.dug)return 'sbjig';}return _mk();};
/* a little steel-drum sparkle on the island tunes */
const _ps=playStep;playStep=function(T,i,t){_ps(T,i,t);if(!SB.on()||!AC||T===TUNES.sbvil||T===TUNES.sbjig||T===TUNES.disco)return;if(i%4===2){const m=T.mel&&T.mel[i%T.mel.length];if(m)try{tone(m.f*2,t,.12,'sine',.07,musF);tone(m.f*3,t,.06,'sine',.02,musF);}catch(e){}}};

/* ================= real-date sandcastle: around midsummer, by the Pup House, whatever the season ================= */
const isMidsummer=()=>{const d=new Date();return d.getMonth()===5&&d.getDate()>=20&&d.getDate()<=22;};
{const _ea=enterArea;enterArea=function(id){_ea.apply(this,arguments);if(id!=='village'||!isMidsummer()||!W.area||W.area.id!=='village')return;const ph=W.things.find(t=>/Pup House/.test(t.label||''));if(!ph)return;
  const p=near(W.area,ph.x+2.6,ph.z+2.2,1),q=near(W.area,ph.x-2.6,ph.z+2.2,1);castle(p[0],p[1],.9);parasol(q[0],q[1],'#ff7fb8','#ffffff');flushTo(W.ag);
  if(!SB.on()){const y=new Date().getFullYear(),k='sbmid_'+y;state.acts=state.acts||{};if(!state.acts[k]){state.acts[k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say('Happy midsummer, Seb! It is one of the longest days of the year. Look, there is a sandcastle by the Pup House!');},2600);}}};}

/* ================= build hooks ================= */
window.SBWORLD={build(A){if(A.id==='village')try{villageS(A);}catch(e){console.warn('sb village',e);}},
  after(A){GRD=null;try{decor(A);if(ISL[A.id])ISL[A.id](A);flushTo(W.ag);}catch(e){console.warn('sb island',A.id,e);}
    if(A.id==='village'&&window.SBSTORY&&SBSTORY.villageAfter)try{SBSTORY.villageAfter(A);}catch(e){}},
  parasol,chair,towel,ball,bucket,castle,flags,contest,startSpot,near,place,isMidsummer,ORDERS};
const css=document.createElement('style');css.textContent=`.sbrow{display:flex;gap:12px;justify-content:center;margin:12px 0;flex-wrap:wrap}.sbrow .opt{display:flex;flex-direction:column;align-items:center;font-size:18px;padding:8px 12px}
#sbsand{z-index:60}#sbsCard{max-width:960px;width:96%;background:#fff8e6;padding-top:12px;padding-bottom:10px}#sbsCard h2{margin:0 0 4px}.sbord{font-size:24px;font-weight:800;background:#fff;border:4px solid #8a6238;border-radius:16px;padding:6px 14px;display:inline-block}.sbord b{color:#e8423a}
#sbsBox svg{width:560px;max-width:100%;height:auto;display:block;margin:6px auto;border-radius:16px}#sbsBtns{display:flex;gap:14px;justify-content:center;align-items:center;flex-wrap:wrap}
.sbsb{display:flex;align-items:center;gap:6px}.sbsb .btn{min-height:64px;font-size:24px;padding:0 14px}.sbsb .sbminus{min-width:56px;padding:0}.sbsb b{font-size:30px;min-width:40px;text-align:center}#sbsDone{min-height:64px;font-size:24px}#sbsMsg{min-height:34px;font-size:22px;font-weight:800;margin:6px 0}`;
document.head.appendChild(css);
})();
