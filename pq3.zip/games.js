/* ================================================================
   Seb's Puppy Quest 3: friend games, the Games Arcade and
   Sheep Herding with Cali.
   Treat Toss, Tummy Tickle, Bubble Pop and Paw Pairs are ported
   from Puppy Quest 2. After a pup is rescued, Seb plays one friend
   game with it to fill its hearts, then the pup is found.
   ================================================================ */
let scale=1,mg=null,lastTs=0,HD=null;
const GAMES={
  toss:{name:'Treat Toss',icon:'🍎',time:30,how:'Tap the treat when the ring turns green!'},
  tickle:{name:'Tummy Tickle',icon:'👆',time:15,how:'Rub the tummy as fast as you can!'},
  bubbles:{name:'Bubble Pop',icon:'🔵',time:30,how:'Pop the bubbles! Gold ones are worth more!'},
  pairs:{name:'Paw Pairs',icon:'🃏',time:0,how:'Find the matching pairs!'},
  maze:{name:'Maze Race',icon:'🌻',time:0,how:''},stones:{name:'Stepping Stones',icon:'🪨',time:0,how:''},flies:{name:'Firefly Catch',icon:'✨',time:0,how:''},
  herd:{name:'Sheep Herding',icon:'🐑',time:0,how:'Drag your finger and Cali will follow. The sheep run away from Cali, so steer them into the pen!'}};
/* difficulty: ring speed, ring window, speed cap, tickle distance per heart, tickle time, bubble rise speed, bubble size, spawn gap, pops per heart, pairs */
const DIFF={1:{ts:2,tol:.17,cap:4.6,tick:620,tkT:15,bs:1,bz:1,bi:1,bp:4,pairs:6},2:{ts:2.6,tol:.14,cap:5.3,tick:780,tkT:13,bs:.8,bz:.88,bi:.85,bp:5,pairs:8},3:{ts:3.2,tol:.12,cap:6,tick:940,tkT:11,bs:.66,bz:.78,bi:.72,bp:6,pairs:10}};
const dif=()=>mg&&mg.mode==='friend'?DIFF[1]:DIFF[Math.min(3,1+Math.floor(Object.keys(state.found).length/10))];
const AREA_BG={windmill:'meadow',sunflowers:'hills',pond:'park',wood:'woods',village:'park'};
const FRIEND_GAMES=['toss','tickle','bubbles'];
const arcadeOpen=()=>Object.keys(state.found).filter(id=>PUPS[id]).length>=3;

/* ----- friend games: called when a rescue is finished ----- */
function friendGame(p,s){const i=Object.keys(PUPS).indexOf(p.id);W.friendWait=null;startGame(FRIEND_GAMES[(i<0?0:i)%3],'friend',{p,s});}
function gStop(){if(mg){clearInterval(mg.timer);clearInterval(mg.spawn);}}
function startGame(game,mode,r){
  gStop();joyReset();const p=r?r.p:(pupById(state.buddy)||PUPS.buttercup),friend=mode==='friend';
  mg={game,mode,r,p,need:friend?(p.tag?3:2):0,got:0,score:0,streak:0,pause:false,over:false,t:0,sc:1,speed:0,tol:0,miss:0,dist:0,last:null,pops:0,left:0,secs:0,green:false,t0:Date.now(),timer:null,spawn:null};
  const D=dif();mg.speed=D.ts;mg.tol=D.tol;mg.left=game==='tickle'?D.tkT:GAMES[game].time;
  $('#bfBg').innerHTML=bg(AREA_BG[W.area&&W.area.id]||'park');$('#bfPup').innerHTML=`<div class="jmp">${pupBox(p)}</div>`;
  const on=(ids,v)=>ids.forEach(id=>{$('#'+id).style.display=v?'':'none';});
  on(['ring','ringT','treatBtn','flyT'],game==='toss');on(['rubPad','hand','meter'],game==='tickle');on(['bubs'],game==='bubbles');on(['pairs'],game==='pairs');on(['bfPup'],game!=='pairs');
  $('#meter b').style.width='0';$('#flyT').style.opacity=0;$('#bubs').innerHTML='';$('#pairs').innerHTML='';gHud();show('game');
  say(friend?(game==='tickle'?`Make friends with ${p.name}! Tickle ${p.name}'s tummy. Rub with your finger!`:game==='bubbles'?`Make friends with ${p.name}! Pop the bubbles to fill the hearts!`:`Make friends with ${p.name}! Tap the treat when the ring turns green!`):GAMES[game].how);
  if(game==='toss'){lastTs=0;requestAnimationFrame(tossLoop);}
  if(game==='bubbles')mg.spawn=setInterval(spawnBub,Math.round((friend?560:430)*D.bi));
  if(game==='pairs')buildPairs();
  if(!friend)mg.timer=setInterval(()=>{if(!mg||mg.over||cur!=='game'||ovOpen()||sleepOn)return;mg.secs++;if(mg.game!=='pairs'){mg.left--;if(mg.left<=3&&mg.left>0)sfx.boop();if(mg.left<=0)return endArcade();}gHud();},1000);
}
function gHud(){if(!mg)return;$('#gScore').textContent='⭐ '+mg.score;
  $('#hearts').innerHTML=mg.mode==='friend'?Array.from({length:mg.need},(_,i)=>`<span class="${i<mg.got?'full':''}">💖</span>`).join(''):`<b class="clock">⏱ ${mg.game==='pairs'?mg.secs:mg.left}</b>`;}
function addScore(n,x,y){mg.score+=n;$('#gScore').textContent='⭐ '+mg.score;if(x!=null){const d=el('span','fl pts','+'+n);d.style.left=(x-30)+'px';d.style.top=(y-30)+'px';$('#fx').appendChild(d);setTimeout(()=>d.remove(),1200);}}
function gain(){if(!mg||mg.mode!=='friend')return;mg.got++;gHud();sfx.yip(mg.p.pitch);anim($('#bfPup .jmp'),'t-jump',650);floaty(512,330,'💖',4);
  if(mg.got>=mg.need){mg.pause=true;mg.over=true;gStop();setTimeout(friendWin,900);}}
function friendWin(){if(!mg)return;const p=mg.p,s=mg.r.s,sc=mg.score;mg=null;$('#bubs').innerHTML='';hush();
  state.stars+=5;state.stats.friendGames=(state.stats.friendGames||0)+1;show('world');hud();freePup(p,s,sc);}

/* treat toss */
function tossLoop(ts){
  if(!mg||mg.game!=='toss'||cur!=='game'||mg.over)return;const dt=Math.min(.05,(ts-(lastTs||ts))/1000);lastTs=ts;
  if(!mg.pause&&!ovOpen()&&!sleepOn){mg.t+=dt*mg.speed;const sc=1.12+.42*Math.sin(mg.t);mg.sc=sc;$('#ring').style.transform=`translate(-50%,-50%) scale(${sc.toFixed(3)})`;const g=Math.abs(sc-1)<mg.tol;
    if(g!==mg.green){mg.green=g;$('#ring').classList.toggle('go',g);$('#treatBtn').classList.toggle('go',g);}}
  requestAnimationFrame(tossLoop);}
tap('#treatBtn',()=>{
  if(!mg||mg.pause||mg.over||mg.game!=='toss')return;
  if(mg.green){const acc=1-Math.abs(mg.sc-1)/mg.tol,pts=Math.round(50+50*acc)+Math.min(mg.streak,5)*10;mg.streak++;if(mg.streak>(state.stats.streak||0))state.stats.streak=mg.streak;mg.pause=true;sfx.chime();addScore(pts,512,250);if(acc>.6)floaty(512,200,'🌟',1);
    const f=$('#flyT');f.style.transition='none';f.style.transform='translate(0,0)';f.style.opacity=1;void f.offsetWidth;f.style.transition='';f.style.transform='translate(-330px,-190px) scale(.5)';
    setTimeout(()=>{if(!mg)return;f.style.opacity=0;if(mg.mode==='friend'){gain();if(mg&&!mg.over)setTimeout(()=>{if(mg)mg.pause=false;},600);}else{sfx.yip(mg.p.pitch);anim($('#bfPup .jmp'),'t-jump',650);mg.speed=Math.min(dif().cap,mg.speed*1.07);mg.pause=false;}},mg.mode==='friend'?420:260);}
  else{mg.miss++;mg.streak=0;if(mg.mode==='friend'){mg.speed=Math.max(.9,mg.speed*.82);mg.tol=Math.min(.32,mg.tol+.04);}sfx.oops();anim($('#bfPup .jmp'),'t-spin',750);if(mg.miss===1)say('Nearly! Wait for the green ring, then tap!');}});

/* tummy tickle */
(function(){const pad=$('#rubPad');let down=false,gl=0,wt=null;
  pad.addEventListener('pointerdown',e=>{initAudio();if(!mg||mg.game!=='tickle'||mg.over)return;down=true;mg.last=[e.clientX,e.clientY];$('#hand').style.display='none';});
  pad.addEventListener('pointermove',e=>{if(!down||!mg||mg.game!=='tickle'||mg.over)return;const d=Math.hypot(e.clientX-mg.last[0],e.clientY-mg.last[1])/scale;mg.last=[e.clientX,e.clientY];if(d<1)return;mg.dist+=d;
    const j=$('#bfPup .jmp');j.classList.add('wig');clearTimeout(wt);wt=setTimeout(()=>j.classList.remove('wig'),220);
    const now=Date.now();if(now-gl>380){gl=now;sfx.giggle();floaty(512+(Math.random()-.5)*160,440,'💖',1);}
    if(mg.mode==='friend'){const per=dif().tick,tot=mg.need*per;$('#meter b').style.width=Math.min(100,mg.dist/tot*100)+'%';const g=Math.min(mg.need,Math.floor(mg.dist/per));
      while(mg&&mg.got<g&&!mg.over){if(mg.got+1>=mg.need){const sec=(Date.now()-mg.t0)/1000;addScore(Math.max(100,Math.round(700-sec*45)),512,250);down=false;j.classList.remove('wig');}gain();}}
    else{mg.score=Math.round(mg.dist/20);$('#gScore').textContent='⭐ '+mg.score;$('#meter b').style.width=(mg.dist/20%100)+'%';}});
  ['pointerup','pointercancel','pointerleave'].forEach(n=>pad.addEventListener(n,()=>{down=false;}));})();

/* bubble pop */
function spawnBub(){
  if(!mg||mg.game!=='bubbles'||mg.over||cur!=='game'||ovOpen()||sleepOn)return;const c=$('#bubs');if(c.children.length>9)return;
  const D=dif(),gold=Math.random()<.14,sz=(96+Math.random()*44)*D.bz,b=el('button','bub'+(gold?' gold':''),gold?'⭐':'');b.style.width=b.style.height=sz+'px';b.style.left=(50+Math.random()*(924-sz))+'px';b.style.animationDuration=((3.4+Math.random()*1.8)*D.bs)+'s';
  b.addEventListener('pointerdown',e=>{e.preventDefault();initAudio();if(!mg||mg.over||b.dataset.x)return;b.dataset.x=1;const r=b.getBoundingClientRect(),s=$('#stage').getBoundingClientRect(),x=(r.left+r.width/2-s.left)/scale,y=(r.top+r.height/2-s.top)/scale;
    b.remove();sfx.pop();addScore(gold?30:10,x,y);floaty(x,y,gold?'🌟':'💦',1);mg.pops++;state.stats.pops=(state.stats.pops||0)+1;if(mg.mode==='friend'&&mg.pops%dif().bp===0)gain();});
  b.addEventListener('animationend',()=>b.remove());c.appendChild(b);}

/* paw pairs */
function buildPairs(){
  const NP=dif().pairs,cols=NP>8?5:4,rows=NP*2/cols,cw=cols>4?150:(rows>3?140:170),ch=rows>3?130:172,sx=cols>4?170:190,sy=rows>3?144:188,x0=512-((cols-1)*sx+cw)/2,y0=rows>3?176:196;
  const c=$('#pairs'),fs=Object.values(PUPS).filter(p=>isFound(p.id)).sort(()=>Math.random()-.5).slice(0,NP),items=fs.map(p=>({k:p.id,h:pupBox(p,{anim:false})}));
  ['🍎','🎾','🌼','🥕','⭐','🦋','🦴','🌈','🍪','🎈'].forEach(e=>{if(items.length<NP)items.push({k:e,h:`<span>${e}</span>`});});
  const deck=items.concat(items).map(o=>({k:o.k,h:o.h})).sort(()=>Math.random()-.5);let first=null,lock=false,moves=0,done=0;
  deck.forEach((o,i)=>{const b=el('button','pc','<span>🐾</span>');b.style.left=(x0+(i%cols)*sx)+'px';b.style.top=(y0+Math.floor(i/cols)*sy)+'px';b.style.width=cw+'px';b.style.height=ch+'px';
    tap(b,()=>{if(!mg||mg.over||lock||b.classList.contains('up'))return;sfx.boop();b.classList.add('up');b.innerHTML=o.h;
      if(!first){first={b,o};return;}moves++;const a=first;first=null;
      if(a.o.k===o.k){done++;sfx.chime();a.b.classList.add('done');b.classList.add('done');addScore(100,512,120);if(done>=NP){mg.score=Math.max(100,NP*220-moves*30-mg.secs*5);setTimeout(endArcade,500);}}
      else{lock=true;sfx.oops();setTimeout(()=>{[a.b,b].forEach(x=>{x.classList.remove('up');x.innerHTML='<span>🐾</span>';});lock=false;},850);}});
    c.appendChild(b);});}

/* ----- arcade endings, leaving a game, and the Games Arcade menu ----- */
function endArcade(){
  if(!mg||mg.over)return;mg.over=true;gStop();const g=mg.game,G2=GAMES[g];state.hi=state.hi||{};const best=state.hi[g]||0,isNew=mg.score>best;if(isNew)state.hi[g]=mg.score;state.played=state.played||{};state.played[g]=(state.played[g]||0)+1;
  const st=Math.min(30,Math.floor(mg.score/40));state.stars+=st;save();hush();if(isNew){confetti(60);sfx.fanfare();}else sfx.jingle();
  const sc=mg.score;
  card({art:`<div style="font-size:100px;line-height:1.1">${G2.icon}</div>`,h:g==='pairs'?'All matched!':"Time's up!",h3:G2.name,p:`<span style="font-size:50px">⭐ ${sc}</span><br>${isNew?'🏆 New high score!':'🏆 Best: '+best}${st?`<br>+${st} stars`:''}`,
    say:isNew?`New high score! ${sc} points!`:`You scored ${sc} points!`,btns:[['Again ▶','green',()=>startGame(g,'arcade')],['Done','white',()=>{mg=null;backToWorld();}]]});}
function backToWorld(msg){show('world');hud();player.lock=false;if(msg)say(msg);}
tap('#bfBack',()=>{if(!mg||(mg.over&&mg.mode==='friend'))return;sfx.boop();gStop();const m=mg;mg=null;$('#bubs').innerHTML='';
  if(m.mode==='friend'){W.friendWait={p:m.p,s:m.r.s};backToWorld(`${m.p.name} is still waiting to play. Tap the heart button when you are ready!`);}else backToWorld();});
/* ================= the Games Arcade menu, grouped by island ================= */
const ACTS={};
function regAct(k,o){ACTS[k]=o;}
function arcadeTravel(area,pos,start,msg){player.lock=true;sfx.chime();fadeTo(()=>{enterArea(area,pos,msg||'Get ready!');setTimeout(start,1200);},['⭐','Off we go!']);}
let arcTab='games';
function openGames(tab){hush();arcTab=tab||arcTab;const c=$('#menuCard');c.className='card wide';state.hi=state.hi||{};state.acts=state.acts||{};
  const isl=ISLANDS.filter(I=>islOpen(I.id)&&Object.values(ACTS).some(a=>a.island===I.id));if(arcTab!=='games'&&!isl.some(I=>I.id===arcTab))arcTab='games';
  const locked=k=>ACTS[k]?(ACTS[k].need?!ACTS[k].need():!state.acts[k]):false;
  const best=k=>ACTS[k]?(state.hi[k]?state.hi[k]+'s':'-'):(state.hi[k]||0);
  const info=k=>ACTS[k]||GAMES[k];
  const row=k=>{const l=locked(k),G2=info(k);return `<button class="grow${l?' lock':''}" data-g="${k}"><span class="gi">${G2.icon}</span><span class="gn">${G2.name}${l?' 🔒':''}</span><span class="gb">🏆 ${best(k)}</span></button>`;};
  const keys=arcTab==='games'?['toss','tickle','bubbles','pairs']:Object.keys(ACTS).filter(k=>ACTS[k].island===arcTab);
  const tabs=[['games','🎮 Games']].concat(isl.map(I=>[I.id,`${I.icon} ${I.name}`])).map(t=>`<button class="atab${t[0]===arcTab?' sel':''}" data-t="${t[0]}">${t[1]}</button>`).join('');
  c.innerHTML=`<h2>🎮 Games Arcade</h2><div class="atabs">${tabs}</div><div class="gcols">${keys.map(row).join('')}</div><div class="btns"><button class="btn white" data-g="">Close ✕</button></div>`;
  $('#menu').classList.add('on');if(!tab)speak('Welcome to the Games Arcade! Pick a game.');
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();if(b.dataset.t){sfx.boop();openGames(b.dataset.t);return;}const k=b.dataset.g;
    if(k&&locked(k)){sfx.oops();const A=ACTS[k];say(A.lockSay||`Find ${A.name} in ${A.where} and play it there first. Then you can play it here too!`);return;}
    $('#menu').classList.remove('on');c.onclick=null;
    if(k&&ACTS[k]){sfx.pop();ACTS[k].play();}else if(k){sfx.pop();startGame(k,'arcade');}else{sfx.boop();quiet();}};}

/* ================= shared activity finish: fastest time, stars ================= */
function finishAct(k,secs,art,title,again,toWorld,extra){secs=Math.max(1,Math.round(secs));state.hi=state.hi||{};state.acts=state.acts||{};
  const best=state.hi[k]||0,isNew=!best||secs<best;if(isNew)state.hi[k]=secs;const first=!state.acts[k];state.acts[k]=(state.acts[k]||0)+1;
  const st=first?30:10;state.stars+=st;save();hud();confetti(70);sfx.fanfare();hush();
  card({art,h:title,h3:`⏱ ${secs} seconds`,p:`${extra?extra+'<br>':''}${isNew?'🏆 Your fastest time!':'🏆 Fastest: '+best+' seconds'}<br>+${st} stars${first?' for your first go!':''}`,
    say:`${title} You took ${secs} seconds.${isNew?' That is your fastest time!':''}`,btns:[['Again ▶','green',again],['Done','white',()=>{if(toWorld)backToWorld();}]]});}
const buddyPup=()=>pupById(state.buddy)||PUPS.buttercup;

/* ================= herding (sheep, penguins, fish) ================= */
const PEN={x1:740,y1:250,x2:985,y2:600,gy1:350,gy2:500};
const HERDS={herd:{k:'herd',icon:'🐑',n:5,animal:()=>sheepSVG(),herder:()=>PUPS.cali,bg:()=>herdBgSVG(),title:'All the sheep are home!',
  intro:()=>'The sheep have wandered out of their pen! Help Cali herd them back in. Drag your finger and Cali will follow. The sheep run away from Cali!'}};
let NSHEEP=5;
function sheepSVG(){const k=INK;return `<svg viewBox="0 0 90 76"><g stroke="${k}" stroke-width="3.5">
  <path d="M26 58 v14 M38 60 v13 M56 60 v13 M66 58 v14" stroke-linecap="round"/>
  <g fill="#ffffff"><circle cx="30" cy="34" r="16"/><circle cx="46" cy="26" r="17"/><circle cx="62" cy="34" r="16"/><circle cx="40" cy="46" r="16"/><circle cx="58" cy="46" r="15"/></g></g>
  <g stroke="none" fill="#ffffff"><circle cx="46" cy="38" r="17"/><circle cx="34" cy="40" r="12"/><circle cx="58" cy="40" r="12"/></g>
  <ellipse cx="80" cy="34" rx="12" ry="14" fill="#3a3338" stroke="${k}" stroke-width="3"/><ellipse cx="70" cy="24" rx="7" ry="4" fill="#3a3338" transform="rotate(-25 70 24)"/>
  <circle cx="84" cy="31" r="3" fill="#fff"/><circle cx="85" cy="31" r="1.6" fill="${k}"/><circle cx="79" cy="20" r="6" fill="#ffffff" stroke="${k}" stroke-width="2.5"/></svg>`;}
function herdBgSVG(){const k=INK,P=PEN;let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="hsky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#a6dfff"/><stop offset="1" stop-color="#e9fbff"/></linearGradient></defs>
  <rect width="1024" height="140" fill="url(#hsky)"/><path d="M0 110 Q200 70 420 100 T1024 96 V140 H0Z" fill="#a8e08c"/>
  <g transform="translate(150 20)"><rect x="-16" y="20" width="32" height="80" fill="#fff8e6" stroke="${k}" stroke-width="4"/><path d="M-20 22 L0 2 L20 22Z" fill="#e8423a" stroke="${k}" stroke-width="4"/><g stroke="${k}" stroke-width="3" fill="#fff8e6"><rect x="-4" y="-30" width="8" height="70" transform="rotate(20 0 10)"/><rect x="-4" y="-30" width="8" height="70" transform="rotate(110 0 10)"/></g></g>
  <rect y="120" width="1024" height="648" fill="#9bd77f"/>`;
  for(let i=0;i<70;i++){const x=(i*137)%1000+12,y=150+(i*89)%600;s+=`<path d="M${x} ${y} l4 -10 l4 10" stroke="#6fbf5a" stroke-width="3" fill="none"/>`;if(i%5===0)s+=`<circle cx="${x+20}" cy="${y-4}" r="6" fill="${['#ffffff','#fff27a','#ff9ecb'][i%3]}"/>`;}
  s+=`<rect x="${P.x1}" y="${P.y1}" width="${P.x2-P.x1}" height="${P.y2-P.y1}" fill="#c9e88f" opacity=".7"/>`;
  const post=(x,y)=>`<rect x="${x-7}" y="${y-30}" width="14" height="40" rx="4" fill="#c9905f" stroke="${k}" stroke-width="3"/>`,rail=(x1,y1,x2,y2)=>`<path d="M${x1} ${y1-18} L${x2} ${y2-18} M${x1} ${y1-4} L${x2} ${y2-4}" stroke="${k}" stroke-width="10" stroke-linecap="round"/><path d="M${x1} ${y1-18} L${x2} ${y2-18} M${x1} ${y1-4} L${x2} ${y2-4}" stroke="#e0b06a" stroke-width="5" stroke-linecap="round"/>`;
  s+=rail(P.x1,P.y1,P.x2,P.y1)+rail(P.x2,P.y1,P.x2,P.y2)+rail(P.x1,P.y2,P.x2,P.y2)+rail(P.x1,P.y1,P.x1,P.gy1)+rail(P.x1,P.gy2,P.x1,P.y2);
  [[P.x1,P.y1],[P.x2,P.y1],[P.x2,P.y2],[P.x1,P.y2],[P.x1,P.gy1],[P.x1,P.gy2],[(P.x1+P.x2)/2,P.y1],[(P.x1+P.x2)/2,P.y2],[P.x2,(P.y1+P.y2)/2]].forEach(q=>s+=post(q[0],q[1]));
  s+=`<g transform="translate(${P.x1+60} ${P.y1+40})"><rect x="-4" y="0" width="8" height="40" fill="#9b6a43"/><rect x="-56" y="-30" width="112" height="40" rx="10" fill="#fff" stroke="${k}" stroke-width="4"/><text x="0" y="-2" font-size="24" font-weight="900" text-anchor="middle" fill="${k}">🐑 Pen</text></g>
  <path d="M${P.x1-70} ${(P.gy1+P.gy2)/2} l40 0 m-14 -14 l14 14 l-14 14" stroke="#fff" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity=".9"/></svg>`;return s;}
function pondSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="pw" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7fd3f0"/><stop offset="1" stop-color="#4fb0e0"/></linearGradient></defs>
  <rect width="1024" height="768" fill="url(#pw)"/><rect width="1024" height="150" fill="#bfe8ff"/><path d="M0 130 Q250 90 512 120 T1024 110 V170 H0Z" fill="#8fd170"/>`;
  for(let i=0;i<26;i++){const x=(i*173)%980+20,y=200+(i*97)%540;s+=`<path d="M${x} ${y} q14 -8 28 0" stroke="#fff" stroke-width="4" fill="none" opacity=".5"/>`;}
  [[300,230],[700,700],[560,215],[420,705]].forEach(p=>s+=`<path d="M${p[0]} ${p[1]} m-34 0 a34 24 0 1 0 68 0 l-34 -4Z" fill="#4fae4a" stroke="${k}" stroke-width="3"/><circle cx="${p[0]+12}" cy="${p[1]-8}" r="7" fill="#ff9ecb"/>`);
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#8fd170" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#8fd170" stroke="${k}" stroke-width="5"/>`;
  for(let i=0;i<10;i++){s+=`<path d="M${20+(i%3)*30} ${180+i*58} l3 -24 M${30+(i%3)*30} ${184+i*58} l-4 -20" stroke="#4f9e3a" stroke-width="4"/>`;s+=`<circle cx="${940+(i%3)*24}" cy="${190+i*56}" r="7" fill="${['#fff27a','#ffffff','#ff9ecb'][i%3]}" stroke="${k}" stroke-width="2"/>`;}
  return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🏁</text></svg>`;}
function nightSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="nt" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1d2350"/><stop offset="1" stop-color="#3b4f86"/></linearGradient></defs><rect width="1024" height="768" fill="url(#nt)"/>
  <circle cx="860" cy="120" r="54" fill="#fff6c9"/><circle cx="880" cy="108" r="48" fill="#1d2350" opacity=".25"/>`;
  for(let i=0;i<40;i++)s+=`<circle cx="${(i*211)%1010+7}" cy="${(i*67)%300+10}" r="${1+i%3}" fill="#fff" opacity="${.4+(i%4)*.15}"/>`;
  [[60,1.3],[200,1],[330,1.2],[700,1.1],[820,1.3],[960,1]].forEach(t=>{const x=t[0],sc=t[1];s+=`<rect x="${x-14*sc}" y="${420-40*sc}" width="${28*sc}" height="${360}" fill="#141a38"/><circle cx="${x}" cy="${330-60*sc}" r="${110*sc}" fill="#18204a"/><circle cx="${x+60*sc}" cy="${380-50*sc}" r="${80*sc}" fill="#1a2350"/>`;});
  s+=`<path d="M0 640 Q260 600 512 630 T1024 620 V768 H0Z" fill="#26386a"/>`;for(let i=0;i<60;i++)s+=`<circle cx="${(i*131)%1020}" cy="${650+(i*37)%110}" r="5" fill="#7b86e0" opacity=".85"/>`;
  return s+'</svg>';}
function jarSVG(){const k=INK;return `<svg viewBox="0 0 160 190"><rect x="34" y="6" width="92" height="22" rx="8" fill="#c9905f" stroke="${k}" stroke-width="5"/><path d="M30 34 Q14 44 14 70 V160 Q14 182 40 182 H120 Q146 182 146 160 V70 Q146 44 130 34Z" fill="rgba(220,240,255,.35)" stroke="#fff" stroke-width="6"/></svg>`;}
function startHerd(mode,key){gStop();mg=null;hush();joyReset();key=key||'herd';const sk=HERDS[key],hp=sk.herder();
  const f=$('#herdField');f.innerHTML='';$('#herdBg').innerHTML=sk.bg();
  const H={mode,key,sk,t:0,sheep:[],cali:{x:150,y:450,tx:150,ty:450,face:1},penned:0,over:false,last:0,down:false,n:sk.n};NSHEEP=sk.n;
  for(let i=0;i<sk.n;i++){const e=el('div','sheep',sk.animal());f.appendChild(e);H.sheep.push({x:330+Math.random()*260,y:200+Math.random()*440,vx:0,vy:0,e,in:false,ph:Math.random()*6});}
  const c=el('div','cali',pupBox(hp,{anim:false}));f.appendChild(c);H.ce=c;HD=H;herdHud();show('herd');
  say(mode==='arcade'&&key==='herd'?GAMES.herd.how:sk.intro(hp));requestAnimationFrame(herdLoop);}
function herdHud(){const H=HD;if(!H)return;$('#herdInfo').textContent=`${H.sk.icon} ${H.penned}/${H.n}  ⏱ ${Math.floor(H.t)}`;}
(function(){const f=$('#herdField'),to=e=>{const s=$('#stage').getBoundingClientRect();return[(e.clientX-s.left)/scale,(e.clientY-s.top)/scale];};
  f.addEventListener('pointerdown',e=>{initAudio();if(!HD||HD.over)return;HD.down=true;const p=to(e);HD.cali.tx=p[0];HD.cali.ty=p[1];});
  f.addEventListener('pointermove',e=>{if(!HD||HD.over||!HD.down)return;const p=to(e);HD.cali.tx=p[0];HD.cali.ty=p[1];});
  ['pointerup','pointercancel','pointerleave'].forEach(n=>f.addEventListener(n,()=>{if(HD)HD.down=false;}));})();
function herdLoop(ts){const H=HD;if(!H||cur!=='herd'||H.over)return;requestAnimationFrame(herdLoop);const dt=Math.min(.05,((ts-(H.last||ts))/1000)||0);H.last=ts;if(ovOpen()||sleepOn)return;
  H.t+=dt;const C=H.cali,P=PEN,r=26;
  {const dx=C.tx-C.x,dy=C.ty-C.y,d=Math.hypot(dx,dy);if(d>4){const sp=Math.min(430,d*5);C.x+=dx/d*sp*dt;C.y+=dy/d*sp*dt;if(Math.abs(dx)>6)C.face=dx<0?-1:1;}C.x=Math.max(40,Math.min(984,C.x));C.y=Math.max(150,Math.min(740,C.y));}
  const out=H.sheep.filter(s=>!s.in),cx=out.reduce((a,s)=>a+s.x,0)/(out.length||1),cy=out.reduce((a,s)=>a+s.y,0)/(out.length||1);
  H.sheep.forEach(s=>{
    if(s.in){s.vx+=Math.sin(H.t*.9+s.ph)*30*dt;s.vy+=Math.cos(H.t*.7+s.ph)*30*dt;s.vx*=1-2*dt;s.vy*=1-2*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;
      s.x=Math.max(P.x1+45,Math.min(P.x2-40,s.x));s.y=Math.max(P.y1+40,Math.min(P.y2-30,s.y));}
    else{const dx=s.x-C.x,dy=s.y-C.y,d=Math.hypot(dx,dy)||1;
      if(d<200){const f=(200-d)/200*1100;s.vx+=dx/d*f*dt;s.vy+=dy/d*f*dt;if(d<120&&Math.random()<dt*1.5)sfx.boop();}
      s.vx+=(cx-s.x)*.25*dt;s.vy+=(cy-s.y)*.25*dt;s.vx+=Math.sin(H.t*1.3+s.ph)*18*dt;s.vy+=Math.cos(H.t*1.1+s.ph)*18*dt;
      H.sheep.forEach(o=>{if(o===s||o.in)return;const ex=s.x-o.x,ey=s.y-o.y,e=Math.hypot(ex,ey)||1;if(e<64){s.vx+=ex/e*(64-e)*6*dt;s.vy+=ey/e*(64-e)*6*dt;}});
      s.vx*=1-2.2*dt;s.vy*=1-2.2*dt;const sp=Math.hypot(s.vx,s.vy);if(sp>280){s.vx*=280/sp;s.vy*=280/sp;}
      s.x+=s.vx*dt;s.y+=s.vy*dt;
      if(s.x<40){s.x=40;s.vx=Math.abs(s.vx)*.5;}if(s.x>990){s.x=990;s.vx=-Math.abs(s.vx)*.5;}if(s.y<170){s.y=170;s.vy=Math.abs(s.vy)*.5;}if(s.y>740){s.y=740;s.vy=-Math.abs(s.vy)*.5;}
      if(s.x>P.x1-r&&s.x<P.x2+r&&s.y>P.y1-r&&s.y<P.y2+r){
        if(s.x>P.x1+40&&s.y>P.gy1-60&&s.y<P.gy2+60){s.in=true;H.penned++;sfx.chime();floaty(s.x,s.y-40,'💚',2);addHerdStar(s);herdHud();}
        else if(s.y>P.gy1+8&&s.y<P.gy2-8&&s.x<P.x1+45){}
        else{const o=[s.x-(P.x1-r),(P.x2+r)-s.x,s.y-(P.y1-r),(P.y2+r)-s.y],m=Math.min(...o);
          if(m===o[0]){s.x=P.x1-r;s.vx=-Math.abs(s.vx)*.4;}else if(m===o[1]){s.x=P.x2+r;s.vx=Math.abs(s.vx)*.4;}else if(m===o[2]){s.y=P.y1-r;s.vy=-Math.abs(s.vy)*.4;}else{s.y=P.y2+r;s.vy=Math.abs(s.vy)*.4;}}}}
    s.e.style.transform=`translate(${(s.x-50).toFixed(1)}px,${(s.y-66).toFixed(1)}px) scaleX(${s.vx<-5?-1:1})`;});
  H.ce.style.transform=`translate(${(C.x-62).toFixed(1)}px,${(C.y-112).toFixed(1)}px) scaleX(${C.face})`;
  if(Math.floor(H.t)!==Math.floor(H.t-dt))herdHud();
  if(H.penned>=H.n)herdDone();}
function addHerdStar(s){const d=el('span','fl pts','+10');d.style.left=(s.x-30)+'px';d.style.top=(s.y-80)+'px';$('#fx').appendChild(d);setTimeout(()=>d.remove(),1200);}
function herdDone(){const H=HD;H.over=true;finishAct(H.sk.k,H.t,pupBox(H.sk.herder()),H.sk.title,()=>startHerd(H.mode,H.key),true);}
tap('#herdBack',()=>{if(!HD)return;sfx.boop();const m=HD.mode;HD.over=true;HD=null;backToWorld(m==='activity'?'You can come back and play again any time!':null);});

/* ================= collecting races in the 3D world ================= */
const MAZE_SEEDS=[[10,-27],[-40,-27],[-8,-17],[-42,-17],[6,3],[-38,13]];
const COLLECT={maze:{k:'maze',area:'sunflowers',icon:'🌻',h:5.6,items:MAZE_SEEDS,start:[18,30,Math.PI],thing:'golden sunflower',art:'🌻',
  intro:'Ready, steady, go! Find the 6 golden sunflowers floating over the sunflower maze. Walk under each one to collect it!',title:'You finished the Sunflower Maze Race!'}};
function startCollect(key){const C=COLLECT[key];if(!W.area||W.area.id!==C.area||W.act||player.ski)return;hush();
  W.act={k:key,C,icon:C.icon,t:0,got:0,items:C.items.map(p=>{const swim=p[2]!=null,y=gy(p[0],p[1])+(swim?p[2]:(C.h!=null?C.h:1.8));return {x:p[0],z:p[1],y,swim,sp:spr(C.icon,C.size||2.4,p[0],y,p[1]),ring:swim?null:spr('✨',1.4,p[0],gy(p[0],p[1])+1.2,p[1])};})};
  sfx.chime();say(C.intro);hud();}
const startMaze=()=>startCollect('maze');
function actTick(dt){const A=W.act;if(!A)return;A.t+=dt;const C=A.C;
  A.items.forEach((it,i)=>{if(it.got)return;const bob=Math.sin(W.t*3+i)*.4;it.sp.position.y=it.y+bob;
    const close=it.swim?Math.hypot(player.x-it.x,player.z-it.z,player.y+1-it.y)<2.6:Math.hypot(player.x-it.x,player.z-it.z)<2.4;
    if(close){it.got=true;W.ag.remove(it.sp);if(it.ring)W.ag.remove(it.ring);A.got++;sfx.chime();floatS('⭐',it.x,it.y,it.z,2);
      const left=A.items.length-A.got;if(left)say(`${A.got}! ${left} more ${left>1?C.thing+'s':C.thing} to find!`);}});
  if(Math.floor(A.t*4)!==Math.floor((A.t-dt)*4))hud();
  if(A.got>=A.items.length){const t=A.t;W.act=null;hud();finishAct(C.k,t,`<div style="font-size:110px;line-height:1">${C.art}</div>`,C.title,()=>startCollect(C.k),false);}}

/* ================= counting stones (pond stones, ice blocks, shells) ================= */
const STONE_ROUNDS=[{step:2,word:'twos'},{step:5,word:'fives'},{step:10,word:'tens'},{step:3,word:'threes'}],STONE_N=8;
const COUNTS={stones:{k:'stones',icon:'🪨',rounds:STONE_ROUNDS,bg:()=>pondSVG(),cls:'',intro:'Help your pup hop across Lily Pond!',title:'You counted all the way across!'}};
let SS=null;
function startStones(mode,key){gStop();mg=null;hush();joyReset();key=key||'stones';const sk=COUNTS[key];SS={mode,key,sk,round:0,col:0,t:0,wrong:0,over:false,last:0,busy:false};$('#stBg').innerHTML=sk.bg();show('stones');stonesRound(true);requestAnimationFrame(stonesLoop);}
const roundVal=(R,c)=>(R.start!=null?R.start:R.step)+R.step*c;
function stonesRound(first){const S=SS,sk=S.sk,R=sk.rounds[S.round],f=$('#stField');f.innerHTML='';S.col=0;S.wrong=0;S.busy=false;
  const xs=i=>184+i*96,ys=[300,450,600];S.cols=[];
  for(let c=0;c<STONE_N;c++){const v=roundVal(R,c),prev=v-R.step,pool=[v+1,v-1,v+R.step,v+2,v+2*R.step,v-2].filter(n=>n>0&&n!==v&&n!==prev),opts=[];
    while(opts.length<2&&pool.length){const n=pool.splice(Math.floor(Math.random()*pool.length),1)[0];if(opts.indexOf(n)<0)opts.push(n);}
    const row=Math.floor(Math.random()*3),vals=[];let j=0;for(let r=0;r<3;r++)vals.push(r===row?v:opts[j++]);
    const col=vals.map((n,r)=>{const b=el('button','stone '+(sk.cls||''),String(n));b.style.left=(xs(c)-46)+'px';b.style.top=(ys[r]-38)+(c%2?18:-18)+'px';b.dataset.v=n;b.dataset.c=c;
      b.addEventListener('pointerdown',e=>{e.preventDefault();initAudio();stoneTap(b);});f.appendChild(b);return b;});S.cols.push({v,col,row});}
  const p=el('div','hopper',pupBox(buddyPup(),{anim:false}));f.appendChild(p);S.pe=p;stoneMove(60,410,true);
  stInfo();const say1=`Count in ${R.word}! Tap the stones in order: ${roundVal(R,0)}, ${roundVal(R,1)}, ${roundVal(R,2)}, and keep going to the other side!`;
  if(first)say(`${sk.intro} ${say1}`);else say(say1);}
function stoneMove(x,y,snap){const p=SS.pe;if(snap)p.style.transition='none';p.style.left=(x-60)+'px';p.style.top=(y-110)+'px';if(snap){void p.offsetWidth;p.style.transition='';}else anim(p,'t-jump',450);}
function stInfo(){if(!SS)return;$('#stInfo').textContent=`${SS.sk.icon} ${SS.round+1}/${SS.sk.rounds.length}  ⏱ ${Math.floor(SS.t)}`;}
function stoneTap(b){const S=SS;if(!S||S.over||S.busy)return;const c=+b.dataset.c,v=+b.dataset.v;if(c!==S.col){if(c>S.col){sfx.oops();say('Hop one stone at a time!');}return;}
  const C=S.cols[c],R=S.sk.rounds[S.round];if(v===C.v){sfx.yip(buddyPup().pitch);b.classList.add('ok');C.col.forEach(x=>{if(x!==b)x.classList.add('gone');});speak(String(v));
    stoneMove(parseFloat(b.style.left)+46,parseFloat(b.style.top)+38);S.col++;S.wrong=0;
    if(S.col>=STONE_N){S.busy=true;setTimeout(()=>{stoneMove(964,430);sfx.jingle();floaty(900,300,'⭐',4);},500);
      setTimeout(()=>{S.round++;if(S.round>=S.sk.rounds.length){S.over=true;stonesDone();}else{say(`Great counting! Now let's count in ${S.sk.rounds[S.round].word}!`);setTimeout(()=>{if(SS===S&&!S.over)stonesRound(false);},2600);}},1300);}}
  else{sfx.oops();anim(b,'shake',400);floaty(parseFloat(b.style.left)+46,parseFloat(b.style.top)+20,'💦',1);S.wrong++;const prev=c>0?roundVal(R,c-1):null;
    if(S.wrong>=2){C.col[C.row].classList.add('hint');say(prev!=null?`Count in ${R.word}. After ${prev} comes ${C.v}. Look for the shiny one!`:`Count in ${R.word}. Start with ${C.v}. Look for the shiny one!`);}
    else say(prev!=null?`Not that one. Count in ${R.word}. What comes after ${prev}?`:`Not that one. Count in ${R.word}. Start with ${C.v}!`);}}
function stonesLoop(ts){const S=SS;if(!S||cur!=='stones'||S.over)return;requestAnimationFrame(stonesLoop);const dt=Math.min(.05,((ts-(S.last||ts))/1000)||0);S.last=ts;if(ovOpen()||sleepOn)return;S.t+=dt;if(Math.floor(S.t)!==Math.floor(S.t-dt))stInfo();}
function stonesDone(){const S=SS;finishAct(S.sk.k,S.t,pupBox(buddyPup()),S.sk.title,()=>startStones(S.mode,S.key),true);}
tap('#stBack',()=>{if(!SS)return;sfx.boop();const m=SS.mode;SS.over=true;SS=null;backToWorld(m==='activity'?'You can come back and count again any time!':null);});

/* ================= catching (fireflies, snowflakes, glow-fish) ================= */
let FF=null;const JAR={x:512,y:660};
const CATCH={flies:{k:'flies',icon:'✨',need:15,bg:()=>nightSVG(),cls:'',inner:'<i></i>',art:'🫙✨',intro:'Catch the fireflies! Tap a firefly while it is glowing, and it will fly into your jar. Catch 15!',tip:'Wait until it glows, then tap!',title:'You caught 15 fireflies!'}};
function startFlies(mode,key){gStop();mg=null;hush();joyReset();key=key||'flies';const sk=CATCH[key],f=$('#ffField');f.innerHTML='';f.className=sk.cls||'';$('#ffBg').innerHTML=sk.bg();
  const jar=el('div','jar',`<div class="fill"></div>${jarSVG()}`);f.appendChild(jar);
  FF={mode,key,sk,t:0,got:0,flies:[],over:false,last:0,tipT:0};for(let i=0;i<9;i++)addFly();ffInfo();show('flies');say(sk.intro);requestAnimationFrame(fliesLoop);}
function addFly(){const f=$('#ffField'),sk=FF.sk,rb=Math.random()<.1,b=el('button','ffly'+(rb?' rb':''),sk.inner);const o={x:80+Math.random()*860,y:170+Math.random()*380,vx:0,vy:0,ph:Math.random()*6,glow:Math.random()<.5,timer:Math.random()*2,e:b,rb,gone:false};
  b.addEventListener('pointerdown',e=>{e.preventDefault();initAudio();flyTap(o);});f.appendChild(b);FF.flies.push(o);}
function flyTap(o){const F=FF;if(!F||F.over||o.gone)return;
  if(!o.glow){sfx.boop();o.vx+=(Math.random()-.5)*400;o.vy-=150;if(F.t-F.tipT>6){F.tipT=F.t;say(F.sk.tip);}return;}
  o.gone=true;const n=o.rb?3:1,need=F.sk.need;F.got=Math.min(need,F.got+n);sfx.chime();if(o.rb){floaty(o.x,o.y,'🌈',2);}
  o.e.style.transition='transform .6s ease-in, opacity .6s';o.e.style.transform=`translate(${JAR.x-35}px,${JAR.y-35}px) scale(.4)`;o.e.style.opacity='.2';setTimeout(()=>o.e.remove(),650);
  F.flies=F.flies.filter(q=>q!==o);ffInfo();const fill=document.querySelector('#ffField .jar .fill');if(fill)fill.style.height=(F.got/need*100)+'%';
  if(F.got>=need){F.over=true;setTimeout(fliesDone,800);}else setTimeout(()=>{if(FF===F&&!F.over)addFly();},700);}
function ffInfo(){if(!FF)return;$('#ffInfo').textContent=`${FF.sk.icon} ${FF.got}/${FF.sk.need}  ⏱ ${Math.floor(FF.t)}`;}
function fliesLoop(ts){const F=FF;if(!F||cur!=='flies'||F.over)return;requestAnimationFrame(fliesLoop);const dt=Math.min(.05,((ts-(F.last||ts))/1000)||0);F.last=ts;if(ovOpen()||sleepOn)return;
  F.t+=dt;if(Math.floor(F.t)!==Math.floor(F.t-dt))ffInfo();const sk=F.sk;
  F.flies.forEach(o=>{if(o.gone)return;o.vx+=Math.sin(F.t*1.7+o.ph)*60*dt;o.vy+=Math.cos(F.t*1.3+o.ph*1.7)*60*dt;if(sk.fall)o.vy+=30*dt;if(sk.swim)o.vx+=(o.ph>3?40:-40)*dt;o.vx*=1-1.2*dt;o.vy*=1-1.2*dt;const sp=Math.hypot(o.vx,o.vy);if(sp>110){o.vx*=110/sp;o.vy*=110/sp;}
    o.x+=o.vx*dt;o.y+=o.vy*dt;if(o.x<50){o.x=50;o.vx=Math.abs(o.vx);if(sk.swim)o.ph=4;}if(o.x>974){o.x=974;o.vx=-Math.abs(o.vx);if(sk.swim)o.ph=1;}if(o.y<150){o.y=150;o.vy=Math.abs(o.vy);}if(o.y>560){if(sk.fall){o.y=150;}else{o.y=560;o.vy=-Math.abs(o.vy);}}
    o.timer-=dt;if(o.timer<=0){o.glow=!o.glow;o.timer=o.glow?1.8+Math.random()*1.6:.8+Math.random()*1;}
    o.e.classList.toggle('on',o.glow);o.e.style.transform=`translate(${(o.x-35).toFixed(1)}px,${(o.y-35).toFixed(1)}px)${sk.swim&&o.vx<0?' scaleX(-1)':''}`;});}
function fliesDone(){const F=FF;F.flies.forEach(o=>{o.glow=true;o.e.classList.add('on');});finishAct(F.sk.k,F.t,`<div style="font-size:110px;line-height:1">${F.sk.art}</div>`,F.sk.title,()=>startFlies(F.mode,F.key),true);}
tap('#ffBack',()=>{if(!FF)return;sfx.boop();const m=FF.mode;FF.over=true;FF=null;backToWorld(m==='activity'?'You can come back and play again any time!':null);});

/* ================= the Meadow activities in the arcade ================= */
regAct('herd',{name:'Sheep Herding',icon:'🐑',island:'meadow',area:'windmill',where:'Windmill Hill',need:()=>isFound('cali'),lockSay:'Find Cali the Border Collie on Windmill Hill, then she can play Sheep Herding with you!',play:()=>startHerd('arcade','herd')});
regAct('maze',{name:'Maze Race',icon:'🌻',island:'meadow',area:'sunflowers',where:'Sunflower Fields',play:()=>arcadeTravel('sunflowers',COLLECT.maze.start,()=>startCollect('maze'),'The Sunflower Maze Race is about to start!')});
regAct('stones',{name:'Stepping Stones',icon:'🪨',island:'meadow',area:'pond',where:'Lily Pond',play:()=>startStones('arcade','stones')});
regAct('flies',{name:'Firefly Catch',icon:'✨',island:'meadow',area:'wood',where:'Bluebell Wood',play:()=>startFlies('arcade','flies')});

/* games and activities keep the sleepy-break clock ticking */
setInterval(()=>{if((cur==='game'||cur==='herd'||cur==='stones'||cur==='flies')&&!sleepOn&&!ovOpen()&&state)playClock(1);},1000);
