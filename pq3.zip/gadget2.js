/* Gadget Island refresh (25 Nov 2026; every recommendation chosen in claude/gadget-number-refresh.md):
   zone floors and pads, a giant friendly robot in each area and a bigger moving Mega Bot, a container maze with a
   mini-map in the Factory (Dynamo, Pixel and a treasure chest inside), a chain-reaction machine in the Workshop,
   moving walkways, a bounce pad, delivery drones and a monorail round the island. Loaded after edges2.js. */
(function(){
const PI=Math.PI,AREAS_G=['workshop','factory','lightlab','mine','launch','robotyard'];
const beep=(f,d,ty,v,dl)=>{try{if(AC&&state.set.sfx!==false)tone(f,AC.currentTime+(dl||0),d||.1,ty||'square',v||.1);}catch(e){}};
const inZ=(Z,x,z)=>Z.some(q=>q.r!=null?Math.hypot(x-q.x,z-q.z)<q.r:(x>q.x1&&x<q.x2&&z>q.z1&&z<q.z2));
function segZ(a,b,w){const Z=[],n=Math.ceil(Math.hypot(b[0]-a[0],b[1]-a[1])/2);for(let i=0;i<=n;i++)Z.push({x:a[0]+(b[0]-a[0])*i/n,z:a[1]+(b[1]-a[1])*i/n,r:w});return Z;}
function clearZ(Z){for(const k in instMap){const o=instMap[k];o.m=o.m.filter(m=>{const e=m.elements;return !inZ(Z,e[12],e[14]);});}W.cols=W.cols.filter(c=>!inZ(Z,c.x,c.z));}
const texCache={};
function floorIcon(x,z,ch,s,rot){const key='fi'+ch;let tx=texCache[key];if(!tx){const c=document.createElement('canvas');c.width=c.height=128;const g=c.getContext('2d');g.font='96px sans-serif';g.textAlign='center';g.textBaseline='middle';g.fillText(ch,64,70);tx=texCache[key]=new THREE.CanvasTexture(c);}
  const m=new THREE.Mesh(new THREE.PlaneGeometry(s,s),new THREE.MeshBasicMaterial({map:tx,transparent:true,depthWrite:false}));m.rotation.x=-PI/2;m.rotation.z=rot||0;m.position.set(x,gy(x,z)+.06,z);W.ag.add(m);return m;}
function pad(x,z,r,col,ch){const y=gy(x,z);I('disc','#ffd23f',r+.55,r+.55,1,x,y+.025,z,-PI/2,0,0);I('disc','#26232e',r+.25,r+.25,1,x,y+.03,z,-PI/2,0,0);I('disc',col,r,r,1,x,y+.035,z,-PI/2,0,0);if(ch)floorIcon(x,z,ch,r*1.25);}

/* ---------------- floors and pads ---------------- */
const ZONE={
 workshop:{g:['#d6a26c','#cc9862'],pad:'#5b8def',pads:[[-15,13,3,'⚙️'],[5,-4,2.6,'🤖'],[10,6,2.2,'🥽']]},
 factory:{g:['#8fb0d6','#86a7cd'],pad:'#ffd23f',pads:[[-3,10,3,'🔩']]},
 lightlab:{g:['#eef1f6','#e3e8ef'],pad:'#b58cff',pads:[[6,5,3,'🌈']]},
 mine:{g:['#b07a5a','#a46f50'],pad:'#5cb8ff',pads:[[5,10,3,'🛤️']]},
 launch:{g:['#6a707a','#61666f'],pad:'#ff8a3c',pads:[[7,11,3,'🚀']]},
 robotyard:{g:['#93a387','#889a7c'],pad:'#e8423a',pads:[[-14,-3,3,'🤖'],[0,-16,2.6,'🦄']]}};

/* ---------------- giant friendly robots ---------------- */
function giantBot(job,col){const g=grp(),b=grp();g.add(b);const P={g,b};
  P.legs=[-1,1].map(s=>{const L=grp();L.position.set(s*.55,2.2,0);b.add(L);mk('box','#5b6378',.5,2.2,.6,0,-1.1,0,L);mk('box','#3a3f4c',.7,.35,.9,0,-2.1,.12,L);return L;});
  mk('box',col,1.9,2.4,1.3,0,3.4,0,b);mk('box','#ffd23f',.8,.5,.06,0,3.6,.66,b);mk('box','#26232e',1.95,.25,1.35,0,2.35,0,b);
  const h=grp();h.position.set(0,4.6,0);b.add(h);P.head=h;mk('box','#e6eaf0',1.3,1,1,0,.5,0,h);mk('box','#26232e',1.05,.5,.06,0,.55,.51,h);
  P.eyes=[-.25,.25].map(x=>mk('sph','#7fffe0',.12,.12,.04,x,.58,.55,h,true));mk('cyl','#8a8f99',.04,.5,.04,0,1.2,0,h);mk('sph','#e8423a',.12,.12,.12,0,1.5,0,h,true);
  P.arms=[-1,1].map(s=>{const A=grp();A.position.set(s*1.15,4.3,0);b.add(A);mk('cyl',col,.18,1.6,.18,0,-.8,0,A);mk('sph','#5b6378',.25,.25,.25,0,-1.65,0,A);return A;});
  const R=P.arms[1],Lf=P.arms[0];
  if(job==='crate'){P.arms.forEach(a=>a.rotation.x=-1.2);mk('box','#c98a4f',1.5,1.1,1.1,0,3.3,1.25,b);mk('box','#8a5a32',1.55,.12,1.15,0,3.3,1.25,b);}
  if(job==='broom'){R.rotation.x=-.5;mk('cyl','#c98a4f',.07,2.6,.07,0,-1.9,.4,R).rotation.x=.5;mk('box','#f2d27a',.9,.3,.4,0,-3.1,1.0,R);}
  if(job==='weld'){R.rotation.x=-1;mk('cyl','#3a3640',.12,.8,.12,0,-1.9,0,R);P.fx=mk('sph','#ffb347',.22,.22,.22,0,-2.4,0,R,true);}
  if(job==='crane'){R.rotation.z=.4;mk('box','#ffd23f',.3,3,.3,0,-2.6,0,R);mk('cyl','#3a3640',.03,1,.03,0,-4.4,0,R);mk('tor','#8a8f99',.2,.2,.3,0,-5,0,R);}
  if(job==='flags'){[R,Lf].forEach((a,i)=>{a.rotation.z=(i?1:-1)*2.2;mk('cyl','#3a3640',.05,1,.05,0,-2,0,a);mk('cyl',i?'#3fae5a':'#e8423a',.45,.06,.45,0,-2.6,0,a).rotation.x=PI/2;});}
  if(job==='bulb'){R.rotation.z=2.5;P.fx=mk('sph','#fff27a',.5,.5,.5,0,-2.1,0,R,true);}
  return P;}
function walker(spec){const P=giantBot(spec.job,spec.col),s=spec.s||1,a=spec.path[0],b=spec.path[1],L=Math.hypot(b[0]-a[0],b[1]-a[1]);P.g.scale.setScalar(s);add(P.g,a[0],a[1]);
  const c1={x:a[0],z:a[1],r:1.35*s};W.cols.push(c1);let u=0,dir=1,ph=0,said=false,face=0;
  W.ticks.push(dt=>{if(!P.g.parent)return true;const g=P.g,dx=player.x-g.position.x,dz=player.z-g.position.z,dp=Math.hypot(dx,dz);ph+=dt;
    if(P.fx){const k=.8+Math.random()*.6;P.fx.scale.setScalar(k*(spec.job==='bulb'?.5:.22));}
    P.eyes.forEach(e=>e.scale.y=(ph%4<.12)?.02:.12);
    if(dp<7*s){const want=Math.atan2(dx,dz);let d=want-g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));g.rotation.y+=d*Math.min(1,dt*3);
      P.legs.forEach(l=>l.rotation.x*=.9);if(spec.job!=='flags'){const A=P.arms[1];A.rotation.x*=.9;A.rotation.z=2.3+Math.sin(ph*7)*.35;}
      if(!said){said=true;beep(660,.08);beep(990,.12,'square',.1,.1);say(spec.line);}}
    else{u+=dir*dt*1.3/L;if(u>1){u=1;dir=-1;}if(u<0){u=0;dir=1;}const x=a[0]+(b[0]-a[0])*u,z=a[1]+(b[1]-a[1])*u;g.position.set(x,gy(x,z),z);
      const want=Math.atan2((b[0]-a[0])*dir,(b[1]-a[1])*dir);let d=want-g.rotation.y;d=Math.atan2(Math.sin(d),Math.cos(d));g.rotation.y+=d*Math.min(1,dt*4);
      const sw=Math.sin(ph*4)*.45;P.legs[0].rotation.x=sw;P.legs[1].rotation.x=-sw;P.b.position.y=Math.abs(Math.cos(ph*4))*.12;
      if(spec.job==='broom')P.arms[1].rotation.z=Math.sin(ph*5)*.3;if(spec.job!=='flags'&&spec.job!=='crate'&&spec.job!=='broom'&&spec.job!=='weld'&&spec.job!=='crane'&&spec.job!=='bulb')P.arms[1].rotation.z*=.9;
      if(spec.job==='flags')P.arms.forEach((A,i)=>A.rotation.z=(i?1:-1)*(2.2+Math.sin(ph*3+i)*.25));}
    c1.x=g.position.x;c1.z=g.position.z;});
  return P;}
const BOTS={
 workshop:{job:'broom',col:'#ff8a3c',path:[[-31,-4],[-13,-4]],line:"Beep boop! I'm Sweepy. I keep the Workshop spick and span!"},
 factory:{job:'crate',col:'#5b8def',path:[[14,-12],[32,-12]],line:"Beep! I'm Lifty. I carry crates all day. Have you tried the container maze?"},
 lightlab:{job:'bulb',col:'#b58cff',path:[[14,16],[30,16]],line:"Hello! I'm Glow-bot. I carry the brightest bulb on Gadget Island!"},
 mine:{job:'crane',col:'#ffd23f',path:[[-30,10],[-12,10]],line:"Clank clank! I'm Clanky. I lift heavy rocks with my crane arm!"},
 launch:{job:'flags',col:'#e8423a',path:[[-32,-8],[-12,-8]],line:"Stop! Go! I'm Signal. I keep the Launch Range safe for take-off!"},
 robotyard:{job:'weld',col:'#3fae5a',path:[[12,-6],[28,-6]],line:"Bzzt! I'm Sparky. I weld broken robots back together!"}};

/* ---------------- drones and the monorail ---------------- */
function drones(R){[0,1].forEach(i=>{const g=grp();mk('box','#e6eaf0',1,.35,1,0,0,0,g);mk('cyl','#3a3640',1.1,.04,1.1,0,.28,0,g);mk('box',['#c98a4f','#ff7fb8'][i],.6,.6,.6,0,-.9,0,g);mk('cyl','#3a3640',.02,.5,.02,0,-.4,0,g);
  W.ag.add(g);const r=R*(i?.55:.4),h=10+i*2,sp=(i?-1:1)*.22;let t=i*2;W.ticks.push(dt=>{if(!g.parent)return true;t+=dt*sp;g.position.set(Math.cos(t)*r,gy(0,0)+h+Math.sin(t*3)*.4,Math.sin(t)*r);g.rotation.y=-t;});});}
function monorail(A){const Rt=A.R-9,y0=gy(0,0),ex=(A.exits||[]).map(e=>Math.atan2(e.z,e.x)).concat(A.start?[Math.atan2(A.start[1],A.start[0])]:[]),near=a=>ex.some(e=>Math.abs(Math.atan2(Math.sin(a-e),Math.cos(a-e)))<.32);
  for(let i=0;i<64;i++){const a=i*PI/32,x=Math.cos(a)*Rt,z=Math.sin(a)*Rt;I('box','#c9d2e3',.9,.5,Rt*PI/32+.15,x,y0+9,z,0,-a,0);}
  for(let i=0;i<10;i++){const a=i*PI/5+.31;if(near(a))continue;const x=Math.cos(a)*Rt,z=Math.sin(a)*Rt;I('cyl','#8a8f99',.35,9,.35,x,y0+4.5,z);col(x,z,.6);}
  const tr=grp();[0,1,2].forEach(k=>{const c=grp();mk('box',k?'#5b8def':'#e8423a',1.4,1.3,3.2,0,.65,0,c);mk('box','#bfe8ff',1.42,.45,2.6,0,.9,0,c,true);c.userData.k=k;tr.add(c);});W.ag.add(tr);
  let th=Math.random()*6;W.ticks.push(dt=>{if(!tr.parent)return true;th+=dt*5/Rt;tr.children.forEach((c,k)=>{const a=th-k*3.5/Rt;c.position.set(Math.cos(a)*Rt,y0+9.3,Math.sin(a)*Rt);c.rotation.y=-a;});});}

/* ---------------- moving walkways and bounce pads ---------------- */
function walkway(x1,z1,x2,z2,w){const L=Math.hypot(x2-x1,z2-z1),ux=(x2-x1)/L,uz=(z2-z1)/L,cx=(x1+x2)/2,cz=(z1+z2)/2;
  let tx=texCache.ww;if(!tx){const c=document.createElement('canvas');c.width=64;c.height=64;const g=c.getContext('2d');g.fillStyle='#3a3f4c';g.fillRect(0,0,64,64);g.fillStyle='#ffd23f';g.beginPath();g.moveTo(16,44);g.lineTo(32,20);g.lineTo(48,44);g.lineTo(40,44);g.lineTo(32,32);g.lineTo(24,44);g.fill();tx=texCache.ww=new THREE.CanvasTexture(c);tx.wrapS=tx.wrapT=THREE.RepeatWrapping;}
  const t2=tx.clone();t2.needsUpdate=true;t2.repeat.set(1,L/w);const m=new THREE.Mesh(new THREE.PlaneGeometry(w,L),new THREE.MeshBasicMaterial({map:t2}));m.rotation.x=-PI/2;m.rotation.z=Math.atan2(-ux,-uz)+PI;m.position.set(cx,gy(cx,cz)+.05,cz);W.ag.add(m);
  [-1,1].forEach(s=>I('box','#ffd23f',.25,.18,L,cx-uz*s*(w/2+.15),gy(cx,cz)+.09,cz+ux*s*(w/2+.15),0,Math.atan2(ux,uz),0));
  W.ticks.push(dt=>{if(!m.parent)return true;t2.offset.y-=dt*.9;const P=player;if(P.lock||W.hop)return;const dx=P.x-cx,dz=P.z-cz,al=dx*ux+dz*uz,ac=-dx*uz+dz*ux;
    if(Math.abs(al)<L/2&&Math.abs(ac)<w/2){const r=resolve(P.x+ux*dt*4,P.z+uz*dt*4);P.x=r[0];P.z=r[1];}});}
function bouncePad(x,z){pad(x,z,1.6,'#3fae5a','⬆️');I('cyl','#ff4f6d',1.3,.25,1.3,x,gy(x,z)+.12,z);let armed=true;
  W.ticks.push(dt=>{const P=player,d=Math.hypot(P.x-x,P.z-z);if(W.hop){const H=W.hop;H.u+=dt/1.7;const k=Math.min(1,H.u);P.x=x;P.z=z;P.y=walkY(x,z)+Math.sin(k*PI)*10;if(P.grp)P.grp.position.y=P.y;if(k>=1){W.hop=null;P.lock=false;}return;}
    if(d>2.4)armed=true;if(armed&&d<1.3&&!P.lock){armed=false;W.hop={u:0};P.lock=true;beep(220,.25,'sine',.15);beep(440,.3,'sine',.12,.12);beep(880,.25,'sine',.1,.3);floatS('🦘',x,gy(x,z)+2,z,2,1);}});}

/* ---------------- the Factory container maze ---------------- */
const MZ={x0:-34,z0:8,n:6,c:4};
const MAZE=(()=>{const n=MZ.n,R=seed(4242),vis=[...Array(n*n)].map(()=>false),walls=new Set(),k=(i,j,d)=>i+','+j+','+d;
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){walls.add(k(i,j,'E'));walls.add(k(i,j,'S'));}
  const st=[[0,0]];vis[0]=true;while(st.length){const [i,j]=st[st.length-1],nb=[[i+1,j,'E',i,j],[i-1,j,'E',i-1,j],[i,j+1,'S',i,j],[i,j-1,'S',i,j-1]].filter(q=>q[0]>=0&&q[1]>=0&&q[0]<n&&q[1]<n&&!vis[q[0]+q[1]*n]);
    if(!nb.length){st.pop();continue;}const q=nb[Math.floor(R()*nb.length)];walls.delete(k(q[3],q[4],q[2]));vis[q[0]+q[1]*n]=true;st.push([q[0],q[1]]);}
  const deg=(i,j)=>[!walls.has(k(i,j,'E'))&&i<n-1,i>0&&!walls.has(k(i-1,j,'E')),!walls.has(k(i,j,'S'))&&j<n-1,j>0&&!walls.has(k(i,j-1,'S'))].filter(Boolean).length;
  const ends=[];for(let i=0;i<n;i++)for(let j=0;j<n;j++)if(deg(i,j)===1)ends.push([i,j]);
  return {walls,k,ends,cell:(i,j)=>[MZ.x0+MZ.c*(i+.5),MZ.z0+MZ.c*(j+.5)],door:{e:4,n:0}};})();
/* Dynamo, Pixel and the treasure chest hide in dead ends far from the way in (east side, row 4) */
(function(){const E=MAZE.ends.slice().sort((p,q)=>Math.hypot(q[0]-5,q[1]-4)-Math.hypot(p[0]-5,p[1]-4));const pick=E.filter(e=>!(e[0]===5&&e[1]===4)&&!(e[0]===0&&e[1]===0));
  MAZE.spots=pick.slice(0,3).map(e=>MAZE.cell(e[0],e[1]));
  if(PUPS.dynamo){PUPS.dynamo.spot={x:MAZE.spots[1][0],z:MAZE.spots[1][1],kind:'crate'};PUPS.dynamo.hint='Dynamo is hiding in a crate deep in the container maze in the Factory. The map shows where you are!';}
  if(PUPS.pixel){PUPS.pixel.spot={x:MAZE.spots[0][0],z:MAZE.spots[0][1],kind:'toybox'};PUPS.pixel.hint='Pixel plays tag. Look in the toy box in the far corner of the container maze, then in a crate.';}})();
function buildMaze(){const {x0,z0,n,c}=MZ,y=gy(x0+12,z0+12),cols=['#e8423a','#3d8fe0','#3fae5a','#ff8a3c','#ffd23f'],R=seed(77),H=2.1;
  const wall=(x1,z1,x2,z2)=>{const cx=(x1+x2)/2,cz=(z1+z2)/2,horiz=Math.abs(z2-z1)<.01,L=horiz?Math.abs(x2-x1):Math.abs(z2-z1),col=cols[Math.floor(R()*cols.length)];
    I('box',col,horiz?L:.9,H,horiz?.9:L,cx,y+H/2,cz);I('box',shade(col,-.2),horiz?L:.92,.12,horiz?.92:L,cx,y+H*.35,cz);I('box',shade(col,-.2),horiz?L:.92,.12,horiz?.92:L,cx,y+H*.75,cz);
    if(horiz)rect(Math.min(x1,x2),cz-.45,Math.max(x1,x2),cz+.45);else rect(cx-.45,Math.min(z1,z2),cx+.45,Math.max(z1,z2));};
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){const X=x0+i*c,Z=z0+j*c;
    if(MAZE.walls.has(MAZE.k(i,j,'E'))&&!(i===n-1&&j===MAZE.door.e))wall(X+c,Z,X+c,Z+c);
    if(MAZE.walls.has(MAZE.k(i,j,'S'))&&j<n-1)wall(X,Z+c,X+c,Z+c);}
  for(let i=0;i<n;i++){if(i!==MAZE.door.n)wall(x0+i*c,z0,x0+(i+1)*c,z0);wall(x0+i*c,z0+n*c,x0+(i+1)*c,z0+n*c);}
  for(let j=0;j<n;j++)wall(x0,z0+j*c,x0,z0+(j+1)*c);
  for(let i=0;i<=n;i++)for(let j=0;j<=n;j++)I('box','#5b6378',.95,H+.15,.95,x0+i*c,y+(H+.15)/2,z0+j*c);
  const s=sign(x0+n*c+2.2,z0+MAZE.door.e*c+c/2+2.6,'🗺️ Container Maze',3,7.5);
  pad(x0+n*c+2.4,z0+MAZE.door.e*c+c/2,1.6,'#ffd23f','🗺️');treasureChest(MAZE.spots[2][0],MAZE.spots[2][1],'gadgetMaze');
  const keepG=new Set(W.spots.map(q=>q.grp).filter(Boolean));W.ag.children.forEach(o=>{if(o.isInstancedMesh||o.isSprite||keepG.has(o))return;const q=o.position;if(q.x>x0+.5&&q.x<x0+n*c-.5&&q.z>z0+.5&&q.z<z0+n*c-.5&&!(Math.hypot(q.x-MAZE.spots[2][0],q.z-MAZE.spots[2][1])<1))o.visible=false;});}

/* the mini-map: the maze, Seb, and the maze pups (a tick when found) */
let mm=null,mmBig=false;
function mapEl(){if(mm)return mm;mm=document.createElement('canvas');mm.id='gMap';mm.width=mm.height=340;mm.style.cssText='position:absolute;right:14px;top:96px;width:170px;height:170px;border:4px solid #5b4636;border-radius:18px;background:#fffdf6;z-index:6;display:none;box-shadow:0 5px 0 #5b4636';
  const host=($('#wCards')&&$('#wCards').parentNode)||document.body;host.appendChild(mm);mm.addEventListener('click',()=>{mmBig=!mmBig;mm.style.width=mm.style.height=mmBig?'340px':'170px';sfx.boop();});return mm;}
function drawMap(){const c=mapEl(),g=c.getContext('2d'),{x0,z0,n,c:cs}=MZ,pad=24,S=(340-2*pad)/(n*cs),X=x=>pad+(x-x0)*S,Z=z=>pad+(z-z0)*S;
  g.clearRect(0,0,340,340);g.fillStyle='#e9f2fb';g.fillRect(pad,pad,n*cs*S,n*cs*S);g.strokeStyle='#5b4636';g.lineWidth=7;g.lineCap='round';g.beginPath();
  for(let i=0;i<n;i++)for(let j=0;j<n;j++){const x=x0+i*cs,z=z0+j*cs;if(MAZE.walls.has(MAZE.k(i,j,'E'))&&!(i===n-1&&j===MAZE.door.e)){g.moveTo(X(x+cs),Z(z));g.lineTo(X(x+cs),Z(z+cs));}if(MAZE.walls.has(MAZE.k(i,j,'S'))&&j<n-1){g.moveTo(X(x),Z(z+cs));g.lineTo(X(x+cs),Z(z+cs));}}
  for(let i=0;i<n;i++){if(i!==MAZE.door.n){g.moveTo(X(x0+i*cs),Z(z0));g.lineTo(X(x0+(i+1)*cs),Z(z0));}g.moveTo(X(x0+i*cs),Z(z0+n*cs));g.lineTo(X(x0+(i+1)*cs),Z(z0+n*cs));}
  g.moveTo(X(x0),Z(z0));g.lineTo(X(x0),Z(z0+n*cs));g.stroke();
  g.font='30px sans-serif';g.textAlign='center';g.textBaseline='middle';
  [['dynamo',1],['pixel',0]].forEach(q=>{const s=MAZE.spots[q[1]];g.fillText(isFound(q[0])?'✅':'🐾',X(s[0]),Z(s[1]));});
  const ch=MAZE.spots[2];g.fillText((state.chests||{}).gadgetMaze?'✅':'🎁',X(ch[0]),Z(ch[1]));
  const px=Math.max(pad-12,Math.min(340-pad+12,X(player.x))),pz=Math.max(pad-12,Math.min(340-pad+12,Z(player.z)));g.fillStyle='#3fae5a';g.strokeStyle='#fff';g.lineWidth=4;g.beginPath();g.arc(px,pz,12,0,7);g.fill();g.stroke();
  g.fillStyle='#5b4636';g.font='bold 22px sans-serif';g.fillText('Container Maze',170,14);}

/* ---------------- the Workshop chain-reaction machine ---------------- */
function chainMachine(){const z=18,y=gy(0,z),T=y+1.15;
  I('box','#8a5a32',15,.3,3.6,0,y+1,z);[[-7,-1.5],[7,-1.5],[-7,1.5],[7,1.5]].forEach(q=>I('box','#6b4428',.3,1,.3,q[0],y+.5,z+q[1]));
  I('box','#5b8def',.6,4.6,.6,-6.6,T+2.3,z-.9);
  const ramps=[[-6.3,T+4.5,-2.2,T+3.3],[-2.0,T+3.0,-5.8,T+1.9],[-6.0,T+1.6,-1.2,T+.3]];
  ramps.forEach((r,i)=>{const cx=(r[0]+r[2])/2,cy=(r[1]+r[3])/2,L=Math.hypot(r[2]-r[0],r[3]-r[1]),a=Math.atan2(r[3]-r[1],r[2]-r[0]);I('box',['#ffd23f','#ff8a3c','#3fae5a'][i],L,.14,.7,cx,cy-.12,z,0,0,a);
    I('cyl','#5b6378',.08,cy-T,.08,cx,T+(cy-T)/2-.1,z-.5);});
  const path=[[-6.3,T+4.9],[-2.2,T+3.6],[-2.0,T+3.35],[-5.8,T+2.2],[-6.0,T+1.95],[-1.2,T+.6],[-.4,T+.3]];
  const ball=mk('sph','#e8423a',.32,.32,.32,path[0][0],path[0][1],z,W.ag);
  const doms=[...Array(8)].map((_,i)=>{const d=grp();d.position.set(.2+i*.6,T,z);W.ag.add(d);mk('box',['#e8423a','#ffd23f','#3d8fe0','#3fae5a'][i%4],.14,1,.6,0,.5,0,d);return d;});
  const ham=grp();ham.position.set(5.6,T+2.6,z);W.ag.add(ham);mk('cyl','#c98a4f',.07,2.2,.07,0,-1.1,0,ham);mk('box','#5b6378',.7,.45,.45,0,-2.25,0,ham);I('box','#5b6378',.25,2.8,.25,5.6,T+1.4,z-.6);
  const bell=grp();bell.position.set(6.7,T+.1,z);W.ag.add(bell);mk('cone','#ffd23f',.55,.8,.55,0,.6,0,bell);mk('sph','#c98a2e',.18,.18,.18,0,.2,0,bell);
  const btn=mk('cyl','#e8423a',.5,.3,.5,0,y+1.2,z-3.2,W.ag);I('cyl','#5b6378',.2,1.05,.2,0,y+.52,z-3.2);
  rect(-7.6,z-1.9,7.6,z+1.9);const l=label('🔴 Chain Reaction!',7);l.position.set(0,y+6.6,z);W.ag.add(l);pad(0,z-4.2,1.6,'#e8423a','🔴');
  let run=null;W.things.push({x:0,z:z-4.2,r:3.2,icon:'🔴',label:'Press the button',show:()=>!run,act:()=>{run={t:0,d:-1,h:false};btn.position.y=y+1.05;sfx.boop();say('Press! The marble is on its way...');}});
  const seg=[];let tot=0;for(let i=1;i<path.length;i++){const L=Math.hypot(path[i][0]-path[i-1][0],path[i][1]-path[i-1][1]);seg.push(L);tot+=L;}
  W.ticks.push(dt=>{if(!ball.parent)return true;if(!run)return;run.t+=dt;const t=run.t,tb=2.4;
    if(t<tb){let s=t/tb*tot,i=0;while(i<seg.length-1&&s>seg[i]){s-=seg[i];i++;}const f=Math.min(1,s/seg[i]);ball.position.set(path[i][0]+(path[i+1][0]-path[i][0])*f,path[i][1]+(path[i+1][1]-path[i][1])*f,z);if(Math.floor(t*8)!==Math.floor((t-dt)*8))beep(300+t*120,.04,'triangle',.06);}
    const td=t-tb;doms.forEach((d,i)=>{const k=Math.max(0,Math.min(1,(td-i*.13)/.16));d.rotation.z=-k*1.25;if(k>0&&d.userData.c!==1){d.userData.c=1;beep(1400-i*60,.03,'square',.08);}});
    const th=t-tb-8*.13-.1;if(th>0){ham.rotation.z=Math.min(1,th/.25)*1.15;if(th>.25&&!run.h){run.h=true;beep(1568,.9,'sine',.18);beep(2093,.7,'sine',.1,.02);confetti(50);try{sfx.jingle();}catch(e){}say('Ding! The chain reaction worked! The marble tipped the dominoes, and the dominoes swung the hammer.');}
      bell.rotation.z=th>.25?Math.sin((th-.25)*30)*Math.max(0,.4-(th-.25)*.25):0;}
    if(t>tb+5.5){run=null;btn.position.y=y+1.2;ball.position.set(path[0][0],path[0][1],z);doms.forEach(d=>{d.rotation.z=0;d.userData.c=0;});ham.rotation.z=0;bell.rotation.z=0;}});}

/* ---------------- put it together ---------------- */
AREAS_G.forEach(id=>{const A=AREAS[id];if(!A)return;const Zs=ZONE[id],bot=BOTS[id];
  const zones=[].concat(segZ(bot.path[0],bot.path[1],3.2),Zs.pads.map(p=>({x:p[0],z:p[1],r:p[2]+.8})));
  if(id==='factory')zones.push({x1:MZ.x0-1.5,z1:MZ.z0-1.5,x2:MZ.x0+MZ.n*MZ.c+1.2,z2:MZ.z0+MZ.n*MZ.c+1.5},{x:-6,z:33,r:3},...segZ([18,-2],[2,-2],2.2));
  if(id==='workshop')zones.push({x1:-8.6,z1:12.5,x2:8.6,z2:20.5},...segZ([0,32],[0,24],2.2));
  if(id==='launch')zones.push({x:-6,z:24,r:3});
  const props={ground:Zs.g[0],ground2:Zs.g[1]};if(A.grid)props.grid=Object.assign({},A.grid,{c:shade(Zs.g[0],-.14)});
  restyle(id,props,function(){clearZ(zones);
    Zs.pads.forEach(p=>pad(p[0],p[1],p[2],Zs.pad,p[3]));
    walker(bot);drones(A.R);monorail(A);
    if(id==='workshop'){chainMachine();walkway(0,32,0,24,2.4);}
    if(id==='factory'){buildMaze();bouncePad(-6,33);walkway(18,-2,2,-2,2.4);let acc=0;W.ticks.push(dt=>{acc+=dt;const m=mapEl();const on=cur==='world'&&W.area&&W.area.id==='factory';m.style.display=on?'block':'none';if(!on)return W.area&&W.area.id!=='factory';if(acc>.2){acc=0;drawMap();}});}
    if(id==='launch')bouncePad(-6,24);
    if(id==='lightlab'){const c=['#ff8fb3','#ffc46b','#fff27a','#8fe39a','#7fc8f0','#b58cff'];c.forEach((q,i)=>I('box',q,1.1,.03,20,-12.4+i*1.1,gy(-12,12)+.03,12,0,.78,0));}
    if(id==='launch')[[-10,22],[14,-22]].forEach(q=>{I('disc','#ffffff',4.2,4.2,1,q[0],gy(q[0],q[1])+.02,q[1],-PI/2,0,0);I('disc','#6a707a',3.6,3.6,1,q[0],gy(q[0],q[1])+.025,q[1],-PI/2,0,0);floorIcon(q[0],q[1],'🚀',4);});
    if(id==='robotyard'){for(let i=0;i<7;i++){const x=-30+i*4.2,z=18+(i%2?1.2:-1.2);I('box','#5b5f68',1.5,.03,2.2,x,gy(x,z)+.03,z);}
      const old=W.ag.children.find(o=>o.isGroup&&Math.abs(o.position.x)<.01&&Math.abs(o.position.z+32)<.01&&o.children.length>8);if(old)old.visible=false;
      const lb=W.ag.children.find(o=>o.isSprite&&Math.abs(o.position.x)<.01&&Math.abs(o.position.z+32)<.01);if(lb)lb.position.y+=3;
      const M=giantBot('wave','#7fc8f0');M.g.scale.setScalar(2.6);add(M.g,0,-32);let ph=0,said=false;
      W.ticks.push(dt=>{if(!M.g.parent)return true;ph+=dt;const dx=player.x,dz=player.z+32,dp=Math.hypot(dx,dz);M.head.rotation.y=Math.max(-.7,Math.min(.7,Math.atan2(dx,dz)));
        M.b.position.y=Math.sin(ph*1.5)*.08;M.arms[1].rotation.z=dp<26?2.4+Math.sin(ph*5)*.4:Math.sin(ph*.8)*.25;M.arms[0].rotation.z=-Math.sin(ph*.7)*.2;M.eyes.forEach(e=>e.scale.y=(ph%5<.15)?.02:.12);
        if(dp<22&&!said){said=true;beep(220,.3,'square',.12);beep(165,.4,'square',.12,.3);say('BEEP BOOP! I AM MEGA BOT! Hello, little friend!');}});}
  });
  const k0=A.keepOut;A.keepOut=(x,z)=>inZ(zones,x,z)||(k0?k0(x,z):false);});
const _ea=enterArea;enterArea=function(){if(W.hop){W.hop=null;if(player)player.lock=false;}const r=_ea.apply(this,arguments);if(mm&&!(W.area&&W.area.id==='factory'))mm.style.display='none';return r;};
window.GADGET2={MAZE,MZ,BOTS,giantBot,drawMap};
})();
