/* ================================================================
   Summer Beach Party (26 Nov 2026; claude/summer-beach-design.md sections 2, 4, 9, 10, 15): the story.
   Muddle sightings during the search, the whole map at nine pieces, Muddle at Seal Cove (he borrowed
   everyone's treasure without asking), the Treasure Dig (a 2D beach grid: read the map, "3 across, 4 up",
   then dig; sums in the later chests), the Beach Party with the Great Shell Swap, 6 badges, the Summer
   Beach Party Hero certificate, the goodbye and the Spring Blossom teaser.
   ================================================================ */
(function(){
const SB=window.SB,SL=window.SBLOOK,PI=Math.PI,SAND='#f2d896',SEA='#2fb3d8',GOLD='#ffd23f';
const X=()=>SB.GS(),F=()=>SB.pal().name,big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`;
const cs=(w,o)=>`<div class="fitsvg" style="width:${w||160}px">${SB.crabSVG(o)}</div>`,mg=w=>`<div class="fitsvg" style="width:${w||150}px">${magpieSVG()}</div>`;
const mapW=(w,o)=>`<div class="fitsvg" style="width:${w||240}px">${SB.mapPieces(null,o)}</div>`;
/* Muddle in his pirate hat, with a spade */
function piratePie(){return `<svg viewBox="0 0 200 190" xmlns="http://www.w3.org/2000/svg">${magpieSVG().replace(/<svg[^>]*>/,'').replace('</svg>','')}`+
  `<path d="M104 44 Q140 18 176 44 Q140 34 104 44 Z" fill="#26232e" stroke="#26232e" stroke-width="4"/><path d="M112 40 Q140 6 168 40 Z" fill="#26232e"/><circle cx="140" cy="26" r="5" fill="#fff"/>`+
  `<path d="M30 60 L58 150" stroke="#8a5a2a" stroke-width="7" stroke-linecap="round"/><path d="M48 140 l22 -8 l8 20 q-10 12 -22 8 Z" fill="#aab3c0" stroke="#26232e" stroke-width="3"/></svg>`;}
const mp=w=>`<div class="fitsvg" style="width:${w||160}px">${piratePie()}</div>`;

/* ---------------- Muddle sightings during the search ---------------- */
const SEEN={4:'A pup says: "I saw Muddle on the beach, in a pirate hat, with a spade! He said ARR! and flew away."',
 12:'Professor Hoot says: "Muddle flew past my window with a big bag. It went clink, clank, like treasure!"',
 24:'A pup found a black and white feather by a freshly dug hole in the sand. "Whose feather could that be?"',
 40:'Somebody heard a sad squawk from Rescue Bay: "Where did I put it? Where DID I put it?" Hmm, says '};
const KS=[4,12,24,40];
function afterFind(p,n){const T=X();T.seen=T.seen||{};const k=KS.find(k=>n>=k&&!T.seen[k]);if(!k)return false;T.seen[k]=1;T.sneak=p.island;save();
  setTimeout(()=>{say(SEEN[k]+(k===40?F()+'.':''));SB.PAL.jump=.5;},300);return true;}
/* ---------------- nine map pieces: the map is whole ---------------- */
function onPiece(I,n){if(n<9)return;const T=X();setTimeout(()=>{player.lock=true;SB.snd.song(9,220);
  story([{art:mapW(260,{all:1}),t:`${F()} fits in the last piece. The map is whole! It shows Seal Cove in Rescue Bay, marked out in squares, with nine red Xs...`},
    {art:mapW(220,{all:1}),t:'...and in the corner, somebody has drawn a little picture of themselves: a black and white bird in a pirate hat!'},
    {art:cs(170,{map:1}),t:`"Seal Cove!" says ${F()}. "Let's go and see who drew this map."`}],
    ()=>{player.lock=false;T.call=Date.now();save();card({art:big('🏝️🗺️'),h:'To Seal Cove!',p:'Shall we follow the map to Seal Cove in Rescue Bay?',btns:[['🗺️ Let\'s go!','green',()=>{player.lock=true;fadeTo(()=>enterArea('cove'),['🏝️','Seal Cove']);}],['Later','white',()=>say('Seal Cove is in Rescue Bay. Take the fire engine from the village!')]]});});},900);}
/* ---------------- Muddle at Seal Cove ---------------- */
let MC=null;
{const Ac=AREAS.cove,b=Ac.build;Ac.build=function(){b.apply(this,arguments);MC=null;if(!SB.on())return;const T=SB.G0();if(!T||!T.call||T.dug)return;const A=Ac,s=A.start||[0,0],nr=window.SBWORLD?SBWORLD.place:(a,x,z)=>[x,z];
  const fx=-Math.sin(s[2]||0),fz=-Math.cos(s[2]||0),c=nr(A,s[0]-fx*12,s[1]-fz*12,3),x=c[0],z=c[1],y=gy(x,z),r=Math.atan2(s[0]-x,s[1]-z);
  const R=seed(31);for(let i=0;i<9;i++){const a=R()*PI*2,d=3+R()*7,hx=x+Math.cos(a)*d,hz=z+Math.sin(a)*d,hy=gy(hx,hz);I('cyl','#c8a870',.7,.04,.7,hx,hy+.03,hz,0,0,0,true);I('sph',SAND,.55,.3,.55,hx+.8,hy+.1,hz+.3);}
  const g=grp();SB.sandcastle3D(g,.8,false);add(g,x-2.6,z+.6);col(x-2.6,z+.6,1.5);
  if(!T.met){const m=magpie3D();mk('cyl','#26232e',.42,.05,.42,0,2.08,.35,m);mk('cone','#26232e',.3,.3,.3,0,2.24,.35,m);mk('sph','#ffffff',.06,.06,.03,0,2.22,.64,m,true);add(m,x,z);m.rotation.y=r;col(x,z,1.2);
    W.ticks.push(()=>{if(W.area!==A||!m.parent)return true;m.rotation.z=Math.sin(W.t*2)*.08;m.position.y=gy(x,z)+Math.abs(Math.sin(W.t*1.4))*.15;});
    MC={m,x,z};W.things.push({x,z:z+2.4,r:4,icon:'🐦',label:'Muddle',act:muddle});
    setTimeout(()=>{if(W.area===A&&!player.lock)say(`Look at all those holes! And who is that in the pirate hat? Go and say hello, Seb!`);},2200);}
  else{W.things.push({x,z,r:4,icon:'🗺️',label:'The Treasure Dig',act:()=>dig()});}};}
function muddle(){if(player.lock)return;player.lock=true;hush();const T=X();MUSIC.over='sbjig';
  story([{art:mp(170),t:'It\'s MUDDLE, in a pirate hat, covered in sand from beak to tail! "Oh! Hello, Seb," he says, very quietly.'},
    {art:mp(160),t:'"I wanted to give everyone the best treasure hunt ever at the Beach Party. So I borrowed all the treasures and buried them here, and drew a treasure map."'},
    {art:mp(150)+big('💨'),t:'"But I didn\'t ask anyone first. And then the wind blew my map away, and I couldn\'t remember where anything was. I\'ve been digging all day!"'},
    {art:cs(160,{map:1}),t:`${F()} holds up the map. "We found it! But Muddle, next time, ask before you borrow. Everyone was so worried about their treasure."`},
    {art:cs(140)+mg(130),t:`"And a treasure hunt is best when friends do it together," says ${F()}. Muddle nods. "I'm sorry. Will you help me dig it all up?"`}],
    ()=>{T.met=Date.now();save();MUSIC.over=null;if(MC&&MC.m){W.ag.remove(MC.m);const m=magpie3D();add(m,MC.x+2,MC.z);}player.lock=false;
      card({art:big('🗺️⛏️'),h:'The Treasure Dig',p:'Read the map, then dig on the beach to find all nine treasure chests. Ready?',btns:[['⛏️ Let\'s dig!','green',()=>dig()],['Later','white',()=>say('Come back to Seal Cove when you are ready for the Treasure Dig!')]]});});}
/* ---------------- the Treasure Dig ---------------- */
const CH=[['meadow',[2,3]],['snowy',[5,1]],['reef',[1,4]],['ninja',[4,5]],['number',[6,3]],['gadget',[3,2]],['rescue',[5,4]],['dino',[3,4]],['planet',[6,5]]];
const TR={meadow:'🌻🐝🍯',snowy:'⛸️🧣❄️',reef:'🐚🦪🐠',ninja:'🏮🎐🥋',number:'🔢🧮👑',gadget:'⚙️🔋🤖',rescue:'🚒⛑️🛟',dino:'🦴🥚🦕',planet:'🚀🌙⭐'};
const NA=6,NU=5;
let DG=null;
function digUI(){if($('#sbdig'))return;const d=el('div','screen',`<div id="sbdSky"></div><div id="sbdMap"></div><div id="sbdBeach"></div><div id="sbdPanel"></div><button class="btn rnd white" id="sbdBack">◀</button><div class="pill" id="sbdPill"></div>`);d.id='sbdig';
  const q=document.querySelector('#quiz');q.parentNode.insertBefore(d,q);
  tap('#sbdBack',()=>{sfx.boop();if(!DG)return;DG=null;MUSIC.over=null;show('world');player.lock=false;say('You can carry on the Treasure Dig at Seal Cove whenever you are ready.');});}
function fullMap(){const S=100/NA,H=100/NU*(NU/NA);let s=`<svg viewBox="-12 -8 124 104" class="sbmap"><path d="M-8 -4 H108 V92 Q98 98 88 92 T68 92 T48 92 T28 92 T8 92 T-8 92 Z" fill="#f4e2b0" stroke="#8a6238" stroke-width="3"/>`;
  const cw=100/NA,ch=80/NU;for(let i=0;i<=NA;i++)s+=`<path d="M${i*cw} 0 V80" stroke="#c8a870" stroke-width="1.2"/>`;for(let j=0;j<=NU;j++)s+=`<path d="M0 ${j*ch} H100" stroke="#c8a870" stroke-width="1.2"/>`;
  for(let i=1;i<=NA;i++)s+=`<text x="${(i-.5)*cw}" y="89" font-size="8" font-weight="900" text-anchor="middle" fill="#5a3a20" font-family="Arial">${i}</text>`;for(let j=1;j<=NU;j++)s+=`<text x="-6" y="${80-(j-.5)*ch+3}" font-size="8" font-weight="900" text-anchor="middle" fill="#5a3a20" font-family="Arial">${j}</text>`;
  CH.forEach((c,k)=>{const x=(c[1][0]-.5)*cw,y=80-(c[1][1]-.5)*ch,I=islandOf(c[0]),got=DG&&DG.got[k];s+=got?`<text x="${x}" y="${y+4}" font-size="10" text-anchor="middle">✅</text>`:`<path d="M${x-4} ${y-4} l8 8 M${x+4} ${y-4} l-8 8" stroke="#e8423a" stroke-width="2.6" stroke-linecap="round"/><text x="${x+5}" y="${y-3}" font-size="6">${I.icon}</text>`;});
  return s+'</svg>';}
function dig(){digUI();hush();player.lock=true;const T=X(),start=Math.min(CH.length,Math.max(0,T.dig||0));
  DG={i:start,got:CH.map((c,k)=>k<start),busy:false};
  $('#sbdSky').innerHTML=`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice"><rect width="1024" height="768" fill="#9fdcff"/><circle cx="900" cy="90" r="56" fill="#ffe066"/><rect y="150" width="1024" height="60" fill="${SEA}"/><path d="M0 210 q64 -14 128 0 t128 0 t128 0 t128 0 t128 0 t128 0 t128 0 t128 0 V768 H0 Z" fill="${SAND}"/></svg>`;
  show('sbdig');MUSIC.over='sbjig';speak(`Let's dig! For each chest, read the map: along the bottom first, then up. ${F()} and Muddle are ready with their spades!`);setTimeout(()=>nextChest(),900);}
function cellsHTML(){let h=`<div class="sbg big" style="grid-template-columns:34px repeat(${NA},78px);grid-template-rows:repeat(${NU},70px) 34px">`;
  for(let u=NU;u>=1;u--){h+=`<b class="sbu" data-u="${u}">${u}</b>`;for(let a=1;a<=NA;a++){const k=CH.findIndex(c=>c[1][0]===a&&c[1][1]===u),done=k>=0&&DG.got[k];h+=`<button class="sbc${done?' dug win':''}" data-a="${a}" data-u="${u}">${done?'🧰':''}</button>`;}}
  h+='<i class="sbo">↗</i>';for(let a=1;a<=NA;a++)h+=`<b class="sba" data-a="${a}">${a}</b>`;return h+'</div>';}
function nextChest(){const R=DG;if(!R)return;X().dig=R.i;save();if(R.i>=CH.length){endDig();return;}const c=CH[R.i],I=islandOf(c[0]),[ax,uy]=c[1];
  R.ca=R.i>=4?SB.coordClue(ax):String(ax);R.cu=R.i>=7?SB.coordClue(uy):String(uy);R.tries=0;R.dug={};
  $('#sbdPill').textContent=`🧰 ${R.i+1} of 9`;$('#sbdMap').innerHTML=fullMap()+`<div class="sbclue">${I.icon} <b>${R.ca}</b> across<br><b>${R.cu}</b> up</div>`;
  $('#sbdBeach').innerHTML=cellsHTML();$('#sbdPanel').innerHTML=`<div class="sbdq">The ${I.name} chest: <b>${R.ca}</b> across, <b>${R.cu}</b> up. Where shall we dig?</div>`;
  speak(`The ${I.name} chest is at ${R.ca} across, ${R.cu} up.`+(R.i===4?' Now work out the sums!':''));
  document.querySelectorAll('#sbdBeach .sbc').forEach(b=>tap(b,()=>tapCell(+b.dataset.a,+b.dataset.u,b)));}
function way(ax,uy){const G=$('#sbdBeach');G.querySelectorAll('.sba,.sbu').forEach(e=>e.classList.remove('way'));for(let a=1;a<=ax;a++)setTimeout(()=>{const e=G.querySelector(`.sba[data-a="${a}"]`);if(e)e.classList.add('way');},a*260);
  for(let u=1;u<=uy;u++)setTimeout(()=>{const e=G.querySelector(`.sbu[data-u="${u}"]`);if(e)e.classList.add('way');},(ax+u)*260+150);}
function tapCell(a,u,b){const R=DG;if(!R||R.busy||b.classList.contains('dug')||R.dug[a+','+u])return;const c=CH[R.i],I=islandOf(c[0]),[ax,uy]=c[1];SB.snd.dig();
  if(a===ax&&u===uy){R.busy=true;b.classList.add('dug','win');b.innerHTML='<span class="sbchest">🧰</span>';R.got[R.i]=true;sfx.fanfare();confetti(30);
    const last=R.i===CH.length-1,m=last?`The last chest! The ${I.name} treasures... and right at the bottom, a big, beautiful shell!`:`The ${I.name} chest! Inside are the ${I.name} pups' treasures!`;
    $('#sbdPanel').innerHTML=`<div class="sbdq win">✅ ${m}<div class="sbtr">${TR[c[0]]}${last?'🐚':''}</div></div>`;say(m);setTimeout(()=>{if(DG!==R)return;R.busy=false;R.i++;nextChest();},last?4200:3200);return;}
  R.dug[a+','+u]=1;R.tries++;b.classList.add('dug');const S=SB.DUG[(R.i*3+R.tries+a+u)%SB.DUG.length];b.innerHTML=`<span class="sbdug">${S[0]}</span>`;sfx.oops();way(ax,uy);
  let m=`${S[1]} The chest is ${R.ca!==String(ax)?`${R.ca} across, which is ${ax}`:`${ax} across`}, and ${R.cu!==String(uy)?`${R.cu} up, which is ${uy}`:`${uy} up`}. Along the bottom first, then up!`;
  if(R.tries>=2){const r=$('#sbdBeach').querySelector(`.sbc[data-a="${ax}"][data-u="${uy}"]`);if(r)r.classList.add('hint');m+=' Look, that square is sparkling!';}
  $('#sbdPanel').innerHTML=`<div class="sbdq">${m}</div>`;speak(m);}
function endDig(){const T=X(),first=!T.dug;DG=null;T.dug=Date.now();if(first)state.stars+=100;save();hud();MUSIC.over=null;
  fadeTo(()=>{show('world');enterArea('village',[0,15,PI]);setTimeout(()=>party(),900);},['🏖️','The Beach Party']);}
/* ---------------- the Beach Party ---------------- */
function swapSVG(){const s=[[30,'#e8d0a8',20],[86,'#f0d8b8',26],[150,'#e8c8a0',32],[224,'#ffd0dc',40]];return `<svg viewBox="0 0 300 140" width="300"><rect width="300" height="140" rx="16" fill="${SAND}"/>`+
  s.map((q,i)=>`<g transform="translate(${q[0]+10} ${110-q[2]*.4})"><ellipse cx="0" cy="${q[2]*.4}" rx="${q[2]*.75}" ry="${q[2]*.6}" fill="${q[1]}" stroke="#26232e" stroke-width="3"/><circle cx="${-q[2]*.7}" cy="${q[2]*.55}" r="${q[2]*.3}" fill="#e8503a" stroke="#26232e" stroke-width="2.4"/></g>`).join('')+
  [0,1,2].map(i=>`<path d="M${s[i][0]+30} 40 Q${(s[i][0]+s[i+1][0])/2+20} 14 ${s[i+1][0]+6} 40" stroke="#e8423a" stroke-width="3" fill="none" stroke-dasharray="5 4"/>`).join('')+`</svg>`;}
function party(){const T=X();if(T.done)return;if(!W.area||W.area.id!=='village'){fadeTo(()=>{enterArea('village',[0,15,PI]);setTimeout(party,900);},['🏖️','The Beach Party']);return;}
  player.lock=true;hush();MUSIC.over='sbvil';const zu=window.BHQ&&state.bh&&state.bh.done?' Zuzu and her puppies have come in sunglasses!':'';
  story([{art:big('🏖️⛱️🏰'),t:`The sun sinks low over Pawprint Village, and the plaza has turned into a beach! Sand, parasols, a paddling pool, and every pup, with Granny Paws, the guides and all nine unicorns.${zu}`},
    {art:mg(140)+big('🧰'),t:'Muddle hands back every treasure, and says sorry to each pup. Then he asks, "May I borrow your bucket, please?" Everybody laughs.'},
    {art:cs(150),t:`Then the hermit crabs come out of the sea for the Great Shell Swap! ${F()} has the big shell from the last chest. It's too big... but that doesn't matter.`},
    {art:`<div class="fitsvg" style="width:300px">${swapSVG()}</div>`,t:`The crabs line up from biggest to smallest. The biggest crab moves into the big new shell, the next crab moves into the shell it left, and so on, all the way down the line. Real hermit crabs really do this!`},
    {art:cs(170,{big:1}),t:`And at the end of the line, ${F()} gets a shell that fits just right. "Room to grow!" ${HW_he()} says. "When everyone shares, there's a home for everyone."`},
    {art:`<div class="fitsvg" style="width:150px">${critterSVG(Object.assign({},state.buddy&&pupById(state.buddy)||PUPS.buttercup,{dressAs:'sbcrab'}),{anim:false})}</div>`,t:'Granny Paws has a crab suit for every pup (dress any pup in it at the Pup Spa), and there is a sandcastle, a parasol, a beach towel and a bucket and spade waiting in your Den!'}],
    ()=>{T.done=Date.now();state.stars+=100;state.costumes=state.costumes||{};state.costumes.sbcrab=1;state.certs=state.certs||{};const c=CERTS.find(q=>q.id==='sbhero');if(c&&!state.certs[c.id])state.certs[c.id]=Date.now();save();hud();
      SB.palShell();
      if(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray! +100 ⭐','green',goodbye]]}));}else goodbye();});}
const HW_he=()=>SB.he();
const NEST='<svg viewBox="0 0 300 200" width="300" xmlns="http://www.w3.org/2000/svg"><rect width="300" height="200" rx="18" fill="#dff6d8"/><circle cx="60" cy="40" r="24" fill="#ffe8f0"/><circle cx="240" cy="34" r="18" fill="#ffd6e8"/>'+
  '<path d="M20 170 Q150 140 280 170 V200 H20 Z" fill="#8ad86a"/><path d="M150 58 q-8 -18 -26 -22 M150 58 q10 -16 28 -18" stroke="#8a5a2a" stroke-width="5" fill="none"/><circle cx="118" cy="34" r="8" fill="#ffb4c8"/><circle cx="182" cy="38" r="8" fill="#ffffff"/>'+
  '<g class="sbegg"><ellipse cx="150" cy="112" rx="26" ry="34" fill="#f4f0e0" stroke="#26232e" stroke-width="3"/><path d="M132 104 l8 6 l6 -8 l8 8 l6 -6" stroke="#26232e" stroke-width="2.4" fill="none"/></g>'+
  '<path d="M96 124 Q150 168 204 124 Q196 150 150 154 Q104 150 96 124 Z" fill="#a8784a" stroke="#26232e" stroke-width="3"/><path d="M104 132 q20 10 46 10 q26 0 46 -10" stroke="#8a5a2a" stroke-width="3" fill="none"/>'+
  '<path d="M118 84 l-8 -6 M182 84 l8 -6 M150 70 v-10" stroke="#ffb020" stroke-width="3" stroke-linecap="round"/></svg>';
function goodbye(){const T=X(),left=SB.all().length-SB.nFound();
  story([{art:cs(170,{big:1}),t:`${F()} gives Seb a big claw-hug. "Thank you for finding my map, and my new home! Whenever you play Summer Beach Party, I'll be right here in the village!"`+(left?` And there are still ${left} summer pups hiding on the islands!`:'')},
    {art:NEST,t:'Far away in Bluebell Wood, the first spring flowers are opening. In a little nest, an egg wobbles... and wobbles... crack!'+(window.SPRING?' Spring Blossom is here!':' Coming soon: Spring Blossom!')}],
    ()=>{player.lock=false;T.bye=Date.now();save();MUSIC.over=null;if(window.SPRING&&SPRING.fromSb){setTimeout(()=>{try{SPRING.fromSb();}catch(e){console.warn('sp from sb',e);}},700);return;}say(`Happy summer, Seb! ${F()} will stay in the village whenever Summer Beach Party is on.`);});}
/* ---------------- the village checks where the story is up to ---------------- */
function village(){const T=SB.G0();if(!T||!T.intro)return false;
  if(T.call&&!T.met){say(`${F()} says: "The map shows Seal Cove, in Rescue Bay. Let's go and see who drew it!"`);return true;}
  if(T.met&&!T.dug){card({art:big('🗺️⛏️'),h:'The Treasure Dig',p:'Muddle is waiting at Seal Cove with his spade. Shall we dig up the treasure now?',btns:[['⛏️ Let\'s dig!','green',()=>dig()],['Later','white']]});return true;}
  if(T.dug&&!T.done){party();return true;}
  return false;}
/* ---------------- badges and the certificate ---------------- */
const ss=()=>(state&&state.sx&&state.sx.sb)||{};
MERITS.push(
 {id:'sbpal',icon:'🦀',name:'Crab Pal',how:'Meet the little hermit crab in Summer Beach Party, and give it a name.',ok:()=>!!ss().pal},
 {id:'sbrescue',icon:'🛟',name:'Lifeguard',how:'Bring back all the swim rings in the Lifeguard Rescue in Summer Beach Party.',ok:()=>!!(state.acts||{}).sbrescue},
 {id:'sbsand',icon:'🏰',name:'Sandcastle Champ',how:'Build three sandcastles for Chief Woofles in the Sandcastle Contest.',ok:()=>!!(state.acts||{}).sbsand},
 {id:'sbsnorkel',icon:'🤿',name:'Snorkel Star',how:'Find the 8 treasures at the Shipwreck in Summer Beach Party.',ok:()=>!!(state.acts||{}).sbsnorkel},
 {id:'sbmap',icon:'🗺️',name:'Nine Map Pieces',how:'Collect all nine pieces of the treasure map from the unicorns in Summer Beach Party.',ok:()=>Object.keys(ss().mp||{}).length>=9},
 {id:'sball',icon:'🐚',name:'Every Pup on the Beach',how:'Find all 119 summer pups.',ok:()=>!!ss().found&&SB.nFound()>=SB.all().length});
CERTS.push({id:'sbhero',icon:'🏖️',title:'Summer Beach Party Hero',get why(){return `for finding the treasure map with ${ss().pal?ss().pal.name+', the little hermit crab':'the little hermit crab'}, and digging up every treasure on the Treasure Dig`;},ok:()=>!!ss().done});
const css=document.createElement('style');css.textContent=`#sbdig{background:#9fdcff;overflow:hidden}#sbdSky,#sbdSky svg{position:absolute;left:0;top:0;width:100%;height:100%}#sbdig .btn.rnd{position:absolute;left:14px;top:10px;z-index:20}#sbdig .pill{position:absolute;right:14px;top:14px;z-index:20}
#sbdMap{position:absolute;left:22px;top:250px;width:280px;z-index:5;display:flex;flex-direction:column;align-items:center}#sbdMap .sbmap{width:270px;height:auto}
#sbdBeach{position:absolute;left:330px;top:236px;z-index:5}.sbg.big .sbc{font-size:40px}.sbg .sbc .sbchest{animation:xpop .6s;font-size:46px}
#sbdPanel{position:absolute;left:50%;top:118px;transform:translateX(-50%);width:min(900px,92%);z-index:10}.sbdq{background:#fff8e6;border:5px solid #8a6238;border-radius:24px;padding:10px 16px;font-size:24px;font-weight:800;text-align:center;box-shadow:0 6px 0 rgba(0,0,0,.2)}
.sbdq b{color:#e8423a}.sbdq.win{background:#eaffd8}.sbtr{font-size:44px;line-height:1.1;animation:xpop .6s}
.sbegg{transform-origin:150px 140px;animation:sbWob 1.2s ease-in-out infinite}@keyframes sbWob{0%,60%,100%{transform:rotate(0)}70%{transform:rotate(-8deg)}80%{transform:rotate(7deg)}90%{transform:rotate(-4deg)}}`;
document.head.appendChild(css);
window.SBSTORY={afterFind,onPiece,village,dig,party,goodbye,muddle,_dg:()=>DG,_mc:()=>MC};
})();
