/* ================================================================
   Ninja Mountains: Region 3 (Fire pups), reached by the dragon kite.
   Dojo (start) opens two paths: the Bamboo Forest (after 2 pups) and
   the Ice Temple (needs the ninja rope from Sensei Mochi's chest).
   Bamboo leads to the Fire Temple (a Fire pup lights the lanterns),
   the Ice Temple to the Thunder Temple (a Fire pup melts the ice wall).
   Both temples lead up to Dragon Peak (boss).
   Bonus: the Glow Cave off the Bamboo Forest, lit by a Spark pup from
   Number Kingdom, with a sparkly pup and treasure.
   ================================================================ */
(function(){
const R=seed(3131),inw=(x,z,f)=>[x*(f||.68),z*(f||.68),Math.atan2(-x,-z)];
const NINJA_G={ground:'#8fcf6a',ground2:'#a9dc80',sky:'#bfe3ff',fog:[70,230],fogC:'#dceefa',hedgeC:'#4f8e3a',biome:'ninja'};
function bambooRing(Rad,gaps){for(let a=0;a<360;a+=9){if(gaps.some(g=>Math.abs(((a-g+540)%360)-180)<11))continue;const an=(a+R()*4)*D2R,r=Rad+4+R()*5;bambooClump(Math.cos(an)*r,Math.sin(an)*r,4,8+R()*3,R);}}
function pathTo(x1,z1,x2,z2,w,c){const d=Math.hypot(x2-x1,z2-z1),m=new THREE.Mesh(G.plane,M(c||'#e8d9b5'));m.scale.set(w||4,1,d);m.rotation.y=Math.atan2(x2-x1,z2-z1);m.position.set((x1+x2)/2,gy((x1+x2)/2,(z1+z2)/2)+.07,(z1+z2)/2);W.ag.add(m);
  for(let t=.08;t<1;t+=.12){const x=x1+(x2-x1)*t,z=z1+(z2-z1)*t;I('cyl',pick(['#cdbf9e','#d9c6a6','#c4b590']),.5,.04,.5,x+(R()-.5)*(w||4)*.5,gy(x,z)+.1,z+(R()-.5));}}
function dummy(x,z){const y=gy(x,z);I('cyl','#9b6a43',.18,2.6,.18,x,y+1.3,z);I('cyl','#e8c77a',.55,1.2,.55,x,y+2,z);I('sph','#e8c77a',.45,.45,.45,x,y+2.9,z);I('box','#9b6a43',2,.18,.18,x,y+2.2,z);I('box','#d9362e',.95,.12,.95,x,y+3.05,z);col(x,z,.6);}
function target(x,z,rot){const y=gy(x,z);I('cyl','#9b6a43',.12,2,.12,x,y+1,z);[['#ffffff',.9],['#e8423a',.7],['#ffffff',.48],['#e8423a',.26]].forEach((q,i)=>I('cyl',q[0],q[1],.08+i*.01,q[1],x,y+2.4,z,Math.PI/2,rot||0,0));col(x,z,.4);}
function gong(x,z){const y=gy(x,z);[-1.4,1.4].forEach(q=>I('cyl','#5b2a1e',.15,4,.15,x+q,y+2,z));I('box','#5b2a1e',3.4,.3,.3,x,y+4,z);I('cyl','#ffd23f',1.1,.15,1.1,x,y+2.5,z,Math.PI/2,0,0);I('cyl','#e0a400',.5,.17,.5,x,y+2.5,z,Math.PI/2,0,0);col(x,z,1.3);}
function banner(x,z,c,e){const y=gy(x,z);I('cyl','#3a3338',.08,5,.08,x,y+2.5,z);I('box',c,1,2.8,.05,x+.55,y+3.4,z);if(e)spr(e,.8,x+.55,y+3.6,z+.05);}
function brazier(x,z){const y=gy(x,z);I('cyl','#3a3338',.7,.3,.7,x,y+1.2,z);I('cyl','#3a3338',.1,1.2,.1,x,y+.6,z);I('sph','#ff8a3c',.5,.5,.5,x,y+1.5,z,0,0,0,true);const f=spr('🔥',1.3,x,y+2,z);W.ticks.push(()=>{f.scale.set(1.3+Math.sin(W.t*9+x)*.12,1.3+Math.sin(W.t*7+z)*.2,1);});col(x,z,.8);}
function bonsai(x,z){const y=gy(x,z);I('box','#5b4636',1,.8,1,x,y+.4,z);I('cyl','#c26a32',.5,.4,.5,x,y+1,z);I('cyl','#7a4f2a',.08,.8,.08,x,y+1.5,z,0,0,.3);I('sphL','#3f9e46',.6,.35,.6,x+.25,y+1.9,z);I('sphL','#4fae4a',.45,.3,.45,x-.2,y+1.7,z);col(x,z,.6);}
function stream(pts,w){for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#7fd3f0'}));m.scale.set(w||3,1,d+1);m.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);m.position.set((a[0]+b[0])/2,gy((a[0]+b[0])/2,(a[1]+b[1])/2)+.09,(a[1]+b[1])/2);W.ag.add(m);W.disp.push(m.material);
  for(let k=0;k<3;k++){const t=R();I('box','#ffffff',.6,.02,.1,a[0]+(b[0]-a[0])*t,gy(a[0],a[1])+.12,a[1]+(b[1]-a[1])*t,0,R()*3,0,true);}}}
function koi(x,z,r){const fs=[0,1,2,3].map(i=>{const s=sprite(i%2?'🐟':'🐠',.7);W.ag.add(s);return s;});W.ticks.push(()=>fs.forEach((s,i)=>{const a=W.t*(.4+i*.1)+i*1.6;s.position.set(x+Math.cos(a)*r*.6,gy(x,z)+.25,z+Math.sin(a)*r*.6);}));
  for(let i=0;i<5;i++)I('cyl','#3f9e46',.6,.04,.6,x+Math.cos(i*1.3)*r*.7,gy(x,z)+.12,z+Math.sin(i*1.3)*r*.7);}
function redPanda3D(){const g=grp();mk('sph','#c8562a',.6,.5,.85,0,.6,0,g);mk('sph','#c8562a',.5,.45,.45,0,1,.7,g);mk('sph','#ffffff',.25,.15,.18,0,.95,1.08,g);[-1,1].forEach(q=>{mk('sph','#ffffff',.14,.18,.08,q*.3,1.38,.65,g);mk('sph','#26232e',.06,.06,.06,q*.15,1.07,1.08,g);});
  for(let i=0;i<4;i++)mk('cyl',i%2?'#f2e0c9':'#a8461e',.22,.3,.22,0,.75,-.7-i*.28,g).rotation.x=1.2;for(let i=0;i<4;i++)mk('cyl','#26232e',.12,.4,.12,(i%2?.3:-.3),.2,(i<2?.35:-.35),g);return g;}
function wanderers(n,mkf,cx,cz,r){for(let i=0;i<n;i++){const g=mkf();W.ag.add(g);const o={a:i*1.7,s:.2+R()*.15};W.ticks.push(dt=>{o.a+=dt*o.s;const x=cx+Math.cos(o.a)*r*(1+Math.sin(o.a*2+i)*.2),z=cz+Math.sin(o.a)*r;g.position.set(x,gy(x,z),z);g.rotation.y=-o.a;});}}
function landingPad(x,z,lbl){const y=gy(x,z);I('cyl','#c9905f',4.2,.5,4.2,x,y+.25,z);I('cyl','#e8423a',3.6,.06,3.6,x,y+.52,z);spr('🪁',1.2,x,y+.9,z);
  I('cyl','#9b6a43',.18,6,.18,x+4.5,y+3,z);const l=label(lbl||'🪁 Dragon kite home',6.5);l.position.set(x+4.5,y+7,z);W.ag.add(l);
  dragonFlyer(t=>[x+Math.cos(t*.5)*6,y+16+Math.sin(t)*2,z-6+Math.sin(t*.5)*4],{c:'#e8423a',c2:'#ffd23f',wing:'#ffb347',n:9,s:.8,speed:1});
  W.things.push({x,z:z-3,r:4.6,icon:'🪁',label:'Go home',act:goHome});}

/* ----------------- the 12 Fire pups ----------------- */
const P=[
 {id:'chilli',name:'Chilli',breed:'Shiba Inu',area:'dojo',pitch:1.15,spot:{x:-24,z:-20,kind:'bush'},hint:'Look in a bush near the koi pond.',
  fact:'Shiba Inus are brave little dogs from the mountains of Japan. When they are happy they do a big Shiba smile!',rescue:{icon:'🍃',verb:'Brush',say:'Chilli is covered in cherry blossom petals! Tap to brush them off!'},
  look:{fur:'#d9894a',ear:'#b56a30',ears:'pointy',muzzle:'#fff4e6',belly:'#fff4e6',face:'#fff4e6',faceLow:true,tail:'curl',acc:['embers'],ninja:{suit:'#d9362e',band:'#d9362e'}}},
 {id:'dumpling',name:'Dumpling',breed:'Pekingese',area:'dojo',pitch:1.4,spot:{x:22,z:20,kind:'crate'},tag:{x:-30,z:24,kind:'log'},hint:'Dumpling plays tag. Look in a crate by the tea house, then by a log.',
  fact:'Pekingese dogs were the pets of Chinese emperors long ago. They walk with a proud little roll, like a lion!',rescue:{icon:'🥟',verb:'Tickle',say:'Dumpling is hiding and will not come out! Tap to tickle Dumpling!'},
  look:{fur:'#e8b46a',ear:'#a8743a',ears:'long',fluffy:true,fringe:'#e8b46a',muzzle:'#3a2a25',belly:'#f3d9a8',tail:'plume',scale:.85,eyeWhite:true,acc:['bow']}},
 {id:'bamboo',name:'Bamboo',breed:'Chow Chow',area:'bamboo',pitch:.8,spot:{x:-20,z:16,kind:'fern'},hint:'Look among the ferns in the Bamboo Forest.',
  fact:'Chow Chows have blue-black tongues and a big fluffy mane like a lion. They are calm and loyal.',rescue:{icon:'🎋',verb:'Bend',say:'Bamboo is stuck behind the bamboo stalks! Tap to bend them apart!'},
  look:{fur:'#f0d9b0',ear:'#d9bb88',ears:'pointy',fluffy:true,muzzle:'#f0d9b0',muzzleBig:true,belly:'#fff2d9',tail:'curl',hw:60,hh:54,acc:['embers'],ninja:{suit:'#3fae5a',band:'#3fae5a'}}},
 {id:'kite',name:'Kite',breed:'Shikoku',area:'bamboo',pitch:1.1,spot:{x:22,z:-14,kind:'stump'},tag:{x:-24,z:-26,kind:'leafpile'},hint:'Kite plays tag. Look by a stump, then in a pile of leaves.',
  fact:'Shikoku dogs come from the mountains of Shikoku island. They are fast and nimble, like real ninjas!',rescue:{icon:'🪁',verb:'Untangle',say:'Kite is tangled in a kite string! Tap to untangle it!'},
  look:{fur:'#b8743a',ear:'#7a4a2a',ears:'pointy',muzzle:'#f2e0c9',belly:'#f2e0c9',face:'#f2e0c9',faceLow:true,tail:'curl',acc:['scarf'],scarfC:'#3d8fe0'}},
 {id:'frosty',name:'Frosty',breed:'Kishu',area:'icet',pitch:1.05,spot:{x:30,z:-6,kind:'drift'},hint:'Look in a snowdrift to the right of the Ice Temple.',
  fact:'Kishu dogs are usually snowy white. They come from the mountains of Japan and love to explore.',rescue:{icon:'❄️',verb:'Dig',say:'Frosty is stuck in a snowdrift! Tap to dig Frosty out!'},
  look:{fur:'#fbf7ee',ears:'pointy',muzzle:'#fbf7ee',belly:'#ffffff',tail:'curl',acc:['scarf','embers'],scarfC:'#d9362e',ninja:{suit:'#f4f8ff',band:'#5aa9dc'}}},
 {id:'noodle',name:'Noodle',breed:'Shar Pei',area:'icet',pitch:.9,spot:{x:24,z:10,kind:'igloo'},tag:{x:-16,z:30,kind:'pine'},hint:'Noodle plays tag. Look in the igloo, then under a snowy pine.',
  fact:'Shar Pei pups are covered in squishy wrinkles. Their name means sandy skin!',rescue:{icon:'🍜',verb:'Lift',say:'Noodle has a bowl stuck on her head! Tap to lift it off!'},
  look:{fur:'#d9a46a',ear:'#b5824a',ears:'side',muzzle:'#c99560',muzzleBig:true,belly:'#e0b47a',tail:'curl',hw:62,hh:56,acc:['mittens']}},
 {id:'blaze',name:'Blaze',breed:'Akita',area:'firet',pitch:.85,spot:{x:-20,z:12,kind:'boulder'},hint:'Look behind a big rock near the lava.',
  fact:'Akitas are big, brave and loyal. In Japan a little Akita statue is a sign of good luck and happiness!',rescue:{icon:'🔥',verb:'Fan',say:'Blaze is too hot by the lava! Tap to fan Blaze and cool down!'},
  look:{fur:'#c8642a',ear:'#a04a1e',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',face:'#ffffff',faceLow:true,tail:'curl',hw:60,hh:54,acc:['embers'],ninja:{suit:'#d9362e',band:'#ffd23f'}}},
 {id:'ash',name:'Ash',breed:'Kai Ken',area:'firet',pitch:1,spot:{x:24,z:-8,kind:'crate'},tag:{x:-26,z:-20,kind:'boulder'},hint:'Ash plays tag. Look in a crate by the temple, then behind a rock.',
  fact:'Kai Ken dogs have stripy brindle coats, like a little tiger. They are great climbers!',rescue:{icon:'💨',verb:'Blow',say:'Ash is in a cloud of smoke! Tap to blow it away!'},
  look:{fur:'#4a3a30',ear:'#2e241e',ears:'pointy',muzzle:'#6b5446',belly:'#6b5446',tail:'curl',stripes:true,acc:['embers','scarf'],scarfC:'#ff8a3c'}},
 {id:'thunder',name:'Thunder',breed:'Thai Ridgeback',area:'thunder',pitch:.9,spot:{x:-22,z:-12,kind:'crystal'},hint:'Look by the glowing crystals in the Thunder Temple.',
  fact:'Thai Ridgebacks have a stripe of fur on their back that grows the wrong way! They can jump very high.',rescue:{icon:'⚡',verb:'Calm',say:'Thunder is scared of the loud storm! Tap to give Thunder a calm cuddle!'},
  look:{fur:'#6b7d9a',ear:'#55657e',ears:'pointy',muzzle:'#55657e',belly:'#7d8ea8',tail:'thin',acc:['embers'],ninja:{suit:'#3d8fe0',band:'#ffd23f'}}},
 {id:'zippy',name:'Zippy',breed:'Shih Tzu',area:'thunder',pitch:1.45,spot:{x:20,z:18,kind:'tent'},tag:{x:-14,z:28,kind:'crystal'},hint:'Zippy plays tag. Look in the tent, then by the crystals near the arch.',
  fact:'Shih Tzu means little lion. They have long silky hair and love a cuddle.',rescue:{icon:'🌧️',verb:'Dry',say:'Zippy got soaked in the storm! Tap to dry Zippy with a towel!'},
  look:{fur:'#f2ece0',ear:'#c9a070',ears:'long',fluffy:true,fringe:'#c9a070',muzzle:'#ffffff',belly:'#ffffff',tail:'plume',scale:.85,acc:['bow']}},
 {id:'phoenix',name:'Phoenix',breed:'Chinese Crested',area:'peak',pitch:1.3,spot:{x:-24,z:6,kind:'boulder'},hint:'Look behind a rock on Dragon Peak.',
  fact:'Chinese Crested dogs have fluffy hair on their head, tail and feet, and soft bare skin everywhere else!',rescue:{icon:'🐉',verb:'Wave',say:'A baby dragon is guarding Phoenix! Tap to wave hello so it flies away!'},
  look:{fur:'#e8d5c4',ear:'#ffffff',ears:'pointy',fringe:'#ffffff',muzzle:'#e8d5c4',belly:'#f2e6d8',tail:'plume',spots:true,acc:['embers'],ninja:{suit:'#ffd23f',band:'#d9362e'}}},
 {id:'ginger',name:'Ginger',breed:'Japanese Chin',area:'peak',pitch:1.4,spot:{x:22,z:-4,kind:'crate'},tag:{x:-6,z:28,kind:'bush'},hint:'Ginger plays tag. Look in a crate by the shrine, then in a bush by the path.',
  fact:'Japanese Chins are tiny and graceful. Some even spin round in a little happy dance!',rescue:{icon:'🎐',verb:'Free',say:'Ginger is tangled in a wind chime! Tap to free Ginger!'},
  look:{fur:'#ffffff',ear:'#26232e',ears:'long',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',patch:'#26232e',tail:'plume',scale:.8,eyeWhite:true,acc:['flower']}}];
const GLIMMER={id:'glimmer',name:'Glimmer',breed:'Samoyed',area:'glow',pitch:1.15,spot:{x:-12,z:-10,kind:'stalagmite'},hint:'A sparkly pup is hiding in the Glow Cave.',
  fact:'Glimmer is a sparkly pup! Samoyeds are fluffy white dogs who always seem to be smiling. You found a secret pup!',rescue:{icon:'🍄',verb:'Shine',say:'Glimmer is hiding in the dark! Tap to shine a glowing mushroom on Glimmer!'},
  look:{fur:'#ffffff',ears:'pointy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',acc:['twinkle','embers']}};
const EMBER={id:'emberuni',name:'Ember',breed:'Fire Unicorn',uni:true,lv:1,pitch:1.2,fact:'Ember the Fire Unicorn keeps the temple lanterns glowing all night long.',
  look:{fur:'#fff1e6',ears:'side',earIn:'#ffb38a',muzzle:'#ffffff',belly:'#ffffff',nose:'#c08a70',iris:'#e8603a',limbs:'hooves',hoofC:'#ffd23f',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','embers'],scale:.96}};
const MOCHI={id:'mochi',name:'Sensei Mochi',breed:'Shiba Inu',pitch:.8,look:{fur:'#e8c79a',ear:'#c9a070',ears:'pointy',muzzle:'#ffffff',muzzleBig:true,belly:'#ffffff',fringe:'#ffffff',tail:'curl',eyeWhite:true,acc:['scarf'],scarfC:'#3fae5a'}};
const MOCHI_SAY=['Sensei Mochi says: a true ninja is kind, brave and patient.','Sensei Mochi says: Fire pups can light lanterns and melt ice. Bring one with you!','Sensei Mochi says: the ninja rope is in my chest by the dojo. Use it to swing across to the Ice Temple.','Sensei Mochi says: practise on the targets. Wait for them to glow!','Sensei Mochi says: there is a dark cave in the Bamboo Forest. A Spark pup from Number Kingdom could light it up.','Sensei Mochi says: Ember the Fire Unicorn lives at the top of Dragon Peak.'];

/* ----------------- areas ----------------- */
const dojo=Object.assign({},NINJA_G,{id:'dojo',name:'Dojo',icon:'🥋',R:52,start:[0,36,Math.PI],
  hf:(x,z)=>Math.sin(x*.07)*.5+Math.cos(z*.06)*.5+Math.max(0,-z-30)*.08,
  hello:'Welcome to Ninja Mountains! This is the Dojo, where pups train to be ninjas. Two pups are hiding here. Say hello to Sensei Mochi!',how:'Fly the dragon kite from the kite hill in the village.',
  exits:[{x:-38,z:-34,to:'bamboo',arrive:inw(34,36),name:'Bamboo Forest',icon:'🎋',open:()=>foundIn(areaPups('dojo'))>=2,lock:()=>{const n=foundIn(areaPups('dojo'));return `The path to the Bamboo Forest is blocked by fallen bamboo. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Dojo to clear it!`;}},
         {x:38,z:-34,to:'icet',arrive:inw(-34,36),name:'Ice Temple',icon:'🧊',open:()=>!!state.gear.rope,lock:'The Ice Temple is across a deep ravine. You need a ninja rope to swing across! Ask Sensei Mochi.'}],
  build(){mountainsFar();landingPad(0,44);
    pathTo(0,40,0,0,4.5);pathTo(-2,-4,-34,-30,4);pathTo(2,-4,34,-30,4);
    const sand=new THREE.Mesh(G.disc,M('#efe3c4'));sand.scale.set(13,1,13);sand.position.set(0,gy(0,6)+.06,6);W.ag.add(sand);for(let r=3;r<13;r+=2.5){const t=new THREE.Mesh(G.ring,M('#dccfae'));t.scale.set(r,r,r);t.rotation.x=Math.PI/2;t.position.set(0,gy(0,6)+.09,6);W.ag.add(t);}
    pagoda(0,-16,{w:14,tiers:2,wall:'#f2e6d8',roof:'#3a3338',label:'🥋 Dojo',lw:6});
    torii(0,24,0);[[-3.5,30],[3.5,30],[-3.5,16],[3.5,16],[-3.5,-1],[3.5,-1]].forEach(p=>stoneLantern(p[0],p[1]));
    dummy(-8,3);dummy(-10,8);dummy(8,3);target(10,9,.4);target(12,13,.8);target(14,6,0);gong(-12,-6);
    [[-14,-12,'#d9362e','🔥'],[14,-12,'#3d8fe0','⚡'],[-15,0,'#3fae5a','🍃'],[15,0,'#ffd23f','⭐']].forEach(b=>banner(b[0],b[1],b[2],b[3]));
    /* Sensei Mochi and his chest with the ninja rope */
    {const g=pup3D(MOCHI,false);add(g,-5,-4);g.rotation.y=.4;col(-5,-4,1);I('cyl','#5fae4a',1.6,.06,1.2,-5,gy(-5,-4)+.07,-4);const l=label('🍵 Sensei Mochi',4.5);l.position.set(-5,gy(-5,-4)+4,-4);W.ag.add(l);
      W.ticks.push(()=>{g.rotation.y=Math.atan2(player.x+5,player.z+4);animPup(g,W.t*.6,false);});let k=0;W.things.push({x:-5,z:-4,r:4,icon:'💬',label:'Sensei',act:()=>{sfx.chime();say(state.gear.rope?MOCHI_SAY[(k++)%MOCHI_SAY.length]:'Sensei Mochi says: welcome, young ninja! Take the ninja rope from my chest by the dojo steps.');}});}
    {const cx=9,cz=-5,y=gy(cx,cz);I('box','#9b6a43',2.2,1.2,1.4,cx,y+.6,cz);I('box','#ffd23f',2.3,.2,1.5,cx,y+.9,cz);I('box','#b9814f',2.2,.5,1.4,cx,y+1.45,cz);col(cx,cz,1.2);
      const rope=grp();mk('tor','#c9a86a',.7,.7,.7,0,0,0,rope).rotation.x=Math.PI/2;mk('tor','#c9a86a',.55,.55,.55,0,.25,0,rope).rotation.x=Math.PI/2;const rs=sprite('🪢',1.2);rs.position.y=1.2;rope.add(rs);add(rope,cx,cz,y+2.1);rope.visible=!state.gear.rope;W.ticks.push(()=>{rope.rotation.y+=.02;});
      W.things.push({x:cx,z:cz+1.5,r:3.6,icon:'🪢',label:'Ninja rope',show:()=>!state.gear.rope,act:()=>{state.gear.rope=true;state.stars+=5;save();hud();rope.visible=false;sfx.jingle();confetti(30);
        card({art:'<div style="font-size:110px;line-height:1">🪢</div>',h:'You found a ninja rope!',p:'Now you can swing across the ravine to the Ice Temple. Its arch is on the right of the dojo!'});}});}
    /* koi pond with a red bridge, cherry trees, tea house */
    pond(-26,12,7,'#6cc6ef');koi(-26,12,7);redBridge(-26,12,0,15);[[-36,4],[-34,22],[-16,22],[-18,2]].forEach(p=>cherry(p[0],p[1],1+R()*.3));bonsai(-14,16);bonsai(-12,26);
    house(28,16,{w:8,d:7,h:3.4,wall:'#f2e6d8',roof:'#3a3338',trim:'#d9362e',face:'w',label:'🍵 Tea house',lw:5});bench(20,14,'e');
    sign(16,18,'🎯 Ninja Targets',3,6);W.things.push({x:15,z:14,r:4,icon:'🎯',label:'Targets',act:()=>{sfx.chime();startFlies('activity','targets');}});
    sign(-30,-24,'🎋 Bamboo Forest',3,6);sign(30,-24,'🧊 Ice Temple',3,6);fence(-46,-10,-40,-26,'#c9a86a');fence(46,-10,40,-26,'#c9a86a');
    [[-44,18],[44,24],[-20,40],[24,38],[44,-2],[-46,-4]].forEach(p=>cherry(p[0],p[1],1.1));bambooRing(52,[angOf(-38,-34),angOf(38,-34),90]);}});

const bamboo=Object.assign({},NINJA_G,{id:'bamboo',name:'Bamboo Forest',icon:'🎋',R:52,start:inw(34,36),
  hf:(x,z)=>Math.sin(x*.09)*.8+Math.cos(z*.08)*.7,ground:'#7fbf5a',ground2:'#9bcf6a',sky:'#c9ecd0',fog:[40,160],fogC:'#cfe8cf',
  hello:'The Bamboo Forest! The bamboo is so tall it whispers in the wind. Two pups are hiding here, and so are 6 ninja scrolls!',how:'Find 2 pups at the Dojo to clear the path.',
  exits:[{x:36,z:36,to:'dojo',arrive:inw(-38,-34),name:'Dojo',icon:'🥋'},
         {x:0,z:-52,to:'firet',arrive:inw(0,48),name:'Fire Temple',icon:'🔥',gate:{type:'fire',key:'lanterns_fire',look:'lanterns',verb:'lights the temple lanterns',done:'The lanterns glow and the gate swings open! The Fire Temple is this way!'},lock:'The gate to the Fire Temple only opens when its lanterns are lit. A Fire pup could light them!'},
         {x:-52,z:0,to:'glow',arrive:inw(30,0,.7),name:'Glow Cave',icon:'🍄',gate:{type:'spark',key:'glowcave',look:'dark',need:0,verb:'lights up the dark cave',done:'The cave lights up! Now you can explore the Glow Cave!'},lock:'The cave is too dark to go in. A Spark pup from Number Kingdom could light it up!'}],
  build(){mountainsFar(['#7fa38a','#6b8f78']);
    pathTo(30,30,0,0,3.5,'#d9c6a0');pathTo(0,0,0,-44,3.5,'#d9c6a0');pathTo(0,0,-44,0,3.5,'#d9c6a0');
    for(let i=0;i<46;i++){const a=R()*6.28,r=8+R()*38,x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.abs(x)<4&&z<2)continue;if(Math.abs(z)<4&&x<2)continue;if(Math.hypot(x-15,z-15)<6||Math.hypot(x+20,z-16)<5||Math.hypot(x-22,z+14)<5||Math.hypot(x+24,z+26)<5||Math.hypot(x-26,z-26)<5)continue;
      if(COLLECT.scrolls.items.some(q=>Math.hypot(q[0]-x,q[1]-z)<4))continue;bambooClump(x,z,3+Math.floor(R()*3),7+R()*4,R);}
    stream([[-46,24],[-26,18],[-10,22],[8,14],[20,20],[46,10]],3.4);redBridge(-10,22,Math.PI/2+.25,7);redBridge(20,20,Math.PI/2-.4,7);
    {const sx=14,sz=-30;pagoda(sx,sz,{w:7,tiers:1,wall:'#f2e6d8',roof:'#5b2a1e',label:'⛩️ Shrine',lw:5,face:'w'});[[sx-7,sz-4],[sx-7,sz+4]].forEach(p=>stoneLantern(p[0],p[1]));}
    {const y=gy(-20,-40);I('box','#8a8378',14,14,4,-20,y+6,-44);const wf=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#bfeaff'}));wf.scale.set(4,1,12);wf.rotation.x=Math.PI/2;wf.position.set(-20,y+6,-41.9);W.ag.add(wf);W.disp.push(wf.material);pond(-20,-37,4,'#7fd3f0');
      W.ticks.push(dt=>{if(Math.random()<dt*5)floatS('💧',-20+(Math.random()-.5)*3,y+1,-38.5,.6,.8);});rect(-27,-46,-13,-42);}
    for(let i=0;i<6;i++)stoneLantern(-6+((i%2)?8:0)-4,-10-i*5,.8);
    sign(4,6,'📜 Scroll Hunt',3,6);W.things.push({x:5,z:3,r:4,icon:'📜',label:'Scroll Hunt',act:()=>{sfx.chime();startCollect('scrolls');}});
    const pd=grp();mk('sph','#ffffff',1,1,1,0,1,0,pd);mk('sph','#26232e',.4,.4,.4,-.6,1.8,0,pd);mk('sph','#26232e',.4,.4,.4,.6,1.8,0,pd);mk('sph','#ffffff',.7,.65,.65,0,2.1,.3,pd);[-1,1].forEach(q=>mk('sph','#26232e',.18,.22,.1,q*.3,2.2,.9,pd));add(pd,26,-4);col(26,-4,1.4);spr('🎋',1.4,27.5,gy(26,-4)+2.6,-4);
    bambooRing(52,[angOf(36,36),270,180]);}});

const icet=Object.assign({},NINJA_G,{id:'icet',name:'Ice Temple',icon:'🧊',R:50,start:inw(-34,36),
  hf:(x,z)=>Math.sin(x*.08)*.6+Math.cos(z*.07)*.6,ground:'#f2f7fb',ground2:'#dde8f2',sky:'#cbe5f7',fog:[60,200],fogC:'#e3eef8',hedgeC:'#eaf2f9',biome:'snow',
  hello:'The Ice Temple! Brrr! Red pandas live here in the snow. Two pups are hiding nearby.',how:'Swing across the ravine with the ninja rope from the Dojo.',
  exits:[{x:-36,z:34,to:'dojo',arrive:inw(38,-34),name:'Dojo',icon:'🥋'},
         {x:0,z:-50,to:'thunder',arrive:inw(0,48),name:'Thunder Temple',icon:'⚡',gate:{type:'fire',key:'icewall',look:'icewall',verb:'melts the ice wall',done:'Drip, drip! The ice wall melted. The way to the Thunder Temple is open!'},lock:'A thick wall of ice blocks the way. A Fire pup could melt it!'}],
  build(){mountainsFar(['#c9d6e6']);snowfall();
    pagoda(0,-18,{w:12,tiers:3,wall:'#e8f4ff',roof:'#5aa9dc',pil:'#3d8fe0',trim:'#ffffff',label:'🧊 Ice Temple',lw:6});
    pond(14,12,7,'#bfeaff');for(let i=0;i<5;i++)I('box','#e8f6ff',1.6,.5,1.6,8+i*3,gy(14,12)+.25,12+Math.sin(i)*2);
    [[-12,-4],[12,-4],[-14,8],[-6,20]].forEach(p=>{const y=gy(p[0],p[1]);I('cone','#bfeaff',.6,2.2,.6,p[0],y+1.1,p[1],0,0,0,true);col(p[0],p[1],.7);});
    [[-30,10],[-38,-12],[30,-26],[36,6],[-22,-30],[20,34],[34,26],[-26,26]].forEach(p=>snowPine(p[0],p[1],1+R()*.4));[[-18,14,1.2],[26,-12,1],[-30,-24,1.3]].forEach(r=>snowRock(r[0],r[1],r[2]));snowman(-8,30,.8);
    wanderers(3,redPanda3D,-12,6,7);
    {const px=-24,pz=-10;fence(px-6,pz-5,px+6,pz-5,'#c9a86a');fence(px-6,pz+5,px+6,pz+5,'#c9a86a');fence(px-6,pz-5,px-6,pz+5,'#c9a86a');sign(px+8,pz+6,'🐾 Red Panda Round-up',3,7);W.things.push({x:px+8,z:pz+3,r:4,icon:'🐾',label:'Red pandas',act:()=>{sfx.chime();startHerd('activity','redpandas');}});}
    sign(-6,-38,'⚡ Thunder Temple',3,6);
    for(let a=0;a<360;a+=8){if(Math.abs(((a-angOf(-36,34)+540)%360)-180)<11||Math.abs(((a-270+540)%360)-180)<11)continue;const an=a*D2R;snowPine(Math.cos(an)*(55+R()*6),Math.sin(an)*(55+R()*6),1+R()*.5);}}});

const firet=Object.assign({},NINJA_G,{id:'firet',name:'Fire Temple',icon:'🔥',R:50,start:inw(0,48),
  hf:(x,z)=>Math.sin(x*.1)*.6+Math.cos(z*.09)*.6,ground:'#8a6a5a',ground2:'#9b7a66',sky:'#ffd2b0',fog:[50,180],fogC:'#f2c4a8',hedgeC:'#5b4636',biome:'fire',
  hello:'The Fire Temple! The lava glows orange, so stay on the stones. Two pups are hiding here.',how:'A Fire pup lights the lanterns on the gate in the Bamboo Forest.',
  exits:[{x:0,z:50,to:'bamboo',arrive:inw(0,-52),name:'Bamboo Forest',icon:'🎋'},
         {x:36,z:-34,to:'peak',arrive:inw(-38,32),name:'Dragon Peak',icon:'🐉',open:()=>foundIn(areaPups('firet'))>=2,lock:()=>{const n=foundIn(areaPups('firet'));return `The steps to Dragon Peak are hidden in smoke. Find ${2-n} more ${2-n>1?'pups':'pup'} in the Fire Temple to clear it!`;}}],
  build(){I('cone','#6b5146',70,90,70,-60,20,-200);I('cone','#ff8a3c',14,6,14,-60,66,-200,0,0,0,true);W.ticks.push(dt=>{if(Math.random()<dt*2)floatS('💨',-60+(Math.random()-.5)*10,72,-200,3,4);});mountainsFar(['#7a5a4a','#6b4f40']);
    const lava=(x,z,w,d,r)=>{const m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#ff7a2a'}));m.scale.set(w,1,d);m.rotation.y=r||0;m.position.set(x,gy(x,z)+.08,z);W.ag.add(m);W.disp.push(m.material);
      for(let i=0;i<8;i++)I('sph','#ffd23f',.3,.12,.3,x+(R()-.5)*w*.8,gy(x,z)+.12,z+(R()-.5)*d*.8,0,0,0,true);W.ticks.push(dt=>{if(Math.random()<dt*1.5)floatS('🔥',x+(Math.random()-.5)*w*.6,gy(x,z)+.5,z+(Math.random()-.5)*d*.6,.7,1);});};
    lava(-26,-4,8,30,0);rect(-30,-19,-22,11);lava(28,16,22,7,0);rect(17,12.5,39,19.5);
    for(let i=0;i<4;i++)I('box','#5b4636',3,.6,2,-26+((i%2)?1:-1)*.5,gy(-26,-4)+.3,-14+i*7);
    pagoda(0,-18,{w:12,tiers:2,wall:'#3a3338',roof:'#d9362e',pil:'#ffd23f',trim:'#ffd23f',label:'🔥 Fire Temple',lw:6});
    [[-6,-4],[6,-4],[-10,14],[10,14],[-6,30],[6,30]].forEach(p=>brazier(p[0],p[1]));pathTo(0,46,0,-6,4,'#6b5146');pathTo(2,-4,32,-30,3.5,'#6b5146');
    [[-34,-24],[-38,10],[34,-10],[30,30],[-30,30],[18,-34],[-18,-36]].forEach(p=>{const y=gy(p[0],p[1]),s=1+R();I('pyr','#2e2630',1.6*s,2.4*s,1.6*s,p[0],y+1.1*s,p[1],0,R()*3,0);I('pyr','#3a3338',1*s,1.6*s,1*s,p[0]+1.2,y+.8*s,p[1]+.6,0,R()*3,0);col(p[0],p[1],1.6*s);});
    [[-14,-2],[14,-2]].forEach(p=>{const y=gy(p[0],p[1]);I('box','#5b4636',1.6,1,1.6,p[0],y+.5,p[1]);I('sph','#d9362e',.9,.9,1.2,p[0],y+1.6,p[1]);I('cone','#ffd23f',.2,.7,.2,p[0]-.3,y+2.4,p[1]);I('cone','#ffd23f',.2,.7,.2,p[0]+.3,y+2.4,p[1]);col(p[0],p[1],1);});
    {const sx=20,sz=4;sign(sx,sz+6,'🌋 Lava Steps',3,6);W.things.push({x:sx,z:sz+3,r:4,icon:'🌋',label:'Lava Steps',act:()=>{sfx.chime();startStones('activity','lavasteps');}});}
    for(let a=0;a<360;a+=7){if(Math.abs(((a-90+540)%360)-180)<11||Math.abs(((a-angOf(36,-34)+540)%360)-180)<11)continue;const an=a*D2R,r=54+R()*5,y=gy(Math.cos(an)*r,Math.sin(an)*r);I('pyr',pick(['#5b4636','#4a3a30','#6b5146']),3+R()*2,6+R()*5,3+R()*2,Math.cos(an)*r,y+3,Math.sin(an)*r,0,R()*3,0);}}});

const thunder=Object.assign({},NINJA_G,{id:'thunder',name:'Thunder Temple',icon:'⚡',R:50,start:inw(0,48),
  hf:(x,z)=>Math.sin(x*.1)*.7+Math.cos(z*.08)*.7,ground:'#9aa8b8',ground2:'#aab6c4',sky:'#7d8fb4',fog:[50,170],fogC:'#9aa6c4',hedgeC:'#5b6b80',biome:'ninja',
  hello:'The Thunder Temple! Rumble, rumble! The storm clouds make sparks dance in the sky. Two pups are hiding here.',how:'A Fire pup melts the ice wall at the Ice Temple.',
  exits:[{x:0,z:50,to:'icet',arrive:inw(0,-50),name:'Ice Temple',icon:'🧊'},
         {x:-36,z:-34,to:'peak',arrive:inw(38,32),name:'Dragon Peak',icon:'🐉',open:()=>foundIn(areaPups('thunder'))>=2,lock:()=>{const n=foundIn(areaPups('thunder'));return `The steps to Dragon Peak are too stormy. Find ${2-n} more ${2-n>1?'pups':'pup'} in the Thunder Temple to calm the storm!`;}}],
  build(){mountainsFar(['#6b7d9a','#5b6b80']);for(let i=0;i<14;i++){const a=i/14*6.28;I('sphL','#5b6378',14,6,14,Math.cos(a)*60,40+R()*8,Math.sin(a)*60-20,0,0,0,true);}
    pagoda(0,-18,{w:12,tiers:2,wall:'#e6ecf5',roof:'#3d5fa8',pil:'#3d8fe0',trim:'#ffd23f',label:'⚡ Thunder Temple',lw:6});
    [[-14,-8],[14,-8],[-20,16],[20,16]].forEach(p=>{const y=gy(p[0],p[1]);I('cyl','#c97a3e',.15,7,.15,p[0],y+3.5,p[1]);I('sph','#c97a3e',.5,.5,.5,p[0],y+7.2,p[1]);I('cyl','#5b6b80',.6,.6,.6,p[0],y+.3,p[1]);col(p[0],p[1],.7);});
    [[-22,-12],[-26,4],[24,-20],[12,30],[-14,28],[30,8]].forEach(p=>{const y=gy(p[0],p[1]);for(let k=0;k<4;k++)I('cone',pick(['#9be8ff','#c9b6ff','#7fc8f0']),.4,1.6+k*.6,.4,p[0]+(k-1.5)*.6,y+.8+k*.3,p[1]+(k%2)*.4,0,0,(k-1.5)*.25,true);col(p[0],p[1],1.1);});
    const bolt=grp();for(let i=0;i<5;i++){const m=new THREE.Mesh(G.box,new THREE.MeshBasicMaterial({color:'#fff6a0'}));m.scale.set(.5,4,.5);m.position.set((i%2?1:-1)*.8,i*3.6,0);m.rotation.z=(i%2?.4:-.4);bolt.add(m);W.disp.push(m.material);}W.ag.add(bolt);bolt.visible=false;
    let bt=2;W.ticks.push(dt=>{bt-=dt;if(bt<0){bt=2+Math.random()*3;const a=Math.random()*6.28;bolt.position.set(Math.cos(a)*45,15,Math.sin(a)*45-10);bolt.visible=true;setTimeout(()=>{bolt.visible=false;},150);if(state.set.sfx&&Math.random()<.5)sfx.boop&&0;}});
    {const tx=20,tz=18;I('cone','#c9a86a',2.8,3.4,2.8,tx,gy(tx,tz)+1.7,tz);col(tx,tz,2.6);}
    sign(-10,6,'⚡ Spark Catch',3,6);W.things.push({x:-10,z:3,r:4,icon:'⚡',label:'Spark Catch',act:()=>{sfx.chime();startFlies('activity','sparks');}});
    [[-30,20],[30,24],[-36,-6],[36,-4]].forEach((p,i)=>banner(p[0],p[1],i%2?'#3d8fe0':'#ffd23f',i%2?'⚡':'🌩️'));
    for(let a=0;a<360;a+=7){if(Math.abs(((a-90+540)%360)-180)<11||Math.abs(((a-angOf(-36,-34)+540)%360)-180)<11)continue;const an=a*D2R,r=54+R()*5,y=gy(Math.cos(an)*r,Math.sin(an)*r);I('pyr',pick(['#6b7d9a','#5b6b80','#7d8ea8']),3+R()*2,7+R()*5,3+R()*2,Math.cos(an)*r,y+3.5,Math.sin(an)*r,0,R()*3,0);}}});

const peak=Object.assign({},NINJA_G,{id:'peak',name:'Dragon Peak',icon:'🐉',R:46,start:inw(-38,32),
  hf:(x,z)=>4*Math.exp(-(x*x+(z+16)*(z+16))/500)+Math.sin(x*.12)*.4,sky:'#a9d8ff',fog:[80,260],fogC:'#e8f4ff',
  hello:'Dragon Peak! You are above the clouds. Dragons fly round the golden shrine. Two pups are hiding up here, and so are 6 dragon pearls!',how:'Find 2 pups in the Fire Temple or the Thunder Temple.',
  exits:[{x:-38,z:30,to:'firet',arrive:inw(36,-34),name:'Fire Temple',icon:'🔥'},{x:38,z:30,to:'thunder',arrive:inw(-36,-34),name:'Thunder Temple',icon:'⚡'}],
  build(){cloudPuffs(16,-6,70);cloudPuffs(10,-14,110,'#f4f8ff');
    pagoda(0,-30,{w:11,tiers:3,wall:'#fff6c9',roof:'#ffd23f',pil:'#d9362e',trim:'#d9362e',label:'🐉 Golden Shrine',lw:6});
    dragonFlyer(t=>[Math.cos(t*.35)*26,14+Math.sin(t*.7)*3,Math.sin(t*.35)*26-10],{c:'#3fae5a',c2:'#ffd23f',wing:'#8fe39a',n:14,s:1.2});
    dragonFlyer(t=>[Math.cos(-t*.28+2)*34,20+Math.sin(t*.5)*4,Math.sin(-t*.28+2)*30-6],{c:'#d9362e',c2:'#ffd23f',wing:'#ffb347',n:12,s:1});
    bunting(-20,10,20,10,5);bunting(-14,-6,14,-6,6);[[-20,10],[20,10],[-14,-6],[14,-6]].forEach(p=>{I('cyl','#9b6a43',.12,6,.12,p[0],gy(p[0],p[1])+3,p[1]);col(p[0],p[1],.3);});
    gong(16,-20);[[-6,18],[6,18],[-6,4],[6,4]].forEach(p=>stoneLantern(p[0],p[1]));torii(0,22,0,'#d9362e',.9);
    [[-18,-18],[18,-6]].forEach(p=>{const y=gy(p[0],p[1]);I('box','#ffd23f',1.6,1,1.6,p[0],y+.5,p[1]);I('sph','#3fae5a',1,1,1.4,p[0],y+1.7,p[1]);I('cone','#ffd23f',.2,.8,.2,p[0]-.3,y+2.6,p[1]);I('cone','#ffd23f',.2,.8,.2,p[0]+.3,y+2.6,p[1]);col(p[0],p[1],1);});
    sign(8,30,'🔮 Dragon Pearls',3,6);W.things.push({x:8,z:27,r:4,icon:'🔮',label:'Dragon Pearls',act:()=>{sfx.chime();startCollect('dpearls');}});
    for(let a=0;a<360;a+=8){if(Math.abs(((a-angOf(-38,30)+540)%360)-180)<11||Math.abs(((a-angOf(38,30)+540)%360)-180)<11)continue;const an=a*D2R;snowRock(Math.cos(an)*(49+R()*3),Math.sin(an)*(49+R()*3),1.4+R()*.6);}},ground:'#b9c6a0',ground2:'#c9d6b0',hedgeC:'#8a9a7a'});

const glow={id:'glow',name:'Glow Cave',icon:'🍄',R:34,ground:'#3a3048',ground2:'#4a3a5a',sky:'#1a1428',fog:[20,90],fogC:'#2a2040',hedgeC:'#5a4a70',noEnrich:true,start:inw(30,0,.7),
  hf:(x,z)=>Math.sin(x*.2)*.3+Math.cos(z*.2)*.3,
  hello:'The Glow Cave! Everything glows in the dark. A secret sparkly pup and a treasure chest are hidden in here!',how:'A Spark pup lights up the dark cave in the Bamboo Forest.',
  exits:[{x:34,z:0,to:'bamboo',arrive:inw(-52,0,.85),name:'Bamboo Forest',icon:'🎋'}],
  build(){const dome=new THREE.Mesh(G.hemi,new THREE.MeshLambertMaterial({color:'#2a2040',side:THREE.BackSide}));dome.scale.set(40,22,40);W.ag.add(dome);W.disp.push(dome.material);
    for(let i=0;i<60;i++){const a=R()*6.28,r=6+R()*30,x=Math.cos(a)*r,z=Math.sin(a)*r,h=Math.sqrt(Math.max(0,1-(r/40)**2))*22;I('sph',pick(['#9be8ff','#c9ff9b','#ffb7f0']),.12,.12,.12,x,h-.5,z,0,0,0,true);}
    for(let i=0;i<26;i++){const a=R()*6.28,r=6+R()*24,x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.hypot(x+12,z+10)<4||Math.hypot(x-6,z+18)<4||x>20)continue;const y=gy(x,z),c=pick(['#7fffe0','#ff7fd0','#c9ff7f','#7fc8ff']),s=.5+R()*.9;
      I('cyl','#f2f0ff',.15*s,1.2*s,.15*s,x,y+.6*s,z,0,0,0,true);I('hemi',c,.8*s,.6*s,.8*s,x,y+1.2*s,z,0,0,0,true);}
    for(let i=0;i<10;i++){const a=R()*6.28,r=10+R()*18,x=Math.cos(a)*r,z=Math.sin(a)*r;if(x>18)continue;const y=gy(x,z);for(let k=0;k<3;k++)I('cone',pick(['#b58cff','#7fd3ff']),.4,1.6+k*.7,.4,x+(k-1)*.5,y+.8+k*.3,z,0,0,(k-1)*.3,true);col(x,z,1);}
    pond(-4,8,6,'#3a7ad0');fishSchool(-4,.6,8,4,5,'🐟',.4);treasureChest(6,-18,'glow');}};

/* ----------------- activity skins ----------------- */
const dojoSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#efe3c4"/>`;for(let i=0;i<12;i++)s+=`<rect x="${i*90}" y="0" width="86" height="768" fill="${i%2?'#e8d9b5':'#efe3c4'}"/>`;
  s+=`<rect x="0" y="0" width="1024" height="110" fill="#5b2a1e"/><rect x="0" y="100" width="1024" height="18" fill="#ffd23f"/>`;[[120,'#d9362e','🔥'],[904,'#3d8fe0','⚡']].forEach(b=>s+=`<rect x="${b[0]-40}" y="118" width="80" height="220" fill="${b[1]}" stroke="${k}" stroke-width="4"/><text x="${b[0]}" y="250" font-size="54" text-anchor="middle">${b[2]}</text>`);return s+'</svg>';};
const stormSVG=()=>{let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="stg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3d4a6b"/><stop offset="1" stop-color="#8a9ac0"/></linearGradient></defs><rect width="1024" height="768" fill="url(#stg)"/>`;
  for(let i=0;i<9;i++)s+=`<ellipse cx="${i*130+30}" cy="${60+(i%3)*30}" rx="120" ry="60" fill="#5b6378"/>`;return s+`<path d="M0 700 L150 620 L300 690 L460 600 L620 680 L800 610 L1024 690 V768 H0Z" fill="#5b6b80"/></svg>`;};
function redPandaSVG(){const k=INK;return `<svg viewBox="0 0 90 90"><g stroke="${k}" stroke-width="3.5"><path d="M20 62 Q2 50 10 30" fill="none" stroke="#c8562a" stroke-width="14" stroke-linecap="round"/><path d="M16 55 l-8 -6 M12 43 l-9 -3" stroke="#f2e0c9" stroke-width="5"/>
  <ellipse cx="48" cy="60" rx="24" ry="18" fill="#c8562a"/><circle cx="56" cy="34" r="18" fill="#c8562a"/><circle cx="42" cy="20" r="7" fill="#fff"/><circle cx="70" cy="20" r="7" fill="#fff"/><ellipse cx="56" cy="40" rx="11" ry="8" fill="#fff"/>
  <rect x="32" y="70" width="9" height="12" rx="4" fill="#26232e"/><rect x="56" y="70" width="9" height="12" rx="4" fill="#26232e"/></g><circle cx="50" cy="32" r="3" fill="${k}"/><circle cx="62" cy="32" r="3" fill="${k}"/><circle cx="56" cy="40" r="3" fill="${k}"/></svg>`;}
function snowPen2SVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="140" fill="#cbe5f7"/><path d="M0 120 L140 50 L300 110 L460 40 L620 120 L780 50 L1024 110 V140 H0Z" fill="#eef4fa"/><rect y="130" width="1024" height="638" fill="#f6fafd"/>`;
  for(let i=0;i<40;i++)s+=`<circle cx="${(i*151)%1010+8}" cy="${160+(i*83)%590}" r="${3+i%4}" fill="#dde8f2"/>`;s+=penBox2('🎋 Bamboo den','#e3f2d8','#c9a86a','#9b6a43');
  for(let i=0;i<5;i++)s+=`<rect x="${PEN.x1+40+i*40}" y="${PEN.y1+70}" width="12" height="${PEN.y2-PEN.y1-90}" rx="5" fill="#7fbf4a" stroke="${k}" stroke-width="2"/>`;return s+'</svg>';}
function lavaSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#ff7a2a"/><rect width="1024" height="150" fill="#5b4636"/>`;for(let i=0;i<30;i++)s+=`<circle cx="${(i*137)%1000+12}" cy="${190+(i*71)%560}" r="${8+i%10}" fill="#ffd23f" opacity=".6"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#5b4636" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#5b4636" stroke="${k}" stroke-width="5"/>`;return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🦄</text></svg>`;}
CATCH.targets={k:'targets',icon:'🎯',need:15,bg:dojoSVG,cls:'',inner:'<b>🎯</b>',art:'🥷🎯',intro:'Ninja target practice! Tap a target while it glows, and your pup throws a soft foam star at it. Hit 15!',tip:'Wait until it glows, then tap!',title:'You hit 15 targets! Super ninja skills!'};
CATCH.sparks={k:'sparks',icon:'⚡',need:15,bg:stormSVG,cls:'snow',inner:'<b>⚡</b>',art:'🫙⚡',fall:true,intro:'Catch the sparks from the storm! Tap a spark while it shines, and it zips into your jar. Catch 15!',tip:'Wait until it shines, then tap!',title:'You caught 15 storm sparks!'};
HERDS.redpandas={k:'redpandas',icon:'🐾',n:6,animal:redPandaSVG,herder:()=>buddyPup(),bg:snowPen2SVG,title:'All the red pandas are cosy in their den!',
  intro:p=>`The red pandas are playing in the snow, and it is nearly bedtime! Help ${p.name} guide them into the bamboo den. Drag your finger and ${p.name} will follow. The red pandas scamper away from ${p.name}!`};
COUNTS.lavasteps={k:'lavasteps',icon:'🌋',rounds:[{step:4,word:'fours'},{step:6,word:'sixes'},{step:8,word:'eights'}],bg:lavaSVG,cls:'stone',intro:'Help your pup hop across the lava on the stepping stones! Count the jumps.',title:'You crossed the lava! Ninja hop!'};
COLLECT.scrolls={k:'scrolls',area:'bamboo',icon:'📜',size:2,items:[[-30,6],[18,-38],[34,4],[-8,-30],[-34,-20],[10,30]],start:[4,0,Math.PI],thing:'ninja scroll',art:'📜',
  intro:'Scroll Hunt! Find the 6 ninja scrolls hidden in the Bamboo Forest. Run, ninja, run!',title:'You found all the ninja scrolls!'};
COLLECT.dpearls={k:'dpearls',area:'peak',icon:'🔮',size:2,items:[[-26,-10],[26,-14],[-14,20],[22,18],[0,-12],[-30,8]],start:[8,26,Math.PI],thing:'dragon pearl',art:'🔮',
  intro:'Dragon Pearls! The dragons have dropped 6 shining pearls. Collect them all!',title:'You collected all the dragon pearls!'};
regAct('targets',{name:'Ninja Targets',icon:'🎯',island:'ninja',area:'dojo',where:'the Dojo',play:()=>startFlies('arcade','targets')});
regAct('scrolls',{name:'Scroll Hunt',icon:'📜',island:'ninja',area:'bamboo',where:'the Bamboo Forest',play:()=>arcadeTravel('bamboo',COLLECT.scrolls.start,()=>startCollect('scrolls'),'Scroll Hunt is about to start!')});
regAct('redpandas',{name:'Red Panda Round-up',icon:'🐾',island:'ninja',area:'icet',where:'the Ice Temple',play:()=>startHerd('arcade','redpandas')});
regAct('lavasteps',{name:'Lava Steps',icon:'🌋',island:'ninja',area:'firet',where:'the Fire Temple',play:()=>startStones('arcade','lavasteps')});
regAct('sparks',{name:'Spark Catch',icon:'⚡',island:'ninja',area:'thunder',where:'the Thunder Temple',play:()=>startFlies('arcade','sparks')});
regAct('dpearls',{name:'Dragon Pearls',icon:'🔮',island:'ninja',area:'peak',where:'Dragon Peak',play:()=>arcadeTravel('peak',COLLECT.dpearls.start,()=>startCollect('dpearls'),'Dragon Pearls is about to start!')});

regIsland({id:'ninja',name:'Ninja Mountains',icon:'🥷',type:'fire',req:['snowy','reef'],rideName:'The dragon kite',ride:'the dragon kite',from:'kite hill in the village',rideIcon:'🪁',rideSay:'Hold on tight! The dragon kite flies you up into the mountains!',
  homeSay:'The dragon kite glides back down to the village!',homePos:[-33,-8,-Math.PI/2],
  badge:'Fire Badge',cert:'Seb, Ninja Mountains Hero!',bossHint:'Ember the Fire Unicorn is waiting at the top of Dragon Peak!',
  nextSay:'Hooray! Ninja Mountains is safe! Have you been to Number Kingdom too?',
  map:{shape:'M80 410 L200 180 L270 230 L360 60 L430 120 L500 40 L600 200 L680 150 L790 410 Q600 470 430 460 Q260 470 80 410Z',
    nodes:{dojo:[430,350],bamboo:[230,260],icet:[630,260],firet:[200,120],thunder:[660,120],peak:[430,80],glow:[95,345]},
    links:[['dojo','bamboo'],['dojo','icet'],['bamboo','firet'],['icet','thunder'],['firet','peak'],['thunder','peak'],['bamboo','glow']]},
  boss:{area:'peak',x:0,z:-16,perch:0,uni:EMBER,
    story:[['m','Muddle the Magpie flaps down in a tiny black ninja mask. "Sorry, Seb! I wanted to be a ninja too. I borrowed the shiny Fire Star to practise sneaking, and I sneaked so well that I scared all the pups!"'],
      ['u','Ember the Fire Unicorn smiles. "Muddle, a true ninja is not sneaky. A true ninja is kind and helps others. Now give back the shiny Fire Star."'],
      ['b','Muddle gives back the Fire Star, and all 12 Fire pups cheer! Sensei Mochi bows to Seb, and Ember gives Seb the Fire Badge.']],
    after:['Ember says: thank you for finding every pup in Ninja Mountains!','Muddle says: hi-yah! I am a kind ninja now.','Ember says: the dragons are doing a loop just for you!']},
  pups:P,bonus:[GLIMMER],areas:[dojo,bamboo,icet,firet,thunder,peak,glow]});
})();
