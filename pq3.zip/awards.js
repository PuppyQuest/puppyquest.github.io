/* ================================================================
   Seb's Puppy Quest 3: merit badges and certificates
   Each award has a test. Every 1.5 seconds new awards are noted in
   the save; when Seb is free (walking about, not in a game or card),
   a badge pops up as a banner and a certificate as a big card.
   Both have their own pages in the Pup House.
   ================================================================ */
const nFound=()=>Object.keys(state.found).filter(id=>PUPS[id]).length;
let awPage=0;
function pager(n,per,cb){const pg=$('#bookPager'),pages=Math.ceil(n/per);if(pages<2){pg.style.display='none';return;}awPage=Math.min(awPage,pages-1);pg.style.display='flex';pg.innerHTML=`<button class="opt" id="pgPrev">◀</button><span>${awPage+1} / ${pages}</span><button class="opt" id="pgNext">▶</button>`;
  tap('#pgPrev',()=>{if(awPage>0){awPage--;sfx.boop();cb();}});tap('#pgNext',()=>{if(awPage<pages-1){awPage++;sfx.boop();cb();}});}
const MERITS=[
  {id:'first',icon:'🐶',name:'First Friend',how:'Find your first pup.',ok:()=>nFound()>=1},
  {id:'five',icon:'🖐️',name:'High Five',how:'Find 5 pups.',ok:()=>nFound()>=5},
  {id:'ten',icon:'🔟',name:'Top Ten',how:'Find 10 pups.',ok:()=>nFound()>=10},
  {id:'tag',icon:'🏃',name:"Tag, You're It!",how:'Find all 5 pups that play tag on Meadow Island.',ok:()=>['barley','cali','poppy','lily','bluebell'].every(isFound)},
  {id:'wellies',icon:'🥾',name:'Welly Walker',how:'Find the wellies in the farmer\'s shed.',ok:()=>!!state.gear.wellies},
  {id:'vine',icon:'🌿',name:'Vine Grower',how:'Grow a vine bridge with a Leaf pup.',ok:()=>!!(state.vines.fields||state.vines.pond)},
  {id:'bridges',icon:'🌉',name:'Bridge Builder',how:'Grow both vine bridges to Bluebell Wood.',ok:()=>!!(state.vines.fields&&state.vines.pond)},
  {id:'explorer',icon:'🧭',name:'Explorer',how:'Visit all four areas of Meadow Island.',ok:()=>['windmill','sunflowers','pond','wood'].every(a=>state.seen[a])},
  {id:'meadow',icon:'🌼',name:'Meadow Hero',how:'Find all 13 pups on Meadow Island.',ok:()=>!!state.islDone.meadow},
  {id:'pets',icon:'💖',name:'Cuddle Champ',how:'Pet your pups 20 times.',ok:()=>(state.stats.pets||0)>=20},
  {id:'pack',icon:'🐾',name:'Pack Leader',how:'Have a buddy and 2 pups in your pack.',ok:()=>teamIds().length>=3},
  {id:'granny',icon:'👵',name:'Granny\'s Helper',how:'Ask Granny Paws for 5 hints.',ok:()=>(state.stats.granny||0)>=5},
  {id:'toss',icon:'🍎',name:'Treat Tosser',how:'Score 300 in Treat Toss at the Games Arcade.',ok:()=>(state.hi.toss||0)>=300},
  {id:'tickle',icon:'👆',name:'Tickle Champ',how:'Score 150 in Tummy Tickle at the Games Arcade.',ok:()=>(state.hi.tickle||0)>=150},
  {id:'pops',icon:'🫧',name:'Bubble Buster',how:'Pop 100 bubbles.',ok:()=>(state.stats.pops||0)>=100},
  {id:'pairs',icon:'🃏',name:'Pair Pro',how:'Match all the Paw Pairs.',ok:()=>(state.hi.pairs||0)>0},
  {id:'herd',icon:'🐑',name:'Shepherd',how:'Herd all the sheep with Cali.',ok:()=>!!state.acts.herd},
  {id:'herdfast',icon:'⏱️',name:'Speedy Shepherd',how:'Herd all the sheep in under 40 seconds.',ok:()=>state.hi.herd>0&&state.hi.herd<40},
  {id:'maze',icon:'🌻',name:'Maze Runner',how:'Finish the Sunflower Maze Race.',ok:()=>!!state.acts.maze},
  {id:'stones',icon:'🪨',name:'Stone Hopper',how:'Count all the way across the Stepping Stones.',ok:()=>!!state.acts.stones},
  {id:'flies',icon:'✨',name:'Firefly Friend',how:'Catch 15 fireflies in Bluebell Wood.',ok:()=>!!state.acts.flies},
  {id:'stars250',icon:'⭐',name:'Star Collector',how:'Collect 250 stars.',ok:()=>state.stars>=250},
  {id:'stars500',icon:'🌟',name:'Super Star',how:'Collect 500 stars.',ok:()=>state.stars>=500},
  {id:'guest',icon:'🎁',name:'Old Friends',how:'Bring your buddy from Puppy Quest 2.',ok:()=>!!state.guest},
  {id:'skis',icon:'⛷️',name:'Ski Ready',how:'Find the skis at the Lift Station.',ok:()=>!!state.gear.skis},
  {id:'firstrun',icon:'🟢',name:'First Run',how:'Ski all the way down a ski run.',ok:()=>!!(state.acts.green||state.acts.blue||state.acts.red)},
  {id:'board',icon:'🏂',name:'Board Rider',how:'Snowboard down the Red Run.',ok:()=>!!state.acts.red},
  {id:'slalom',icon:'🚩',name:'Slalom Star',how:'Finish the Green, Blue and Red Runs.',ok:()=>['green','blue','red'].every(k=>state.acts[k])},
  {id:'drift',icon:'❄️',name:'Snow Shifter',how:'Clear a snowdrift with a Snow pup.',ok:()=>!!(state.vines.drift_blue||state.vines.drift_cave_b||state.vines.drift_cave_r)},
  {id:'penguins',icon:'🐧',name:'Penguin Pal',how:'Herd all the penguins home.',ok:()=>!!state.acts.penguins},
  {id:'flakes',icon:'🫙',name:'Flake Catcher',how:'Catch 15 sparkly snowflakes.',ok:()=>!!state.acts.flakes},
  {id:'icesteps',icon:'🧊',name:'Ice Counter',how:'Count across the Ice Steps.',ok:()=>!!state.acts.icesteps},
  {id:'snowy',icon:'🏔️',name:'Snowy Hero',how:'Find all 12 pups on Snowy Summit.',ok:()=>!!state.islDone.snowy},
  {id:'flippers',icon:'🤿',name:'Flipper Finder',how:'Find the flippers in the Lagoon.',ok:()=>!!state.gear.flippers},
  {id:'current',icon:'🌀',name:'Current Calmer',how:'Calm a strong current with a Water pup.',ok:()=>!!(state.vines.current_ship||state.vines.current_trench||state.vines.current_palace_s||state.vines.current_palace_t)},
  {id:'pearls',icon:'🦪',name:'Pearl Diver',how:'Collect all the pearls in Pearl Dive.',ok:()=>!!state.acts.pearls},
  {id:'fishherd',icon:'🐠',name:'Fish Friend',how:'Round up all the little fish.',ok:()=>!!state.acts.fishherd},
  {id:'starfish',icon:'⭐',name:'Starfish Spotter',how:'Find all the starfish.',ok:()=>!!state.acts.starfish},
  {id:'treasure',icon:'🪙',name:'Treasure Hunter',how:'Find all the gold coins at the Shipwreck.',ok:()=>!!state.acts.treasure},
  {id:'glowfish',icon:'🐟',name:'Glow Catcher',how:'Catch 15 glow-fish.',ok:()=>!!state.acts.glowfish},
  {id:'shellsteps',icon:'🐚',name:'Shell Counter',how:'Count across the Shell Steps.',ok:()=>!!state.acts.shellsteps},
  {id:'reef',icon:'🐠',name:'Reef Hero',how:'Find all 12 pups on Coral Reef.',ok:()=>!!state.islDone.reef},
  {id:'secret',icon:'🗝️',name:'Secret Explorer',how:'Open a secret bonus area.',ok:()=>!!(state.vines.eagle||state.vines.vent)},
  {id:'sparkly',icon:'💎',name:'Sparkly Friend',how:'Find a sparkly secret pup.',ok:()=>isFound('crystal')||isFound('opal')},
  {id:'chest',icon:'🎁',name:'Treasure Chest',how:'Open a secret treasure chest.',ok:()=>Object.keys(state.chests||{}).length>0},
  {id:'twenty',icon:'🐾',name:'Twenty Pups',how:'Find 20 pups.',ok:()=>nFound()>=20},
  {id:'thirty',icon:'🏅',name:'Pup Collector',how:'Find 30 pups.',ok:()=>nFound()>=30}];
const CERTS=[
  {id:'meadow',icon:'🌼',title:'Meadow Island Hero',why:'for finding all 13 pups on Meadow Island',ok:()=>!!state.islDone.meadow},
  {id:'herd',icon:'🐑',title:'Super Shepherd',why:'for helping Cali herd all the sheep home',ok:()=>!!state.acts.herd},
  {id:'maze',icon:'🌻',title:'Maze Runner',why:'for racing through the Sunflower Maze',ok:()=>!!state.acts.maze},
  {id:'stones',icon:'🪨',title:'Counting Champion',why:'for counting in 2s, 5s, 10s and 3s across the Stepping Stones',ok:()=>!!state.acts.stones},
  {id:'flies',icon:'✨',title:'Firefly Friend',why:'for catching 15 fireflies in Bluebell Wood',ok:()=>!!state.acts.flies},
  {id:'allacts',icon:'🏆',title:'Meadow Games Champion',why:'for playing every activity on Meadow Island',ok:()=>['herd','maze','stones','flies'].every(k=>state.acts[k])},
  {id:'arcade',icon:'🎮',title:'Games Arcade Ace',why:'for playing every game in the Games Arcade',ok:()=>['toss','tickle','bubbles','pairs'].every(k=>(state.played||{})[k])},
  {id:'guest',icon:'🎁',title:'Friends Forever',why:'for bringing a friend all the way from Puppy Quest 2',ok:()=>!!state.guest},
  {id:'snowy',icon:'🏔️',title:'Snowy Summit Hero',why:'for finding all 12 pups on Snowy Summit',ok:()=>!!state.islDone.snowy},
  {id:'slalom',icon:'⛷️',title:'Slalom Champion',why:'for skiing the Green, Blue and Red Runs',ok:()=>['green','blue','red'].every(k=>state.acts[k])},
  {id:'snowgames',icon:'❄️',title:'Snowy Games Champion',why:'for playing every activity on Snowy Summit',ok:()=>['penguins','green','flakes','blue','red','icesteps'].every(k=>state.acts[k])},
  {id:'reef',icon:'🐠',title:'Coral Reef Hero',why:'for finding all 12 pups on Coral Reef',ok:()=>!!state.islDone.reef},
  {id:'deepsea',icon:'🤿',title:'Deep Sea Explorer',why:'for playing every activity on Coral Reef',ok:()=>['pearls','fishherd','starfish','treasure','glowfish','shellsteps'].every(k=>state.acts[k])},
  {id:'secrets',icon:'💎',title:'Secret Finder',why:'for finding both sparkly secret pups',ok:()=>isFound('crystal')&&isFound('opal')}];

const AQ=[];let toastUntil=0;
function awardTick(){if(!state||cur==='title')return;state.badges=state.badges||{};state.certs=state.certs||{};state.hi=state.hi||{};state.acts=state.acts||{};
  let changed=false;
  MERITS.forEach(m=>{if(!state.badges[m.id]&&m.ok()){state.badges[m.id]=Date.now();AQ.push({b:m});changed=true;}});
  CERTS.forEach(c=>{if(!state.certs[c.id]&&c.ok()){state.certs[c.id]=Date.now();AQ.push({c});changed=true;}});
  if(changed)save();
  if(!AQ.length||Date.now()<toastUntil)return;
  const free=!ovOpen()&&!sleepOn&&((cur==='world'&&!player.lock&&!W.rescue&&!W.act&&!W.friendWait)||cur==='book'||cur==='binder');if(!free)return;
  const a=AQ.shift();if(a.b)toast(a.b);else certCard(a.c);}
setInterval(awardTick,1500);
function toast(m){const t=$('#toast');t.innerHTML=`<span class="ti">${m.icon}</span><span><small>New badge!</small><br>${m.name}</span>`;t.classList.remove('on');void t.offsetWidth;t.classList.add('on');
  toastUntil=Date.now()+3600;sfx.chime();try{if(!speechSynthesis.speaking)speak(`New badge! ${m.name}!`);}catch(e){}setTimeout(()=>t.classList.remove('on'),3300);}
function certHTML(c,date){return {cls:'cert',art:`<div style="font-size:90px;line-height:1">${c.icon}</div><div class="fitsvg" style="width:110px">${sebSVG(true)}</div>`,h:'Certificate',h3:`🏅 ${c.title}`,
  p:`Awarded to <b>Seb</b> ${c.why}.${date?`<br><small>${new Date(date).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'})}</small>`:''}`,say:`Certificate! ${c.title}! Awarded to Seb ${c.why}.`};}
function certCard(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray!','green']]}));}

/* ----- Pup House pages ----- */
function badgesPage(quiet){const gr=$('#bookGrid');gr.className='merits';gr.innerHTML='';const got=MERITS.filter(m=>state.badges[m.id]).length;pager(MERITS.length,24,()=>badgesPage(true));
  MERITS.slice(awPage*24,awPage*24+24).forEach(m=>{const has=!!state.badges[m.id],b=el('button','mcard'+(has?'':' lock'),`<span class="mi">${has?m.icon:'🔒'}</span><span>${m.name}</span>`);
    tap(b,()=>{sfx.boop();card({art:`<div style="font-size:110px;line-height:1;${has?'':'filter:grayscale(1);opacity:.5'}">${m.icon}</div>`,h:m.name,p:(has?'✅ You earned this badge! ':'🔒 To earn this badge: ')+m.how,btns:[['OK','green']]});});gr.appendChild(b);});
  if(!quiet)say(`Your badges. You have earned ${got} of ${MERITS.length}.`);}
function certsPage(quiet){const gr=$('#bookGrid');gr.className='certs';gr.innerHTML='';const got=CERTS.filter(c=>state.certs[c.id]).length;pager(CERTS.length,8,()=>certsPage(true));
  CERTS.slice(awPage*8,awPage*8+8).forEach(c=>{const has=!!state.certs[c.id],b=el('button','ccard'+(has?'':' lock'),`<span class="ci">${has?c.icon:'🔒'}</span><b>${c.title}</b><small>${has?'Awarded to Seb':'Not yet'}</small>`);
    tap(b,()=>{sfx.boop();if(has)card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['OK','green']]}));else card({art:`<div style="font-size:100px;line-height:1;filter:grayscale(1);opacity:.5">${c.icon}</div>`,h:c.title,p:`🔒 This certificate is ${c.why}.`,btns:[['OK','green']]});});gr.appendChild(b);});
  if(!quiet)say(`Your certificates. You have ${got} of ${CERTS.length}.`);}
