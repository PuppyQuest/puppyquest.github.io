/* ================================================================
   Summer Beach Party: the summer cards (26 Nov 2026, claude/summer-beach-design.md section 11)
   - a card for each of the 119 summer pups, the hermit crab (Season Friend) and the nine unicorns in
     summer looks; on the Seasons shelf, one tab per island plus a 🏖️ tab for the crab, Breeze and Sorbet;
   - stats and powers as on the main card (the saga's fixed scale); the everyday move gets a summer name;
   - the island's scene in summer, a shell and starfish frame, a shell badge, a wave edge, and the
     summer-only Seashell finish (cardlook.js rolls it, letter e);
   - packs per area, sandy with a spade; the Pup House and binder summer look.
   Hooks: window.XCARDS, window.SEALOOK['b:'], window.SEAPACK.b_, CLOOK.EDGE.sb.
   ================================================================ */
(function(){
const SB=window.SB,SL=window.SBLOOK,sp=SL.sp,X=()=>(state&&state.sx&&state.sx.sb)||{};
const SMOVE={herd:'Wave Ride',pull:'Wave Ride',snow:'Wave Ride',tug:'Wave Ride',rescue:'Wave Ride',dig:'Sandcastle Stomp',giant:'Sandcastle Stomp',sniff:'Shell Shake',point:'Shell Shake',truffle:'Shell Shake',
 zoom:'Splash Dash',spots:'Splash Dash',fetch:'Beach Ball Bounce',splash:'Splash Dash',guard:'Sandcastle Stomp',yodel:'Sunny Roll',snore:'Sunny Roll',cuddle:'Sunny Roll',wiggle:'Shell Shake',rainbow:'Beach Ball Bounce',cloud:'Beach Ball Bounce'};
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const HOW={dig:'🗺️ Dug up with a treasure map',hut:'🛖 Found peeking out of a beach hut',castle:'🏰 Found inside a giant sandcastle'};
const dstr=d=>d&&d>1e12?new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'';
const TM={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const hs=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;},cp=(v,a,b)=>Math.max(a,Math.min(b,v));
function scard(p,set,n,of,isl){const C=window.CARDS,B=C.breedOf(p.breed),T=C.TY(p.type),z=SZ[B.sz]||SZ.m,sh=p.shiny||p.season?10:0,st={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  st[C.STATS[hs(p.id)%4][0]]+=1;for(const k in st)st[k]=cp(st[k],1,10);
  const c={stats:st,zoom:cp(z[0]+sh,30,120),moves:[[SMOVE[B.g]||'Splash Dash',1,z[1]],[TM[p.type]||'Pup Power',2,z[2]+sh]],col:T.col,bg:shade(T.col,.72)};
  Object.assign(c,{cid:'3:sb_'+p.id,game:3,set,n,of,src:p,base:p.id,name:p.name,breed:p.breed,type:p.type,rar:p.shiny||p.season?'sparkly':'common',fact:SL.FACT[p.id]||p.fact||'',sb:true,bisl:isl});
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return p.id==='sorbet'?'the Beach Party, Pawprint Village':(A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>SB.xFound(p.id);c.foundAt=()=>{const v=(X().found||{})[p.id];return typeof v==='number'?v:0;};
  c.art=an=>critterSVG(sp(p),{anim:an,sparkly:!!(p.shiny||p.season)});
  c.hint=()=>SB.opened()?`${p.name} is hiding in ${AREAS[p.area]?AREAS[p.area].name:'the village'} in summer. ${p.hint||''}`:'Summer Beach Party opens after Halloween is finished!';
  c.back=()=>{const d=c.foundAt(),h=(X().how||{})[p.id];return [`🏖️ Found in summer${d?' on '+dstr(d):''}`,`📍 ${c.home()}`,HOW[h]||'🏖️ Found at the Summer Beach Party','🐚 Ready for the Beach Party'];};
  return c;}
function unicard(I,set,n,of){const u=I.boss.uni,C=window.CARDS,T=C.TY(I.type);const c={cid:'3:sb_'+u.id,game:3,set,n,of,src:u,base:u.id,name:u.name,breed:u.breed,type:I.type,rar:'unicorn',uni:true,sb:true,bisl:I.id,
  fact:`${u.name}'s summer lesson: ${SB.LESSON[u.id]||'Friends make every day sunnier.'}`,zoom:120,moves:[['Rainbow Gallop',1,30],['Map Piece',3,100]],col:T.col,bg:'#e6f6ff',stats:{spd:9,brn:9,cud:10,brv:9}};
  c.home=()=>I.name;c.earned=()=>!!(X().mp||{})[I.id];c.foundAt=()=>(X().mp||{})[I.id]||0;c.art=an=>critterSVG(sp(u),{anim:an});
  c.hint=()=>`Find ${SB.NEED} summer pups on ${I.name}, and ${u.name} will give your hermit crab a piece of the map.`;
  c.back=()=>{const d=c.foundAt();return [`🗺️ Gave a map piece${d?' on '+dstr(d):''}`,`🦄 ${I.name}`,`💬 ${SB.LESSON[u.id]||''}`];};return c;}
function palcard(set,n,of){const c={cid:'3:sb_pal',game:3,set,n,of,src:{id:'sbpal'},base:'sbpal',get name(){return SB.pal().name;},breed:'Hermit crab',type:'water',rar:'friend',sb:true,bisl:'reef',
  fact:'Hermit crabs live in empty seashells and move into bigger ones as they grow. When a big new shell turns up, they can line up from biggest to smallest and all swap shells!',zoom:100,moves:[['Claw Click',1,30],['Shell Swap',3,90]],col:'#e8503a',bg:'#fff0e6',stats:{spd:6,brn:8,cud:9,brv:9}};
  c.home=()=>'Pawprint Village';c.earned=()=>SB.named();c.foundAt=()=>SB.named()&&X().pal.at||0;c.art=()=>SB.crabSVG({big:!!X().done}).replace('<svg ','<svg class="pup" ');
  c.hint=()=>'Meet the little hermit crab when Summer Beach Party begins!';
  c.back=()=>[`🏖️ Named by Seb${c.foundAt()?' on '+dstr(c.foundAt()):''}`,'📍 Pawprint Village, under a bucket',`🗺️ ${SB.nMp()} of 9 map pieces`,X().done?'🐚 Got a new shell at the Great Shell Swap!':'🐚 Looking for a bigger shell'];return c;}
/* the sets, one per island and a special one */
const SETS={};
function mkSet(key){if(SETS[key])return SETS[key];let S;const lock=()=>'Summer Beach Party opens after Halloween is finished!';
  if(key==='sb'){const L=[];S={id:'3:b_sb',game:3,b:true,season:'sb',isl:'b_sb',name:'Summer Beach Party',short:'Summer',icon:'🏖️',open:()=>SB.opened(),lockSay:lock,cards:L};
    L.push(palcard(S.id,1,3),scard(SL.SPUPS.breeze,S.id,2,3,'rescue'),scard(SL.SPUPS.sorbet,S.id,3,3,'meadow'));}
  else{const I=islandOf(key),P=SB.islX(I),of=P.length+1,L=P.map((p,i)=>scard(p,'3:b_'+key,i+1,of,key));L.push(unicard(I,'3:b_'+key,of,of));
    S={id:'3:b_'+key,game:3,b:true,season:'sb',isl:'b_'+key,name:`${I.name} in summer`,short:I.name.split(' ')[0],icon:I.icon,open:()=>SB.opened(),lockSay:lock,cards:L};}
  return (SETS[key]=S);}
const SPA=['village','harbour'],strip=k=>k.slice(5).replace(/^b(?=village|harbour)/,'');
function entry(key){const I=key!=='sb'&&islandOf(key),pups=key==='sb'?[SL.SPUPS.breeze,SL.SPUPS.sorbet]:SB.islX(I),areas=key==='sb'?SPA:I.areas.map(a=>a.id).filter(a=>SB.areaX(a).some(p=>pups.indexOf(p)>=0));
  const mine=cid=>cid.indexOf('3:sb_')===0&&(cid==='3:sb_pal'?key==='sb':cid==='3:sb_'+(I&&I.boss.uni.id)||pups.some(p=>cid==='3:sb_'+p.id));
  const inSet=a=>SB.areaX(a).filter(p=>pups.indexOf(p)>=0);
  return {isl:'b_'+key,season:'sb',keys:()=>areas.map(a=>'x:sb:'+(key==='sb'?'b'+a:a)),set:()=>mkSet(key),
    ids(){if(!state)return [];const out=pups.filter(p=>SB.xFound(p.id)).map(p=>'3:sb_'+p.id);if(key==='sb'&&SB.named())out.unshift('3:sb_pal');if(I&&(X().mp||{})[I.id])out.push('3:sb_'+I.boss.uni.id);return out;},
    key(cid){if(!mine(cid))return undefined;if(cid==='3:sb_pal')return null;const id=cid.slice(5),p=SB.gpup(id);return p?'x:sb:'+(key==='sb'?'b'+p.area:p.area):null;},
    done(k){const a=strip(k);return inSet(a).every(p=>SB.xFound(p.id));},
    info(k){const a=strip(k),A=AREAS[a];return {k,isl:'b_'+key,icon:key==='sb'?'🏖️':(A&&A.icon)||'🏖️',name:`${A?A.name:'Summer'} in summer`,short:A?A.name:'Summer',sb:true};},
    say(k,c){const a=strip(k),A=AREAS[a],left=inSet(a).filter(p=>!SB.xFound(p.id)).length;return `${c.name}'s summer card is waiting in the ${A?A.name:''} beach pack. Find ${left} more summer ${left>1?'pups':'pup'} there to open it!`;}};}
window.XCARDS=(window.XCARDS||[]).concat(['sb'].concat(ISLANDS.map(I=>I.id)).map(entry));

/* ---------------- the summer look ---------------- */
const K=INK,GOLD='#ffd23f';
const shellP=(x,y,s,o,c)=>`<g opacity="${o}"><path d="M${x-6*s} ${y+4*s} Q${x-7*s} ${y-5*s} ${x} ${y-6*s} Q${x+7*s} ${y-5*s} ${x+6*s} ${y+4*s} Q${x} ${y+7*s} ${x-6*s} ${y+4*s} Z" fill="${c||'#ffd2a8'}"/><path d="M${x} ${y+5*s} V${y-4*s} M${x} ${y+5*s} L${x-4*s} ${y-3*s} M${x} ${y+5*s} L${x+4*s} ${y-3*s}" stroke="#d89a6a" stroke-width="${.8*s}" fill="none"/></g>`;
const starP=(x,y,r,o)=>{let d='';for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.5:r;d+=(i?'L':'M')+(x+Math.cos(a)*rr).toFixed(1)+' '+(y+Math.sin(a)*rr).toFixed(1);}return `<path d="${d}Z" fill="#ff8a3c" opacity="${o}"/>`;};
const PATH=`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">${shellP(15,16,1.1,.55)}${shellP(48,46,1,.5,'#ffffff')}${starP(46,15,7,.5)}${starP(16,46,6,.45)}<circle cx="32" cy="30" r="1.6" fill="#fff" opacity=".6"/></svg>`;
function beach(i){const R=seed(i.length*43+5);let s=`<rect width="200" height="190" fill="#bfe8ff" opacity=".32"/><rect y="118" width="200" height="22" fill="#2fb3d8" opacity=".3"/><path d="M0 140 q25 -6 50 0 t50 0 t50 0 t50 0 V190 H0 Z" fill="#f2d896" opacity=".55"/>`;
  s+=`<circle cx="164" cy="36" r="22" fill="#fff3a0" opacity=".35"/><circle cx="164" cy="36" r="14" fill="#ffe066"/>`;
  for(let k=0;k<3;k++){const x=(20+R()*150).toFixed(0);s+=`<path d="M${x} ${(20+R()*30).toFixed(0)} q4 -4 8 0 q4 -4 8 0" stroke="#5a6070" stroke-width="1.6" fill="none" opacity=".7"/>`;}
  for(let k=0;k<3;k++)s+=shellP(20+R()*160,158+R()*24,1,1,['#ffd2a8','#ffffff','#ffb4c8'][k%3]);
  return s;}
const EDGEB=()=>{let s=`<path d="M0 0 H400 V12 Q380 22 360 12 T320 12 T280 12 T240 12 T200 12 T160 12 T120 12 T80 12 T40 12 T0 12 Z" fill="#2fb3d8" opacity=".85"/>`;
  let k=0;for(let y=50;y<540;y+=40){[7,393].forEach(x=>{s+=`<g class="twk" style="animation-delay:${(k%5)*.35}s">${k%2?starP(x,y,6,1):shellP(x,y,.9,1,['#ffd2a8','#ffffff','#ffb4c8'][k%3])}</g>`;k++;});}
  s+=`<path d="M0 548 Q50 540 100 548 T200 548 T300 548 T400 548 V564 H0 Z" fill="#f2d896"/>`;for(let x=30;x<380;x+=40){s+=shellP(x,556,.8,1,['#ffd2a8','#ffffff','#ffb4c8'][k%3]);k++;}
  return s;};
if(window.CLOOK&&CLOOK.EDGE)CLOOK.EDGE.sb=EDGEB;
function packSVG(s){const n=s.n!=null?s.n:(s.cards||[]).length;const R=seed((s.icon||'').length*9+n);let st='';for(let k=0;k<7;k++)st+=shellP(40+R()*120,90+R()*110,.9,.5,'#ffffff');
  return `<svg viewBox="0 0 200 270" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="20" width="160" height="236" rx="16" fill="#f2d896" stroke="#5b4636" stroke-width="5"/><rect x="20" y="20" width="160" height="62" rx="16" fill="#2fb3d8"/>`+
  `<path d="M20 74 q20 -8 40 0 t40 0 t40 0 t40 0 V84 H20 Z" fill="#ffffff" opacity=".85"/>${st}`+
  `<g class="sbspade"><path d="M100 30 V64" stroke="#5b4636" stroke-width="7"/><path d="M100 30 V64" stroke="#c98a4f" stroke-width="4"/><path d="M88 64 h24 v8 q0 12 -12 14 q-12 -2 -12 -14 Z" fill="#ff6a6a" stroke="#5b4636" stroke-width="3"/></g>`+
  `<circle cx="100" cy="150" r="36" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="166" text-anchor="middle" font-size="40">${s.icon||'🏖️'}</text>`+
  `<rect x="34" y="214" width="132" height="34" rx="12" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="239" text-anchor="middle" font-size="21" font-weight="900" fill="#5b4636" font-family="Arial">${n} card${n===1?'':'s'}</text></svg>`;}
function openPack(P,pk2){SB.snd.dig();setTimeout(()=>{const b=pk2&&pk2.querySelector('.sbspade');if(b)b.classList.add('pop');SB.snd.splash();},450);}
window.SBCL={pat:()=>PATH,beach,packSVG,open:openPack,scard};
window.SEALOOK=Object.assign(window.SEALOOK||{},{'b:':{pat:()=>PATH,over:beach,edge:'sb',badge:'🐚'}});
window.SEAPACK=Object.assign(window.SEAPACK||{},{b_:{packSVG,open:openPack}});

/* the summer look for cards, the Pup House and the binder */
const SHL=(()=>{const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300">${[[40,50],[205,25],[150,150],[265,205],[70,250],[115,80],[250,110],[30,175],[185,265],[95,205]].map((q,i)=>i%3===0?starP(q[0],q[1],8,.4):shellP(q[0],q[1],1.4,.4,['#ffd2a8','#ffffff','#ffb4c8'][i%3])).join('')}</svg>`;return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';})();
const css=document.createElement('style');css.textContent=`
.mc.fin-e,.tc.fin-e{box-shadow:0 0 0 2px #fff inset}.mc.fin-e .finsh,.tc.fin-e .finsh{background:linear-gradient(115deg,rgba(255,255,255,0) 20%,rgba(255,220,240,.45) 35%,rgba(200,240,255,.45) 50%,rgba(255,250,210,.45) 65%,rgba(255,255,255,0) 80%);background-size:250% 100%;animation:sbShell 4s ease-in-out infinite alternate}
@keyframes sbShell{from{background-position:0 0}to{background-position:100% 0}}
.pq2pack .sbspade{transform-origin:100px 60px;transition:transform .5s}.pq2pack .sbspade.pop{transform:rotate(-30deg) translateY(-10px)}
#book[data-sea=sb],#binder[data-sea=sb]{isolation:isolate}
#book[data-sea=sb]{background:linear-gradient(#e6f8ff,#fff0c8)}#book[data-sea=sb] #bookH{color:#1f7aa8}
#binder[data-sea=sb]{background:#1f6a8a}#binder[data-sea=sb] .bcover{border-color:rgba(255,210,120,.6)}
#book[data-sea=sb]::before,#binder[data-sea=sb]::before{content:'';position:absolute;left:0;right:0;top:0;bottom:0;z-index:-1;background-image:${SHL};background-size:300px 300px;pointer-events:none;animation:sbDrift 22s linear infinite}
@keyframes sbDrift{from{background-position:0 0}to{background-position:300px 60px}}@media (prefers-reduced-motion:reduce){#book[data-sea=sb]::before,#binder[data-sea=sb]::before{animation:none}}
/* four seasons on the Seasons shelf make 15 binder tabs: let the tabs shrink a little so they always fit in one row */
#bdTabs{gap:4px}#bdTabs .tab{flex:0 1 auto;min-width:54px;padding:0 5px}#bdTabs .tab.sea small{font-size:12px;letter-spacing:-.3px;white-space:nowrap}
#book[data-sea=sb] .tab{opacity:1;background:#fff8e0}#book[data-sea=sb] .tab.sel{background:#ffd88a}#binder[data-sea=sb] #bdTabs .tab.sel{background:#ffd88a}`;
document.head.appendChild(css);
})();
