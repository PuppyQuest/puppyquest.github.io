/* ================================================================
   Paw Showdown (24 Nov 2026): pup trading cards, bigger number wins.
   Two players on one iPad, or Seb against Granny Paws, Sensei Mochi,
   Professor Hoot, Chief Woofles or Muddle. Rules agreed
   (claude/pup-cards-plan.md section 5): players take turns choosing;
   the chooser sees their own card, the other card shows only a clue
   (its Pup Type and where it comes from); the other player turns
   their own card over; both cards come fresh from one shared pile of
   Seb's cards each round; ties go to the Pup Pile and the next winner
   scores 1 extra for each; first to 10, 25, 50 or 100. A strength
   meter on every stat, an optional hint, an optional shadow clue, a
   Swap Bone for whoever is 5 behind, an optional head start, and the
   match saves after every step so it can carry on later.
   Save: state.cards.sd = {opp, p2:{name,col}, target, sets, opts,
   coin, first, rec:{name:[sebWins,theirWins]}, stat, match}.
   ================================================================ */
(function(){
const C=window.CARDS;if(!C)return;
const SEB='#3fae5a',P2COLS=['#3d8fe0','#ff8a3c','#9a6fe0','#e8423a'],NAMES=['Dad','Mum','Granny','Grandad'];
const SK=[['zoom','⚡','Zoomies'],['spd','💨','Speed'],['brn','💡','Brains'],['cud','💖','Cuddles'],['brv','🛡️','Bravery']];
const SKN=k=>SK.find(q=>q[0]===k);
const TARGETS=[[10,'5 min'],[25,'12 min'],[50,'25 min'],[100,'50 min']];
const val=(c,k)=>k==='zoom'?c.zoom:c.stats[k];
const H=c=>typeof c.home==='function'?c.home():(c.home||'');
const art_=w=>/^[aeiou]/i.test(w)?'an':'a';
const E=s=>C.esc(s);
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};

/* ---------- save ---------- */
function SD(){const c=C.CS();if(!c.sd)c.sd={};const s=c.sd;s.opp=s.opp||'p2';s.p2=s.p2||{name:'Dad',col:P2COLS[0]};s.target=s.target||10;s.sets=s.sets||'all';
  s.opts=Object.assign({hint:[1,0],shadow:0,bone:1,head:[0,0]},s.opts||{});s.rec=s.rec||{};s.stat=s.stat||{};if(s.first==null)s.first=0;return s;}

/* ---------- cards ---------- */
let MAP={},PCT={};
function buildMap(){MAP={};C.allSets().forEach(s=>s.cards.forEach(c=>{MAP[c.cid]=c;}));PCT={};
  const all=Object.values(MAP);SK.forEach(q=>{PCT[q[0]]=all.map(c=>val(c,q[0])).sort((a,b)=>a-b);});}
const cardOf=id=>MAP[id];
function pct(k,v){const A=PCT[k]||[];if(!A.length)return .5;let lo=0,eq=0;for(const x of A){if(x<v)lo++;else if(x===v)eq++;}return (lo+eq/2)/A.length;}
const band=(k,v)=>1+Math.min(4,Math.floor(pct(k,v)*5));
const bestStat=c=>SK.reduce((b,q)=>pct(q[0],val(c,q[0]))>pct(b,val(c,b))?q[0]:b,SK[0][0]);
function setsFor(sel){const all=C.allSets();if(sel==='pq3')return all.filter(s=>s.game===3);if(sel==='pq2')return all.filter(s=>s.game===2);
  if(Array.isArray(sel))return all.filter(s=>sel.indexOf(s.id)>=0);return all;}
function poolFor(sel){const got={};C.earnedIds().forEach(id=>{got[id]=1;});const out=[];setsFor(sel).forEach(s=>s.cards.forEach(c=>{if(got[c.cid])out.push(c.cid);}));return out;}
function clue(c){const T=C.TY(c.type);
  if(c.game===2){const L=C.LV2[c.lv],kind=c.lv===0?'Rainbow':L?L[0].replace(/ Pups$/,''):'Puppy Quest 2';
    return {T,kind:kind+' pup',from:c.lv===0?'the rainbow trail':H(c),pq2:true};}
  const I=c.src&&c.src.island&&typeof islandOf==='function'?islandOf(c.src.island):null,S=C.setById(c.set);
  return {T,kind:T.name+' pup',from:I?I.name:S&&S.id!=='3:sci'?S.name:H(c).split(', ').pop()};}
const clueSay=(who,c)=>{const q=clue(c);return `${who}'s card is ${art_(q.kind)} ${q.kind} from ${q.from}${q.pq2?', in Puppy Quest 2':''}.`;};

/* ---------- characters ---------- */
const LOOK={mochi:{id:'mochi',name:'Sensei Mochi',breed:'Shiba Inu',look:{fur:'#e8c79a',ear:'#c9a070',ears:'pointy',muzzle:'#ffffff',muzzleBig:true,belly:'#ffffff',fringe:'#ffffff',tail:'curl',eyeWhite:true,acc:['scarf'],scarfC:'#3fae5a'}},
  chief:{id:'chief',name:'Chief Woofles',breed:'Boxer',look:{fur:'#c8843a',ear:'#a8642a',ears:'floppy',muzzle:'#26232e',belly:'#ffffff',tail:'stub',hw:60,hh:56}}};
function owlSVG(){return `<svg viewBox="0 0 120 124"><g stroke="#26232e" stroke-width="4" stroke-linejoin="round"><path d="M20 22 L46 34 M100 22 L74 34" fill="none"/><ellipse cx="60" cy="74" rx="40" ry="44" fill="#9b6a43"/><ellipse cx="60" cy="86" rx="25" ry="28" fill="#e8d3b0"/>
  <circle cx="43" cy="56" r="16" fill="#fff"/><circle cx="77" cy="56" r="16" fill="#fff"/><circle cx="43" cy="57" r="7" fill="#26232e" stroke="none"/><circle cx="77" cy="57" r="7" fill="#26232e" stroke="none"/>
  <path d="M27 56 L59 56 M61 56 L93 56" fill="none" stroke-width="3"/><path d="M60 64 L53 74 L67 74 Z" fill="#ffb030"/><path d="M26 22 L60 10 L94 22 L60 34 Z" fill="#3a3338"/><path d="M94 22 L98 40" fill="none" stroke="#ffd23f"/></g></svg>`;}
const safe=f=>{try{return f();}catch(e){return '<div style="font-size:44px;line-height:56px;text-align:center">🐾</div>';}};
const CHARS=[
  {id:'granny',name:'Granny Paws',short:'Granny',she:'her',col:'#e88fb3',art:()=>safe(()=>grannySVG()),open:()=>true,smart:false,
    about:'Granny Paws picks any number. A gentle game!',win:'Ooh, lucky me!',lose:'Well done, dear!'},
  {id:'mochi',name:'Sensei Mochi',short:'Mochi',she:'his',col:'#c9a070',art:()=>safe(()=>critterSVG(LOOK.mochi)),open:()=>islOpen('ninja'),smart:true,
    about:'Sensei Mochi always picks his best number.',win:'A true ninja is patient.',lose:'Well played, young ninja!'},
  {id:'hoot',name:'Professor Hoot',short:'Hoot',she:'his',col:'#9b6a43',art:owlSVG,open:()=>islOpen('number'),smart:true,
    about:'Professor Hoot always picks his best number.',win:'Hoo hoo! The numbers like me today.',lose:'Hoo! A clever pick, Seb!'},
  {id:'chief',name:'Chief Woofles',short:'Chief',she:'his',col:'#e8423a',art:()=>safe(()=>critterSVG(LOOK.chief)),open:()=>islOpen('rescue'),smart:true,
    about:'Chief Woofles always picks his best number.',win:'Woof! Ready for anything!',lose:'Great teamwork, Seb!'},
  {id:'muddle',name:'Muddle the Magpie',short:'Muddle',she:'his',col:'#5b6378',art:()=>safe(()=>magpieSVG()),open:()=>true,smart:true,
    about:'Muddle always picks his best number. Cheeky!',win:'Ha ha! Shiny!',lose:'Oh, bother my feathers!'}];
const CH=id=>CHARS.find(c=>c.id===id);
const isHuman=(m,i)=>i===0||m.opp==='p2';
const nm=(m,i)=>i===0?'Seb':m.opp==='p2'?m.p2.name:CH(m.opp).short;
const colOf=(m,i)=>i===0?SEB:m.opp==='p2'?m.p2.col:CH(m.opp).col;
function avatar(m,i){if(i===0)return `<div class="fitsvg">${safe(()=>sebSVG())}</div>`;
  if(m.opp!=='p2')return `<div class="fitsvg">${CH(m.opp).art()}</div>`;return `<div class="sdIni" style="background:${m.p2.col}">${E((m.p2.name||'?')[0].toUpperCase())}</div>`;}

/* ---------- screen ---------- */
let M=null,from='binder',busy=0,timers=[];
const later=(f,ms)=>{const t=setTimeout(()=>{timers=timers.filter(x=>x!==t);f();},ms);timers.push(t);return t;};
const clearLater=()=>{timers.forEach(clearTimeout);timers=[];};
function build(){if($('#showdown'))return;const S=el('div','screen','');S.id='showdown';
  S.innerHTML=`<button class="btn rnd white" id="sdBack" style="left:14px;top:10px">◀</button><h2 id="sdH">🏆 Paw Showdown</h2><div class="pill" id="sdTgt"></div><div id="sdBody"></div><div id="sdPanel"></div>`;
  $('#stage').insertBefore(S,$('#bubble'));tap('#sdBack',back);}
function open(src){build();from=src||from;clearLater();busy=0;closeOv('menu');
  const go=()=>{buildMap();show('showdown');const sd=SD();if(sd.match&&restore(sd.match))resumeView();else setupView(true);};
  if(C.CS().pq2&&!window.PQ2ART)C.loadArt(go,true);else go();}
function leave(){clearLater();hush();if(from==='binder'){C.openBinder();return;}if(W.area){show('world');if(typeof syncFollowers==='function')syncFollowers(true);hud();player.lock=false;}else showTitle();}
function back(){sfx.boop();if(M&&!M.over&&$('#showdown').classList.contains('game')){card({art:'<div style="font-size:90px;line-height:1">🏆</div>',h:'Stop for now?',
    p:`Your game is saved: ${nm(M,0)} ${M.sc[0]}, ${nm(M,1)} ${M.sc[1]}. You can carry on later.`,btns:[['▶ Keep playing','green'],['Stop for now','white',leave]]});return;}leave();}

/* ---------- setup ---------- */
function resumeView(){const m=M,S=$('#showdown');S.classList.remove('game');$('#sdTgt').style.display='none';$('#sdH').textContent='🏆 Paw Showdown';
  $('#sdBody').innerHTML=`<div class="sdResume"><div class="sdRA">${avatar(m,0)}<b>${m.sc[0]}</b></div><div class="sdRm"><h3>Your game is saved!</h3><p>${E(nm(m,0))} ${m.sc[0]}, ${E(nm(m,1))} ${m.sc[1]}<br><small>First to ${m.target}</small></p>
    <button class="btn green" id="sdCarry">▶ Carry on</button><button class="btn white" id="sdNew">New game</button></div><div class="sdRA">${avatar(m,1)}<b>${m.sc[1]}</b></div></div>`;
  tap('#sdCarry',()=>{sfx.pop();gameView(true);});tap('#sdNew',()=>{sfx.boop();M=null;SD().match=null;save();setupView(false);});
  say(`Your game is saved. ${nm(m,0)} ${m.sc[0]}, ${nm(m,1)} ${m.sc[1]}. Carry on?`);}
function chip(label,sel,data,cls){return `<button class="sdChip${sel?' sel':''}${cls?' '+cls:''}" ${data}>${label}</button>`;}
function setupView(first){const sd=SD(),S=$('#showdown');S.classList.remove('game');$('#sdTgt').style.display='none';$('#sdH').textContent='🏆 Paw Showdown';
  const two=sd.opp==='p2',P2=two?sd.p2.name:CH(sd.opp).short,pool=poolFor(sd.sets),cnt=sel=>poolFor(sel).length,pq2=!!C.CS().pq2;
  const rec=sd.rec[two?sd.p2.name:CH(sd.opp).name],next=sd.first?P2:'Seb';
  const opp=[chip('<span class="big">👫</span>Two players',two,'data-opp="p2"')].concat(CHARS.filter(c=>c.open()).map(c=>chip(`<span class="av">${c.art()}</span>${c.short}`,sd.opp===c.id,`data-opp="${c.id}"`))).join('');
  const p2row=two?NAMES.map(n=>chip(n,sd.p2.name===n,`data-nm="${n}"`)).join('')+`<input id="sdName" maxlength="12" placeholder="✏️ Name" autocomplete="off" autocorrect="off" spellcheck="false" value="${NAMES.indexOf(sd.p2.name)<0?E(sd.p2.name):''}">`+
      `<span class="sdCols">${P2COLS.map(c=>`<button class="sdDot${sd.p2.col===c?' sel':''}" data-col="${c}" style="background:${c}"></button>`).join('')}</span>`
    :`<span class="sdAbout">${E(CH(sd.opp).about)}</span>`;
  const sets=[['all','All my cards'],['pq3','Puppy Quest 3']].concat(pq2?[['pq2','Puppy Quest 2']]:[]).map(q=>chip(`${q[1]} <small>${cnt(q[0])}</small>`,sd.sets===q[0],`data-sets="${q[0]}"`)).join('')+
    chip(Array.isArray(sd.sets)?`Chosen sets <small>${pool.length}</small>`:'Pick sets…',Array.isArray(sd.sets),'data-pick="1"');
  $('#sdBody').innerHTML=`<div class="sdSetup">
    <div class="sdRow"><label>Play with</label><div>${opp}</div></div>
    <div class="sdRow"><label>${two?'Player 2':'About'}</label><div>${p2row}</div></div>
    <div class="sdRow"><label>First to</label><div>${TARGETS.map(t=>chip(`${t[0]}<small>about ${t[1]}</small>`,sd.target===t[0],`data-tg="${t[0]}"`,'tg')).join('')}</div></div>
    <div class="sdRow"><label>Cards</label><div>${sets}</div></div>
    <div class="sdRow"><label>Who starts</label><div>${chip(`Take turns <small>${E(next)} next</small>`,!sd.coin,'data-coin="0"')}${chip('🪙 Paw coin <small>toss for it</small>',!!sd.coin,'data-coin="1"')}</div></div>
    <div class="sdFoot"><span class="sdRec">${chip('⚙️ More','',`data-more="1"`)} ${rec?`🏆 Seb ${rec[0]} ${rec[0]===1?'game':'games'}, ${E(P2)} ${rec[1]}`:''}</span><button class="btn green" id="sdStart">▶ Start!</button></div></div>`;
  const B=$('#sdBody');
  B.querySelectorAll('[data-opp]').forEach(b=>tap(b,()=>{sfx.pop();sd.opp=b.dataset.opp;save();setupView();if(sd.opp!=='p2')say(CH(sd.opp).about);}));
  B.querySelectorAll('[data-nm]').forEach(b=>tap(b,()=>{sfx.pop();sd.p2.name=b.dataset.nm;save();setupView();}));
  const inp=$('#sdName');if(inp){inp.addEventListener('input',()=>{const v=inp.value.replace(/[<>]/g,'').trim();if(v){sd.p2.name=v;save();B.querySelectorAll('[data-nm]').forEach(b=>b.classList.remove('sel'));}});
    inp.addEventListener('change',()=>setupView());}
  B.querySelectorAll('[data-col]').forEach(b=>tap(b,()=>{sfx.pop();sd.p2.col=b.dataset.col;save();setupView();}));
  B.querySelectorAll('[data-tg]').forEach(b=>tap(b,()=>{sfx.pop();sd.target=+b.dataset.tg;save();setupView();}));
  B.querySelectorAll('[data-sets]').forEach(b=>tap(b,()=>{sfx.pop();sd.sets=b.dataset.sets;save();setupView();}));
  B.querySelectorAll('[data-coin]').forEach(b=>tap(b,()=>{sfx.pop();sd.coin=b.dataset.coin==='1';save();setupView();}));
  tap(B.querySelector('[data-pick]'),()=>{sfx.pop();pickSets();});tap(B.querySelector('[data-more]'),()=>{sfx.pop();morePanel();});
  tap('#sdStart',()=>{const n=poolFor(sd.sets).length;if(n<10){sfx.oops();say(`You need 10 cards to play Showdown, and these sets have ${n}. Find more pups, or pick more sets!`);return;}sfx.pop();startMatch();});
  if(first)say(C.earnedIds().length<10?'Paw Showdown needs 10 cards. Find more pups to fill your binder, then come back!':'Paw Showdown! Pick your best number, and the biggest number wins the card. Who are you playing with?');}
function panel(html,done){const P=$('#sdPanel');P.innerHTML=`<div class="sdPan">${html}<button class="btn green sdDone">✓ Done</button></div>`;P.classList.add('on');
  tap(P.querySelector('.sdDone'),()=>{sfx.boop();P.classList.remove('on');if(done)done();});return P;}
function pickSets(){const sd=SD(),chosen=Array.isArray(sd.sets)?sd.sets.slice():[],got={};C.earnedIds().forEach(id=>{got[id]=1;});
  const L0=C.allSets().map(s=>({s,n:s.cards.filter(c=>got[c.cid]).length})).filter(q=>q.n>0),XL=L0.filter(q=>q.s.season),XI=XL.map(q=>q.s.id),SK=[...new Set(XL.map(q=>q.s.season))],SI=k=>XL.filter(q=>q.s.season===k).map(q=>q.s.id),L=L0.filter(q=>!q.s.season).concat(SK.map(k=>{const S=(window.SEASONS||{})[k],cd=S&&S.card||['✨',k];return {s:{id:'*'+k,icon:cd[0],short:cd[1]},n:XL.filter(q=>q.s.season===k).reduce((a,q)=>a+q.n,0)};})),sel=id=>id[0]==='*'?SI(id.slice(1)).every(x=>chosen.indexOf(x)>=0):chosen.indexOf(id)>=0;
  const P=panel(`<h3>Pick the sets to play with</h3><div class="sdSets">${L.map(q=>chip(`<span>${q.s.icon}</span>${E(q.s.short||q.s.name)} <small>${q.n}</small>`,sel(q.s.id),`data-set="${q.s.id}"`)).join('')}</div>`,
    ()=>{sd.sets=chosen.length?chosen:'all';save();setupView();});
  P.querySelectorAll('[data-set]').forEach(b=>tap(b,()=>{sfx.pop();const id=b.dataset.set;if(id[0]==='*'){const on=sel(id);SI(id.slice(1)).forEach(x=>{const i=chosen.indexOf(x);if(on&&i>=0)chosen.splice(i,1);if(!on&&i<0)chosen.push(x);});b.classList.toggle('sel',!on);return;}const i=chosen.indexOf(id);if(i<0)chosen.push(id);else chosen.splice(i,1);b.classList.toggle('sel',i<0);}));}
function morePanel(){const sd=SD(),o=sd.opts,two=sd.opp==='p2',P2=two?sd.p2.name:CH(sd.opp).short;
  const row=(lab,key,opts,cur)=>`<div class="sdOpt"><label>${lab}</label>${opts.map(q=>chip(q[1],cur===q[0],`data-k="${key}" data-v="${q[0]}"`)).join('')}</div>`,OF=[[1,'On'],[0,'Off']];
  const draw=()=>{const P=panel(`<h3>⚙️ More</h3>`+row('⭐ Hint for Seb','hint0',OF,o.hint[0]?1:0)+(two?row(`⭐ Hint for ${E(P2)}`,'hint1',OF,o.hint[1]?1:0):'')+
      row('👤 Shadow clue','shadow',OF,o.shadow?1:0)+row('🦴 Swap Bone','bone',OF,o.bone?1:0)+row('🏁 Head start for Seb','head0',[[0,'0'],[2,'2'],[5,'5']],o.head[0])+
      row(`🏁 Head start for ${E(P2)}`,'head1',[[0,'0'],[2,'2'],[5,'5']],o.head[1])+
      `<p class="sdNote">The hint makes the best number glow. The shadow clue shows the hidden pup's shadow. Whoever is 5 behind gets a Swap Bone to swap their card once.</p>`,()=>setupView());
    P.querySelectorAll('[data-k]').forEach(b=>tap(b,()=>{sfx.pop();const k=b.dataset.k,v=+b.dataset.v;
      if(k==='hint0')o.hint[0]=v;else if(k==='hint1')o.hint[1]=v;else if(k==='shadow')o.shadow=v;else if(k==='bone')o.bone=v;else if(k==='head0')o.head[0]=v;else if(k==='head1')o.head[1]=v;save();draw();}));};
  draw();}

/* ---------- a match ---------- */
function startMatch(){const sd=SD();if(poolFor(sd.sets).length<2){setupView();return;}let first=sd.first;const coin=!!sd.coin;if(coin)first=Math.random()<.5?0:1;
  M={v:1,opp:sd.opp,p2:{name:sd.p2.name,col:sd.p2.col},target:sd.target,sets:sd.sets,opts:JSON.parse(JSON.stringify(sd.opts)),
    sc:[sd.opts.head[0]||0,sd.opts.head[1]||0],ties:0,pile:[],won:[[],[]],turn:first,first,bones:[0,0],round:0,top:null,deck:[],cards:null,phase:'pick',stat:null,res:null,over:false};
  if(M.opp!=='p2')M.opts.hint[1]=0;
  M.pool=poolFor(M.sets);deal();sd.match=M;persist();
  gameView(false,coin?`The paw coin says ${nm(M,first)} goes first!`:null);}
function restore(m){if(!m||m.v!==1||!m.cards)return false;if(m.opp!=='p2'&&!CH(m.opp))return false;m.pool=poolFor(m.sets);
  if(m.cards.some(id=>!cardOf(id))||m.pool.length<2)return false;m.deck=(m.deck||[]).filter(id=>cardOf(id));M=m;return true;}
function persist(){const sd=SD();if(!M){sd.match=null;save();return;}const keep=M.pool;delete M.pool;sd.match=JSON.parse(JSON.stringify(M));M.pool=keep;save();}
function draw(not){const m=M;let tries=0;while(tries++<4){if(!m.deck.length)m.deck=shuffle(m.pool.filter(id=>(m.cards||[]).indexOf(id)<0&&id!==not));const id=m.deck.pop();if(id&&id!==not)return id;}
  const L=m.pool.filter(id=>id!==not);return L[Math.floor(Math.random()*L.length)];}
function deal(){const a=draw(null);M.cards=[a,null];M.cards[1]=draw(a);}

/* ---------- drawing the table ---------- */
const meter=(k,v)=>{const b=band(k,v);return Array.from({length:5},(_,j)=>`<i class="${j<b?'on b'+b:''}"></i>`).join('');};
function statList(m,i,mode){const c=cardOf(m.cards[i]),hint=mode==='pick'&&m.opts.hint[i]&&isHuman(m,i)?bestStat(c):null;
  return SK.map(q=>{const k=q[0],v=val(c,k);let cls='sdSt';if(m.stat===k)cls+=' sel';if(hint===k)cls+=' hint';
    if(m.phase==='result'&&m.stat===k&&m.res){cls+=m.res.w<0?' tie':m.res.w===i?' win':' lose';}
    return `<button class="${cls}" data-st="${k}"><span class="i">${q[1]}</span><span class="n">${q[2]}<small>${meter(k,v)}</small></span><span class="v">${v}</span></button>`;}).join('');}
function cluePanel(m,i){const c=cardOf(m.cards[i]),q=clue(c),who=nm(m,i),rev=m.phase==='reveal';
  const tapLine=rev?(isHuman(m,i)?`<div class="sdTapNow">👆 ${E(who)}, tap your card to turn it over!</div>`:`<div class="sdTapNow">${E(who)} is turning ${CH(m.opp).she} card over…</div>`):'';
  return `<div class="sdClueP"><div class="ty" style="background:${q.T.col}">${q.T.icon}</div><p>${E(who)}'s card</p><b>${art_(q.kind)} ${E(q.kind)}</b><p>from <b>${E(q.from)}</b></p>${q.pq2?'<small>Puppy Quest 2</small>':''}${tapLine}</div>`;}
function clueFace(m,i){const c=cardOf(m.cards[i]),q=clue(c);
  return `<div class="sdBackF" style="background:${q.T.col}"><div class="lg">🐾 <b>Puppy Quest</b></div><div class="qq">${m.opts.shadow?`<div class="sh">${c.art(false)}</div>`:''}<span>?</span></div>
    <div class="tyB">${q.T.icon}</div><div class="cl">${art_(q.kind)} <b>${E(q.kind)}</b><br>from <b>${E(q.from)}</b></div></div>`;}
function cardHTML(m,i,hidden){const c=cardOf(m.cards[i]),w=document.createElement('div');w.innerHTML=C.bigHTML(c);const tc=w.firstElementChild;
  const bk=tc.querySelector('.face.back');if(bk){bk.innerHTML=clueFace(m,i);bk.removeAttribute('style');}/* 26 Nov: card backs wear their frame; a clue card stays plain */if(hidden)tc.classList.add('flip');
  if(m.phase==='result'&&m.stat){const k=m.stat;const t=k==='zoom'?tc.querySelector('.zm'):tc.querySelectorAll('.st span')[C.STATS.findIndex(s=>s[0]===k)];if(t)t.classList.add('sdHi');}
  return tc.outerHTML;}
function minis(ids){return ids.slice(-3).map((id,j)=>{const c=cardOf(id);return c?`<div class="sdMini" style="--j:${j}">${C.miniHTML(c,{force:true})}</div>`:'';}).join('');}
function track(m,i){const s=Math.min(m.sc[i],m.target),col=colOf(m,i);
  if(m.target<=10)return `<div class="sdTrack">${Array.from({length:m.target},(_,j)=>`<i style="${j<s?`background:${col}`:''}">${j<s?'🐾':''}</i>`).join('')}</div>`;
  return `<div class="sdBar"><i style="width:${100*s/m.target}%;background:${col}"></i><span>${m.sc[i]} / ${m.target}</span></div>`;}
function gameView(resumed,lead){const m=M,S=$('#showdown');S.classList.add('game');$('#sdPanel').classList.remove('on');$('#sdH').textContent='🏆 Showdown';
  const t=$('#sdTgt');t.style.display='';t.textContent=`First to ${m.target}`;
  $('#sdBody').innerHTML=[0,1].map(i=>`<div class="sdPlate p${i}" style="--pc:${colOf(m,i)}"><div class="av">${avatar(m,i)}</div><div class="nm">${E(nm(m,i))}<em></em></div><div class="sc">${m.sc[i]}</div>${track(m,i)}</div>
    <div class="sdSlot p${i}"><div class="sdScale"></div></div><div class="sdCol p${i}"></div><div class="sdWon p${i}"><div class="pl"></div><div class="lbl">Cards won</div><div class="bn"></div></div>`).join('')+
    `<div class="sdPile"><div class="pl"></div><div class="lbl">Pup Pile</div></div><button class="btn green" id="sdNext">Next ▶</button>`;
  [0,1].forEach(i=>tap($('#showdown .sdSlot.p'+i),()=>slotTap(i)));tap('#sdNext',next);
  draw2();if(m.phase==='pick')announce(resumed?`Welcome back! ${nm(m,0)} ${m.sc[0]}, ${nm(m,1)} ${m.sc[1]}.`:lead);
  else if(m.phase==='reveal'){const o=1-m.turn;if(isHuman(m,o))say(`${SKN(m.stat)[2]}! ${nm(m,o)}, tap your card to turn it over!`);else later(reveal,1300);}
  else if(m.phase==='result')say(m.over?'The game is over! Tap Finish.':'Tap Next for the next cards.');}
function draw2(){const m=M,S=$('#showdown');if(!S)return;
  [0,1].forEach(i=>{const hidden=m.phase!=='result'&&i!==m.turn,P=S.querySelector('.sdPlate.p'+i);
    P.classList.toggle('turn',m.phase!=='result'&&i===m.turn&&!m.over);P.querySelector('.nm em').textContent=m.phase==='pick'&&i===m.turn&&!m.over?(isHuman(m,i)?'Your turn!':'Thinking…'):m.phase==='reveal'&&i===m.turn?'Picked!':'';
    P.querySelector('.sc').textContent=m.sc[i];P.querySelector('.sdTrack,.sdBar').outerHTML=track(m,i);
    const sl=S.querySelector('.sdSlot.p'+i);sl.querySelector('.sdScale').innerHTML=cardHTML(m,i,hidden);sl.classList.toggle('tapme',m.phase==='reveal'&&i!==m.turn&&isHuman(m,i));
    const col=S.querySelector('.sdCol.p'+i);
    if(m.phase==='result')col.innerHTML=`<div class="sdList">${statList(m,i,'result')}</div>`;
    else if(i===m.turn){const go=isHuman(m,i)&&m.phase==='pick';col.innerHTML=`<div class="sdList${go?'':' off'}">${statList(m,i,m.phase)}</div>`+(go?`<button class="btn sdGo${m.stat?'':' off'}">Go! ▶</button>`:'');
      if(go){col.querySelectorAll('[data-st]').forEach(b=>tap(b,()=>pick(b.dataset.st)));tap(col.querySelector('.sdGo'),goBtn);}}
    else col.innerHTML=cluePanel(m,i);
    const W2=S.querySelector('.sdWon.p'+i);W2.querySelector('.pl').innerHTML=minis(m.won[i]);
    const bn=W2.querySelector('.bn');bn.innerHTML=m.bones[i]?`<button class="sdBone${m.phase==='pick'&&m.turn===i&&isHuman(m,i)?' can':''}">🦴<small>Swap</small></button>`:'';
    const bb=bn.querySelector('.sdBone');if(bb)tap(bb,()=>useBone(i));});
  S.querySelector('.sdPile .pl').innerHTML=minis(m.pile)+(m.ties?`<b class="sdPlus">+${m.ties}</b>`:'');S.querySelector('.sdPile').classList.toggle('has',m.ties>0);
  const nx=$('#sdNext');nx.style.display=m.phase==='result'?'':'none';nx.textContent=m.over?'🏆 Finish':'Next ▶';}

/* ---------- a round ---------- */
function announce(lead){const m=M,i=m.turn,o=1-i;
  if(isHuman(m,i))say(`${lead?lead+' ':''}${nm(m,i)}'s turn! ${clueSay(nm(m,o),cardOf(m.cards[o]))} Pick your best number.`);
  else{say(`${lead?lead+' ':''}${nm(m,i)}'s turn! ${nm(m,i)} is thinking…`);later(charPick,1900);}}
function pick(k){const m=M;if(m.phase!=='pick'||!isHuman(m,m.turn))return;sfx.pop();m.stat=k;persist();draw2();const q=SKN(k),v=val(cardOf(m.cards[m.turn]),k);speak(`${q[2]}, ${v}.`);}
function goBtn(){const m=M;if(m.phase!=='pick')return;if(!m.stat){sfx.oops();say('Tap a number first, then tap Go!');return;}sfx.chime();m.phase='reveal';persist();draw2();
  const o=1-m.turn;if(isHuman(m,o))say(`${SKN(m.stat)[2]}! ${nm(m,o)}, tap your card to turn it over!`);else{say(`${SKN(m.stat)[2]}! ${nm(m,o)} turns ${CH(m.opp).she} card over…`);later(reveal,1500);}}
function charPick(){const m=M;if(!m||m.phase!=='pick'||isHuman(m,m.turn)||cur!=='showdown')return;const ch=CH(m.opp),c=cardOf(m.cards[m.turn]);
  m.stat=ch.smart?bestStat(c):SK[Math.floor(Math.random()*SK.length)][0];m.phase='reveal';persist();sfx.chime();draw2();
  say(`${ch.short} picks ${SKN(m.stat)[2]}, ${val(c,m.stat)}! Seb, tap your card to turn it over!`);}
function slotTap(i){const m=M;if(!m||busy)return;
  if(m.phase==='reveal'&&i!==m.turn){if(!isHuman(m,i))return;reveal();return;}
  if(m.phase==='pick'&&i!==m.turn){sfx.oops();say(isHuman(m,m.turn)?`Wait for ${nm(m,m.turn)} to pick a number first!`:`Wait for ${nm(m,m.turn)} to pick!`);}}
function useBone(i){const m=M;if(m.phase!=='pick'||m.turn!==i||!m.bones[i]||!isHuman(m,i))return;sfx.giggle();m.bones[i]=0;
  m.cards[i]=draw(m.cards[1-i]);m.stat=null;persist();draw2();const sl=$('#showdown .sdSlot.p'+i);sl.classList.remove('swap');void sl.offsetWidth;sl.classList.add('swap');
  say(`Swap! ${nm(m,i)} has a new card. Pick your best number.`);}
function reveal(){const m=M;if(!m||m.phase!=='reveal'||busy)return;busy=1;const i=m.turn,o=1-i,k=m.stat;
  const tc=$(`#showdown .sdSlot.p${o} .tc`);sfx.pop();if(tc){tc.classList.add('half');setTimeout(()=>{tc.classList.remove('flip');void tc.offsetWidth;tc.classList.remove('half');},300);}
  const a=val(cardOf(m.cards[0]),k),b=val(cardOf(m.cards[1]),k),w=a>b?0:b>a?1:-1;let gain=0,newBone=-1;
  if(w<0){m.ties++;m.pile=m.pile.concat(m.cards).slice(-6);}
  else{gain=1+m.ties;m.sc[w]+=gain;m.won[w]=m.won[w].concat([m.cards[1-w]]).slice(-5);{const wv=w===0?a:b,wp=pct(k,wv);if(!m.top||wp>m.top.p)m.top={id:m.cards[w],k,v:wv,p:wp,who:w};}m.ties=0;m.pile=[];
    if(m.opts.bone)[0,1].forEach(p=>{if(!m.bones[p]&&m.sc[1-p]-m.sc[p]>=5){m.bones[p]=1;newBone=p;}});}
  m.over=w>=0&&m.sc[w]>=m.target;m.res={w,a,b,gain,k,newBone};m.phase='result';m.round++;persist();
  setTimeout(()=>{busy=0;if(!M||M!==m)return;draw2();result();},700);}
function result(){const m=M,r=m.res,q=SKN(r.k),n0=nm(m,0),n1=nm(m,1);let t=`${q[2]}: ${n0} ${r.a}, ${n1} ${r.b}. `;
  if(r.w<0){sfx.boop();t+=`A tie! Both cards go on the Pup Pile. The next winner gets ${m.ties} extra!`;fly(-1);}
  else{const hi=Math.max(r.a,r.b),lo=Math.min(r.a,r.b),wn=nm(m,r.w);t+=`${hi} is ${hi-lo} more than ${lo}. `;
    t+=r.gain>1?`${wn} wins ${r.gain} cards, with the Pup Pile! `:`${wn} wins the card! `;
    if(!m.over){t+=`${n0} ${m.sc[0]}, ${n1} ${m.sc[1]}.`;const lead=m.sc[0]===m.sc[1]?-1:m.sc[0]>m.sc[1]?0:1;if(lead>=0&&m.target-m.sc[lead]<=3)t+=` ${nm(m,lead)} needs ${m.target-m.sc[lead]} more!`;}
    if(r.w===0||m.opp==='p2'){sfx.jingle();confetti(m.over?80:16);}else sfx.yip(1.2);
    if(m.opp!=='p2'&&!m.over&&Math.random()<.35){const ch=CH(m.opp);t+=` ${ch.short}: "${r.w===1?ch.win:ch.lose}"`;}
    const sl=$(`#showdown .sdSlot.p${r.w}`);if(sl){sl.classList.remove('hop');void sl.offsetWidth;sl.classList.add('hop');}fly(r.w);}
  if(r.newBone>=0)t+=` ${nm(m,r.newBone)} gets a Swap Bone!`;
  if(m.over)t+=` ${nm(m,r.w)} reaches ${m.target}!`;say(t);}
function fly(w){const m=M,S=$('#showdown');if(!S)return;
  const go=(i,dx,dy)=>{const c=cardOf(m.cards[i]);if(!c)return;const f=el('div','sdFly',C.miniHTML(c,{force:true}));const p=i===0?[60,240]:[798,240];f.style.left=p[0]+'px';f.style.top=p[1]+'px';S.appendChild(f);
    setTimeout(()=>{f.style.transform=`translate(${dx-p[0]}px,${dy-p[1]}px) scale(.5) rotate(${i?8:-8}deg)`;f.style.opacity='.2';},60);setTimeout(()=>f.remove(),900);};
  if(w<0){go(0,450,560);go(1,470,560);}else go(1-w,w===0?40:740,560);}
function next(){const m=M;if(!m||m.phase!=='result'||busy)return;sfx.boop();if(m.over){finish();return;}
  m.turn=1-m.turn;m.stat=null;m.res=null;m.phase='pick';deal();persist();draw2();
  const sl=$(`#showdown .sdSlot.p${m.turn}`);if(sl){sl.classList.remove('deal');void sl.offsetWidth;sl.classList.add('deal');}announce();}
function finish(){const m=M,sd=SD(),w=m.sc[0]>=m.target?0:1,P2=m.opp==='p2'?m.p2.name:CH(m.opp).name,n1=nm(m,1);
  state.stars+=m.target;sd.rec[P2]=sd.rec[P2]||[0,0];sd.rec[P2][w]++;const rec=sd.rec[P2];
  if(m.opp==='p2'){sd.stat.pals=(sd.stat.pals||0)+1;if(w===0)sd.stat.champ=(sd.stat.champ||0)+1;}else{sd.stat.cpu=(sd.stat.cpu||0)+1;if(w===0)sd.stat.cpuWin=(sd.stat.cpuWin||0)+1;}
  if(m.target>=100)sd.stat.marathon=(sd.stat.marathon||0)+1;sd.stat.games=(sd.stat.games||0)+1;
  if(!sd.coin)sd.first=1-m.first;sd.match=null;const done=M;M=null;save();
  const T=done.top,bc=T&&cardOf(T.id);
  confetti(90);sfx.fanfare();
  const head=w===0?'Seb is the Showdown Champion!':`${n1} wins this time!`,well=w===0?(done.opp==='p2'?`Well played, ${n1}!`:`${CH(done.opp).short}: "${CH(done.opp).lose}"`):'Well played, Seb!';
  card({cls:'sdEnd',art:`<div class="sdEndA"><div class="av">${avatar(done,w)}</div>${bc?`<div class="bp">${C.miniHTML(bc,{force:true})}<small>⭐ Star pup</small></div>`:''}</div>`,h:head,
    p:`${nm(done,0)} ${done.sc[0]}, ${n1} ${done.sc[1]}. ${well}${bc?`<br>Star pup of the match: <b>${E(bc.name)}</b>, who won for ${E(nm(done,T.who))} with ${SKN(T.k)[2]} ${T.v}!`:''}<br>+${done.target} ⭐ for playing! Seb ${rec[0]} ${rec[0]===1?'game':'games'}, ${E(m.opp==='p2'?P2:CH(m.opp).short)} ${rec[1]}.`,
    btns:[['▶ Play again','green',()=>startMatch()],['Done','white',()=>setupView()]]});}

/* ---------- ways in ---------- */
function addBinderBtn(){const B=$('#binder');if(!B||$('#bdSD'))return !!B;const b=el('button','bdMark','<span class="i">🏆</span><small>Show-<br>down</small>');b.id='bdSD';B.appendChild(b);tap(b,()=>{sfx.pop();open('binder');});return true;}
{const t=setInterval(()=>{if(addBinderBtn())clearInterval(t);},400);}
if(typeof openGames==='function'){const _og=openGames;openGames=function(tab){_og.apply(this,arguments);try{if(arcTab!=='games')return;const g=$('#menuCard .gcols');if(!g||g.querySelector('[data-g="showdown"]'))return;
    const sd=SD(),r=sd.stat.games?`${sd.stat.games} played`:'New!';const b=el('button','grow',`<span class="gi">🏆</span><span class="gn">Paw Showdown</span><span class="gb">${r}</span>`);b.dataset.g='showdown';g.appendChild(b);}catch(e){}};}
if(typeof startGame==='function'){const _sg=startGame;startGame=function(k){if(k==='showdown'){open('arcade');return;}return _sg.apply(this,arguments);};}
setInterval(()=>{if(cur==='showdown'&&state&&!sleepOn&&!ovOpen())playClock(1);},1000);
MERITS.push(
  {id:'sdpals',icon:'🤝',name:'Showdown Pals',how:'Finish a game of Paw Showdown with a friend on the same iPad.',ok:()=>!!(state.cards&&state.cards.sd&&state.cards.sd.stat&&state.cards.sd.stat.pals)},
  {id:'sdchamp',icon:'🏆',name:'Showdown Champ',how:'Win a two-player game of Paw Showdown.',ok:()=>!!(state.cards&&state.cards.sd&&state.cards.sd.stat&&state.cards.sd.stat.champ)},
  {id:'sdmarathon',icon:'🏃',name:'Marathon Paws',how:'Finish a game of Paw Showdown played to 100.',ok:()=>!!(state.cards&&state.cards.sd&&state.cards.sd.stat&&state.cards.sd.stat.marathon)});

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
#showdown{background:radial-gradient(circle at 50% 42%,#4b8fd0,#24507e 75%);color:#5b4636}
#showdown.on~#bubble{left:104px;width:690px}
#sdH{position:absolute;left:104px;top:22px;margin:0;font-size:34px;color:#fff;white-space:nowrap;text-shadow:3px 3px 0 #5b4636,-2px 2px 0 #5b4636,2px -2px 0 #5b4636,-2px -2px 0 #5b4636}
#sdTgt{right:14px;top:18px}
#bdSD{top:184px;background:#ffd86b}
.sdChip{display:inline-flex;flex-direction:column;align-items:center;justify-content:center;min-width:92px;height:66px;margin:0 8px 0 0;padding:0 14px;border:4px solid #5b4636;border-radius:20px;background:#fff;font:inherit;font-size:22px;font-weight:900;color:#5b4636;vertical-align:middle;line-height:1.05}
.sdChip small{font-size:14px;font-weight:800;opacity:.8}.sdChip.sel{background:#ffd86b;box-shadow:0 0 0 4px #fff}
.sdChip .av{width:44px;height:40px;display:block}.sdChip .av .fitsvg,.sdChip .av svg{width:44px;height:40px}.sdChip .big{font-size:28px;line-height:1}
.sdChip.tg{min-width:118px}
.sdSetup{position:absolute;left:24px;right:24px;top:140px}
.sdRow{display:flex;align-items:center;min-height:78px;margin-bottom:10px}
.sdRow>label{width:150px;flex:none;font-size:24px;font-weight:900;color:#fff;text-shadow:2px 2px 0 #5b4636}
.sdRow>div{flex:1;display:flex;align-items:center;flex-wrap:nowrap}
#sdName{width:130px;height:58px;border:4px solid #5b4636;border-radius:18px;font:inherit;font-size:22px;font-weight:900;padding:0 10px;color:#5b4636;margin-right:12px}
.sdCols{display:inline-flex;gap:8px}.sdDot{width:46px;height:46px;border-radius:50%;border:4px solid #5b4636}.sdDot.sel{box-shadow:0 0 0 4px #fff,0 0 0 8px #5b4636}
.sdAbout{font-size:24px;font-weight:900;color:#fff;text-shadow:2px 2px 0 #5b4636}
.sdFoot{display:flex;align-items:center;justify-content:space-between;margin-top:8px}
.sdRec{font-size:24px;font-weight:900;color:#fff;text-shadow:2px 2px 0 #5b4636}
#sdStart{min-width:260px;height:92px;font-size:38px}
#sdPanel{position:absolute;inset:0;background:rgba(20,30,60,.55);display:none;z-index:30}#sdPanel.on{display:block}
.sdPan{position:absolute;left:70px;right:70px;top:120px;bottom:40px;background:#fffaf0;border:5px solid #5b4636;border-radius:28px;padding:16px 24px;overflow:auto}
.sdPan h3{margin:4px 0 14px;font-size:30px}.sdPan .sdDone{position:absolute;right:22px;bottom:16px}
.sdSets{display:flex;flex-wrap:wrap;gap:10px}.sdSets .sdChip{margin:0;height:70px}.sdSets .sdChip span{font-size:24px}
.sdOpt{display:flex;align-items:center;margin-bottom:10px}.sdOpt label{width:300px;font-size:24px;font-weight:900}.sdOpt .sdChip{height:58px}
.sdNote{font-size:19px;font-weight:700;width:560px}
.sdResume{position:absolute;left:60px;right:60px;top:170px;display:flex;align-items:center;justify-content:space-between}
.sdRA{width:180px;text-align:center;color:#fff;font-size:70px;font-weight:900;text-shadow:3px 3px 0 #5b4636}.sdRA .fitsvg{width:150px;margin:0 auto}
.sdRm{flex:1;margin:0 20px;background:#fffaf0;border:5px solid #5b4636;border-radius:28px;padding:20px;text-align:center}.sdRm h3{font-size:34px;margin:0 0 8px}.sdRm p{font-size:30px;font-weight:900;margin:0 0 18px}
.sdRm .btn{margin:6px}
.sdIni{width:52px;height:52px;border-radius:50%;border:4px solid #5b4636;color:#fff;font-size:30px;font-weight:900;line-height:46px;text-align:center;box-sizing:border-box;margin:0 auto;text-shadow:2px 2px 0 #5b4636}
.sdPlate{position:absolute;top:146px;width:472px;height:62px;background:#fffaf0;border:4px solid #5b4636;border-radius:20px;display:flex;align-items:center;box-sizing:border-box;padding:0 10px 0 6px;transition:box-shadow .2s}
.sdPlate.p0{left:20px}.sdPlate.p1{left:532px}
.sdPlate.turn{box-shadow:0 0 0 5px #fff27a,0 0 22px 8px #ffd23f}
.sdPlate .av{width:54px;height:54px;flex:none;overflow:hidden}.sdPlate .av .fitsvg{width:54px}.sdPlate .av .fitsvg svg{width:54px;height:54px}
.sdPlate .nm{font-size:26px;font-weight:900;margin-left:8px;width:150px;line-height:1;color:var(--pc);text-shadow:1px 1px 0 #5b4636}.sdPlate .nm em{display:block;font-style:normal;font-size:16px;color:#5b4636;text-shadow:none;height:18px;margin-top:3px}
.sdPlate .sc{font-size:40px;font-weight:900;width:66px;text-align:center}
.sdTrack{display:flex;gap:3px}.sdTrack i{width:17px;height:17px;border-radius:50%;border:2px solid #5b4636;font-style:normal;font-size:9px;line-height:17px;text-align:center;background:#fff}
.sdBar{position:relative;width:180px;height:26px;border:3px solid #5b4636;border-radius:14px;background:#fff;overflow:hidden}.sdBar i{position:absolute;left:0;top:0;bottom:0}
.sdBar span{position:relative;display:block;text-align:center;font-size:16px;font-weight:900;line-height:20px}
.sdSlot{position:absolute;top:218px;width:238px;height:333px;perspective:1400px}.sdSlot.p0{left:24px}.sdSlot.p1{left:762px}
.sdScale{width:410px;height:574px;transform:scale(.58);transform-origin:0 0}
.sdSlot.tapme .sdScale{animation:sdPulse 1s ease-in-out infinite}
@keyframes sdPulse{50%{transform:scale(.6) rotate(-2deg)}}
.sdSlot.hop{animation:sdHop .6s ease-out}@keyframes sdHop{40%{transform:translateY(-30px) rotate(-3deg)}}
.sdSlot.deal,.sdSlot.swap{animation:sdDeal .45s ease-out}@keyframes sdDeal{from{transform:translateY(-60px) rotate(-10deg);opacity:0}}
.tc .sdHi{background:#fff27a;border-radius:10px;box-shadow:0 0 0 4px #ffd23f;padding:0 4px}
.sdBackF{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;color:#fff;text-shadow:3px 3px 0 #5b4636}
.sdBackF .lg{margin-top:18px;font-size:34px}.sdBackF .lg b{font-size:34px}
.sdBackF .qq{position:relative;width:300px;height:240px;margin-top:10px;display:flex;align-items:center;justify-content:center}
.sdBackF .qq span{position:relative;font-size:200px;font-weight:900;line-height:1}
.sdBackF .sh{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}.sdBackF .sh svg{width:280px;height:240px;filter:brightness(0);opacity:.45}
.sdBackF .tyB{width:90px;height:90px;border-radius:50%;background:#fff;border:5px solid #5b4636;font-size:54px;line-height:82px;text-align:center;text-shadow:none}
.sdBackF .cl{margin-top:12px;font-size:30px;font-weight:800;text-align:center;line-height:1.2;padding:0 16px}
.sdCol{position:absolute;top:218px;width:220px;height:340px}.sdCol.p0{left:272px}.sdCol.p1{left:532px}
.sdList.off{pointer-events:none}
.sdSt{display:flex;align-items:center;width:220px;height:52px;margin:0 0 6px;padding:0 6px;border:4px solid #5b4636;border-radius:16px;background:#fff;font:inherit;color:#5b4636;font-weight:900;box-sizing:border-box;transition:transform .15s,background .15s}
.sdSt .i{font-size:24px;width:32px;text-align:center}.sdSt .n{flex:1;text-align:left;font-size:19px;line-height:1;padding-left:4px}
.sdSt .n small{display:flex;gap:3px;margin-top:5px}.sdSt .n small i{width:15px;height:8px;border-radius:4px;background:#e4dccd}.sdSt .n small i.on{background:#f0a030}.sdSt .n small i.b4,.sdSt .n small i.b5{background:#3fae5a}.sdSt .n small i.b1,.sdSt .n small i.b2{background:#e8826a}
.sdSt .v{font-size:30px;min-width:56px;text-align:right}
.sdSt.sel{background:#ffd86b;transform:scale(1.05)}.sdSt.hint{box-shadow:0 0 0 4px #fff27a,0 0 16px 6px #ffd23f}
.sdSt.win{background:#8fe39a;transform:scale(1.06)}.sdSt.lose{background:#ffd0d0}.sdSt.tie{background:#9bdcff;transform:scale(1.04)}
.sdGo{width:220px;height:58px;min-height:0;font-size:28px;background:#8fe39a;margin-top:2px}
.sdClueP{width:220px;height:340px;box-sizing:border-box;border:4px dashed rgba(255,255,255,.8);border-radius:22px;color:#fff;text-align:center;padding:10px 8px;text-shadow:2px 2px 0 #5b4636}
.sdClueP .ty{width:76px;height:76px;margin:4px auto 6px;border-radius:50%;border:4px solid #fff;font-size:44px;line-height:70px;text-shadow:none}
.sdClueP p{margin:2px 0;font-size:21px;font-weight:800}.sdClueP>b{display:block;font-size:28px;line-height:1.1;margin:4px 0}.sdClueP small{display:block;font-size:17px;font-weight:800;opacity:.9}
.sdTapNow{margin-top:10px;background:#fff27a;color:#5b4636;text-shadow:none;border:4px solid #5b4636;border-radius:16px;padding:8px 6px;font-size:20px;font-weight:900;animation:sdPulse2 1s ease-in-out infinite}
@keyframes sdPulse2{50%{transform:scale(1.06)}}
.sdWon,.sdPile{position:absolute;top:570px;height:180px}.sdWon.p0{left:24px;width:300px}.sdWon.p1{left:700px;width:300px}.sdPile{left:402px;width:220px}
.sdWon .pl,.sdPile .pl{position:relative;height:118px}
.sdMini{position:absolute;left:calc(var(--j)*30px);top:0;transform:scale(.62) rotate(calc(var(--j)*5deg - 5deg));transform-origin:0 0}
.sdWon.p1 .sdMini{left:auto;right:calc(var(--j)*30px + 30px);transform-origin:100% 0}
.sdPile .sdMini{left:calc(60px + var(--j)*12px)}
.sdWon .lbl,.sdPile .lbl{font-size:20px;font-weight:900;color:#fff;text-shadow:2px 2px 0 #5b4636}.sdWon.p1 .lbl{text-align:right}.sdPile .lbl{text-align:center;opacity:.6}.sdPile.has .lbl{opacity:1}
.sdPlus{position:absolute;left:150px;top:30px;font-size:34px;color:#fff27a;text-shadow:2px 2px 0 #5b4636}
.sdWon .bn{position:absolute;top:0;width:90px}.sdWon.p0 .bn{left:206px}.sdWon.p1 .bn{left:0}
.sdBone{width:86px;height:86px;border-radius:22px;border:4px solid #5b4636;background:#fff;font-size:40px;line-height:1;display:flex;flex-direction:column;align-items:center;justify-content:center;opacity:.6}
.sdBone small{font-size:16px;font-weight:900}.sdBone.can{opacity:1;background:#ffd86b;animation:sdPulse2 1s ease-in-out infinite}
#sdNext{position:absolute;left:412px;top:676px;width:200px;height:76px;font-size:30px}
.sdFly{position:absolute;z-index:25;transition:transform .8s ease-in,opacity .8s ease-in;pointer-events:none}
.card.sdEnd .sdEndA{display:flex;align-items:center;justify-content:center;gap:24px}.card.sdEnd .av{width:140px}.card.sdEnd .av .fitsvg{width:140px}.card.sdEnd .bp{text-align:center}.card.sdEnd .bp small{display:block;font-weight:900}
`;document.head.appendChild(st);}
window.SHOWDOWN={open,SD,get M(){return M;},buildMap,poolFor,clue,band,bestStat,val,next,pick,goBtn,reveal,slotTap,useBone,startMatch,finish:()=>finish(),CHARS};
})();
