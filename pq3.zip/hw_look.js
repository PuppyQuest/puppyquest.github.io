/* ================================================================
   Halloween (Pup Seasons 3, 25 Nov 2026; claude/halloween-design.md): how the pups look.
   - Marmalade (Kooikerhondje) and Conker (Hovawart), the two secret season pups;
   - an autumn fact for each of the 119 Halloween pups (stable science, written 25 Nov 2026);
   - costume kits per island, one full costume per island, the pumpkin suit for the Spa;
   - new pieces: witch hat, pumpkin hat, cat ears, wizard hat, pirate hat, skeleton top,
     capes in five colours, bat wings, eye mask (2D and 3D);
   - window.SEASONSPEC is wrapped: in Halloween every pup in 3D wears its costume, and in 2D any
     copy made with HLOOK.hp(p). Not scary: costumes only, never ghosts.
   ================================================================ */
(function(){
const PS=window.PSTYLE,K=INK,PI=Math.PI;
const ol=w=>`stroke="${K}" stroke-width="${w||2.6}" stroke-linejoin="round" stroke-linecap="round"`;
const st=(c,w,o)=>`fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${o==null?1:o}"`;
const GOLD='#ffd23f',ORNG=['#ff8a1a','#ffb020','#e8603a'],PURP=['#5a2a8a','#7a3ab8','#3a2a6a','#8a2a6a'],HERO=['#c8302a','#2b5ab8','#5a2a8a','#e8603a'];
const CAPES={capered:'#c8302a',capepurple:'#6a2a9a',capeorange:'#f07a1a',capeblack:'#2a2630',capeblue:'#2b5ab8'};

/* ---------------- the two secret season pups ---------------- */
const HPUPS={
 marmalade:{id:'marmalade',name:'Marmalade',breed:'Kooikerhondje',area:'sunflowers',island:'meadow',type:'leaf',pitch:1.2,season:'hw',
   look:{fur:'#e0662a',ear:'#c8521f',ears:'floppy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',paw:'#ffffff',tail:'plume',tailTip:'#ffffff',collar:'#7a3ab8',acc:[]},
   fact:'The Kooikerhondje is a small orange and white dog from the Netherlands, with black tips on its ears called earrings. Long ago it helped catch ducks by waving its fluffy white tail, which made them curious.',
   hint:'Marmalade is somewhere in the Pumpkin Patch Maze.'},
 conker:{id:'conker',name:'Conker',breed:'Hovawart',area:'village',island:'village',type:'fire',pitch:.9,season:'hw',
   look:{fur:'#26232e',ear:'#26232e',ears:'floppy',fluffy:true,muzzle:'#d9a050',belly:'#d9a050',paw:'#d9a050',tail:'plume',collar:'#ff8a1a',acc:[]},
   fact:'The Hovawart is a big German farm dog. Its name means guardian of the farm, and it can be black, blond, or black and gold.',
   hint:'Conker is waiting near the Pumpkin Parade in the village.'}};
if(window.CARDS&&CARDS.BREEDS){if(!CARDS.BREEDS.Kooikerhondje)CARDS.BREEDS.Kooikerhondje={sz:'s',spd:7,brn:8,cud:8,brv:6,g:'fetch'};if(!CARDS.BREEDS.Hovawart)CARDS.BREEDS.Hovawart={sz:'l',spd:7,brn:8,cud:7,brv:9,g:'guard'};}
if(PS&&PS.COAT){PS.COAT.Kooikerhondje='feathered';PS.COAT.Hovawart='feathered';}

/* ---------------- autumn facts, one per pup, in island order (I.pups then the sparkly pup) ---------------- */
const HF={
 meadow:['A pumpkin is a fruit, because it grows from a flower and has seeds inside.',
  'Pumpkins are mostly water, and they are hollow inside, so they float.',
  'Leaves turn yellow and orange in autumn because the green colour breaks down, showing colours that were hidden underneath.',
  'Red autumn leaves make their red colour fresh in autumn, from sugar left in the leaf.',
  'Hedgehogs eat lots in autumn to build up fat, then hibernate through the winter.',
  'Squirrels bury nuts in autumn to eat later, and forgotten nuts can grow into new trees.',
  'Conkers are the seeds of the horse chestnut tree. Children in Britain have played conkers for more than 150 years.',
  'On misty autumn mornings, tiny drops of dew make spiders\' webs sparkle.',
  'Barn owls can catch a mouse in total darkness, just by listening for it.',
  'Swallows from Britain fly all the way to South Africa for the winter.',
  'Scarecrows are put in fields to frighten birds away from the crops.',
  'The heaviest pumpkins ever grown weigh more than a tonne, as much as a small car!',
  'Bats are the only mammals that can really fly.'],
 snowy:['Some animals, like the stoat, grow white fur in winter to hide in the snow.',
  'Polar bears have black skin under their thick fur, which helps them soak up warmth from the Sun.',
  'Bats that live where winters are cold hibernate in caves, where it does not freeze.',
  'White pumpkins are real! Some kinds have pale skins, and people call them ghost pumpkins.',
  'Snowy owls have feathers on their feet, like fluffy slippers.',
  'Arctic foxes change colour: brown in summer and white in winter.',
  'Ptarmigans are birds that turn white in winter to hide in the snow.',
  'Animals that hibernate breathe very slowly and let their bodies cool down, to save energy.',
  'In Ireland and Scotland, people used to carve lanterns out of turnips, long before pumpkins.',
  'Mountain goats have special hooves that grip on steep, icy rocks.',
  'Huskies have two layers of fur: a soft, warm one underneath and a tougher one on top.',
  'Each snowflake is clear ice, but lots of tiny crystals together bounce the light back and look white.',
  'Frost on a window grows in patterns that look like little ferns made of ice.'],
 reef:['An octopus has eight arms and three hearts.',
  'An octopus can squirt ink to make a dark cloud and swim away.',
  'Pumpkins float, so in some places people race in giant hollowed-out pumpkins like boats!',
  'A pufferfish puffs itself up into a spiky ball to look too big to eat.',
  'Hermit crabs live in empty shells, and move into a bigger one as they grow.',
  'Cuttlefish can change colour in less than a second, to hide or to talk to each other.',
  'Sea stars have no brain and no blood, and they can grow back a lost arm.',
  'Vampire squid live deep in the dark sea, and they eat tiny bits of food that drift down, called marine snow.',
  'Clownfish live safely among the stinging arms of sea anemones.',
  'Sharks have been swimming in the sea for more than 400 million years, longer than there have been trees.',
  'A seahorse dad carries the babies in a pouch until they hatch.',
  'Decorator crabs stick seaweed and sponges on their shells as a disguise.',
  'Jellyfish have no brain, no heart and no bones, and they have been around for more than 500 million years.'],
 ninja:['Shadows happen because light travels in straight lines and cannot bend round things.',
  'Your shadow is longest in the morning and the evening, when the Sun is low in the sky.',
  'Shadow puppets are a very old kind of theatre. In China they have been made for more than a thousand years.',
  'In Japan, people dress up for Halloween too, with big costume parades in the cities.',
  'In Japan, people go out to look at the red autumn maple leaves. This is called momijigari.',
  'Red pandas have a false thumb, a bony bump on the wrist that helps them hold bamboo.',
  'Japanese snow monkeys live farther north than any other monkey in the world.',
  'Some bats live for more than 30 years, which is a very long time for such a small animal.',
  'Many small bats find their food in the dark by listening to echoes.',
  'Thin paper lets light shine through, which is why paper lanterns glow.',
  'Crows are very clever. They can solve puzzles and use sticks as tools.',
  'In Japan, actors have worn masks in Noh plays for more than 600 years.',
  'Moths are drawn to lights at night. Scientists think the lights muddle the way they steer.'],
 number:['A spider has 8 legs, and most spiders have 8 eyes too.',
  'An octopus has 8 arms, so 3 octopuses have 24 arms.',
  'One pumpkin can have hundreds of seeds inside.',
  'Halloween is on 31 October, the last day of October.',
  'A bat can catch hundreds of insects in one night.',
  'Many spiders that spin round webs make a new web almost every night.',
  'There are more than 1,400 kinds of bat, about one in every five kinds of mammal.',
  'When there are two full moons in one month, the second one is called a blue moon.',
  'At their fastest, giant pumpkins can grow more than 20 kilograms in a single day.',
  'A cat has 5 toes on each front paw and 4 on each back paw: 18 toes in all.',
  'An owl can turn its head three quarters of the way round, 270 degrees.',
  'Halloween is day number 304 of the year, or 305 in a leap year.',
  'Some spiders can make 7 different kinds of silk, for different jobs.'],
 gadget:['Reflective strips bounce car headlights straight back, so drivers can see you in the dark.',
  'An echo is a sound bouncing back off a wall or a cliff.',
  'Bats make squeaks too high for people to hear, and listen to the echoes to find insects. This is called echolocation.',
  'Ships use sonar, which works like a bat\'s echoes, to find things under the sea.',
  'A torch has a curved mirror behind the bulb to make a beam of light.',
  'Dry ice is frozen carbon dioxide. It makes foggy clouds because it turns straight into a gas. Only grown-ups should touch it!',
  'Spider silk is stronger than a steel thread of the same weight.',
  'Velcro was invented after a man noticed how burrs from plants stuck to his dog\'s fur.',
  'Some robots are built to move like animals, like robot dogs that can climb stairs.',
  'LED lights stay much cooler than candles, so they are safer inside a pumpkin.',
  'A battery stores energy in chemicals, and turns it into electricity when you switch something on.',
  'Magnets can make things move without touching them, like a magic trick!',
  'The word robot comes from a play written in 1920, from a Czech word meaning hard work.'],
 rescue:['Wear bright colours or something reflective when you go out in the dark, so drivers can see you.',
  'Always go trick-or-treating with a grown-up.',
  'Firefighters have shiny stripes on their jackets, so they can be seen in smoke and in the dark.',
  'Most lifeboat crews in Britain are volunteers, ready to rush out whenever they are needed.',
  'A battery light is safer than a candle in a pumpkin, because it cannot start a fire.',
  'Dressing-up costumes sold in Britain have to pass fire safety tests.',
  'Seals can sleep in the water, floating upright like a bottle.',
  'Gulls can drink salty sea water, because special glands above their eyes get rid of the salt.',
  'Puffins can carry ten or more little fish in their beaks at once.',
  'Newfoundland dogs have webbed feet, which help them swim to rescue people.',
  'Bats are not blind. They can see, and many use echoes in the dark as well.',
  'In Britain, dialling 999 gets you the police, fire, ambulance or the coastguard.',
  'Saint Bernard dogs once helped rescue travellers lost in the snow in the Alps.'],
 dino:['Your skeleton holds you up. Without bones, you would flop like a jellyfish!',
  'A grown-up has 206 bones. Babies are born with about 300, and some join together as they grow.',
  'Fossil bones are rock. Over millions of years, minerals slowly took the place of the bone.',
  'Tyrannosaurus rex had about 60 teeth, and the biggest were as long as bananas.',
  'A dog has about 320 bones, more than a person, partly because of its long tail.',
  'Dinosaurs laid eggs, just like birds, their living relatives.',
  'Birds are living dinosaurs. A chicken is a cousin of the T. rex!',
  'Some dinosaurs had feathers, and fossils even show what colour a few of them were.',
  'Crocodiles\' relatives lived alongside the dinosaurs.',
  'The word dinosaur means terrible lizard, but dinosaurs were not lizards at all.',
  'Museums put dinosaur skeletons together like a giant puzzle, often using lighter copies of the real bones.',
  'Spiders were around long before the dinosaurs, more than 300 million years ago.',
  'Amber is old tree resin that went hard, and sometimes it holds insects from millions of years ago.'],
 planet:['A big full moon in autumn is called a harvest moon.',
  'The Moon looks orange when it is low in the sky, because its light passes through more air.',
  'On the Moon you would weigh about a sixth of what you weigh on Earth.',
  'Astronauts on the space station have dressed up in costumes for Halloween.',
  'There is no air in space, so sound cannot travel there. Nobody could hear you say boo!',
  'Mars looks red because its dust has rust in it.',
  'Saturn is so light for its size that it would float in a big enough bath.',
  'A day on Venus is longer than its whole year!',
  'Jupiter has a giant storm called the Great Red Spot, bigger than the whole Earth.',
  'A comet\'s tail always points away from the Sun.',
  'The two moons of Mars are named Phobos and Deimos, which mean fear and dread.',
  'Neptune has the fastest winds of any planet, more than 2,000 kilometres an hour.',
  'Pluto has a giant heart shape on it, made of ice.']};
const FACT={marmalade:HPUPS.marmalade.fact,conker:HPUPS.conker.fact};
ISLANDS.forEach(I=>{const L=HF[I.id];if(!L)return;I.pups.concat(I.bonus||[]).forEach((p,i)=>{if(L[i])FACT[p.id]=L[i];});});

/* ---------------- new pieces (2D) ---------------- */
const star5=(x,y,r,col)=>{let d='';for(let i=0;i<10;i++){const a=-PI/2+i*PI/5,rr=i%2?r*.45:r;d+=(i?'L':'M')+(x+Math.cos(a)*rr).toFixed(1)+' '+(y+Math.sin(a)*rr).toFixed(1);}return `<path d="${d}Z" fill="${col||GOLD}" ${ol(1.4)}/>`;};
const paw=(x,y,col,s)=>{s=s||1;return `<ellipse cx="${x}" cy="${y+3*s}" rx="${6*s}" ry="${5*s}" fill="${col}"/>`+[[-6,-4],[-2,-8],[2,-8],[6,-4]].map(q=>`<circle cx="${x+q[0]*s}" cy="${y+q[1]*s}" r="${2.3*s}" fill="${col}"/>`).join('');};
const pumpkinSVG=(x,y,r,col,face)=>{col=col||ORNG[0];const dk=shade(col,-.28);return `<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.82}" fill="${col}" ${ol(2.4)}/><path d="M${x-r*.45} ${y-r*.75} Q${x-r*.7} ${y} ${x-r*.45} ${y+r*.75} M${x} ${y-r*.8} V${y+r*.8} M${x+r*.45} ${y-r*.75} Q${x+r*.7} ${y} ${x+r*.45} ${y+r*.75}" ${st(dk,1.8,1)}/>`+
  `<path d="M${x-2} ${y-r*.78} q-1 -${r*.35} ${r*.25} -${r*.45}" ${st('#4a7a2a',3.4,1)}/>`+(face?`<path d="M${x-r*.5} ${y-r*.2} l${r*.18} -${r*.24} l${r*.18} ${r*.24} Z M${x+r*.14} ${y-r*.2} l${r*.18} -${r*.24} l${r*.18} ${r*.24} Z M${x-r*.55} ${y+r*.15} Q${x} ${y+r*.6} ${x+r*.55} ${y+r*.15} Q${x} ${y+r*.35} ${x-r*.55} ${y+r*.15} Z" fill="#ffd23f" stroke="${dk}" stroke-width="1.2"/>`:'');};
if(PS){
 Object.assign(PS.HAT,{
  witchhat(c,col,o){const cx=c.cx,hw=c.hw,yb=c.cy-c.hh*.62;col=col||PURP[0];const band=(o&&o.band)||ORNG[0];
   return `<ellipse cx="${cx}" cy="${yb}" rx="${hw*1.25}" ry="13" fill="${col}" ${ol(3)}/>`+
    `<path d="M${cx-hw*.62} ${yb-4} L${cx-hw*.06} ${yb-80} Q${cx+hw*.12} ${yb-96} ${cx+hw*.52} ${yb-86} Q${cx+hw*.16} ${yb-76} ${cx+hw*.18} ${yb-64} L${cx+hw*.62} ${yb-4} Z" fill="${col}" ${ol(3.2)}/>`+
    `<path d="M${cx-hw*.56} ${yb-12} L${cx+hw*.56} ${yb-12}" ${st(K,13,1)}/><path d="M${cx-hw*.55} ${yb-12} L${cx+hw*.55} ${yb-12}" ${st(band,8,1)}/>`+star5(cx+hw*.08,yb-38,7,GOLD);},
  pumpkinhat(c,col){const cx=c.cx,yb=c.cy-c.hh*.7;return pumpkinSVG(cx,yb-18,c.hw*.72,col||ORNG[0],false)+`<path d="M${cx+4} ${yb-50} q14 -10 22 2 q-12 6 -22 -2 Z" fill="#5aa83a" ${ol(2)}/>`;},
  catears(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||'#26232e';const d=`M${cx-hw*.86} ${cy-hh*.3} Q${cx} ${cy-hh*1.28} ${cx+hw*.86} ${cy-hh*.3}`;let s=`<path d="${d}" ${st(K,10,1)}/><path d="${d}" ${st(col,6,1)}/>`;
   for(const g of[-1,1]){const x=cx+g*hw*.42,y=cy-hh*.92;s+=`<path d="M${x-15} ${y+8} L${x+g*7} ${y-30} L${x+15} ${y+4} Z" fill="${col}" ${ol(2.6)}/><path d="M${x-7} ${y+3} L${x+g*5} ${y-17} L${x+7} ${y+1} Z" fill="#ff9ecb"/>`;}return s;},
  wizhat(c,col,o){o=o||{};const cx=c.cx,hw=c.hw,yb=c.cy-c.hh*.62;col=col||'#3a4ab8';const n=o.num!=null?String(o.num):null;
   return `<path d="M${cx-hw*.8} ${yb} L${cx+hw*.12} ${yb-98} L${cx+hw*.8} ${yb} Z" fill="${col}" ${ol(3.2)}/>`+`<path d="M${cx-hw*.94} ${yb+1} Q${cx} ${yb+12} ${cx+hw*.94} ${yb+1}" ${st(K,12,1)}/><path d="M${cx-hw*.92} ${yb+1} Q${cx} ${yb+11} ${cx+hw*.92} ${yb+1}" ${st(GOLD,7,1)}/>`+
    (n?`<text x="${cx-hw*.02}" y="${yb-22}" font-size="${n.length>1?22:28}" font-weight="900" text-anchor="middle" fill="${GOLD}" stroke="${K}" stroke-width="1.6" font-family="Arial">${n}</text>`:star5(cx-hw*.02,yb-34,9,GOLD))+star5(cx+hw*.2,yb-64,6,'#fff');},
  tricorn(c,col){const cx=c.cx,hw=c.hw,yb=c.cy-c.hh*.62;col=col||'#26232e';
   return `<path d="M${cx-hw*1.15} ${yb+2} Q${cx-hw*.9} ${yb-48} ${cx} ${yb-42} Q${cx+hw*.9} ${yb-48} ${cx+hw*1.15} ${yb+2} Q${cx} ${yb-14} ${cx-hw*1.15} ${yb+2} Z" fill="${col}" ${ol(3.2)}/>`+`<path d="M${cx-hw*1.0} ${yb-6} Q${cx} ${yb-24} ${cx+hw*1.0} ${yb-6}" ${st(GOLD,3,1)}/>`+paw(cx,yb-26,'#ffffff',1.1);}});
 Object.assign(PS.BODY,{
  skeleton(c,col){const by=c.by,bw=c.bw,bh=c.bh,x1=100-bw,bx=c.bcx;col=col||'#26232e';let s=`<rect x="${x1}" y="${by-bh}" width="${bw*2}" height="${bh*2}" fill="${col}"/><path d="M${bx} ${by-bh*.85} V${by+bh*.85}" ${st('#ffffff',4.5,1)}/>`;
   for(let i=0;i<4;i++){const y=by-bh*.55+i*bh*.32,w=bw*(.62-i*.07);s+=`<path d="M${bx-w} ${y+7} Q${bx} ${y-6} ${bx+w} ${y+7}" ${st('#ffffff',3.6,1)}/>`;}return s;}});
 for(const k in CAPES){const col=CAPES[k];PS.BACK[k]=c=>{const x1=100-c.bw-6,x2=100+c.bw+6,y=c.by-c.bh-2,yb=c.by+c.bh+8;
   return `<path d="M${x1+12} ${y} Q100 ${y-10} ${x2-12} ${y} L${x2+16} ${yb} Q100 ${yb+14} ${x1-16} ${yb} Z" fill="${col}" ${ol(3)}/><path d="M${x1+18} ${y+6} Q100 ${y-2} ${x2-18} ${y+6}" ${st(shade(col,-.3),3,1)}/>`;};}
 PS.BACK.batwings=c=>{const col='#5a3a7a';let s='';for(const g of[-1,1]){const x=100+g*(c.bw-4),y=c.by-c.bh+4;
   s+=`<path d="M${x} ${y} L${x+g*48} ${y-24} L${x+g*42} ${y-6} L${x+g*55} ${y+3} L${x+g*38} ${y+12} L${x+g*42} ${y+25} Q${x+g*20} ${y+14} ${x} ${y+20} Z" fill="${col}" ${ol(2.8)}/><path d="M${x+g*8} ${y+6} L${x+g*44} ${y-16}" ${st('#7a5a9a',2,1)}/>`;}return s;};
 Object.assign(PS.FACE,{
  mask(c,col){const cx=c.cx,y=c.cy-3,ed=c.hw*c.L.eyeD;col=col||'#26232e';
   const out=`M${cx-ed-26} ${y-4} Q${cx-ed} ${y-24} ${cx} ${y-11} Q${cx+ed} ${y-24} ${cx+ed+26} ${y-4} Q${cx+ed+8} ${y+20} ${cx} ${y+6} Q${cx-ed-8} ${y+20} ${cx-ed-26} ${y-4} Z`;
   const holes=[-1,1].map(g=>`M${cx+g*ed+13} ${y} A13 12 0 1 0 ${cx+g*ed-13} ${y} A13 12 0 1 0 ${cx+g*ed+13} ${y} Z`).join(' ');
   return `<path d="${out} ${holes}" fill-rule="evenodd" fill="${col}" ${ol(2.6)}/>`;}});
}
/* ---------------- new pieces (3D) ---------------- */
if(PS){
 Object.assign(PS.H3,{
  witchhat(h,col,o){const c=col||PURP[0];mk('cyl',c,.66,.04,.66,0,.42,0,h);const cn=mk('cone',c,.36,.78,.36,.04,.82,0,h);cn.rotation.z=-.16;mk('cyl',(o&&o.band)||ORNG[0],.37,.08,.37,0,.5,0,h);},
  pumpkinhat(h,col){mk('sph',col||ORNG[0],.38,.28,.38,0,.62,0,h);mk('cyl','#4a7a2a',.04,.14,.04,0,.92,0,h);},
  catears(h,col){const c=col||'#26232e';mk('arc',c,.6,.6,1.2,0,.08,0,h);[-1,1].forEach(s=>{const e=mk('cone',c,.13,.28,.08,s*.24,.58,0,h);e.rotation.z=-s*.25;mk('cone','#ff9ecb',.07,.16,.03,s*.24,.56,.05,h).rotation.z=-s*.25;});},
  wizhat(h,col){mk('cyl',GOLD,.46,.04,.46,0,.42,0,h);mk('cone',col||'#3a4ab8',.36,.95,.36,0,.9,0,h);mk('sph',GOLD,.07,.07,.03,0,.8,.27,h,true);},
  tricorn(h,col){const c=col||'#26232e';mk('cyl',c,.56,.12,.42,0,.48,0,h);mk('sph',c,.3,.2,.28,0,.58,0,h);mk('sph','#ffffff',.06,.06,.02,0,.58,.27,h);}});
 for(const k in CAPES){const col=CAPES[k];PS.K3[k]=(b,c)=>{mk('box',col,.98*c.bw,.04,1.0*c.lg,0,1.17,-.12*c.lg,b);};}
 PS.K3.batwings=(b,c)=>{[-1,1].forEach(s=>{const w=mk('box','#5a3a7a',.7,.03,.38,s*(.5*c.bw+.3),1.12,-.05*c.lg,b);w.rotation.z=s*.35;});};
 Object.assign(PS.FACE3,{mask(h,col,L){const ex=.22*L.eyeD/.42;[-1,1].forEach(g=>mk('ring',col||'#26232e',.15,.15,.9,g*ex,.07,.53,h));mk('box',col||'#26232e',.14,.04,.03,0,.1,.55,h);}});
 Object.assign(PS.B3,{skeleton:'#26232e'});
}
function skel3D(S,b,c){if(!S.b||S.b[0]!=='skeleton')return;const lg=c.lg,bw=c.bw;mk('box','#ffffff',.06,.04,.85*lg,0,1.14,0,b);
  for(let i=0;i<4;i++)mk('box','#ffffff',.9*bw,.035,.05,0,1.08-i*.0,(.32-i*.2)*lg,b);}

/* ---------------- full costumes ---------------- */
const HC={
 hwpump:{n:'Pumpkin',body:'#ff8a1a',belly:'#ffb020',paw:'#c8601a',line:'NAME is a round, smiley pumpkin!'},
 pbear:{n:'Polar Bear',body:'#ffffff',belly:'#f6f7fa',paw:'#e4e8ee',line:'NAME is a cuddly polar bear!'},
 octo:{n:'Octopus',body:'#9a5ad8',belly:'#c89af0',paw:'#7a3ab8',line:'NAME is an octopus with eight wiggly arms!'},
 dragon:{n:'Dragon',body:'#3fae5a',belly:'#ffd23f',paw:'#2a7a3a',line:'NAME is a friendly little dragon. Rooar!'},
 skel:{n:'Skeleton',body:'#26232e',belly:'#26232e',paw:'#3a3640',line:'NAME is a dancing skeleton. Rattle rattle!'},
 alienc:{n:'Alien',body:'#8ae05a',belly:'#b8f08a',paw:'#5ab83a',line:'NAME is a friendly alien. Take me to your treats!'}};
const HKEYS=Object.keys(HC),isH=k=>HKEYS.indexOf(k)>=0;
for(const k in HC){HC[k].hw=true;COS[k]=HC[k];}
if(typeof COS_ICON!=='undefined')Object.assign(COS_ICON,{hwpump:'🎃',pbear:'🐻‍❄️',octo:'🐙',dragon:'🐉',skel:'💀',alienc:'👽'});
const _c2=cos2D;cos2D=function(w,c){let s=_c2(w,c);const L=c.L,Kc=L.cos;if(!isH(Kc))return s;
  const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,S3=c.S3,yb=cy-hh*.42;
  const dome=(col,lo)=>`<path d="M${cx-hw*.94} ${lo} Q${cx-hw*.94} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.94} ${cy-hh*1.2} ${cx+hw*.94} ${lo} Z" fill="${col}" ${S}/>`;
  if(w==='behind'){
    if(Kc==='octo'){const y=by+bh-6;for(let i=0;i<8;i++){const x=100-bw*.85+i*bw*.24;s+=`<path d="M${x} ${y} q-8 14 0 24 q8 10 2 22" ${st(K,10,1)}/><path d="M${x} ${y} q-8 14 0 24 q8 10 2 22" ${st('#9a5ad8',6.5,1)}/>`;}}
    if(Kc==='dragon')s+=PS.BACK.batwings(c).replace(/#5a3a7a/g,'#2f8a48').replace(/#7a5a9a/g,'#5ac87a');}
  if(w==='bodyClip'){
    if(Kc==='hwpump'){for(const t of[-.55,-.2,.2,.55])s+=`<path d="M${100+t*bw} ${by-bh} Q${100+t*bw*1.3} ${by} ${100+t*bw} ${by+bh}" ${st('#d8641a',3,1)}/>`;
      s+=`<path d="M${bcx-bw*.45} ${by-bh*.25} l${bw*.15} -${bh*.25} l${bw*.15} ${bh*.25} Z M${bcx+bw*.15} ${by-bh*.25} l${bw*.15} -${bh*.25} l${bw*.15} ${bh*.25} Z M${bcx-bw*.5} ${by+bh*.15} Q${bcx} ${by+bh*.7} ${bcx+bw*.5} ${by+bh*.15} Q${bcx} ${by+bh*.42} ${bcx-bw*.5} ${by+bh*.15} Z" fill="#ffd23f" stroke="#a84a10" stroke-width="2"/>`;}
    if(Kc==='pbear')[[-.5,-.3],[.3,-.5],[.5,.3],[-.2,.4]].forEach(q=>{s+=`<path d="M${100+q[0]*bw-5} ${by+q[1]*bh} q5 4 10 0" ${st('#d8dde6',2.4,1)}/>`;});
    if(Kc==='octo')[[-.5,-.3],[.3,-.45],[.55,.25],[-.25,.4],[0,0]].forEach(q=>{s+=`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="4.5" fill="#e8c8ff" ${ol(1.4)}/>`;});
    if(Kc==='dragon')for(const t of[-.3,0,.3])s+=`<rect x="${100-bw}" y="${by+t*bh+bh*.1}" width="${bw*2}" height="5" fill="#e8b020"/>`;
    if(Kc==='skel')s+=PS.BODY.skeleton(c,'#26232e');
    if(Kc==='alienc')[[-.5,-.3],[.4,-.4],[.5,.3],[-.2,.45]].forEach(q=>{s+=`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="5" fill="#5ab83a"/>`;});}
  if(w==='top'){
    if(Kc==='hwpump')s+=`<path d="M${cx-2} ${cy-hh*1.05} q-3 -20 12 -26" ${st('#4a7a2a',8,1)}/><path d="M${cx+8} ${cy-hh*1.3} q16 -10 24 2 q-12 7 -24 -2 Z" fill="#5aa83a" ${ol(2)}/>`;
    if(Kc==='pbear')s+=dome('#ffffff',yb)+[-1,1].map(g=>`<circle cx="${cx+g*hw*.62}" cy="${cy-hh*1.02}" r="14" fill="#ffffff" ${S}/><circle cx="${cx+g*hw*.62}" cy="${cy-hh*1.02}" r="7" fill="#e8dce6"/>`).join('');
    if(Kc==='octo')s+=dome('#9a5ad8',yb)+[[-.45,-1.0],[.4,-1.08],[0,-1.25]].map(q=>`<circle cx="${cx+q[0]*hw}" cy="${cy+q[1]*hh}" r="4.5" fill="#e8c8ff"/>`).join('');
    if(Kc==='dragon')s+=dome('#3fae5a',yb)+[-.5,-.15,.2,.55].map((t,i)=>`<path d="M${cx+t*hw-7} ${cy-hh*(1.12+(i%2)*.06)} L${cx+t*hw} ${cy-hh*(1.4+(i%2)*.06)} L${cx+t*hw+7} ${cy-hh*(1.12+(i%2)*.06)} Z" fill="#ffd23f" ${ol(2)}/>`).join('')+[-1,1].map(g=>`<path d="M${cx+g*hw*.7} ${cy-hh*.95} q${g*6} -18 ${g*14} -20" ${st('#e8e0c8',6,1)}/>`).join('');
    if(Kc==='skel')s+=dome('#26232e',yb)+`<path d="M${cx-hw*.55} ${cy-hh*.95} H${cx+hw*.55} M${cx} ${cy-hh*1.18} V${cy-hh*.78}" ${st('#ffffff',4,1)}/>`;
    if(Kc==='alienc')s+=dome('#8ae05a',yb)+[-1,1].map(g=>{const x=cx+g*hw*.3,y=cy-hh*1.12;return `<path d="M${x} ${y} q${g*6} -18 ${g*20} -22" ${st(K,3.4,1)}/><circle cx="${x+g*20}" cy="${y-23}" r="6" fill="#ffd23f" ${ol(2)}/>`;}).join('');}
  return s;};
const _c3=cos3D;cos3D=function(L,b,h,c){const Kc=L.cos;if(!isH(Kc))return _c3(L,b,h,c);
  const bw=c.bw,lg=c.lg,helm=col=>{const hm=mk('hemi',col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;return hm;};
  switch(Kc){
   case'hwpump':mk('sph','#ff8a1a',.56*bw,.5,.7*lg,0,.68,0,b);mk('cyl','#4a7a2a',.05,.2,.05,0,.6,0,h);mk('sph','#5aa83a',.12,.03,.08,.1,.68,0,h);break;
   case'pbear':helm('#ffffff');[-1,1].forEach(s=>mk('sph','#ffffff',.13,.13,.08,s*.36,.5,0,h));break;
   case'octo':helm('#9a5ad8');for(let i=0;i<8;i++){const a=i/8*PI*2;mk('cyl','#9a5ad8',.05,.5,.05,Math.cos(a)*.4*bw,.25,Math.sin(a)*.5*lg,b);}break;
   case'dragon':helm('#3fae5a');for(let i=0;i<5;i++)mk('cone','#ffd23f',.07,.2,.07,0,1.18,(.4-i*.2)*lg,b);[-1,1].forEach(s=>{const w=mk('box','#2f8a48',.6,.03,.34,s*(.5*bw+.26),1.12,-.05*lg,b);w.rotation.z=s*.4;});break;
   case'skel':helm('#26232e');mk('box','#ffffff',.06,.04,.85*lg,0,1.14,0,b);for(let i=0;i<4;i++)mk('box','#ffffff',.92*bw,.035,.05,0,1.08,(.32-i*.2)*lg,b);break;
   case'alienc':helm('#8ae05a');[-1,1].forEach(s=>{mk('cyl','#3a3640',.025,.36,.025,s*.18,.74,.05,h).rotation.z=-s*.35;mk('sph','#ffd23f',.07,.07,.07,s*.3,.92,.05,h,true);});break;}};

/* ---------------- who wears what at Halloween ---------------- */
const NUMS={digit:'1',dot:'2',doodle:'10',zero:'0',ruler:'12',paddle:'5',cube:'8',prism:'3',pie:'π',seven:'7',infinity:'∞',plus:'+',pretzel:'6'};
const KIT={
 meadow:(i,p)=>{const k=i%3;return {h:k===0?['witchhat',PURP[i%4],{band:ORNG[i%3]}]:k===1?['pumpkinhat',ORNG[i%3]]:['catears',['#26232e','#ff8a1a','#7a3ab8'][i%3]],k:i%2?[['capeorange','capepurple','capered'][i%3]]:null,n:k===2?[['bowtie','#ff8a1a']]:null,drop:['scarf','bow']};},
 snowy:(i,p)=>({h:i%2?['wizhat',['#3a4ab8','#5a2a8a','#2a6a8a'][i%3]]:['witchhat',PURP[(i+1)%4],{band:'#5cf0ff'}],k:i%3===0?['capepurple']:null,drop:['scarf']}),
 reef:(i,p)=>({h:i%3===0?['tricorn']:null,g:i%3===1?['mask','#26232e']:null,k:i%2?['capeblue']:null,keep:['bubbles'],drop:['shellneck']}),
 ninja:(i,p)=>({h:i%3===0?['catears','#26232e']:null,g:i%3!==0?['mask',['#c8302a','#26232e','#5a2a8a'][i%3]]:null,k:i%2?['capered']:null,drop:['scarf','bow']}),
 number:(i,p)=>({h:['wizhat',['#3a4ab8','#5a2a8a','#2a6a8a','#8a2a6a'][i%4],{num:NUMS[p.id]||String(i+1)}],k:i%2?['capepurple']:null,drop:['scarf','flower','bow']}),
 gadget:(i,p)=>({h:i%3===0?['witchhat','#3a3640',{band:'#5cf0ff'}]:null,k:i%3===1?['batwings']:null,g:i%3===2?['mask','#3a4ab8']:null,drop:['scarf','bow']}),
 rescue:(i,p)=>({g:['mask',HERO[i%4]],k:[['capered','capeblue','capepurple','capeorange'][i%4]],drop:['scarf','glow']}),
 dino:(i,p)=>({h:i%2?['trex']:null,b:i%2?null:['skeleton'],k:i%3===2?['batwings']:null}),
 planet:(i,p)=>({space:{trim:'#ff8a1a',ant:true},k:i%2?['capepurple']:null})};
const COSTUME={meadow:'hwpump',snowy:'pbear',reef:'octo',ninja:'dragon',number:'wizard',gadget:'hero',rescue:'pirate',dino:'skel',planet:'alienc'};
const HOUT={marmalade:{h:['witchhat','#7a3ab8',{band:'#ff8a1a'}],k:['capeorange']},conker:{h:['pumpkinhat'],n:[['bowtie','#ff8a1a']]}};
const CWHO={};
ISLANDS.forEach(I=>{const f=KIT[I.id];if(!f)return;const cp=I.pups.find((p,i)=>i>=4&&!(p.look&&p.look.ninja));I.pups.concat(I.bonus||[]).forEach((p,i)=>{const cs=p===cp&&COSTUME[I.id];if(cs)CWHO[p.id]=cs;HOUT[p.id]=cs?{cos:cs}:f(i,p);const S=HOUT[p.id];for(const k in S)if(S[k]==null)delete S[k];});});
/* the unicorns at Halloween: a witch hat and an orange cape */
const UNI={h:['witchhat','#7a3ab8',{band:'#ff8a1a'}],k:['capeorange']};
const isPup=p=>!!(p&&p.id&&(PUPS[p.id]||HPUPS[p.id]));
const hOn=()=>!!(typeof state!=='undefined'&&state&&state.season==='hw');
const s0=window.SEASONSPEC;
window.SEASONSPEC=function(p,is2D){const prev=()=>s0?s0(p,is2D):null;if(!p||!p.id||p.guest)return prev();
  if(p.hw){if(p.uni)return UNI;if(!isPup(p))return null;const R=PUPS[p.id]||HPUPS[p.id];if(R.breed!==p.breed)return null;return HOUT[p.id]||null;}
  if(!is2D&&hOn()&&!p.xmas&&!p.glow){if(p.uni||!isPup(p))return null;const R=PUPS[p.id]||HPUPS[p.id];if(R.breed!==p.breed)return null;return HOUT[p.id]||null;}
  return prev();};
const _f3=form3D;form3D=function(L,b,h,c){_f3(L,b,h,c);const S=L._ps&&L._ps.S3;if(S&&!L.cos)try{skel3D(S,b,c);}catch(e){console.warn('hw 3D',e);}};

/* a Halloween copy of a pup, for 2D pictures and cards */
const hp=p=>p?Object.assign({},p,{hw:true}):p;
window.HLOOK={HPUPS,FACT,HOUT,hp,UNI,COSTUME,CWHO,ORNG,PURP,GOLD,star5,paw,pumpkinSVG};
})();
