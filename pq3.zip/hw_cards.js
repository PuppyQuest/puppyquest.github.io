/* ================================================================
   Halloween: the Halloween cards (25 Nov 2026, claude/halloween-design.md section 11)
   - a card for each of the 119 Halloween pups, the little pup in the bedsheet (Season Friend) and
     the nine unicorns in costume; on the Seasons shelf, one tab per island plus a 🎃 tab for the
     little pup, Marmalade and Conker;
   - stats and powers as on the main card (the saga's fixed scale); the everyday move gets a Halloween name;
   - the island's scene at dusk, a pumpkin and bat frame, a pumpkin badge, an autumn leaf edge, and the
     Halloween-only Candy finish (cardlook.js rolls it, letter c);
   - packs per area, orange with a pumpkin face; the Pup House and binder dusk look.
   Hooks: window.XCARDS, window.SEALOOK['h:'], window.SEAPACK.h_, CLOOK.EDGE.hw.
   ================================================================ */
(function(){
const HW=window.HW,HL=window.HLOOK,hp=HL.hp,X=()=>(state&&state.sx&&state.sx.hw)||{};
const HMOVE={herd:'Broomstick Dash',pull:'Broomstick Dash',snow:'Broomstick Dash',tug:'Broomstick Dash',rescue:'Broomstick Dash',dig:'Leaf Leap',giant:'Leaf Leap',sniff:'Pumpkin Pounce',point:'Pumpkin Pounce',truffle:'Pumpkin Pounce',
 zoom:'Bat Flap',spots:'Bat Flap',fetch:'Bat Flap',splash:'Bat Flap',guard:'Candy Crunch',yodel:'Candy Crunch',snore:'Candy Crunch',cuddle:'Spooky Spin',wiggle:'Spooky Spin',rainbow:'Spooky Spin',cloud:'Spooky Spin'};
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const HOW={look:'🎃 Found among the pumpkins',door:'🚪 Found behind a trick-or-treat door',carve:'🕯️ Found inside a carved pumpkin'};
const dstr=d=>d&&d>1e12?new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'';
const TM={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const hs=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;},cp=(v,a,b)=>Math.max(a,Math.min(b,v));
function hcard(p,set,n,of,isl){const C=window.CARDS,B=C.breedOf(p.breed),T=C.TY(p.type),z=SZ[B.sz]||SZ.m,sh=p.shiny||p.season?10:0,st={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  st[C.STATS[hs(p.id)%4][0]]+=1;for(const k in st)st[k]=cp(st[k],1,10);
  const c={stats:st,zoom:cp(z[0]+sh,30,120),moves:[[HMOVE[B.g]||'Bat Flap',1,z[1]],[TM[p.type]||'Pup Power',2,z[2]+sh]],col:T.col,bg:shade(T.col,.72)};
  Object.assign(c,{cid:'3:hw_'+p.id,game:3,set,n,of,src:p,base:p.id,name:p.name,breed:p.breed,type:p.type,rar:p.shiny||p.season?'sparkly':'common',fact:HL.FACT[p.id]||p.fact||'',hw:true,hisl:isl});
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return p.id==='conker'?'the Pumpkin Parade, Pawprint Village':(A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>HW.xFound(p.id);c.foundAt=()=>{const v=(X().found||{})[p.id];return typeof v==='number'?v:0;};
  c.art=an=>critterSVG(hp(p),{anim:an,sparkly:!!(p.shiny||p.season)});
  c.hint=()=>HW.opened()?`${p.name} is hiding in ${AREAS[p.area]?AREAS[p.area].name:'the village'} at Halloween. ${p.hint||''}`:'Halloween opens after Night Glow is finished!';
  c.back=()=>{const d=c.foundAt(),h=(X().how||{})[p.id];return [`🎃 Found at Halloween${d?' on '+dstr(d):''}`,`📍 ${c.home()}`,HOW[h]||'🎃 Found at Halloween','🍬 Ready for the Pumpkin Parade'];};
  return c;}
function unicard(I,set,n,of){const u=I.boss.uni,C=window.CARDS,T=C.TY(I.type);const c={cid:'3:hw_'+u.id,game:3,set,n,of,src:u,base:u.id,name:u.name,breed:u.breed,type:I.type,rar:'unicorn',uni:true,hw:true,hisl:I.id,
  fact:`${u.name}'s Halloween lesson: ${HW.LESSON[u.id]||'Every friend makes you braver.'}`,zoom:120,moves:[['Rainbow Gallop',1,30],['Brave Paw',3,100]],col:T.col,bg:'#f3e6ff',stats:{spd:9,brn:9,cud:10,brv:9}};
  c.home=()=>I.name;c.earned=()=>!!(X().bp||{})[I.id];c.foundAt=()=>(X().bp||{})[I.id]||0;c.art=an=>critterSVG(hp(u),{anim:an});
  c.hint=()=>`Find ${HW.NEED} Halloween pups on ${I.name}, and ${u.name} will give your little pup a Brave Paw.`;
  c.back=()=>{const d=c.foundAt();return [`🐾 Gave a Brave Paw${d?' on '+dstr(d):''}`,`🦄 ${I.name}`,`💬 ${HW.LESSON[u.id]||''}`];};return c;}
function palcard(set,n,of){const c={cid:'3:hw_pal',game:3,set,n,of,src:{id:'hwpal'},base:'hwpal',get name(){return HW.pal().name;},breed:'Puppy in a bedsheet',type:'star',rar:'friend',hw:true,hisl:'meadow',
  fact:'Being scared is your body trying to keep you safe. Being brave means feeling scared and going anyway, with a friend beside you.',zoom:100,moves:[['Tiny Boo',1,30],['Brave Paw',3,90]],col:'#9a7ad8',bg:'#f1eaff',stats:{spd:7,brn:8,cud:10,brv:9}};
  c.home=()=>'Pawprint Village';c.earned=()=>HW.named();c.foundAt=()=>HW.named()&&X().pal.at||0;c.art=()=>HW.palSVG().replace('<svg ','<svg class="pup" ');
  c.hint=()=>'Meet the little pup in the bedsheet when Halloween begins!';
  c.back=()=>[`🎃 Named by Seb${c.foundAt()?' on '+dstr(c.foundAt()):''}`,'📍 Pawprint Village, behind the biggest pumpkin',`🐾 ${HW.nBp()} of 9 Brave Paws`,X().done?'🏆 Won Bravest Costume at the Pumpkin Parade!':'🎃 Getting braver every day'];return c;}
/* the sets, one per island and a special one */
const SETS={};
function mkSet(key){if(SETS[key])return SETS[key];let S;const lock=()=>'Halloween opens after Night Glow is finished!';
  if(key==='hw'){const L=[];S={id:'3:h_hw',game:3,h:true,season:'hw',isl:'h_hw',name:'Halloween',short:'Halloween',icon:'🎃',open:()=>HW.opened(),lockSay:lock,cards:L};
    L.push(palcard(S.id,1,3),hcard(HL.HPUPS.marmalade,S.id,2,3,'meadow'),hcard(HL.HPUPS.conker,S.id,3,3,'meadow'));}
  else{const I=islandOf(key),P=HW.islX(I),of=P.length+1,L=P.map((p,i)=>hcard(p,'3:h_'+key,i+1,of,key));L.push(unicard(I,'3:h_'+key,of,of));
    S={id:'3:h_'+key,game:3,h:true,season:'hw',isl:'h_'+key,name:`${I.name} at Halloween`,short:I.name.split(' ')[0],icon:I.icon,open:()=>HW.opened(),lockSay:lock,cards:L};}
  return (SETS[key]=S);}
function entry(key){const I=key!=='hw'&&islandOf(key),pups=key==='hw'?[HL.HPUPS.marmalade,HL.HPUPS.conker]:HW.islX(I),areas=key==='hw'?['village','sunflowers']:I.areas.map(a=>a.id).filter(a=>HW.areaX(a).some(p=>pups.indexOf(p)>=0));
  const mine=cid=>cid.indexOf('3:hw_')===0&&(cid==='3:hw_pal'?key==='hw':cid==='3:hw_'+(I&&I.boss.uni.id)||pups.some(p=>cid==='3:hw_'+p.id));
  const inSet=a=>HW.areaX(a).filter(p=>pups.indexOf(p)>=0);
  return {isl:'h_'+key,season:'hw',keys:()=>areas.map(a=>'x:hw:'+(key==='hw'?'h'+a:a)),set:()=>mkSet(key),
    ids(){if(!state)return [];const out=pups.filter(p=>HW.xFound(p.id)).map(p=>'3:hw_'+p.id);if(key==='hw'&&HW.named())out.unshift('3:hw_pal');if(I&&(X().bp||{})[I.id])out.push('3:hw_'+I.boss.uni.id);return out;},
    key(cid){if(!mine(cid))return undefined;if(cid==='3:hw_pal')return null;const id=cid.slice(5),p=HW.gpup(id);return p?'x:hw:'+(key==='hw'?'h'+p.area:p.area):null;},
    done(k){const a=k.slice(5).replace(/^h(?=village|sunflowers)/,'');return inSet(a).every(p=>HW.xFound(p.id));},
    info(k){const a=k.slice(5).replace(/^h(?=village|sunflowers)/,''),A=AREAS[a];return {k,isl:'h_'+key,icon:key==='hw'?'🎃':(A&&A.icon)||'🎃',name:`${A?A.name:'Halloween'} at Halloween`,short:A?A.name:'Halloween',hw:true};},
    say(k,c){const a=k.slice(5).replace(/^h(?=village|sunflowers)/,''),A=AREAS[a],left=inSet(a).filter(p=>!HW.xFound(p.id)).length;return `${c.name}'s Halloween card is waiting in the ${A?A.name:''} pumpkin pack. Find ${left} more Halloween ${left>1?'pups':'pup'} there to open it!`;}};}
window.XCARDS=(window.XCARDS||[]).concat(['hw'].concat(ISLANDS.map(I=>I.id)).map(entry));

/* ---------------- the dusk look ---------------- */
const K=INK,GOLD='#ffd23f',ORNG='#ff8a1a';
const pk=(x,y,r,o)=>`<g opacity="${o}"><ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.8}" fill="${ORNG}"/><path d="M${x} ${y-r*.8} v-${r*.4}" stroke="#4a7a2a" stroke-width="${r*.25}"/></g>`;
const bat=(x,y,s,o)=>`<path d="M${x} ${y} l-${s*.6} -${s*.5} l-${s*1.2} ${s*.2} l${s*.4} ${s*.4} l-${s*.3} ${s*.5} l${s*.8} -${s*.2} Z M${x} ${y} l${s*.6} -${s*.5} l${s*1.2} ${s*.2} l-${s*.4} ${s*.4} l${s*.3} ${s*.5} l-${s*.8} -${s*.2} Z" fill="#3a2a50" opacity="${o}"/>`;
const PATH=`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">${pk(14,16,6,.55)}${pk(48,46,5,.5)}${bat(46,14,6,.55)}${bat(16,46,5,.45)}<circle cx="32" cy="30" r="1.6" fill="#fff" opacity=".5"/></svg>`;
function dusk(i){const R=seed(i.length*41+7);let s=`<rect width="200" height="190" fill="#3a2a6a" opacity=".42"/><rect width="200" height="70" fill="#ff8a4a" opacity=".18"/>`;
  for(let k=0;k<9;k++)s+=`<circle cx="${(R()*200).toFixed(1)}" cy="${(R()*55).toFixed(1)}" r="${(.6+R()*1).toFixed(1)}" fill="#fff" opacity="${(.5+R()*.4).toFixed(2)}"/>`;
  s+=`<circle cx="160" cy="40" r="22" fill="#ffb070" opacity=".22"/><circle cx="160" cy="40" r="15" fill="#ffc98a"/>`+bat(40,30,7,.85)+bat(70,18,5,.7);
  for(let k=0;k<4;k++){const x=(20+R()*160).toFixed(0);s+=`<g transform="translate(${x} ${(160+R()*20).toFixed(0)})">${pk(0,0,7+R()*3,1)}<path d="M-3 -1 l2 -2 l2 2 Z M1 -1 l2 -2 l2 2 Z M-3 2 q3 2 6 0" stroke="#ffd23f" stroke-width="1" fill="#ffd23f"/></g>`;}
  return s;}
const EDGEH=()=>{let s=`<path d="M0 0 H400 V14 Q200 30 0 14 Z" fill="#4b3a7a" opacity=".85"/>`;for(let x=26;x<390;x+=36)s+=pk(x,12,5,1);
  const LC=['#ff8a1a','#e8423a','#ffc21a','#c8641a'];let k=0;
  for(let y=50;y<540;y+=38){[7,393].forEach(x=>{s+=`<path class="twk" style="animation-delay:${(k%5)*.35}s" d="M${x} ${y-7} q6 4 0 14 q-6 -10 0 -14 Z" fill="${LC[k%4]}"/>`;k++;});}
  for(let x=30;x<380;x+=34){s+=`<path class="twk" style="animation-delay:${(k%5)*.35}s" d="M${x} 550 q6 4 0 14 q-6 -10 0 -14 Z" fill="${LC[k%4]}"/>`;k++;}
  return s+bat(18,28,9,1)+bat(382,28,9,1)+pk(16,546,8,1)+pk(384,546,8,1);};
if(window.CLOOK&&CLOOK.EDGE)CLOOK.EDGE.hw=EDGEH;
function packSVG(s){const n=s.n!=null?s.n:(s.cards||[]).length;const R=seed((s.icon||'').length*9+n);let st='';for(let k=0;k<8;k++)st+=bat(40+R()*120,80+R()*130,4+R()*3,.5);
  return `<svg viewBox="0 0 200 270" xmlns="http://www.w3.org/2000/svg"><rect x="20" y="20" width="160" height="236" rx="16" fill="#ff8a1a" stroke="#5b4636" stroke-width="5"/><rect x="20" y="20" width="160" height="60" rx="16" fill="#4b3a7a"/>${st}`+
  `<g class="hpump"><ellipse cx="100" cy="70" rx="36" ry="29" fill="#ffb040" stroke="#5b4636" stroke-width="3"/><path d="M84 64 l6 -8 l6 8 Z M104 64 l6 -8 l6 8 Z M82 76 Q100 92 118 76 Q100 84 82 76 Z" fill="#5a2a10"/><path d="M100 41 q-2 -8 6 -12" stroke="#4a7a2a" stroke-width="5" fill="none"/></g>`+
  `<circle cx="100" cy="150" r="36" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="166" text-anchor="middle" font-size="40">${s.icon||'🎃'}</text>`+
  `<rect x="34" y="214" width="132" height="34" rx="12" fill="#fff" stroke="#5b4636" stroke-width="4"/><text x="100" y="239" text-anchor="middle" font-size="21" font-weight="900" fill="#5b4636" font-family="Arial">${n} card${n===1?'':'s'}</text></svg>`;}
function openPack(P,pk2){HW.snd.knock();setTimeout(()=>{const b=pk2&&pk2.querySelector('.hpump');if(b)b.classList.add('pop');HW.snd.pop();},450);}
window.HCL={pat:()=>PATH,dusk,packSVG,open:openPack,hcard};
window.SEALOOK=Object.assign(window.SEALOOK||{},{'h:':{pat:()=>PATH,over:dusk,edge:'hw',badge:'🎃'}});
window.SEAPACK=Object.assign(window.SEAPACK||{},{h_:{packSVG,open:openPack}});

/* the dusk look for cards, the Pup House and the binder */
const LVS=(()=>{const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300">${[[40,50,'#ff8a1a'],[205,25,'#e8423a'],[150,150,'#ffc21a'],[265,205,'#c8641a'],[70,250,'#ff8a1a'],[115,80,'#ffc21a'],[250,110,'#e8423a'],[30,175,'#ffc21a'],[185,265,'#ff8a1a'],[95,205,'#e8423a']].map((q,i)=>`<path transform="rotate(${i*37} ${q[0]} ${q[1]})" d="M${q[0]} ${q[1]-10} q12 8 0 22 q-12 -14 0 -22 Z" fill="${q[2]}" opacity=".45"/>`).join('')}</svg>`;return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';})();
const css=document.createElement('style');css.textContent=`
.mc.fin-c,.tc.fin-c{box-shadow:0 0 0 2px #fff inset}.mc.fin-c .finsh,.tc.fin-c .finsh{background:repeating-linear-gradient(135deg,rgba(255,255,255,.0) 0 10px,rgba(255,178,32,.28) 10px 16px,rgba(255,122,26,.28) 16px 22px);animation:hCandy 3s linear infinite;background-size:200% 200%}
@keyframes hCandy{from{background-position:0 0}to{background-position:62px 0}}
.pq2pack .hpump{transform-origin:100px 70px;transition:transform .5s}.pq2pack .hpump.pop{transform:scale(1.4);filter:drop-shadow(0 0 10px #ffd23f)}
#book[data-sea=hw],#binder[data-sea=hw]{isolation:isolate}
#book[data-sea=hw]{background:linear-gradient(#f6e2ff,#ffd9b0)}#book[data-sea=hw] #bookH{color:#5a2a8a}
#binder[data-sea=hw]{background:#4b3a7a}#binder[data-sea=hw] .bcover{border-color:rgba(255,138,26,.6)}
#book[data-sea=hw]::before,#binder[data-sea=hw]::before{content:'';position:absolute;left:0;right:0;top:0;bottom:0;z-index:-1;background-image:${LVS};background-size:300px 300px;pointer-events:none;animation:hDrift 18s linear infinite}
@keyframes hDrift{from{background-position:0 0}to{background-position:60px 300px}}@media (prefers-reduced-motion:reduce){#book[data-sea=hw]::before,#binder[data-sea=hw]::before{animation:none}}
#book[data-sea=hw] .tab{opacity:1;background:#fff0e0}#book[data-sea=hw] .tab.sel{background:#ffc07a}#binder[data-sea=hw] #bdTabs .tab.sel{background:#ffc07a}`;
document.head.appendChild(css);
})();
