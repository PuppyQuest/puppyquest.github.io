/* ================================================================
   Puppy Quest saga file (saga step 8, 26 Nov 2026). Shared by every game and the website front page.
   Needs nothing else: load it first (before cards.js in a kit game).
   - SAGA.store: the saga store `pqSaga` (trophies, stars of the Great Dog, series badges, heroes), in the
     same storage as the games: shared on the website (one address for every game), separate in each
     claude.ai artifact. The Lab uses `lab_pqSaga`, so tests never touch Seb's.
   - SAGA.GAMES: the saga's games, their save keys and code prefixes. SAGA.readSave and SAGA.progress read
     another game's save on the website (the Card Passport's first step; backup codes are the fallback).
   - SAGA.BEATS, SAGA.TYPES, SAGA.SCALE: the Pup Type chart and the fixed stat scale for the whole saga.
     Each new series adds its type and rebalances by simulation (every type beats 2, is beaten by 2).
   - SAGA.DOG: the Great Dog from the real stars; SAGA.skySVG draws it with the restored stars lit.
   - SAGA.cupSVG: a times table trophy (none, bronze, silver, gold).
   ================================================================ */
(function(){
const LAB=!!window.LAB,KEY=(LAB?'lab_':'')+'pqSaga';
const fresh=()=>({v:1,trophies:{},stars:{},badges:{},heroes:{},seen:{}});
function load(){let j=null;try{j=JSON.parse(localStorage.getItem(KEY)||'null');}catch(e){}return Object.assign(fresh(),j&&j.v===1?j:{});}
function put(S){try{localStorage.setItem(KEY,JSON.stringify(S));}catch(e){}}
function edit(fn){const S=load();fn(S);put(S);return S;}

/* the saga's games: released ones have live:true; titles of later games stay a surprise */
const GAMES=[
  {id:'pq1',n:1,name:'Puppy Quest 1',sub:'The First Wish',path:'pq1/',save:'sebPuppyQuest1v1',code:'PQ1:',star:'wish',type:'star'},
  {id:'pq2',n:2,name:'Puppy Quest 2',sub:'Ninjas and Legends',path:'pq2/',save:'sebPuppyQuest2v1',code:'PQ2:',live:true},
  {id:'pq3',n:3,name:'Puppy Quest 3',sub:'Island Adventures',path:'pq3/',save:'sebPuppyQuest3v1',code:'PQ3:',live:true},
  {id:'pq4',n:4,star:'muliphein',type:'tide'},{id:'pq5',n:5,star:'furud',type:'pulse'},{id:'pq6',n:6,star:'aludra',type:'time'},
  {id:'pq7',n:7,star:'wezen',type:'myth'},{id:'pq8',n:8,star:'adhara',type:'storm'},{id:'pq9',n:9,star:'mirzam',type:'spook',snatch:true},
  {id:'pq10',n:10,star:'mirzam',type:'mirror'},{id:'pq11',n:11,star:'sirius',type:'cosmos'}];
GAMES.forEach(g=>{if(!g.name)g.name='Puppy Quest '+g.n;if(!g.save)g.save='sebPuppyQuest'+g.n+'v1';if(!g.code)g.code='PQ'+g.n+':';if(!g.path)g.path=g.id+'/';});
const game=id=>GAMES.find(g=>g.id===id)||null;
/* which game this page is: kit games set GAME; Puppy Quest 3 was built before the kit */
const ME=window.GAME&&GAME.id?{id:GAME.id,name:GAME.name||GAME.id}:{id:'pq3',name:'Puppy Quest 3'};

/* another game's save (website only: every game is at one address) */
function readSave(id,slot){const g=game(id);if(!g)return null;let j=null;
  try{j=JSON.parse(localStorage.getItem((LAB?'lab_':'')+g.save+(slot>1?'_h'+slot:''))||'null');}catch(e){}return j;}
function progress(id){const j=readSave(id);if(!j)return null;let found=0;
  if(j.L&&typeof j.L==='object')Object.values(j.L).forEach(l=>{found+=Object.keys((l&&l.found)||{}).length;});   /* Puppy Quest 2 keeps a save per level */
  else found=Object.keys(j.found||{}).length;
  return {found,stars:j.stars||0,buddy:j.buddy||null,started:!!(j.intro||found)};}

/* the Pup Type chart (from Puppy Quest 3, agreed 24 Nov 2026) and the fixed stat scale */
const TYPES={leaf:['Leaf','🍃'],water:['Water','💧'],fire:['Fire','🔥'],snow:['Snow','❄️'],sky:['Sky','☁️'],spark:['Spark','⚡'],star:['Star','⭐'],stone:['Stone','🪨'],comet:['Comet','☄️']};
const BEATS={fire:['leaf','comet'],water:['fire','stone'],leaf:['water','stone'],snow:['sky','spark'],spark:['water','star'],
  stone:['fire','spark'],sky:['star','leaf'],star:['snow','comet'],comet:['sky','snow']};
const SCALE={zoomies:[50,120],moves:[10,90],unicorn:100};

/* the Great Dog (Canis Major), from the real stars (as in Night Glow's star puzzle). Points 0 to 100.
   Order: θ, γ Muliphein, ι, α Sirius, β Mirzam, ζ Furud, ο2, δ Wezen, ε Adhara, η Aludra. */
const DOG={pts:[[50.9,6.5],[39.6,18],[48.6,22.6],[61.2,21],[86.9,25.5],[90,64.2],[40.6,44],[34.3,52],[45.6,60.7],[16.4,61.8]],
  names:['','muliphein','','sirius','mirzam','furud','','wezen','adhara','aludra'],
  edges:[[0,1],[1,2],[2,0],[2,3],[3,4],[4,5],[3,6],[6,7],[7,8],[7,9]],
  sil:[[66,13],[60,7],[52,6],[46,0],[42,8],[38,14],[44,24],[40,34],[33,44],[27,50],[15,60],[13,63],[22,60],[30,56],[36,60],[42,68],[50,68],[48,60],[52,48],[58,36],[70,30],[86,24],[92,25],[91,30],[84,31],[88,62],[92,66],[86,66],[80,60],[76,34],[64,32],[62,24],[64,18]],
  label:{sirius:'Sirius',mirzam:'Mirzam',muliphein:'Muliphein',wezen:'Wezen',adhara:'Adhara',furud:'Furud',aludra:'Aludra'}};
function skySVG(lit,o){o=o||{};lit=lit||{};const W=o.w||300,s=W/100,P=DOG.pts.map(p=>[p[0]*s,p[1]*s]),H=70*s;
  const spark=(x,y,r,c)=>`<path d="M${x} ${y-r} Q${x+r*.18} ${y-r*.18} ${x+r} ${y} Q${x+r*.18} ${y+r*.18} ${x} ${y+r} Q${x-r*.18} ${y+r*.18} ${x-r} ${y} Q${x-r*.18} ${y-r*.18} ${x} ${y-r}Z" fill="${c}"/>`;
  let g=`<path d="M${DOG.sil.map(q=>(q[0]*s).toFixed(1)+' '+(q[1]*s).toFixed(1)).join(' L')}Z" fill="${o.fill||'rgba(255,255,255,.18)'}" stroke="${o.line||'rgba(255,255,255,.45)'}" stroke-width="${1.2*s/3}" stroke-dasharray="${2*s/3} ${3*s/3}"/>`;
  g+=DOG.edges.map(e=>{const a=P[e[0]],b=P[e[1]],on=lit[DOG.names[e[0]]]&&lit[DOG.names[e[1]]];return `<path d="M${a[0].toFixed(1)} ${a[1].toFixed(1)} L${b[0].toFixed(1)} ${b[1].toFixed(1)}" stroke="${on?'#fff3b0':'rgba(255,255,255,.5)'}" stroke-width="${(on?1.6:1)*s/3}"/>`;}).join('');
  P.forEach((p,i)=>{const nm=DOG.names[i],on=!!lit[nm],big=nm==='sirius';
    if(on){g+=`<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="${(big?9:6)*s/3}" fill="#fff3b0" opacity=".45"/>`+spark(p[0],p[1],(big?8:5.5)*s/3,'#ffe066');}
    else g+=`<circle cx="${p[0].toFixed(1)}" cy="${p[1].toFixed(1)}" r="${(big?2.6:nm?2.1:1.5)*s/3}" fill="${nm?'#ffffff':'rgba(255,255,255,.7)'}" stroke="${o.ink||'#5b4636'}" stroke-width="${.8*s/3}"/>`;});
  return `<svg viewBox="0 0 ${W} ${H.toFixed(0)}" width="${W}" height="${H.toFixed(0)}" xmlns="http://www.w3.org/2000/svg" style="overflow:visible">${g}</svg>`;}

/* a times table trophy: lv 0 none yet, 1 bronze, 2 silver, 3 gold */
const CUP=[['#efe7dc','#d6cbbb'],['#d98c4a','#b06a2e'],['#d9dee6','#a9b2bf'],['#ffd23f','#e0a400']];
function cupSVG(lv,n,sz){sz=sz||100;const c=CUP[lv||0],k='#5b4636',none=!lv;
  return `<svg viewBox="0 0 100 112" width="${sz}" height="${(sz*1.12).toFixed(0)}" xmlns="http://www.w3.org/2000/svg"><g stroke="${k}" stroke-width="4.5" stroke-linejoin="round" stroke-linecap="round"${none?' stroke-dasharray="7 6" opacity=".75"':''}>
  <path d="M24 22 Q4 22 8 40 Q12 54 30 52" fill="none"/><path d="M76 22 Q96 22 92 40 Q88 54 70 52" fill="none"/>
  <path d="M20 12 H80 V32 Q80 64 50 66 Q20 64 20 32 Z" fill="${c[0]}"/><rect x="43" y="65" width="14" height="14" fill="${c[1]}"/>
  <rect x="28" y="78" width="44" height="12" rx="4" fill="${c[1]}"/><rect x="20" y="89" width="60" height="16" rx="5" fill="#a9774d"/></g>
  ${none?'':'<path d="M31 20 Q28 38 36 50" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".6"/>'}
  <text x="50" y="47" text-anchor="middle" font-family="ui-rounded,system-ui,sans-serif" font-weight="900" font-size="${String(n).length>1?26:30}" fill="${none?'#a89a88':k}">${n}</text></svg>`;}
const MEDAL=['Not yet','Bronze','Silver','Gold'];

window.SAGA={KEY,GAMES,game,ME,TYPES,BEATS,SCALE,DOG,skySVG,cupSVG,MEDAL,readSave,progress,
  load,edit,
  trophy(n){return +(load().trophies[n]||0);},
  trophies(){return Object.assign({},load().trophies);},
  setTrophy(n,lv){let up=false;edit(S=>{if((S.trophies[n]||0)<lv){S.trophies[n]=lv;up=true;}});return up;},
  stars(){return Object.assign({},load().stars);},
  lightStar(name){edit(S=>{if(!S.stars[name])S.stars[name]=Date.now();});},
  badge(id){edit(S=>{if(!S.badges[id])S.badges[id]=Date.now();});},
  badges(){return Object.assign({},load().badges);},
  setHero(gameId,slot,h){edit(S=>{S.heroes[gameId]=S.heroes[gameId]||{};S.heroes[gameId][slot||1]=h;});}};
})();
