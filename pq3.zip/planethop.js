/* ================================================================
   Planet Hop: Region 8 (Comet pups), reached by the rocket from the
   village launch pad. Every area is a tiny round planet with no edges
   (planet.js). Moon Base (start) opens Mars (after 2 pups) and Europa
   (needs the moon boots). Mars leads to the Solar Station (a launch
   code), Europa to Saturn's Rings (a Comet pup pulls the way clear).
   Both lead to the Black Hole (boss). Bonus: the Nebula Nursery off
   the Rings, through asteroid rubble a Stone pup from Dino Valley can
   dig through. Seb hops between planets in the Hopper.
   ================================================================ */
(function(){
const R=seed(8888),PL=96,H=PL/2,wd=d=>PLANET.wrapD(d,PL);
const PA=o=>Object.assign({planet:{L:PL,Rs:52,lowG:false},rect:{x1:-H,z1:-H,x2:H,z2:H},noHedge:true,noEnrich:true,camH:6.6,camD:12.5,fog:[500,900],sky:'#05061a'},o);
const face=(x,z)=>Math.atan2(-x,-z);
/* keep scenery clear of pups, pads, things and the start */
function keepList(A,extra){const k=[];(A.exits||[]).forEach(e=>k.push([e.x,e.z,7]));Object.values(PUPS).filter(p=>p.area===A.id).forEach(p=>{k.push([p.spot.x,p.spot.z,3.6]);if(p.tag)k.push([p.tag.x,p.tag.z,3.6]);});
  if(A.start)k.push([A.start[0],A.start[1],6]);(extra||[]).forEach(e=>k.push(e));return k;}
function free(x,z,k,r){return !k.some(q=>Math.hypot(wd(x-q[0]),wd(z-q[1]))<q[2]+r);}
function scatter(A,n,r,fn,extra,sd){const k=keepList(A,extra),Rn=seed(sd||n*31+7);let made=0;for(let t=0;t<n*6&&made<n;t++){const x=(Rn()-.5)*PL,z=(Rn()-.5)*PL;if(!free(x,z,k,r))continue;fn(x,z,Rn);made++;k.push([x,z,r]);}}
const rock=(x,z,s,c,Rn)=>{const y=gy(x,z);I('sph',c,1.2*s,.75*s,1*s,x,y+.25*s,z,0,(Rn?Rn():.5)*6,0);if(s>1.1)col(x,z,.9*s);};
const glowM=c=>{const m=new THREE.MeshBasicMaterial({color:c});W.disp.push(m);return m;};
const mixC=(L,cr,f)=>(x,z)=>{let k=f?f(x,z):(Math.sin(x*.31)*Math.sin(z*.27)+1)*.3;(cr||[]).forEach(c=>{const r=Math.hypot(wd(x-c[0]),wd(z-c[1]))/c[2];if(r<1)k=Math.max(k,.9-r*.5);});return k;};

/* ----------------- sky pictures only Planet Hop needs ----------------- */
const {cv,glow,ball,SKY}=PLANET;
SKY.olympus=()=>cv('olympus',512,128,(g)=>{g.fillStyle='rgba(150,80,50,.85)';g.beginPath();g.moveTo(0,128);g.bezierCurveTo(120,118,160,40,256,34);g.bezierCurveTo(352,40,392,118,512,128);g.fill();g.fillStyle='rgba(120,60,40,.6)';g.fillRect(226,30,60,8);});
SKY.marsSun=()=>cv('marssun',256,0,(g)=>{glow(g,128,128,10,128,'rgba(120,170,255,.85)');glow(g,128,128,6,60,'rgba(220,235,255,1)');ball(g,128,128,16,['#ffffff','#f4f8ff'],'#dfe8ff');});
SKY.io=()=>cv('io',128,0,(g)=>{ball(g,64,64,40,['#fff27a','#e8c040'],'#6a5010');g.fillStyle='#c9702a';[[50,50,6],[74,70,5],[60,80,4]].forEach(q=>{g.beginPath();g.arc(q[0],q[1],q[2],0,6.28);g.fill();});});

/* ----------------- props ----------------- */
function hamster3D(){const g=grp();mk('sph','#f4f6fb',.75,.85,.7,0,1,0,g);mk('sph','#e8a85a',.5,.48,.46,0,1.95,.02,g);[-1,1].forEach(s=>{mk('sph','#e8a85a',.15,.17,.08,s*.3,2.35,0,g);mk('sph','#26232e',.07,.08,.04,s*.17,2.02,.42,g);mk('cyl','#f4f6fb',.2,.6,.2,s*.62,1,.1,g).rotation.z=s*.5;mk('cyl','#c9d2e3',.2,.5,.2,s*.3,.25,0,g);});
  mk('sph','#ffffff',.25,.18,.15,0,1.84,.42,g);mk('sph','#ff9ecb',.07,.06,.05,0,1.92,.52,g);mk('box','#3d8fe0',.4,.3,.08,0,1.25,.68,g);const h=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#dff4ff',transparent:true,opacity:.28,depthWrite:false}));h.scale.setScalar(.72);h.position.set(0,2,0);g.add(h);W.disp.push(h.material);return g;}
function rover3D(){const g=grp();mk('box','#e8e2d8',2.2,.6,3.2,0,1.2,0,g);mk('box','#c9905f',1.6,.6,1.2,0,1.7,-.2,g);mk('box','#2b4a8a',2.8,.08,1.6,0,2.2,-.9,g);mk('cyl','#8a8f99',.08,1.6,.08,.8,2.3,1.1,g);mk('box','#e8e2d8',.5,.35,.4,.8,3.1,1.1,g);mk('sph','#26232e',.12,.12,.06,.8,3.1,1.32,g);
  const wh=[];[-1,1].forEach(s=>[-1.1,0,1.1].forEach(z=>{const w=mk('cyl','#3a3338',.42,.32,.42,s*1.25,.45,z,g);w.rotation.z=Math.PI/2;wh.push(w);}));g.userData.tick=(t,mv)=>{if(mv)wh.forEach(w=>{w.rotation.x+=.25;});g.children[0].position.y=1.2+(mv?Math.sin(t*20)*.04:0);};return g;}
regRide('rover',rover3D,1.15);
function bigRocket(x,z,s){s=s||1;const g=grp();mk('cyl','#f4f6fb',1.4*s,9*s,1.4*s,0,5.5*s,0,g);mk('cone','#e8423a',1.4*s,3*s,1.4*s,0,11.5*s,0,g);mk('cyl','#3d8fe0',1.45*s,.6*s,1.45*s,0,7*s,0,g);mk('cyl','#9bdcff',.5*s,.15*s,.5*s,0,8.5*s,1.35*s,g).rotation.x=Math.PI/2;
  [0,2.09,4.19].forEach(a=>{const f=mk('box','#e8423a',.2*s,3*s,2.2*s,Math.sin(a)*1.4*s,1.8*s,Math.cos(a)*1.4*s,g);f.rotation.y=a;});mk('cyl','#5b6378',1*s,1*s,1*s,0,.6*s,0,g);add(g,x,z);col(x,z,1.8*s);return g;}
function dome(x,z,r,c){const y=gy(x,z);const d=new THREE.Mesh(G.hemi,M(c||'#f4f6fb'));d.scale.set(r,r*.8,r);d.position.set(x,y-.1,z);W.ag.add(d);for(let i=0;i<8;i++){const a=i/8*6.283;I('sph','#9bdcff',.5,.35,.15,x+Math.cos(a)*r*.86,y+r*.32,z+Math.sin(a)*r*.86,0,-a+Math.PI/2,0);}
  I('cyl','#c9d2e3',r*1.05,.5,r*1.05,x,y+.2,z);col(x,z,r);camBlock(x-r,z-r,x+r,z+r);}
function antenna(x,z){const y=gy(x,z);I('cyl','#c9d2e3',.12,5,.12,x,y+2.5,z);const d=mk('hemi','#f4f6fb',1.4,.5,1.4,x,y+5.2,z);d.rotation.x=2.4;W.ag.add(d);I('sph','#e8423a',.2,.2,.2,x,y+5.4,z,0,0,0,true);col(x,z,.5);}
function flag(x,z){const y=gy(x,z);I('cyl','#c9d2e3',.07,3.4,.07,x,y+1.7,z);I('box','#3fae5a',1.4,.9,.05,x+.7,y+3,z);I('sph','#ffffff',.25,.25,.06,x+.7,y+3,z+.04);col(x,z,.3);}
function panels(x,z,rows,cols){const y=gy(x,z);for(let i=0;i<rows;i++)for(let j=0;j<cols;j++){const px=x+j*3.4,pz=z+i*4;I('box','#2b4a8a',3,.08,2.2,px,y+1.3,pz,-.5,0,0);I('box','#c9d2e3',3.1,.04,.08,px,y+1.32,pz,-.5,0,0);I('cyl','#8a8f99',.1,1.2,.1,px,y+.6,pz);col(px,pz,1.2);}}
function iceSpikes(x,z,c){const y=gy(x,z);for(let k=0;k<5;k++)I('cone',c||'#dff4ff',.5,1.6+k*.6,.5,x+(k-2)*.6,y+.8+k*.3,z+(k%2)*.5,0,0,(k-2)*.18);col(x,z,1.2);}
function geyser(x,z){const y=gy(x,z);I('cyl','#c9b89a',1,.4,1,x,y+.2,z);const m=new THREE.Mesh(G.cone,new THREE.MeshBasicMaterial({color:'#e8f6ff',transparent:true,opacity:.35,depthWrite:false}));m.scale.set(1.2,7,1.2);m.rotation.x=Math.PI;m.position.set(x,y+4,z);W.ag.add(m);W.disp.push(m.material);
  let t=R()*3;W.ticks.push(dt=>{t+=dt;const on=(t%6)<2.2;m.visible=on;m.scale.y=on?6+Math.sin(t*9):1;if(on&&Math.random()<dt*8)floatS(pick(['💧','❄️']),x+(Math.random()-.5),y+7,z,1,1.2);});col(x,z,1);}
function dustDevil(cx,cz,r){const m=new THREE.Mesh(G.cone,new THREE.MeshBasicMaterial({color:'#e0a070',transparent:true,opacity:.28,depthWrite:false}));m.scale.set(1.6,7,1.6);m.rotation.x=Math.PI;W.ag.add(m);W.disp.push(m.material);let a=R()*6;
  W.ticks.push(dt=>{a+=dt*.12;const x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r;m.position.set(x,gy(x,z)+3.5,z);m.rotation.y+=dt*6;});}
function floatChunks(A,n,c){scatter(A,n,1,(x,z,Rn)=>{const s=.6+Rn()*1.6,h=3+Rn()*10;I(Rn()<.5?'sph':'box',Rn()<.5?(c||'#e6eef5'):'#c9d6e6',s,s*.8,s,x,gy(x,z)+h,z,Rn()*3,Rn()*3,0);},[],77);}
function babyStars(cx,cz,n,r){const sp=[];for(let i=0;i<n;i++){const s=spr(pick(['⭐','🌟','✨']),1.2,cx,gy(cx,cz)+3,cz);sp.push({s,a:i/n*6.28,h:2+(i%3)});}
  W.ticks.push(dt=>{sp.forEach((o,i)=>{o.a+=dt*.4;const x=cx+Math.cos(o.a)*r,z=cz+Math.sin(o.a)*r;o.s.position.set(x,gy(x,z)+o.h+Math.sin(W.t*2+i)*.4,z);});});}
function nibbles(x,z,say){const g=hamster3D();add(g,x,z);col(x,z,1);const l=label('🐹 Captain Nibbles',5);l.position.set(x,gy(x,z)+4.2,z);W.ag.add(l);let k=0;
  W.ticks.push(()=>{g.rotation.y=Math.atan2(wd(player.x-x),wd(player.z-z));g.position.y=gy(x,z)+Math.abs(Math.sin(W.t*2.2))*.35;});
  W.things.push({x,z,r:4,icon:'💬',label:'Nibbles',act:()=>{sfx.chime();say(NIB[(k++)%NIB.length]);}});}
const NIB=['Captain Nibbles says: welcome to Moon Base! Squeak! The moon boots are in my locker, for low gravity on Europa.','Captain Nibbles says: hop pads take you from planet to planet. Find 2 pups here to power the one to Mars!','Captain Nibbles says: on the Moon you weigh about a sixth of what you weigh on Earth. Boing!','Captain Nibbles says: Comet pups can switch off gravity, so heavy things float away.','Captain Nibbles says: there is rubble near Saturn\'s Rings. A Stone pup from Dino Valley could dig through it!','Captain Nibbles says: Nebula the Galaxy Unicorn is waiting at the Black Hole. Be brave!'];

/* ----------------- the 12 Comet pups ----------------- */
const P=[
 {id:'luna',name:'Luna',breed:'Bolognese',area:'moon',pitch:1.4,spot:{x:-22,z:6,kind:'crater'},hint:'Look in a crater near Moon Base.',
  fact:'Bolognese dogs come from Bologna in Italy. Their fluffy white coat looks like a little cloud!',rescue:{icon:'🌙',verb:'Lift',say:'Luna has bounced into a crater! Tap to lift her out!'},
  look:{fur:'#ffffff',ears:'floppy',fluffy:true,wool:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',scale:.8,eyeWhite:true,acc:['twinkle']}},
 {id:'sputnik',name:'Sputnik',breed:'Schipperke',area:'moon',pitch:1.3,spot:{x:22,z:12,kind:'meteor'},tag:{x:-30,z:24,kind:'pod'},hint:'Sputnik plays tag. Look behind a meteor rock, then in an escape pod.',
  fact:'Schipperkes are little black dogs from Belgium. Long ago they rode on canal boats and kept watch.',rescue:{icon:'🛰️',verb:'Untangle',say:'Sputnik is tangled in a satellite cable! Tap to untangle him!'},
  look:{fur:'#26232e',ears:'pointy',fluffy:true,muzzle:'#3a3640',belly:'#3a3640',tail:'stub',scale:.8,eyeWhite:true,acc:['scarf'],scarfC:'#e8423a'}},
 {id:'rusty',name:'Rusty',breed:'Redbone Coonhound',area:'mars',pitch:.95,spot:{x:24,z:-12,kind:'boulder'},hint:'Look behind a big red boulder on Mars.',
  fact:'Redbone Coonhounds have shiny deep red coats, a bit like the red rocks on Mars!',rescue:{icon:'🪨',verb:'Dig',say:'Rusty is buried in red dust! Tap to dig him out!'},
  look:{fur:'#b5502a',ear:'#a04524',ears:'long',muzzle:'#a04524',belly:'#c4643a',tail:'thin',eyeWhite:true,collar:'#3d8fe0'}},
 {id:'rover',name:'Rover',breed:'Australian Kelpie',area:'mars',pitch:1.15,spot:{x:-22,z:10,kind:'crater'},tag:{x:12,z:-34,kind:'meteor'},hint:'Rover plays tag. Look in a crater, then behind a meteor rock.',
  fact:'Australian Kelpies are super sheepdogs. They can even run across the backs of the sheep!',rescue:{icon:'🌪️',verb:'Catch',say:'Rover is spinning in a dust devil! Tap to catch him!'},
  look:{fur:'#6b4a32',ears:'pointy',muzzle:'#c98a5a',belly:'#c98a5a',brows:'#c98a5a',paw:'#c98a5a',tail:'plume'}},
 {id:'cosmo',name:'Cosmo',breed:'Borzoi',area:'europa',pitch:.9,spot:{x:-20,z:-14,kind:'crystal'},hint:'Look by the ice crystals on Europa.',
  fact:'Borzois are tall, silky hounds from Russia. They are gentle at home and amazingly fast outside!',rescue:{icon:'🧊',verb:'Melt',say:'Cosmo is frozen in an ice cave! Tap to melt the ice!'},
  look:{fur:'#f4efe6',ears:'fold',fluffy:true,patch:{c:'#c9a06a',side:1},muzzle:'#f4efe6',belly:'#ffffff',tail:'plume',hw:44,hh:58,scale:1.08}},
 {id:'astra',name:'Astra',breed:'Silken Windhound',area:'europa',pitch:1.1,spot:{x:22,z:16,kind:'pod'},tag:{x:-26,z:28,kind:'crystal'},hint:'Astra plays tag. Look in an escape pod, then by the ice crystals.',
  fact:'Silken Windhounds are speedy hounds with soft, silky coats. They were first bred in America in the 1980s.',rescue:{icon:'💨',verb:'Fan',say:'Astra is stuck in a geyser\'s spray! Tap to fan the mist away!'},
  look:{fur:'#d9c8b0',ears:'fold',fluffy:true,muzzle:'#e8dcc8',belly:'#f2e8d8',tail:'plume',hw:46,hh:54}},
 {id:'saturn',name:'Saturn',breed:'Clumber Spaniel',area:'rings',pitch:.9,spot:{x:-16,z:18,kind:'meteor'},hint:'Look behind an icy rock in Saturn\'s Rings.',
  fact:'Clumber Spaniels are big, gentle spaniels from England, with white coats and lemon or orange markings.',rescue:{icon:'💫',verb:'Lift',say:'Saturn is wedged between two ice chunks! Tap to lift him free!'},
  look:{fur:'#ffffff',ear:'#e8b04a',ears:'floppy',patch:{c:'#e8b04a',side:1},muzzle:'#ffffff',belly:'#ffffff',tail:'stub',bw:46,bh:36,eyeWhite:true}},
 {id:'halley',name:'Halley',breed:'Löwchen',area:'rings',pitch:1.4,spot:{x:24,z:4,kind:'crystal'},tag:{x:-30,z:10,kind:'pod'},hint:'Halley plays tag. Look by the ice crystals, then in an escape pod.',
  fact:'Löwchen means little lion in German. Some have their fur clipped to look like a tiny lion!',rescue:{icon:'🧊',verb:'Polish',say:'Halley is hiding inside a frosty ice chunk! Tap to polish it clear!'},
  look:{fur:'#f2d6a0',ears:'floppy',fluffy:true,muzzle:'#f7e4c0',belly:'#f7e4c0',tail:'pom',scale:.8,acc:['bow']}},
 {id:'solar',name:'Solar',breed:'Azawakh',area:'station',pitch:1,spot:{x:-12,z:26,kind:'satellite'},hint:'Look behind a satellite dish at the Solar Station.',
  fact:'Azawakhs come from the hot Sahara desert in Africa. They are slim, fast and love warm sunshine.',rescue:{icon:'☀️',verb:'Shade',say:'Solar is snoozing in the sunshine! Tap to shade him and wake him up!'},
  look:{fur:'#e0a85a',ears:'fold',muzzle:'#c98a4a',belly:'#f2d0a0',paw:'#ffffff',tail:'thin',hw:44,hh:54,bw:30,bh:44}},
 {id:'zoom',name:'Zoom',breed:'Miniature Pinscher',area:'station',pitch:1.5,spot:{x:18,z:-18,kind:'pod'},tag:{x:30,z:22,kind:'satellite'},hint:'Zoom plays tag. Look in an escape pod, then behind a satellite dish.',
  fact:'Miniature Pinschers are tiny but bold. They lift their feet high when they trot, like a little pony!',rescue:{icon:'🔋',verb:'Unplug',say:'Zoom is tangled in the charging cables! Tap to unplug them!'},
  look:{fur:'#2b2326',ears:'pointy',muzzle:'#b5642a',belly:'#b5642a',brows:'#b5642a',paw:'#b5642a',tail:'stub',scale:.7,eyeWhite:true}},
 {id:'speckle',name:'Speckle',breed:'Bluetick Coonhound',area:'blackhole',pitch:.95,spot:{x:-18,z:-14,kind:'crystal'},hint:'Look by the glowing crystals near the Black Hole.',
  fact:'Bluetick Coonhounds have coats covered in dark blue speckles, like a starry night sky!',rescue:{icon:'🌀',verb:'Hold',say:'Speckle is wobbling in the swirly wind! Tap to hold on to her!'},
  look:{fur:'#e6e9f2',spots:true,spotC:'#2c3a5a',ear:'#26232e',ears:'long',patch:{c:'#26232e'},muzzle:'#c98a4a',belly:'#e6e9f2',tail:'thin',eyeWhite:true}},
 {id:'rocket',name:'Rocket',breed:'Pumi',area:'blackhole',pitch:1.2,spot:{x:22,z:8,kind:'meteor'},tag:{x:-6,z:-32,kind:'pod'},hint:'Rocket plays tag. Look behind a space rock, then in an escape pod.',
  fact:'Pumis are curly herding dogs from Hungary. Their ears stand up and flop over at the tips!',rescue:{icon:'🚀',verb:'Land',say:'Rocket is zooming round and round! Tap to help her land!'},
  look:{fur:'#7a7f88',fluffy:true,wool:true,ears:'fold',muzzle:'#7a7f88',belly:'#8a8f99',tail:'curl',scale:.85}}];
const STARDUST={id:'stardust',name:'Stardust',breed:'Biewer Terrier',area:'nebula',pitch:1.5,spot:{x:-10,z:-8,kind:'crystal'},hint:'A sparkly pup is hiding in the Nebula Nursery.',
  fact:'Stardust is a sparkly pup! Biewer Terriers are little long-haired dogs from Germany with white, black and gold coats. You found a secret pup!',rescue:{icon:'✨',verb:'Twinkle',say:'Stardust is hiding in a cloud of baby stars! Tap to make them twinkle!'},
  look:{fur:'#ffffff',ear:'#26232e',ears:'long',fluffy:true,patch:{c:'#26232e'},muzzle:'#f2d6a0',belly:'#ffffff',tail:'plume',scale:.75,acc:['twinkle','bow']}};
const NEBULA={id:'nebulauni',name:'Nebula',breed:'Galaxy Unicorn',uni:true,lv:1,pitch:1.15,fact:'Nebula the Galaxy Unicorn has a coat full of tiny stars, and her mane streams out like a comet.',
  look:{fur:'#3a2f7a',ears:'side',earIn:'#c9b6ff',spots:true,spotCs:['#ffffff','#fff27a','#9be8ff'],muzzle:'#5a4a9a',belly:'#5a4a9a',nose:'#1a1440',iris:'#ffd23f',limbs:'hooves',hoofC:'#c9b6ff',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','twinkle'],scale:.98}};

/* ----------------- the planets ----------------- */
const hop=(o)=>Object.assign({noArch:true,noLabel:true,hop:true,ride:['🚀',`Hop! Off to ${o.name}!`]},o);
const moonCr=[[-22,6,5,1.4],[14,30,8,2],[-34,-34,9,2.2],[34,-6,6,1.6],[-6,-36,5,1.2],[30,34,4,1]];
const moon=PA({id:'moon',name:'Moon Base',icon:'🌙',planet:{L:PL,Rs:52,lowG:true},start:[0,10,Math.PI],ground:'#cfd2da',ground2:'#8e929c',
  hf:planetHF(PL,[[.5,2,1],[.35,3,2,1],[.25,5,4,2]],moonCr),gmix:mixC(PL,moonCr),
  light:{sky:'#cfd6ff',gr:'#2a2a44',hi:.64,dir:'#fffaf0',di:.78,pos:[-60,70,60]},
  space:{band:40,items:[{k:'earth',az:-90,el:0,size:170},{k:'sun',az:140,el:4,size:110}]},
  hello:'Welcome to Planet Hop! This is Moon Base. On the Moon you can bounce! Two pups are hiding here.',how:'Take the rocket from the launch pad in the village.',
  exits:[hop({x:-26,z:-22,to:'mars',arrive:[0,16,Math.PI],name:'Mars',icon:'🔴',col:'#ff8a5a',open:()=>foundIn(areaPups('moon'))>=2,lock:()=>{const n=foundIn(areaPups('moon'));return `The Hopper to Mars needs power. Find ${2-n} more ${2-n>1?'pups':'pup'} at Moon Base!`;}}),
    hop({x:26,z:-22,to:'europa',arrive:[0,16,Math.PI],name:'Europa',icon:'🧊',col:'#9be8ff',open:()=>!!state.gear.moonboots,lock:'Europa is very slippery! You need moon boots. Ask Captain Nibbles about his locker.'})],
  build(){dome(0,-16,6);dome(-12,-24,3.4,'#e6e9f2');antenna(10,-22);flag(-4,-6);flag(4,-6);
    bigRocket(12,24,.8);const l=label('🚀 Rocket home',5);l.position.set(12,gy(12,24)+12,24);W.ag.add(l);W.things.push({x:9,z:19,r:4.2,icon:'🏡',label:'Go home',act:goHome});
    nibbles(-6,-8);
    {const x=-12,z=-12,y=gy(x,z),bt=grp();I('box','#c9d2e3',2.2,3.2,1.2,x,y+1.6,z);I('box','#5b6378',2,.1,1.25,x,y+2.4,z);mk('box','#3fae5a',.5,.5,.9,-.3,0,0,bt);mk('box','#3fae5a',.5,.5,.9,.3,0,0,bt);add(bt,x,z+1,y+3.6);bt.visible=!state.gear.moonboots;col(x,z,1.3);
      W.ticks.push(()=>{bt.rotation.y+=.03;});W.things.push({x,z:z+2.6,r:3.4,icon:'🥾',label:'Moon boots',show:()=>!state.gear.moonboots,act:()=>{state.gear.moonboots=true;state.stars+=5;save();hud();bt.visible=false;sfx.jingle();confetti(30);
        card({art:'<div style="font-size:110px;line-height:1">🥾</div>',h:'You found moon boots!',p:'Now you can hop to icy Europa. Its hop pad is on the right of Moon Base!'});}});}
    sign(-14,8,'🪨 Moon Rock Bounce',3,6.5);W.things.push({x:-14,z:6,r:4,icon:'🪨',label:'Moon rocks',act:()=>{sfx.chime();startCollect('moonrocks');}});
    for(let i=0;i<14;i++){const z=6-i*2.2;I('box','#9a9ea8',.35,.04,.6,-.5+(i%2),gy(0,z)+.03,z);}
    scatter(this,70,1.4,(x,z,Rn)=>rock(x,z,.4+Rn()*1.6,pick(['#9a9ea8','#b9bcc6','#7a7e88']),Rn),[[12,24,4],[-12,-12,3],[-14,7,3],[0,-16,8]],11);}});
const marsCr=[[-22,10,6,1.6],[30,30,9,2],[-34,-30,8,2],[8,-40,5,1.2]];
const mars=PA({id:'mars',name:'Mars',icon:'🔴',start:[0,16,Math.PI],ground:'#c4643a',ground2:'#8a3f22',sky:'#d9a074',fog:[60,240],fogC:'#e3b58a',
  hf:planetHF(PL,[[.8,2,1],[.5,3,2,1.3],[.3,6,5]],marsCr),gmix:mixC(PL,marsCr,(x,z)=>(Math.sin(x*.21+z*.07)*Math.sin(z*.19)+1)*.35),
  light:{sky:'#ffe0c4',gr:'#6a3020',hi:.62,dir:'#ffe6cc',di:.7,pos:[60,40,-80]},
  space:{stars:false,items:[{k:'marsSun',az:-60,el:-6,size:90},{k:'moonlet',key:'phobos',az:-120,el:4,size:34},{k:'moonlet',key:'deimos',c:'#a89a8a',az:40,el:8,size:20}]},
  hello:'Mars, the red planet! The dust is rusty red, and look: the sunset here is blue! Two pups are hiding.',how:'Find 2 pups at Moon Base, then take the Hopper.',
  exits:[hop({x:0,z:34,to:'moon',arrive:[-16,-10,face(-16,-10)],name:'Moon Base',icon:'🌙'}),
    hop({x:0,z:-28,to:'station',arrive:[0,16,Math.PI],name:'Solar Station',icon:'☀️',col:'#ffd23f',nlock:{key:'nl_station',kind:['add','take','times'],n:3,done:'Beep! Launch code accepted! The Hopper to the Solar Station is ready!'}})],
  build(){const rv=rover3D();rv.position.set(-12,gy(-12,-6),-6);rv.rotation.y=.8;W.ag.add(rv);col(-12,-6,2);sign(-16,-2,'🚙 Rover Rally',3,5.5);
    W.things.push({x:-14,z:-2,r:4.2,icon:'🚙',label:'Rover Rally',act:()=>{sfx.chime();startCollect('roverrally');}});
    {const x=14,z=4,y=gy(x,z),g=grp();mk('cyl','#e8e2d8',2,1.2,2,0,2.4,0,g);mk('cone','#c9c2b8',2,1,2,0,3.5,0,g);[0,2.09,4.19].forEach(a=>{const l=mk('cyl','#8a8f99',.1,2.6,.1,Math.sin(a)*1.6,1.1,Math.cos(a)*1.6,g);l.rotation.set(Math.cos(a)*.45,0,-Math.sin(a)*.45);});add(g,x,z,y);col(x,z,2);}
    dustDevil(10,-10,14);dustDevil(-20,24,10);
    scatter(this,80,1.4,(x,z,Rn)=>rock(x,z,.4+Rn()*1.8,pick(['#8a3f22','#a8502c','#6b3220','#b5683f']),Rn),[[-12,-6,4],[14,4,4],[-15,-2,3]],21);}});
const euCr=[[30,-30,7,1.2],[-34,26,6,1]];
const crack=(x,z)=>{const a=Math.abs(Math.sin(x*.18+Math.sin(z*.05)*2)),b=Math.abs(Math.sin(z*.16+x*.04)),c=Math.abs(Math.sin((x+z)*.12));return Math.max(a<.06?1:0,b<.05?1:0,c<.04?1:0)*.9;};
const europa=PA({id:'europa',name:'Europa',icon:'🧊',planet:{L:PL,Rs:52,lowG:true},start:[0,16,Math.PI],ground:'#f2eadb',ground2:'#9a5a3a',
  hf:planetHF(PL,[[.4,2,2],[.3,4,3,1],[.15,7,6]],euCr),gmix:crack,
  light:{sky:'#ffe8d0',gr:'#4a3a40',hi:.62,dir:'#fff2dc',di:.75,pos:[-80,60,-40]},
  space:{band:120,items:[{k:'jupiter',az:-90,el:4,size:400},{k:'io',az:-40,el:6,size:30},{k:'sun',az:150,el:6,size:44}]},
  hello:'Europa, one of Jupiter\'s moons! It is covered in ice, and under the ice there may be a hidden ocean. Two pups are hiding.',how:'Put on the moon boots from Moon Base.',
  exits:[hop({x:0,z:34,to:'moon',arrive:[16,-10,face(16,-10)],name:'Moon Base',icon:'🌙'}),
    hop({x:0,z:-28,to:'rings',arrive:[0,16,Math.PI],name:'Saturn\'s Rings',icon:'🪐',col:'#ffd27a',gate:{type:'comet',key:'rings_float',look:'floatrock',verb:'switches off gravity, and the giant ice rock floats off the hop pad',done:'Whoosh! The ice rock floats away into space. The Hopper to Saturn\'s Rings is free!'},lock:'A giant ice rock is sitting on the hop pad to Saturn\'s Rings. A Comet pup could float it away!'})],
  build(){geyser(-14,-2);geyser(16,-8);geyser(14,30);[[-24,-20],[18,18],[-30,8],[30,-4],[-6,-36]].forEach(p=>iceSpikes(p[0],p[1]));
    sign(12,10,'🪐 Space Quiz',3,5.5);W.things.push({x:12,z:8,r:4,icon:'🪐',label:'Space Quiz',act:()=>{sfx.chime();startQuiz('activity','spacequiz');}});
    scatter(this,60,1.2,(x,z,Rn)=>{Rn()<.35?iceSpikes(x,z,pick(['#dff4ff','#f4fbff','#c9e8ff'])):rock(x,z,.4+Rn()*1.2,pick(['#e8dcc4','#d6c8ae']),Rn);},[[12,9,3]],31);}});
const rings=PA({id:'rings',name:'Saturn\'s Rings',icon:'🪐',planet:{L:PL,Rs:52,lowG:true},start:[0,16,Math.PI],ground:'#dfe8f2',ground2:'#a9b8cc',
  hf:planetHF(PL,[[.9,3,2],[.6,5,4,1],[.3,8,7,2]],[]),gmix:(x,z)=>(Math.sin(x*.4)*Math.sin(z*.37)+1)*.4,
  light:{sky:'#fff2d6',gr:'#30344a',hi:.62,dir:'#fff6e6',di:.78,pos:[70,50,-60]},
  space:{band:60,items:[{k:'saturn',az:-90,el:-1,size:560},{k:'sun',az:40,el:7,size:40}]},
  hello:'Saturn\'s Rings! You are walking on giant chunks of ice and rock that circle round Saturn. Two pups are hiding.',how:'A Comet pup floats the ice rock off the hop pad on Europa.',
  exits:[hop({x:0,z:34,to:'europa',arrive:[0,-16,0],name:'Europa',icon:'🧊'}),
    hop({x:-24,z:-24,to:'blackhole',arrive:[-14,10,face(-14,10)],name:'The Black Hole',icon:'🌀',col:'#c9b6ff',open:()=>foundIn(areaPups('rings'))>=2,lock:()=>{const n=foundIn(areaPups('rings'));return `The Hopper to the Black Hole needs power. Find ${2-n} more ${2-n>1?'pups':'pup'} on Saturn's Rings!`;}}),
    hop({x:26,z:-20,to:'nebula',arrive:[0,14,Math.PI],name:'Nebula Nursery',icon:'🌸',col:'#ff9ecb',gate:{type:'stone',key:'neb_rubble',look:'rockfall',need:0,verb:'digs through the asteroid rubble',done:'Dig, dig, dig! The rubble is cleared. The Hopper to the Nebula Nursery is free!'},lock:'Asteroid rubble covers the hop pad to the Nebula Nursery. A Stone pup from Dino Valley could dig through it!'})],
  build(){floatChunks(this,90);scatter(this,70,1.4,(x,z,Rn)=>{const s=.8+Rn()*2,y=gy(x,z);I(Rn()<.5?'box':'sph',pick(['#e6eef5','#c9d6e6','#f4f8ff']),s*1.4,s*.7,s,x,y+.3*s,z,Rn()*.4,Rn()*3,Rn()*.4);col(x,z,.8*s);},[[0,10,3]],41);
    sign(4,10,'💫 Ring Steps',3,5);W.things.push({x:4,z:8,r:4,icon:'💫',label:'Ring Steps',act:()=>{sfx.chime();startStones('activity','ringsteps');}});}});
const station=PA({id:'station',name:'Solar Station',icon:'☀️',start:[0,16,Math.PI],ground:'#eadcb8',ground2:'#c9b48a',
  hf:planetHF(PL,[[.6,2,2],[.4,4,3,2]],[[24,26,6,1.2],[-30,-30,7,1.4]]),gmix:(x,z)=>(Math.sin(x*.25)*Math.sin(z*.23)+1)*.35,
  light:{sky:'#fff2cc',gr:'#6a5030',hi:.72,dir:'#fff0c0',di:.85,pos:[0,40,-90]},
  space:{band:150,items:[{k:'sun',az:-90,el:0,size:440}]},
  hello:'The Solar Station, close to the Sun! Its solar panels turn sunshine into electricity. Two pups are hiding.',how:'Crack the launch code on Mars.',
  exits:[hop({x:0,z:34,to:'mars',arrive:[0,-16,0],name:'Mars',icon:'🔴'}),
    hop({x:0,z:-28,to:'blackhole',arrive:[14,10,face(14,10)],name:'The Black Hole',icon:'🌀',col:'#c9b6ff',open:()=>foundIn(areaPups('station'))>=2,lock:()=>{const n=foundIn(areaPups('station'));return `The Hopper to the Black Hole needs power. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Solar Station!`;}})],
  build(){panels(-30,-10,3,4);panels(16,-14,3,4);panels(-34,18,2,5);dome(18,14,5,'#ffd27a');antenna(26,8);
    {const x=-6,z=-4,y=gy(x,z);I('cyl','#c9d2e3',.3,3,.3,x,y+1.5,z);const d=mk('hemi','#f4f6fb',2.4,.8,2.4,x,y+3.4,z);d.rotation.x=-2.2;W.ag.add(d);col(x,z,1);}
    sign(8,10,'☀️ Sunbeam Catch',3,6);W.things.push({x:8,z:8,r:4,icon:'☀️',label:'Sunbeams',act:()=>{sfx.chime();startFlies('activity','sunbeams');}});
    scatter(this,50,1.3,(x,z,Rn)=>rock(x,z,.4+Rn()*1.4,pick(['#c9b48a','#b59a6a','#a08060']),Rn),[[-24,-6,10],[22,-10,10],[-27,20,9],[18,14,6],[8,9,3]],51);}});
const holeCr=[[0,-14,10,1.2],[-30,30,7,1.4],[34,-36,6,1.2]];
const blackhole=PA({id:'blackhole',name:'The Black Hole',icon:'🌀',start:[-14,10,face(-14,10)],ground:'#3a2a5a',ground2:'#7a3fb0',sky:'#07020f',
  hf:planetHF(PL,[[.7,2,1],[.5,3,3,1]],holeCr),gmix:(x,z)=>{const v=Math.abs(Math.sin(x*.15+Math.sin(z*.1)*2.4));return v<.08?1:.15+(Math.sin(z*.3)+1)*.1;},
  light:{sky:'#c9a8ff',gr:'#2a1040',hi:.6,dir:'#ffd6a0',di:.7,pos:[0,30,-90]},
  space:{band:20,starTint:'#e0c8ff',items:[{k:'hole',az:-90,el:-3,size:760},{k:'neb',c1:'rgba(200,80,255,.7)',c2:'rgba(80,120,255,.7)',key:'bh1',az:-30,el:6,size:420,op:.6},{k:'neb',c1:'rgba(255,90,170,.7)',c2:'rgba(255,190,90,.6)',key:'bh2',az:-150,el:3,size:380,op:.5}]},
  hello:'The edge of the galaxy, by a giant black hole! Its swirling disc glows gold and purple. Two pups are hiding here.',how:'Find 2 pups on Saturn\'s Rings or at the Solar Station.',
  exits:[hop({x:-26,z:22,to:'rings',arrive:[-14,-14,face(-14,-14)],name:'Saturn\'s Rings',icon:'🪐'}),hop({x:26,z:22,to:'station',arrive:[0,-16,0],name:'Solar Station',icon:'☀️'})],
  build(){[[-30,-6],[24,-20],[-14,30],[34,6],[8,34],[-36,-30]].forEach((p,i)=>{const y=gy(p[0],p[1]),c=['#ff5fa8','#c9b6ff','#7fe0ff'][i%3];for(let k=0;k<4;k++){const m=new THREE.Mesh(G.cone,glowM(c));m.scale.set(.5,1.6+k*.7,.5);m.position.set(p[0]+(k-1.5)*.6,y+.8+k*.3,p[1]+(k%2)*.5);m.rotation.z=(k-1.5)*.2;W.ag.add(m);}col(p[0],p[1],1.2);});
    floatChunks(this,40,'#5a4a7a');scatter(this,50,1.3,(x,z,Rn)=>rock(x,z,.5+Rn()*1.5,pick(['#2a2040','#4a3a6a','#3a2a5a']),Rn),[[0,-14,10],[2,12,3]],61);
    sign(2,12,'⭐ Star Rescue',3,5.5);W.things.push({x:2,z:10,r:4,icon:'⭐',label:'Star Rescue',act:()=>{sfx.chime();startHerd('activity','starrescue');}});
    babyStars(0,-14,7,7);}});
const nebula=PA({id:'nebula',name:'Nebula Nursery',icon:'🌸',start:[0,14,Math.PI],ground:'#f4d6ec',ground2:'#bfe8ee',sky:'#120a24',
  hf:planetHF(PL,[[.8,2,2],[.5,3,4,1]],[]),gmix:(x,z)=>(Math.sin(x*.2+z*.1)+1)*.5,
  light:{sky:'#ffe0f4',gr:'#3a2a5a',hi:.75,dir:'#ffffff',di:.55,pos:[40,80,30]},
  space:{band:90,starTint:'#ffd6f0',items:[{k:'neb',c1:'rgba(255,150,210,.8)',c2:'rgba(120,230,220,.7)',key:'n1',az:-90,el:2,size:520,op:.8},{k:'neb',c1:'rgba(180,140,255,.8)',c2:'rgba(255,200,240,.7)',key:'n2',az:60,el:5,size:460,op:.7},{k:'neb',c1:'rgba(120,230,220,.7)',c2:'rgba(255,240,180,.6)',key:'n3',az:170,el:0,size:420,op:.6}]},
  hello:'The Nebula Nursery! Colourful clouds of gas and dust, where new stars are born. A secret sparkly pup and a treasure chest are hidden here!',how:'A Stone pup from Dino Valley digs through the rubble on Saturn\'s Rings.',
  exits:[hop({x:0,z:32,to:'rings',arrive:[16,-12,face(16,-12)],name:'Saturn\'s Rings',icon:'🪐'})],
  build(){scatter(this,60,2,(x,z,Rn)=>{const s=1+Rn()*2.4;I('sph',pick(['#ffc8e8','#c8f0f0','#e8d8ff','#fff0c8']),s,s*.8,s,x,gy(x,z)+s*.5+Rn()*3,z);},[[8,-6,4]],71);
    babyStars(0,0,10,10);babyStars(-20,-20,6,5);treasureChest(8,-6,'nebula');}});

/* ----------------- activities ----------------- */
const spaceBG=(c)=>()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="${c||'#0b1030'}"/>`;for(let i=0;i<70;i++)s+=`<circle cx="${(i*173)%1010+7}" cy="${(i*97)%760}" r="${1+i%3}" fill="#fff" opacity="${.4+(i%3)*.2}"/>`;return s+'</svg>';};
const ringsSVG=()=>spaceBG('#0a1440')().replace('</svg>',`<ellipse cx="512" cy="-60" rx="700" ry="200" fill="none" stroke="#e8c06a" stroke-width="40" opacity=".5"/><circle cx="512" cy="-160" r="200" fill="#f0d080" opacity=".8"/><text x="964" y="140" font-size="44" text-anchor="middle">🪐</text></svg>`);
const sunSVG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#ffe9a8"/><circle cx="512" cy="40" r="220" fill="#ffd23f" opacity=".9"/><circle cx="512" cy="40" r="300" fill="#ffb347" opacity=".25"/>`;for(let i=0;i<6;i++)s+=`<rect x="${40+i*165}" y="600" width="140" height="70" rx="6" fill="#2b4a8a" stroke="${INK}" stroke-width="4" transform="skewX(-12)"/>`;return s+'</svg>';};
const nurseryPen=()=>{let s=spaceBG('#1a0a30')().replace('</svg>','');return s+penBox2('⭐ Star nursery','#3a2a6a','#c9b6ff','#7a5ad6')+'</svg>';};
function babyStarSVG(){const k=INK;return `<svg viewBox="0 0 90 90"><path d="M45 6 L56 33 L85 35 L62 53 L70 82 L45 66 L20 82 L28 53 L5 35 L34 33 Z" fill="#ffe066" stroke="${k}" stroke-width="4" stroke-linejoin="round"/><circle cx="37" cy="44" r="4" fill="${k}"/><circle cx="53" cy="44" r="4" fill="${k}"/><path d="M38 54 Q45 60 52 54" fill="none" stroke="${k}" stroke-width="3" stroke-linecap="round"/><circle cx="31" cy="52" r="4" fill="#ff9ecb" opacity=".7"/><circle cx="59" cy="52" r="4" fill="#ff9ecb" opacity=".7"/></svg>`;}
const planetPic=e=>`<div style="font-size:110px;line-height:1">${e}</div>`;
COLLECT.moonrocks={k:'moonrocks',area:'moon',icon:'🪨',size:2,items:[[-12,-30],[16,-4],[-30,4],[30,30],[-6,34],[34,-36]],start:[-14,4,Math.PI],thing:'moon rock',art:'🪨',
  intro:'Moon Rock Bounce! Bounce across the Moon and collect 6 moon rocks for Captain Nibbles!',title:'You collected all the moon rocks! Squeak, says Captain Nibbles!'};
COLLECT.roverrally={k:'roverrally',area:'mars',icon:'🧪',size:2,items:[[-20,-20],[22,-6],[-30,18],[28,26],[-4,-34],[14,36]],start:[-14,-1,Math.PI],thing:'rock sample',art:'🚙',ride:'rover',
  intro:'Rover Rally! Drive the Mars rover and collect 6 rock samples for the scientists back on Earth!',title:'You collected all the rock samples! Brilliant driving!'};
QUIZ.spacequiz={k:'spacequiz',name:'Space Quiz',icon:'🪐',n:8,bg:spaceBG(),intro:'The Space Quiz! How much do you know about our solar system?',
  make:i=>[{q:'Which planet is <b>closest</b> to the Sun?',say:'Which planet is closest to the Sun?',pic:planetPic('☀️'),ans:'Mercury',opts:['Mercury','Neptune','Mars'],hintSay:'It is the smallest planet, and it zooms round the Sun the fastest.'},
    {q:'Which is the <b>biggest</b> planet?',say:'Which is the biggest planet?',pic:planetPic('🪐'),ans:'Jupiter',opts:['Jupiter','Earth','Mars'],hintSay:'It is the giant planet with stripes and a big red spot.'},
    {q:'Which planet is famous for its beautiful <b>rings</b>?',say:'Which planet is famous for its beautiful rings?',pic:planetPic('💫'),ans:'Saturn',opts:['Saturn','Venus','Mercury'],hintSay:'You walked on its rings!'},
    {q:'What is the <b>Sun</b>?',say:'What is the Sun?',pic:planetPic('🌞'),ans:'A star',opts:['A star','A planet','A moon'],hintSay:'The Sun is like the stars you see at night, just much closer to us.'},
    {q:'How many <b>planets</b> go round our Sun?',say:'How many planets go round our Sun?',pic:planetPic('🌍'),ans:8,opts:[8,5,12],hintSay:'Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune. Count them!'},
    {q:'Why is <b>Mars</b> red?',say:'Why is Mars red?',pic:planetPic('🔴'),ans:'Rusty dust',opts:['Rusty dust','Red paint','Hot lava'],hintSay:'Its rocks and dust have iron in them that has gone rusty.'},
    {q:'What covers <b>Europa</b>?',say:'What covers Europa, the moon you just visited?',pic:planetPic('🧊'),ans:'Ice',opts:['Ice','Grass','Sand'],hintSay:'It is cold, white and slippery!'},
    {q:'In 1969, astronauts first walked on the...',say:'In 1969, astronauts first walked on the what?',pic:planetPic('👨‍🚀'),ans:'Moon',opts:['Moon','Sun','Jupiter'],hintSay:'It is the closest thing to Earth in space. You bounced on it!'}][i],
  block:()=>'🪐',title:'You are a space expert!'};
COUNTS.ringsteps={k:'ringsteps',icon:'💫',rounds:[{step:3,word:'threes'},{step:4,word:'fours'},{start:100,step:-10,word:'tens, counting down'}],bg:ringsSVG,cls:'stone',intro:'Hop across the ice chunks in Saturn\'s Rings! Count the jumps.',title:'You hopped all the way across the rings!'};
CATCH.sunbeams={k:'sunbeams',icon:'☀️',need:15,bg:sunSVG,cls:'',inner:'<b>☀️</b>',art:'🔋☀️',fall:true,intro:'Catch the sunbeams to charge the solar panels! Tap a sunbeam while it shines. Catch 15!',tip:'Wait until it shines, then tap!',title:'The solar panels are fully charged!'};
HERDS.starrescue={k:'starrescue',icon:'⭐',n:6,animal:babyStarSVG,herder:()=>buddyPup(),bg:nurseryPen,title:'All the baby stars are safe in the star nursery!',
  intro:p=>`Some baby stars are drifting towards the Black Hole! Help ${p.name} guide them into the star nursery. Drag your finger and ${p.name} will follow. The baby stars float away from ${p.name}!`};
regAct('moonrocks',{name:'Moon Rock Bounce',icon:'🪨',island:'planet',area:'moon',where:'Moon Base',play:()=>arcadeTravel('moon',COLLECT.moonrocks.start,()=>startCollect('moonrocks'),'Moon Rock Bounce is about to start!')});
regAct('roverrally',{name:'Rover Rally',icon:'🚙',island:'planet',area:'mars',where:'Mars',play:()=>arcadeTravel('mars',COLLECT.roverrally.start,()=>startCollect('roverrally'),'Rover Rally is about to start!')});
regAct('spacequiz',{name:'Space Quiz',icon:'🪐',island:'planet',area:'europa',where:'Europa',play:()=>startQuiz('arcade','spacequiz')});
regAct('ringsteps',{name:'Ring Steps',icon:'💫',island:'planet',area:'rings',where:'Saturn\'s Rings',play:()=>startStones('arcade','ringsteps')});
regAct('sunbeams',{name:'Sunbeam Catch',icon:'☀️',island:'planet',area:'station',where:'the Solar Station',play:()=>startFlies('arcade','sunbeams')});
regAct('starrescue',{name:'Star Rescue',icon:'⭐',island:'planet',area:'blackhole',where:'the Black Hole',play:()=>startHerd('arcade','starrescue')});

regIsland({id:'planet',name:'Planet Hop',icon:'🪐',type:'comet',req:['gadget','rescue'],rideName:'The rocket',ride:'the rocket',from:'launch pad in the village',rideIcon:'🚀',rideSay:'3, 2, 1, blast off! The rocket roars up into space, all the way to the Moon!',
  homeSay:'The rocket zooms back down to Pawprint Village!',homePos:[-34,10,Math.atan2(34,-10)],
  badge:'Planet Badge',cert:'Seb, Planet Hop Hero!',bossHint:'Nebula the Galaxy Unicorn is waiting at the Black Hole!',
  nextSay:'Hooray! Planet Hop is safe, and every star is home!',
  map:{shape:'M20 235 A410 215 0 1 0 840 235 A410 215 0 1 0 20 235Z',
    nodes:{moon:[430,368],mars:[220,300],europa:[640,300],station:[200,130],rings:[660,130],blackhole:[430,70],nebula:[772,150]},
    links:[['moon','mars'],['moon','europa'],['mars','station'],['europa','rings'],['station','blackhole'],['rings','blackhole'],['rings','nebula']]},
  boss:{area:'blackhole',x:0,z:-14,perch:0,uni:NEBULA,
    story:[['m','Muddle the Magpie is grabbing at the shiniest stars by the Black Hole, and he starts to drift towards the swirl! "Help! Help, Seb!"'],
      ['b','Quick! All the pups hold paws in a long line, the very first conga line, and pull Muddle back to safety. Heave! Heave!'],
      ['u','Nebula the Galaxy Unicorn smiles. "Muddle, the brightest things in the universe are your friends, not shiny things."'],
      ['m','"I know that now," says Muddle. "I have the best friends in the whole galaxy." He gives back the shiny Planet Star, the very last one!'],
      ['b','All nine stars are home! Together they make the giant disco ball sparkle, ready for the biggest party ever. Hooray for Seb!']],
    after:['Nebula says: thank you for finding every pup on Planet Hop!','Muddle says: I am never chasing shiny things again. Well, hardly ever!','Nebula says: the black hole is beautiful from a safe distance.']},
  pups:P,bonus:[STARDUST],areas:[moon,mars,europa,rings,station,blackhole,nebula]});

/* ----------------- the village launch pad ----------------- */
function countdown(go){player.lock=true;hush();const f=$('#fx'),box=el('div','cdown','');f.appendChild(box);let n=state.seen.moon?5:10;
  const tick=()=>{if(n===0){box.remove();go();return;}box.textContent=n;box.classList.remove('cpop');void box.offsetWidth;box.classList.add('cpop');speak(String(n));sfx.boop();n--;setTimeout(tick,800);};tick();}
const vb=AREAS.village.build;AREAS.village.build=function(){vb.apply(this,arguments);
  const x=-40,z=6,y=gy(x,z);I('cyl','#c9c2b8',5,.6,5,x,y+.3,z);I('cyl','#ffd23f',4.4,.08,4.4,x,y+.62,z);
  const r=bigRocket(x,z,1);r.position.y=y+.6;for(let i=0;i<4;i++)I('box','#e8423a',.4,15,.4,x+4,y+7.5,z-1.5+i);I('box','#e8423a',3.4,.3,3.4,x+4,y+12,z);col(x+4,z,1.2);
  const open=!!islandOf('planet')&&islOpen('planet'),lb=label(open?'🚀 Rocket to Planet Hop':'🚀 Planet Hop 🔒',8);lb.position.set(x,y+18,z);W.ag.add(lb);
  W.things.push({x:x+5.5,z:z+4.5,r:4.6,icon:'🚀',label:'Rocket',act:()=>{if(!islOpen('planet')){rideTo('planet');return;}countdown(()=>rideTo('planet'));}});};
window.ROCKET={bigRocket,countdown};
{const st=document.createElement('style');st.textContent='.cdown{position:absolute;left:50%;top:40%;transform:translate(-50%,-50%);font-size:220px;font-weight:900;color:#fff;-webkit-text-stroke:8px #26232e;paint-order:stroke;pointer-events:none;z-index:60}.cdown.cpop{animation:cpop .8s ease-out}@keyframes cpop{0%{transform:translate(-50%,-50%) scale(1.8);opacity:0}30%{opacity:1}100%{transform:translate(-50%,-50%) scale(1)}}';document.head.appendChild(st);}
})();
