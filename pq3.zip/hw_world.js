/* ================================================================
   Halloween (25 Nov 2026; claude/halloween-design.md sections 6, 7, 10, 12, 13): the world at dusk.
   The village (lit pumpkins, bat bunting, the Pumpkin Board), pumpkins and touches on every island,
   the island surprises (the joking snowman, the octopus in a pumpkin, shadow puppets, Tinker's robot
   costume contest, Chief Woofles' be-seen stand, the bouncing Moon pumpkins), the three spotlights
   (Pumpkin Pick in the sunflower maze, the Bone Xylophone at the Skeleton Disco, Night Watch in the
   museum at night), the autumn quiz in the Lab, the Den after the parade, Arcade entries, the tunes
   (In the Hall of the Mountain King, an original village tune, the disco at the dig) and the
   real-date pumpkins on 31 October.
   ================================================================ */
(function(){
const HW=window.HW,XM=window.XMAS,PI=Math.PI,ORNG='#ff8a1a',GOLD='#ffd23f',PURP='#4b3a7a',BAT='#3a2a50';
const G=()=>HW.GS(),acts=()=>{const s=G();s.acts=s.acts||{};return s.acts;},F=()=>HW.pal().name;
function sayOnce(k,m,ms){const a=acts();if(a['s_'+k])return;a['s_'+k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say(m);},ms||1600);}
let GRD=null;function near(A,x,z,c){if(!GRD||GRD.id!==A.id){GRD=XM.grid(A,1);GRD.id=A.id;}const k=GRD.snap(x,z,c||2);return k<0?[x,z]:GRD.xz(k);}
const big=e=>`<div style="font-size:96px;line-height:1">${e}</div>`;
function card2(art,h,p,sayT){card({art,h,p,say:sayT||p,btns:[['OK','green']]});}
function reward(k,n){const a=acts();if(a[k])return;a[k]=1;state.stars+=n||5;save();hud();}
/* a pumpkin from instanced parts; lit ones get a glowing face turned towards (fx,fz) */
function pk(x,z,s,col,lit,fx,fz){const y=gy(x,z);s=s||1;col=col||ORNG;const dk=HW.mixC(col,'#3a2010',.25);
  I('sph',col,.62*s,.46*s,.62*s,x,y+.42*s,z);I('sph',dk,.3*s,.43*s,.3*s,x+.36*s,y+.42*s,z);I('sph',dk,.3*s,.43*s,.3*s,x-.36*s,y+.42*s,z);I('cyl','#4a7a2a',.05*s,.22*s,.05*s,x,y+.92*s,z);
  if(lit){let dx=(fx==null?0:fx)-x,dz=(fz==null?0:fz)-z;const d=Math.hypot(dx,dz)||1;dx/=d;dz/=d;const r=Math.atan2(dx,dz),px=-dz,pz=dx,fy=y+.42*s,o=.6*s;
    [-1,1].forEach(k=>I('box',GOLD,.14*s,.14*s,.05,x+dx*o+px*k*.2*s,fy+.12*s,z+dz*o+pz*k*.2*s,0,r,PI/4,true));I('box',GOLD,.38*s,.1*s,.05,x+dx*o,fy-.12*s,z+dz*o,0,r,0,true);}}
function scarecrow(x,z){const y=gy(x,z);I('cyl','#7a5a3a',.08,2.6,.08,x,y+1.3,z);I('box','#7a5a3a',2,.1,.1,x,y+2,z);I('box','#b85a2a',.7,.8,.35,x,y+1.9,z);I('sph','#e8c87a',.34,.36,.34,x,y+2.6,z);
  I('cone','#5a3a8a',.42,.6,.42,x,y+3.1,z);I('cyl','#5a3a8a',.6,.05,.6,x,y+2.86,z);col(x,z,.5);}
function bunting(cx,cz,r,y0,n){for(let i=0;i<n;i++){const a=i/n*PI*2,x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r,y=y0+Math.sin(i*PI/2)*.25;I('box',BAT,.6,.2,.04,x,y,z,0,-a,0);I('box',BAT,.26,.26,.04,x,y-.12,z,0,-a,PI/4);}}

/* ================= Pawprint Village at dusk ================= */
function villageH(A){
  for(let i=0;i<14;i++){const a=i/14*PI*2+.2,x=Math.cos(a)*12.6,z=4+Math.sin(a)*12.6;if(Math.hypot(x+5.5,z-9)<2.6)continue;pk(x,z,1.1,ORNG,true,0,4);}
  bunting(0,4,9.5,4.6,26);pumpkinBoard(-9,-18);
  sayOnce('village',`Welcome to Halloween! Every pup is in costume for the Pumpkin Parade. Look at the Pumpkin Board by the plaza: a pumpkin lights up for every pup you find.`);}
function pumpkinBoard(x,z){const y=gy(x,z);[-2.1,2.1].forEach(d=>I('box','#5a4030',.22,3.8,.22,x+d,y+1.9,z));I('box',PURP,4.5,2.9,.2,x,y+2.7,z);I('box',ORNG,4.7,.16,.26,x,y+4.18,z);I('box',ORNG,4.7,.16,.26,x,y+1.22,z);
  const n=Math.min(60,Math.round(HW.nFound()/HW.all().length*60));for(let i=0;i<60;i++){const c=i%12,r=Math.floor(i/12);I('sph',i<n?ORNG:'#6a5a8a',.13,.11,.06,x-1.9+c*.345,y+3.75-r*.48,z+.13,0,0,0,i<n);}
  const l=label('🎃 Pumpkin Board',4.5,'#fff3e6');l.position.set(x,y+5,z);W.ag.add(l);rect(x-2.4,z-.3,x+2.4,z+.3);
  W.things.push({x,z:z+2.2,r:3.6,icon:'🎃',label:'Pumpkin Board',act:()=>HW.board()});}

/* ================= the islands at dusk ================= */
const ISL={},PCOL={meadow:ORNG,snowy:'#f2efe6',reef:'#8aa0a8',ninja:'#d8402a',number:ORNG,gadget:'#b8c0cc',rescue:ORNG,dino:'#6aa84a',planet:'#9a5ad8'};
function decor(A){const isl=A.island;if(!PCOL[isl]||A.indoor)return;const s=A.start||[0,0],R=seed(A.id.length*17+3),n=A.swim?4:7;
  for(let i=0;i<n;i++){const a=i/n*PI*2+R(),d=7+R()*7,p=near(A,s[0]+Math.cos(a)*d,s[1]-5+Math.sin(a)*d,1);pk(p[0],p[1],.8+R()*.5,PCOL[isl],i%2===0,player.x,player.z);}}
/* Meadow: scarecrows in the fields */
ISL.windmill=A=>{const s=A.start||[0,0];[[8,-10],[-9,-14]].forEach(q=>{const p=near(A,s[0]+q[0],s[1]+q[1],2);scarecrow(p[0],p[1]);});};
/* Snowy Summit: the snowman in a witch hat tells a joke */
const JOKES=[['What do snowmen eat for breakfast?','Snowflakes!'],['What is a skeleton\'s favourite instrument?','The trom-BONE!'],['Why did the pumpkin go to the Pumpkin Parade?','Because it had nothing to gourd... I mean, nothing to guard!'],['What do you call a cold puppy sitting on a rabbit?','A chilli dog... on a bunny!'],['How do snowmen get around?','They ride an ICE-cycle!']];
ISL.lift=A=>{const s=A.start||[0,0],p=near(A,s[0]+6,s[1]-7,2),x=p[0],z=p[1],y=gy(x,z);I('sph','#ffffff',1.1,1,1.1,x,y+.9,z);I('sph','#ffffff',.8,.75,.8,x,y+2.3,z);I('sph','#ffffff',.55,.55,.55,x,y+3.4,z);
  I('cone',ORNG,.1,.45,.1,x,y+3.4,z+.75,PI/2,0,0);[-1,1].forEach(k=>I('sph','#26232e',.08,.08,.08,x+k*.2,y+3.55,z+.5));I('cyl',PURP,.95,.06,.95,x,y+3.9,z);I('cone',PURP,.5,1.2,.5,x,y+4.5,z);I('cyl',ORNG,.52,.12,.52,x,y+4,z);col(x,z,1.2);
  W.things.push({x,z:z+2.2,r:3.6,icon:'⛄',label:'Snowman',act:()=>{if(player.lock)return;const a=acts(),j=JOKES[(a.joke||0)%JOKES.length];a.joke=(a.joke||0)+1;save();sfx.chime();
    card({art:big('⛄🧙'),h:'The snowman tells a joke!',p:`"${j[0]}"<br><br><b>"${j[1]}"</b>`,say:`${j[0]} ... ${j[1]}`,btns:[['😂 Ha ha!','green',()=>{reward('snowman');}]]});}});};
/* Coral Reef: an octopus waves from a sunken pumpkin */
ISL.lagoon=A=>{const s=A.start||[0,0],p=near(A,s[0]-6,s[1]-9,2),x=p[0],z=p[1],y=gy(x,z);pk(x,z,2.4,'#8aa0a8');I('sph','#a86ad8',.6,.55,.6,x,y+2.4,z);[-1,1].forEach(k=>I('sph','#ffffff',.16,.16,.1,x+k*.22,y+2.5,z+.5));
  for(let i=0;i<8;i++){const a=i/8*PI*2;I('cyl','#a86ad8',.1,1.2,.1,x+Math.cos(a)*.7,y+2,z+Math.sin(a)*.7,Math.sin(a)*.9,0,-Math.cos(a)*.9);}col(x,z,1.8);
  W.things.push({x,z:z+3,r:4,icon:'🐙',label:'Octopus',act:()=>{if(player.lock)return;sfx.chime();reward('octopus');card2(big('🐙🎃'),'An octopus in a pumpkin!','The octopus waves all eight arms! An octopus has eight arms, just as a spider has eight legs. Octopuses love hiding in small, cosy places.');}});};
/* Ninja Mountains: shadow puppets on the Dojo's paper screen */
const SHAD=[['rabbit','<path d="M90 120 q-10 -50 6 -80 q8 30 4 60 q14 -40 30 -60 q4 34 -18 74 q34 4 40 34 q-30 22 -64 4 Z"/>'],['bird','<path d="M40 110 q40 -10 60 0 q30 -40 70 -36 q-26 14 -40 44 q20 10 36 2 q-16 26 -60 18 q-40 10 -66 -28 Z"/>'],
 ['dog','<path d="M60 150 q-10 -40 14 -60 l-6 -40 q22 12 30 36 q30 -6 50 10 q22 -2 28 16 q-10 10 -28 6 q-6 24 -34 30 q-8 12 -54 2 Z"/>']];
function shadowSVG(i){const q=SHAD[i%SHAD.length];return `<svg viewBox="0 0 240 200" width="300"><rect width="240" height="200" rx="14" fill="#5a3a2a"/><rect x="14" y="12" width="212" height="176" fill="#fff2d0"/><circle cx="120" cy="100" r="90" fill="#ffe9a8" opacity=".6"/>`+
  `<path d="M14 100 H226 M120 12 V188" stroke="#d8c8a0" stroke-width="3"/><g fill="#3a2a3a" opacity=".85">${q[1]}</g></svg>`;}
ISL.dojo=A=>{const s=A.start||[0,0],p=near(A,s[0]+7,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('box','#5a3a2a',4,3,.2,x,y+1.6,z);I('box','#fff2d0',3.6,2.6,.22,x,y+1.6,z,0,0,0,true);col(x,z,1.6);
  W.things.push({x,z:z+2.4,r:3.6,icon:'🖐️',label:'Shadow puppets',act:()=>{if(player.lock)return;sfx.chime();player.lock=true;let i=0;const nx=()=>{card({art:shadowSVG(i),h:`A shadow ${SHAD[i][0]}!`,
      p:i===0?'Sensei Mochi makes shadow animals with her paws! A shadow is made when something blocks the light, so the light cannot reach the screen behind it.':i===1?'The closer the paws are to the lantern, the bigger the shadow gets!':'A dog! Shadows always fall on the side away from the light.',
      btns:i<SHAD.length-1?[['Next ▶','green',()=>{i++;nx();}]]:[['OK','green',()=>{player.lock=false;reward('shadows');}]]});};nx();}});};
/* Gadget Island: Tinker's robot costume contest */
const ROBO=[['#ff8a1a','a pumpkin robot'],['#8a5ad8','a wizard robot'],['#5ab8ff','a superhero robot']];
function roboSVG(c,i){return `<svg viewBox="0 0 100 130" width="110"><rect x="22" y="40" width="56" height="54" rx="8" fill="${c}" stroke="#26232e" stroke-width="4"/><rect x="28" y="10" width="44" height="32" rx="8" fill="#c8d0dc" stroke="#26232e" stroke-width="4"/>`+
  `<circle cx="41" cy="26" r="5" fill="#26232e"/><circle cx="59" cy="26" r="5" fill="#26232e"/><rect x="30" y="94" width="12" height="26" fill="#8a92a0" stroke="#26232e" stroke-width="3"/><rect x="58" y="94" width="12" height="26" fill="#8a92a0" stroke="#26232e" stroke-width="3"/>`+
  (i===0?'<path d="M42 60 l6 -6 l6 6 Z M52 60 l6 -6 l6 6 Z M40 74 q10 8 20 0" stroke="#5a2a10" stroke-width="3" fill="#ffd23f"/>':i===1?'<path d="M30 12 L50 -14 L70 12 Z" fill="#5a3a8a" stroke="#26232e" stroke-width="3"/><circle cx="50" cy="66" r="9" fill="#ffd23f"/>':'<path d="M38 56 L62 56 L50 82 Z" fill="#e8423a" stroke="#26232e" stroke-width="3"/><path d="M22 44 L4 104 L22 94 Z" fill="#e8423a"/>')+`</svg>`;}
ISL.workshop=A=>{const s=A.start||[0,0],p=near(A,s[0]+6,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('box','#8a5a3a',4.4,.5,2,x,y+.25,z);ROBO.forEach((r,i)=>{const rx=x-1.4+i*1.4;I('box',r[0],.7,.8,.5,rx,y+1,z);I('box','#c8d0dc',.6,.5,.5,rx,y+1.7,z);});col(x,z,2.2);
  W.things.push({x,z:z+2.6,r:3.8,icon:'🤖',label:'Robot contest',act:()=>{if(player.lock)return;sfx.chime();
    card({h:'🤖 Tinker\'s robot costume contest!',p:`Tinker built three robots and dressed them up. Which costume is your favourite?<div class="hrobo">${ROBO.map((r,i)=>`<button class="opt hrb" data-i="${i}">${roboSVG(r[0],i)}</button>`).join('')}</div>`,
      say:'Tinker built three robots and dressed them up for Halloween. Which costume is your favourite?',btns:[['Back','white']]});
    document.querySelectorAll('#celeCard .hrb').forEach(b=>tap(b,()=>{const r=ROBO[+b.dataset.i];sfx.fanfare();confetti(30);reward('robots');
      card2(`<div class="fitsvg" style="width:130px">${roboSVG(r[0],+b.dataset.i)}</div><div style="font-size:60px">🏅</div>`,'A gold rosette!',`You picked ${r[1]}! Tinker pins on a gold rosette. "Robots follow instructions called a program," says Tinker. "I programmed this one to wave!"`);}));}});};
/* Rescue Bay: Chief Woofles' be-seen stand */
ISL.firestation=A=>{const s=A.start||[0,0],p=near(A,s[0]-6,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('box','#e8423a',3,1.1,1.2,x,y+.55,z);I('box','#ffd23f',3.1,.2,1.3,x,y+1.15,z,0,0,0,true);I('box','#c8ff4a',.3,1.6,.3,x-1.3,y+1.9,z,0,0,0,true);I('box','#c8ff4a',.3,1.6,.3,x+1.3,y+1.9,z,0,0,0,true);col(x,z,1.6);
  W.things.push({x,z:z+2.4,r:3.6,icon:'🦺',label:'Be seen!',act:()=>{if(player.lock)return;sfx.chime();
    card({h:'🦺 Chief Woofles says: be seen in the dark!',p:'Which pup is easier to see in the dark?<div class="hrobo"><button class="opt hbs" data-i="0"><div style="font-size:64px">🐕‍🦺</div>Bright coat and shiny strips</button><button class="opt hbs" data-i="1"><div style="font-size:64px;filter:brightness(.35)">🐕</div>Dark coat</button></div>',
      say:'Chief Woofles says: be seen in the dark! Which pup is easier to see?',btns:[['Back','white']]});
    document.querySelectorAll('#celeCard .hbs').forEach(b=>tap(b,()=>{const ok=b.dataset.i==='0';if(ok){sfx.chime();reward('beseen');}else sfx.oops();
      card2(big('🦺✨'),ok?'That\'s right!':'Look again!','Bright colours and reflective strips bounce car headlights straight back, so drivers can see you from far away. Wear something bright when it gets dark!');}));}});};
/* Planet Hop: Moon pumpkins bounce and drift in low gravity */
ISL.moon=A=>{const s=A.start||[0,0],L=[];for(let i=0;i<5;i++){const p=near(A,s[0]-6+i*3,s[1]-9-(i%2)*2,1),g=grp();HW.pumpkin3D(g,'#9a5ad8',1.1,i%2===0);g.position.set(p[0],gy(p[0],p[1]),p[1]);W.ag.add(g);L.push({g,x:p[0],z:p[1],v:0,h:0,ph:i});}
  W.ticks.push(dt=>{if(W.area!==A)return true;L.forEach(q=>{q.v-=1.62*dt;q.h+=q.v*dt;if(q.h<=0){q.h=0;q.v=q.ph===q.kick?9:2.4;q.kick=-1;}q.g.position.y=gy(q.x,q.z)+q.h;q.g.rotation.y+=dt*.4;});});
  const c=L[2];W.things.push({x:c.x,z:c.z+2.6,r:4,icon:'🎃',label:'Moon pumpkins',act:()=>{L.forEach(q=>{q.kick=q.ph;});HW.snd.boo();reward('moonpk');
    setTimeout(()=>card2(big('🌕🎃'),'Boing... boing...','On the Moon, gravity pulls about six times less than on Earth, so the pumpkins bounce up high and float down slowly. You could jump six times higher there!'),1600);}});};

/* ================= the spotlights ================= */
/* free spots for a collect game, reachable from the start (in a box if given) */
function prep(k,box){const C=COLLECT[k],A=W.area,s=[player.x,player.z],Gd=XM.grid(A,1),st=Gd.snap(s[0],s[1],1);C.items=[];if(st<0)return;const B=Gd.bfs(st),R=seed(Math.floor(Math.random()*9999)),out=[],n=C.n||8;
  for(let tries=0;tries<6000&&out.length<n;tries++){const kk=Math.floor(R()*Gd.N);if(Gd.clr[kk]<2||B.D[kk]>=1e9||B.D[kk]<6||B.D[kk]>60)continue;const p=Gd.xz(kk);
    if(box&&tries<4500&&(p[0]<box[0]||p[0]>box[2]||p[1]<box[1]||p[1]>box[3]))continue;if(out.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<6))continue;out.push([p[0],p[1]]);}
  C.items=out;}
COLLECT.hwpick={k:'hwpick',area:'sunflowers',icon:'🎃',size:2,h:1.4,items:[],start:null,thing:'pumpkin',art:'🎃',n:8,
  intro:'Pumpkin Pick! The sunflower maze is full of pumpkins. Walk to each one to pick it. Find all 8!',title:'Every pumpkin picked! A pumpkin is a fruit, because it grows from a flower and holds the seeds.'};
const NUMS=['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
COLLECT.hwwatch={k:'hwwatch',area:'ntown',icon:'🔢',size:2,h:2,items:[],start:null,thing:'glowing number',art:'🔦',n:10,
  intro:'Night Watch! The numbers have escaped from the museum and are glowing all over Number Town. Collect all 10 with your torch!',title:'All 10 numbers are back in the museum! Night Watch complete!'};
function startSpot(k){if(player.lock||W.act)return;if(!W.area||W.area.id!==COLLECT[k].area)return;prep(k,k==='hwpick'?[-48,-33,16,19]:null);if(COLLECT[k].items.length<5){say('Let\'s try that again in a moment!');return;}sfx.chime();startCollect(k);
  if(k==='hwwatch'&&W.act)W.act.items.forEach((it,i)=>{W.ag.remove(it.sp);it.sp=spr(NUMS[i%10],2,it.x,it.y,it.z);});}
ISL.sunflowers=A=>{const p=near(A,26,18,2);sign(p[0]+1.6,p[1]-1.6,'🎃 Pumpkin Pick',3,6.4);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🎃',label:'Pumpkin Pick',act:()=>startSpot('hwpick')});
  for(let i=0;i<10;i++){const q=near(A,-40+(i%5)*12,-24+Math.floor(i/5)*26,1);pk(q[0],q[1],.7,ORNG,i%3===0,q[0],q[1]+5);}
  sayOnce('maze','The sunflower maze is full of pumpkins! Find the Pumpkin Pick sign by the maze to pick them.',2600);};
ISL.ntown=A=>{const s=A.start||[0,0],p=near(A,s[0]+5,s[1]-6,2);sign(p[0]+1.6,p[1]-1.6,'🔦 Night Watch',3,6.4);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🔦',label:'Night Watch',act:()=>startSpot('hwwatch')});
  sayOnce('museum','The museum is open at night! The exhibits are in costume, and the numbers have escaped. Find the Night Watch sign!',2600);};
/* the Skeleton Disco and the Bone Xylophone at Dig Camp */
let SK=null;
function skeleton(x,z,g){const y=0;mk('sph','#f4f0e4',.36,.38,.36,0,2.5,0,g);[-1,1].forEach(k=>mk('sph','#26232e',.08,.1,.05,k*.13,2.56,.3,g));for(let i=0;i<4;i++)mk('box','#f4f0e4',.7-i*.08,.06,.34,0,2-i*.2,0,g);
  mk('cyl','#f4f0e4',.06,1.1,.06,0,1.7,0,g);[-1,1].forEach(k=>{mk('cyl','#f4f0e4',.05,.9,.05,k*.42,1.7,0,g).rotation.z=k*.5;mk('cyl','#f4f0e4',.06,1,.06,k*.18,.6,0,g);});return g;}
ISL.digcamp=A=>{const s=A.start||[0,0],c=near(A,s[0]+6,s[1]-9,3);SK=[];
  for(let i=0;i<3;i++){const a=i/3*PI*2,x=c[0]+Math.cos(a)*3.2,z=c[1]+Math.sin(a)*3.2,g=grp();skeleton(x,z,g);g.position.set(x,gy(x,z),z);g.rotation.y=Math.atan2(c[0]-x,c[1]-z);bakeModel(g,'hskel');W.ag.add(g);SK.push({g,x,z,ph:i});col(x,z,.6);}
  const ball=mk('sph','#c8c8d8',.5,.5,.5,c[0],gy(c[0],c[1])+5,c[1],null,true);W.ag.add(ball);
  const lights=[0,1,2,3].map(i=>{const m=new THREE.SpriteMaterial({map:HW.glowTex(),color:['#ff7fe0','#5cf0ff','#c8ff4a','#ffd23f'][i],transparent:true,opacity:.5,depthWrite:false,blending:THREE.AdditiveBlending}),sp=new THREE.Sprite(m);sp.scale.set(5,5,1);W.ag.add(sp);W.disp.push(m);return sp;});
  const D={party:0};SK.D=D;W.ticks.push(dt=>{if(W.area!==A)return true;const t=W.t,on=D.party>0;if(on)D.party-=dt;ball.rotation.y+=dt*(on?3:.6);
    SK.forEach(q=>{q.g.position.y=gy(q.x,q.z)+(on?Math.abs(Math.sin(t*8+q.ph))*.6:Math.abs(Math.sin(t*2+q.ph))*.1);q.g.rotation.z=on?Math.sin(t*8+q.ph)*.2:0;});
    lights.forEach((sp,i)=>{const a=t*(on?2.4:.8)+i*PI/2;sp.position.set(c[0]+Math.cos(a)*3.5,gy(c[0],c[1])+.3,c[1]+Math.sin(a)*3.5);sp.material.opacity=on?.7:.3;});});
  W.things.push({x:c[0],z:c[1]+4.6,r:4,icon:'🦴',label:'Bone Xylophone',act:boneXylo});
  sayOnce('disco','The skeletons at the dig are having a disco! They are made of plastic, so they are not scary at all. Find the Bone Xylophone and play them a tune!',2600);};
let BX=null;
function boneUI(){if($('#hbone'))return;const d=el('div','ov','<div class="card" id="hbCard"><h2 id="hbH"></h2><div id="hbBox"></div><p id="hbMsg"></p><div class="btns"><button class="btn white" id="hbBack">Back</button></div></div>');d.id='hbone';document.body.appendChild(d);
  tap('#hbBack',()=>{sfx.boop();$('#hbone').classList.remove('on');player.lock=false;BX=null;});}
function boneXylo(){if(player.lock||W.act)return;boneUI();player.lock=true;hush();const first=!(state.acts||{}).hwbones,tb=typeof tablesOn==='function'?tablesOn():[];const step=first?1:pick([2,5,10].concat(tb||[]));
  const n=8,order=[...Array(n).keys()].sort(()=>Math.random()-.5);BX={i:0,step,t0:W.t};
  $('#hbBox').innerHTML=`<svg viewBox="0 0 640 300" id="hbSvg"><rect width="640" height="300" rx="18" fill="${PURP}"/><path d="M40 60 Q320 10 600 60" stroke="#f4f0e4" stroke-width="14" fill="none" stroke-linecap="round"/>`+
    order.map((v,k)=>{const x=60+k*72,h=200-v*14;return `<g class="hbb" data-v="${v}"><rect x="${x}" y="60" width="44" height="${h}" rx="20" fill="#f4f0e4" stroke="#26232e" stroke-width="4"/><circle cx="${x+10}" cy="${60+h}" r="12" fill="#f4f0e4" stroke="#26232e" stroke-width="4"/><circle cx="${x+34}" cy="${60+h}" r="12" fill="#f4f0e4" stroke="#26232e" stroke-width="4"/>`+
      `<rect x="${x+2}" y="${56+h}" width="40" height="10" fill="#f4f0e4"/><circle class="hbg" cx="${x+22}" cy="${104}" r="24" fill="#ffd23f" opacity="0"/><text x="${x+22}" y="114" font-size="28" font-weight="900" text-anchor="middle" fill="#26232e" font-family="Arial">${(v+1)*step}</text></g>`;}).join('')+`</svg>`;
  $('#hbH').textContent='🦴 Play the Bone Xylophone!';const m=`Tap the bones in order: ${step}, ${2*step}, ${3*step}... and the skeletons will dance!`;$('#hbMsg').textContent=m;speak(m);
  document.querySelectorAll('#hbSvg .hbb').forEach(g=>tap(g,()=>{if(!BX)return;const v=+g.dataset.v;if(v!==BX.i){if(v<BX.i)return;sfx.oops();const t=`Look for ${(BX.i+1)*step}.`;$('#hbMsg').textContent=t;speak(t);return;}
    HW.snd.note(7-v);g.querySelector('.hbg').setAttribute('opacity','.6');g.classList.add('hit');BX.i++;if(BX.i<n){$('#hbMsg').textContent=`${(v+1)*step}! Next: ${(BX.i+1)*step}`;return;}
    const secs=W.t-BX.t0;BX=null;$('#hbMsg').textContent='What a tune! Look at the skeletons dance!';HW.snd.song(9,180);
    setTimeout(()=>{$('#hbone').classList.remove('on');player.lock=false;if(SK&&SK.D)SK.D.party=12;MUSIC.over='disco';setTimeout(()=>{if(MUSIC.over==='disco'&&!W.act)MUSIC.over=null;},12000);
      setTimeout(()=>finishAct('hwbones',secs,big('🦴💃'),'The Skeleton Disco! Fossil bones are rock that slowly took the place of the old bone.',()=>boneXylo()),3500);},1300);}));
  $('#hbone').classList.add('on');}
function hTravel(area,pos,start,msg){if(!HW.on()){state.season='hw';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='hw'&&S.hide)try{S.hide();}catch(e){}});}arcadeTravel(area,pos,start,msg);}
regAct('hwpick',{name:'Pumpkin Pick',icon:'🎃',island:'meadow',area:'sunflowers',where:'Halloween, in Sunflower Fields',lockSay:'Find Pumpkin Pick by the sunflower maze in Halloween, and play it there first!',play:()=>hTravel('sunflowers',[15,22,PI],()=>startSpot('hwpick'),'Pumpkin Pick!')});
regAct('hwbones',{name:'Bone Xylophone',icon:'🦴',island:'dino',area:'digcamp',where:'Halloween, at Dig Camp',lockSay:'Find the Skeleton Disco at Dig Camp in Halloween, and play it there first!',play:()=>hTravel('digcamp',null,()=>boneXylo(),'The Skeleton Disco!')});
regAct('hwwatch',{name:'Night Watch',icon:'🔦',island:'number',area:'ntown',where:'Halloween, in Number Town',lockSay:'Find Night Watch in Number Town in Halloween, and play it there first!',play:()=>hTravel('ntown',null,()=>startSpot('hwwatch'),'Night Watch!')});
/* the Den: carved pumpkins, bat bunting and a cauldron of sweets, after the parade */
ISL.den=A=>{if(!G().done)return;[[-8,-6],[8,-6],[-8,4],[8,4]].forEach(q=>pk(q[0],q[1],.9,ORNG,true,0,0));bunting(0,-2,7,4.4,22);
  const x=0,z=-7,y=gy(x,z);I('hemi','#26232e',1,1,1,x,y+1,z,PI,0,0);I('cyl','#26232e',1.05,.15,1.05,x,y+1,z);for(let i=0;i<10;i++){const a=i*.63;I('sph',['#ff5a8a','#ffd23f','#5ab8ff','#8ae05a'][i%4],.16,.12,.16,x+Math.cos(a)*.6,y+1.12,z+Math.sin(a)*.6,0,0,0,true);}};

/* ================= the Lab: an autumn science quiz ================= */
const AQ=[['Is a pumpkin a fruit or a vegetable?','A pumpkin is a fruit, because it grows from a flower and has seeds inside.',['A fruit','A vegetable','A nut'],'A fruit'],
 ['How do bats find their food in the dark?','Bats make tiny squeaks and listen for the echoes bouncing back. That is called echolocation.',['By listening to echoes','With torches','By smell only'],'By listening to echoes'],
 ['Is a spider an insect?','No! Spiders have eight legs, and insects have six. Spiders are arachnids.',['No, it has eight legs','Yes, it is an insect','Only at Halloween'],'No, it has eight legs'],
 ['Why do leaves change colour in autumn?','In autumn trees stop making green chlorophyll, so the yellow and orange colours that were hiding in the leaves show through.',['The green fades and other colours show','Someone paints them','They get cold and blush'],'The green fades and other colours show'],
 ['How do owls fly so quietly?','Owl feathers have soft, fringed edges that break up the air, so they hardly make a sound.',['Soft, fringed feathers','They hold their breath','They fly very slowly'],'Soft, fringed feathers'],
 ['Why do hedgehogs hibernate?','There is not much food for hedgehogs in winter, so they sleep through it, living on the fat they stored up in autumn.',['There is little food in winter','They are bored','To grow spines'],'There is little food in winter']];
const duskBG=()=>`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="hqb" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a2a6a"/><stop offset="1" stop-color="#ff9a5a"/></linearGradient></defs><rect width="1024" height="768" fill="url(#hqb)"/>`+
  `<circle cx="840" cy="160" r="70" fill="#ffc98a"/>`+[[120,690],[300,710],[700,700],[900,690]].map(q=>`<ellipse cx="${q[0]}" cy="${q[1]}" rx="50" ry="40" fill="${ORNG}"/><path d="M${q[0]} ${q[1]-40} v-14" stroke="#4a7a2a" stroke-width="8"/>`).join('')+`</svg>`;
QUIZ.autumn={k:'autumn',name:'Autumn Science',icon:'🍂',n:6,bg:duskBG,introMs:3400,intro:'Professor Fizz has an autumn science quiz! Pumpkins, bats, spiders and more. Let\'s find out!',
  make:i=>{const q=AQ[i%AQ.length],o=q[2].slice().sort(()=>Math.random()-.5);return {q:q[0],say:q[0]+' '+o.join(', or ')+'?',pic:'<div style="font-size:110px;line-height:1">🍂🎃</div>',ans:q[3],opts:o,hintSay:q[1],after:`<div style="font-size:26px;font-weight:800;padding:10px">${q[1]}</div>`};},
  block:()=>'🍂',title:'Brilliant! You are an autumn science star!'};
if(typeof openLab==='function'){const base=openLab;openLab=function(){base.apply(this,arguments);if(!HW.on())return;setTimeout(()=>{if(document.querySelector('#lab .hwin'))return;const host=document.querySelector('#lab');if(!host)return;
  const b=el('button','btn green hwin','🍂 Autumn science');b.style.cssText='position:absolute;right:24px;bottom:24px;z-index:30;font-size:24px';tap(b,()=>{sfx.pop();startQuiz('lab','autumn');});host.appendChild(b);},50);};}

/* ================= music ================= */
const C1=s=>tuneRow(s);
/* In the Hall of the Mountain King (Grieg, 1875): the sneaky monster tune */
TUNES.hmk={step:.2,mw:'triangle',mv:.45,mel:C1('B4 C#5 D5 E5 F#5 D5 F#5 - F5 C#5 F5 - E5 C5 E5 - B4 C#5 D5 E5 F#5 D5 F#5 B5 A5 F#5 D5 F#5 A5 - - - B4 C#5 D5 E5 F#5 D5 F#5 - F5 C#5 F5 - E5 C5 E5 - B4 C#5 D5 E5 F#5 D5 F#5 B5 A5 F#5 D5 F#5 B5 - - -'),
  bas:C1('B2 . F#3 . B2 . F#3 . C#3 . G#3 . C3 . G3 . B2 . F#3 . B2 . F#3 . F#2 . C#3 . F#2 . - . B2 . F#3 . B2 . F#3 . C#3 . G#3 . C3 . G3 . B2 . F#3 . B2 . F#3 . F#2 . C#3 . B2 . - .'),drm:'k.h.k.h.'};
/* an original bouncy tune for the village at dusk */
TUNES.hvil={step:.24,mw:'triangle',mv:.42,mel:C1('A4 . C5 . E5 . A5 - G5 . E5 . C5 - D5 . E5 . D5 . C5 . B4 . G4 . B4 - - . A4 . C5 . E5 . A5 - G5 . E5 . C5 - D5 . F5 . E5 . D5 . C5 . B4 . A4 - - .'),
  bas:C1('A2 . E3 . A2 . E3 . C3 . G3 . C3 . G3 . G2 . D3 . G2 . D3 . E2 . B2 . E2 . B2 . A2 . E3 . A2 . E3 . C3 . G3 . C3 . G3 . D3 . A3 . E2 . B2 . A2 . E3 . A2 . - .'),drm:'k..hk.h.'};
const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;if(HW.on()&&typeof W!=='undefined'&&W&&W.area){const id=W.area.id;if(id==='village')return 'hvil';if(id==='castle'&&!(G().unmask))return 'hmk';
    if(window.HSTORY&&HSTORY.sneak&&HSTORY.sneak()===W.area.island)return 'hmk';}return _mk();};
/* a pizzicato bounce on the island tunes */
const _ps=playStep;playStep=function(T,i,t){_ps(T,i,t);if(!HW.on()||!AC||T===TUNES.hmk||T===TUNES.disco)return;if(i%2===0){const m=T.mel&&T.mel[i%T.mel.length];if(m)try{tone(m.f*2,t,.07,'triangle',.06,musF);}catch(e){}}};

/* ================= real-date pumpkins: 31 October, by the Pup House, whatever the season ================= */
const isHallo=()=>{const d=new Date();return d.getMonth()===9&&d.getDate()===31;};
{const _ea=enterArea;enterArea=function(id){_ea.apply(this,arguments);if(id!=='village'||!isHallo()||!W.area||W.area.id!=='village')return;const ph=W.things.find(t=>/Pup House/.test(t.label||''));if(!ph)return;
  [[-2.4,1.6],[2.4,1.6],[0,2.8]].forEach((q,i)=>{const p=near(W.area,ph.x+q[0],ph.z+q[1],1);pk(p[0],p[1],.9+i*.15,ORNG,true,ph.x,ph.z+6);});flushTo(W.ag);
  if(!HW.on()){const y=new Date().getFullYear(),k='hw31_'+y;state.acts=state.acts||{};if(!state.acts[k]){state.acts[k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say('Happy Halloween, Seb! Look, there are lit pumpkins by the Pup House tonight!');},2600);}}};}

/* ================= build hooks ================= */
window.HWORLD={build(A){if(A.id==='village')try{villageH(A);}catch(e){console.warn('hw village',e);}},
  after(A){GRD=null;if(BX&&W.area&&W.area.id!=='digcamp')BX=null;try{decor(A);if(ISL[A.id])ISL[A.id](A);flushTo(W.ag);}catch(e){console.warn('hw island',A.id,e);}
    if(A.id==='village'&&window.HSTORY&&HSTORY.villageAfter)try{HSTORY.villageAfter(A);}catch(e){}},
  pk,bunting,boneXylo,startSpot,skeleton,near,isHallo};
const css=document.createElement('style');css.textContent=`.hrobo{display:flex;gap:12px;justify-content:center;margin:12px 0;flex-wrap:wrap}.hrobo .opt{display:flex;flex-direction:column;align-items:center;font-size:18px;padding:8px 12px;max-width:220px}
#hbone{z-index:60}#hbCard{max-width:900px;width:94%;background:#fff3e6}#hbBox svg{width:640px;max-width:100%;height:auto;display:block;margin:6px auto}#hbSvg .hbb{cursor:pointer}#hbSvg .hbb.hit rect{fill:#ffe9a8}#hbMsg{min-height:34px;font-size:26px;font-weight:800}`;
document.head.appendChild(css);
})();
