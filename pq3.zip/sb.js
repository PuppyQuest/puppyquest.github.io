/* ================================================================
   Summer Beach Party (Pup Seasons 4, 26 Nov 2026; claude/summer-beach-design.md): the engine.
   A bright summer's day (sun, seagulls, fluffy clouds), Seb's hermit crab (named by Seb; its shell
   is far too small), the three hiding tricks (treasure maps on a grid, then dig; paw prints to a beach
   hut; giant sandcastles with shell pictures), finding a summer pup, the nine map pieces from the
   unicorns, the opening, the invitation and the grown-ups switch.
   Shares window.SEASONS, the Season Globe and the spot planner grid with season.js.
   Save: state.sx.sb = {pal:{name,girl,at}, found:{id:time}, how:{id:kind}, tagged:{id:1},
   mp:{island:time}, inv, intro, ...}; created only once Summer Beach Party is opened and started.
   ================================================================ */
(function(){
const PI=Math.PI,SL=window.SBLOOK,SP=SL.SPUPS,sp=SL.sp,FACT=SL.FACT,XM=window.XMAS,SAND='#f2d896',SEA='#2fb3d8',RED='#e8503a';
const G0=()=>(state&&state.sx&&state.sx.sb)||null;
const GS=()=>{if(!state.sx)state.sx={};const s=state.sx;if(!s.sb)s.sb={found:{},how:{},tagged:{},mp:{}};if(!s.sb.mp)s.sb.mp={};return s.sb;};
const on=()=>!!(state&&state.season==='sb');
const hwDone=()=>!!(state&&state.sx&&state.sx.hw&&state.sx.hw.done);
const opened=()=>hwDone()||!!(state&&state.set&&state.set.sbOpen);
const named=()=>!!(G0()&&G0().pal);
let ALL=null;
const all=()=>ALL||(ALL=ISLANDS.reduce((a,I)=>a.concat(I.pups,I.bonus||[]),[]).concat([SP.breeze,SP.sorbet]));
const gpup=id=>PUPS[id]||SP[id];
const xFound=id=>!!(G0()&&G0().found[id]);
const nFound=()=>G0()?all().filter(p=>xFound(p.id)).length:0;
const islX=I=>I.pups.concat(I.bonus||[]);
const islN=I=>islX(I).filter(p=>xFound(p.id)).length;
const areaX=a=>all().filter(p=>p.area===a);
const nMp=()=>Object.keys((G0()||{}).mp||{}).length;
const pal=()=>(G0()&&G0().pal)||{name:'the little crab',girl:false};
const he=()=>pal().girl?'she':'he',his=()=>pal().girl?'her':'his',him=()=>pal().girl?'her':'him',He=()=>pal().girl?'She':'He';
const kindOf=p=>p.season==='sb'||p.bonus?'castle':p.tag?'hut':'dig';
const NEED=6;
const hsh=s=>{let h=7;for(const ch of String(s))h=(h*31+ch.charCodeAt(0))%100003;return h;};
const mixC=(a,b,k)=>{const c=new THREE.Color(a||'#888888');c.lerp(new THREE.Color(b),k);return '#'+c.getHexString();};

/* ---------------- sounds ---------------- */
const SCALE=[523,587,659,698,784,880,988,1047,1175];/* one note per map piece */
const snd={
 click(){if(!fxOk())return;const t=AC.currentTime;[0,.09].forEach(d=>{nzHit(t+d,.03,.16,'highpass',3600);tone(1800,t+d,.03,'square',.03);});},
 dig(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.16,.18,'bandpass',900,null,.8);nzHit(t+.18,.14,.14,'bandpass',1200,null,.8);},
 splash(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.45,.16,'highpass',1800);nzHit(t+.05,.3,.1,'bandpass',600);},
 wave(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.9,.08,'lowpass',900);nzHit(t+.3,.8,.06,'highpass',2400);},
 gull(){if(!fxOk())return;const t=AC.currentTime;tone(1500,t,.16,'triangle',.07,null,1100);tone(1600,t+.22,.2,'triangle',.07,null,1000);},
 door(){if(!fxOk())return;const t=AC.currentTime;tone(320,t,.18,'triangle',.08,null,520);nzHit(t,.05,.1,'lowpass',500);},
 twinkle(){if(!fxOk())return;const t=AC.currentTime;[1319,1568,2093,2637].forEach((f,i)=>tone(f,t+i*.08,.22,'sine',.09));},
 note(i){if(!fxOk())return;const t=AC.currentTime,f=SCALE[i%9];tone(f,t,.4,'triangle',.13);tone(f*2,t,.2,'sine',.04);},
 song(n,gap){for(let i=0;i<n;i++)setTimeout(()=>snd.note(i),i*(gap||240));}};

/* ================= the summer look ================= */
const NOSB=new Set(['den','cave','glow','vault','ambercave','library','alien']);
const SUN={sky:'#ffffff',gr:'#e8d8a0',hi:.8,dir:'#fff2cc',di:.62,pos:[70,100,40]};
const MUSEUM={sky:'#fffaf0',gr:'#e8dcc0',hi:.86,dir:'#fff6dc',di:.36,pos:[20,90,10]};
const sunny=A=>!!(A&&!NOSB.has(A.id)&&!A.indoor);
const museum=A=>!!(A&&A.indoor&&A.island==='number');
function lookFor(A){if(museum(A))return {light:Object.assign({},MUSEUM)};if(!sunny(A))return null;
  const space=(A.island||A.id)==='planet',o={light:Object.assign({},SUN)};
  if(!space){o.sky=A.swim?'#4ab8e8':'#8fd4ff';o.fogC=A.swim?'#4ab8e8':'#bfe6ff';o.fog=A.swim?[50,190]:[80,260];o.skyObj=Object.assign({},A.skyObj||{},{sun:{az:-50,el:14,size:64},moon:null,stars:false,flies:0});}
  if(A.swim){o.light.hi=.86;o.light.sky='#e0f6ff';}return o;}
let GLT=null,GULLT=null,CLOUDT=null,PRINTT=null;
const canvasTex=(w,h,f)=>{const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'));return new THREE.CanvasTexture(c);};
function glowTex(){return GLT||(GLT=canvasTex(64,64,x=>{const g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.3,'rgba(255,255,255,.7)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);}));}
function gullTex(){return GULLT||(GULLT=canvasTex(64,64,x=>{x.strokeStyle='#5a6070';x.lineWidth=7;x.lineCap='round';x.lineJoin='round';x.beginPath();x.moveTo(4,26);x.quadraticCurveTo(18,14,32,30);x.quadraticCurveTo(46,14,60,26);x.stroke();
  x.strokeStyle='#ffffff';x.lineWidth=4;x.beginPath();x.moveTo(6,26);x.quadraticCurveTo(18,16,32,30);x.quadraticCurveTo(46,16,58,26);x.stroke();}));}
function cloudTex(){return CLOUDT||(CLOUDT=canvasTex(256,128,x=>{x.fillStyle='rgba(255,255,255,.95)';[[70,80,40],[120,62,52],[175,78,42],[100,88,36],[150,92,36]].forEach(q=>{x.beginPath();x.arc(q[0],q[1],q[2],0,PI*2);x.fill();});}));}
function printTex(){return PRINTT||(PRINTT=canvasTex(64,64,x=>{x.fillStyle='#ffffff';x.beginPath();x.ellipse(32,40,12,10,0,0,PI*2);x.fill();[[18,24],[27,17],[37,17],[46,24]].forEach(q=>{x.beginPath();x.ellipse(q[0],q[1],5,6,0,0,PI*2);x.fill();});}));}
function glowMat(col,op){return new THREE.SpriteMaterial({map:glowTex(),color:col||'#fff2a0',transparent:true,opacity:op==null?.9:op,depthWrite:false,blending:THREE.AdditiveBlending,fog:false});}
/* seagulls wheeling high up, as one points cloud */
function gulls(A,n){const P=new Float32Array(n*3),B=[],R=seed(hsh(A.id)+5);for(let i=0;i<n;i++)B.push([R()*PI*2,16+R()*24,18+R()*12,.18+R()*.25,R()*6,R()<.5?1:-1]);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({size:2.4,map:gullTex(),transparent:true,alphaTest:.3,depthWrite:false,fog:false});
  const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);
  const tick=()=>{if(W.area!==A||!pts.parent)return true;const t=W.t;for(let i=0;i<n;i++){const b=B[i],a=b[0]+t*b[3]*b[5];P[i*3]=Math.cos(a)*b[1];P[i*3+1]=b[2]+Math.sin(t*.8+b[4])*1.5;P[i*3+2]=Math.sin(a)*b[1];}
    m.size=2.2+Math.abs(Math.sin(t*3))*.4;g.attributes.position.needsUpdate=true;};W.ticks.push(tick);tick();return pts;}
/* a few fluffy clouds drifting far away */
function clouds(A){const R=seed(hsh(A.id)+11),L=[];for(let i=0;i<5;i++){const m=new THREE.SpriteMaterial({map:cloudTex(),transparent:true,depthWrite:false,fog:false,opacity:.9}),s=new THREE.Sprite(m),a=R()*PI*2,d=230+R()*60;
    s.scale.set(70+R()*40,35+R()*20,1);s.position.set(Math.cos(a)*d,40+R()*30,Math.sin(a)*d);W.ag.add(s);W.disp.push(m);L.push({s,a,d});}
  W.ticks.push(dt=>{if(W.area!==A)return true;L.forEach(q=>{q.a+=dt*.004;q.s.position.x=Math.cos(q.a)*q.d;q.s.position.z=Math.sin(q.a)*q.d;});});}

/* ================= entering an area in summer ================= */
const _ea=enterArea;
enterArea=function(id,pos,msg){const A=AREAS[id];
  if(!A||!on())return _ea.apply(this,arguments);
  const o=lookFor(A),keep={};if(o)for(const k in o){keep[k]=[k in A,A[k]];A[k]=o[k];}
  if(!msg&&named()&&G0().intro){const L=areaX(id),left=L.filter(p=>!xFound(p.id)).length;if(L.length)msg=`${A.icon} ${A.name} in summer! `+(left?`${left===1?'One pup is':left+' pups are'} hiding here. Listen to ${pal().name}'s claws!`:'Every pup here is found!');}
  try{_ea.call(this,id,pos,msg);}finally{for(const k in keep){if(keep[k][0])A[k]=keep[k][1];else delete A[k];}}
  if(W.area!==A)return;
  if(sunny(A)&&(A.island||A.id)!=='planet'){if(!A.swim){gulls(A,A.id==='village'?9:6);clouds(A);}}
  if(window.SBWORLD&&SBWORLD.after)try{SBWORLD.after(A);}catch(e){console.warn('sb after',e);}
  palEnter(A);hud();
  const I=A.island&&islandOf(A.island);if(I&&named()&&G0().intro&&islN(I)>=NEED&&!G0().mp[I.id])setTimeout(()=>{if(W.area===A&&!player.lock&&!ovOpen())piece(I);},1800);
  if(id==='village')setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village')return;if(window.SBSTORY&&SBSTORY.village)SBSTORY.village();},900);};
Object.values(AREAS).forEach(A=>{const b=A.build;if(typeof b!=='function')return;A.build=function(){b.apply(this,arguments);if(on()&&window.SBWORLD&&SBWORLD.build)try{SBWORLD.build(A);}catch(e){console.warn('sb build',e);}};});

/* ================= hiding spots ================= */
const _bs=buildSpots;buildSpots=function(A){if(!on())return _bs(A);if(SB.noSpots)return;sSpots(A);};
const _bb=buildBoss;buildBoss=function(IS){if(!on())return _bb(IS);uniHome(IS);};
const _ac=areaCount;areaCount=function(a){if(!on())return _ac(a);const L=areaX(a);return L.length?`🐚 ${L.filter(p=>xFound(p.id)).length}/${L.length}`:'';};
let PLAN=null,LIVE=[];
function spotFor(p,A){const S=(window.SBSPOTS||{})[p.id];if(S)return S;if(!PLAN||PLAN.area!==A.id){PLAN=plan(A);PLAN.area=A.id;}return PLAN.spots[p.id]||null;}
function sSpots(A){LIVE=[];areaX(A.id).forEach(p=>{const S=spotFor(p,A);if(!S)return;const k=S.k||kindOf(p);try{
    if(k==='dig')LIVE.push(digSpot(p,S,A));else if(k==='castle')LIVE.push(castleSpot(p,S,A));else if(k==='hut')LIVE.push(hutSpot(p,S,A));}catch(e){console.warn('sb spot',p.id,e);}});
  W.ticks.push(spotTick);}
const gridN=isl=>['meadow','snowy','reef','village'].indexOf(isl)>=0?4:5;
/* 1. a treasure map on a grid: a square of sand marked out with rope, a spade and a little flag */
function digSpot(p,S,A){const isl=A.island||'village',n=gridN(isl),x=S.x,z=S.z,y=gy(x,z),half=2.3,found=xFound(p.id);
  mk('plane',A.swim?'#f6e6b0':SAND,half*2,1,half*2,x,y+.05,z,W.ag);
  for(let i=0;i<=n;i++){const d=-half+i*half*2/n;I('box','#b8864a',half*2,.05,.07,x,y+.08,z+d);I('box','#b8864a',.07,.05,half*2,x+d,y+.08,z);}
  [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>I('cyl','#9b6a43',.08,.7,.08,x+q[0]*half,y+.35,z+q[1]*half));
  I('cyl','#c98a4f',.05,1.3,.05,x+half+.5,y+.65,z-half+.3,0,0,.25);I('box','#aab3c0',.4,.5,.06,x+half+.36,y+.12,z-half+.3,0,0,.25);
  I('cyl','#ffffff',.04,2.2,.04,x-half-.4,y+1.1,z+half+.2);I('box',RED,.7,.45,.04,x-half-.04,y+1.95,z+half+.2,0,0,0,true);
  const o={p,k:'dig',x,z,n,num:isl==='number',noX:['number','gadget','rescue','dino','planet'].indexOf(isl)>=0,right:[1+hsh(p.id+'a')%n,1+hsh(p.id+'u')%n],tries:0};
  if(!found)o.easy=spr('🗺️',1.6,x,y+4,z);else markFound(o);
  W.things.push({x,z,r:4.6,icon:'🗺️',label:'Treasure map!',show:()=>!xFound(p.id),act:()=>openDig(o)});return o;}
/* 3. a giant sandcastle on a ring of shells */
function sandcastle3D(par,s,open){const g=grp();g.scale.setScalar(s||1);par.add(g);const S1='#e8c87a',S2='#d8b468';
  mk('box',S1,2.4,1.2,2.4,0,.6,0,g);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>{mk('cyl',S2,.5,1.9,.5,q[0]*1.15,.95,q[1]*1.15,g);mk('cone',S1,.55,.6,.55,q[0]*1.15,2.2,q[1]*1.15,g);});
  mk('cyl',S1,.8,1.1,.8,0,1.75,0,g);mk('cone',S2,.85,.8,.85,0,2.7,0,g);mk('cyl','#ffffff',.03,.9,.03,0,3.4,0,g);mk('box',RED,.4,.26,.03,.2,3.7,0,g,true);
  for(let i=0;i<5;i++)mk('box',S2,.34,.24,.24,-.9+i*.45,1.32,1.2,g);mk('box',open?'#5a3a2a':'#c8a058',.6,.75,.05,0,.38,1.22,g);
  [[-.6,.95],[.6,.95],[0,1.55]].forEach(q=>mk('sph','#ffd2a8',.09,.07,.05,q[0],q[1],1.23,g));return g;}
function castleSpot(p,S,A){const found=xFound(p.id),y=gy(S.x,S.z),g=grp();sandcastle3D(g,1.15,found);add(g,S.x,S.z);bakeModel(g,'sbcastle'+(found?1:0));
  const R=seed(hsh(p.id));for(let i=0;i<14;i++){const a=i/14*PI*2,r=3.1;I('sph',['#ffd2a8','#ffffff','#ffb4c8','#f6e0b0'][i%4],.22,.12,.18,S.x+Math.cos(a)*r,y+.08,S.z+Math.sin(a)*r,0,R()*PI,0);}
  const m=new THREE.MeshBasicMaterial({color:'#fff2a0',transparent:true,opacity:.6,depthWrite:false}),ring=new THREE.Mesh(G.tor||G.sph,m);ring.scale.set(3.1,3.1,.3);ring.rotation.x=PI/2;ring.position.set(S.x,y+.14,S.z);W.ag.add(ring);W.disp.push(m);
  const o={p,k:'castle',x:S.x,z:S.z,ring,m,g};if(!A.ski)col(S.x,S.z,1.9);
  if(found)markFound(o);else o.glow=spr('🐚',1.6,S.x,y+4.6,S.z);
  W.things.push({x:S.x,z:S.z,r:4.8,icon:'🏰',label:'The giant sandcastle',show:()=>!xFound(p.id),act:()=>openCastle(o)});return o;}
function markFound(o){if(o.easy){W.ag.remove(o.easy);o.easy=null;}if(o.glow){W.ag.remove(o.glow);o.glow=null;}if(o.ring)o.m.opacity=.22;
  if(!o.mark)o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+(o.k==='castle'?4.4:3.4),o.z);}
/* 2. paw prints in the sand lead to a little striped beach hut */
function prints(pts,A){const step=1.25,out=[];for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.floor(d/step)),ang=Math.atan2(b[0]-a[0],b[1]-a[1]);
    for(let k=0;k<n;k++){const t=k/n,side=(out.length%2?1:-1)*.28;out.push([a[0]+(b[0]-a[0])*t+Math.cos(ang)*side,a[1]+(b[1]-a[1])*t-Math.sin(ang)*side,ang]);}}
  const col=A&&A.swim?'#2a6a8a':(A&&A.island==='snowy')?'#6a7a9a':'#8a6238',m=new THREE.MeshBasicMaterial({map:printTex(),color:col,transparent:true,opacity:.85,alphaTest:.3,depthWrite:false}),
    im=new THREE.InstancedMesh(G.plane,m,Math.max(1,out.length)),M4=new THREE.Matrix4(),q=new THREE.Quaternion(),s=new THREE.Vector3(.62,1,.62),v=new THREE.Vector3(),e=new THREE.Euler();
  out.forEach((p,i)=>{e.set(0,p[2]+PI,0);q.setFromEuler(e);v.set(p[0],walkY(p[0],p[1])+.07,p[1]);M4.compose(v,q,s);im.setMatrixAt(i,M4);});
  im.count=out.length;im.frustumCulled=false;W.ag.add(im);W.disp.push(m);return {im,m,n:out.length};}
const HUTC=[['#ff7fb8','#ffffff'],['#5ab8ff','#ffffff'],['#ffd23f','#ff8a3c'],['#8ae05a','#ffffff'],['#b88aff','#ffffff']];
function hut3D(key){const g=grp(),c=HUTC[hsh(key)%HUTC.length];
  mk('box',c[1],1.5,1.7,1.3,0,.95,0,g);for(let i=0;i<4;i++)mk('box',c[0],.19,1.7,1.32,-.56+i*.375,.95,0,g);
  [-1,1].forEach(s=>{const r=mk('box','#e8423a',.95,.1,1.5,s*.4,2.02,0,g);r.rotation.z=-s*.6;});mk('box','#8a5a3a',1.7,.12,1.5,0,.06,.1,g);
  mk('box','#6a4a3a',.62,1.12,.06,0,.68,.67,g);mk('sph','#ffd23f',.05,.05,.05,.2,.7,.72,g,true);mk('cyl','#ffffff',.03,.8,.03,0,2.6,0,g);mk('box',c[0],.36,.22,.03,.18,2.85,0,g,true);
  g.scale.setScalar(DS);return g;}
const DS=1.6;
function hutSpot(p,S,A){const tagged=!!(G0()&&G0().tagged[p.id]),found=xFound(p.id),to=tagged?S.c:S.b,path=tagged?S.bc:S.ab;
  const o={p,k:'hut',S,x:to[0],z:to[1],tagged};o.g=hut3D(p.id+(tagged?'c':'b'));add(o.g,o.x,o.z);o.g.rotation.y=hsh(p.id+(tagged?'c':'b'))%6;bakeModel(o.g,'sbhut|'+hsh(p.id+(tagged?'c':'b'))%HUTC.length);col(o.x,o.z,1.6);
  if(found){o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+4.6,o.z);return o;}
  o.pr=prints(path||[[tagged?S.b[0]:S.a[0],tagged?S.b[1]:S.a[1]],to],A);o.easy=spr('🐾',1.6,o.x,gy(o.x,o.z)+4.9,o.z);
  o.th={x:o.x,z:o.z,r:3.9,icon:'👀',label:'Peek in the hut!',show:()=>!xFound(p.id)&&!o.busy,act:()=>peek(o)};W.things.push(o.th);return o;}
function spotTick(dt){const t=W.t,P=player;let near=null,nd=1e9;
  LIVE.forEach(o=>{if(o.easy){o.easy.visible=state.set.hsEasy;o.easy.position.y=gy(o.x,o.z)+(o.k==='hut'?5:4)+Math.sin(t*3)*.3;}if(o.glow)o.glow.position.y=gy(o.x,o.z)+4.6+Math.sin(t*2.5)*.25;
    if(o.ring&&!xFound(o.p.id)){o.m.opacity=.45+.3*Math.sin(t*2.6);o.ring.rotation.z=t*.3;}
    if(xFound(o.p.id))return;const d=Math.hypot(P.x-o.x,P.z-o.z);if(d<nd){nd=d;near=o;}});
  if(near&&nd<9&&t-(SB.jT||0)>2.8&&!P.lock&&!ovOpen()){SB.jT=t;if(near.k==='dig')snd.dig();else if(near.k==='castle')snd.twinkle();else{sfx.yip((near.p.pitch||1)*1.1);floatS('🐾',near.x,gy(near.x,near.z)+2.6,near.z,1.2);}}
  if(near&&!P.lock&&t-W.findT>75&&t-W.hintT>75){W.hintT=t;sparkTrail(near);}}
function sparkTrail(o){W.trail.forEach(s=>W.ag.remove(s));W.trail=[];const P=player,dx=o.x-P.x,dz=o.z-P.z,d=Math.hypot(dx,dz),n=Math.min(10,Math.floor((d-3)/2.5));
  for(let i=1;i<=n;i++){const x=P.x+dx*i/(n+1.2),z=P.z+dz*i/(n+1.2);W.trail.push(spr('🐚',1.1,x,gy(x,z)+.6,z));}
  PAL.jump=.7;snd.click();say(`${pal().name} is clicking like mad! Follow the shells, Seb!`);}

/* ----- the dig picker: read the treasure map, then dig ----- */
const DUG=[['🦀','A little crab waves hello!'],['⭐','A starfish!'],['🩴','Somebody\'s lost flip-flop!'],['🦆','A rubber duck. Squeak!'],['🪣','A red bucket!'],['🧦','A sandy sock. Pooh!'],['🐚','A pretty seashell!']];
function coordClue(v){if(v<=1)return '1';const R=Math.random();if(v%2===0&&R<.3)return `double ${v/2}`;if(R<.7){const a=1+Math.floor(Math.random()*(v-1));return `${a} add ${v-a}`;}const b=1+Math.floor(Math.random()*3);return `${v+b} take away ${b}`;}
function mapSVG(n,X,o){o=o||{};const S=100/n;let s=`<svg viewBox="-14 -8 128 128" class="sbmap"><path d="M-10 -4 H110 V108 Q100 114 90 108 T70 108 T50 108 T30 108 T10 108 T-10 108 Z" fill="#f4e2b0" stroke="#8a6238" stroke-width="3"/>`;
  for(let i=0;i<=n;i++)s+=`<path d="M${i*S} 0 V100 M0 ${i*S} H100" stroke="#c8a870" stroke-width="1.4"/>`;
  for(let i=1;i<=n;i++)s+=`<text x="${(i-.5)*S}" y="${100+11}" font-size="10" font-weight="900" text-anchor="middle" fill="#5a3a20" font-family="Arial">${i}</text><text x="-7" y="${100-(i-.5)*S+4}" font-size="10" font-weight="900" text-anchor="middle" fill="#5a3a20" font-family="Arial">${i}</text>`;
  if(X&&!o.noX){const cx=(X[0]-.5)*S,cy=100-(X[1]-.5)*S,r=S*.28;s+=`<path d="M${cx-r} ${cy-r} L${cx+r} ${cy+r} M${cx+r} ${cy-r} L${cx-r} ${cy+r}" stroke="#e8423a" stroke-width="5" stroke-linecap="round"/>`;}
  if(o.paw)s+=`<text x="${100-S*.5}" y="${S*.7}" font-size="${S*.5}" text-anchor="middle">🐾</text>`;
  return s+'</svg>';}
let PK=null;
function pickUI(){if($('#sbpick'))return;const d=el('div','ov','<div class="card" id="sbpCard"><h2 id="sbpH"></h2><div id="sbpWrap"><div id="sbpMap"></div><div id="sbpGrid"></div></div><p id="sbpMsg"></p><div class="btns"><button class="btn white" id="sbpBack">Back</button></div></div>');d.id='sbpick';document.body.appendChild(d);
  tap('#sbpBack',()=>{sfx.boop();closeDig();});}
function closeDig(){$('#sbpick').classList.remove('on');player.lock=false;PK=null;hush();}
function gridHTML(n,cell){let h=`<div class="sbg" style="grid-template-columns:34px repeat(${n},${cell}px);grid-template-rows:repeat(${n},${cell}px) 34px">`;
  for(let u=n;u>=1;u--){h+=`<b class="sbu" data-u="${u}">${u}</b>`;for(let a=1;a<=n;a++)h+=`<button class="sbc" data-a="${a}" data-u="${u}"></button>`;}
  h+='<i class="sbo">↗</i>';for(let a=1;a<=n;a++)h+=`<b class="sba" data-a="${a}">${a}</b>`;return h+'</div>';}
function openDig(o){if(player.lock||xFound(o.p.id))return;pickUI();player.lock=true;hush();snd.dig();PK=o;o.tries=0;o.dug={};
  const F=pal().name,n=o.n,[ax,uy]=o.right;o.ca=o.num?coordClue(ax):String(ax);o.cu=o.num?coordClue(uy):String(uy);
  $('#sbpMap').innerHTML=mapSVG(n,o.right,{noX:o.noX})+`<div class="sbclue"><b>${o.ca}</b> across<br><b>${o.cu}</b> up</div>`;
  $('#sbpGrid').innerHTML=gridHTML(n,n>4?76:90);$('#sbpMsg').textContent='Along the bottom first, then up!';
  $('#sbpH').textContent=o.num?'🔢 Work out the numbers, then dig!':'🗺️ Read the treasure map, then dig!';
  speak(o.num?`${F} reads the map: ${o.ca} across, and ${o.cu} up. Work out the numbers, then dig!`:`${F} reads the map: ${ax} across, ${uy} up. Along the bottom first, then up. Where should we dig?`);
  document.querySelectorAll('#sbpGrid .sbc').forEach(b=>tap(b,()=>tapSquare(o,+b.dataset.a,+b.dataset.u,b)));
  $('#sbpick').classList.add('on');}
function showWay(o){const [ax,uy]=o.right,G=$('#sbpGrid');G.querySelectorAll('.sba,.sbu,.sbc').forEach(e=>e.classList.remove('way'));
  for(let a=1;a<=ax;a++)setTimeout(()=>{const e=G.querySelector(`.sba[data-a="${a}"]`);if(e)e.classList.add('way');},a*280);
  for(let u=1;u<=uy;u++)setTimeout(()=>{const e=G.querySelector(`.sbu[data-u="${u}"]`);if(e)e.classList.add('way');},(ax+u)*280+150);}
function tapSquare(o,a,u,b){if(PK!==o||o.dug[a+','+u])return;o.dug[a+','+u]=1;b.classList.remove('hint');b.classList.add('dug');snd.dig();
  if(a===o.right[0]&&u===o.right[1]){sfx.yip(o.p.pitch);b.innerHTML=`<div class="sbpup">${critterSVG(sp(o.p),{anim:false})}</div>`;b.classList.add('win');$('#sbpMsg').textContent=`X marks the spot! It's ${o.p.name}!`;
    setTimeout(()=>{closeDig();markFound(o);found(o.p,'dig',o);},1300);return;}
  o.tries++;const S=DUG[(hsh(o.p.id)+o.tries*3+a+u)%DUG.length];sfx.oops();b.innerHTML=`<span class="sbdug">${S[0]}</span>`;
  const [ax,uy]=o.right;let m=`${S[0]==='🦆'?'Squeak! ':''}${S[1]} The map says ${o.num?`${o.ca} across, which is ${ax}, and ${o.cu} up, which is ${uy}`:`${ax} across, ${uy} up`}.`;
  m+=` Along the bottom: ${Array.from({length:ax},(v,i)=>i+1).join(', ')}. Then up: ${Array.from({length:uy},(v,i)=>i+1).join(', ')}.`;showWay(o);
  if(o.tries>=2){const r=$('#sbpGrid').querySelector(`.sbc[data-a="${ax}"][data-u="${uy}"]`);if(r)r.classList.add('hint');m+=' Look, that square is sparkling!';}
  $('#sbpMsg').textContent=m;speak(m);}
/* tag pups: the first peek makes them giggle and run to another hut along fresh paw prints */
function peek(o){if(player.lock||xFound(o.p.id))return;player.lock=true;o.busy=true;hush();snd.door();say('Knock knock! Anybody in the beach hut?');o.g.scale.set(DS*1.04,DS*.96,DS*1.04);
  setTimeout(()=>{o.g.scale.setScalar(DS);if(!o.tagged){runOff(o);return;}o.busy=false;player.lock=false;found(o.p,'hut',o);},1100);}
function runOff(o){const p=o.p,S=o.S,g=pup3D(p,p.shiny),A=W.area;add(g,o.x,o.z);sfx.giggle();say(`Hee hee! ${p.name} giggles and runs off to another beach hut! Follow the new paw prints!`);
  GS().tagged[p.id]=1;save();const path=(S.bc||[S.b,S.c]).slice();let seg=0,k=0;
  if(o.pr){W.ag.remove(o.pr.im);o.pr=null;}if(o.easy){W.ag.remove(o.easy);o.easy=null;}
  W.ticks.push(function run(dt){if(W.area!==A)return true;const a=path[seg],b=path[seg+1];if(!b){W.ag.remove(g);W.ag.remove(o.g);const n=hutSpot(p,S,A);LIVE=LIVE.filter(q=>q!==o);LIVE.push(n);W.things=W.things.filter(t=>t!==o.th);flushTo(W.ag);player.lock=false;return true;}
    const d=Math.hypot(b[0]-a[0],b[1]-a[1])||.01;k+=dt*14/d;const e=Math.min(1,k),x=a[0]+(b[0]-a[0])*e,z=a[1]+(b[1]-a[1])*e;g.position.set(x,walkY(x,z)+Math.abs(Math.sin(W.t*16))*.35,z);g.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);animPup(g,W.t,true);
    if(e>=1){seg++;k=0;}});}

/* ================= shell pictures on the giant sandcastle (join the shells in order) ================= */
const starPts=(()=>{const o=[];for(let i=0;i<10;i++){const a=-PI/2+i*PI/5,r=i%2?13:30;o.push([+(50+Math.cos(a)*r).toFixed(1),+(40+Math.sin(a)*r).toFixed(1)]);}return o;})();
const SHAPES={
 star:starPts,
 shell:[[50,68],[30,60],[18,46],[16,32],[24,20],[37,13],[50,11],[63,13],[76,20],[84,32],[82,46],[70,60]],
 crab:[[50,62],[34,60],[24,52],[14,50],[8,40],[12,28],[20,24],[18,34],[26,38],[34,32],[50,30],[66,32],[74,38],[82,34],[80,24],[88,28],[92,40],[86,50],[76,52],[66,60]],
 boat:[[26,64],[12,50],[44,50],[44,10],[80,46],[90,50],[76,64]],
 fish:[[12,40],[26,28],[44,22],[62,26],[74,36],[90,24],[86,40],[90,56],[74,44],[62,54],[44,58],[26,52]]};
const STEP={meadow:1,snowy:1,reef:2,ninja:2,number:3,gadget:5,rescue:5,dino:10,planet:10,village:2};
let CP=null;
function castleUI(){if($('#sbcastle'))return;const d=el('div','ov','<div class="card" id="sbcCard"><h2 id="sbcH"></h2><div id="sbcBox"></div><p id="sbcMsg"></p><div class="btns"><button class="btn white" id="sbcBack">Back</button></div></div>');d.id='sbcastle';document.body.appendChild(d);
  tap('#sbcBack',()=>{sfx.boop();closeCastle();});}
function closeCastle(){$('#sbcastle').classList.remove('on');if(CP&&CP.lock!==false)player.lock=false;const cb=CP&&CP.cancel;CP=null;hush();if(cb)cb();}
function shellDot(x,y,r){return `<path d="M${x-r} ${y+r*.6} Q${x-r*1.2} ${y-r*.8} ${x} ${y-r} Q${x+r*1.2} ${y-r*.8} ${x+r} ${y+r*.6} Q${x} ${y+r*1.2} ${x-r} ${y+r*.6} Z" fill="#fff4e4" stroke="#8a5a3a" stroke-width=".35"/><path d="M${x} ${y+r*.8} V${y-r*.7} M${x} ${y+r*.8} L${x-r*.55} ${y-r*.55} M${x} ${y+r*.8} L${x+r*.55} ${y-r*.55}" stroke="#d89a6a" stroke-width=".3"/>`;}
function castlePuzzle(o){castleUI();const pts=o.pts,step=o.step||1,start=o.start!=null?o.start:step,lab=i=>start+i*step,n=pts.length;CP={o,i:0,lock:o.lock,cancel:o.cancel};$('#sbcBack').style.display=o.noBack?'none':'';
  $('#sbcBox').innerHTML=`<svg viewBox="0 0 100 75" id="sbcSvg"><rect width="100" height="75" rx="4" fill="#8fd4ff"/><rect y="9" width="100" height="7" fill="${SEA}"/><path d="M0 16 q5 -2 10 0 t10 0 t10 0 t10 0 t10 0 t10 0 t10 0 t10 0 t10 0 t10 0 V75 H0 Z" fill="#f2d896"/>`+
    `<path d="M6 16 V7 h3 v2 h2 v-2 h3 v9 Z M86 16 V7 h3 v2 h2 v-2 h3 v9 Z" fill="#e8c87a" opacity=".8"/><circle cx="88" cy="4" r="3" fill="#ffd23f"/>`+
    `<g id="sbcLines"></g><g id="sbcPic" opacity="0">${o.pic||''}</g>`+
    pts.map((p,i)=>`<g class="sbcd" data-i="${i}"><circle cx="${p[0]}" cy="${p[1]}" r="5.4" fill="transparent"/><circle class="sbcg" cx="${p[0]}" cy="${p[1]}" r="2.4" fill="#ffffff" opacity=".35"/>${shellDot(p[0],p[1],1.5)}<text x="${p[0]+(p[0]>88?-3.4:2.2)}" y="${p[1]+(p[1]<8?4.8:-2)}" font-size="3.4" font-weight="900" fill="#ffffff" stroke="#5a3a20" stroke-width=".55" paint-order="stroke" font-family="Arial" text-anchor="${p[0]>88?'end':'start'}">${lab(i)}</text></g>`).join('')+`</svg>`;
  $('#sbcH').textContent=o.title||'🏰 Press the shells into the sand!';const intro=o.say||`Tap the shells in order: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;$('#sbcMsg').textContent=step===1?'Start at 1 and keep going!':`Count in ${step}s: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;speak(intro);
  const mark=()=>document.querySelectorAll('#sbcSvg .sbcd').forEach(g=>g.classList.toggle('next',+g.dataset.i===CP.i));mark();
  document.querySelectorAll('#sbcSvg .sbcd').forEach(g=>tap(g,()=>{if(!CP||CP.o!==o)return;const i=+g.dataset.i;
    if(i!==CP.i){if(i<CP.i)return;sfx.oops();const m=`Look for ${lab(CP.i)}.`;$('#sbcMsg').textContent=m;speak(m);g.classList.remove('nope');void g.getBBox();g.classList.add('nope');return;}
    snd.note(i);g.classList.add('done');if(i>0){const a=pts[i-1],b=pts[i];$('#sbcLines').insertAdjacentHTML('beforeend',`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#a8784a" stroke-width="1.3" stroke-linecap="round" stroke-dasharray="1.6 1"/>`);}
    CP.i++;if(CP.i<n){mark();$('#sbcMsg').textContent=`${lab(i)}! Next: ${lab(CP.i)}`;return;}
    if(o.loop!==false){const a=pts[n-1],b=pts[0];$('#sbcLines').insertAdjacentHTML('beforeend',`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#a8784a" stroke-width="1.3" stroke-linecap="round" stroke-dasharray="1.6 1"/>`);
      $('#sbcLines').insertAdjacentHTML('afterbegin',`<polygon class="sbclit" points="${pts.map(p=>p.join(',')).join(' ')}" fill="#ffe0b0"/>`);}
    mark();$('#sbcSvg').classList.add('win');$('#sbcPic').setAttribute('opacity','1');snd.twinkle();confetti(24);const m=o.win||'A shell picture!';$('#sbcMsg').textContent=m;speak(m);
    const done=o.done;CP.cancel=null;setTimeout(()=>{if(!$('#sbcastle').classList.contains('on'))return;$('#sbcastle').classList.remove('on');if(o.lock!==false)player.lock=false;CP=null;if(done)done();},o.hold||1900);}));
  $('#sbcastle').classList.add('on');}
function openCastle(o){if(player.lock||xFound(o.p.id))return;player.lock=true;hush();snd.twinkle();const isl=o.p.island,sh=o.p.id==='breeze'?'boat':o.p.id==='sorbet'?'star':['star','shell','crab','fish','boat'][hsh(o.p.id)%5];
  let step=STEP[isl]||1;if(isl==='number'&&typeof tablesOn==='function'){const tb=tablesOn();if(tb&&tb.length)step=pick(tb);}
  castlePuzzle({pts:SHAPES[sh],step,title:'🏰 Press the shells into the giant sandcastle!',
    say:`A giant sandcastle! Press the shells into the sand in order to make a picture.${step>1?` Count in ${step}s!`:''}`,win:'A shell picture! The sandcastle door is opening...',
    done:()=>{snd.splash();confetti(30);setTimeout(()=>{markFound(o);found(o.p,'castle',o);},700);}});}

/* ================= finding a summer pup ================= */
function found(p,how,o){const X=GS();if(X.found[p.id])return;X.found[p.id]=Date.now();X.how[p.id]=how;state.stars+=10;W.findT=W.t;W.trail.forEach(t=>W.ag.remove(t));W.trail=[];save();hud();
  const P=player,dx=P.x-o.x,dz=P.z-o.z,d=Math.hypot(dx,dz)||1,g=pup3D(p,p.shiny);add(g,o.x+dx/d*1.9,o.z+dz/d*1.9);g.rotation.y=Math.atan2(-dx,-dz)+PI;g.userData.jump=.8;
  player.cheer=1.3;player.wave=2.4;sfx.jingle();confetti(36);W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});
  const n=nFound(),where={dig:'dug up with a treasure map',hut:'peeking out of a beach hut',castle:'inside a giant sandcastle'}[how]||'';
  card({art:pupBox(sp(p)),h:`You found ${p.name}!`,h3:`🏖️ Summer · ${p.breed} ${typeBadge(p.type)}`,p:FACT[p.id]||p.fact,say:`You found ${p.name}, ${where}! ${FACT[p.id]||''}`,
    btns:[['☀️ Hooray!','green',()=>{W.ag.remove(g);PAL.jump=.8;setTimeout(()=>after(p,n),500);}]]});
  if(window.SBSTORY&&SBSTORY.onFind)try{SBSTORY.onFind(p);}catch(e){}}
function after(p,n){const I=islandOf(p.island);
  if(I&&islN(I)>=NEED&&!GS().mp[I.id]){setTimeout(()=>piece(I),400);return;}
  if(window.SBSTORY&&SBSTORY.afterFind&&SBSTORY.afterFind(p,n))return;
  if(n===all().length){say(`Every single summer pup is found! All ${n} of them! Fin-tastic, Seb!`);return;}
  const A=W.area,L=areaX(A.id),left=L.filter(q=>!xFound(q.id)).length;
  say(`${n} of ${all().length} summer pups found! `+(left?`${left} more ${left>1?'pups':'pup'} hiding in ${A.name}.`:`Every summer pup in ${A.name} is found!`)+(I&&!GS().mp[I.id]?` Find ${NEED-islN(I)} more on ${I.name} for a map piece!`:''));}

/* ================= the nine map pieces ================= */
const LESSON={blossom:'Everyone grows at their own speed, like flowers in summer.',flurry:'On a hot day, share your shade with a friend.',pearl:'The sea is home to so many creatures, so leave the beach as clean as you found it.',
 emberuni:'Be brave enough to try new things, like dipping your toes in the waves.',tally:'Take turns, and everyone gets a go. That is what makes a game fair.',gizmouni:'A good map helps everyone, so share what you know.',
 beaconuni:'Swim where the lifeguards can see you, between the red and yellow flags.',amberuni:'Big changes take time, like the tide coming in, so be patient.',nebulauni:'The Moon pulls the sea to make the tides. Even from far away, friends can pull you along.'};
/* the crab's treasure map: nine pieces, filled in as they come home */
function mapPieces(n,o){o=o||{};const L=ISLANDS.map(I=>I.id),got=(G0()||{}).mp||{};let s=`<svg viewBox="0 0 180 150" xmlns="http://www.w3.org/2000/svg"><rect x="4" y="4" width="172" height="142" rx="10" fill="#c8a870" stroke="#5a3a20" stroke-width="4"/>`;
  L.forEach((id,i)=>{const x=10+(i%3)*54,y=10+Math.floor(i/3)*44,has=o.all||(n!=null?i<n:!!got[id]);
    s+=`<rect x="${x}" y="${y}" width="52" height="42" rx="3" fill="${has?'#f4e2b0':'#a8885a'}" stroke="#8a6238" stroke-width="1.5" ${has?'':'stroke-dasharray="3 3"'}/>`;
    if(has){s+=`<path d="M${x+4} ${y+30} q12 -8 22 -2 t22 -4" stroke="#5ab8ff" stroke-width="3" fill="none"/>`;if(o.all||o.xs)s+=`<path d="M${x+20} ${y+12} l10 10 M${x+30} ${y+12} l-10 10" stroke="#e8423a" stroke-width="3.4" stroke-linecap="round"/>`;
      s+=`<text x="${x+44}" y="${y+14}" font-size="11" text-anchor="middle">${ISLANDS[i].icon}</text>`;}});
  if(o.all)s+=`<g transform="translate(132 112)"><circle r="13" fill="#ffffff" stroke="#5a3a20" stroke-width="2"/><path d="M-8 4 q8 -12 16 0 q-8 6 -16 0 Z" fill="#26232e"/><path d="M-9 -4 l9 -8 l9 8 Z" fill="#26232e"/><circle cx="2" cy="2" r="1.6" fill="#fff"/></g>`;
  return s+'</svg>';}
function piece(I){const u=I.boss.uni,P=player,X=GS();player.lock=true;hush();
  const a=P.h+.7,x=P.x+Math.sin(a)*4.5,z=P.z+Math.cos(a)*4.5,g=pup3D(u,true);add(g,x,z);g.rotation.y=Math.atan2(P.x-x,P.z-z);g.userData.jump=.9;snd.twinkle();confetti(30);floatS('🗺️',x,gy(x,z)+4,z,3);
  W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});const n=nMp()+1,F=pal().name;
  story([{art:`<div class="fitsvg">${critterSVG(sp(u))}</div>`,t:`${u.name} trots up in a sun hat and sunglasses! "You found ${NEED} summer pups on ${I.name}, and ${F} scuttled along beside you all the way."`},
    {art:`<div class="fitsvg">${critterSVG(sp(u))}</div><div style="font-size:64px;line-height:1">🗺️</div>`,t:`"The wind blew this piece of your map right onto my nose! Here is something to remember, ${F}: ${LESSON[u.id]||'Friends make every day sunnier.'}"`},
    {art:`<div class="fitsvg" style="width:240px">${mapPieces(n)}</div>`,t:`${F} fits the piece into the map. ${n} of 9 map pieces!`+(n===9?` The map is whole at last!`:` ${F} clicks ${his()} claws with joy.`)}],
    ()=>{X.mp[I.id]=Date.now();save();W.ag.remove(g);player.lock=false;PAL.jump=1;sfx.fanfare();snd.song(n);confetti(40);hud();
      if(window.SBSTORY&&SBSTORY.onPiece)try{SBSTORY.onPiece(I,n);}catch(e){}
      if(n<9)say(`${n} of 9 map pieces! Find ${NEED} summer pups on each island to collect them all.`);});}
function uniHome(IS){const B=IS.boss;if(!B||!B.uni||!(G0()&&G0().mp[IS.id]))return;if(W.bossUp===IS.id)return;W.bossUp=IS.id;const u=pup3D(B.uni,true);u.rotation.y=Math.atan2(-B.x,-B.z)+PI;add(u,B.x,B.z);col(B.x,B.z,1.4);
  W.ticks.push(()=>{animPup(u,W.t,false);});W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(`${B.uni.name} says: "${LESSON[B.uni.id]} Happy summer, Seb!"`);}});}

/* ================= Seb's hermit crab ================= */
const PAL={g:null,x:0,z:0,h:0,jump:0,step:0};
function crab3D(big){const g=grp(),b=grp();g.add(b);const C=RED,D='#c8402a',SH=big?'#ffd0dc':'#e8d0a8',SH2=big?'#ffffff':'#b8885a';
  /* the shell */
  const sh=grp();sh.position.set(0,.42,-.18);b.add(sh);const k=big?1.25:.9;mk('sph',SH,.42*k,.4*k,.46*k,0,0,0,sh);mk('sph',SH2,.3*k,.28*k,.32*k,0,.2*k,-.16*k,sh);mk('sph',SH,.18*k,.16*k,.18*k,0,.36*k,-.3*k,sh);mk('sph',SH2,.08*k,.08*k,.08*k,0,.46*k,-.38*k,sh);
  if(!big)mk('sph','#ff9a7a',.2,.16,.18,0,.08,-.5,b);
  /* body, eyes on stalks, claws and legs */
  mk('sph',C,.3,.2,.26,0,.24,.2,b);[-1,1].forEach(s=>{mk('cyl',D,.025,.26,.025,s*.1,.46,.32,b);mk('sph','#ffffff',.07,.07,.07,s*.1,.6,.33,b);mk('sph','#26232e',.035,.035,.035,s*.1,.61,.39,b);
    const big2=s<0?1:.7;mk('sph',C,.14*big2,.1*big2,.16*big2,s*.3,.2,.42,b);mk('cone',C,.05*big2,.14*big2,.05*big2,s*.3,.22,.58,b).rotation.x=PI/2;
    for(let i=0;i<2;i++){const l=mk('cyl',D,.03,.3,.03,s*.32,.12,.14-i*.16,b);l.rotation.z=s*1.1;}});
  bakeModel(g,big?'sbpal2':'sbpal');g.scale.setScalar(1.5);Object.assign(g.userData,{body:b});g.traverse(o=>{o.frustumCulled=false;});return g;}
function usePal(g){if(PAL.g&&PAL.g!==g&&PAL.g.parent)PAL.g.parent.remove(PAL.g);PAL.g=g;if(!g.parent)scene.add(g);}
function palEnter(A){if(!named()){if(PAL.g)PAL.g.visible=false;return;}
  const big=!!(G0()&&G0().done);if(!PAL.g||PAL.big!==big){usePal(crab3D(big));PAL.big=big;}PAL.g.visible=true;const P=player,a=P.h+PI/2;PAL.x=P.x+Math.sin(a)*1.6;PAL.z=P.z+Math.cos(a)*1.6;PAL.h=P.h;
  W.things.push({x:PAL.x,z:PAL.z,r:3.2,icon:'💬',label:pal().name,spal:1,show:()=>!followers.some(f=>Math.hypot(f.x-player.x,f.z-player.z)<2.3),act:palTalk});
  W.ticks.push(palTick);}
function palHide(){if(PAL.g)PAL.g.visible=false;}
/* after the Great Shell Swap the crab wears its new, bigger shell */
function palShell(){const big=!!(G0()&&G0().done);if(!PAL.g||PAL.big===big)return;const old=PAL.g,vis=old.visible,x=old.position.x,y=old.position.y,z=old.position.z,h=old.rotation.y;usePal(crab3D(big));PAL.big=big;PAL.g.visible=vis;PAL.g.position.set(x,y,z);PAL.g.rotation.y=h;}
function nearest(){let best=null,bd=1e9;LIVE.forEach(o=>{if(xFound(o.p.id))return;const d=Math.hypot(player.x-o.x,player.z-o.z);if(d<bd){bd=d;best=o;}});return best?{o:best,d:bd}:null;}
function palTick(dt){if(!PAL.g||!on())return true;if(!PAL.g.visible||PAL.script)return;const P=player,t=W.t,u=PAL.g.userData;
  const fx=Math.sin(P.h),fz=Math.cos(P.h),tx=P.x+fz*1.5-fx*.9,tz=P.z-fx*1.5-fz*.9,dx=tx-PAL.x,dz=tz-PAL.z,d=Math.hypot(dx,dz),mv=d>.2;
  if(d>.05){PAL.x+=dx*Math.min(1,dt*3.4);PAL.z+=dz*Math.min(1,dt*3.4);}if(d>26){PAL.x=tx;PAL.z=tz;}
  /* crabs scuttle sideways: face across the way it moves */
  PAL.h=lerpAng(PAL.h,mv?Math.atan2(dx,dz)+PI/2:P.h,Math.min(1,dt*6));if(PAL.jump>0)PAL.jump-=dt;PAL.step+=mv?dt*14:0;
  const hop=PAL.jump>0?Math.sin(PAL.jump*PI*1.6)*.6:0;
  PAL.g.position.set(PAL.x,walkY(PAL.x,PAL.z)+Math.abs(Math.sin(PAL.step))*(mv?.06:0)+hop+(W.area&&W.area.swim?1:0),PAL.z);PAL.g.rotation.y=PAL.h;
  const th=W.things.find(q=>q.spal);if(th){th.x=PAL.x;th.z=PAL.z;}
  /* warmer and colder: the claws click faster near a hiding pup */
  const n=nearest(),k=n?Math.max(0,Math.min(1,1-n.d/45)):0;u.body.rotation.z=mv?Math.sin(PAL.step)*.1:Math.sin(t*(3+16*k))*.06;u.body.position.y=Math.abs(Math.sin(t*(3+16*k)))*.04*k;
  if(n&&n.d<10&&t-(PAL.dingT||0)>3.4&&!P.lock&&!ovOpen()){PAL.dingT=t;snd.click();}
  if(t-(PAL.factT||0)>140&&!P.lock&&!ovOpen()&&t-W.msgT>20){PAL.factT=t;say(`${pal().name} says: "${pick(PFACT)}"`);}}
const PFACT=['Did you know? Hermit crabs live in empty seashells, and move into bigger ones as they grow.','Did you know? Hermit crabs have ten legs, and two of them are claws!','Did you know? The sea is salty because rain washes tiny bits of salt out of rocks, and rivers carry it to the sea.',
 'Did you know? The Moon pulls on the sea to make the tides. Most beaches have two high tides a day.','My shell is getting a bit squeezy. I need a bigger one!','Did you know? Many hermit crabs have one big claw and one small one.'];
function dir(o){const P=player,a=Math.atan2(o.x-P.x,o.z-P.z),r=angDiff(a,W.camYaw),d=Math.hypot(o.x-P.x,o.z-P.z);
  const w=Math.abs(r)<.6?'straight ahead':Math.abs(r)>2.4?'behind you':r>0?'over to your left':'over to your right';return `${w}, ${d<12?'really close':d<30?'not far away':'a long way off'}`;}
function palTalk(){if(player.lock)return;snd.click();PAL.jump=.6;const F=pal().name,n=nearest(),A=W.area;
  if(n){const o=n.o,w=dir(o);say(o.k==='dig'?`${F} says: "I can see a treasure map in the sand, ${w}!"`:o.k==='castle'?`${F} says: "There's a giant sandcastle, ${w}!"`:`${F} says: "Paw prints in the sand! They go ${w}. Let's follow them!"`);return;}
  const I=A.island&&islandOf(A.island),more=I?I.areas.filter(a=>areaX(a.id).some(p=>!xFound(p.id))):[];
  if(more.length)say(`${F} says: "Every pup here is found! Shall we try ${more[0].name}?"`);
  else if(I)say(`${F} says: "Every summer pup on ${I.name} is found! Let's try another island."`);
  else{const left=ISLANDS.find(I2=>islX(I2).some(p=>!xFound(p.id)));say(left?`${F} says: "Let's look for summer pups on ${left.name}!"`:`${F} says: "Happy summer, Seb!"`);}}
/* a picture of the hermit crab, for cards and story scenes */
function crabSVG(o){o=o||{};const K=INK,big=!!o.big,S1=big?'#ffd0dc':'#ead2a8',S2=big?'#ffffff':'#b8885a';
  const shell=big?`<path d="M58 132 Q40 70 96 52 Q156 40 160 100 Q162 140 120 146 Q76 152 58 132 Z" fill="${S1}" stroke="${K}" stroke-width="4"/><path d="M110 96 m-30 0 a30 30 0 1 0 60 0 a22 22 0 1 0 -44 0 a14 14 0 1 0 28 0 a7 7 0 1 0 -14 0" fill="none" stroke="#e8a0b8" stroke-width="4"/>`+
      `<path d="M70 120 Q100 134 140 124" stroke="${S2}" stroke-width="4" fill="none"/>`
    :`<path d="M86 132 Q72 92 108 78 Q146 70 150 106 Q152 136 124 142 Q100 146 86 132 Z" fill="${S1}" stroke="${K}" stroke-width="4"/><path d="M118 106 m-18 0 a18 18 0 1 0 36 0 a13 13 0 1 0 -26 0 a8 8 0 1 0 16 0" fill="none" stroke="${S2}" stroke-width="3.4"/>`+
      `<path d="M148 118 q22 4 26 18 q-14 4 -26 -4 Z" fill="#ff9a7a" stroke="${K}" stroke-width="3"/>`;
  const legs=[0,1,2].map(i=>`<path d="M${70+i*12} 146 l-${10+i*2} 20" stroke="${K}" stroke-width="8" stroke-linecap="round"/><path d="M${70+i*12} 146 l-${10+i*2} 20" stroke="${RED}" stroke-width="4.4" stroke-linecap="round"/>`).join('');
  const sweat=o.squeeze?`<path d="M166 92 q4 -8 0 -12 M174 104 q6 -6 4 -12" stroke="#5ab8ff" stroke-width="3" fill="none" stroke-linecap="round"/>`:'';
  const mapR=o.map?`<g transform="translate(6 120) rotate(-12)"><rect width="42" height="22" rx="5" fill="#f4e2b0" stroke="${K}" stroke-width="3"/><circle cx="4" cy="11" r="7" fill="#e8d0a0" stroke="${K}" stroke-width="3"/><path d="M14 14 q8 -10 14 -2" stroke="#8a5a2a" stroke-width="2" stroke-dasharray="3 3" fill="none"/></g>`:'';
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">${mapR}${legs}${shell}`+
    `<ellipse cx="78" cy="138" rx="30" ry="18" fill="${RED}" stroke="${K}" stroke-width="4"/>`+
    `<path d="M56 130 Q30 120 34 98" stroke="${K}" stroke-width="10" fill="none" stroke-linecap="round"/><path d="M56 130 Q30 120 34 98" stroke="${RED}" stroke-width="6" fill="none" stroke-linecap="round"/>`+
    `<path d="M34 98 q-16 -12 -4 -26 q4 10 14 12 q-8 2 -6 10 q8 -2 10 4 Z" fill="${RED}" stroke="${K}" stroke-width="3.4" stroke-linejoin="round"/>`+
    `<path d="M96 132 Q112 112 104 100" stroke="${K}" stroke-width="7" fill="none" stroke-linecap="round"/><path d="M96 132 Q112 112 104 100" stroke="${RED}" stroke-width="3.6" fill="none" stroke-linecap="round"/><path d="M104 100 q-10 -6 -4 -14 q4 6 10 6 Z" fill="${RED}" stroke="${K}" stroke-width="3"/>`+
    [66,84].map(x=>`<path d="M${x} 126 L${x-2} 96" stroke="${K}" stroke-width="5" stroke-linecap="round"/><circle cx="${x-2}" cy="92" r="9" fill="#fff" stroke="${K}" stroke-width="3.4"/><circle cx="${x}" cy="93" r="4.4" fill="${K}"/><circle cx="${x+1.4}" cy="91" r="1.4" fill="#fff"/>`).join('')+
    `<path d="M68 142 Q78 ${o.squeeze?140:148} 88 142" stroke="${K}" stroke-width="3" fill="none" stroke-linecap="round"/><circle cx="62" cy="140" r="4" fill="#ff9ec0" opacity=".8"/><circle cx="94" cy="140" r="4" fill="#ff9ec0" opacity=".8"/>${sweat}</svg>`;}

/* ================= the opening ================= */
const SUG=['Scuttle','Nipper','Winkle','Cockle','Limpet','Clicky'];
const cleanName=s=>{s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,18);return s?s.charAt(0).toUpperCase()+s.slice(1):'';};
const big=e=>`<div style="font-size:100px;line-height:1">${e}</div>`,csv=(w,o)=>`<div class="fitsvg" style="width:${w||170}px">${crabSVG(o)}</div>`;
function intro(){const X=GS();X.inv=1;save();player.lock=true;hush();
  story([{art:big('☀️🏖️'),t:'The sun is shining on Pawprint Village. Summer is here, and tonight is the Summer Beach Party!'},
    {art:`<div class="fitsvg" style="width:150px">${grannySVG()}</div>`,t:'"There will be a sandcastle contest," says Granny Paws, "and at sunset, the Great Treasure Swap! Every pup brought a little treasure to swap with a friend. But look: the treasure chest is empty!"'},
    {art:big('🏴‍☠️🐶'),t:'"The pups have gone off to play Pirate Hide-and-Seek all over the islands, and to look for the treasure. Pirate rules: every hider leaves a treasure map!"'}],
    ()=>{state.season='sb';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='sb'&&S.hide)try{S.hide();}catch(e){}});fadeTo(()=>{enterArea('village',[-5,17,PI]);arrive();},['🏖️','Summer Beach Party']);});}
function arrive(){const P=player,x=1.5,z=9;player.lock=true;W.camYaw=Math.atan2(x-P.x,z-P.z);P.h=W.camYaw;const D=crab3D(false);usePal(D);PAL.big=false;D.visible=true;PAL.script=true;PAL.x=x;PAL.z=z;
  const bk=grp();mk('cyl','#ff6a6a',.5,.7,.44,0,.35,0,bk);mk('tor','#26232e',.3,.3,.4,0,.78,0,bk);add(bk,x,z);bk.rotation.z=0;
  D.position.set(x,walkY(x,z),z);D.rotation.y=Math.atan2(P.x-x,P.z-z)+PI/2;D.scale.setScalar(.01);let t=0;snd.click();
  W.ticks.push(dt=>{t+=dt;bk.rotation.z=t<1?Math.sin(t*30)*.12:Math.min(1.5,(t-1)*4);bk.position.x=x+(t>1?Math.min(1.2,(t-1)*3):0);const k=Math.max(0,Math.min(1,(t-1.1)/.6));D.scale.setScalar(1.5*(.01+.99*k));
    if(t>1.1)D.position.x=x-Math.sin(t*14)*.15*(1-Math.min(1,(t-1.1)/2));if(t>3){meet();return true;}});}
function meet(){story([{art:csv(190,{squeeze:1,map:1}),t:'A bucket wobbles, tips over... and out scuttles a little hermit crab, dragging a rolled-up treasure map! Its shell is much too small: a bit of it pokes out at the back.'},
    {art:csv(190,{squeeze:1,map:1}),t:'"I found this map on the beach last night, in the moonlight," the little crab says. "Maybe it shows where the treasure went! Phew, my shell is SO squeezy."'}],()=>nameCard(()=>whoosh()));}
function nameCard(done){sfx.chime();
  card({art:csv(160),h:'Name the hermit crab!',p:`The little hermit crab doesn't have a name yet. What would you like to call it?<input id="sbName" maxlength="18" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="Type a name..."><span class="xSug">${SUG.map(s=>`<button class="opt">${s}</button>`).join('')}</span><span class="xSex"><button class="opt on" data-g="0">👦 Boy</button><button class="opt" data-g="1">👧 Girl</button></span>`,
    say:'The little hermit crab does not have a name yet. Type a name, or pick one. Is your crab a boy or a girl?',
    btns:[['✓ That\'s the name!','green',()=>{const n=cleanName($('#sbName').value)||pick(SUG),g=!!+(document.querySelector('#celeCard .xSex .on')||{dataset:{g:0}}).dataset.g;
      GS().pal={name:n,girl:g,at:Date.now()};save();sfx.fanfare();confetti(50);player.cheer=1.6;if(done)done();}]]});
  const inp=$('#sbName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .xSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));
  document.querySelectorAll('#celeCard .xSex .opt').forEach(b=>tap(b,()=>{document.querySelectorAll('#celeCard .xSex .opt').forEach(q=>q.classList.toggle('on',q===b));sfx.boop();}));}
function whoosh(){const F=pal().name;snd.wave();
  story([{art:csv(170,{map:1}),t:`"I'm ${F}!" ${F} unrolls the treasure map on the plaza... and WHOOSH! A big gust of sea wind tears it into nine pieces and blows them away over the islands!`},
    {art:`<div class="fitsvg" style="width:240px">${mapPieces(0)}</div>`,t:`Only the edge of the map is left, with "X marks the spot" in the corner. "Oh no!" says ${F}. "Maybe the unicorns can catch the pieces."`},
    {art:big('🗺️🏖️🏰'),t:'The pups are hiding under treasure maps in the sand (read the map, then dig!), in little beach huts at the end of paw prints, and inside giant sandcastles.'},
    {art:csv(150)+big('🦄'),t:`Find 6 pups on an island, and its unicorn will give ${F} a piece of the map. Collect all nine, and the map will show where the treasure is! ${F}'s claws click faster when a hidden pup is near.`}],
    ()=>{const X=GS();X.intro=Date.now();save();player.lock=false;PAL.script=false;palEnter(W.area);hud();say(`Let's find the summer pups! Take the ferry to Meadow Island, or any island you like. ${F} will come too!`);
      if(window.SBSTORY&&SBSTORY.onIntro)try{SBSTORY.onIntro();}catch(e){}});}
/* the invitation, once Summer Beach Party is open (earlier seasons' invitations go first) */
/* also when Seb is still in a finished Halloween (its goodbye used to leave him there) */
const seaFree=()=>!state.season||(state.season==='hw'&&hwDone());
const _ea3=enterArea;enterArea=function(id,pos,msg){_ea3.apply(this,arguments);if(!seaFree()||id!=='village'||!opened()||!state.intro)return;
  if(Object.values(window.SEASONS).some(S=>S.order<4&&S.opened()&&!(state.sx&&state.sx[S.id]&&state.sx[S.id].inv)))return;const X=G0();if(X&&(X.inv||X.pal))return;
  setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!seaFree()||!W.area||W.area.id!=='village')return;GS().inv=1;save();invite();},1900);};
function invite(){player.lock=true;sfx.chime();
  card({art:big('🏖️✨'),h:'🏖️ Summer Beach Party is here!',p:'The sun is shining on Pawprint Village, and tonight is the Summer Beach Party! But all the treasure has gone missing. Shall we go and see?',
    btns:[['🏖️ Yes, let\'s go!','green',()=>{player.lock=false;intro();}],['Not now','white',()=>{player.lock=false;say('Shake the Season Globe in the plaza whenever you want to play Summer Beach Party!');}]]});}
function fromHw(){if(named()){XM.setSeason('sb');return;}intro();}
/* the grown-ups switch */
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=$('#setCard');if(!c)return;const S=state.set;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`🏖️ Open Summer Beach Party early<div class="opts"><button class="opt${S.sbOpen?'':' on'}" data-x="0">Off</button><button class="opt${S.sbOpen?' on':''}" data-x="1">On</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=hwDone()?'Summer Beach Party is already open, because Halloween is finished. Shake the Season Globe in the village plaza to switch seasons.':'Summer Beach Party opens after Halloween is finished. Turn this on to open it now: an invitation arrives the next time Seb is in the village.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt').forEach(b=>tap(b,()=>{S.sbOpen=b.dataset.x==='1';if(!S.sbOpen&&!hwDone()&&state.season==='sb'){state.season=null;XM.rebuildPack();palHide();openSettings.dirty='season';}save();sfx.boop();const d=openSettings.dirty;openSettings();if(d)openSettings.dirty=d;}));};}

/* ================= the Shell Board (the Season Calendar for Summer Beach Party) ================= */
function board(){if(player.lock)return;sfx.chime();const n=nFound(),X=G0()||{mp:{}};
  const rows=ISLANDS.map(I=>`<div class="sbbRow"><b>${I.icon}</b>${islX(I).map(p=>`<i class="${xFound(p.id)?'lit':''}">🐚</i>`).join('')}<em>${X.mp&&X.mp[I.id]?'🗺️':''}</em></div>`).join('')+
    `<div class="sbbRow"><b>🌟</b>${[SP.breeze,SP.sorbet].map(p=>`<i class="${xFound(p.id)?'lit':''}">🐚</i>`).join('')}<em></em></div>`;
  card({cls:'sbboard',h:`🐚 The Shell Board: ${n} of ${all().length}`,p:`A shell shines for every summer pup you find. 🗺️ means that island's map piece is home.<div class="sbbGrid">${rows}</div>`,
    say:`${n} of ${all().length} summer pups found, and ${nMp()} of 9 map pieces.`,btns:[['OK','green']]});}

/* ================= planning hiding spots (offline for sb_spots.js, and as a fallback) ================= */
function plan(A){const out={spots:{}};const L=areaX(A.id);if(!L.length)return out;const Gd=XM.grid(A,1),R=seed(hsh(A.id)+53),chosen=[];
  const avoid=[];(W.exits||[]).forEach(e=>avoid.push([e.x,e.z,9]));W.things.forEach(t=>{if(!t.hpal&&!t.spal&&!t.gfly&&!t.xdeer)avoid.push([t.x,t.z,4.5]);});if(A.start)avoid.push([A.start[0],A.start[1],9]);
  L.forEach(p=>{if(p.spot)avoid.push([p.spot.x,p.spot.z,5]);if(p.tag)avoid.push([p.tag.x,p.tag.z,5]);
    [(window.XSPOTS||{})[p.id],(window.GSPOTS||{})[p.id],(window.HSPOTS||{})[p.id]].forEach(xs=>{if(!xs)return;if(xs.x!=null)avoid.push([xs.x,xs.z,6]);['b','c'].forEach(k=>{if(xs[k])avoid.push([xs[k][0],xs[k][1],5]);});});});
  const okAt=(p,sep)=>{if(avoid.some(a=>Math.hypot(p[0]-a[0],p[1]-a[1])<a[2]))return false;if(chosen.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<sep))return false;return true;};
  const st=A.start?Gd.snap(A.start[0],A.start[1],1):Gd.snap(0,0,1);if(st<0)return out;const B0=Gd.bfs(st);
  const best=(B,mc,sep,lo,hi,ideal)=>{let bk=-1,bs=-1e9;for(let k=0;k<Gd.N;k++){if(Gd.clr[k]<mc||B.D[k]>=1e9||B0.D[k]>=1e9)continue;const d=B.D[k];if(d<lo||d>hi)continue;const p=Gd.xz(k);if(!okAt(p,sep))continue;
      const sp2=chosen.length?Math.min(30,Math.min(...chosen.map(q=>Math.hypot(p[0]-q[0],p[1]-q[1])))):30,s=sp2*.6-Math.abs(d-ideal)*.25+R()*6;if(s>bs){bs=s;bk=k;}}return bk;};
  L.forEach(p=>{const k=kindOf(p);
    if(k==='hut'){let a=p.spot?Gd.snap(p.spot.x,p.spot.z,1):-1;if(a<0||B0.D[a]>=1e9)a=st;const Ba=Gd.bfs(a),b=best(Ba,2,10,15,40,26);if(b<0)return;chosen.push(Gd.xz(b));
      const Bb=Gd.bfs(b);let c2=-1,bs=-1e9;const pa=Gd.xz(a);for(let q=0;q<Gd.N;q++){if(Gd.clr[q]<2||Bb.D[q]>=1e9)continue;const d=Bb.D[q];if(d<14||d>34)continue;const pq=Gd.xz(q);if(Math.hypot(pq[0]-pa[0],pq[1]-pa[1])<10||!okAt(pq,10))continue;const s=-Math.abs(d-22)*.3+R()*6;if(s>bs){bs=s;c2=q;}}
      if(c2<0)return;chosen.push(Gd.xz(c2));const P2=k2=>Gd.xz(k2).map(v=>+v.toFixed(1));
      out.spots[p.id]={k:'hut',a:P2(a),b:P2(b),c:P2(c2),ab:Gd.path(Ba,b),bc:Gd.path(Bb,c2)};}
    else{const kk=best(B0,3,12,12,140,40);if(kk<0)return;const q=Gd.xz(kk);chosen.push(q);out.spots[p.id]={k,x:+q[0].toFixed(1),z:+q[1].toFixed(1)};}});
  return out;}

/* ================= look and API ================= */
const css=document.createElement('style');css.textContent=`
#sbpick,#sbcastle{z-index:60}#sbpCard{max-width:980px;width:96%;background:#fff8e6;padding-top:12px;padding-bottom:10px}#sbpCard h2{margin:0 0 6px}
#sbpWrap{display:flex;gap:18px;align-items:center;justify-content:center}#sbpMap{width:250px;display:flex;flex-direction:column;align-items:center}#sbpMap .sbmap{width:220px;height:auto}
.sbclue{font-size:28px;font-weight:900;line-height:1.15;text-align:center;margin-top:4px;background:#fff;border:4px solid #8a6238;border-radius:16px;padding:6px 14px}.sbclue b{color:#e8423a;font-size:34px}
.sbg{display:grid;gap:4px}.sbg .sbc{background:#f2d896;border:3px solid #b8864a;border-radius:10px;padding:0;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:44px;overflow:hidden;
 background-image:radial-gradient(circle at 30% 40%,rgba(160,110,60,.25) 2px,transparent 3px),radial-gradient(circle at 70% 70%,rgba(160,110,60,.2) 2px,transparent 3px)}
.sbg .sbc.dug{background:#c8a870}.sbg .sbc.win{background:#ffe9a8}.sbg .sbc .sbdug{animation:xpop .5s}.sbg .sbc .sbpup{width:100%;animation:xpop .6s}.sbg .sbc .sbpup svg{width:100%;height:auto;display:block}
.sbg .sbc.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 5px #ffd23f}
.sbg b{display:flex;align-items:center;justify-content:center;font-size:24px;font-weight:900;color:#5a3a20;border-radius:10px}.sbg b.way{background:#ffd23f;animation:xpop .4s}.sbg .sbo{font-style:normal;font-size:20px;opacity:.5;display:flex;align-items:center;justify-content:center}
#sbpMsg,#sbcMsg{min-height:34px;font-size:24px;font-weight:800;margin:6px 0}
#sbcCard{max-width:980px;width:96%;background:#fff8e6}#sbcBox svg{width:620px;max-width:100%;height:auto;display:block;margin:4px auto;border-radius:18px}#sbcCard h2{margin:0}#sbcCard{padding-top:14px;padding-bottom:12px}
#sbcSvg .sbcd{cursor:pointer}#sbcSvg .sbcd.next .sbcg{opacity:1;fill:#ffd23f;animation:hcPulse 1s ease-in-out infinite;transform-box:fill-box;transform-origin:center}#sbcSvg .sbcd.done .sbcg{opacity:.9;fill:#ffb070}
#sbcSvg .sbcd.nope{animation:hcNo .4s}#sbcSvg .sbclit{opacity:0;transition:opacity 1s}#sbcSvg.win .sbclit{opacity:.9;filter:drop-shadow(0 0 2px #ffd23f)}#sbcPic{transition:opacity 1s}
@keyframes hcPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.6)}}@keyframes hcNo{0%,100%{transform:translateX(0)}30%{transform:translateX(-1px)}60%{transform:translateX(1px)}}
#sbName{display:block;width:420px;margin:12px auto 8px;font-size:30px;font-weight:900;padding:10px 16px;border:4px solid #26232e;border-radius:18px;text-align:center;font-family:inherit;color:#26232e}
.sbbGrid{margin-top:8px}.sbbRow{display:flex;align-items:center;gap:2px;justify-content:center;margin:1px 0}.sbbRow b{width:34px;font-size:24px}.sbbRow em{width:30px;font-style:normal}
.sbbRow i{width:24px;height:24px;font-style:normal;font-size:18px;line-height:24px;display:inline-block;filter:grayscale(1) opacity(.35)}.sbbRow i.lit{filter:none;text-shadow:0 0 8px #ffd23f}`;
document.head.appendChild(css);
window.SEASONS.sb={id:'sb',order:4,name:'Summer Beach Party',short:'Summer',icon:'🏖️',tag:'🏖️',card:['🏖️','Summer Beach Party cards'],lockShort:'After Halloween',
  on,opened,named,nFound,total:()=>all().length,invite,hide:palHide,
  book:{xp:sp,found:xFound,islX,islN,fact:id=>FACT[id],tag:'🏖️',word:'summer',isl:I=>`${I.name} in summer`}};
const SB=window.SB={on,opened,named,GS,G0,all,gpup,xFound,nFound,islN,islX,areaX,nMp,pal,he,his,him,He,found,crabSVG,crab3D,usePal,PAL,snd,plan,board,intro,fromHw,invite,
  castlePuzzle,SHAPES,sandcastle3D,hut3D,prints,mapSVG,mapPieces,gridHTML,coordClue,glowMat,glowTex,palEnter,palHide,palShell,LIVE:()=>LIVE,NEED,LESSON,kindOf,noSpots:false,SCALE,mixC,DUG,piece};
})();
