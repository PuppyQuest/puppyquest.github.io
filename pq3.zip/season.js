/* ================================================================
   Pup Seasons (25 Nov 2026), starting with Christmas Snow (claude/christmas-snow-design.md).
   The engine: season saving and switching, the grown-ups switch, the invitation and the
   opening story, snowy looks and falling snow, Seb's young reindeer (named by Seb), the two
   hiding tricks (jingling presents and footprints in the snow), finding a Christmas pup,
   and the nine star sparkles the unicorns hand back.
   Save: state.season (null or 'xmas'); state.sx.xmas = {deer:{name,girl}, found:{id:time},
   how:{id:kind}, tagged:{id:1}, sp:{island:time}, inv, intro, ...}. Seb's main-game pups and
   progress never change. Island looks, the story finale and the cards live in xmas_*.js.
   ================================================================ */
(function(){
const PI=Math.PI,XL=window.XLOOK,XP=XL.XPUPS,xp=XL.xp,FACT=XL.FACT;
const XS=()=>{if(!state.sx)state.sx={};const s=state.sx;if(!s.xmas)s.xmas={found:{},how:{},tagged:{},sp:{}};return s.xmas;};
const on=()=>!!(state&&state.season==='xmas');
const congaDone=()=>{const c=state&&state.conga;return !!(c&&(c.done||c.leg>=10));};
const opened=()=>congaDone()||!!(state&&state.set&&state.set.xmasOpen);
const named=()=>!!(state&&state.sx&&state.sx.xmas&&state.sx.xmas.deer);
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
/* every season registers itself here (25 Nov: Night Glow made this shared) */
window.SEASONS=window.SEASONS||{};
window.XOPEN=()=>!!(state&&state.season&&window.SEASONS[state.season]);

/* ---------------- the 119 Christmas pups ---------------- */
let ALL=null;
const all=()=>ALL||(ALL=ISLANDS.reduce((a,I)=>a.concat(I.pups,I.bonus||[]),[]).concat([XP.holly,XP.tinsel]));
const xpup=id=>PUPS[id]||XP[id];
const xFound=id=>!!(state&&state.sx&&state.sx.xmas&&state.sx.xmas.found[id]);
const nFound=()=>all().filter(p=>xFound(p.id)).length;
const islX=I=>I.pups.concat(I.bonus||[]);
const islN=I=>islX(I).filter(p=>xFound(p.id)).length;
const areaX=a=>all().filter(p=>p.area===a);
const nSp=()=>Object.keys(XS().sp||{}).length;
const deer=()=>XS().deer||{name:'the reindeer',girl:true};
const he=()=>deer().girl?'she':'he',his=()=>deer().girl?'her':'his',him=()=>deer().girl?'her':'him';
const kindOf=p=>p.season?(p.id==='tinsel'?'gold':'pile'):p.bonus?'gold':p.tag?'trail':'pile';
const NEED=6;

/* ---------------- sounds ---------------- */
const snd={
 bells(n){if(!fxOk())return;const t=AC.currentTime;for(let i=0;i<(n||6);i++){const q=t+i*.11+Math.random()*.03;tone(2350+Math.random()*500,q,.08,'sine',.07);tone(3150+Math.random()*400,q+.02,.06,'sine',.05);nzHit(q,.05,.06,'highpass',7000);}},
 whump(){if(!fxOk())return;const t=AC.currentTime;tone(120,t,.4,'sine',.7,null,40);nzHit(t,.3,.4,'lowpass',600);},
 crunch(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.07,.18,'bandpass',2200,null,1.5);nzHit(t+.06,.05,.12,'bandpass',1800,null,1.5);},
 boing(){if(!fxOk())return;const t=AC.currentTime;tone(220,t,.35,'sine',.3,null,660);tone(330,t+.08,.25,'triangle',.15,null,880);},
 twinkle(){if(!fxOk())return;const t=AC.currentTime;[1760,2093,2637,3136].forEach((f,i)=>tone(f,t+i*.08,.25,'sine',.1));}};

/* ================= the snowy look ================= */
const NOSNOW=new Set(['cave','glow','vault','ambercave','library','den']);
const mixC=(a,b,k)=>{const c=new THREE.Color(a||'#888888');c.lerp(new THREE.Color(b),k);return '#'+c.getHexString();};
function snowMode(A){if(!A||NOSNOW.has(A.id)||A.swim)return null;const isl=A.island||A.id;if(isl==='planet'||A.id==='alien')return null;
  if(isl==='snowy'||isl==='number'||A.id==='icet'||A.id==='firet'||A.id==='ridge')return 'fall';return 'full';}
const TO_SNOW=new Set(['','village','pinewood','ninja']);
function lookFor(A){const m=snowMode(A);if(m!=='full')return null;const o={ground:mixC(A.ground,'#f3f7fb',.82),ground2:mixC(A.ground2||A.ground,'#dbe6f1',.78),sky:mixC(A.sky||'#a6dfff','#dfe9f2',.35)};
  if(TO_SNOW.has(A.biome||''))o.biome='snow';return o;}
let flakeT=null;
function flakeTex(){if(flakeT)return flakeT;const c=document.createElement('canvas');c.width=c.height=32;const x=c.getContext('2d'),g=x.createRadialGradient(16,16,0,16,16,16);
  g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.45,'rgba(255,255,255,.85)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,32,32);flakeT=new THREE.CanvasTexture(c);return flakeT;}
function snowfall(A,n,o){o=o||{};const H=o.h||22,R=o.r||32,P=new Float32Array(n*3),V=new Float32Array(n);
  for(let i=0;i<n;i++){P[i*3]=player.x+(Math.random()*2-1)*R;P[i*3+1]=player.y+Math.random()*H-2;P[i*3+2]=player.z+(Math.random()*2-1)*R;V[i]=.9+Math.random()*1.3;}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({color:'#ffffff',size:o.size||.38,map:flakeTex(),transparent:true,depthWrite:false,opacity:.95});
  const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);
  W.ticks.push(dt=>{if(W.area!==A)return true;const t=W.t,px=player.x,pz=player.z,py=player.y;
    for(let i=0;i<n;i++){const j=i*3;P[j+1]-=V[i]*dt*(o.speed||1.6);P[j]+=Math.sin(t*.7+i)*dt*.35;
      if(P[j+1]<py-3){P[j+1]+=H;}if(P[j]-px>R)P[j]-=2*R;else if(P[j]-px<-R)P[j]+=2*R;if(P[j+2]-pz>R)P[j+2]-=2*R;else if(P[j+2]-pz<-R)P[j+2]+=2*R;}
    g.attributes.position.needsUpdate=true;});
  return pts;}

/* ================= entering an area in Christmas Snow ================= */
let ENTER=null;
const _ea=enterArea;
enterArea=function(id,pos,msg){const A=AREAS[id];
  if(!A||!on())return _ea.apply(this,arguments);
  const o=lookFor(A),keep={};if(o)for(const k in o){keep[k]=[k in A,A[k]];A[k]=o[k];}ENTER=A;
  try{_ea.apply(this,arguments);}finally{ENTER=null;for(const k in keep){if(keep[k][0])A[k]=keep[k][1];else delete A[k];}}
  if(W.area!==A)return;
  const m=snowMode(A);if(m)snowfall(A,m==='full'?650:A.indoor?260:520);
  if(window.XWORLD&&XWORLD.after)try{XWORLD.after(A);}catch(e){console.warn('xmas after',e);}
  deerEnter(A);hud();
  const I=A.island&&islandOf(A.island);if(I&&named()&&XS().intro&&islN(I)>=NEED&&!XS().sp[I.id])setTimeout(()=>{if(W.area===A&&!player.lock&&!ovOpen())sparkle(I);},1800);
  if(id==='village')setTimeout(()=>villageNews(),900);};
/* decorations go in while the area is being built, so they join the instanced meshes */
Object.values(AREAS).forEach(A=>{const b=A.build;if(typeof b!=='function')return;A.build=function(){b.apply(this,arguments);if(on()&&window.XWORLD&&XWORLD.build)try{XWORLD.build(A);}catch(e){console.warn('xmas build',e);}};});
/* in December, snow falls on the village in the normal game too */
const _ea2=enterArea;enterArea=function(id){_ea2.apply(this,arguments);if(!state.season&&id==='village'&&W.area&&W.area.id==='village'&&new Date().getMonth()===11)snowfall(W.area,420);};

/* ================= hiding spots ================= */
const _bs=buildSpots;buildSpots=function(A){if(!on())return _bs(A);if(XM.noSpots)return;xSpots(A);};
const _bb=buildBoss;buildBoss=function(IS){if(!on())return _bb(IS);uniHome(IS);};
const _ac=areaCount;areaCount=function(a){if(!on())return _ac(a);const L=areaX(a);return L.length?`🎁 ${L.filter(p=>xFound(p.id)).length}/${L.length}`:'';};
const SPOTS=()=>window.XSPOTS||{};
let PLAN=null;
function spotFor(p,A){const S=SPOTS()[p.id];if(S)return S;if(!PLAN||PLAN.area!==A.id){PLAN=plan(A);PLAN.area=A.id;}return PLAN.spots[p.id]||null;}
let LIVE=[];
function xSpots(A){LIVE=[];areaX(A.id).forEach(p=>{const S=spotFor(p,A);if(!S)return;const k=S.k||kindOf(p);try{
    if(k==='pile')LIVE.push(pile(p,S,A));else if(k==='gold')LIVE.push(gold(p,S,A));else if(k==='trail')LIVE.push(trail(p,S,A));}catch(e){console.warn('xmas spot',p.id,e);}});
  W.ticks.push(spotTick);}
const NUMK=['0️⃣','1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
const PCOL=[['#d9363e','#ffd23f'],['#2f9a54','#ffffff'],['#2b4a8a','#ffd23f'],['#ff7fb8','#ffffff'],['#8a5ad6','#ffd23f'],['#f3ead8','#d9363e'],['#ffb000','#2f9a54']];
const hsh=s=>{let h=7;for(const ch of String(s))h=(h*31+ch.charCodeAt(0))%100003;return h;};
function present3D(c,s,par){const g=grp();g.scale.setScalar(s);const lid=grp();lid.position.y=.9;g.add(lid);
  mk('box',c[0],1,.9,1,0,.45,0,g);mk('box',c[1],.18,.92,1.02,0,.45,0,g);mk('box',c[1],1.02,.92,.18,0,.45,0,g);
  mk('box',c[0],1.1,.22,1.1,0,.08,0,lid);mk('box',c[1],.2,.24,1.12,0,.08,0,lid);mk('box',c[1],1.12,.24,.2,0,.08,0,lid);
  [-1,1].forEach(q=>{const b=mk('sph',c[1],.26,.16,.12,q*.2,.3,0,lid);b.rotation.z=q*.5;});mk('sph',c[1],.1,.1,.1,0,.28,0,lid);
  if(par)par.add(g);return {g,lid};}
function pile(p,S,A){const R=seed(hsh(p.id)+7),n=5+(hsh(p.id)%2),G0=grp(),ps=[],right=hsh(p.id+'r')%n,found=xFound(p.id),num=A.island==='number';
  for(let i=0;i<n;i++){const a=i/n*PI*2+R()*.5,r=i?1.35+R()*.35:0.2,s=.62+R()*.38,c=PCOL[(hsh(p.id)+i*3)%PCOL.length],q=present3D(c,s,G0);q.g.position.set(Math.cos(a)*r,0,Math.sin(a)*r);q.g.rotation.y=R()*PI;q.s=s;q.c=c;ps.push(q);}
  add(G0,S.x,S.z);bakeModel(G0,'xpile'+n+'|'+p.id);if(A.id&&!A.ski)col(S.x,S.z,1.1);
  const o={p,k:'pile',x:S.x,z:S.z,g:G0,ps,right,n,num,wob:0,easy:null,mark:null,tries:0};
  if(num){const R2=seed(hsh(p.id)+3),used={};o.nums=ps.map(()=>{let v;do{v=2+Math.floor(R2()*9);}while(used[v]);used[v]=1;return v;});
    ps.forEach((q,i)=>{const sp=spr(NUMK[o.nums[i]],.8,S.x+q.g.position.x,gy(S.x,S.z)+q.s*1.25+.45,S.z+q.g.position.z);o.tags=o.tags||[];o.tags.push(sp);});}
  if(found)markFound(o);else o.easy=spr('✨',1.6,S.x,gy(S.x,S.z)+3.6,S.z);
  W.things.push({x:S.x,z:S.z,r:4.2,icon:'🎁',label:'Presents!',show:()=>!xFound(p.id),act:()=>openPile(o)});return o;}
function gold(p,S,A){const G0=grp(),q=present3D(['#ffd23f','#ffffff'],1.25,G0),found=xFound(p.id);add(G0,S.x,S.z);bakeModel(G0,'xgold');
  const o={p,k:'gold',x:S.x,z:S.z,g:G0,ps:[q],wob:0};if(!A.ski)col(S.x,S.z,1);
  o.glow=spr('✨',2.2,S.x,gy(S.x,S.z)+2.4,S.z);if(found)markFound(o);
  W.things.push({x:S.x,z:S.z,r:4,icon:'🌟',label:'Gold present!',show:()=>!xFound(p.id),act:()=>openGold(o)});return o;}
function markFound(o){if(o.easy){W.ag.remove(o.easy);o.easy=null;}if(o.glow){W.ag.remove(o.glow);o.glow=null;}if(!o.mark)o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+3.4,o.z);
  const q=o.ps[o.k==='pile'?o.right:0];if(q){q.lid.position.y=1.35;q.lid.rotation.z=.9;q.lid.position.x=.5;}}

/* ----- footprints in the snow ----- */
let pawT=null;
function pawTex(){if(pawT)return pawT;const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');x.fillStyle='#ffffff';
  x.beginPath();x.ellipse(32,40,13,11,0,0,PI*2);x.fill();[[16,22],[27,15],[39,15],[50,22]].forEach(q=>{x.beginPath();x.ellipse(q[0],q[1],6,7.5,0,0,PI*2);x.fill();});pawT=new THREE.CanvasTexture(c);return pawT;}
function prints(pts,A,col){const step=1.25,out=[];for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.floor(d/step));
    for(let k=0;k<n;k++){const t=k/n,x=a[0]+(b[0]-a[0])*t,z=a[1]+(b[1]-a[1])*t,h=Math.atan2(b[0]-a[0],b[1]-a[1]),side=(out.length%2?1:-1)*.32;out.push([x+Math.cos(h)*side,z-Math.sin(h)*side,h]);}}
  const m=new THREE.MeshBasicMaterial({map:pawTex(),color:col||'#9fe0ff',transparent:true,opacity:.85,depthWrite:false}),im=new THREE.InstancedMesh(G.plane,m,Math.max(1,out.length)),M4=new THREE.Matrix4(),q=new THREE.Quaternion(),s=new THREE.Vector3(.62,1,.62),v=new THREE.Vector3(),e=new THREE.Euler();
  out.forEach((p,i)=>{e.set(0,p[2]+PI,0);q.setFromEuler(e);v.set(p[0],walkY(p[0],p[1])+.07,p[1]);M4.compose(v,q,s);im.setMatrixAt(i,M4);});im.count=out.length;im.frustumCulled=false;W.ag.add(im);W.disp.push(m);return {im,m,n:out.length};}
function mound(A,par){const c=A.swim?'#f0dca8':A.island==='planet'?'#cfd2da':'#ffffff',g=grp();mk('hemi',c,1.5,1,1.3,0,0,0,g);mk('hemi',c,.9,.75,.8,.9,0,.5,g);mk('hemi',c,.8,.6,.9,-.8,0,-.4,g);if(par)par.add(g);return g;}
function trail(p,S,A){const tagged=!!XS().tagged[p.id],found=xFound(p.id),to=tagged?S.c:S.b,path=tagged?S.bc:S.ab;
  const o={p,k:'trail',S,x:to[0],z:to[1],tagged,wob:0};o.g=mound(A);add(o.g,o.x,o.z);bakeModel(o.g,'xmound|'+(A.swim?1:A.island==='planet'?2:0));
  if(found){o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+3,o.z);return o;}
  o.pr=prints(path||[[tagged?S.b[0]:S.a[0],tagged?S.b[1]:S.a[1]],to],A,A.swim?'#bff4ff':'#8fdcff');o.easy=spr('✨',1.6,o.x,gy(o.x,o.z)+3.2,o.z);
  o.th={x:o.x,z:o.z,r:3.8,icon:'🔍',label:'Look',show:()=>!xFound(p.id)&&!o.busy,act:()=>searchMound(o)};W.things.push(o.th);return o;}
function spotTick(dt){const t=W.t,P=player;let near=null,nd=1e9;
  LIVE.forEach(o=>{if(o.easy){o.easy.visible=state.set.hsEasy;o.easy.position.y=gy(o.x,o.z)+3.4+Math.sin(t*3)*.3;}if(o.glow)o.glow.position.y=gy(o.x,o.z)+2.6+Math.sin(t*2.5)*.25;
    if(o.pr){const d=Math.hypot(P.x-o.x,P.z-o.z);o.pr.m.opacity=.45+.4*(.5+.5*Math.sin(t*3))*(DEER.g&&Math.hypot(DEER.x-P.x,DEER.z-P.z)<9?1.4:1);}
    if(xFound(o.p.id))return;const d=Math.hypot(P.x-o.x,P.z-o.z);if(d<nd){nd=d;near=o;}
    if(o.k==='pile'){o.ps.forEach((q,i)=>{const w=i===o.right?(d<10?.14:.05):(d<10?.03:0);q.g.rotation.z=Math.sin(t*(i===o.right?13:9)+i)*w;});}
    if(o.k==='gold')o.ps[0].g.rotation.y=t*.8;
    if(o.k==='trail'){o.g.scale.y=1+Math.sin(t*5)*.04*(d<9?2:1);}});
  if(near&&nd<9&&t-(XM.jT||0)>2.6&&!P.lock&&!ovOpen()){XM.jT=t;if(near.k==='pile'||near.k==='gold')snd.bells(4);else{sfx.yip((near.p.pitch||1)*1.1);floatS('🐾',near.x,gy(near.x,near.z)+2.6,near.z,1.2);}}
  /* never stuck: after a while the reindeer sparkles a trail to the nearest pup */
  if(near&&!P.lock&&t-W.findT>75&&t-W.hintT>75){W.hintT=t;sparkTrail(near);}}
function sparkTrail(o){W.trail.forEach(s=>W.ag.remove(s));W.trail=[];const P=player,dx=o.x-P.x,dz=o.z-P.z,d=Math.hypot(dx,dz),n=Math.min(10,Math.floor((d-3)/2.5));
  for(let i=1;i<=n;i++){const x=P.x+dx*i/(n+1.2),z=P.z+dz*i/(n+1.2);W.trail.push(spr('✨',1.1,x,gy(x,z)+.6,z));}
  if(DEER.g)DEER.jump=.7;snd.twinkle();say(`${deer().name}'s antlers are twinkling like mad! Follow the sparkles, Seb!`);}

/* ----- the present picker ----- */
const SURP=[['🧦','A sock! Not a puppy.'],['🦆','A squeaky rubber duck!'],['❄️','Poof! Just a puff of snow!'],['jack','Boing! A jack-in-the-box!'],['🧸','A teddy bear! Cute, but not a puppy.'],['🍪','A gingerbread biscuit! Yum, but no puppy.'],['🧤','Some woolly mittens!'],['🪀','A yo-yo!']];
const JACK='<svg viewBox="0 0 80 90" width="80" height="90"><rect x="14" y="56" width="52" height="30" rx="4" fill="#5b8def" stroke="#26232e" stroke-width="3"/><path d="M40 56 l-10 -6 l20 -6 l-20 -6 l20 -6 l-10 -4" fill="none" stroke="#8a8f99" stroke-width="4"/><circle cx="40" cy="20" r="15" fill="#ffd9b0" stroke="#26232e" stroke-width="3"/><path d="M26 10 l-6 -8 M54 10 l6 -8 M40 6 v-6" stroke="#e8423a" stroke-width="4"/><circle cx="35" cy="18" r="2.2" fill="#26232e"/><circle cx="45" cy="18" r="2.2" fill="#26232e"/><path d="M34 25 q6 5 12 0" fill="none" stroke="#26232e" stroke-width="2.5"/><circle cx="40" cy="22" r="3" fill="#e8423a"/></svg>';
function presentSVG(c,big,num){const w=big?132:112;return `<svg viewBox="0 0 120 120" width="${w}" height="${w}"><g class="lid"><rect x="12" y="34" width="96" height="20" rx="4" fill="${c[0]}" stroke="#26232e" stroke-width="4"/><rect x="52" y="34" width="16" height="20" fill="${c[1]}"/>`+
  `<path d="M60 34 q-30 -28 -36 -6 q14 10 36 6 q30 -28 36 -6 q-14 10 -36 6" fill="${c[1]}" stroke="#26232e" stroke-width="3.5"/></g><rect x="18" y="52" width="84" height="62" rx="4" fill="${c[0]}" stroke="#26232e" stroke-width="4"/><rect x="52" y="52" width="16" height="62" fill="${c[1]}"/>`+
  (num!=null?`<circle cx="92" cy="98" r="15" fill="#fff" stroke="#26232e" stroke-width="3"/><text x="92" y="105" font-size="20" font-weight="900" text-anchor="middle" font-family="Arial" fill="#26232e">${num}</text>`:'')+`</svg>`;}
const CNAME={'#d9363e':'red','#2f9a54':'green','#2b4a8a':'blue','#ff7fb8':'pink','#8a5ad6':'purple','#f3ead8':'white','#ffb000':'orange','#ffd23f':'gold'};
let PK=null;
function pickUI(){if($('#xpick'))return;const d=el('div','ov','<div class="card" id="xpCard"><h2 id="xpH"></h2><div id="xpRow"></div><p id="xpMsg"></p><div class="btns"><button class="btn white" id="xpBack">Back</button></div></div>');d.id='xpick';document.body.appendChild(d);
  tap('#xpBack',()=>{sfx.boop();closePick();});}
function closePick(){$('#xpick').classList.remove('on');player.lock=false;PK=null;hush();}
function numClue(n){const R=Math.random(),a=1+Math.floor(Math.random()*(n-1));if(n%2===0&&R<.3)return `Double ${n/2}`;if(R<.6)return `${a} more than ${n-a}`;const b=1+Math.floor(Math.random()*4);return `${n+b} take away ${b}`;}
function openPile(o){if(player.lock||xFound(o.p.id))return;pickUI();player.lock=true;hush();snd.bells(8);PK=o;o.tries=0;o.opened={};
  const D=deer().name,row=$('#xpRow');row.innerHTML='';$('#xpMsg').textContent='';
  const order=o.ps.map((q,i)=>i);order.sort((a,b)=>hsh(o.p.id+a)%7-hsh(o.p.id+b)%7);
  order.forEach(i=>{const q=o.ps[i],b=el('button','xpr jing',presentSVG(q.c,q.s>.85,o.num?o.nums[i]:null));b.style.animationDelay=(i*.13)+'s';b.dataset.i=i;tap(b,()=>tapPresent(o,i,b));row.appendChild(b);});
  if(o.num){o.clue=numClue(o.nums[o.right]);$('#xpH').textContent=`🔢 Which present? ${o.clue}!`;speak(`${D} says: the puppy is in the present with the number that is ${o.clue.toLowerCase()}. Which present is it?`);}
  else{$('#xpH').textContent='🎁 Which present is jingling?';speak('Listen! One of the presents is jingling. Which one has a puppy inside?');}
  $('#xpick').classList.add('on');}
function tapPresent(o,i,b){if(o.opened[i]||PK!==o)return;o.opened[i]=1;b.classList.remove('jing','hint');b.classList.add('open');
  if(i===o.right){snd.bells(10);sfx.yip(o.p.pitch);b.innerHTML=`<div class="xpup">${critterSVG(xp(o.p),{anim:false})}</div>`;$('#xpMsg').textContent=`It's ${o.p.name}!`;
    setTimeout(()=>{closePick();markFound(o);found(o.p,'present',o);},1100);return;}
  o.tries++;const S=SURP[(hsh(o.p.id)+o.tries*3+i)%SURP.length];snd[S[0]==='jack'?'boing':'crunch']();sfx.oops();b.innerHTML=`<div class="xsur">${S[0]==='jack'?JACK:`<span>${S[0]}</span>`}</div>`;
  const q=o.ps[o.right],cn=CNAME[q.c[0]]||'shiny',sz=q.s>.85?'big':q.s<.75?'little':'middle-sized';let m=S[1];
  if(o.num)m+=` Remember: ${o.clue}.`;else if(o.tries===1)m+=` Listen... the jingling is coming from a ${sz} present.`;else m+=` Look! The ${cn} present is wobbling!`;
  if(o.tries>=2)$('#xpRow').querySelectorAll('.xpr').forEach(e=>{if(+e.dataset.i===o.right)e.classList.add('hint');});
  $('#xpMsg').textContent=m;speak(m);}
function openGold(o){if(player.lock||xFound(o.p.id))return;player.lock=true;snd.twinkle();o.ps[0].lid.position.y=1.4;o.ps[0].lid.rotation.z=1;
  confetti(20);setTimeout(()=>{player.lock=false;markFound(o);found(o.p,'gold',o);},700);}
/* tag pups: the first time, a giggle and a dash to a new spot, leaving fresh paw prints */
function searchMound(o){if(player.lock||xFound(o.p.id))return;player.lock=true;o.busy=true;hush();snd.crunch();o.g.scale.set(1.15,.8,1.15);
  setTimeout(()=>{o.g.scale.set(1,1,1);if(!o.tagged){runOff(o);return;}o.busy=false;player.lock=false;W.ag.remove(o.g);found(o.p,'prints',o);},800);}
function runOff(o){const p=o.p,S=o.S,g=pup3D(p,p.shiny),A=W.area;add(g,o.x,o.z);sfx.giggle();say(`Hee hee! ${p.name} giggles and dashes away through the snow! Follow the new paw prints!`);
  XS().tagged[p.id]=1;save();const path=(S.bc||[S.b,S.c]).slice();let seg=0,k=0;
  if(o.pr){W.ag.remove(o.pr.im);o.pr=null;}W.ag.remove(o.g);if(o.easy){W.ag.remove(o.easy);o.easy=null;}
  W.ticks.push(function run(dt){if(W.area!==A)return true;const a=path[seg],b=path[seg+1];if(!b){W.ag.remove(g);const n=trail(p,S,A);LIVE=LIVE.filter(q=>q!==o);LIVE.push(n);W.things=W.things.filter(t=>t!==o.th);flushTo(W.ag);player.lock=false;return true;}
    const d=Math.hypot(b[0]-a[0],b[1]-a[1])||.01;k+=dt*14/d;const e=Math.min(1,k),x=a[0]+(b[0]-a[0])*e,z=a[1]+(b[1]-a[1])*e;g.position.set(x,walkY(x,z)+Math.abs(Math.sin(W.t*16))*.35,z);g.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);animPup(g,W.t,true);
    if(e>=1){seg++;k=0;}});}

/* ================= finding a Christmas pup ================= */
function found(p,how,o){const X=XS();if(X.found[p.id])return;X.found[p.id]=Date.now();X.how[p.id]=how;state.stars+=10;W.findT=W.t;W.trail.forEach(t=>W.ag.remove(t));W.trail=[];save();hud();
  const P=player,dx=P.x-o.x,dz=P.z-o.z,d=Math.hypot(dx,dz)||1,g=pup3D(p,p.shiny);add(g,o.x+dx/d*1.9,o.z+dz/d*1.9);g.rotation.y=Math.atan2(-dx,-dz)+PI;g.userData.jump=.8;
  player.cheer=1.3;player.wave=2.4;sfx.jingle();confetti(36);const live=W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});
  const n=nFound(),T=TYPES[p.type]||TYPES.star,where={present:'in a jingling present',prints:'at the end of a trail of paw prints',gold:'in a golden present'}[how]||'';
  card({art:pupBox(xp(p)),h:`You found ${p.name}!`,h3:`🎄 Christmas Snow · ${p.breed} ${typeBadge(p.type)}`,p:FACT[p.id]||p.fact,
    say:`You found ${p.name}, hiding ${where}! ${FACT[p.id]||''}`,
    btns:[['🎁 Bring the present home!','green',()=>{W.ag.remove(g);flyPresent(o);setTimeout(()=>after(p,n),900);}]]});
  if(window.XSTORY&&XSTORY.onFind)try{XSTORY.onFind(p);}catch(e){}}
function flyPresent(o){if(!DEER.g)return;const A=W.area,sp=sprite('🎁',1.6);scene.add(sp);let k=0;const x0=o.x,z0=o.z;
  W.ticks.push(dt=>{k+=dt*1.3;const e=Math.min(1,k),x=x0+(DEER.x-x0)*e,z=z0+(DEER.z-z0)*e;sp.position.set(x,walkY(x,z)+2+Math.sin(e*PI)*4,z);if(e>=1||W.area!==A){scene.remove(sp);if(e>=1){snd.bells(5);sackSize();DEER.jump=.5;}return true;}});}
function after(p,n){const I=islandOf(p.island);
  if(I&&islN(I)>=NEED&&!XS().sp[I.id]){setTimeout(()=>sparkle(I),400);return;}
  if(window.XSTORY&&XSTORY.afterFind&&XSTORY.afterFind(p,n))return;
  if(n===all().length){say(`Every single present is home! All ${n} Christmas pups found! You are amazing, Seb!`);return;}
  const A=W.area,L=areaX(A.id),left=L.filter(q=>!xFound(q.id)).length;
  say(`${n} of ${all().length} presents are home! `+(left?`${left} more ${left>1?'pups':'pup'} hiding in ${A.name}.`:`Every Christmas pup in ${A.name} is found!`)+(I&&!XS().sp[I.id]?` Find ${NEED-islN(I)} more on ${I.name} for ${I.boss.uni.name}'s sparkle!`:''));}

/* ================= the nine star sparkles ================= */
const LESSON={blossom:'A present you make yourself holds a little bit of your heart.',flurry:'Snow is more fun when you share it.',pearl:'What you give comes back to you, like the tide.',
 emberuni:'A kind deed warms you up, like a cosy fire.',tally:'Friends are the best thing to count.',gizmouni:'The best present is your time, not a toy.',
 beaconuni:'Helping someone at Christmas is the brightest light of all.',amberuni:'The best things are worth waiting for, like Christmas.',nebulauni:'Even the smallest star can light the way.'};
function sparkle(I){const u=I.boss.uni,P=player,X=XS();player.lock=true;hush();
  const a=P.h+.7,x=P.x+Math.sin(a)*4.5,z=P.z+Math.cos(a)*4.5,g=pup3D(u,true);add(g,x,z);g.rotation.y=Math.atan2(P.x-x,P.z-z);g.userData.jump=.9;snd.twinkle();confetti(40);floatS('🌟',x,gy(x,z)+4,z,3);
  W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});const n=nSp()+1,D=deer().name;
  const lvl=n===3?`${D} feels brave enough to glide! The Sleigh Run on Snowy Summit is open.`:n===6?`${D} can fly little loops now!`:n===9?`All nine sparkles are home! ${D} can fly!`:`${D} feels a little bit braver.`;
  story([{art:`<div class="fitsvg">${critterSVG(xp(u))}</div>`,t:`${u.name} is here, holding a sparkle of the Christmas Star! "When the star went dark, its light split into nine sparkles, and one flew to me. You found ${NEED} Christmas pups on ${I.name}, so it is yours."`},
    {art:`<div class="fitsvg">${critterSVG(xp(u))}</div><div style="font-size:70px;line-height:1">🌟</div>`,t:`"Here is a Christmas lesson to keep: ${LESSON[u.id]||'Christmas is for sharing.'}"`},
    {art:`<div class="fitsvg" style="width:190px">${deerSVG()}</div><div style="font-size:60px;line-height:1">${'🌟'.repeat(Math.min(n,9))}</div>`,t:`The sparkle swirls round ${D}'s antlers. ${n} of 9 sparkles are home! ${lvl}`}],
    ()=>{X.sp[I.id]=Date.now();save();W.ag.remove(g);player.lock=false;DEER.jump=1;sfx.fanfare();confetti(50);hud();
      if(window.XSTORY&&XSTORY.onSparkle)try{XSTORY.onSparkle(I,n);}catch(e){}
      if(n<9)say(`${n} of 9 sparkles home! Find ${NEED} Christmas pups on each island to bring back every sparkle.`);});}
/* the unicorns wait in their island's last area once their sparkle is home */
function uniHome(IS){const B=IS.boss;if(!B||!B.uni||!XS().sp[IS.id])return;if(W.bossUp===IS.id)return;W.bossUp=IS.id;const u=pup3D(B.uni,true);u.rotation.y=Math.atan2(-B.x,-B.z)+PI;add(u,B.x,B.z);col(B.x,B.z,1.4);
  W.ticks.push(()=>{animPup(u,W.t,false);});W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(`${B.uni.name} says: "${LESSON[B.uni.id]} Happy Christmas, Seb!"`);}});}

/* ================= Seb's reindeer ================= */
const DEER={g:null,x:0,z:0,y:0,h:0,jump:0,lights:[],sack:null,legs:[],head:null,moving:false,lift:0,loopT:0};
function deer3D(){const g=grp(),b=grp();g.add(b);const C='#9a5a2e',CR='#f3e2c0',DK='#3a2a25',AN={};
  mk('sph',C,.55,.5,.85,0,1.45,0,b);mk('sph',CR,.42,.36,.55,0,1.25,.1,b);mk('sph',CR,.36,.4,.3,0,1.62,.62,b);
  const nk=grp();nk.position.set(0,1.8,.62);b.add(nk);mk('cyl',C,.2,.62,.2,0,.25,.1,nk).rotation.x=.45;
  const h=grp();h.position.set(0,.62,.32);nk.add(h);mk('sph',C,.36,.34,.4,0,0,0,h);mk('sph','#e8d8c0',.22,.2,.28,0,-.1,.32,h);mk('sph',DK,.09,.07,.06,0,-.02,.58,h);
  [-1,1].forEach(s=>{mk('sph','#2a1e1a',.1,.12,.06,s*.17,.08,.3,h);mk('sph','#ffffff',.035,.035,.02,s*.15,.13,.355,h,true);
    const e=mk('sph',C,.09,.2,.06,s*.34,.16,-.06,h);e.rotation.z=-s*1.1;mk('sph','#e8b8a8',.05,.13,.03,s*.35,.16,-.03,h).rotation.z=-s*1.1;
    const an=grp();an.position.set(s*.16,.3,-.05);h.add(an);mk('cyl','#c9a070',.04,.42,.04,0,.2,0,an).rotation.z=-s*.25;mk('cyl','#c9a070',.035,.2,.035,s*.12,.3,0,an).rotation.z=-s*1.1;mk('cyl','#c9a070',.03,.16,.03,s*.05,.4,.06,an).rotation.x=-.6;
    AN[s]=an;});
  mk('tor','#d9363e',.25,.25,.5,0,-.02,.15,nk).rotation.x=PI/2-.4;mk('box','#d9363e',.14,.36,.06,.16,-.22,.3,nk).rotation.z=.2;
  const legs=[];[[-.28,.5],[.28,.5],[-.28,-.5],[.28,-.5]].forEach(q=>{const l=grp();l.position.set(q[0],1.2,q[1]);b.add(l);mk('cyl',C,.12,.7,.12,0,-.35,0,l);mk('cyl','#e8d8c0',.1,.28,.1,0,-.86,0,l);mk('cyl',DK,.12,.12,.13,0,-1.06,.02,l);legs.push(l);});
  mk('sph','#ffffff',.14,.16,.12,0,1.62,-.85,b);
  bakeModel(g,'xdeer');
  /* parts that change: antler lights, the bell and the present sack */
  /* the frost lights: one points cloud in the head, so they cost a single draw */
  const LP=[];[-1,1].forEach(s=>{const o=AN[s].position;[[0,.42,0],[s*.2,.38,0],[s*.04,.5,.1],[s*.1,.22,0]].forEach(q=>LP.push(o.x+q[0]-s*.05*(q[1]>.3?1:0),o.y+q[1]+.02,o.z+q[2]));});
  const lg=new THREE.BufferGeometry();lg.setAttribute('position',new THREE.BufferAttribute(new Float32Array(LP),3));const lm=new THREE.PointsMaterial({color:'#bfefff',size:.16,map:flakeTex(),transparent:true,depthWrite:false});
  const lights=new THREE.Points(lg,lm);h.add(lights);
  const bl=new THREE.Mesh(G.sph,M('#d8dde6'));bl.scale.setScalar(.11);bl.position.set(0,-.2,.42);nk.add(bl);
  const sk=grp();sk.position.set(0,1.95,-.35);b.add(sk);mk('sph','#a8743a',.42,.42,.42,0,.3,0,sk);mk('cyl','#d9363e',.1,.12,.1,0,.68,0,sk);
  Object.assign(g.userData,{legs,body:b,head:h,neck:nk,lights,sack:sk});g.traverse(o=>{o.frustumCulled=false;});return g;}
function useDeer(g){DEER.g=g;DEER.lights=g.userData.lights;DEER.sack=g.userData.sack;if(!g.parent)scene.add(g);}
function sackSize(){if(DEER.sack)DEER.sack.scale.setScalar(.35+.75*nFound()/all().length);}
let bubble=null;
function deerEnter(A){if(!named()){if(DEER.g)DEER.g.visible=false;return;}
  if(!DEER.g)useDeer(deer3D());DEER.g.visible=true;sackSize();
  const P=player,a=P.h+PI/2;DEER.x=P.x+Math.sin(a)*2.6;DEER.z=P.z+Math.cos(a)*2.6;DEER.h=P.h;
  if(!bubble){bubble=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#bfe8ff',transparent:true,opacity:.3,depthWrite:false}));bubble.scale.setScalar(.75);bubble.position.set(0,.05,.05);DEER.g.userData.head.add(bubble);}
  bubble.visible=!!A.swim;
  W.things.push({x:DEER.x,z:DEER.z,r:3.2,icon:'💬',label:deer().name,xdeer:1,show:()=>!followers.some(f=>Math.hypot(f.x-player.x,f.z-player.z)<2.3),act:deerTalk});
  W.ticks.push(deerTick);}
/* hide the reindeer when the season is switched off */
function deerHide(){if(DEER.g)DEER.g.visible=false;}
function nearest(){let best=null,bd=1e9;LIVE.forEach(o=>{if(xFound(o.p.id))return;const d=Math.hypot(player.x-o.x,player.z-o.z);if(d<bd){bd=d;best=o;}});return best?{o:best,d:bd}:null;}
function deerTick(dt){if(!DEER.g||!on())return true;if(!DEER.g.visible||DEER.script)return;const P=player,t=W.t,u=DEER.g.userData,lv=nSp();
  const fx=Math.sin(P.h),fz=Math.cos(P.h),tx=P.x+fz*2.6-fx*1.0,tz=P.z-fx*2.6-fz*1.0,dx=tx-DEER.x,dz=tz-DEER.z,d=Math.hypot(dx,dz);
  DEER.moving=d>.35;if(d>.05){DEER.x+=dx*Math.min(1,dt*3);DEER.z+=dz*Math.min(1,dt*3);}if(d>26){DEER.x=tx;DEER.z=tz;}
  DEER.h=lerpAng(DEER.h,DEER.moving?Math.atan2(dx,dz):P.h,Math.min(1,dt*5));
  /* braver with every sparkle: hops, then glides, then little loops */
  let lift=0;if(lv>=3)lift=DEER.moving?.7+Math.sin(t*2)*.15:.2;if(lv>=6){DEER.loopT+=dt;if(DEER.loopT>18&&!P.lock&&!DEER.moving)DEER.loopT=-3;}
  if(DEER.loopT<0){const k=(DEER.loopT+3)/3;lift+=Math.sin(k*PI)*4.5;DEER.h+=dt*PI*2/3;}
  if(W.area&&W.area.swim)lift+=.3;DEER.lift+=(lift-DEER.lift)*Math.min(1,dt*3);
  if(DEER.jump>0)DEER.jump-=dt;const hop=DEER.jump>0?Math.sin(DEER.jump*PI*1.6)*.9:0;
  DEER.y=walkY(DEER.x,DEER.z)+DEER.lift+Math.max(0,hop)+(lv<3&&DEER.moving?Math.abs(Math.sin(t*8))*.12:0);
  DEER.g.position.set(DEER.x,DEER.y,DEER.z);DEER.g.rotation.y=DEER.h;
  const sw=DEER.moving?Math.sin(t*10)*(DEER.lift>.4?.15:.55):0;u.legs.forEach((l,i)=>{l.rotation.x=(i===0||i===3?sw:-sw)+(DEER.lift>.4?.5:0);});u.neck.rotation.x=Math.sin(t*2)*.05+(DEER.moving?.1:0);u.head.rotation.z=Math.sin(t*1.3)*.08;
  const th=W.things.find(q=>q.xdeer);if(th){th.x=DEER.x;th.z=DEER.z;}
  /* warmer and colder: the frost lights twinkle faster near a hiding pup */
  const n=nearest(),k=n?Math.max(0,Math.min(1,1-n.d/45)):0,pl=.5+.5*Math.sin(t*(2+12*k)),L=DEER.lights;if(L){L.material.color.setHSL(.53-.05*k,.6+.4*k,.55+.4*pl*(.4+.6*k));L.material.size=.14*(1+.9*k*pl);}
  if(n&&n.d<10&&t-(DEER.dingT||0)>3.2&&!P.lock&&!ovOpen()){DEER.dingT=t;snd.bells(3);}
  if(t-(DEER.factT||0)>140&&!P.lock&&!ovOpen()&&t-W.msgT>20){DEER.factT=t;say(`${deer().name} says: "${pick(DFACT)}"`);}}
const DFACT=['Did you know? Reindeer eyes change colour, golden in summer and deep blue in winter, to see better in the long dark.',
 'Did you know? Reindeer are the only deer where the girls grow antlers too!','Did you know? In winter, a reindeer\'s hooves grip the ice like ice skates.',
 'Did you know? A reindeer\'s nose warms up the freezing air before it breathes it in.','Did you know? Reindeer can smell lichen, their favourite food, under deep snow.'];
function dir(o){const P=player,a=Math.atan2(o.x-P.x,o.z-P.z),r=angDiff(a,W.camYaw),d=Math.hypot(o.x-P.x,o.z-P.z);
  const w=Math.abs(r)<.6?'straight ahead':Math.abs(r)>2.4?'behind you':r>0?'over to your left':'over to your right';return `${w}, ${d<12?'really close':d<30?'not far away':'a long way off'}`;}
function deerTalk(){if(player.lock)return;sfx.chime();DEER.jump=.6;const D=deer().name,n=nearest(),A=W.area;
  if(n){const o=n.o,w=dir(o);say(o.k==='pile'?`${D} says: "I can hear jingling ${w}!"`:o.k==='gold'?`${D} says: "Something golden is sparkling ${w}!"`:`${D} says: "Fresh paw prints! They go ${w}. Let's follow them!"`);return;}
  const I=A.island&&islandOf(A.island),more=I?I.areas.filter(a=>areaX(a.id).some(p=>!xFound(p.id))):[];
  if(more.length)say(`${D} says: "Every pup here is home! I think I can hear jingling in ${more[0].name}."`);
  else if(I)say(`${D} says: "Every Christmas pup on ${I.name} is home! Let's try another island."`);
  else{const left=ISLANDS.find(I2=>islX(I2).some(p=>!xFound(p.id)));say(left?`${D} says: "Let's look for Christmas pups on ${left.name}!"`:`${D} says: "Happy Christmas, Seb!"`);}}
/* a picture of the reindeer, for cards and story scenes */
function deerSVG(o){o=o||{};const K=INK,S=`stroke="${K}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"`,C='#9a5a2e',CR='#f3e2c0';
  const ant=g=>{const x=100+g*20,y=50;return `<path d="M${x} ${y} q${g*-4} -18 ${g*6} -36 M${x+g*2} ${y-16} l${g*16} -10 M${x+g*4} ${y-28} l${g*-12} -10" fill="none" stroke="${K}" stroke-width="9" stroke-linecap="round"/><path d="M${x} ${y} q${g*-4} -18 ${g*6} -36 M${x+g*2} ${y-16} l${g*16} -10 M${x+g*4} ${y-28} l${g*-12} -10" fill="none" stroke="#c9a070" stroke-width="5" stroke-linecap="round"/>`+
    [[x+g*6,y-36],[x+g*18,y-26],[x+g*-8,y-38],[x+g*2,y-14]].map((q,i)=>`<circle class="twk" style="animation-delay:${i*.3}s" cx="${q[0]}" cy="${q[1]}" r="4.5" fill="#d8f6ff" stroke="#7fd0ff" stroke-width="1.5"/>`).join('');};
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg"><ellipse cx="100" cy="192" rx="62" ry="7" fill="#000" opacity=".12"/>`+
   [70,86,116,132].map((x,i)=>`<rect x="${x-6}" y="${140}" width="13" height="46" rx="6" fill="${i%3?C:'#8a4e26'}" ${S}/><rect x="${x-7}" y="178" width="15" height="10" rx="3" fill="#3a2a25"/>`).join('')+
   `<ellipse cx="100" cy="132" rx="52" ry="34" fill="${C}" ${S}/><ellipse cx="100" cy="146" rx="32" ry="18" fill="${CR}"/><circle cx="152" cy="122" r="9" fill="#fff" ${S}/>`+
   (o.sack?`<ellipse cx="78" cy="98" rx="24" ry="22" fill="#a8743a" ${S}/><path d="M72 78 q6 -8 12 0" fill="none" stroke="#d9363e" stroke-width="6"/>`:'')+
   ant(-1)+ant(1)+`<ellipse cx="62" cy="66" rx="16" ry="9" transform="rotate(-30 62 66)" fill="${C}" ${S}/><ellipse cx="138" cy="66" rx="16" ry="9" transform="rotate(30 138 66)" fill="${C}" ${S}/>`+
   `<ellipse cx="100" cy="78" rx="34" ry="32" fill="${C}" ${S}/><ellipse cx="100" cy="96" rx="20" ry="15" fill="#e8d8c0" ${S}/><ellipse cx="100" cy="88" rx="7" ry="5" fill="#3a2a25"/>`+
   `<circle cx="86" cy="72" r="8" fill="#2a1e1a"/><circle cx="114" cy="72" r="8" fill="#2a1e1a"/><circle cx="83" cy="69" r="3" fill="#fff"/><circle cx="111" cy="69" r="3" fill="#fff"/><path d="M93 102 q7 6 14 0" fill="none" stroke="${K}" stroke-width="3"/>`+
   `<path d="M68 106 Q100 124 132 106" fill="none" stroke="${K}" stroke-width="16" stroke-linecap="round"/><path d="M68 106 Q100 124 132 106" fill="none" stroke="#d9363e" stroke-width="11" stroke-linecap="round"/><rect x="118" y="110" width="13" height="30" rx="4" fill="#d9363e" ${S} transform="rotate(-14 124 112)"/>`+
   `<circle cx="100" cy="122" r="9" fill="#d8dde6" ${S}/><circle cx="100" cy="125" r="2.5" fill="${K}"/></svg>`;}

/* ================= the opening ================= */
const SUG=['Twig','Nutmeg','Toffee','Cinnamon','Maple','Merry'];
const cleanName=s=>{s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,18);return s?s.charAt(0).toUpperCase()+s.slice(1):'';};
const tree='<div style="font-size:110px;line-height:1">🎄</div>',mg=()=>`<div class="fitsvg" style="width:150px">${magpieSVG()}</div>`;
function starSVG(dark){return `<svg viewBox="0 0 220 200" width="240"><rect width="220" height="200" rx="18" fill="${dark?'#141a3c':'#bfe6ff'}"/><path d="M110 30 L60 150 H160 Z" fill="${dark?'#1f4a34':'#2f9a54'}" stroke="#26232e" stroke-width="4"/><path d="M110 66 L70 170 H150 Z" fill="${dark?'#1f4a34':'#2f9a54'}" stroke="#26232e" stroke-width="4"/><rect x="100" y="170" width="20" height="18" fill="#8a5a32"/>`+
  (dark?'':[[90,100,'#ff4f6d'],[126,118,'#ffd23f'],[100,140,'#5cb8ff'],[132,150,'#ff9ecb'],[84,156,'#ffd23f']].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="6" fill="${q[2]}"/>`).join('')+`<path d="M110 8 l7 15 l16 2 l-12 11 l3 16 l-14 -8 l-14 8 l3 -16 l-12 -11 l16 -2 Z" fill="#ffd23f" stroke="#26232e" stroke-width="3"/>`)+`</svg>`;}
function intro(){const X=XS();X.inv=1;player.lock=true;hush();
  story([{art:'<div style="font-size:110px;line-height:1">❄️🏡❄️</div>',t:'Snow is falling on Pawprint Village! Everyone is getting ready for Christmas.'},
    {art:`<div class="fitsvg" style="width:150px">${grannySVG()}</div>${tree}`,t:'"The pups have wrapped a present for every friend on the islands," says Granny Paws. "And look at the Christmas Star on the big tree! It shines so the North Pole reindeer can find their way with the presents."'},
    {art:mg()+'<div style="font-size:90px;line-height:1">🧣🎁</div>',t:'Muddle the Magpie flutters by in his woolly scarf. "Seb is my best friend," he says. "I am going to find him the best present ever!"'},
    {art:starSVG(true)+mg(),t:'That night, Muddle flies to the top of the tree and pulls off the star. "The shiniest present in the whole world, for Seb!" Every light in the village goes out.'}],
    ()=>{state.season='xmas';save();rebuildPack();fadeTo(()=>{enterArea('village',[2,22,PI]);crash();},['❄️','Christmas Snow']);});}
function crash(){const P=player,A=W.area,x=8.5,z=19;player.lock=true;W.camYaw=Math.atan2(x-P.x,z-P.z);P.h=W.camYaw;
  const dr=mound(A);dr.scale.set(1.4,1.4,1.4);add(dr,x,z);flushTo(W.ag);snd.bells(14);
  const sp=sprite('✨',2.5);scene.add(sp);let t=0,bang=false;
  W.ticks.push(dt=>{t+=dt;if(t<2.2){const k=t/2.2;sp.position.set(x-40+k*40,gy(x,z)+22-k*22+Math.sin(k*20)*1.2,z-20+k*20);return;}
    if(!bang){bang=true;scene.remove(sp);snd.whump();confetti(10);for(let i=0;i<10;i++)floatS(pick(['❄️','💨','❄️']),x+(Math.random()-.5)*4,gy(x,z)+1+Math.random()*2,z+(Math.random()-.5)*4,1.8,1.4);}
    if(t<2.9){cam.position.x+=(Math.random()-.5)*.6;cam.position.y+=(Math.random()-.5)*.6;return;}
    if(t>3.6){meet(x,z);return true;}});}
function meet(x,z){const D=deer3D();useDeer(D);D.visible=true;DEER.x=x;DEER.z=z+1.6;DEER.h=Math.atan2(player.x-x,player.z-z);DEER.g.position.set(DEER.x,walkY(x,z),DEER.z);D.rotation.y=DEER.h;DEER.jump=1;snd.bells(6);
  story([{art:`<div class="fitsvg" style="width:200px">${deerSVG()}</div>`,t:'A pair of small antlers pokes out of the snowdrift, tangled in tinsel. It\'s a young reindeer, a bit dizzy and very nervous!'},
    {art:`<div class="fitsvg" style="width:200px">${deerSVG()}</div>`,t:'"I\'m from the North Pole reindeer school, on my very first practice flight," it says. "I was following the Christmas Star to bring the presents, but the star went dark, and I crashed!"'}],()=>nameCard(()=>scatter()));}
function nameCard(done){sfx.chime();
  card({art:`<div class="fitsvg" style="width:170px">${deerSVG()}</div>`,h:'Name your reindeer!',p:`The young reindeer doesn't have a name yet. What would you like to call it?<input id="xName" maxlength="18" autocomplete="off" placeholder="Type a name..."><span class="xSug">${SUG.map(s=>`<button class="opt">${s}</button>`).join('')}</span><span class="xSex"><button class="opt on" data-g="1">👧 Girl</button><button class="opt" data-g="0">👦 Boy</button></span>`,
    say:'The young reindeer does not have a name yet. Type a name, or pick one. Is your reindeer a girl or a boy?',
    btns:[['✓ That\'s the name!','green',()=>{const n=cleanName($('#xName').value)||pick(SUG),g=!!+(document.querySelector('#celeCard .xSex .on')||{dataset:{g:1}}).dataset.g;
      XS().deer={name:n,girl:g,at:Date.now()};save();sfx.fanfare();confetti(50);player.cheer=1.6;if(done)done();}]]});
  const inp=$('#xName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .xSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));
  document.querySelectorAll('#celeCard .xSex .opt').forEach(b=>tap(b,()=>{document.querySelectorAll('#celeCard .xSex .opt').forEach(q=>q.classList.toggle('on',q===b));sfx.boop();}));}
function scatter(){const D=deer().name;
  story([{art:`<div class="fitsvg" style="width:180px">${deerSVG({sack:true})}</div><div style="font-size:70px;line-height:1">🎁💨</div>`,t:`"Hello Seb! I'm ${D}!" But oh no: ${D}'s sack has burst! The presents blew away over all nine islands, and the pups chased after them. Now they are hiding with the presents in the snow!`},
    {art:`<div class="fitsvg" style="width:180px">${deerSVG()}</div>`,t:`"My first big job, and I've lost every present!" sniffs ${D}. Seb promises to help. ${D}'s antlers twinkle when a hidden pup is near, so ${he()} can help too!`},
    {art:'<div style="font-size:90px;line-height:1">🎁🔔🐾</div>',t:'Some pups hide in a pile of jingling presents: listen for the jingle, and pick the right present. Others leave paw prints in the fresh snow: follow them! Find 6 pups on an island, and its unicorn will bring back a sparkle of the Christmas Star.'}],
    ()=>{const X=XS();X.intro=Date.now();save();player.lock=false;deerEnter(W.area);hud();say(`Let's find the Christmas pups! Take the ferry to Meadow Island, or any island you like. ${D} will come too!`);
      if(window.XSTORY&&XSTORY.onIntro)try{XSTORY.onIntro();}catch(e){}});}
/* the invitation, once Christmas Snow is open */
function villageNews(){if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village')return;if(window.XSTORY&&XSTORY.village&&XSTORY.village())return;}
const _ea3=enterArea;enterArea=function(id,pos,msg){_ea3.apply(this,arguments);if(state.season||id!=='village'||!opened()||!state.intro)return;const X=XS();if(X.inv||named())return;
  setTimeout(()=>{if(cur!=='world'||ovOpen()||!W.area||W.area.id!=='village')return;X.inv=1;save();invite();},1500);};
function invite(){player.lock=true;sfx.chime();
  card({art:`${mg()}<div style="font-size:90px;line-height:1">❄️🎄</div>`,h:'❄️ Christmas Snow is here!',p:'Snow is drifting down on Pawprint Village, and a giant Christmas tree has appeared in the plaza. Shall we go and see?',
    btns:[['❄️ Yes, let\'s go!','green',()=>{player.lock=false;intro();}],['Not now','white',()=>{player.lock=false;say('Shake the Snow Globe in the plaza whenever you want to play Christmas Snow!');}]]});}
function fromConga(){if(named()){setSeason('xmas');return;}intro();}

/* ================= switching seasons ================= */
function rebuildPack(){followers.forEach(f=>scene.remove(f.grp));followers.length=0;}
function setSeason(k){const was=state.season||null;if(was===(k||null))return;state.season=k||null;save();rebuildPack();
  Object.values(window.SEASONS).forEach(S=>{if(S.id!==k&&S.hide)try{S.hide();}catch(e){}});
  const S=k&&window.SEASONS[k],w=state.where&&AREAS[state.where]?state.where:'village';fadeTo(()=>enterArea(w,[player.x,player.z,player.h]),S?[S.icon,S.name]:['🏝️','The islands']);}
/* the Season Globe in the plaza: pick the islands as they are, or any season that is open */
const LATER=[['🎃','Halloween'],['🏖️','Summer Beach Party'],['🌷','Spring Blossom']];
function globe(){if(player.lock)return;sfx.chime();snd.bells(6);
  const L=Object.values(window.SEASONS).sort((a,b)=>a.order-b.order),op=L.filter(S=>S.opened()),cur=state.season&&window.SEASONS[state.season];
  if(!op.length){card({art:'<div style="font-size:110px;line-height:1">🔮</div>',h:'The Season Globe',p:'Something is swirling inside the globe... Finish the Great Pup Conga World Tour, and it will be ready to shake!',btns:[['OK','green']]});return;}
  if(!cur&&op.length===1&&!op[0].named()){op[0].invite();return;}
  const btns=[];op.forEach(S=>{if(cur&&S.id===cur.id)return;btns.push([`${S.icon} ${S.name}`,btns.length?'blue':'green',()=>{if(!S.named()){S.invite();return;}setSeason(S.id);}]);});
  if(cur)btns.push(['🏝️ The islands as they are',btns.length?'blue':'green',()=>setSeason(null)]);btns.push(['Not now','white']);
  const locked=L.filter(S=>!S.opened()).map(S=>[S.icon,S.name,S.lockShort||'Coming soon']).concat(LATER.filter(q=>!L.some(S=>S.name===q[1])).map(q=>[q[0],q[1],'Coming soon']));
  card({art:'<div style="font-size:110px;line-height:1">🔮</div>',h:'🔮 Shake the Season Globe!',p:`Pick a season. Your pups and everything you have found always stay safe.${cur?` You are playing ${cur.name} now.`:''}<span class="xSeas">${locked.map(q=>`<span class="xsz">${q[0]}<small>${q[1]}</small><small>${q[2]}</small></span>`).join('')}</span>`,btns});}
function calendar(){if(player.lock)return;sfx.chime();const X=XS(),n=nFound();
  const rows=ISLANDS.map(I=>`<div class="xcRow"><b>${I.icon}</b>${islX(I).map(p=>`<i class="${xFound(p.id)?'lit':''}"></i>`).join('')}<em>${X.sp&&X.sp[I.id]?'🌟':''}</em></div>`).join('')+
    `<div class="xcRow"><b>⭐</b>${[XP.holly,XP.tinsel].map(p=>`<i class="${xFound(p.id)?'lit':''}"></i>`).join('')}<em></em></div>`;
  card({cls:'xcal',h:`🏠 The Season Calendar: ${n} of ${all().length}`,p:`A window lights up for every Christmas pup you find. 🌟 means that island's sparkle is home.<div class="xcGrid">${rows}</div>`,
    say:`${n} of ${all().length} Christmas pups found, and ${nSp()} of 9 sparkles home.`,btns:[['OK','green']]});}

/* the grown-ups switch */
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=$('#setCard');if(!c)return;const S=state.set;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`❄️ Open Christmas Snow early<div class="opts"><button class="opt${S.xmasOpen?'':' on'}" data-x="0">Off</button><button class="opt${S.xmasOpen?' on':''}" data-x="1">On</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=congaDone()?'Christmas Snow is already open, because the World Tour is finished. Shake the Snow Globe in the village plaza to switch it on or off.':'Christmas Snow opens after the Great Pup Conga World Tour. Turn this on to open it now: an invitation arrives the next time Seb is in the village.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt').forEach(b=>tap(b,()=>{S.xmasOpen=b.dataset.x==='1';if(!S.xmasOpen&&!congaDone()&&state.season==='xmas'){state.season=null;rebuildPack();deerHide();openSettings.dirty='season';}save();sfx.boop();const d=openSettings.dirty;openSettings();if(d)openSettings.dirty=d;}));};}

/* ================= planning hiding spots (used offline to make xmas_spots.js, and as a fallback) ================= */
function grid(A,c){const B=areaBox(A),x0=B.x1,z0=B.z1,nx=Math.ceil((B.x2-B.x1)/c)+1,nz=Math.ceil((B.z2-B.z1)/c)+1,N=nx*nz,free=new Uint8Array(N);
  for(let j=0;j<nz;j++)for(let i=0;i<nx;i++){const x=x0+i*c,z=z0+j*c;if(!A.rect&&Math.hypot(x,z)>A.R-2)continue;const r=resolve(x,z);if(Math.abs(r[0]-x)+Math.abs(r[1]-z)<.02&&(!A.keepOut||A.id==='village'||!A.keepOut(x,z)))free[j*nx+i]=1;}
  let cl=free.slice();const clr=new Uint8Array(N);for(let k=0;k<N;k++)clr[k]=free[k];
  for(let r=1;r<=3;r++){const nx2=new Uint8Array(N);for(let j=1;j<nz-1;j++)for(let i=1;i<nx-1;i++){const k=j*nx+i;if(cl[k]&&cl[k-1]&&cl[k+1]&&cl[k-nx]&&cl[k+nx]&&cl[k-nx-1]&&cl[k-nx+1]&&cl[k+nx-1]&&cl[k+nx+1])nx2[k]=1;}cl=nx2;for(let k=0;k<N;k++)if(cl[k])clr[k]=r+1;}
  const at=(x,z)=>{const i=Math.round((x-x0)/c),j=Math.round((z-z0)/c);return i<0||j<0||i>=nx||j>=nz?-1:j*nx+i;},xz=k=>[x0+(k%nx)*c,z0+Math.floor(k/nx)*c];
  const snap=(x,z,mc)=>{let best=-1,bd=1e9;for(let k=0;k<N;k++){if(clr[k]<(mc||1))continue;const p=xz(k),d=Math.hypot(p[0]-x,p[1]-z);if(d<bd){bd=d;best=k;}}return best;};
  function bfs(s){const D=new Float32Array(N).fill(1e9),par=new Int32Array(N).fill(-1),Q=[s];D[s]=0;const nb=[[1,0,1],[-1,0,1],[0,1,1],[0,-1,1],[1,1,1.414],[1,-1,1.414],[-1,1,1.414],[-1,-1,1.414]];
    for(let h=0;h<Q.length;h++){const k=Q[h],i=k%nx,j=(k/nx)|0;for(const q of nb){const i2=i+q[0],j2=j+q[1];if(i2<0||j2<0||i2>=nx||j2>=nz)continue;const k2=j2*nx+i2;if(!free[k2])continue;if(q[2]>1&&(!free[j*nx+i2]||!free[j2*nx+i]))continue;const nd=D[k]+q[2]*c;if(nd<D[k2]){D[k2]=nd;par[k2]=k;Q.push(k2);}}}return {D,par};}
  function path(B2,k){const out=[];while(k>=0){out.push(xz(k));k=B2.par[k];}out.reverse();const s=[out[0]];for(let i=3;i<out.length-1;i+=3)s.push(out[i]);s.push(out[out.length-1]);return s.map(p=>[+p[0].toFixed(1),+p[1].toFixed(1)]);}
  return {N,free,clr,at,xz,snap,bfs,path,c};}
function plan(A){const out={spots:{}};const L=areaX(A.id);if(!L.length)return out;const Gd=grid(A,1),R=seed(hsh(A.id)+11),chosen=[];
  const avoid=[];(W.exits||[]).forEach(e=>avoid.push([e.x,e.z,9]));W.things.forEach(t=>{if(!t.xdeer)avoid.push([t.x,t.z,4.5]);});if(A.start)avoid.push([A.start[0],A.start[1],9]);
  L.forEach(p=>{if(p.spot)avoid.push([p.spot.x,p.spot.z,5]);if(p.tag)avoid.push([p.tag.x,p.tag.z,5]);});
  const okAt=(p,mc,sep)=>{if(avoid.some(a=>Math.hypot(p[0]-a[0],p[1]-a[1])<a[2]))return false;if(chosen.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<sep))return false;return true;};
  const st=A.start?Gd.snap(A.start[0],A.start[1],1):Gd.snap(0,0,1);if(st<0)return out;const B0=Gd.bfs(st);
  const best=(B,mc,sep,lo,hi,ideal)=>{let bk=-1,bs=-1e9;for(let k=0;k<Gd.N;k++){if(Gd.clr[k]<mc||B.D[k]>=1e9||B0.D[k]>=1e9)continue;const d=B.D[k];if(d<lo||d>hi)continue;const p=Gd.xz(k);if(!okAt(p,mc,sep))continue;
      const sp=chosen.length?Math.min(30,Math.min(...chosen.map(q=>Math.hypot(p[0]-q[0],p[1]-q[1])))):30,s=sp*.6-Math.abs(d-ideal)*.25+R()*6;if(s>bs){bs=s;bk=k;}}return bk;};
  L.forEach(p=>{const k=kindOf(p);
    if(k==='trail'){let a=p.spot?Gd.snap(p.spot.x,p.spot.z,1):-1;if(a<0||B0.D[a]>=1e9)a=st;const Ba=Gd.bfs(a),b=best(Ba,2,10,15,40,26);if(b<0)return;chosen.push(Gd.xz(b));
      const Bb=Gd.bfs(b);let c2=-1,bs=-1e9;const pa=Gd.xz(a);for(let q=0;q<Gd.N;q++){if(Gd.clr[q]<2||Bb.D[q]>=1e9)continue;const d=Bb.D[q];if(d<14||d>34)continue;const pq=Gd.xz(q);if(Math.hypot(pq[0]-pa[0],pq[1]-pa[1])<10||!okAt(pq,2,10))continue;const s=-Math.abs(d-22)*.3+R()*6;if(s>bs){bs=s;c2=q;}}
      if(c2<0)return;chosen.push(Gd.xz(c2));const P2=k2=>Gd.xz(k2).map(v=>+v.toFixed(1));
      out.spots[p.id]={k:'trail',a:P2(a),b:P2(b),c:P2(c2),ab:Gd.path(Ba,b),bc:Gd.path(Bb,c2)};}
    else{const kk=best(B0,k==='pile'?3:2,12,12,140,40);if(kk<0)return;const q=Gd.xz(kk);chosen.push(q);out.spots[p.id]={k,x:+q[0].toFixed(1),z:+q[1].toFixed(1)};}});
  return out;}

/* ================= look and API ================= */
const css=document.createElement('style');css.textContent=`
#xpick{z-index:60}#xpCard{max-width:960px;width:94%}#xpRow{display:flex;flex-wrap:wrap;justify-content:center;gap:14px;margin:12px 0}
#xpRow .xpr{background:none;border:0;padding:0;width:136px;height:150px;display:flex;align-items:flex-end;justify-content:center;cursor:pointer;transform-origin:50% 90%}
#xpRow .xpr.jing{animation:xjing 1.6s ease-in-out infinite}#xpRow .xpr.hint{animation:xhint .5s ease-in-out infinite}
#xpRow .xpr .xsur{font-size:80px;line-height:1;animation:xpop .5s}#xpRow .xpr .xpup{width:130px;animation:xpop .6s}#xpRow .xpr .xpup svg{width:100%;height:auto}
#xpMsg{min-height:34px;font-size:26px;font-weight:800}
@keyframes xjing{0%,70%,100%{transform:rotate(0)}75%{transform:rotate(-6deg)}80%{transform:rotate(6deg)}85%{transform:rotate(-4deg)}90%{transform:rotate(3deg)}}
@keyframes xhint{0%,100%{transform:rotate(-9deg) scale(1.06)}50%{transform:rotate(9deg) scale(1.06)}}@keyframes xpop{0%{transform:scale(.2) translateY(40px)}70%{transform:scale(1.15)}100%{transform:scale(1)}}
#xName{display:block;width:420px;margin:12px auto 8px;font-size:30px;font-weight:900;padding:10px 16px;border:4px solid #26232e;border-radius:18px;text-align:center;font-family:inherit;color:#26232e}
#celeCard .xSug,#celeCard .xSex{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:6px}#celeCard .xSug .opt,#celeCard .xSex .opt{font-size:20px}#celeCard .xSex .opt.on{background:#fff2b8}
#celeCard .xSeas{display:flex;gap:14px;justify-content:center;margin-top:10px}#celeCard .xsz{display:flex;flex-direction:column;align-items:center;font-size:44px;opacity:.45;filter:grayscale(1)}#celeCard .xsz small{font-size:15px;line-height:1.2}
.xcGrid{margin-top:8px}.xcRow{display:flex;align-items:center;gap:4px;justify-content:center;margin:3px 0}.xcRow b{width:34px;font-size:24px}.xcRow em{width:28px;font-style:normal}
.xcRow i{width:21px;height:22px;border-radius:5px 5px 2px 2px;background:#5a3a2a;border:2px solid #26232e;display:inline-block}.xcRow i.lit{background:#ffd86a;box-shadow:0 0 8px #ffd23f}`;
document.head.appendChild(css);
window.SEASONS.xmas={id:'xmas',order:1,name:'Christmas Snow',short:'Christmas',icon:'❄️',tag:'🎄',card:['🎄','Christmas cards'],lockShort:'After the World Tour',
  on,opened,named,nFound,total:()=>all().length,invite,hide:deerHide,
  book:{xp,found:xFound,islX,islN,fact:id=>FACT[id],tag:'🎄',word:'Christmas',isl:I=>`${I.name} at Christmas`}};
const XM=window.XMAS={deer3D,on,opened,named,XS,all,xpup,xFound,nFound,islN,islX,areaX,nSp,deer,he,his,him,found,deerSVG,DEER,snd,plan,grid,globe,calendar,setSeason,intro,fromConga,invite,snowfall,mound,present3D,presentSVG,LIVE:()=>LIVE,NEED,LESSON,
  rebuildPack,deerHide,deerEnter,starSVG,kindOf,noSpots:false};
})();

/* ================= season history (25 Nov evening) =================
   Night Glow was seen switching off by itself on the way to the Lily Pond, which could not be reproduced. The save now keeps a
   short history (state.slog, last 12): every page load, and every change of season with the code that made it, shown under
   the season switches in the grown-ups panel. */
(function(){
  const NM=k=>k?((window.SEASONS[k]||{}).name||k):'islands',hm=t=>{const d=new Date(t);return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');};
  function log(ev,who){if(!state)return;const L=state.slog=Array.isArray(state.slog)?state.slog:[];L.push([Date.now(),ev,state.where||'',(typeof cur!=='undefined'?cur:'')||'',who||'']);while(L.length>12)L.shift();}
  function caller(){const st=(new Error().stack||'').split('\n').map(x=>x.trim()).filter(x=>x&&!/^Error/.test(x));
    return st.slice(2,5).map(x=>x.replace(/^at /,'').replace(/\(?(?:https?|blob):[^)]*\/([^/:)]+):(\d+):\d+\)?/,'$1:$2').replace(/@.*\/([^/:]+):(\d+):\d+$/,'@$1:$2').slice(0,50)).join(' < ');}
  function watch(){if(!state||Object.getOwnPropertyDescriptor(state,'season')&&Object.getOwnPropertyDescriptor(state,'season').get)return;
    let v=state.season||null;
    Object.defineProperty(state,'season',{configurable:true,enumerable:true,get(){return v;},set(n){n=n||null;if(n!==v){const was=v;v=n;log(NM(was)+' > '+NM(n),caller());}else v=n;}});}
  let loaded=false;const tick=()=>{if(!state)return;watch();if(!loaded){loaded=true;log('load ('+NM(state.season)+')');}};
  setTimeout(tick,0);setInterval(tick,2000);
  window.SEASONLOG={log,watch,text:n=>((state&&state.slog)||[]).slice(-(n||4)).map(e=>`${hm(e[0])} ${e[1]}${e[2]?' at '+e[2]:''}${e[4]?' ['+e[4]+']':''}`).join('; ')};
})();
