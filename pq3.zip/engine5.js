/* ================================================================
   Seb's Puppy Quest 3: Release 5 engine pieces.
   - island pairs (Ninja Mountains and Number Kingdom open after
     Snowy Summit and Coral Reef)
   - more Pup Type gate looks: ice wall, lanterns, dark cave, river
   - number locks on gates (three quick sums open the gate)
   - a quiz engine for maths activities (times tables, shapes, pizza)
   - times tables that the grown-ups choose
   ================================================================ */
const tablesOn=()=>{const t=(state.set&&state.set.tables)||[];return t.length?t.slice().sort((a,b)=>a-b):[2,5,10];};
const rint=(a,b)=>a+Math.floor(Math.random()*(b-a+1));
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
function islLockSay(id){const IS=islandOf(id);if(!IS)return 'That island is still being built.';const r=IS.req||['meadow'];
  return r.length>1?`${IS.name} opens when you have finished ${r.map(k=>islandOf(k).name).join(' and ')}. Meet ${r.map(k=>islandOf(k).boss.uni.name).join(' and ')}!`:`${IS.name} opens when you have finished ${islandOf(r[0]).name}. Find all the ${islandOf(r[0]).name.split(' ')[0]} pups and meet ${islandOf(r[0]).boss.uni.name}!`;}

/* ----------------- more gate looks ----------------- */
const GATE_LOOKS={
  icewall(blk,grow){for(let i=0;i<5;i++)mk('box',i%2?'#bfeaff':'#dff4ff',1.3,4.6+(i%3)*.8,1.3,-2.6+i*1.3,2.4,0,blk);mk('box','#ffffff',6.8,.5,1.6,0,5.4,0,blk);
    for(let i=0;i<6;i++)mk('cone','#e8f6ff',.25,1,.25,-2.5+i,-.0+4.9,0.8,blk).rotation.x=Math.PI;for(let i=0;i<3;i++)mk('sph','#9be8ff',.5,.25,.5,-1.6+i*1.6,.1,1.2,grow);},
  lanterns(blk,grow){mk('box','#7a2a1e',6.6,5.2,.5,0,2.6,0,blk);mk('box','#c9342a',7.2,.5,.9,0,5.4,0,blk);mk('cyl','#ffd23f',.25,.25,.25,0,2.6,.3,blk).rotation.x=Math.PI/2;
    [-2.4,2.4].forEach(s=>{mk('cyl','#5b4636',.15,3.8,.15,s,1.9,1.4,blk);mk('box','#f2e6d8',.7,.9,.7,s,4.2,1.4,blk);mk('cyl','#5b4636',.15,3.8,.15,s,1.9,1.4,grow);mk('box','#ffb347',.8,1,.8,s,4.2,1.4,grow,0,0,0);mk('sph','#ffd23f',.3,.45,.3,s,5.1,1.4,grow);});},
  dark(blk,grow){mk('box','#3a3338',7,6,1.4,0,3,0,blk);mk('box','#1a1720',4,4.4,.3,0,2.2,.75,blk);for(let i=0;i<5;i++)mk('sph','#5b5358',.9,.7,.9,-3+i*1.5,6,.2,blk);mk('cyl','#c9c2b8',.1,.1,.1,0,0,0,blk);
    for(let i=0;i<5;i++){mk('cyl','#5b4636',.08,1.4,.08,-2.4+i*1.2,.7,1.4,grow);mk('sph','#fff27a',.3,.3,.3,-2.4+i*1.2,1.55,1.4,grow);}},
  river(blk,grow){const w=new THREE.Mesh(G.box,new THREE.MeshBasicMaterial({color:'#5fc4f0',transparent:true,opacity:.85}));w.scale.set(7,.3,4.2);w.position.y=.12;blk.add(w);W.disp.push(w.material);
    for(let i=0;i<6;i++)mk('box','#ffffff',.7,.12,.12,-2.6+i,.32,-1.4+(i%3)*1.4,blk);for(let i=0;i<4;i++)mk('cyl','#b7bcc9',.75,.3,.75,-.6+(i%2)*1.2,.25,-1.8+i*1.2,grow);}};

/* ----------------- number locks ----------------- */
function dotsPic(rows,cols,ch){const r=Math.min(rows,12),c=Math.min(cols,12);let s='<div class="dots">';for(let i=0;i<r;i++){s+='<div>';for(let j=0;j<c;j++)s+=`<span>${ch||'●'}</span>`;s+='</div>';}return s+'</div>';}
function opts(ans,cands,n){const o=[ans];shuffle(cands.filter(v=>v>=0&&v!==ans&&Number.isInteger(v))).forEach(v=>{if(o.length<n&&o.indexOf(v)<0)o.push(v);});let k=1;while(o.length<n){const v=ans+k*(k%2?1:-1)*Math.ceil(k/2);if(v>=0&&o.indexOf(v)<0)o.push(v);k++;}return shuffle(o);}
/* one question; kind: times, missing, add, take, share, double, half, quarter, sides */
function makeQ(kind,n){n=n||3;const T=tablesOn();
  if(kind==='times'){const a=pick(T),b=rint(1,10),ans=a*b;return {q:`${b} × ${a} = ?`,say:`What is ${b} times ${a}?`,ans,opts:opts(ans,[ans+a,ans-a,ans+1,ans-1,a*(b+2),ans+10,ans-10],n),hint:dotsPic(b,a),hintSay:`Count ${b} rows of ${a}. ${Array.from({length:b},(_,i)=>a*(i+1)).join(', ')}.`};}
  if(kind==='missing'){const a=pick(T),b=rint(2,10),c=a*b;return {q:`${a} × ? = ${c}`,say:`${a} times what makes ${c}?`,ans:b,opts:opts(b,[b+1,b-1,b+2,b-2,a],n),hint:dotsPic(b,a),hintSay:`Count in ${a}s until you get to ${c}. How many jumps?`};}
  if(kind==='add'){const a=rint(3,12),b=rint(2,9),ans=a+b;return {q:`${a} + ${b} = ?`,say:`What is ${a} add ${b}?`,ans,opts:opts(ans,[ans+1,ans-1,ans+2,ans+10,ans-2],n),hint:dotsPic(1,a,'🔵')+dotsPic(1,b,'🟢'),hintSay:`Start at ${a} and count on ${b} more.`};}
  if(kind==='take'){const a=rint(8,20),b=rint(2,7),ans=a-b;return {q:`${a} − ${b} = ?`,say:`What is ${a} take away ${b}?`,ans,opts:opts(ans,[ans+1,ans-1,ans+2,a+b],n),hint:dotsPic(1,a,'🍪'),hintSay:`Start at ${a} and count back ${b}.`};}
  if(kind==='share'){const k=pick([2,3,4,5].filter(v=>T.indexOf(v)>=0).concat([2,4])),m=rint(2,6),tot=k*m;return {q:`Share ${tot} 🦴 between ${k} pups`,say:`Share ${tot} bones between ${k} pups. How many bones does each pup get?`,ans:m,opts:opts(m,[m+1,m-1,m+2,k],n),hint:dotsPic(k,m,'🦴'),hintSay:`Give each pup one bone at a time, until all ${tot} are gone.`};}
  if(kind==='double'){const a=rint(2,15),ans=a*2;return {q:`Double ${a} = ?`,say:`What is double ${a}?`,ans,opts:opts(ans,[ans+1,ans-1,a+1,ans+2],n),hint:dotsPic(2,a),hintSay:`Double means two lots. ${a} add ${a}.`};}
  if(kind==='half'){const a=rint(1,10)*2,ans=a/2;return {q:`Half of ${a} = ?`,say:`What is half of ${a}?`,ans,opts:opts(ans,[ans+1,ans-1,a,ans+2],n),hint:dotsPic(2,ans),hintSay:`Split ${a} into two equal groups.`};}
  if(kind==='quarter'){const a=pick([4,8,12,16,20]),ans=a/4;return {q:`A quarter of ${a} = ?`,say:`What is a quarter of ${a}?`,ans,opts:opts(ans,[ans+1,ans-1,a/2,ans+2],n),hint:dotsPic(4,ans),hintSay:`Split ${a} into four equal groups.`};}
  return makeQ('times',n);}
/* a number lock: tap the 🔢 sign, answer 3 questions */
function buildNumLock(e){const L=e.nlock,d=Math.hypot(e.x,e.z)||1,ux=-e.x/d,uz=-e.z/d,tx=e.x+ux*6.5,tz=e.z+uz*6.5;
  const g=grp();mk('box','#5b4636',.25,3.2,.25,0,1.6,0,g);mk('box','#ffd23f',2.6,1.8,.25,0,3.6,0,g);const s=sprite('🔢',1.2);s.position.set(0,3.6,.2);g.add(s);g.rotation.y=Math.atan2(-ux,-uz);add(g,tx,tz);col(tx,tz,.4);
  const sg=label('🔢 Number lock',5);sg.position.set(tx,gy(tx,tz)+6,tz);W.ag.add(sg);const vis=()=>{const v=!state.vines[L.key];g.visible=v;sg.visible=v;};vis();
  W.things.push({x:tx,z:tz,r:4.2,icon:'🔢',label:'Number lock',show:()=>!state.vines[L.key],act:()=>numLock(e,vis)});}
function numLock(e,vis){const L=e.nlock,n=L.n||3,c=$('#menuCard');let i=0,wrong=0,Q=null;c.className='card wide nlock';hush();
  const kinds=Array.isArray(L.kind)?L.kind:[L.kind||'times'];
  const ask=()=>{Q=makeQ(kinds[i%kinds.length],3);wrong=0;
    c.innerHTML=`<h2>🔢 Number lock</h2><div class="nlprog">${Array.from({length:n},(_,k)=>`<span class="${k<i?'ok':''}">${k<i?'✅':'🔒'}</span>`).join('')}</div>
      <div class="nlq">${Q.q}</div><div class="nlhint"></div><div class="nlopts">${Q.opts.map(v=>`<button class="btn white" data-v="${v}">${v}</button>`).join('')}</div>
      <div class="btns"><button class="btn white small" data-v="x">Not now</button></div>`;speak(Q.say);};
  c.onclick=ev=>{const b=ev.target.closest('button');if(!b)return;initAudio();const v=b.dataset.v;if(v==='x'){sfx.boop();closeOv('menu');c.onclick=null;return;}
    if(+v===Q.ans){sfx.ding?sfx.ding():sfx.chime();b.classList.add('right');i++;state.stats.sums=(state.stats.sums||0)+1;
      if(i>=n){setTimeout(()=>{closeOv('menu');c.onclick=null;state.vines[L.key]=true;state.stars+=5;save();hud();vis();sfx.jingle();confetti(50);say(L.done||`Click! The number lock is open. Well done, number ninja! The way to ${e.name} is open!`);},500);}
      else{say(pick(['Yes!','Correct!','Brilliant!','Super sums!']));setTimeout(ask,700);}}
    else{sfx.oops();anim(b,'t-shake',500);b.disabled=true;wrong++;c.querySelector('.nlhint').innerHTML=Q.hint;say(wrong>1?`Here is a clue. ${Q.hintSay}`:`Not quite. Have another go! ${Q.hintSay}`);}};
  $('#menu').classList.add('on');ask();}

/* ----------------- the quiz engine (maths activities) ----------------- */
const QUIZ={};let QZ=null;
function startQuiz(mode,key){gStop&&gStop();mg=null;hush();joyReset();const sk=QUIZ[key];QZ={mode,key,sk,i:0,t0:performance.now(),wrong:0,busy:false};
  $('#qzBg').innerHTML=sk.bg();$('#qzPup').innerHTML=pupBox(buddyPup());$('#qzTower').innerHTML='';$('#qzTitle').textContent=`${sk.icon} ${sk.name}`;show('quiz');
  say(sk.intro);setTimeout(()=>{if(QZ&&QZ.key===key&&QZ.i===0)quizAsk();},sk.introMs||2600);quizInfo();}
function quizInfo(){if(QZ)$('#qzInfo').textContent=`${Math.min(QZ.i+1,QZ.sk.n)} of ${QZ.sk.n}`;}
function quizAsk(){const Z=QZ;if(!Z)return;const Q=Z.Q=Z.sk.make(Z.i);Z.wrong=0;Z.busy=false;quizInfo();
  $('#qzQ').innerHTML=Q.q;$('#qzPic').innerHTML=Q.pic||'';$('#qzHint').innerHTML='';
  $('#qzOpts').innerHTML=Q.opts.map((v,k)=>`<button class="btn white qopt${!Q.show&&String(v).length>4?' long':''}" data-k="${k}">${Q.show?Q.show(v):v}</button>`).join('');speak(Q.say);}
function quizTap(k){const Z=QZ;if(!Z||Z.busy||!Z.Q)return;const Q=Z.Q,v=Q.opts[k],b=$('#qzOpts').children[k];
  if(v===Q.ans){Z.busy=true;b.classList.add('right');state.stats.sums=(state.stats.sums||0)+1;sfx.ding?sfx.ding():sfx.chime();anim($('#qzPup .fitsvg')||$('#qzPup'),'t-jump',600);
    const blk=el('div','qblk',Z.sk.block?Z.sk.block(Q,Z.i):String(Q.ans));blk.style.background=['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff'][Z.i%6];$('#qzTower').prepend(blk);
    Z.i++;if(Q.after)$('#qzPic').innerHTML=Q.after;say(pick(['Yes!','Correct!','Brilliant!','Well done!','Super!']));
    if(Z.i>=Z.sk.n){setTimeout(()=>{if(QZ!==Z)return;const secs=(performance.now()-Z.t0)/1000;QZ=null;finishAct(Z.sk.k,secs,pupBox(buddyPup()),Z.sk.title,()=>startQuiz(Z.mode,Z.key),true);},900);}
    else setTimeout(()=>{if(QZ===Z)quizAsk();},Q.after?1500:900);}
  else{sfx.oops();anim(b,'t-shake',500);b.disabled=true;Z.wrong++;$('#qzHint').innerHTML=Q.hint||'';say(Z.wrong>1&&Q.hintSay?`Here is a clue. ${Q.hintSay}`:`Not quite. Try again!${Q.hintSay?' '+Q.hintSay:''}`);}}
(function(){const o=$('#qzOpts');o.addEventListener('click',e=>{const b=e.target.closest('.qopt');if(!b||b.disabled)return;initAudio();quizTap(+b.dataset.k);});
  tap('#qzBack',()=>{if(!QZ)return;sfx.boop();const m=QZ.mode;QZ=null;if(m==='lab'&&typeof openLab==='function'){openLab();return;}backToWorld(m==='activity'?'You can come back and play again any time!':null);});})();

/* ----------------- pictures for quizzes ----------------- */
const SHAPES=[{n:'triangle',s:3},{n:'square',s:4},{n:'pentagon',s:5},{n:'hexagon',s:6},{n:'octagon',s:8},{n:'circle',s:0}];
function shapeSVG(sides,col,sz){sz=sz||110;const c=sz/2,r=sz*.42;let d;if(!sides)return `<svg viewBox="0 0 ${sz} ${sz}" width="${sz}" height="${sz}"><circle cx="${c}" cy="${c}" r="${r}" fill="${col}" stroke="${INK}" stroke-width="5"/></svg>`;
  d=Array.from({length:sides},(_,i)=>{const a=-Math.PI/2+i*2*Math.PI/sides+(sides===4?Math.PI/4:0);return (i?'L':'M')+(c+Math.cos(a)*r).toFixed(1)+' '+(c+Math.sin(a)*r).toFixed(1);}).join(' ')+'Z';
  return `<svg viewBox="0 0 ${sz} ${sz}" width="${sz}" height="${sz}"><path d="${d}" fill="${col}" stroke="${INK}" stroke-width="5" stroke-linejoin="round"/></svg>`;}
function pizzaSVG(slices,eaten,sz){sz=sz||220;const c=sz/2,r=sz*.44;let s=`<svg viewBox="0 0 ${sz} ${sz}" width="${sz}" height="${sz}"><circle cx="${c}" cy="${c}" r="${r+6}" fill="#e0a45c" stroke="${INK}" stroke-width="5"/>`;
  for(let i=0;i<slices;i++){const a1=-Math.PI/2+i*2*Math.PI/slices,a2=a1+2*Math.PI/slices,x1=c+Math.cos(a1)*r,y1=c+Math.sin(a1)*r,x2=c+Math.cos(a2)*r,y2=c+Math.sin(a2)*r,on=i<eaten;
    s+=`<path d="M${c} ${c} L${x1.toFixed(1)} ${y1.toFixed(1)} A${r} ${r} 0 0 1 ${x2.toFixed(1)} ${y2.toFixed(1)}Z" fill="${on?'#ffe39a':'#ffd23f'}" stroke="${INK}" stroke-width="3" opacity="${on?.35:1}"/>`;
    if(!on){const am=(a1+a2)/2;s+=`<circle cx="${(c+Math.cos(am)*r*.6).toFixed(1)}" cy="${(c+Math.sin(am)*r*.6).toFixed(1)}" r="${sz*.04}" fill="#e8423a"/>`;}}
  return s+'</svg>';}

/* ----------------- grown-ups: times tables to practise ----------------- */
(function(){const base=openSettings;openSettings=function(){base();const c=$('#setCard'),row=document.createElement('div');row.className='srow tt';const T=tablesOn();
  row.innerHTML=`✖️ Times tables to practise<div class="opts">${[2,3,4,5,6,7,8,9,10,11,12].map(n=>`<button class="opt tt${T.indexOf(n)>=0&&(state.set.tables||[]).length?' on':''}" data-t="${n}">${n}</button>`).join('')}</div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=`Number Kingdom's number locks and Times Table Towers use these tables. ${(state.set.tables||[]).length?'':'None chosen yet, so it uses 2, 5 and 10.'}`;
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Open all areas/.test(r.textContent))||c.querySelector('.srow:nth-of-type(5)');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt.tt').forEach(b=>tap(b,()=>{const n=+b.dataset.t;let t=(state.set.tables||[]).slice();const i=t.indexOf(n);if(i>=0)t.splice(i,1);else t.push(n);state.set.tables=t;save();sfx.boop();openSettings();}));};})();

/* ----------------- shared props for the new islands ----------------- */
function penBox2(lbl,fill,rail,post){const k=INK,P=PEN;let s=`<rect x="${P.x1}" y="${P.y1}" width="${P.x2-P.x1}" height="${P.y2-P.y1}" fill="${fill}" opacity=".75"/>`;
  const r=(x1,y1,x2,y2)=>`<path d="M${x1} ${y1-10} L${x2} ${y2-10}" stroke="${k}" stroke-width="18" stroke-linecap="round"/><path d="M${x1} ${y1-10} L${x2} ${y2-10}" stroke="${rail}" stroke-width="11" stroke-linecap="round"/>`;
  s+=r(P.x1,P.y1,P.x2,P.y1)+r(P.x2,P.y1,P.x2,P.y2)+r(P.x1,P.y2,P.x2,P.y2)+r(P.x1,P.y1,P.x1,P.gy1)+r(P.x1,P.gy2,P.x1,P.y2);
  [[P.x1,P.gy1],[P.x1,P.gy2]].forEach(q=>s+=`<rect x="${q[0]-12}" y="${q[1]-34}" width="24" height="44" rx="6" fill="${post}" stroke="${k}" stroke-width="3"/>`);
  return s+`<g transform="translate(${P.x1+70} ${P.y1+40})"><rect x="-70" y="-30" width="140" height="40" rx="10" fill="#fff" stroke="${k}" stroke-width="4"/><text x="0" y="-2" font-size="22" font-weight="900" text-anchor="middle" fill="${k}">${lbl}</text></g>
  <path d="M${P.x1-70} ${(P.gy1+P.gy2)/2} l40 0 m-14 -14 l14 14 l-14 14" stroke="#fff" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity=".9"/>`;}
/* a pagoda: stacked halls with wide roofs; face is the door side */
function pagoda(x,z,o){o=o||{};const s=o.s||1,tiers=o.tiers||2,wall=o.wall||'#f2e6d8',roof=o.roof||'#3a3338',pil=o.pil||'#c9342a',trim=o.trim||'#ffd23f',a=FACE[o.face||'s'],y=gy(x,z);let w=(o.w||12)*s,h=3.4*s,yy=y;
  I('box','#a9a399',w+3,.8,w+3,x,y+.4,z,0,a,0);for(let k=0;k<3;k++)I('box','#c9c2b8',4*s,.35,1.2,x+Math.sin(a)*(w/2+1.6+k*.8),y+.6-k*.2,z+Math.cos(a)*(w/2+1.6+k*.8),0,a,0);yy+=.8;
  for(let t=0;t<tiers;t++){const ww=w*(1-t*.22);I('box',wall,ww,h,ww,x,yy+h/2,z,0,a,0);
    if(t===0){[[-1,-1],[1,-1],[-1,1],[1,1],[-.33,1],[.33,1]].forEach(q=>{const lx=q[0]*ww/2,lz=q[1]*ww/2,ca=Math.cos(a),sa=Math.sin(a);I('cyl',pil,.32*s,h,.32*s,x+lx*ca+lz*sa,yy+h/2,z-lx*sa+lz*ca);});
      const dx=Math.sin(a)*(ww/2+.06),dz=Math.cos(a)*(ww/2+.06);I('box','#5b2a1e',2.6*s,2.6*s,.2,x+dx,yy+1.3*s,z+dz,0,a,0);I('box',trim,3*s,.3,.25,x+dx,yy+2.7*s,z+dz,0,a,0);
      [-1,1].forEach(q=>{const lx=q*ww*.3;I('box','#fff6c9',1.2*s,1.2*s,.15,x+dx+Math.cos(a)*lx,yy+2*s,z+dz-Math.sin(a)*lx,0,a,0,true);});}
    yy+=h;I('pyr',roof,ww*.95,1.6*s,ww*.95,x,yy+.7*s,z,0,a+Math.PI/4,0);I('box',trim,ww*1.36,.18,ww*1.36,x,yy+.05,z,0,a,0);
    [[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>{const lx=q[0]*ww*.68,lz=q[1]*ww*.68,ca=Math.cos(a),sa=Math.sin(a);I('cone',trim,.25,.8,.25,x+lx*ca+lz*sa,yy+.35,z-lx*sa+lz*ca);});yy+=1.2*s;}
  I('cyl',trim,.15,2.2*s,.15,x,yy+1.1*s,z);for(let k=0;k<3;k++)I('tor',trim,.45*s,.45*s,.45*s,x,yy+.5*s+k*.6*s,z,Math.PI/2,0,0);
  const hw=w/2+1.2;rect(x-hw,z-hw,x+hw,z+hw);camBlock(x-hw,z-hw,x+hw,z+hw);
  if(o.label){const l=label(o.label,o.lw||7);l.position.set(x,yy+3*s,z);W.ag.add(l);}return {y:yy,front:[x+Math.sin(a)*(w/2+5),z+Math.cos(a)*(w/2+5)]};}
function torii(x,z,rot,c,s){s=s||1;c=c||'#d9362e';const y=gy(x,z),ca=Math.cos(rot||0),sa=Math.sin(rot||0),P=(l)=>[x+l*ca,z-l*sa];
  [-1,1].forEach(q=>{const p=P(q*3.4*s);I('cyl',c,.36*s,6*s,.36*s,p[0],y+3*s,p[1]);I('cyl','#3a3338',.45*s,.6,.45*s,p[0],y+.3,p[1]);col(p[0],p[1],.5*s);});
  I('box',c,8*s,.5*s,.6*s,x,y+4.8*s,z,0,rot||0,0);I('box','#3a3338',9.6*s,.5*s,.9*s,x,y+6.2*s,z,0,rot||0,0);I('box',c,9*s,.45*s,.75*s,x,y+5.8*s,z,0,rot||0,0);I('box','#ffd23f',1*s,1.2*s,.2,x,y+5.3*s,z,0,rot||0,0);}
function stoneLantern(x,z,s,lit){s=s||1;const y=gy(x,z);I('box','#a9a399',1*s,.3*s,1*s,x,y+.15*s,z);I('cyl','#a9a399',.22*s,1.4*s,.22*s,x,y+1*s,z);I('box','#a9a399',.9*s,.2*s,.9*s,x,y+1.75*s,z);
  I('box',lit===false?'#6b6560':'#fff27a',.6*s,.6*s,.6*s,x,y+2.15*s,z,0,0,0,lit!==false);I('pyr','#8a8378',.85*s,.6*s,.85*s,x,y+2.75*s,z,0,Math.PI/4,0);I('sph','#8a8378',.15*s,.15*s,.15*s,x,y+3.1*s,z);col(x,z,.6*s);}
function bambooClump(x,z,k,h,Rn){Rn=Rn||Math.random;const y=gy(x,z);k=k||5;h=h||7;for(let j=0;j<k;j++){const bx=x+(Rn()-.5)*2,bz=z+(Rn()-.5)*2,hh=h*(.7+Rn()*.5);I('cylL',pick(['#7fbf4a','#6aae3a','#8fcf5a']),.18,hh,.18,bx,y+hh/2,bz,(Rn()-.5)*.08,0,(Rn()-.5)*.08);
  for(let q=1.2;q<hh;q+=1.3)I('cylL','#4f8e2a',.21,.12,.21,bx,y+q,bz);I('sphL','#6cc45e',1.1,.45,1.1,bx,y+hh,bz);I('sphL','#5fae4a',.8,.35,.8,bx+.5,y+hh*.8,bz);}col(x,z,1.2);}
function cherry(x,z,s){tree(x,z,s||1,pick(['#ffb7d5','#ff9ecb','#ffc9e0']));for(let i=0;i<10;i++){const a=Math.random()*6.28,r=1+Math.random()*3;I('cyl','#ffc9e0',.18,.02,.18,x+Math.cos(a)*r,gy(x,z)+.06,z+Math.sin(a)*r);}}
function redBridge(x,z,rot,len){len=len||8;const y=gy(x,z),ca=Math.cos(rot||0),sa=Math.sin(rot||0);for(let i=0;i<=10;i++){const t=i/10-.5,h=Math.cos(t*Math.PI)*1.3,lx=t*len;I('box','#c9905f',len/10+.1,.2,2.6,x+lx*ca,y+h+.2,z-lx*sa,0,rot||0,-Math.sin(t*Math.PI)*.35);
  [-1.25,1.25].forEach(q=>{I('cyl','#d9362e',.08,1,.08,x+lx*ca+q*sa,y+h+.7,z-lx*sa+q*ca);});}[-1.25,1.25].forEach(q=>{for(let i=0;i<10;i++){const t=(i+.5)/10-.5,h=Math.cos(t*Math.PI)*1.3,lx=t*len;I('box','#d9362e',len/10+.15,.12,.12,x+lx*ca+q*sa,y+h+1.2,z-lx*sa+q*ca,0,rot||0,-Math.sin(t*Math.PI)*.35);}});}
function stickBetween(m,a,b){const dx=b.x-a.x,dy=b.y-a.y,dz=b.z-a.z,L=Math.hypot(dx,dy,dz)||1;m.position.set((a.x+b.x)/2,(a.y+b.y)/2,(a.z+b.z)/2);m.scale.set(m.userData.th||.05,L,m.userData.th||.05);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),new THREE.Vector3(dx/L,dy/L,dz/L));}
/* a long flying dragon; path(t) gives where the head is at time t */
function dragonFlyer(path,o){o=o||{};const c1=o.c||'#3fae5a',c2=o.c2||'#ffd23f',n=o.n||12,s=o.s||1,segs=[];
  const head=grp();mk('box',c1,1.4*s,1*s,1.8*s,0,0,.2*s,head);mk('box',c2,1.1*s,.35*s,1*s,0,-.45*s,.9*s,head);[-1,1].forEach(q=>{mk('cone',c2,.18*s,1*s,.18*s,q*.45*s,.85*s,-.3*s,head).rotation.x=-.5;mk('sph','#ffffff',.22*s,.22*s,.22*s,q*.42*s,.25*s,.75*s,head);mk('sph','#26232e',.11*s,.11*s,.11*s,q*.45*s,.27*s,.92*s,head);
    const wh=mk('cyl',c2,.03*s,1.4*s,.03*s,q*.6*s,-.2*s,1.1*s,head);wh.rotation.z=q*1.2;});W.ag.add(head);
  for(let i=0;i<n;i++){const g=grp(),r=(1-i/n*.6)*s;mk('sph',c1,.75*r,.7*r,.75*r,0,0,0,g);mk('cone',c2,.18*r,.6*r,.18*r,0,.65*r,0,g);if(i===3||i===6){[-1,1].forEach(q=>{const w=mk('box',o.wing||'#ff9ecb',2.2*s,.06,1*s,q*1.3*s,.2,0,g);w.userData.q=q;g.userData.wing=g.userData.wing||[];g.userData.wing.push(w);});}W.ag.add(g);segs.push(g);}
  const tick=dt=>{const t=W.t*(o.speed||1);const p=path(t),p2=path(t+.05);head.position.set(p[0],p[1],p[2]);head.lookAt(p2[0],p2[1],p2[2]);
    segs.forEach((g,i)=>{const q=path(t-(i+1)*(o.lag||.07));g.position.set(q[0],q[1],q[2]);(g.userData.wing||[]).forEach(w=>{w.rotation.z=w.userData.q*Math.sin(W.t*6)*.5;});});};W.ticks.push(tick);tick(0);return {head,segs};}
function mountainsFar(cols){[[-170,-240,70],[30,-300,90],[210,-230,60],[-290,-40,55],[290,60,65],[-220,180,50],[180,240,55]].forEach((m,i)=>{I('cone',cols&&cols[i%cols.length]||'#8fa6c0',m[2],m[2]*1.5,m[2],m[0],m[2]*.55-12,m[1]);I('cone','#ffffff',m[2]*.4,m[2]*.55,m[2]*.4,m[0],m[2]*1.17-12,m[1]);});}
function cloudPuffs(n,y,r,c){for(let i=0;i<n;i++){const a=i/n*6.28,rr=r*(1+Math.sin(i*3.7)*.15),x=Math.cos(a)*rr,z=Math.sin(a)*rr;for(let k=0;k<3;k++)I('sphL',c||'#ffffff',6+k*2,3+k,6+k*2,x+k*3,y+(k%2),z-k*2,0,0,0,true);}}
/* a little steam train: engine plus carriages; returns the group */
function train3D(cols){cols=cols||['#e8423a','#3d8fe0','#ffd23f','#3fae5a'];const g=grp();
  mk('box',cols[0],2.2,1.8,4,0,1.5,0,g);mk('cyl',cols[0],.95,3,.95,0,1.9,2.5,g).rotation.x=Math.PI/2;mk('cyl','#26232e',.35,1.4,.35,0,3.2,3.4,g);mk('box','#26232e',2.4,.3,4.6,0,.55,.6,g);mk('box','#fff6c9',.6,.6,.1,0,1.9,4.05,g);
  mk('box',cols[0],2.4,.4,2.4,0,3.2,-.6,g);mk('box','#9bdcff',2.3,.9,.1,0,2.4,-1.4,g);for(let i=0;i<3;i++)[-1.1,1.1].forEach(q=>mk('cyl','#26232e',.55,.3,.55,q,.6,-1.2+i*1.5,g).rotation.z=Math.PI/2);
  for(let c=1;c<cols.length;c++){const z=-5.2*c;mk('box',cols[c],2.2,1.8,4.4,0,1.5,z,g);mk('box','#ffffff',2.4,.25,4.6,0,2.5,z,g);for(let w=0;w<3;w++)[-1.11,1.11].forEach(q=>mk('box','#9bdcff',.08,.7,.9,q,1.7,z-1.4+w*1.4,g));
    [-1.6,1.6].forEach(dz=>[-1.1,1.1].forEach(q=>mk('cyl','#26232e',.45,.3,.45,q,.5,z+dz,g).rotation.z=Math.PI/2));const n=sprite(['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣'][c-1],1.1);n.position.set(0,3.3,z);g.add(n);}
  return g;}
function castleTower(x,z,r,h,c,roof,flag){const y=gy(x,z);I('cyl',c,r,h,r,x,y+h/2,z);I('cyl',shade(c,-.08),r*1.12,.6,r*1.12,x,y+h+.3,z);for(let i=0;i<8;i++){const a=i/8*6.28;I('box',c,.7,.8,.7,x+Math.cos(a)*r*1.02,y+h+1,z+Math.sin(a)*r*1.02);}
  if(roof){I('cone',roof,r*1.15,r*1.6,r*1.15,x,y+h+.6+r*.8,z);I('cyl','#9b6a43',.06,1.6,.06,x,y+h+r*1.6+1.2,z);I('box',flag||'#ffd23f',1,.6,.04,x+.5,y+h+r*1.6+1.7,z);}
  for(let i=0;i<3;i++)I('box','#26232e',.5,.9,.1,x+Math.cos(i*2.1)*r,y+h*.6,z+Math.sin(i*2.1)*r,0,-i*2.1+Math.PI/2,0);col(x,z,r+.3);}
