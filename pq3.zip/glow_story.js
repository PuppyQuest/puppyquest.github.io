/* ================================================================
   Night Glow (25 Nov 2026; claude/night-glow-design.md sections 2, 9, 10, 15): the story.
   Muddle sightings, the Glow Song call, Muddle's nest of jars in Bluebell Wood, the Glow Flight
   (a 2D flight with a star picture over every island, ending with the Great Dog and a faint
   twinkle beside Sirius: the saga seed), the Star Party, 6 badges, the certificate, the
   goodbye and the Halloween teaser (since 25 Nov it goes straight into Halloween's opening).
   ================================================================ */
(function(){
const GW=window.GLOW,PI=Math.PI,LIME='#d8ff5a',GOLD='#ffd23f';
const X=()=>GW.GS(),F=()=>GW.fly().name,big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`,mg=w=>`<div class="fitsvg" style="width:${w||150}px">${magpieSVG()}</div>`,fs=w=>`<div class="fitsvg" style="width:${w||160}px">${GW.flySVG()}</div>`;
const Cap=s=>s.charAt(0).toUpperCase()+s.slice(1);

/* ---------------- Muddle sightings during the search ---------------- */
const SEEN={4:'Professor Hoot saw Muddle flap past last night, carrying a bag that went clink, clink, clink!',12:'A pup says: "Muddle went by humming a Christmas song, with a jam jar under each wing!"',
 24:'Someone spotted a faint glow over Meadow Island... and a magpie-shaped shadow!',40:'"Muddle flew towards Meadow Island with more empty jars," says a guide. "I wonder what he is up to?"'};
function afterFind(p,n){const T=X();T.seen=T.seen||{};if(SEEN[n]&&!T.seen[n]){T.seen[n]=1;save();setTimeout(()=>say(SEEN[n]),300);return true;}return false;}
/* ---------------- the Glow Song: all nine flashes ---------------- */
function onFlash(I,n){if(n<9)return;const T=X();setTimeout(()=>{player.lock=true;GW.snd.song(9,300);
  story([{art:fs(180)+big('🎵'),t:`${F()} knows all nine flashes now! ${Cap(GW.he())} flashes the whole Glow Song: blink, blink, blink... the call that every firefly answers.`},
    {art:big('🌳✨'),t:'Everyone holds their breath. Then, far away, a faint flicker answers... from Bluebell Wood on Meadow Island!'}],
    ()=>{player.lock=false;T.call=1;save();card({art:big('🌳'),h:'To Bluebell Wood!',p:'Shall we go to Bluebell Wood and find the Glow?',btns:[['🌳 Let\'s go!','green',()=>{player.lock=true;fadeTo(()=>enterArea('wood'),['🌳','Bluebell Wood']);}],['Later','white',()=>say('Bluebell Wood is on Meadow Island. Take the ferry from the village!')]]});});},900);}
/* ---------------- Muddle's nest in the old oak ---------------- */
const NX=-9,NZ=51;let NEST=null;
{const Wd=AREAS.wood,b=Wd.build;Wd.build=function(){b.apply(this,arguments);if(!GW.on())return;const T=GW.G0();if(!T||!T.call)return;const x=NX,z=NZ,y=gy(x,z);
  I('cyl','#5a3a22',1.6,9,1.6,x,y+4.5,z);[[2.6,7.6,0],[-2.4,8.4,1.6],[.4,9.2,-2.4],[1.8,10,2.2]].forEach(q=>I('sph','#2f5a3a',3.4,2.4,3.4,x+q[0],y+q[1],z+q[2]));
  [[1,0],[-1,.6],[.3,-1]].forEach(q=>I('cyl','#5a3a22',.35,3.2,.35,x+q[0]*1.4,y+6.4,z+q[1]*1.4,q[1]*.7,0,-q[0]*.7));col(x,z,2);
  const ny=y+5.4;I('cyl','#8a5a32',1.5,.45,1.5,x,ny,z+1.4);for(let i=0;i<10;i++){const a=i*.63;I('cyl','#a8743a',.07,1.5,.07,x+Math.cos(a)*1.3,ny+.2,z+1.4+Math.sin(a)*1.3,0,a,PI/2.4);}
  if(T.nest){GW.swarmPts(x,z,80,{r:5,h:7,y:y+1,size:.38});return;}
  const jars=[];for(let i=0;i<9;i++){const a=i/9*PI*2,jx=x+Math.cos(a)*2.6,jz=z+Math.sin(a)*2.6,jy=y+3.4+(i%3)*.6;I('cyl','#c8c8d0',.03,.6,.03,jx,jy+.6,jz);
    const m=new THREE.MeshBasicMaterial({color:'#7a8a4a'}),j=new THREE.Mesh(G.cyl,m);j.scale.set(.32,.5,.32);j.position.set(jx,jy,jz);W.ag.add(j);W.disp.push(m);jars.push({j,m});}
  const mud=magpie3D();mud.scale.setScalar(1.1);add(mud,x,z+1.4,ny+.25);W.ticks.push(()=>{mud.rotation.y=Math.sin(W.t*.6)*.5;jars.forEach((q,i)=>q.m.color.setHSL(.2,.5,.22+.06*Math.sin(W.t*2+i)));});
  NEST={jars,mud};W.things.push({x,z:z+4.2,r:5,icon:'💬',label:'Muddle',act:nestScene});
  setTimeout(()=>{if(W.area===Wd)say('Look up in the old oak! There is a nest, hung all round with jam jars... and Muddle!');},2400);};}
function jarUI(done){if(!$('#gjars')){const d=el('div','ov','<div class="card" id="gjCard"><h2>🫙 Open the jars!</h2><div id="gjRow"></div><p id="gjMsg">Tap every jar to let the fireflies go.</p></div>');d.id='gjars';document.body.appendChild(d);}
  const row=$('#gjRow');row.innerHTML='';let n=0;
  for(let i=0;i<9;i++){const b=el('button','gjar','<svg viewBox="0 0 80 100" width="80" height="100"><rect class="lid" x="16" y="8" width="48" height="14" rx="4" fill="#c8a040" stroke="#26232e" stroke-width="3"/><rect x="12" y="20" width="56" height="72" rx="12" fill="#e8f0f8" opacity=".75" stroke="#26232e" stroke-width="3"/>'+
    [[30,50],[48,60],[38,72],[52,44],[28,76]].map(q=>`<circle class="ff" cx="${q[0]}" cy="${q[1]}" r="4" fill="#9aa86a"/>`).join('')+'</svg>');
    tap(b,()=>{if(b.classList.contains('open'))return;b.classList.add('open');n++;GW.snd.pop();setTimeout(()=>GW.snd.note(n-1),120);if(NEST&&NEST.jars[i]){NEST.jars[i].j.visible=false;}
      $('#gjMsg').textContent=n<9?`${n} of 9 jars open!`:'Every jar is open!';if(n===9){setTimeout(()=>{$('#gjars').classList.remove('on');done();},1300);}});row.appendChild(b);}
  $('#gjars').classList.add('on');speak('Tap every jar to let the fireflies go!');}
function nestScene(){if(player.lock)return;player.lock=true;hush();sfx.chime();const T=X();
  story([{art:mg(150)+big('🫙'),t:'High in the old oak is a brand-new nest, hung all round with jam jars. Inside every jar, fireflies glow very, very dimly. And there is Muddle!'},
    {art:mg(160),t:'"I missed the Christmas lights so much," sniffs Muddle. "When they were packed away, everything felt dark. So I caught the fireflies, to make my nest glow like Christmas, for ever."'},
    {art:fs(170),t:`${F()} flies up to the jars. "Fireflies glow to talk to our friends. In a jar, nobody can hear us, so our lights go dim. Please let them go!"`},
    {art:mg(150),t:'"Oh no," says Muddle. "I didn\'t know. I\'m sorry!" Let\'s open the jars together!'}],
    ()=>jarUI(()=>{const W0=W.area;GW.swarmPts(NX,NZ,90,{r:5,h:7,y:gy(NX,NZ)+1,size:.4});GW.snd.twinkle();confetti(50);
      story([{art:big('✨✨✨'),t:'Pop, pop, pop! The Glow pours out of the jars and swirls round the old oak, brighter and brighter!'},
        {art:mg(150),t:'Muddle looks sad. "But now my nest is dark again."'},
        {art:fs(160)+big('🌙⭐'),t:`${F()} takes Muddle up above the trees. "Look up! The stars, the Moon, the glowing sea... the night is full of lights, and nobody has to keep them in a jar."`},
        {art:mg(150)+big('😊'),t:'Muddle smiles. "It\'s even better than Christmas lights," he whispers.'},
        {art:big('✨🍃✨'),t:'The Glow wants to say thank you. "Hold on tight, Seb! We will fly you round all nine islands, and paint pictures in the stars!"'}],
        ()=>{T.nest=Date.now();save();player.lock=false;glowFlight();});}));}
/* ---------------- the Glow Flight (a 2D flight) ---------------- */
const PICS={
 windmill:{pts:[[40,70],[44,32],[28,12],[50,26],[72,12],[56,32],[60,70]],name:'a windmill'},
 owl:{pts:[[50,70],[32,60],[28,36],[32,14],[42,24],[58,24],[68,14],[72,36],[68,60]],name:'an owl'},
 jelly:{pts:[[26,40],[34,22],[50,14],[66,22],[74,40],[64,60],[56,42],[50,64],[44,42],[36,60]],name:'a jellyfish'},
 dragon:{pts:[[14,30],[24,18],[36,26],[50,20],[62,32],[76,24],[90,34],[80,44],[64,42],[50,52],[34,44],[20,40]],name:'a dragon'},
 crown:{pts:[[20,62],[16,24],[34,42],[50,14],[66,42],[84,24],[80,62]],name:'a crown'},
 robot:{pts:[[36,12],[64,12],[64,30],[76,30],[76,64],[24,64],[24,30],[36,30]],name:'a robot'},
 lighthouse:{pts:[[40,70],[44,26],[40,22],[50,8],[60,22],[56,26],[60,70]],name:'a lighthouse'},
 longneck:{pts:[[14,64],[24,46],[46,42],[58,22],[64,10],[76,12],[70,22],[64,44],[82,52],[94,62],[72,60],[64,70],[30,70]],name:'a long-neck dinosaur'},
 rocket:{pts:[[50,6],[60,22],[60,50],[72,64],[58,60],[50,70],[42,60],[28,64],[40,50],[40,22]],name:'a rocket'},
 /* the Great Dog (Canis Major), from the real stars: θ, γ Muliphein, ι, α Sirius, β Mirzam, ζ Furud, ο2, δ Wezen, ε Adhara, η Aludra */
 greatdog:{sil:[[66,13],[60,7],[52,6],[46,0],[42,8],[38,14],[44,24],[40,34],[33,44],[27,50],[15,60],[13,63],[22,60],[30,56],[36,60],[42,68],[50,68],[48,60],[52,48],[58,36],[70,30],[86,24],[92,25],[91,30],[84,31],[88,62],[92,66],[86,66],[80,60],[76,34],[64,32],[62,24],[64,18]],pts:[[50.9,6.5],[39.6,18],[48.6,22.6],[61.2,21],[86.9,25.5],[90,64.2],[40.6,44],[34.3,52],[45.6,60.7],[16.4,61.8]],edges:[[0,1],[1,2],[2,0],[2,3],[3,4],[4,5],[3,6],[6,7],[7,8],[7,9]],big:3,name:'the Great Dog'}};
const LEGS=[['meadow','windmill',1],['snowy','owl',1],['reef','jelly',2],['ninja','dragon',2],['number','crown',5],['gadget','robot',5],['rescue','lighthouse',10],['dino','longneck','t'],['planet','rocket',4],['village','greatdog',1]];
const ISC={meadow:['#3a6a3a','#2a4a2a'],snowy:['#c8d6e6','#8a9ab0'],reef:['#c8b88a','#2a6a8a'],ninja:['#7a3a2a','#4a2a2a'],number:['#a89a6a','#7a6a4a'],gadget:['#6a7a8a','#3a4250'],rescue:['#a89a6a','#7a6a4a'],dino:['#4a6a3a','#2a4a2a'],planet:['#8a8e9a','#5a5e6a'],village:['#3a5a3a','#2a3a2a']};
let RN=null;
function svgImg(s){if(!/xmlns=/.test(s))s=s.replace('<svg','<svg xmlns="http://www.w3.org/2000/svg"');const i=new Image();i.src='data:image/svg+xml;charset=utf-8,'+encodeURIComponent(s);return i;}
const SX=x=>212+x*6,SY=y=>78+y*6;
function runUI(){if($('#grun'))return;const d=el('div','screen','<canvas id="grCv" width="1024" height="768"></canvas><button class="btn rnd white" id="grBack">◀</button><div class="pill" id="grPill"></div>');d.id='grun';
  const q=document.querySelector('#quiz');q.parentNode.insertBefore(d,q);const cv=$('#grCv');
  const pos=e=>{const r=cv.getBoundingClientRect();return [(e.clientX-r.left)*1024/r.width,(e.clientY-r.top)*768/r.height];};
  cv.addEventListener('pointerdown',e=>{initAudio();if(!RN)return;const p=pos(e);RN.ty=p[1];if(RN.ph==='stars')tapStar(p);});cv.addEventListener('pointermove',e=>{if(!RN)return;RN.ty=pos(e)[1];});
  tap('#grBack',()=>{sfx.boop();if(!RN)return;RN.over=true;RN=null;MUSIC.over=null;show('world');player.lock=false;say('You can fly the Glow Flight again from the village whenever you are ready.');});}
function glowFlight(){runUI();hush();player.lock=true;const B=state.buddy&&pupById(state.buddy);
  RN={i:-1,ph:'fly',t:0,sy:300,ty:300,rings:[],stars:Array.from({length:140},()=>[Math.random()*1024,Math.random()*560,Math.random()]),
    img:{fly:svgImg(GW.flySVG({glow:9})),seb:svgImg(sebSVG(true)),bud:B?svgImg(critterSVG(window.GLOOK.gp(B),{anim:false})):null},hill:0,last:performance.now(),over:false};
  show('grun');hush();MUSIC.over='gmoon';speak(`Hold on tight! Drag up and down to steer through the rings of fireflies. Over each island, tap the stars in order to draw a picture in the sky!`);nextLeg();requestAnimationFrame(frame);}
function nextLeg(){const R=RN;R.i++;if(R.i>=LEGS.length){R.ph='end';R.t=0;return;}R.ph='fly';R.t=0;R.rings=[];const last=R.i===LEGS.length-1;
  for(let k=0;k<(last?2:3);k++)R.rings.push({x:1150+k*360,y:180+Math.random()*260,hit:false});R.isl={x:1150+(last?2:3)*360+220};
  const L=LEGS[R.i],I=islandOf(L[0]);$('#grPill').textContent=last?'✨ Home to Pawprint Village':`✨ ${R.i+1} of 9: ${I?I.name:''}`;}
function startPic(){const R=RN,L=LEGS[R.i],P=PICS[L[1]];let step=L[2];if(step==='t'){const tb=(typeof tablesOn==='function'?tablesOn():[3]).filter(v=>v>=2&&v<=6);step=tb.length?tb[Math.floor(Math.random()*tb.length)]:3;}
  R.pic={P,step,done:P.pts.map(()=>false),next:0,fin:0};R.ph='stars';R.t=0;const lab=i=>(i+1)*step;
  const m=L[1]==='greatdog'?`Over Pawprint Village, the last picture! Tap the stars from 1 to ${P.pts.length}.`:`Over ${islandOf(L[0]).name}! Tap the stars in order: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;R.msg=m;speak(m);}
function tapStar(p){const R=RN,Q=R.pic;if(!Q||Q.fin)return;const P=Q.P;let hit=-1,hd=48;P.pts.forEach((q,i)=>{const d=Math.hypot(SX(q[0])-p[0],SY(q[1])-p[1]);if(d<hd){hd=d;hit=i;}});if(hit<0)return;
  if(hit!==Q.next){if(Q.done[hit])return;sfx.oops();const m=`Look for ${(Q.next+1)*Q.step}.`;R.msg=m;speak(m);return;}
  Q.done[hit]=true;Q.next++;GW.snd.note(hit);if(Q.next<P.pts.length){R.msg=`${hit*Q.step+Q.step}! Next: ${(Q.next+1)*Q.step}`;return;}
  Q.fin=R.t||.01;GW.snd.twinkle();sfx.fanfare();const L=LEGS[R.i];
  if(L[1]==='greatdog'){R.msg='The Great Dog! Its brightest star is Sirius, the Dog Star.';speak('The Great Dog! Its brightest star is Sirius, the Dog Star, the brightest star in the whole night sky.');
    setTimeout(()=>{if(RN===R){R.wink=R.t;GW.snd.blink();R.msg=`${F()}: "Did that tiny star just wink at us?"`;speak(`${F()} says: did that tiny star just wink at us?`);}},4200);setTimeout(()=>{if(RN===R)nextLeg();},8600);}
  else{R.msg=`${Cap(PICS[L[1]].name)} in the stars!`;speak(R.msg);setTimeout(()=>{if(RN===R)nextLeg();},2600);}}
function frame(now){const R=RN;if(!R||R.over)return;requestAnimationFrame(frame);if(cur!=='grun')return;const dt=Math.min(.05,(now-R.last)/1000);R.last=now;R.t+=dt;
  const g=$('#grCv').getContext('2d');
  if(R.ph==='fly'){R.sy+=(Math.max(120,Math.min(520,R.ty-40))-R.sy)*Math.min(1,dt*5);const sp=260*dt;
    R.rings.forEach(r=>{r.x-=sp;if(!r.hit&&Math.abs(r.x-200)<50&&Math.abs(r.y-(R.sy+40))<70){r.hit=true;GW.snd.blink();sfx.chime();}});R.isl.x-=sp;if(R.isl.x<620){R.isl.x=620;startPic();}}
  if(R.ph==='stars')R.sy+=(560-R.sy)*Math.min(1,dt*2);
  if(R.ph==='end'&&R.t>1.4&&!R.fin){R.fin=true;RN=null;MUSIC.over=null;X().flight=Date.now();save();fadeTo(()=>{show('world');enterArea('village',[0,15,PI]);setTimeout(()=>starParty(),900);},['🌙','The Star Party']);return;}
  /* sky */
  const sky=g.createLinearGradient(0,0,0,768);sky.addColorStop(0,'#070c28');sky.addColorStop(1,'#1f2a62');g.fillStyle=sky;g.fillRect(0,0,1024,768);
  R.stars.forEach(s=>{g.fillStyle=`rgba(255,255,255,${.3+.5*Math.abs(Math.sin(R.t*2+s[2]*9))})`;g.fillRect((s[0]-R.t*6*s[2]+1024*4)%1024,s[1],2,2);});
  g.fillStyle='#f6f0d0';g.beginPath();g.arc(900,100,46,0,PI*2);g.fill();g.fillStyle='#070c28';g.beginPath();g.arc(922,88,42,0,PI*2);g.fill();
  R.hill=(R.hill+(R.ph==='fly'?260*dt:0))%1024;g.fillStyle='#141c44';for(let k=-1;k<3;k++){const ox=k*512-R.hill*.5;g.beginPath();g.moveTo(ox,768);g.quadraticCurveTo(ox+256,590,ox+512,768);g.fill();}
  /* the island below, with glowing windows */
  if(R.isl&&LEGS[R.i]){const L=LEGS[R.i],c=ISC[L[0]]||ISC.meadow,x=R.isl.x;g.fillStyle=c[1];g.beginPath();g.ellipse(x+40,720,320,120,0,PI,0);g.fill();g.fillStyle=c[0];g.beginPath();g.ellipse(x+40,730,290,96,0,PI,0);g.fill();
    for(let k=0;k<7;k++){const wx=x-150+k*52,wy=650+(k%2)*18;g.fillStyle='#2a2a3a';g.fillRect(wx,wy-20,34,30);g.fillStyle='#ffd86a';g.fillRect(wx+8,wy-12,10,12);}
    g.font='50px Arial';g.textAlign='center';const I=islandOf(L[0]);g.fillText(L[0]==='village'?'🏡':(I?I.icon:''),x+40,742);}
  /* the star picture */
  if(R.ph==='stars'&&R.pic){const Q=R.pic,P=Q.P,E=P.edges||P.pts.map((q,i)=>[i,(i+1)%P.pts.length]),glow=Q.fin?.6+.4*Math.sin((R.t-Q.fin)*6):0;
    if(P.sil&&Q.fin){const k=Math.min(1,(R.t-Q.fin)*.6);g.fillStyle=`rgba(216,255,90,${.12*k})`;g.strokeStyle=`rgba(216,255,90,${.45*k})`;g.lineWidth=3;g.beginPath();P.sil.forEach((q,i)=>{const x=SX(q[0]),y=SY(q[1]);i?g.lineTo(x,y):g.moveTo(x,y);});g.closePath();g.fill();g.stroke();}
    g.lineCap='round';E.forEach(e=>{if(!Q.done[e[0]]||!Q.done[e[1]])return;const a=P.pts[e[0]],b=P.pts[e[1]];g.strokeStyle=Q.fin?`rgba(216,255,90,${.55+.45*glow})`:'#fff2a8';g.lineWidth=Q.fin?7:5;g.beginPath();g.moveTo(SX(a[0]),SY(a[1]));g.lineTo(SX(b[0]),SY(b[1]));g.stroke();});
    P.pts.forEach((q,i)=>{const x=SX(q[0]),y=SY(q[1]),nx=i===Q.next&&!Q.fin,r=(P.big===i?13:9)*(nx?1.25+.2*Math.sin(R.t*6):1);
      g.fillStyle=Q.done[i]?'rgba(216,255,90,.35)':'rgba(255,242,168,.25)';g.beginPath();g.arc(x,y,r*2.2,0,PI*2);g.fill();g.fillStyle=Q.done[i]?LIME:'#fff8d0';g.beginPath();g.arc(x,y,r,0,PI*2);g.fill();
      if(!Q.fin){g.font='bold 26px Arial';g.textAlign='left';g.lineWidth=5;g.strokeStyle='#070c28';g.strokeText(String((i+1)*Q.step),x+14,y-10);g.fillStyle='#ffffff';g.fillText(String((i+1)*Q.step),x+14,y-10);}});
    if(P.big!=null&&Q.fin){const s=P.pts[P.big],x=SX(s[0]),y=SY(s[1]);g.font='bold 24px Arial';g.textAlign='left';g.fillStyle='#fff6c2';g.fillText('Sirius',x+20,y+30);
      if(R.wink){const k=R.t-R.wink,a=Math.max(0,Math.sin(k*3))*(k<4?1:.5);g.fillStyle=`rgba(255,255,255,${a})`;g.beginPath();g.arc(x+18,y-12,3.4,0,PI*2);g.fill();g.fillStyle=`rgba(200,220,255,${a*.35})`;g.beginPath();g.arc(x+18,y-12,9,0,PI*2);g.fill();}}}
  /* firefly rings */
  R.rings.forEach(r=>{if(r.x<-80||r.x>1100)return;for(let k=0;k<12;k++){const a=k/12*PI*2+R.t,x=r.x+Math.cos(a)*36,y=r.y+Math.sin(a)*70;g.fillStyle=r.hit?'rgba(255,210,63,.4)':'rgba(216,255,90,.35)';g.beginPath();g.arc(x,y,9,0,PI*2);g.fill();g.fillStyle=r.hit?GOLD:LIME;g.beginPath();g.arc(x,y,4,0,PI*2);g.fill();}});
  /* Seb on a leaf, carried by the Glow, with the firefly leading */
  const sx=140,sy=R.sy+Math.sin(R.t*3)*6;for(let k=0;k<14;k++){const a=k/14*PI*2+R.t*1.5,x=sx+60+Math.cos(a)*90,y=sy+60+Math.sin(a)*34;g.fillStyle='rgba(216,255,90,.3)';g.beginPath();g.arc(x,y,8,0,PI*2);g.fill();g.fillStyle=LIME;g.beginPath();g.arc(x,y,3.2,0,PI*2);g.fill();}
  if(R.img.seb.complete)g.drawImage(R.img.seb,sx+20,sy-24,70,84);if(R.img.bud&&R.img.bud.complete)g.drawImage(R.img.bud,sx+66,sy+2,58,58);
  g.fillStyle='#4a9a3a';g.strokeStyle='#26232e';g.lineWidth=4;g.beginPath();g.ellipse(sx+64,sy+70,84,18,0,0,PI*2);g.fill();g.stroke();g.strokeStyle='#2f6a24';g.lineWidth=3;g.beginPath();g.moveTo(sx-10,sy+70);g.lineTo(sx+140,sy+70);g.stroke();
  if(R.img.fly.complete)g.drawImage(R.img.fly,sx+150,sy-40+Math.sin(R.t*5)*8,90,90);
  /* words */
  if(R.ph==='fly'&&R.t<2.5){g.fillStyle='#fff';g.font='bold 30px Arial';g.textAlign='center';g.fillText('Drag up and down to fly through the firefly rings!',512,740);}
  if(R.ph==='stars'&&R.msg){g.font='bold 28px Arial';g.textAlign='center';const w=Math.min(980,g.measureText(R.msg).width+60);g.fillStyle='rgba(255,255,255,.95)';g.strokeStyle='#26232e';g.lineWidth=4;g.beginPath();g.roundRect?g.roundRect(512-w/2,690,w,56,16):g.rect(512-w/2,690,w,56);g.fill();g.stroke();g.fillStyle='#26232e';g.fillText(R.msg,512,728);}}
/* ---------------- the Star Party ---------------- */
function starParty(){const T=X();if(T.done)return;if(!W.area||W.area.id!=='village'){fadeTo(()=>{enterArea('village',[0,15,PI]);setTimeout(starParty,900);},['🌙','The Star Party']);return;}
  player.lock=true;hush();MUSIC.over='glull';if(window.GWORLD)GWORLD.meteors(W.area,.5);const zu=window.BHQ&&state.bh&&state.bh.done?' Zuzu and her puppies have come too!':'';
  const seb='<svg viewBox="0 0 320 140" width="320"><rect width="320" height="140" rx="18" fill="#0b1236"/>'+[[[70,30],[50,30],[40,45],[55,62],[75,75],[70,95],[45,108]],[[140,30],[110,30],[110,68],[135,68],[110,68],[110,108],[140,108]],[[190,30],[190,108],[225,108],[240,90],[225,68],[190,68],[225,68],[238,50],[222,30],[190,30]]].map(L=>L.map(q=>`<circle cx="${q[0]+30}" cy="${q[1]}" r="9" fill="${LIME}" opacity=".3"/><circle cx="${q[0]+30}" cy="${q[1]}" r="4" fill="${LIME}"/>`).join('')).join('')+'</svg>';
  story([{art:big('🌙🏡✨'),t:`Back in Pawprint Village, everyone gathers on blankets for a Star Party: the pups, Granny Paws, the guides, all nine unicorns, and Muddle too.${zu}`},
    {art:big('🌠🌠'),t:'Look! Shooting stars streak across the sky. Everyone makes a wish.'},
    {art:seb,t:'Then the Glow flies up into the sky and flashes three letters: S... E... B!'},
    {art:mg(140)+big('⭐'),t:'Muddle has a present for Seb: a star he painted himself, and it glows in the dark! "It\'s my own light," he says, "and I\'m giving it away."'},
    {art:`<div class="fitsvg" style="width:140px">${grannySVG()}</div>`+(state.buddy&&pupById(state.buddy)?`<div class="fitsvg" style="width:150px">${critterSVG(Object.assign({},pupById(state.buddy),{dressAs:'gpjs'}),{anim:false})}</div>`:''),t:'Granny Paws gives everyone star pyjamas and a night cap. (You can dress any pup in them at the Pup Spa.) And there are glow-in-the-dark stars, a moon lamp and a little telescope waiting in your Den!'}],
    ()=>{T.done=Date.now();state.stars+=100;state.costumes=state.costumes||{};state.costumes.gpjs=1;state.certs=state.certs||{};const c=CERTS.find(q=>q.id==='glowhero');if(c&&!state.certs[c.id])state.certs[c.id]=Date.now();save();hud();
      if(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray! +100 ⭐','green',goodbye]]}));}else goodbye();});}
const GHOST='<svg viewBox="0 0 300 200" width="300"><rect width="300" height="200" rx="18" fill="#0b1236"/><rect x="0" y="150" width="300" height="50" fill="#2a2440"/>'+
  '<ellipse cx="110" cy="146" rx="46" ry="36" fill="#ff8a2a" stroke="#26232e" stroke-width="4"/><path d="M110 112 q4 -12 12 -14" stroke="#3a7a3a" stroke-width="6" fill="none"/><path d="M92 138 l8 -8 l8 8 Z M114 138 l8 -8 l8 8 Z" fill="#ffd86a"/><path d="M94 156 q16 10 32 0" stroke="#ffd86a" stroke-width="5" fill="none"/><circle cx="110" cy="146" r="60" fill="#ffb347" opacity=".18"/>'+
  '<g transform="translate(186 92)"><path d="M0 50 Q0 0 28 0 Q56 0 56 50 l-8 -7 l-8 7 l-8 -7 l-8 7 l-8 -7 l-8 7 l-8 -7 Z" fill="#f4f6ff" stroke="#26232e" stroke-width="3"/><ellipse cx="6" cy="14" rx="7" ry="13" fill="#f4f6ff" stroke="#26232e" stroke-width="3" transform="rotate(-25 6 14)"/><ellipse cx="50" cy="14" rx="7" ry="13" fill="#f4f6ff" stroke="#26232e" stroke-width="3" transform="rotate(25 50 14)"/><circle cx="20" cy="22" r="5" fill="#26232e"/><circle cx="36" cy="22" r="5" fill="#26232e"/><circle cx="21" cy="20" r="1.6" fill="#fff"/><circle cx="37" cy="20" r="1.6" fill="#fff"/><ellipse cx="28" cy="33" rx="4" ry="3" fill="#26232e"/><path d="M-10 20 l-6 -3 M-10 30 l-7 0 M66 20 l6 -3 M66 30 l7 0" stroke="#c8d0ff" stroke-width="2.5"/></g>'+
  '<text x="236" y="70" font-size="18" font-weight="900" fill="#fff" font-family="Arial">boo?</text></svg>';
function goodbye(){const T=X(),left=GW.all().length-GW.nFound();
  story([{art:fs(170),t:`${F()} flashes goodnight. "Whenever you play Night Glow, I'll be right here with the Glow!"`+(left?` And there are still ${left} Night Glow pups hiding on the islands!`:'')},
    {art:window.HW?`<div style="display:flex;align-items:flex-end;justify-content:center;gap:6px"><div style="font-size:84px;line-height:1">🎃</div><div class="fitsvg" style="width:150px">${HW.palSVG({bp:0,scared:1})}</div></div>`:GHOST,
     t:'That night, a pumpkin glows on a windowsill... and from behind it comes a tiny voice: "boo?" It\'s a little puppy in a bedsheet costume, much too big for him, shivering. "It\'s s-so dark..."'+(window.HW?' Halloween is here!':' Coming soon: Halloween!')}],
    ()=>{player.lock=false;T.bye=Date.now();save();MUSIC.over=null;if(window.HW&&HW.fromGlow){setTimeout(()=>{try{HW.fromGlow();}catch(e){console.warn('hw from glow',e);}},700);return;}say(`Goodnight, Seb! ${F()} will stay in the village whenever Night Glow is on.`);});}
/* ---------------- the village checks where the story is up to ---------------- */
function village(){const T=GW.G0();if(!T||!T.intro)return false;
  if(T.call&&!T.nest){say(`${F()} says: "The answer came from Bluebell Wood on Meadow Island! Let's go!"`);return true;}
  if(T.nest&&!T.flight){card({art:big('✨🍃✨'),h:'The Glow Flight',p:'The Glow is waiting to fly you round all nine islands. Ready?',btns:[['✨ Let\'s fly!','green',()=>glowFlight()],['Later','white']]});return true;}
  if(T.flight&&!T.done){starParty();return true;}
  return false;}
/* ---------------- badges and the certificate ---------------- */
const gs=()=>(state&&state.sx&&state.sx.glow)||{};
MERITS.push(
 {id:'gfly',icon:'✨',name:'Firefly Friend',how:'Meet the little firefly in Night Glow, and give it a name.',ok:()=>!!gs().fly},
 {id:'gmeteor',icon:'🌠',name:'Star Catcher',how:'Catch the star dust in the meteor shower on Moon Base in Night Glow.',ok:()=>!!(state.acts||{}).meteor},
 {id:'glantern',icon:'🏮',name:'Lantern Lighter',how:'Light every lantern at the Lantern Festival in Night Glow.',ok:()=>!!(state.acts||{}).lanterns},
 {id:'gswim',icon:'💙',name:'Glow Swimmer',how:'Collect the glowing sparks in the Glowing Bay in Night Glow.',ok:()=>!!(state.acts||{}).glowswim},
 {id:'gsong',icon:'🎵',name:'Glow Song',how:'Learn all nine flashes of the Glow Song from the unicorns.',ok:()=>Object.keys(gs().fl||{}).length>=9},
 {id:'gall',icon:'🌙',name:'Every Light Home',how:'Find all 119 Night Glow pups.',ok:()=>!!gs().found&&GW.nFound()>=GW.all().length});
CERTS.push({id:'glowhero',icon:'🌙',title:'Night Glow Hero',get why(){return `for freeing the Glow with ${gs().fly?gs().fly.name+' the firefly':'the little firefly'}, and painting pictures in the stars over all nine islands`;},ok:()=>!!gs().done});
const css=document.createElement('style');css.textContent=`#grun{background:#070c28}#grun canvas{position:absolute;left:0;top:0;width:100%;height:100%;touch-action:none}#grun .btn.rnd{position:absolute;left:14px;top:10px;z-index:20}#grun .pill{position:absolute;right:14px;top:14px;z-index:20}
#gjars{z-index:60}#gjCard{max-width:900px;width:92%}#gjRow{display:grid;grid-template-columns:repeat(9,1fr);gap:6px;margin:14px 0}.gjar{background:none;border:0;padding:0;cursor:pointer}
.gjar .ff{transition:transform 1.2s,opacity 1.2s,fill .3s}.gjar.open .ff{fill:${LIME};transform:translateY(-60px);opacity:0}.gjar.open .lid{transform:translate(20px,-14px) rotate(30deg);transition:transform .4s}#gjMsg{font-size:26px;font-weight:800;min-height:34px}`;document.head.appendChild(css);
window.GSTORY={afterFind,onFlash,village,glowFlight,starParty,nestScene,goodbye,_rn:()=>RN};
})();
