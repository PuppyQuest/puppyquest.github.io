/* Card makeover (25 Nov 2026, "Pup Looks and Card Makeover", claude/pup-looks-design.md sections 3 and 4).
   - A sign of each world on every Puppy Quest 3 card: a pattern on the frame, a scene behind the pup, a world
     badge, and on the big card a detailed edge.
   - Special finishes: Silver Shine, Holo, Gold, Diamond. Rolled when a card is first shown after the Shiny
     Delivery (so packs reveal them), kept in state.cards.fin; Best Friend cards are Gold unless Diamond.
     The frame shows the finish; the corner shows the rarity. Looks only: no numbers change.
   - A one-off Shiny Delivery gives the cards Seb already has their finishes.
   cards.js calls CLOOK.mini / CLOOK.big / CLOOK.packSay / CLOOK.onBinder; Puppy Quest 2 cards are left as they are. */
(function(){
const K=INK,enc=s=>"url('data:image/svg+xml,"+encodeURIComponent(s).replace(/'/g,'%27')+"')";
const svgT=(w,h,b)=>`<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}" viewBox="0 0 ${w} ${h}">${b}</svg>`;
const flake=(x,y,r,c,o)=>`<g stroke="${c}" stroke-width="${r/3.2}" stroke-linecap="round" opacity="${o}"><path d="M${x-r} ${y}h${2*r}M${x-r/2} ${y-r*.87}l${r} ${r*1.74}M${x+r/2} ${y-r*.87}l${-r} ${r*1.74}"/></g>`;
const cog=(x,y,r,c,o)=>{let p='';for(let i=0;i<8;i++){const a=i*Math.PI/4;p+=`<rect x="${x-r*.18}" y="${y-r*1.28}" width="${r*.36}" height="${r*.5}" fill="${c}" transform="rotate(${a*57.3} ${x} ${y})"/>`;}return `<g opacity="${o}">${p}<circle cx="${x}" cy="${y}" r="${r}" fill="${c}"/><circle cx="${x}" cy="${y}" r="${r*.38}" fill="none" stroke="#fff" stroke-width="${r*.12}" opacity=".0"/></g>`;};
const st4=(x,y,r,c,o)=>`<path d="M${x} ${y-r}Q${x} ${y} ${x+r} ${y}Q${x} ${y} ${x} ${y+r}Q${x} ${y} ${x-r} ${y}Q${x} ${y} ${x} ${y-r}Z" fill="${c}" opacity="${o}"/>`;
const W='#ffffff';
/* repeating pattern over the card colour */
const PAT={
 meadow:svgT(60,60,`<g fill="${W}" opacity=".35"><circle cx="15" cy="15" r="3"/>${[0,1,2,3,4].map(i=>{const a=i*1.2566;return `<circle cx="${15+Math.cos(a)*5}" cy="${15+Math.sin(a)*5}" r="3"/>`;}).join('')}</g><ellipse cx="45" cy="44" rx="7" ry="3.5" fill="${W}" opacity=".3" transform="rotate(-30 45 44)"/>`),
 snowy:svgT(56,56,flake(14,14,7,W,.45)+flake(42,40,5,W,.35)),
 reef:svgT(60,60,`<g fill="none" stroke="${W}" opacity=".4" stroke-width="2"><circle cx="14" cy="16" r="6"/><circle cx="24" cy="8" r="3"/><circle cx="44" cy="42" r="4"/></g><path d="M0 54 q7.5 -6 15 0 t15 0 t15 0 t15 0" fill="none" stroke="${W}" stroke-width="2" opacity=".3"/>`),
 ninja:svgT(40,24,`<g fill="none" stroke="${W}" stroke-width="2" opacity=".32"><path d="M0 24 a20 20 0 0 1 40 0M6 24 a14 14 0 0 1 28 0M12 24 a8 8 0 0 1 16 0"/><path d="M-20 12 a20 20 0 0 1 40 0M20 12 a20 20 0 0 1 40 0"/></g>`),
 number:svgT(64,64,`<g fill="${W}" opacity=".35" font-family="Arial" font-weight="900"><text x="6" y="22" font-size="18">3</text><text x="38" y="30" font-size="14">×</text><text x="20" y="54" font-size="16">7</text><text x="46" y="58" font-size="13">+</text></g>`),
 gadget:svgT(60,60,cog(16,16,7,W,.3)+`<circle cx="44" cy="44" r="2.5" fill="${W}" opacity=".4"/><circle cx="50" cy="14" r="2.5" fill="${W}" opacity=".4"/>`),
 rescue:svgT(60,60,`<circle cx="16" cy="16" r="8" fill="none" stroke="${W}" stroke-width="4" stroke-dasharray="6.3 6.3" opacity=".42"/><path d="M38 38 l14 14 M52 38 l-14 14" stroke="${W}" stroke-width="4" opacity=".0"/><path d="M40 48 h12 M46 42 v12" stroke="${W}" stroke-width="4" stroke-linecap="round" opacity=".38"/>`),
 dino:svgT(64,64,`<g fill="${W}" opacity=".33"><ellipse cx="16" cy="20" rx="6" ry="7"/><ellipse cx="9" cy="10" rx="2.5" ry="4" transform="rotate(-25 9 10)"/><ellipse cx="16" cy="7" rx="2.5" ry="4"/><ellipse cx="23" cy="10" rx="2.5" ry="4" transform="rotate(25 23 10)"/></g><path d="M38 50 h16" stroke="${W}" stroke-width="5" stroke-linecap="round" opacity=".3"/><g fill="${W}" opacity=".3"><circle cx="37" cy="47" r="3.5"/><circle cx="37" cy="53" r="3.5"/><circle cx="55" cy="47" r="3.5"/><circle cx="55" cy="53" r="3.5"/></g>`),
 planet:svgT(64,64,st4(14,14,6,W,.55)+`<circle cx="44" cy="42" r="6" fill="${W}" opacity=".35"/><ellipse cx="44" cy="42" rx="11" ry="3" fill="none" stroke="${W}" stroke-width="1.8" opacity=".4" transform="rotate(-20 44 42)"/><circle cx="52" cy="12" r="1.5" fill="${W}" opacity=".6"/><circle cx="10" cy="50" r="1.5" fill="${W}" opacity=".6"/>`),
 alien:svgT(60,60,`<g fill="${W}" opacity=".35"><circle cx="15" cy="15" r="7"/><circle cx="42" cy="40" r="4"/><circle cx="50" cy="12" r="2.5"/></g><path d="M15 8 v-5 M11 9 l-3 -4 M19 9 l3 -4" stroke="${W}" stroke-width="2" stroke-linecap="round" opacity=".35"/>`),
 science:svgT(64,64,`<g fill="none" stroke="${W}" stroke-width="1.8" opacity=".38"><ellipse cx="18" cy="18" rx="11" ry="4"/><ellipse cx="18" cy="18" rx="11" ry="4" transform="rotate(60 18 18)"/><ellipse cx="18" cy="18" rx="11" ry="4" transform="rotate(-60 18 18)"/><path d="M42 38 h8 M44 38 v8 l-6 10 h16 l-6 -10 v-8"/></g><circle cx="18" cy="18" r="2.5" fill="${W}" opacity=".5"/>`)};
/* the picture window scene behind the pup */
const sky=(id,a,b)=>`<defs><linearGradient id="${id}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="200" height="190" fill="url(#${id})"/>`;
let sid=0;
const SCN={
 meadow:i=>sky(i,'#bfe6ff','#e8f7ff')+`<circle cx="165" cy="34" r="16" fill="#ffe066" opacity=".9"/><path d="M0 128 Q50 98 110 122 T200 112 V190 H0Z" fill="#9edc7e"/><path d="M0 150 Q70 128 130 148 T200 140 V190 H0Z" fill="#7cc85a"/>`+[[24,142],[60,150],[150,150],[178,138]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="3.5" fill="#fff"/><circle cx="${q[0]}" cy="${q[1]}" r="1.5" fill="#ffd23f"/>`).join(''),
 snowy:i=>sky(i,'#cfe8fb','#f2f8ff')+`<path d="M-10 120 L40 60 L70 92 L105 48 L150 104 L175 80 L215 120 V190 H-10Z" fill="#dbe7f3"/><path d="M40 60 L52 74 L44 72 L36 78 Z M105 48 L118 64 L108 61 L96 66 Z" fill="#fff"/><path d="M0 140 Q60 124 120 138 T200 132 V190 H0Z" fill="#ffffff"/>`+[[22,30],[70,22],[130,30],[180,50],[40,90],[160,96],[96,80]].map((q,k)=>`<circle cx="${q[0]}" cy="${q[1]}" r="${k%2?2:2.8}" fill="#fff"/>`).join('')+`<path d="M182 140 l10 -30 l10 30 Z" fill="#3f8a5a"/>`,
 reef:i=>sky(i,'#6fd0e8','#2a86c8')+`<path d="M30 0 L60 0 L90 190 L50 190Z M120 0 L140 0 L170 190 L140 190Z" fill="#fff" opacity=".1"/><path d="M0 160 Q100 146 200 160 V190 H0Z" fill="#f3d99a"/>`+
   `<path d="M18 160 v-24 m0 10 l-10 -10 m10 4 l9 -12" stroke="#ff7f9a" stroke-width="6" stroke-linecap="round" fill="none"/><path d="M182 160 q-6 -16 2 -28 q8 -12 0 -26" stroke="#3fae5a" stroke-width="5" stroke-linecap="round" fill="none"/>`+[[40,50,5],[52,30,3],[160,70,4],[150,40,6]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="${q[2]}" fill="none" stroke="#fff" stroke-width="2" opacity=".7"/>`).join(''),
 ninja:i=>sky(i,'#ffb88a','#ffe0b8')+`<circle cx="150" cy="56" r="22" fill="#fff3d0" opacity=".9"/><path d="M0 120 L0 80 h30 v-10 h26 v50 Z M150 120 v-56 h22 v10 h28 v46Z" fill="#c9805a"/><path d="M-5 190 V130 Q100 112 205 130 V190Z" fill="#b8664a"/>`+
   `<g fill="#8a3a2e"><path d="M88 78 h24 l-4 -8 h-16 Z"/><rect x="94" y="78" width="12" height="10"/><path d="M84 92 h32 l-5 -8 h-22 Z"/><rect x="92" y="92" width="16" height="22"/></g>`,
 number:i=>sky(i,'#fff3d6','#f6e3b8')+`<rect x="0" y="140" width="200" height="50" fill="#e8d4a8"/><path d="M0 140 H200 M0 160 H200 M40 140 L30 190 M100 140 V190 M160 140 L170 190" stroke="#d6bd8a" stroke-width="2"/>`+
   [[30,60,'3'],[170,52,'8'],[100,30,'×']].map(q=>`<rect x="${q[0]-18}" y="${q[1]-22}" width="36" height="40" rx="5" fill="#fff" stroke="#c9a040" stroke-width="4"/><text x="${q[0]}" y="${q[1]+10}" font-size="28" font-weight="900" text-anchor="middle" fill="#5b8def" font-family="Arial">${q[2]}</text>`).join(''),
 gadget:i=>sky(i,'#2f6fb8','#245a96')+`<g stroke="#fff" stroke-width="1" opacity=".22">${[...Array(10)].map((_,k)=>`<path d="M${k*20} 0V190M0 ${k*20}H200"/>`).join('')}</g>`+cog(26,40,14,'#9ec8ff',.5)+cog(176,130,18,'#9ec8ff',.45)+cog(150,40,9,'#9ec8ff',.5)+`<path d="M10 170 H190" stroke="#9ec8ff" stroke-width="3" stroke-dasharray="8 6" opacity=".5"/>`,
 rescue:i=>sky(i,'#bfe6ff','#e6f6ff')+`<path d="M0 150 Q100 140 200 150 V190 H0Z" fill="#3d8fe0"/><path d="M0 158 q12 -5 25 0 t25 0 t25 0 t25 0 t25 0 t25 0 t25 0 t25 0" fill="none" stroke="#fff" stroke-width="2.5" opacity=".7"/>`+
   `<rect x="164" y="62" width="16" height="88" fill="#fff" stroke="${K}" stroke-width="2"/><rect x="164" y="80" width="16" height="12" fill="#e8423a"/><rect x="164" y="108" width="16" height="12" fill="#e8423a"/><path d="M160 62 h24 l-12 -12 Z" fill="#e8423a"/><circle cx="172" cy="56" r="4" fill="#ffe066"/><path d="M14 140 h40 l-6 10 h-28 Z" fill="#ff8a3c"/><rect x="26" y="128" width="16" height="12" fill="#fff"/>`,
 dino:i=>sky(i,'#ffd9a0','#fff1d6')+`<path d="M110 120 L140 54 h14 L184 120 Z" fill="#8a6a5a"/><path d="M140 54 q8 -10 14 0" fill="#ff7a45"/><circle cx="148" cy="38" r="9" fill="#c9b8a8" opacity=".7"/><circle cx="160" cy="26" r="7" fill="#c9b8a8" opacity=".5"/>`+
   `<path d="M0 140 Q100 124 200 140 V190 H0Z" fill="#8fbf5a"/><g fill="#3f8a3a">${[[14,150,-1],[190,146,1]].map(q=>`<path d="M${q[0]} ${q[1]} q${q[2]*-6} -40 ${q[2]*14} -60 q${q[2]*-4} 30 ${q[2]*-6} 60Z"/><path d="M${q[0]} ${q[1]} q${q[2]*20} -30 ${q[2]*34} -34 q${q[2]*-14} 14 ${q[2]*-30} 34Z"/>`).join('')}</g>`,
 planet:i=>sky(i,'#1d2050','#3a3f86')+[[20,24],[60,14],[110,30],[176,20],[150,70],[30,90],[88,64]].map((q,k)=>st4(q[0],q[1],k%2?3:4.5,'#fff',.9)).join('')+
   `<circle cx="160" cy="56" r="18" fill="#ff9a5a"/><ellipse cx="160" cy="56" rx="32" ry="7" fill="none" stroke="#ffe066" stroke-width="3.5" transform="rotate(-18 160 56)"/><path d="M0 160 Q100 140 200 160 V190 H0Z" fill="#c9cdd8"/><circle cx="40" cy="168" r="7" fill="#aab0be"/><circle cx="150" cy="172" r="5" fill="#aab0be"/>`,
 alien:i=>sky(i,'#b58cff','#ffb3e0')+`<path d="M0 140 Q30 110 60 140 Q90 116 120 140 Q150 112 200 138 V190 H0Z" fill="#9be86a"/><path d="M150 140 l8 -34 l8 34Z M168 140 l6 -22 l6 22Z" fill="#7ff6ff" stroke="#fff" stroke-width="2"/><circle cx="40" cy="40" r="14" fill="#ffe066" opacity=".8"/><circle cx="66" cy="28" r="6" fill="#fff" opacity=".7"/>`,
 science:i=>sky(i,'#2e4a3e','#36584a')+`<g fill="#fff" opacity=".75" font-family="Arial" font-weight="700"><text x="12" y="34" font-size="16">E=mc²</text><text x="120" y="30" font-size="14">H₂O</text><text x="140" y="70" font-size="14">a²+b²</text></g>`+
   `<rect x="0" y="150" width="200" height="40" fill="#c99a6a"/><path d="M14 150 v-14 l-6 -12 h16 l-6 12" fill="#9bff8a" stroke="#fff" stroke-width="2"/><rect x="176" y="126" width="10" height="24" rx="4" fill="#ff9ecb" stroke="#fff" stroke-width="2"/>`};

/* 25 Nov: each season registers its card look in window.SEALOOK by world prefix ('x:' Christmas Snow, 'g:' Night Glow, 'h:' Halloween) */
const SEA=w=>window.SEALOOK&&SEALOOK[String(w).slice(0,2)];
const scene=w=>{const SL=SEA(w);if(SL){const i=w.slice(2),b=SCN[i]?SCN[i]('ks'+(++sid)):SCN.snowy('ks'+(++sid));return `<svg class="scn" viewBox="0 0 200 190" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg">${b}${SL.over(i)}</svg>`;}return `<svg class="scn" viewBox="0 0 200 190" preserveAspectRatio="xMidYMax slice" xmlns="http://www.w3.org/2000/svg">${SCN[w]('ks'+(++sid))}</svg>`;};
const ICON={meadow:'🌼',snowy:'🏔️',reef:'🐠',ninja:'🥷',number:'🔢',gadget:'🔧',rescue:'🚒',dino:'🦖',planet:'🪐',alien:'👽',science:'🔬'};
/* ---------------- Puppy Quest 2 worlds: its six lands, plus the levels that move the pups somewhere new ---------------- */
Object.assign(PAT,{
 school:svgT(64,64,`<g fill="${W}" opacity=".38" font-family="Arial" font-weight="900"><text x="6" y="22" font-size="17">A</text><text x="38" y="52" font-size="15">b</text></g><g transform="translate(46 14) rotate(35)" opacity=".38"><rect x="-3" y="-11" width="6" height="18" fill="${W}"/><path d="M-3 7 L0 13 L3 7 Z" fill="${W}"/></g>`),
 beach:svgT(60,60,`<circle cx="15" cy="15" r="6" fill="${W}" opacity=".4"/><g opacity=".4" stroke="${W}" stroke-width="2" fill="none"><path d="M15 5 v-3 M15 25 v3 M5 15 h-3 M25 15 h3"/><path d="M36 48 q4 -12 12 0 Z M42 48 v-8"/></g>`),
 farm:svgT(60,60,`<g fill="${W}" opacity=".38"><circle cx="15" cy="15" r="2.5"/>${[0,1,2,3,4].map(i=>{const a=i*1.2566;return `<circle cx="${15+Math.cos(a)*4.5}" cy="${15+Math.sin(a)*4.5}" r="2.6"/>`;}).join('')}</g><path d="M44 54 V34 M44 40 l-5 -5 M44 44 l5 -5 M44 36 l5 -5" stroke="${W}" stroke-width="2" opacity=".38" fill="none"/>`),
 jungle:svgT(64,64,`<g opacity=".36"><ellipse cx="18" cy="18" rx="12" ry="6" fill="${W}" transform="rotate(-35 18 18)"/><ellipse cx="46" cy="46" rx="10" ry="5" fill="${W}" transform="rotate(30 46 46)"/></g>`),
 ski:svgT(60,60,`<g stroke="${W}" stroke-width="3" stroke-linecap="round" opacity=".42"><path d="M8 26 L26 8 M10 8 L28 26"/></g>`+flake(44,42,6,W,.42)),
 star:svgT(60,60,st4(15,15,7,W,.55)+`<path d="M44 34 a9 9 0 1 0 8 12 a7 7 0 1 1 -8 -12 Z" fill="${W}" opacity=".45"/>`),
 lava:svgT(56,56,`<path d="M14 26 q-8 -8 0 -18 q2 8 6 6 q4 6 -6 12 Z" fill="${W}" opacity=".38"/><path d="M40 50 q-6 -6 0 -14 q2 6 5 5 q3 5 -5 9 Z" fill="${W}" opacity=".3"/>`),
 micro:svgT(64,64,`<g fill="none" stroke="${W}" stroke-width="1.8" opacity=".4"><ellipse cx="18" cy="18" rx="11" ry="4"/><ellipse cx="18" cy="18" rx="11" ry="4" transform="rotate(60 18 18)"/><ellipse cx="18" cy="18" rx="11" ry="4" transform="rotate(-60 18 18)"/><circle cx="46" cy="46" r="7"/><circle cx="44" cy="44" r="2"/></g>`),
 disco:svgT(60,60,`<g fill="${W}" opacity=".42"><circle cx="12" cy="22" r="4"/><path d="M15 22 V6 l8 3 v4 l-8 -3"/></g>`+st4(44,42,7,W,.5)),
 rainbow:svgT(60,60,`<g fill="none" stroke-width="3" opacity=".55"><path d="M8 28 a14 14 0 0 1 28 0" stroke="#fff"/><path d="M12 28 a10 10 0 0 1 20 0" stroke="#fff3a0"/></g>`+st4(46,46,5,W,.5))});
Object.assign(SCN,{
 school:i=>sky(i,'#bfe6ff','#e8f7ff')+`<rect x="0" y="140" width="200" height="50" fill="#c9c2b2"/><rect x="40" y="70" width="120" height="70" fill="#d9734a" stroke="${K}" stroke-width="2"/><path d="M34 72 L100 38 L166 72 Z" fill="#8a4a3a"/><rect x="90" y="100" width="20" height="40" fill="#5b8def"/>`+[50,70,130,150].map(x=>`<rect x="${x-6}" y="84" width="14" height="14" fill="#fff6d0" stroke="${K}" stroke-width="1.5"/>`).join('')+`<circle cx="100" cy="58" r="8" fill="#fff" stroke="${K}" stroke-width="1.5"/><path d="M100 58 v-5 M100 58 h4" stroke="${K}" stroke-width="1.5"/>`+[0,1,2].map(k=>`<rect x="${20+k*14}" y="${158-k*0}" width="12" height="12" fill="none" stroke="#fff" stroke-width="2"/>`).join(''),
 beach:i=>sky(i,'#9fdcff','#e6f7ff')+`<circle cx="164" cy="34" r="16" fill="#ffe066"/><rect x="0" y="118" width="200" height="22" fill="#3d8fe0"/><path d="M0 120 q10 -6 20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0 t20 0" fill="none" stroke="#fff" stroke-width="3"/><rect x="0" y="138" width="200" height="52" fill="#f3d99a"/>`+[['#e8423a',16],['#5b8def',44],['#ffd23f',150],['#3fae5a',178]].map(q=>`<rect x="${q[1]-10}" y="120" width="20" height="22" fill="${q[0]}" stroke="${K}" stroke-width="1.5"/><path d="M${q[1]-12} 120 L${q[1]} 110 L${q[1]+12} 120 Z" fill="#fff" stroke="${K}" stroke-width="1.5"/>`).join(''),
 farm:i=>sky(i,'#bfe6ff','#eaf7ff')+`<path d="M0 132 Q60 112 120 128 T200 120 V190 H0Z" fill="#b9e08a"/><rect x="118" y="70" width="60" height="58" fill="#d9363e" stroke="${K}" stroke-width="2"/><path d="M112 72 L148 42 L184 72 Z" fill="#8a2a2a" stroke="${K}" stroke-width="2"/><path d="M136 128 v-28 h24 v28 M136 100 l24 28 M160 100 l-24 28" fill="none" stroke="#fff" stroke-width="3"/>`+
   `<path d="M0 150 H110 M10 142 v16 M40 142 v16 M70 142 v16 M100 142 v16" stroke="#a8743a" stroke-width="4"/><ellipse cx="30" cy="172" rx="16" ry="10" fill="#f2d27a" stroke="${K}" stroke-width="1.5"/>`,
 jungle:i=>sky(i,'#bfeccf','#7fd9a0')+`<rect x="90" y="40" width="22" height="120" fill="#bfe8ff" opacity=".8"/><path d="M0 150 Q100 136 200 150 V190 H0Z" fill="#4a9a4a"/>`+[[0,40,-1],[200,30,1],[0,120,-1],[200,110,1]].map(q=>`<ellipse cx="${q[0]}" cy="${q[1]}" rx="46" ry="18" fill="#2f7a3a" transform="rotate(${q[2]*-20} ${q[0]} ${q[1]})"/>`).join('')+`<path d="M40 0 q8 40 -4 80 M160 0 q-8 30 6 70" fill="none" stroke="#3f8a3a" stroke-width="4"/>`,
 ski:i=>sky(i,'#9fd2ff','#e6f4ff')+`<path d="M-10 120 L50 50 L90 96 L130 40 L210 120 V190 H-10Z" fill="#eaf2fa"/><path d="M50 50 L62 64 L50 62 L40 70 Z M130 40 L144 58 L130 54 L118 62 Z" fill="#fff"/><path d="M0 30 L200 80" stroke="#3a3640" stroke-width="1.5"/><rect x="96" y="44" width="10" height="8" fill="#e8423a"/>`+
   `<path d="M0 140 Q60 126 120 138 T200 132 V190 H0Z" fill="#fff"/><rect x="140" y="104" width="44" height="34" fill="#a8743a" stroke="${K}" stroke-width="1.5"/><path d="M134 106 L162 86 L190 106 Z" fill="#fff" stroke="${K}" stroke-width="1.5"/>`,
 star:i=>sky(i,'#3d3878','#7a6ad0')+[[20,24],[60,14],[110,30],[176,20],[150,70],[30,90]].map((q,k)=>st4(q[0],q[1],k%2?3:4.5,'#fff',.9)).join('')+`<path d="M20 150 A80 80 0 0 1 180 150" fill="none" stroke="#ff8fb3" stroke-width="5" opacity=".7"/><path d="M28 150 A72 72 0 0 1 172 150" fill="none" stroke="#fff27a" stroke-width="5" opacity=".7"/><path d="M36 150 A64 64 0 0 1 164 150" fill="none" stroke="#8fe39a" stroke-width="5" opacity=".7"/><path d="M0 160 Q100 138 200 160 V190 H0Z" fill="#5a4a9a"/>`,
 lava:i=>sky(i,'#3a1f24','#6a2a24')+`<path d="M0 60 Q40 40 80 60 T160 50 T200 60 V0 H0Z" fill="#2a1418"/><path d="M0 160 Q100 140 200 160 V190 H0Z" fill="#4a2a2a"/><path d="M0 172 Q50 162 100 172 T200 168" fill="none" stroke="#ff8a3c" stroke-width="7"/><path d="M0 172 Q50 162 100 172 T200 168" fill="none" stroke="#ffe066" stroke-width="2"/>`+[[30,90],[170,80],[100,40]].map(q=>`<path d="M${q[0]-6} ${q[1]+14} L${q[0]} ${q[1]} L${q[0]+6} ${q[1]+14} Z" fill="#7ff6ff" opacity=".8"/>`).join(''),
 micro:i=>sky(i,'#1f5a6a','#2f8a8a')+[[30,40,14],[160,60,18],[100,150,12],[170,150,9],[40,140,10]].map(q=>`<circle cx="${q[0]}" cy="${q[1]}" r="${q[2]}" fill="#9be8ff" opacity=".25" stroke="#fff" stroke-width="1.5"/><circle cx="${q[0]}" cy="${q[1]}" r="${q[2]*.3}" fill="#ff9ecb" opacity=".6"/>`).join(''),
 disco:i=>sky(i,'#2a1a4a','#5a2a7a')+`<path d="M60 0 L20 140 M140 0 L180 140 M100 0 L100 140" stroke="#fff27a" stroke-width="10" opacity=".15"/><circle cx="100" cy="26" r="16" fill="#c9d2e3" stroke="#fff" stroke-width="2"/>`+[...Array(10)].map((_,k)=>`<rect x="${(k%5)*40}" y="${150+Math.floor(k/5)*20}" width="40" height="20" fill="${['#ff4f6d','#ffd23f','#5cb8ff','#8fe39a','#b58cff'][(k+Math.floor(k/5))%5]}" opacity=".85"/>`).join(''),
 rainbow:i=>sky(i,'#bfe6ff','#f2fbff')+['#ff8fb3','#ffc46b','#fff27a','#8fe39a','#7fc8f0','#b58cff'].map((c,k)=>`<path d="M${10+k*8} 150 A${90-k*8} ${90-k*8} 0 0 1 ${190-k*8} 150" fill="none" stroke="${c}" stroke-width="8"/>`).join('')+`<ellipse cx="20" cy="150" rx="26" ry="12" fill="#fff"/><ellipse cx="180" cy="150" rx="26" ry="12" fill="#fff"/><path d="M0 162 Q100 150 200 162 V190 H0Z" fill="#9edc7e"/>`});
Object.assign(ICON,{school:'🏫',beach:'🏖️',farm:'🚜',jungle:'🌴',ski:'⛷️',star:'🌟',lava:'🌋',micro:'⚛️',disco:'🪩',rainbow:'🌈'});
const EDGE2={school:'number',beach:'reef',farm:'meadow',jungle:'meadow',ski:'snowy',star:'planet',lava:'dino',micro:'science',disco:'planet',rainbow:'planet'};
function world2(c){if(c.lv===0)return 'rainbow';const lv={5:'planet',6:'lava',7:'micro',10:'disco'}[c.lv];if(lv)return lv;const l=c.src&&c.src.land;return PAT[l]&&['school','beach','farm','jungle','ski','star'].indexOf(l)>=0?l:'star';}

const PATU={},patURL=w=>PATU[w]||(PATU[w]=enc(SEA(w)?SEA(w).pat():PAT[w]));
function worldOf(c){if(c&&c.xmas&&c.xisl)return 'x:'+c.xisl;if(c&&c.glow&&c.gisl)return 'g:'+c.gisl;if(c&&c.hw&&c.hisl)return 'h:'+c.hisl;if(c&&c.sb&&c.bisl)return 'b:'+c.bisl;if(c&&c.sp&&c.pisl)return 'p:'+c.pisl;if(c&&c.game===2)return world2(c);if(!c||c.game!==3)return null;if(c.set==='3:sci')return 'science';const S=CARDS.setById&&CARDS.setById(c.set),w=S&&S.isl;return w&&PAT[w]?w:null;}

/* ---------------- the detailed edge on the big card (400 by 564 inside the border) ---------------- */
function around(step,f){let s='';for(let x=24;x<=378;x+=step)s+=f(x,6,'t')+f(x,558,'b');for(let y=26;y<=540;y+=step)s+=f(6,y,'l')+f(394,y,'r');return s;}
const CORN=[[12,12],[388,12],[12,552],[388,552]],corners=f=>CORN.map((q,i)=>f(q[0],q[1],i)).join('');
const ol=w=>`stroke="${K}" stroke-width="${w||2}" stroke-linejoin="round"`;
const rimPath=`M6 6 H394 V558 H6 Z`;
function daisy(x,y,r){let s='';for(let i=0;i<6;i++){const a=i*1.047;s+=`<circle cx="${(x+Math.cos(a)*r*.6).toFixed(1)}" cy="${(y+Math.sin(a)*r*.6).toFixed(1)}" r="${r*.45}" fill="#fff" ${ol(1.4)}/>`;}return s+`<circle cx="${x}" cy="${y}" r="${r*.38}" fill="#ffd23f" ${ol(1.2)}/>`;}
function bone(x,y,a){return `<g transform="translate(${x} ${y}) rotate(${a})"><path d="M-11 0 H11" stroke="${K}" stroke-width="7" stroke-linecap="round"/><path d="M-11 0 H11" stroke="#f2ead2" stroke-width="4" stroke-linecap="round"/>`+[-1,1].map(g=>`<circle cx="${g*12}" cy="-3" r="3.6" fill="#f2ead2" ${ol(1.4)}/><circle cx="${g*12}" cy="3" r="3.6" fill="#f2ead2" ${ol(1.4)}/>`).join('')+'</g>';}
function atom(x,y,r){return `<g fill="none" stroke="#fff3c0" stroke-width="1.8">${[0,60,-60].map(a=>`<ellipse cx="${x}" cy="${y}" rx="${r}" ry="${r*.38}" transform="rotate(${a} ${x} ${y})"/>`).join('')}</g><circle cx="${x}" cy="${y}" r="${r*.22}" fill="#fff3c0"/>`;}
const EDGE={
 meadow:()=>`<path d="${rimPath}" fill="none" stroke="#2f7a3a" stroke-width="2.5"/>`+around(32,(x,y,sd)=>{const a=sd==='t'||sd==='b'?(x/32%2?30:-30):(y/32%2?60:120);return `<ellipse cx="${x}" cy="${y}" rx="6" ry="3" fill="#8fe39a" stroke="#2f7a3a" stroke-width="1.2" transform="rotate(${a} ${x} ${y})"/>`;})+corners((x,y)=>daisy(x,y,11)),
 snowy:()=>{let d='M0 0 H400 V9';for(let x=400;x>0;x-=20)d+=` Q${x-10} ${16+(x/20%2)*3} ${x-20} 9`;let s=`<path d="${d} Z" fill="#ffffff" stroke="#b8d6ee" stroke-width="1.5"/>`;
   for(let x=22;x<390;x+=26)s+=`<path d="M${x-3} 12 L${x} ${18+(x*7%9)} L${x+3} 12 Z" fill="#e6f4ff" stroke="#9ec8e8" stroke-width="1"/>`;
   s+=around(30,(x,y,sd)=>sd==='t'?'':`<circle cx="${x}" cy="${y}" r="${(x+y)%3?1.6:2.4}" fill="#fff" opacity=".9"/>`);
   return s+corners((x,y,i)=>i<2?'':`<g stroke="#fff" stroke-width="2.6" stroke-linecap="round"><path d="M${x-9} ${y}h18M${x-4.5} ${y-7.8}l9 15.6M${x+4.5} ${y-7.8}l-9 15.6"/></g>`);},
 reef:()=>{let d='M0 556';for(let x=0;x<400;x+=20)d+=` q5 -6 10 0 t10 0`;return `<path d="${d}" fill="none" stroke="#fff" stroke-width="2.5" opacity=".85"/>`+around(34,(x,y,sd)=>sd==='b'?'':`<circle cx="${x+(y%3)}" cy="${y}" r="${3+(x+y)%3}" fill="none" stroke="#fff" stroke-width="1.6" opacity=".8"/>`)+
   corners((x,y,i)=>i<2?`<path d="M${x} ${y-9}L${x+2.6} ${y-2.6}L${x+9} ${y-2}L${x+4} ${y+2.4}L${x+5.6} ${y+9}L${x} ${y+5}L${x-5.6} ${y+9}L${x-4} ${y+2.4}L${x-9} ${y-2}L${x-2.6} ${y-2.6}Z" fill="#ff8a3c" ${ol(1.4)}/>`
     :`<path d="M${x-10} ${y+4} Q${x-10} ${y-10} ${x} ${y-11} Q${x+10} ${y-10} ${x+10} ${y+4} Z" fill="#ffc2d1" ${ol(1.4)}/><path d="M${x} ${y+4}V${y-9}M${x-5} ${y+4}l-2 -11M${x+5} ${y+4}l2 -11" stroke="${K}" stroke-width="1"/>`);},
 ninja:()=>{let s='';for(const x of[1,389]){s+=`<rect x="${x}" y="0" width="10" height="564" fill="#6fbf4a" stroke="#2f7a3a" stroke-width="1.2"/>`;for(let y=40;y<564;y+=46)s+=`<path d="M${x} ${y}h10" stroke="#2f7a3a" stroke-width="2"/>`;}
   s+=`<rect x="11" y="1" width="378" height="10" fill="#d9362e"/><rect x="11" y="553" width="378" height="10" fill="#d9362e"/>`;for(let x=30;x<380;x+=36)s+=`<circle cx="${x}" cy="6" r="2" fill="#ffd23f"/><circle cx="${x}" cy="558" r="2" fill="#ffd23f"/>`;
   return s+corners((x,y)=>`<rect x="${x-9}" y="${y-9}" width="18" height="18" rx="3" fill="#ffd23f" ${ol(1.4)}/><circle cx="${x}" cy="${y}" r="3.5" fill="#d9362e"/>`);},
 number:()=>{let s='';for(let x=20;x<=380;x+=10){const L=x%50===0?8:4;s+=`<path d="M${x} 0v${L}M${x} 564v${-L}" stroke="${K}" stroke-width="1.4" opacity=".7"/>`;}for(let y=20;y<=544;y+=10){const L=y%50===0?8:4;s+=`<path d="M0 ${y}h${L}M400 ${y}h${-L}" stroke="${K}" stroke-width="1.4" opacity=".7"/>`;}
   return s+corners((x,y,i)=>`<rect x="${x-9}" y="${y-9}" width="18" height="18" rx="3" fill="#fff" ${ol(1.4)}/><text x="${x}" y="${y+5}" font-size="13" font-weight="900" text-anchor="middle" fill="#5b8def" font-family="Arial">${['1','2','3','4'][i]}</text>`);},
 gadget:()=>around(26,(x,y)=>`<circle cx="${x}" cy="${y}" r="2.8" fill="#dfe4ea" stroke="${K}" stroke-width=".8"/><circle cx="${x-.8}" cy="${y-.8}" r="1" fill="#fff"/>`)+corners((x,y)=>cog(x,y,10,'#c9d2e3',1)+`<circle cx="${x}" cy="${y}" r="3.5" fill="#6b7480"/>`),
 rescue:()=>`<path d="${rimPath}" fill="none" stroke="#e6c38a" stroke-width="7"/><path d="${rimPath}" fill="none" stroke="#a8743a" stroke-width="7" stroke-dasharray="3 5" opacity=".75"/>`+
   corners((x,y)=>`<circle cx="${x}" cy="${y}" r="9" fill="none" stroke="${K}" stroke-width="8"/><circle cx="${x}" cy="${y}" r="9" fill="none" stroke="#e8423a" stroke-width="5.5"/><circle cx="${x}" cy="${y}" r="9" fill="none" stroke="#fff" stroke-width="5.5" stroke-dasharray="7 7.1"/>`),
 dino:()=>around(22,(x,y)=>`<ellipse cx="${x}" cy="${y}" rx="${5+(x*y)%3}" ry="${3.5+(x+y)%2}" fill="${['#b8b0a0','#9a9284','#c9c0ae'][(x+y)%3]}" stroke="${K}" stroke-width=".8"/>`)+corners((x,y,i)=>bone(x,y,i%2?-40:40)),
 planet:()=>around(28,(x,y)=>{const r=(x+y)%3?2.4:3.6,c=(x*y)%5?'#fff':'#ffe066';return `<path d="M${x} ${y-r}Q${x} ${y} ${x+r} ${y}Q${x} ${y} ${x} ${y+r}Q${x} ${y} ${x-r} ${y}Q${x} ${y} ${x} ${y-r}Z" fill="${c}"/>`;})+
   `<circle cx="386" cy="14" r="9" fill="#ff9a5a" ${ol(1.4)}/><ellipse cx="386" cy="14" rx="16" ry="4" fill="none" stroke="#ffe066" stroke-width="2.2" transform="rotate(-18 386 14)"/><circle cx="14" cy="550" r="9" fill="#e4e6ee" ${ol(1.4)}/><circle cx="11" cy="547" r="2.4" fill="#c9cdd8"/>`,
 alien:()=>{let s='';for(let x=16;x<390;x+=30){const h=6+(x*7%9);s+=`<path d="M${x-7} 8 Q${x-7} ${10+h} ${x} ${12+h} Q${x+7} ${10+h} ${x+7} 8 Z" fill="#9be86a" stroke="#5aa84a" stroke-width="1.2"/>`;}
   return `<rect x="0" y="0" width="400" height="10" fill="#9be86a"/>`+s+around(30,(x,y,sd)=>sd==='t'?'':`<circle cx="${x}" cy="${y}" r="3" fill="${['#7ff6ff','#fff27a','#ff9ecb'][(x+y)%3]}"/>`);},
 science:()=>`<path d="${rimPath}" fill="none" stroke="#c9962e" stroke-width="4"/><path d="${rimPath}" fill="none" stroke="#ffe680" stroke-width="1.2"/>`+around(60,(x,y)=>`<circle cx="${x}" cy="${y}" r="2.6" fill="#ffe680" stroke="#8a6a14" stroke-width="1"/>`)+corners((x,y)=>atom(x,y,10))};
const edgeSVG=(w,fin)=>(w=SEA(w)?SEA(w).edge:EDGE[w]?w:EDGE2[w],EDGE[w])?`<svg class="edge" viewBox="0 0 400 564" preserveAspectRatio="none"${fin?' opacity=".45"':''}>${EDGE[w]()}</svg>`:'';
function gemsSVG(w,h,inset,r,n){let s='';const cols=['#ffffff','#9be8ff','#ffd6f0','#ffffff','#c9b8ff'];let k=0;
  const put=(x,y)=>{const c=cols[k++%cols.length];s+=`<path d="M${x} ${y-r} L${x+r*.8} ${y} L${x} ${y+r} L${x-r*.8} ${y} Z" fill="${c}" stroke="#7a8aa0" stroke-width="1.2"/><path d="M${x-r*.3} ${y-r*.3} l${r*.25} ${-r*.25}" stroke="#fff" stroke-width="1.4"/>`;};
  for(let i=0;i<=n;i++){put(inset+(w-2*inset)*i/n,inset);put(inset+(w-2*inset)*i/n,h-inset);}const m=Math.round(n*h/w);for(let i=1;i<m;i++){put(inset,inset+(h-2*inset)*i/m);put(w-inset,inset+(h-2*inset)*i/m);}
  return `<svg class="gemr" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none">${s}`+[[.2,.08],[.85,.3],[.12,.7],[.9,.9]].map((q,i)=>`<path class="twk" style="animation-delay:${i*.4}s" d="M${q[0]*w} ${q[1]*h-r*1.6}Q${q[0]*w} ${q[1]*h} ${q[0]*w+r*1.6} ${q[1]*h}Q${q[0]*w} ${q[1]*h} ${q[0]*w} ${q[1]*h+r*1.6}Q${q[0]*w} ${q[1]*h} ${q[0]*w-r*1.6} ${q[1]*h}Q${q[0]*w} ${q[1]*h} ${q[0]*w} ${q[1]*h-r*1.6}Z" fill="#fff"/>`).join('')+'</svg>';}

/* ---------------- finishes ---------------- */
const FN={s:'Silver Shine',h:'Holo',g:'Gold',d:'Diamond',f:'Frost',w:'Glow',c:'Candy',e:'Seashell',p:'Petal'};
const BLURB={p:'Petal cards are a Spring Blossom special, with a soft pink and green frame and blossom petals drifting across.',e:'Seashell cards are a Summer Beach Party special, with a pearly frame that shimmers like the inside of a shell.',c:'Candy cards are a Halloween special, with orange and gold stripes that swirl like a sweet wrapper.',w:'Glow cards are a Night Glow special, with a frame that glows in the dark.',f:'Frost cards are a Christmas special, with a frosty frame and snow falling across the card.',d:'Diamond cards are the rarest of all, with gems all the way round the edge.',g:'Gold cards have a shining gold frame. Best Friend pups get a Gold card too!',h:'Holo cards have a rainbow that shimmers behind the pup.',s:'Silver Shine cards have a silver frame that shines.'};
const METAL={p:'linear-gradient(135deg,#ffd0e0,#ffffff 18%,#d8f4c8 36%,#fff0f6 54%,#ffc0d8 72%,#e6f8d8 88%,#ffffff)',e:'linear-gradient(135deg,#ffe6f0,#ffffff 18%,#d6f2ff 36%,#fff6d6 54%,#ffd6e8 72%,#e0f8ff 88%,#ffffff)',c:'linear-gradient(135deg,#ff7a1a,#ffd23f 20%,#ff9a3a 40%,#fff0b0 62%,#e8601a 84%,#ffc21a)',s:'linear-gradient(135deg,#8d97a3,#f4f7fa 22%,#a9b2bd 45%,#eef2f6 70%,#7d8794)',g:'linear-gradient(135deg,#9a6a14,#ffe680 22%,#c9962e 45%,#fff1b0 70%,#a8741a)',
 f:'linear-gradient(135deg,#9fc4e4,#ffffff 20%,#cfe6fb 40%,#f4fbff 62%,#a8cbe8 84%,#e6f4ff)',w:'linear-gradient(135deg,#1f2a5a,#5cffb0 20%,#2a3a7a 40%,#c8ff4a 62%,#1f2a5a 84%,#5cf0ff)',d:'linear-gradient(135deg,#c9d8ea,#ffffff 22%,#dfe9f5 45%,#ffffff 70%,#b8c8de)',h:'linear-gradient(135deg,#e9ecf8,#ffd9f2 22%,#d6f4ff 44%,#f3e6ff 66%,#e2f7e6 85%,#ffe9d6)'};
const BORDER={p:'#c86a90',e:'#c87a9a',c:'#c8501a',w:'#1f5a4a',f:'#5a86ad',s:'#5f6874',g:'#7a5410',d:'#6a7a92',h:'#7a5cd6'};
const CS=()=>CARDS.CS(),F=()=>{const c=CS();if(!c.fin)c.fin={};return c.fin;},delivered=g=>!!(g===2?CS().shiny2:CS().shiny),special=x=>!!x&&x!=='n';
let dirty=0;function later(){if(dirty)return;dirty=1;setTimeout(()=>{dirty=0;save();},60);}
function roll(){const r=Math.random();return r<1/60?'d':r<1/60+1/25?'g':r<1/60+1/25+1/12?'h':r<1/60+1/25+1/12+1/8?'s':'n';}
const isIsl=id=>{if(id&&id[0]==='2')return true;const S=CARDS.setById(id);return !!(S&&S.isl&&S.isl!=='alien');};
function rollCard(c){const f=F();if(f[c.cid])return f[c.cid];let x=roll();if(c.xmas&&!special(x)&&Math.random()<1/19)x='f';if(c.glow&&!special(x)&&Math.random()<1/19)x='w';if(c.hw&&!special(x)&&Math.random()<1/19)x='c';if(c.sb&&!special(x)&&Math.random()<1/19)x='e';if(c.sp&&!special(x)&&Math.random()<1/19)x='p';
  if(!special(x)&&isIsl(c.set)){const S=CARDS.setById(c.set),L=S?S.cards:[];if(!L.some(q=>special(f[q.cid]))&&L.every(q=>q.cid===c.cid||f[q.cid]))x='s';}
  f[c.cid]=x;later();return x;}
const isBest=c=>c.game===3&&!c.uni&&typeof bestFriend==='function'&&!!bestFriend(c.base);
function finOf(c,best){if(!c||(c.game!==3&&c.game!==2)||!delivered(c.game))return null;let x=rollCard(c);if(best&&x!=='d')x='g';return special(x)?x:null;}
function frameBG(c,r,best,fin,w,size){let base;if(fin)base=METAL[fin];else if(best)base='#e0a82e';else if(r==='sparkly'||r==='unicorn')base='conic-gradient(#ff8fb3,#ffc46b,#fff27a,#8fe39a,#7fc8f0,#b58cff,#ff8fb3)';else if(r==='legend')base='#7f6bff';else base=c.col;
  return w?`${patURL(w)} 0 0/${size}px ${size}px repeat,${base}`:base;}
const HOLO='<div class="holo"></div>';
function mini(c,r,best){const w=worldOf(c),fin=finOf(c,best);if(!w&&!fin)return null;
  return {cls:(w?' wd':'')+(fin?' fin-'+fin:''),style:`background:${frameBG(c,r,best,fin,w,56)}`+(fin?`;border-color:${BORDER[fin]}`:''),
    scene:(w?scene(w):'')+(fin==='h'?HOLO:''),extra:(w?`<div class="wemb">${ICON[w]||ICON[w.slice(2)]||'🎄'}</div>`+(SEA(w)?`<div class="wemb xh">${SEA(w).badge}</div>`:''):'')+(fin?'<div class="finsh"></div>':'')+(fin==='d'?gemsSVG(119,169,3,3.4,5):'')};}
function big(c,r,best){const w=worldOf(c),fin=finOf(c,best);if(!w&&!fin)return null;
  return {cls:(w?' wd':'')+(fin?' fin-'+fin:''),style:`background:${frameBG(c,r,best,fin,w,84)}`+(fin?`;border-color:${BORDER[fin]}`:''),
    scene:(w?scene(w)+`<div class="wemb big">${ICON[w]||ICON[w.slice(2)]||'🎄'}</div>`+(SEA(w)?`<div class="wemb big xh">${SEA(w).badge}</div>`:''):'')+(fin==='h'?HOLO:'')+(fin?'<div class="glare"></div>':''),
    extra:(w?edgeSVG(w,fin):'')+(fin?'<div class="finsh"></div>':'')+(fin==='d'?gemsSVG(400,564,6,6,12):''),fname:fin?FN[fin]:''};}
function packSay(cards,msg){const sp=cards.map(c=>[c,finOf(c,isBest(c))]).filter(q=>q[1]).sort((a,b)=>'dgfwcephs'.indexOf(a[1])-'dgfwcephs'.indexOf(b[1]));if(!sp.length)return msg;
  setTimeout(()=>{try{sfx.chime();}catch(e){}},1400);const q=sp[0];return msg+` And ${q[0].name} is a ${FN[q[1]]} card!`;}
function counts(){const n={s:0,h:0,g:0,d:0,f:0,w:0,c:0,e:0,p:0,all:0};CARDS.earnedIds().forEach(id=>{if(!delivered(id[0]==='2'?2:3))return;const c=CARDS.cardById(id),x=c&&finOf(c,isBest(c));if(x){n[x]++;n.all++;}});return n;}

/* ---------------- the Shiny Delivery ---------------- */
const parcel=`<svg viewBox="0 0 200 170" xmlns="http://www.w3.org/2000/svg"><path d="M30 70 L100 40 L170 70 L170 150 L100 168 L30 150 Z" fill="#c98a4f" ${ol(4)}/><path d="M30 70 L100 92 L170 70 M100 92 V168" fill="none" ${ol(4)}/><path d="M64 56 L134 82 V112" fill="none" stroke="#e8423a" stroke-width="10"/><path d="M100 92 L100 168" stroke="#e8423a" stroke-width="10"/>`+
  `<path d="M100 40 q-30 -26 -36 -6 q14 10 36 6 q30 -26 36 -6 q-14 10 -36 6" fill="#ff7fb8" ${ol(3)}/><path d="M18 30 l4 10 l10 4 l-10 4 l-4 10 l-4 -10 l-10 -4 l10 -4 Z M182 24 l3 8 l8 3 l-8 3 l-3 8 l-3 -8 l-8 -3 l8 -3 Z M176 120 l3 7 l7 3 l-7 3 l-3 7 l-3 -7 l-7 -3 l7 -3 Z" fill="#ffe066" ${ol(1.6)}/><text x="134" y="140" font-size="16" font-weight="900" fill="#fff3d0" font-family="Arial" transform="rotate(-14 134 140)">SHINY!</text></svg>`;
let busy=false;
function pending(){const C=CS(),e=CARDS.earnedIds(),a=!C.shiny?e.filter(id=>id[0]==='3'):[],b=!C.shiny2&&C.pq2?e.filter(id=>id[0]==='2'):[];return {a,b};}
function onBinder(){const C=CS();if(busy||(C.shiny&&(C.shiny2||!C.pq2)))return;const P=pending();if(!C.shiny&&!P.a.length)C.shiny=Date.now();if(!C.shiny2&&C.pq2&&!P.b.length)C.shiny2=Date.now();if(!P.a.length&&!P.b.length){save();return;}
  busy=true;let tries=0;const go=()=>{const Q=pending();if(cur!=='binder'||(!Q.a.length&&!Q.b.length)){busy=false;return;}if($('#cele').classList.contains('on')||$('#cardv').classList.contains('on')||(Q.b.length&&!window.PQ2ART)){if(++tries<60)setTimeout(go,800);else busy=false;return;}
    const only2=!Q.a.length;card({cls:'cert',art:`<div class="fitsvg" style="width:170px">${parcel}</div>`,h:only2?'📦 A Shiny Delivery for your Puppy Quest 2 cards!':'📦 A Shiny Delivery!',p:'A parcel has arrived from the Pup Card Printers! Some of your cards are now printed in special shiny finishes. Open it to find out which!',
      btns:[['📦 Open it!','green',()=>{busy=false;deliver();}]]});};setTimeout(go,1200);}
function deliver(){const C=CS(),P=pending(),ids=P.a.concat(P.b),f=F(),bySet={};if(!ids.length)return;
  ids.forEach(id=>{const c=CARDS.cardById(id);if(!c)return;if(!f[id])f[id]=roll();(bySet[c.set]=bySet[c.set]||[]).push(id);});
  for(const k in bySet){if(isIsl(k)&&!bySet[k].some(id=>special(f[id])))f[bySet[k][Math.floor(Math.random()*bySet[k].length)]]='s';}
  if(P.a.length)C.shiny=Date.now();if(P.b.length)C.shiny2=Date.now();save();try{sfx.jingle();confetti(60);}catch(e){}if(cur==='binder')CARDS.render();
  const by={d:[],g:[],h:[],s:[],f:[],w:[],c:[],e:[],p:[]};ids.forEach(id=>{const c=CARDS.cardById(id),x=c&&finOf(c,isBest(c));if(x)by[x].push(c);});
  const seq=['d','g','f','w','c','e','p','h','s'].filter(k=>by[k].length),n=seq.reduce((a,k)=>a+by[k].length,0);
  const step=i=>{if(i>=seq.length){card({art:`<div class="fitsvg" style="width:150px">${parcel}</div>`,h:`${n} shiny cards!`,p:'Open a shiny card and tilt it to make it shine. The frame shows how the card was printed, and the corner shows how rare the pup is. New cards from packs can be shiny too!'});return;}
    const k=seq[i],L=by[k];card({art:`<div class="shrow">${L.slice(0,5).map(c=>CARDS.miniHTML(c,{force:1})).join('')}</div>`,h:`${L.length} ${FN[k]} card${L.length>1?'s':''}!`,p:BLURB[k]+(L.length>5?` Here are 5 of them.`:''),btns:[['Next ▶','green',()=>step(i+1)]]});};
  setTimeout(()=>step(0),700);}

/* ---------------- tilt the iPad (grown-ups switch) ---------------- */
function askMotion(cb){const D=window.DeviceOrientationEvent;if(D&&typeof D.requestPermission==='function'){D.requestPermission().then(r=>cb(r==='granted')).catch(()=>cb(false));}else cb(!!D);}
/* 25 Nov evening: the iPad does not pass tilting to a game shown inside another page (the claude.ai frame; WebKit bugs 152299
   and 301294), so the switch now checks that tilt readings really arrive and says why when they do not. Dragging a finger
   across a shiny card always makes it shine (cards.js tilt()). */
const IN_FRAME=(()=>{try{return window.self!==window.top;}catch(e){return true;}})();
let oriT=0,raf=0;window.addEventListener('deviceorientation',e=>{if(e.beta!=null||e.gamma!=null)oriT=Date.now();if(!state||!state.set||!state.set.tiltCards||raf)return;raf=requestAnimationFrame(()=>{raf=0;const v=$('#cardv'),t=$('#cvTilt');if(!v||!t||!v.classList.contains('on'))return;
  const cl=(a,b)=>Math.max(-1,Math.min(1,a/b)),x=cl(e.gamma||0,30)*.5,y=cl((e.beta||45)-45,30)*.5;t.style.transform=`perspective(900px) rotateY(${x*18}deg) rotateX(${-y*14}deg)`;t.style.setProperty('--sx',(x*100+50)+'%');t.style.setProperty('--sy',(y*100+50)+'%');});});
const _os=openSettings;openSettings=function(){_os.apply(this,arguments);const a=$('#pq2Cards');if(!a)return;let row=a.closest('.srow'),note=row&&row.nextElementSibling;if(!note)return;
  const on=!!state.set.tiltCards,r=el('div','srow',`✨ Shiny cards: tilt the iPad<div class="opts"><button class="opt${on?'':' on'}" id="tcOff">Off</button><button class="opt${on?' on':''}" id="tcOn">On</button></div>`);r.style.border='0';
  const DRAG='Shiny cards always shine when you drag a finger across them in the big card view.',
    WEB=' Tilting only works when Puppy Quest is opened from its own website (puppyquest.github.io), not inside claude.ai, because the iPad does not pass tilting to games shown inside another page.',
    t=el('div','snote',on?'Tilting is on: open a shiny card in the Card Binder and tilt the iPad. '+DRAG:DRAG+' Switch this on to make them shine when you tilt the iPad too. The iPad will ask to allow motion.'+(IN_FRAME?WEB:''));note.after(r);r.after(t);
  const set=v=>{state.set.tiltCards=v;save();const f=$('#tcOff'),o=$('#tcOn');if(f)f.classList.toggle('on',!v);if(o)o.classList.toggle('on',v);};
  const fail=why=>{set(false);t.textContent=why+' '+DRAG;sfx.oops&&sfx.oops();};
  tap('#tcOff',()=>{set(false);t.textContent=DRAG+' Switch this on to make them shine when you tilt the iPad too.';});
  tap('#tcOn',()=>{const t0=Date.now();t.textContent='Asking the iPad for motion...';askMotion(ok=>{
    if(!ok)return fail(IN_FRAME?'The iPad would not allow motion here.'+WEB:'The iPad did not allow motion. If you tapped Don\'t Allow, close Puppy Quest completely, open it again and try once more.');
    set(true);t.textContent='Checking the iPad sends tilting...';
    setTimeout(()=>{if(oriT>=t0){t.textContent='Tilting is on: open a shiny card in the Card Binder and tilt the iPad. '+DRAG;sfx.chime&&sfx.chime();}
      else fail(IN_FRAME?'The iPad allowed motion but sends no tilting to games inside claude.ai.'+WEB:'This device did not send any tilting.');},1800);});});};

/* ---------------- styles ---------------- */
const css=`.mc.wd .mart{position:relative}
.mc .mart svg.scn,.tc .art svg.scn{position:absolute;left:0;top:0;width:100%;height:100%;margin:0;z-index:0}
.mc.wd .mart>svg.pup,.mc[class*="fin-"] .mart>svg.pup,.tc .art>svg.pup{position:relative;z-index:1}
.mc[class*="fin-"] .mart{position:relative}
.wemb{position:absolute;z-index:3;left:3px;top:3px;width:22px;height:22px;border-radius:50%;background:#fffaf0;border:2px solid #5b4636;display:flex;align-items:center;justify-content:center;font-size:12px;line-height:1;pointer-events:none}
.mc em{z-index:5}
.wemb.big{left:6px;top:6px;width:38px;height:38px;font-size:21px;border-width:3px}
.tc .edge{position:absolute;left:0;top:0;width:100%;height:100%;z-index:2;pointer-events:none}
.finsh{position:absolute;top:0;right:0;bottom:0;left:0;z-index:4;pointer-events:none;border-radius:inherit;background:linear-gradient(105deg,rgba(255,255,255,0) 38%,rgba(255,255,255,.7) 50%,rgba(255,255,255,0) 62%);background-size:260% 100%;animation:finsw 4.5s ease-in-out infinite}
.tc .finsh{z-index:0}
.mc.fin-d .finsh,.tc.fin-d .finsh{background-image:linear-gradient(105deg,rgba(255,255,255,0) 38%,rgba(255,255,255,.95) 50%,rgba(255,255,255,0) 62%)}
@keyframes finsw{0%{background-position:130% 0}60%,100%{background-position:-30% 0}}
.holo{position:absolute;top:0;right:0;bottom:0;left:0;z-index:0;pointer-events:none;background:repeating-linear-gradient(115deg,#ff8fb3 0%,#ffe27a 7%,#8fe39a 14%,#7fc8f0 21%,#b58cff 28%,#ff8fb3 35%);background-size:300% 300%;opacity:.42;animation:holo 6s linear infinite}
@keyframes holo{from{background-position:0% 50%}to{background-position:100% 50%}}
.tc .glare{position:absolute;top:0;right:0;bottom:0;left:0;z-index:2;pointer-events:none;background:radial-gradient(circle at var(--sx,30%) var(--sy,25%),rgba(255,255,255,.55),rgba(255,255,255,0) 45%)}
.gemr{position:absolute;left:0;top:0;width:100%;height:100%;z-index:3;pointer-events:none}
.tc .gemr{z-index:3}
.fc .mc[class*="fin-"]{animation:finpop 1.1s ease-in-out 1.2s 2}
@keyframes finpop{50%{box-shadow:0 0 0 4px #fff3a0,0 0 26px 10px #ffe066}}
.shrow{display:flex;gap:2px;justify-content:center;align-items:flex-end;flex-wrap:wrap;max-width:720px}
.shrow .mc{transform:scale(.92)}
.tc .ft .fintag{color:#7a5cd6}`;
const stl=document.createElement('style');stl.textContent=css;document.head.appendChild(stl);

/* ---------------- badges ---------------- */
MERITS.push({id:'shiny10',icon:'✨',name:'Shiny Collector',how:'Have 10 shiny cards (Silver Shine, Holo, Gold or Diamond).',ok:()=>!!state&&!!state.cards&&counts().all>=10},
  {id:'diamond1',icon:'💎',name:'Diamond Paws',how:'Get a Diamond card.',ok:()=>!!state&&!!state.cards&&counts().d>=1});

window.CLOOK={mini,big,packSay,onBinder,deliver,finOf,worldOf,counts,roll,FN,EDGE,PAT};
})();
