/* Pup looks (25 Nov 2026, "Pup Looks and Card Makeover", claude/pup-looks-design.md).
   The 2D pictures (cards, Pup House, found cards, start screen) get:
   - soft shading and a ground shadow on every critter;
   - a coat type for every breed (smooth, short, wire, curly, corded, silky, feathered, double) and ticked speckles;
   - a land outfit for every island pup (hats, body wear, neck things, boots, back things, props, hoods),
     space furs for Planet Hop and the alien puppies, and a signature look for each science pup.
   Hooks: formLook (outfit data; full costumes also reach the 3D pups), critterSVG (marks 2D drawing),
   form2D (draws the layers at each stage). A Spa costume always wins over the land outfit. */
(function(){
const K=INK;let D2=0;
function hrng(id){let h=7;for(const ch of String(id))h=(h*31+ch.charCodeAt(0))%233280;return seed(h);}
const lum=h=>{const n=parseInt((h||'#888888').slice(1),16);return((n>>16)*.3+(n>>8&255)*.59+(n&255)*.11)/255;};
const st=(c,w,o)=>`fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${o}"`;
const ol=(w)=>`stroke="${K}" stroke-width="${w||2.6}" stroke-linejoin="round" stroke-linecap="round"`;
function inEll(R,cx,cy,rx,ry,n,f){const out=[];for(let i=0;i<n;i++){const a=R()*6.283,r=Math.sqrt(R());out.push([cx+Math.cos(a)*rx*r,cy+Math.sin(a)*ry*r]);}return out.map(f).join('');}

/* ---------------- coats by breed ---------------- */
const CT={smooth:'British Bulldog,Weimaraner,Boston Terrier,Boxer,Thai Ridgeback,Bull Terrier,Dalmatian,Great Dane,Dachshund,Whippet,Pug,Italian Greyhound,Basenji,Vizsla,French Bulldog,Toy Fox Terrier,Bullmastiff,Plott Hound,Dogue de Bordeaux,Xoloitzcuintli,Neapolitan Mastiff,Rhodesian Ridgeback,Pharaoh Hound,Cirneco dell\'Etna,Redbone Coonhound,Azawakh,Miniature Pinscher,Chinese Crested,Doberman,Labrador,Labrador Retriever',
 short:'Basset Hound,Black and Tan Coonhound,Bracco Italiano,Shar Pei,Beagle,Jack Russell Terrier,Chihuahua,Australian Cattle Dog,German Shorthaired Pointer,Bloodhound,Belgian Malinois,Rottweiler,Lancashire Heeler,Smooth Collie,Catahoula Leopard Dog,Treeing Walker Coonhound,Mixed breed,Australian Kelpie,Bluetick Coonhound,American Foxhound,Polish Hound,Chesapeake Bay Retriever',
 wire:'Border Terrier,Miniature Schnauzer,West Highland Terrier,Otterhound,Wire Fox Terrier,Brussels Griffon,Cairn Terrier,Affenpinscher,Airedale Terrier,Spinone Italiano,Scottish Deerhound,Norfolk Terrier,Scottish Terrier,Welsh Terrier,Irish Wolfhound,Schnauzer',
 curly:'Labradoodle,Goldendoodle,Spanish Water Dog,Lagotto Romagnolo,Cavapoo,Irish Water Spaniel,Curly-coated Retriever,Barbet,American Water Spaniel,Croatian Sheepdog,Bichon Frise,Standard Poodle,Bedlington Terrier,Kerry Blue Terrier,Portuguese Water Dog,Mudi,Bolognese,Pumi,Löwchen,Poodle',
 corded:'Puli,Bergamasco,Komondor',
 silky:'Maltese,Tibetan Terrier,Lhasa Apso,Old English Sheepdog,Havanese,Pekingese,Shih Tzu,Japanese Chin,Yorkshire Terrier,Polish Lowland Sheepdog,Coton de Tulear,Skye Terrier,Biewer Terrier',
 feather:'Cavalier King Charles,Cavalier King Charles Spaniel,Border Collie,Papillon,Springer Spaniel,Australian Shepherd,English Setter,Cocker Spaniel,Nova Scotia Duck Tolling Retriever,Flat-coated Retriever,Boykin Spaniel,Kokoni,Brittany,Golden Retriever,Saluki,Sussex Spaniel,Borzoi,Silken Windhound,Clumber Spaniel,Field Spaniel',
 double:'Japanese Spitz,Leonberger,Swedish Vallhund,Eurasier,Norwegian Elkhound,American Eskimo Dog,Icelandic Sheepdog,Kuvasz,Keeshond,Alaskan Klee Kai,White Swiss Shepherd,Swedish Lapphund,Siberian Husky,Landseer,Shiba Inu,Chow Chow,Shikoku,Kishu,Akita,Kai Ken,Samoyed,Tibetan Mastiff,Bernese Mountain Dog,Pembroke Welsh Corgi,Rough Collie,German Shepherd,Pomeranian,Newfoundland,Saint Bernard,Norwegian Lundehund,Canaan Dog,Mongolian Bankhar,Schipperke,Husky,St Bernard'};
const COAT={};for(const k in CT)CT[k].split(',').forEach(b=>COAT[b.trim()]=k);
const TICKED={'English Setter':1,'Bracco Italiano':1,'Brittany':1,'Australian Cattle Dog':1,'German Shorthaired Pointer':1,'Bluetick Coonhound':1};

function coatMarks(coat,R,cx,cy,rx,ry,fur,n,isHead){
  const pale=lum(fur)>.8,dk=shade(fur,pale?-.36:-.28),lt=shade(fur,.45),ao=pale?.8:.6;let s='';
  if(coat==='smooth')return `<path d="M${cx-rx*.62} ${cy-ry*.38} Q${cx-rx*.3} ${cy-ry*.82} ${cx+rx*.18} ${cy-ry*.78}" ${st('#fff',isHead?5:6,.42)}/>`;
  if(coat==='short')return inEll(R,cx,cy,rx*.9,ry*.88,n,(q,i)=>`<path d="M${q[0].toFixed(1)} ${q[1].toFixed(1)} l${(R()*3-1.5).toFixed(1)} 5" ${st(i%3?dk:lt,2,ao-.1)}/>`);
  if(coat==='double'||coat==='feather')return inEll(R,cx,cy,rx*.94,ry*.9,n,(q,i)=>{const x=q[0].toFixed(1),y=q[1].toFixed(1);return `<path d="M${x} ${y} q2 5 -1 9 M${+x+5} ${y} q2 5 -1 9" ${st(i%3?dk:lt,2.2,ao)}/>`;});
  if(coat==='curly')return inEll(R,cx,cy,rx*.94,ry*.94,n,(q,i)=>`<path d="M${(q[0]-4).toFixed(1)} ${q[1].toFixed(1)} a4.5 4.5 0 1 1 4 4.4" ${st(i%2?dk:lt,2.6,ao+.1)}/>`);
  if(coat==='wire')return inEll(R,cx,cy,rx*.9,ry*.88,n,(q,i)=>`<path d="M${q[0].toFixed(1)} ${q[1].toFixed(1)} l3 -4 l3 4 l3 -4" ${st(i%3?dk:lt,2,ao)}/>`);
  if(coat==='silky'){for(let i=0;i<n;i++){const x=cx-rx*.85+i*(rx*1.7/(n-1)),y=cy-ry*.55+R()*ry*.3;s+=`<path d="M${x.toFixed(1)} ${y.toFixed(1)} q5 ${ry*.3} 0 ${ry*.6} q-5 ${ry*.3} 1 ${ry*.7}" ${st(i%2?dk:lt,3,ao)}/>`;}return s;}
  if(coat==='corded'){for(let i=0;i<n;i++){const x=cx-rx*.85+i*(rx*1.7/(n-1)),y=cy-ry*.75+R()*ry*.2;let d=`M${x.toFixed(1)} ${y.toFixed(1)}`;for(let j=0;j<5;j++)d+=` q${j%2?-4:4} ${ry*.18} 0 ${ry*.36}`;
    s+=`<path d="${d}" ${st(shade(fur,pale?-.22:-.16),9,.55)}/><path d="${d}" transform="translate(-2 0)" ${st(shade(fur,.4),2.5,.7)}/>`;}return s;}
  return '';}
function ticks(R,cx,cy,rx,ry,n,c){return inEll(R,cx,cy,rx*.9,ry*.85,n,q=>`<circle cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" r="${(1.2+R()*1.4).toFixed(1)}" fill="${c}" opacity=".7"/>`);}
function hangHair(coat,R,L,c){if(coat!=='silky'&&coat!=='corded'&&coat!=='feather')return '';
  const by=c.by,bw=c.bw,bh=c.bh,col=L.body||L.fur,dk=shade(col,-.22),top=by-bh*.2,fl=coat==='feather'?6:16,x0=100-bw-fl,x1=100+bw+fl,n=coat==='corded'?9:coat==='silky'?8:6,low=coat==='feather'?by+bh+2:194;
  let d=`M${100-bw*.7} ${top} L${x0} ${low-6}`;for(let i=0;i<n;i++){const a=x0+(x1-x0)*i/n,b=x0+(x1-x0)*(i+1)/n,m=(a+b)/2,y=low-(coat==='corded'?R()*6:R()*4);
    d+=coat==='corded'?` L${(a+2).toFixed(1)} ${(y-4).toFixed(1)} Q${m.toFixed(1)} ${(y+8).toFixed(1)} ${(b-2).toFixed(1)} ${(y-4).toFixed(1)}`:` Q${(a+(b-a)*.25).toFixed(1)} ${(y+6).toFixed(1)} ${m.toFixed(1)} ${y.toFixed(1)} Q${(a+(b-a)*.75).toFixed(1)} ${(y-3).toFixed(1)} ${b.toFixed(1)} ${(y+3).toFixed(1)}`;}
  d+=` L${x1} ${low-6} L${100+bw*.7} ${top} Z`;let s=`<path d="${d}" fill="${col}" ${ol(4)}/>`;
  for(let i=1;i<n;i++){const x=x0+(x1-x0)*i/n;s+=`<path d="M${x.toFixed(1)} ${(by+bh*.6).toFixed(1)} q${coat==='silky'?4:0} 14 0 ${(low-by-bh*.6-6).toFixed(1)}" ${st(dk,2.2,.55)}/>`;}return s;}
function ruff(L,c){const cx=c.cx,y0=c.cy+c.hh*.3,N=16,ro=c.hw*1.16,ri=c.hw*.96;let p='';
  for(let i=0;i<=N;i++){const a=Math.PI*(-.08+i*1.16/N),r=i%2?ri:ro;p+=(i?' L':'M')+(cx+Math.cos(a)*r).toFixed(1)+' '+(y0+Math.sin(a)*r*.78).toFixed(1);}
  return `<path d="${p} Z" fill="${L.fur}" ${ol(4)}/>`;}
function wireFace(L,c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,col=L.brows||shade(L.headC||L.fur,.35);let s='';
  for(const g of[-1,1])s+=`<path d="M${cx+g*hw*.2} ${cy-14} l${g*6} -12 l${g*4} 9 l${g*6} -11 l${g*3} 13 Z" fill="${col}" ${ol(2.5)}/>`;
  s+=`<path d="M${cx-hw*.26} ${cy+hh*.66} l5 16 l5 -8 l5 12 l5 -10 l5 12 l5 -8 l5 14 l3 -32 Z" fill="${L.muzzle||col}" ${ol(2.5)}/>`;return s;}

/* ---------------- space and alien furs (inside the head and body outlines) ---------------- */
const FUR={
 galaxy(c,h,o,R){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh,sc=o.star||'#fff';
   let s=`<ellipse cx="${cx-rx*.35}" cy="${cy-ry*.2}" rx="${rx*.62}" ry="${ry*.46}" fill="url(#${c.id}N1)"/><ellipse cx="${cx+rx*.4}" cy="${cy+ry*.35}" rx="${rx*.56}" ry="${ry*.4}" fill="url(#${c.id}N2)"/>`;
   s+=inEll(R,cx,cy,rx*.95,ry*.92,h?10:14,(q,i)=>`<circle cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" r="${(i%4?1.3:2.3)}" fill="${sc}" opacity="${i%3?.75:1}"/>`);
   return s+(h?star4(cx+rx*.55,cy-ry*.55,5,sc,'twk',.3):star4(cx-rx*.4,cy-ry*.3,6,sc,'twk')+star4(cx+rx*.45,cy+ry*.1,5,'#ffe066','twk',.6));},
 moon(c,h,o,R){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh;
   return inEll(R,cx,cy,rx*.8,ry*.75,h?4:5,(q,i)=>{const r=(h?5:6)+R()*5;return `<circle cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" r="${r.toFixed(1)}" fill="#c9cdd8"/><path d="M${(q[0]-r*.7).toFixed(1)} ${(q[1]-r*.3).toFixed(1)} a${r.toFixed(1)} ${r.toFixed(1)} 0 0 1 ${(r*1.3).toFixed(1)} -${(r*.4).toFixed(1)}" ${st('#a9afbd',2,1)}/>`;})+(h?'':star4(cx+rx*.5,cy-ry*.5,6,'#fff3a0','twk'));},
 jelly(c,h){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh;
   return `<ellipse cx="${cx-rx*.42}" cy="${cy-ry*.45}" rx="${rx*.28}" ry="${ry*.16}" fill="#fff" opacity=".75" transform="rotate(-25 ${cx-rx*.42} ${cy-ry*.45})"/><circle cx="${cx-rx*.12}" cy="${cy-ry*.62}" r="${rx*.06}" fill="#fff" opacity=".8"/>`+
     `<circle cx="${cx+rx*.35}" cy="${cy+ry*.3}" r="${rx*.09}" ${st('#fff',2,.75)}/><circle cx="${cx+rx*.12}" cy="${cy+ry*.52}" r="${rx*.05}" ${st('#fff',2,.75)}/><ellipse cx="${cx}" cy="${cy+ry*.75}" rx="${rx*.8}" ry="${ry*.3}" fill="#000" opacity=".08"/>`;},
 glitter(c,h,o,R){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh,cols=['#ffffff','#fff3a0','#ff7fd0','#9be8ff'];
   return inEll(R,cx,cy,rx*.9,ry*.85,h?7:10,(q,i)=>star4(+q[0].toFixed(1),+q[1].toFixed(1),2.5+R()*3,cols[i%4],i%3?'':'twk',i*.2));},
 neon(c,h,o){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh,col=o.col||'#7fe0ff';let s='';
   for(let i=-2;i<=2;i++)s+=`<path d="M${cx+i*rx*.38-rx*.2} ${cy-ry} l${rx*.4} ${ry*2}" ${st(col,h?7:8,.35)}/><path d="M${cx+i*rx*.38-rx*.2} ${cy-ry} l${rx*.4} ${ry*2}" ${st('#fff',2,.8)}/>`;return s;},
 ripples(c,h,o){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,col=o.col||'#ffffff';let s='';
   for(let i=1;i<=4;i++)s+=`<circle cx="${cx-rx*.7}" cy="${cy}" r="${i*rx*.32}" ${st(col,3,.55-i*.08)}/>`;return s;},
 rainbow(c,h){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh,cols=['#ff8fb3','#ffc46b','#fff27a','#8fe39a','#7fc8f0','#b58cff'];let s='';
   cols.forEach((q,i)=>{s+=`<rect x="${cx-rx*1.2+i*rx*.42}" y="${cy-ry*1.3}" width="${rx*.42}" height="${ry*2.6}" fill="${q}" opacity=".6" transform="rotate(20 ${cx} ${cy})"/>`;});return s;},
 planets(c,h,o,R){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh,cols=['#ff8a5a','#7f9cff','#8fe39a','#ff7fd0'];
   return inEll(R,cx,cy,rx*.75,ry*.7,h?2:4,(q,i)=>{const r=4+R()*3;return `<circle cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" r="${r.toFixed(1)}" fill="${cols[i%4]}" ${ol(1.6)}/><ellipse cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" rx="${(r*1.9).toFixed(1)}" ry="${(r*.5).toFixed(1)}" ${st(K,1.6,.8)} transform="rotate(-18 ${q[0].toFixed(1)} ${q[1].toFixed(1)})"/>`;});},
 swirl(c,h){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw;if(h)return '';let d=`M${cx} ${cy}`;for(let i=1;i<28;i++){const a=i*.5,r=i*rx*.032;d+=` L${(cx+Math.cos(a)*r).toFixed(1)} ${(cy+Math.sin(a)*r*.8).toFixed(1)}`;}
   return `<circle cx="${cx}" cy="${cy}" r="${rx*.85}" fill="url(#${c.id}N1)"/><path d="${d}" ${st('#3a1f5c',5,.8)}/><path d="${d}" ${st('#ffb3e0',1.8,.9)}/><circle cx="${cx}" cy="${cy}" r="5" fill="#1d1230"/>`;},
 stars(c,h,o,R){const cx=h?c.cx:100,cy=h?c.cy:c.by,rx=h?c.hw:c.bw,ry=h?c.hh:c.bh;return inEll(R,cx,cy,rx*.78,ry*.72,h?3:5,q=>star5(+q[0].toFixed(1),+q[1].toFixed(1),5+R()*2.5,o.col||'#ffd23f',K));}};
const FURBASE={galaxy:o=>({fur:o.base||'#2b2f6e',ear:o.ear||shade(o.base||'#2b2f6e',-.3),belly:shade(o.base||'#2b2f6e',.12),muzzle:shade(o.base||'#2b2f6e',.16),eyeWhite:true}),
 moon:()=>({fur:'#e4e6ee',ear:'#c9cdd8',belly:'#f2f3f8',muzzle:'#f6f7fb'})};

/* ---------------- hats and headgear (drawn last) ---------------- */
function nordicBand(x0,x1,y,col){let z='';for(let x=x0;x<x1-8;x+=12)z+=`<path d="M${x.toFixed(1)} ${y+5} l6 -10 l6 10 Z" fill="${col}"/>`;return z;}
const HAT={
 beanie(c,col,o){const cx=c.cx,yb=c.cy-c.hh*.5,hw=c.hw,hh=c.hh;col=col||'#e8423a';let s=`<path d="M${cx-hw*.92} ${yb} C${cx-hw*.9} ${yb-hh*1.05} ${cx+hw*.9} ${yb-hh*1.05} ${cx+hw*.92} ${yb} Z" fill="${col}" ${ol(4)}/>`;
   for(const x of[-.5,-.17,.17,.5])s+=`<path d="M${cx+hw*x} ${yb-4} Q${cx+hw*x*1.1} ${yb-hh*.5} ${cx+hw*x*.7} ${yb-hh*.72}" ${st(shade(col,-.2),3,1)}/>`;
   if(o.cuff)s+=`<rect x="${cx-hw*.98}" y="${yb-10}" width="${hw*1.96}" height="21" rx="10" fill="${shade(col,-.1)}" ${ol(3)}/>`;
   else s+=`<rect x="${cx-hw*.98}" y="${yb-10}" width="${hw*1.96}" height="21" rx="10" fill="#fff4e0" ${ol(3)}/>`+nordicBand(cx-hw*.86,cx+hw*.9,yb,col);
   if(!o.nopom)s+=`<circle cx="${cx}" cy="${yb-hh*.8-6}" r="15" fill="${o.pom||'#fff'}" ${ol(3)}/><circle cx="${cx-5}" cy="${yb-hh*.8-10}" r="4" fill="#fff" opacity=".7"/>`;return s;},
 earmuffs(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||'#ff9ecb';let s=c.two(`M${cx-hw*.95} ${cy-hh*.05} Q${cx} ${cy-hh*1.75} ${cx+hw*.95} ${cy-hh*.05}`,'#8a8f99',6);
   for(const g of[-1,1]){const x=cx+g*hw*1.0,y=cy-hh*.05;for(let i=0;i<8;i++){const a=i*.785;s+=`<circle cx="${(x+Math.cos(a)*12).toFixed(1)}" cy="${(y+Math.sin(a)*12).toFixed(1)}" r="7" fill="${col}" ${ol(2.5)}/>`;}s+=`<circle cx="${x}" cy="${y}" r="13" fill="${col}"/><circle cx="${x-3}" cy="${y-4}" r="4" fill="#fff" opacity=".6"/>`;}return s;},
 strawhat(c,col){const cx=c.cx,yb=c.cy-c.hh*.48,hw=c.hw,hh=c.hh;return `<ellipse cx="${cx}" cy="${yb+2}" rx="${hw*1.4}" ry="14" fill="#f2d27a" ${ol(4)}/><path d="M${cx-hw*1.1} ${yb+2} q${hw*1.1} 8 ${hw*2.2} 0" ${st('#d9b45a',2.5,1)}/>`+
   `<path d="M${cx-hw*.66} ${yb+2} C${cx-hw*.66} ${yb-hh*.78} ${cx+hw*.66} ${yb-hh*.78} ${cx+hw*.66} ${yb+2} Z" fill="#f2d27a" ${ol(4)}/><rect x="${cx-hw*.66}" y="${yb-12}" width="${hw*1.32}" height="11" fill="${col||'#e8423a'}" ${ol(2.5)}/>`;},
 sunhat(c,col){const cx=c.cx,yb=c.cy-c.hh*.48,hw=c.hw,hh=c.hh;col=col||'#ff9ecb';let s=`<path d="M${cx-hw*1.55} ${yb+8} Q${cx-hw*.8} ${yb-12} ${cx} ${yb-6} Q${cx+hw*.8} ${yb-12} ${cx+hw*1.55} ${yb+8} Q${cx} ${yb+22} ${cx-hw*1.55} ${yb+8} Z" fill="${col}" ${ol(4)}/>`+
   `<path d="M${cx-hw*.62} ${yb} C${cx-hw*.62} ${yb-hh*.75} ${cx+hw*.62} ${yb-hh*.75} ${cx+hw*.62} ${yb} Z" fill="${col}" ${ol(4)}/><rect x="${cx-hw*.62}" y="${yb-11}" width="${hw*1.24}" height="10" fill="#fff" ${ol(2.5)}/>`;
   const fx=cx+hw*.45,fy=yb-6;for(let i=0;i<5;i++){const a=i*1.2566;s+=`<circle cx="${(fx+Math.cos(a)*7).toFixed(1)}" cy="${(fy+Math.sin(a)*7).toFixed(1)}" r="6" fill="#fff27a" ${ol(2)}/>`;}return s+`<circle cx="${fx}" cy="${fy}" r="4.5" fill="#ff8a3c"/>`;},
 sailor(c){const cx=c.cx,yb=c.cy-c.hh*.72,hw=c.hw;return `<path d="M${cx-hw*.5} ${yb} L${cx-hw*.42} ${yb-26} Q${cx} ${yb-34} ${cx+hw*.42} ${yb-26} L${cx+hw*.5} ${yb} Z" fill="#ffffff" ${ol(3.5)}/><ellipse cx="${cx}" cy="${yb}" rx="${hw*.62}" ry="9" fill="#ffffff" ${ol(3.5)}/><path d="M${cx-hw*.44} ${yb-6} H${cx+hw*.44}" ${st('#2b4a8a',4,1)}/>`;},
 captain(c){const cx=c.cx,yb=c.cy-c.hh*.55,hw=c.hw,hh=c.hh;return `<path d="M${cx-hw*.85} ${yb-6} Q${cx-hw*.9} ${yb-hh*.62} ${cx} ${yb-hh*.66} Q${cx+hw*.9} ${yb-hh*.62} ${cx+hw*.85} ${yb-6} Z" fill="#ffffff" ${ol(3.5)}/><rect x="${cx-hw*.8}" y="${yb-12}" width="${hw*1.6}" height="13" fill="#2b4a8a" ${ol(3)}/>`+
   `<path d="M${cx-hw*.7} ${yb} Q${cx} ${yb+16} ${cx+hw*.7} ${yb} Z" fill="#26232e" ${ol(3)}/><circle cx="${cx}" cy="${yb-hh*.36}" r="7" fill="#ffd23f" ${ol(2)}/><path d="M${cx} ${yb-hh*.36-4} v8 M${cx-4} ${yb-hh*.36+2} q4 4 8 0" ${st(K,1.6,1)}/>`;},
 ranger(c){const cx=c.cx,yb=c.cy-c.hh*.52,hw=c.hw,hh=c.hh;return `<ellipse cx="${cx}" cy="${yb+2}" rx="${hw*1.38}" ry="12" fill="#a88a4a" ${ol(4)}/><path d="M${cx-hw*.6} ${yb+2} L${cx-hw*.42} ${yb-hh*.72} L${cx} ${yb-hh*.6} L${cx+hw*.42} ${yb-hh*.72} L${cx+hw*.6} ${yb+2} Z" fill="#b89a5a" ${ol(4)}/><rect x="${cx-hw*.6}" y="${yb-9}" width="${hw*1.2}" height="9" fill="#5a3a22" ${ol(2.5)}/>`;},
 pith(c){const cx=c.cx,yb=c.cy-c.hh*.5,hw=c.hw,hh=c.hh;return `<ellipse cx="${cx}" cy="${yb+4}" rx="${hw*1.2}" ry="15" fill="#e6d3a0" ${ol(4)}/>`+
   `<path d="M${cx-hw*.78} ${yb+2} C${cx-hw*.78} ${yb-hh*1.0} ${cx+hw*.78} ${yb-hh*1.0} ${cx+hw*.78} ${yb+2} Z" fill="#d8c08a" ${ol(4)}/><rect x="${cx-hw*.8}" y="${yb-9}" width="${hw*1.6}" height="11" fill="#8a6238" ${ol(2.5)}/><circle cx="${cx}" cy="${yb-hh*.74}" r="5" fill="#c9a86a" ${ol(2.5)}/>`;},
 explorer(c,col){const cx=c.cx,yb=c.cy-c.hh*.52,hw=c.hw,hh=c.hh;col=col||'#8a5a32';return `<path d="M${cx-hw*1.25} ${yb+6} Q${cx} ${yb-6} ${cx+hw*1.25} ${yb+6} Q${cx} ${yb+18} ${cx-hw*1.25} ${yb+6} Z" fill="${col}" ${ol(4)}/>`+
   `<path d="M${cx-hw*.62} ${yb+2} L${cx-hw*.56} ${yb-hh*.66} Q${cx} ${yb-hh*.5} ${cx+hw*.56} ${yb-hh*.66} L${cx+hw*.62} ${yb+2} Z" fill="${col}" ${ol(4)}/><rect x="${cx-hw*.62}" y="${yb-10}" width="${hw*1.24}" height="9" fill="#3a2a20"/>`;},
 tophat(c,col){const cx=c.cx,yb=c.cy-c.hh*.62,hw=c.hw,hh=c.hh;col=col||'#2a2630';return `<rect x="${cx-hw*.55}" y="${yb-hh*1.15}" width="${hw*1.1}" height="${hh*1.15}" rx="4" fill="${col}" ${ol(4)}/><rect x="${cx-hw*.55}" y="${yb-16}" width="${hw*1.1}" height="9" fill="#8a2a2a"/><ellipse cx="${cx}" cy="${yb}" rx="${hw*.95}" ry="9" fill="${col}" ${ol(4)}/><path d="M${cx-hw*.4} ${yb-hh*1.05} v${hh*.8}" ${st('#fff',3,.25)}/>`;},
 beret(c,col){const cx=c.cx-6,y=c.cy-c.hh*.78,hw=c.hw,hh=c.hh;col=col||'#3a3640';return `<ellipse cx="${cx}" cy="${y}" rx="${hw*.95}" ry="${hh*.34}" fill="${col}" ${ol(4)} transform="rotate(-12 ${cx} ${y})"/><path d="M${cx} ${y-hh*.33} q2 -9 7 -10" ${st(K,4,1)}/>`;},
 laurel(c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;let s='';for(const g of[-1,1])for(let i=0;i<6;i++){const a=Math.PI*(g<0?1.02+i*.075:-.02-i*.075),x=cx+Math.cos(a)*hw*.92,y=cy-hh*.25+Math.sin(a)*hh*.95;
   s+=`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="9" ry="4.5" fill="#6fbf4a" ${ol(2)} transform="rotate(${(a*57.3+90*g).toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})"/>`;}return s;},
 flycap(c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,y=cy-hh*.55;let s=`<path d="M${cx-hw*1.0} ${cy+hh*.25} L${cx-hw*1.0} ${cy-hh*.2} C${cx-hw*.95} ${cy-hh*1.28} ${cx+hw*.95} ${cy-hh*1.28} ${cx+hw*1.0} ${cy-hh*.2} L${cx+hw*1.0} ${cy+hh*.25} Q${cx+hw*.82} ${cy+hh*.3} ${cx+hw*.8} ${cy-hh*.1} Q${cx} ${cy-hh*.62} ${cx-hw*.8} ${cy-hh*.1} Q${cx-hw*.82} ${cy+hh*.3} ${cx-hw*1.0} ${cy+hh*.25} Z" fill="#8a5a32" ${ol(4)}/>`;
   s+=`<path d="M${cx} ${cy-hh*1.0} v${hh*.42}" ${st('#5a3a22',3,1)}/>`;for(const g of[-1,1])s+=`<circle cx="${cx+g*16}" cy="${y}" r="13" fill="#9be8ff" stroke="#b8862e" stroke-width="5"/><circle cx="${cx+g*16}" cy="${y}" r="16" ${st(K,2.5,1)}/><path d="M${cx+g*16-6} ${y-4} l4 -4" ${st('#fff',3,1)}/>`;return s;},
 nursecap(c){const cx=c.cx,y=c.cy-c.hh*.86,hw=c.hw;return `<path d="M${cx-hw*.55} ${y+8} L${cx-hw*.45} ${y-14} H${cx+hw*.45} L${cx+hw*.55} ${y+8} Z" fill="#ffffff" ${ol(3.5)}/><path d="M${cx} ${y-9} v12 M${cx-6} ${y-3} h12" ${st('#e8423a',4,1)}/>`;},
 headscarf(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||'#3d8fe0';const yb=cy-hh*.42;let s=`<path d="M${cx-hw*.98} ${yb+4} C${cx-hw*.95} ${cy-hh*1.3} ${cx+hw*.95} ${cy-hh*1.3} ${cx+hw*.98} ${yb+4} Q${cx} ${yb-10} ${cx-hw*.98} ${yb+4} Z" fill="${col}" ${ol(4)}/>`;
   for(let i=0;i<7;i++)s+=`<circle cx="${(cx-hw*.6+i*hw*.2).toFixed(1)}" cy="${(yb-hh*.35-Math.sin(i/6*Math.PI)*hh*.2).toFixed(1)}" r="3" fill="#fff" opacity=".8"/>`;
   return s+`<path d="M${cx+4} ${cy-hh*1.08} l-14 -12 l-2 16 Z M${cx+4} ${cy-hh*1.08} l14 -12 l2 16 Z" fill="${col}" ${ol(3)}/><circle cx="${cx+4}" cy="${cy-hh*1.08}" r="5" fill="${shade(col,-.2)}" ${ol(2)}/>`;},
 wig(c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,W='#f4f1ea';let s='';for(const g of[-1,1])for(let i=0;i<4;i++)s+=`<circle cx="${cx+g*hw*1.02}" cy="${cy-hh*.45+i*15}" r="10" fill="${W}" ${ol(2.5)}/>`;
   for(let i=0;i<5;i++)s+=`<circle cx="${cx-hw*.6+i*hw*.3}" cy="${cy-hh*.95+Math.abs(i-2)*4}" r="12" fill="${W}" ${ol(2.5)}/>`;return s;},
 crown(c,cols){const cx=c.cx,cy=c.cy-c.hh*.82;cols=cols||['#ff9ecb','#fff','#ffd23f','#b58cff','#fff','#ff9ecb'];let s='';
   [-2.5,-1.5,-.5,.5,1.5,2.5].forEach((i,n)=>{const x=cx+i*c.hw*.3,y=cy+i*i*2.2;for(let k=0;k<5;k++){const a=k*1.2566;s+=`<circle cx="${(x+Math.cos(a)*6).toFixed(1)}" cy="${(y+Math.sin(a)*6).toFixed(1)}" r="5" fill="${cols[n%cols.length]}" ${ol(1.8)}/>`;}s+=`<circle cx="${x}" cy="${y}" r="3.6" fill="${n%2?'#ff8a3c':'#ffd23f'}"/>`;});
   for(const g of[-1,1])s+=`<ellipse cx="${cx+g*c.hw*.9}" cy="${cy+16}" rx="8" ry="4" fill="#6fcf73" ${ol(2)} transform="rotate(${g*40} ${cx+g*c.hw*.9} ${cy+16})"/>`;return s;},
 numcrown(c,txt){const cx=c.cx,yb=c.cy-c.hh*.68,hw=c.hw;return `<path d="M${cx-hw*.62} ${yb} L${cx-hw*.7} ${yb-30} L${cx-hw*.32} ${yb-14} L${cx} ${yb-36} L${cx+hw*.32} ${yb-14} L${cx+hw*.7} ${yb-30} L${cx+hw*.62} ${yb} Z" fill="#ffd23f" ${ol(3.5)}/>`+
   `<circle cx="${cx-hw*.7}" cy="${yb-32}" r="4" fill="#ff4f6d" ${ol(2)}/><circle cx="${cx+hw*.7}" cy="${yb-32}" r="4" fill="#5cb8ff" ${ol(2)}/><circle cx="${cx}" cy="${yb-12}" r="11" fill="#fff" ${ol(2.5)}/><text x="${cx}" y="${yb-7.5}" font-size="${String(txt).length>1?11:14}" font-weight="900" text-anchor="middle" fill="${K}" font-family="Arial,sans-serif">${txt}</text>`;},
 propeller(c){const cx=c.cx,yb=c.cy-c.hh*.62,hw=c.hw,hh=c.hh,top=yb-hh*.6;return `<path d="M${cx-hw*.7} ${yb} C${cx-hw*.7} ${top} ${cx+hw*.7} ${top} ${cx+hw*.7} ${yb} Z" fill="#e8423a" ${ol(3.5)}/><path d="M${cx} ${top+4} C${cx-hw*.2} ${top+8} ${cx-hw*.3} ${yb-4} ${cx-hw*.32} ${yb} H${cx+hw*.32} C${cx+hw*.3} ${yb-4} ${cx+hw*.2} ${top+8} ${cx} ${top+4} Z" fill="#ffd23f" ${ol(2.5)}/>`+
   `<rect x="${cx-hw*.74}" y="${yb-5}" width="${hw*1.48}" height="9" rx="4" fill="#5b8def" ${ol(2.5)}/><path d="M${cx} ${top+3} v-9" ${st(K,3,1)}/><g class="tail" style="transform-origin:${cx}px ${top-7}px"><path d="M${cx-26} ${top-10} Q${cx-13} ${top-15} ${cx} ${top-7} Q${cx+13} ${top+1} ${cx+26} ${top-4} Q${cx+13} ${top-16} ${cx} ${top-7} Q${cx-13} ${top+2} ${cx-26} ${top-10} Z" fill="#3fae5a" ${ol(2.5)}/></g><circle cx="${cx}" cy="${top-7}" r="3.5" fill="#fff" ${ol(2)}/>`;},
 racing(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||'#e8423a';return `<path d="M${cx-hw*1.02} ${cy-hh*.05} C${cx-hw*1.02} ${cy-hh*1.32} ${cx+hw*1.02} ${cy-hh*1.32} ${cx+hw*1.02} ${cy-hh*.05} Q${cx+hw*.8} ${cy-hh*.1} ${cx+hw*.74} ${cy-hh*.4} H${cx-hw*.74} Q${cx-hw*.8} ${cy-hh*.1} ${cx-hw*1.02} ${cy-hh*.05} Z" fill="${col}" ${ol(4)}/>`+
   `<path d="M${cx-hw*.74} ${cy-hh*.42} Q${cx} ${cy-hh*.72} ${cx+hw*.74} ${cy-hh*.42} L${cx+hw*.6} ${cy-hh*.62} Q${cx} ${cy-hh*.86} ${cx-hw*.6} ${cy-hh*.62} Z" fill="#3a4a6a" fill-opacity=".85" ${ol(2.5)}/><path d="M${cx-8} ${cy-hh*1.0} v${hh*.25} M${cx+8} ${cy-hh*1.0} v${hh*.25}" ${st('#fff',5,1)}/>`;},
 hardhat(c,col){const cx=c.cx,yb=c.cy-c.hh*.5,hw=c.hw,hh=c.hh;col=col||'#ffd23f';return `<ellipse cx="${cx}" cy="${yb+2}" rx="${hw*1.08}" ry="10" fill="${col}" ${ol(4)}/><path d="M${cx-hw*.8} ${yb} C${cx-hw*.8} ${yb-hh*.92} ${cx+hw*.8} ${yb-hh*.92} ${cx+hw*.8} ${yb} Z" fill="${col}" ${ol(4)}/><path d="M${cx} ${yb-hh*.7} v${hh*.6}" ${st(shade(col,-.2),5,1)}/>`+
   `<circle class="glow" cx="${cx}" cy="${yb-hh*.28}" r="16" fill="#fff6a8" opacity=".55"/><circle cx="${cx}" cy="${yb-hh*.28}" r="9" fill="#c9d2e3" ${ol(2.5)}/><circle cx="${cx}" cy="${yb-hh*.28}" r="5.5" fill="#fff27a"/>`;},
 sirenhat(c){return HAT.hardhat(c,'#ffffff')+`<path d="M${c.cx-10} ${c.cy-c.hh*1.2} a10 10 0 0 1 20 0 Z" fill="#5cb8ff" ${ol(2.5)}/><circle class="glow" cx="${c.cx}" cy="${c.cy-c.hh*1.24}" r="13" fill="#5cb8ff" opacity=".45"/>`;},
 souwester(c){const cx=c.cx,yb=c.cy-c.hh*.45,hw=c.hw,hh=c.hh;return `<path d="M${cx-hw*1.25} ${yb+6} Q${cx} ${yb+26} ${cx+hw*1.25} ${yb+6} Q${cx} ${yb-8} ${cx-hw*1.25} ${yb+6} Z" fill="#ffd23f" ${ol(4)}/>`+
   `<path d="M${cx-hw*.72} ${yb+4} C${cx-hw*.7} ${yb-hh*.95} ${cx+hw*.7} ${yb-hh*.95} ${cx+hw*.72} ${yb+4} Z" fill="#ffd23f" ${ol(4)}/><path d="M${cx-hw*.5} ${yb-hh*.5} Q${cx} ${yb-hh*.68} ${cx+hw*.5} ${yb-hh*.5}" ${st('#e0a400',3,1)}/>`;},
 bubble(c){const cx=c.cx,cy=c.cy,r=Math.max(c.hw,c.hh)+16;return `<ellipse cx="${cx}" cy="${cy+c.hh-2}" rx="${c.hw*.78}" ry="10" fill="#c9d2e3" ${ol(3)}/><circle cx="${cx}" cy="${cy+2}" r="${r}" fill="#d6f1ff" fill-opacity=".2" ${ol(4)}/><path d="M${cx-r*.62} ${cy-r*.5} A${r*.8} ${r*.8} 0 0 1 ${cx-r*.05} ${cy-r*.84}" ${st('#fff',6,.85)}/>`;},
 headband(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,y=cy-hh*.68;col=col||'#e8423a';return `<path d="M${cx-hw*.76} ${y+4} Q${cx} ${y-8} ${cx+hw*.76} ${y+4} L${cx+hw*.8} ${y+15} Q${cx} ${y+3} ${cx-hw*.8} ${y+15} Z" fill="${col}" ${ol(3)}/>`+
   c.two(`M${cx+hw*.78} ${y+9} q14 -8 26 -2`,col,6)+c.two(`M${cx+hw*.78} ${y+9} q14 6 22 18`,col,6)+`<circle cx="${cx}" cy="${y+3}" r="6" fill="#fff" ${ol(2)}/>`;},
 antenna(c,col,o){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||'#ff4f6d';let s=c.two(`M${cx-hw*.9} ${cy-hh*.1} Q${cx} ${cy-hh*1.5} ${cx+hw*.9} ${cy-hh*.1}`,'#8a8f99',5);
   const one=o.one,xs=one?[cx+hw*.25]:[cx-hw*.4,cx+hw*.4];xs.forEach(x=>{const y0=cy-hh*1.02;s+=`<path d="M${x} ${y0} l-4 -4 l8 -4 l-8 -4 l4 -4" ${st(K,3,1)}/><circle class="${o.glow?'glow':''}" cx="${x}" cy="${y0-20}" r="${o.glow?8:6.5}" fill="${col}" ${ol(2.5)}/>`;
     if(one)s+=`<path d="M${x-12} ${y0-24} l-6 -4 M${x+12} ${y0-24} l6 -4 M${x} ${y0-31} v-6" ${st(col,3,.9)}/>`;});return s;},
 acorncap(c){const cx=c.cx,yb=c.cy-c.hh*.5,hw=c.hw,hh=c.hh;let s=`<path d="M${cx-hw*.95} ${yb+4} C${cx-hw*.95} ${yb-hh*.98} ${cx+hw*.95} ${yb-hh*.98} ${cx+hw*.95} ${yb+4} Q${cx} ${yb+12} ${cx-hw*.95} ${yb+4} Z" fill="#a8743a" ${ol(4)}/>`;
   for(let r=0;r<3;r++)for(let i=0;i<7;i++)s+=`<path d="M${(cx-hw*.72+i*hw*.24).toFixed(1)} ${(yb-4-r*hh*.24+Math.abs(i-3)*3*r*.4).toFixed(1)} q5 -6 10 0" ${st('#7a4a22',2.2,.9)}/>`;
   return s+`<path d="M${cx} ${yb-hh*.75} q2 -12 9 -16" ${st(K,7,1)}/><path d="M${cx} ${yb-hh*.75} q2 -12 9 -16" ${st('#7a4a22',4,1)}/>`;},
 fernhat(c){const cx=c.cx,y=c.cy-c.hh*.9;let s=`<path d="M${cx-30} ${y+12} Q${cx} ${y-26} ${cx+34} ${y-10}" ${st('#3f8a3a',4,1)}/>`;
   for(let i=0;i<7;i++){const t=i/6,x=cx-30+t*64,yy=y+12-Math.sin(t*Math.PI)*28-t*6;for(const g of[-1,1])s+=`<ellipse cx="${x.toFixed(1)}" cy="${(yy+g*7).toFixed(1)}" rx="8" ry="4" fill="#6fbf4a" ${ol(1.8)} transform="rotate(${g*35} ${x.toFixed(1)} ${(yy+g*7).toFixed(1)})"/>`;}return s;},
 visor(c){const cx=c.cx,y=c.cy-c.hh*.66,hw=c.hw;return `<path d="M${cx-hw*.8} ${y} Q${cx} ${y-10} ${cx+hw*.8} ${y} L${cx+hw*.82} ${y+9} Q${cx} ${y-1} ${cx-hw*.82} ${y+9} Z" fill="#ff8a3c" ${ol(3)}/><path d="M${cx-hw*.7} ${y+7} Q${cx} ${y+30} ${cx+hw*.7} ${y+7} Q${cx} ${y+12} ${cx-hw*.7} ${y+7} Z" fill="#ffd23f" fill-opacity=".85" ${ol(3)}/>`+star5(cx,y-12,9,'#ffd23f',K);},
 trex(c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,col='#6fbf4a';let s=`<path d="M${cx-hw*1.04} ${cy-hh*.02} C${cx-hw*1.04} ${cy-hh*1.4} ${cx+hw*1.04} ${cy-hh*1.4} ${cx+hw*1.04} ${cy-hh*.02} Q${cx} ${cy-hh*.62} ${cx-hw*1.04} ${cy-hh*.02} Z" fill="${col}" ${ol(4)}/>`;
   for(let i=0;i<9;i++){const t=i/8,x=cx-hw*.9+t*hw*1.8,y=cy-hh*.06-Math.sin(t*Math.PI)*hh*.3;s+=`<path d="M${(x-4).toFixed(1)} ${(y-3).toFixed(1)} l4 9 l4 -9 Z" fill="#fff" ${ol(1.6)}/>`;}
   for(const g of[-1,1])s+=`<circle cx="${cx+g*hw*.36}" cy="${cy-hh*.92}" r="8" fill="#fff" ${ol(2.5)}/><circle cx="${cx+g*hw*.36+2}" cy="${cy-hh*.92}" r="4" fill="${K}"/>`;
   for(let i=0;i<4;i++)s+=`<path d="M${cx-hw*.2+i*hw*.16} ${cy-hh*1.18+i*3} l6 -12 l6 12 Z" fill="#ff8a3c" ${ol(2)}/>`;return s;},
 trike(c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,col='#ff9a4a';let s=`<path d="M${cx-hw*1.04} ${cy-hh*.08} C${cx-hw*1.04} ${cy-hh*1.36} ${cx+hw*1.04} ${cy-hh*1.36} ${cx+hw*1.04} ${cy-hh*.08} Q${cx} ${cy-hh*.62} ${cx-hw*1.04} ${cy-hh*.08} Z" fill="${col}" ${ol(4)}/>`;
   for(const g of[-1,1])s+=`<path d="M${cx+g*hw*.4-6} ${cy-hh*.95} q${g*4} -30 ${g*16} -38 q${-g*2} 18 ${g*2} 40 Z" fill="#fff3d6" ${ol(2.5)}/>`;
   return s+`<path d="M${cx-6} ${cy-hh*.62} l6 -16 l6 16 Z" fill="#fff3d6" ${ol(2.5)}/>`;},
 mammoth(c){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,col='#8a5a32';let d=`M${cx-hw*1.06} ${cy}`;for(let i=0;i<=10;i++){const t=i/10,a=Math.PI*(1+t);d+=` L${(cx+Math.cos(a)*hw*(1.06+(i%2)*.08)).toFixed(1)} ${(cy-hh*.1+Math.sin(a)*hh*(1.22+(i%2)*.08)).toFixed(1)}`;}
   d+=` L${cx+hw*1.06} ${cy} Q${cx} ${cy-hh*.62} ${cx-hw*1.06} ${cy} Z`;let s=`<path d="${d}" fill="${col}" ${ol(4)}/>`;
   for(const g of[-1,1]){const x=cx+g*hw*.3,y=cy+hh*.62;s+=c.two(`M${x} ${y} Q${x+g*hw*.2} ${y+hh*.6} ${x+g*hw*.62} ${y+hh*.5} Q${x+g*hw*.78} ${y+hh*.44} ${x+g*hw*.8} ${y+hh*.2}`,'#fff8e6',8);}return s;}
};
/* glasses */
const frameC=c=>lum(c.L.headC||c.L.fur)<.3?'#e6c46a':K;
const FACE={
 round(c){const cx=c.cx,y=c.cy-2,ed=c.hw*c.L.eyeD,fc=frameC(c);return [-1,1].map(g=>`<circle cx="${cx+g*ed}" cy="${y}" r="15" fill="#fff" fill-opacity=".18" stroke="${fc}" stroke-width="3.5"/>`).join('')+`<path d="M${cx-ed+15} ${y-2} q${ed-15} -8 ${2*ed-30} 0" ${st(fc,3,1)}/>`;},
 sun(c,col){const cx=c.cx,y=c.cy-3,ed=c.hw*c.L.eyeD;col=col||'#26232e';return [-1,1].map(g=>`<rect x="${cx+g*ed-15}" y="${y-11}" width="30" height="22" rx="9" fill="${col}" ${ol(3)}/><path d="M${cx+g*ed-9} ${y-5} l7 -3" ${st('#fff',3,.8)}/>`).join('')+`<path d="M${cx-ed+15} ${y-3} H${cx+ed-15}" ${st(K,4,1)}/>`;},
 pixel(c){const cx=c.cx,y=c.cy-4,ed=c.hw*c.L.eyeD;let s=`<rect x="${cx-ed-16}" y="${y-8}" width="${2*ed+32}" height="6" fill="${K}"/>`;for(const g of[-1,1])s+=`<path d="M${cx+g*ed-14} ${y-2} h28 v8 h-4 v4 h-20 v-4 h-4 Z" fill="${K}"/><rect x="${cx+g*ed-10}" y="${y}" width="5" height="4" fill="#fff"/>`;return s;},
 prism(c){const cx=c.cx,y=c.cy-2,ed=c.hw*c.L.eyeD;return [-1,1].map(g=>`<path d="M${cx+g*ed} ${y-15} L${cx+g*ed+15} ${y+11} H${cx+g*ed-15} Z" fill="url(#${c.id}r)" fill-opacity=".7" ${ol(3)}/>`).join('')+`<path d="M${cx-ed+8} ${y-2} H${cx+ed-8}" ${st(K,3,1)}/>`;},
 cats(c){const cx=c.cx,y=c.cy-2,ed=c.hw*c.L.eyeD;return [-1,1].map(g=>`<path d="M${cx+g*ed-g*14} ${y-6} Q${cx+g*ed} ${y-14} ${cx+g*ed+g*18} ${y-14} Q${cx+g*ed+g*16} ${y+12} ${cx+g*ed} ${y+12} Q${cx+g*ed-g*14} ${y+10} ${cx+g*ed-g*14} ${y-6} Z" fill="#fff" fill-opacity=".15" stroke="${frameC(c)}" stroke-width="3.5"/>`).join('')+`<path d="M${cx-ed+14} ${y-4} H${cx+ed-14}" ${st(frameC(c),3,1)}/>`;},
 skigog(c){const cx=c.cx,y=c.cy-c.hh*.5-1,hw=c.hw;return `<defs><linearGradient id="${c.id}G" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#ffe27a"/><stop offset=".45" stop-color="#ff9a3c"/><stop offset=".55" stop-color="#e8423a"/><stop offset="1" stop-color="#8a5cd6"/></linearGradient></defs>`+
   `<rect x="${cx-hw*.98}" y="${y-5}" width="${hw*1.96}" height="10" fill="#3a3640"/><rect x="${cx-31}" y="${y-13}" width="62" height="26" rx="12" fill="url(#${c.id}G)" ${ol(4)}/><path d="M${cx} ${y-12} v24" ${st(K,3,1)}/><path d="M${cx-24} ${y-6} l9 -4" ${st('#fff',3.5,1)}/>`;},
 snorkel(c){const cx=c.cx,y=c.cy-c.hh*.6,hw=c.hw;return `<rect x="${cx-hw*.98}" y="${y-4}" width="${hw*1.96}" height="8" fill="#2fb3b3"/><ellipse cx="${cx}" cy="${y}" rx="${hw*.6}" ry="15" fill="#bff0ff" fill-opacity=".75" stroke="#ff8a3c" stroke-width="7"/><ellipse cx="${cx}" cy="${y}" rx="${hw*.6+4}" ry="19" ${st(K,2.5,1)}/><path d="M${cx-hw*.4} ${y-6} l10 -5" ${st('#fff',3.5,1)}/>`+
   c.two(`M${cx+hw*.62} ${y+4} q14 -2 12 -22 v-30`,'#ffd23f',7)+`<rect x="${cx+hw*.62+6}" y="${y-58}" width="12" height="9" rx="3" fill="#ff8a3c" ${ol(2.5)}/>`;},
 divemask(c){return FACE.snorkel(c).replace(/#ff8a3c/g,'#3a3640').replace('#ffd23f','#3a3640');},
 brass(c){const cx=c.cx,y=c.cy-c.hh*.58,hw=c.hw;let s=`<rect x="${cx-hw*.98}" y="${y-4}" width="${hw*1.96}" height="8" fill="#7a4a2a"/>`;
   for(const g of[-1,1])s+=`<circle cx="${cx+g*17}" cy="${y}" r="15" fill="#9be8ff" stroke="#b8862e" stroke-width="6"/><circle cx="${cx+g*17}" cy="${y}" r="18" ${st(K,2.5,1)}/><path d="M${cx+g*17-7} ${y-4} l5 -5" ${st('#fff',3,1)}/>`;return s+`<rect x="${cx-4}" y="${y-3}" width="8" height="6" fill="#b8862e"/>`;}
};

/* ---------------- body wear (inside the body outline) ---------------- */
function bodyRect(c,col){return `<rect x="${100-c.bw}" y="${c.by-c.bh}" width="${c.bw*2}" height="${c.bh*2}" fill="${col}"/>`;}
const BODY={
 jumper(c,col,o){const by=c.by,bw=c.bw,bh=c.bh;col=col||'#5b8def';let s=bodyRect(c,col);for(let i=0;i<3;i++)s+=`<path d="M${100-bw} ${by+bh*.62+i*7} H${100+bw}" ${st(shade(col,-.25),3,1)}/>`;
   if(o.pat==='nordic'){for(let x=100-bw;x<100+bw;x+=16)s+=`<path d="M${x} ${by-bh*.5} l8 -7 l8 7" ${st('#fff',3,.85)}/>`;s+=nordicBand(100-bw,100+bw,by+bh*.25,'#fff');for(let x=100-bw+6;x<100+bw;x+=14)s+=`<circle cx="${x}" cy="${by-bh*.15}" r="2.4" fill="#fff"/>`;}
   if(o.pat==='rivets'){s+=`<path d="M100 ${by-bh} V${by+bh}" ${st(shade(col,-.3),3,1)}/>`;for(let y=by-bh*.6;y<by+bh*.6;y+=12)s+=`<circle cx="92" cy="${y}" r="2.6" fill="#fff"/><circle cx="108" cy="${y}" r="2.6" fill="#fff"/>`;s+=`<path d="M${100-bw*.8} ${by-bh*.6} l${bw*.5} ${bh*.4}" ${st('#fff',5,.5)}/>`;}
   return s;},
 camo(c){const R=hrng(c.id);let s=bodyRect(c,'#7a8a4a');s+=inEll(R,100,c.by,c.bw*.95,c.bh*.9,9,(q,i)=>`<ellipse cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" rx="${(8+R()*7).toFixed(1)}" ry="${(5+R()*4).toFixed(1)}" fill="${['#4a5a2a','#a89a5a','#5a4a32'][i%3]}" transform="rotate(${(R()*60-30).toFixed(0)} ${q[0].toFixed(1)} ${q[1].toFixed(1)})"/>`);return s;},
 hawaiian(c,col){const R=hrng(c.id+'h');col=col||'#ff8a3c';let s=bodyRect(c,col);s+=inEll(R,100,c.by,c.bw*.9,c.bh*.85,6,(q,i)=>{let f='';for(let k=0;k<5;k++){const a=k*1.2566;f+=`<circle cx="${(q[0]+Math.cos(a)*4.5).toFixed(1)}" cy="${(q[1]+Math.sin(a)*4.5).toFixed(1)}" r="3.6" fill="${i%2?'#fff':'#ffe066'}"/>`;}return f+`<circle cx="${q[0].toFixed(1)}" cy="${q[1].toFixed(1)}" r="2.4" fill="#e8423a"/>`;});
   return s+`<path d="M${100-12} ${c.by-c.bh} L100 ${c.by-c.bh*.45} L${100+12} ${c.by-c.bh}" fill="${shade(col,.25)}" ${ol(2)}/>`;},
 gi(c){const by=c.by,bw=c.bw,bh=c.bh;return bodyRect(c,'#f6f4ee')+`<path d="M${100-bw*.5} ${by-bh} L100 ${by+bh*.1} L${100+bw*.5} ${by-bh}" ${st('#c9c2b2',4,1)}/><path d="M${100-bw*.2} ${by-bh} L100 ${by-bh*.4}" ${st('#c9c2b2',3,1)}/>`;},
 hivis(c){const by=c.by,bw=c.bw,bh=c.bh;return bodyRect(c,'#d8f23a')+`<rect x="${100-bw}" y="${by-bh*.1}" width="${bw*2}" height="9" fill="#c9d2e3"/><rect x="${100-bw}" y="${by+bh*.35}" width="${bw*2}" height="9" fill="#c9d2e3"/><path d="M100 ${by-bh} V${by+bh}" ${st('#a8c22a',3,1)}/>`;},
 lifevest(c){const by=c.by,bw=c.bw,bh=c.bh;let s='';for(const g of[-1,1])s+=`<rect x="${g<0?100-bw:100+bw*.18}" y="${by-bh}" width="${bw*.82}" height="${bh*2}" fill="#ff6a2a"/>`;
   return s+`<rect x="${100-bw}" y="${by+bh*.08}" width="${bw*2}" height="9" fill="#e6eaf0"/><path d="M${100-bw} ${by+bh*.08+4.5} H${100+bw}" ${st('#aab3c0',2,1)} stroke-dasharray="5 4"/>`;},
 labcoat(c){const by=c.by,bw=c.bw,bh=c.bh;return bodyRect(c,'#f6f8fb')+`<path d="M100 ${by-bh} V${by+bh}" ${st('#c9d2e3',3,1)}/><circle cx="106" cy="${by-6}" r="3" fill="#c9d2e3"/><circle cx="106" cy="${by+10}" r="3" fill="#c9d2e3"/><rect x="${100-bw*.75}" y="${by+4}" width="16" height="12" rx="2" ${st('#c9d2e3',2.5,1)}/>`;},
 waistcoat(c){const by=c.by,bw=c.bw,bh=c.bh;let s='';for(const g of[-1,1]){const x=g<0?100-bw:100+bw*.2;s+=`<rect x="${x}" y="${by-bh}" width="${bw*.8}" height="${bh*2}" fill="#c9b07a"/><rect x="${g<0?100-bw*.75:100+bw*.32}" y="${by+2}" width="15" height="12" rx="2" fill="#b89a5a" ${ol(1.8)}/>`;}return s;}
};
/* things on the chest and round the neck (drawn before the head) */
const NECK={
 neckerchief(c,col){const cx=c.cx,y=c.cy+c.hh-14;col=col||'#e8423a';return `<path d="M${cx-30} ${y} Q${cx} ${y+10} ${cx+30} ${y} L${cx} ${y+30} Z" fill="${col}" ${ol(3)}/><path d="M${cx-18} ${y+3} L${cx-6} ${y+20} M${cx-4} ${y+6} L${cx+4} ${y+20} M${cx+12} ${y+5} L${cx+4} ${y+20} M${cx-24} ${y+6} H${cx+24} M${cx-14} ${y+14} H${cx+14}" ${st('#fff',2.5,.55)}/>`;},
 bowtie(c,col){const cx=c.cx,y=c.cy+c.hh+2;col=col||'#e8423a';return `<path d="M${cx} ${y} l-16 -10 v20 Z M${cx} ${y} l16 -10 v20 Z" fill="${col}" ${ol(2.5)}/><circle cx="${cx}" cy="${y}" r="5" fill="${shade(col,-.15)}" ${ol(2)}/>`;},
 medal(c){const cx=c.cx,y=c.cy+c.hh+18;return `<path d="M${cx-16} ${c.cy+c.hh-12} L${cx-4} ${y-8} M${cx+16} ${c.cy+c.hh-12} L${cx+4} ${y-8}" ${st('#5b8def',7,1)}/><circle cx="${cx}" cy="${y}" r="12" fill="#ffd23f" ${ol(3)}/>`+star5(cx,y+1,7,'#fff3a8',K);},
 whistle(c){const cx=c.cx,y=c.cy+c.hh+14;return `<path d="M${cx-18} ${c.cy+c.hh-12} Q${cx} ${y+4} ${cx+18} ${c.cy+c.hh-12}" ${st('#e8423a',3,1)}/><rect x="${cx-6}" y="${y-3}" width="18" height="10" rx="4" fill="#c9d2e3" ${ol(2.5)}/><circle cx="${cx-6}" cy="${y+3}" r="6" fill="#c9d2e3" ${ol(2.5)}/>`;},
 amber(c){const cx=c.cx,y0=c.cy+c.hh-12;let s='';for(let i=-3;i<=3;i++)s+=`<circle cx="${cx+i*8}" cy="${y0+8+(9-i*i)*0.9}" r="4" fill="#ffb347" ${ol(1.6)}/>`;
   return s+`<path d="M${cx} ${y0+20} l9 8 l-9 10 l-9 -10 Z" fill="#ffa62a" fill-opacity=".9" ${ol(2.5)}/><circle cx="${cx}" cy="${y0+29}" r="2" fill="#5a3a22"/>`;},
 binocs(c){const cx=c.cx,y=c.cy+c.hh+12;return `<path d="M${cx-26} ${c.cy+c.hh-16} L${cx-14} ${y} M${cx+26} ${c.cy+c.hh-16} L${cx+14} ${y}" ${st('#5a3a22',4,1)}/>`+
   [-1,1].map(g=>`<rect x="${cx+g*11-9}" y="${y-4}" width="18" height="24" rx="6" fill="#3f5a3a" ${ol(3)}/><circle cx="${cx+g*11}" cy="${y+18}" r="6" fill="#9be8ff" ${ol(2.5)}/>`).join('')+`<rect x="${cx-3}" y="${y+2}" width="6" height="10" fill="#2a3a28"/>`;},
 lei(c){const cx=c.cx,y0=c.cy+c.hh-10,cols=['#ff7fb8','#ffd23f','#ff8a3c','#fff'];let s='';for(let i=-4;i<=4;i++){const x=cx+i*8.5,y=y0+(16-i*i)*0.9;for(let k=0;k<5;k++){const a=k*1.2566+i;s+=`<circle cx="${(x+Math.cos(a)*3.6).toFixed(1)}" cy="${(y+Math.sin(a)*3.6).toFixed(1)}" r="3" fill="${cols[(i+4)%4]}"/>`;}s+=`<circle cx="${x}" cy="${y}" r="1.8" fill="#e8423a"/>`;}return s;},
 num(c,col,o){const bcx=c.bcx,by=c.by,t=String(o.num);return `<circle cx="${bcx}" cy="${by+4}" r="19" fill="#ffd23f" ${ol(3)}/><text x="${bcx}" y="${by+(t==='π'?13:15)}" font-size="${t.length>1?20:30}" font-weight="900" text-anchor="middle" fill="${K}" font-family="Arial Rounded MT Bold,Arial,sans-serif">${t}</text>`;},
 belt(c,col){const bcx=c.bcx,y=c.by+c.bh*.12;col=col||'#26232e';return `<rect x="${100-c.bw}" y="${y-5}" width="${c.bw*2}" height="10" fill="${col}"/>`+c.two(`M${bcx-2} ${y} l-8 18`,col,5)+c.two(`M${bcx+2} ${y} l8 18`,col,5)+`<rect x="${bcx-6}" y="${y-6}" width="12" height="12" rx="3" fill="${col}" ${ol(2)}/>`;},
 buckle(c){const bcx=c.bcx,by=c.by;return `<rect x="${bcx-6}" y="${by-20}" width="12" height="40" rx="3" fill="#3a3640"/><rect x="${bcx-9}" y="${by-4}" width="18" height="11" rx="3" fill="#ffd23f" ${ol(2.5)}/>`;},
 saturn(c){const by=c.by+6,rx=c.bw+22,d=`M${100+rx} ${by} A${rx} 15 0 0 1 ${100-rx} ${by}`;return `<path d="${d}" ${st(K,13,1)}/><path d="${d}" ${st('#ffd27a',7,1)}/><path d="${d}" ${st('#fff3c0',2,.8)}/>`;}
};
/* boots over the front paws (drawn last) */
function pawXs(c){const xs=[c.bcx-17,c.bcx+17];if(c.L.long)xs.push(100+c.bw-36,100+c.bw-10);return xs;}
const FEET={
 wellies(c,col){col=col||'#3fae5a';return pawXs(c).map(x=>`<path d="M${x-12} 168 v18 q0 8 8 8 h18 q5 0 5 -5 q0 -5 -7 -6 v-15 Z" fill="${col}" ${ol(3)}/><rect x="${x-13}" y="165" width="22" height="7" rx="3" fill="${shade(col,.3)}" ${ol(2.5)}/>`).join('');},
 flippers(c,col){col=col||'#ffd23f';return pawXs(c).map((x,i)=>{const g=i%2?1:-1;return `<path d="M${x-9} 182 L${x+g*6-16} 200 Q${x+g*3} 208 ${x+g*6+16} 200 L${x+9} 182 Z" fill="${col}" ${ol(3)}/><path d="M${x+g*3-6} 196 l-2 6 M${x+g*3+6} 196 l2 6" ${st(shade(col,-.2),2,1)}/>`;}).join('');},
 rocket(c){return pawXs(c).map((x,i)=>`<path class="flt" style="animation-delay:${i*.3}s" d="M${x-8} 196 Q${x} 214 ${x+8} 196 Z" fill="#ff8a3c" ${ol(2)}/><path d="M${x-4} 196 Q${x} 206 ${x+4} 196 Z" fill="#ffe066"/><rect x="${x-13}" y="174" width="26" height="23" rx="7" fill="#c9d2e3" ${ol(3)}/><rect x="${x-13}" y="182" width="26" height="6" fill="#e8423a"/>`).join('');},
 moon(c){return pawXs(c).map(x=>`<rect x="${x-14}" y="170" width="28" height="26" rx="9" fill="#ffffff" ${ol(3)}/><path d="M${x-14} 180 h28 M${x-14} 188 h28" ${st('#aab3c0',3,1)}/>`).join('');}
};
/* things behind the body */
const BACK={
 windkey(c){const x=100-c.bw+4,y=c.by-8;return `<g class="tail" style="transform-origin:${x}px ${y}px"><rect x="${x-26}" y="${y-4}" width="28" height="8" rx="3" fill="#d9a83a" ${ol(3)}/><path d="M${x-26} ${y} c-10 -22 -26 -10 -18 0 c-8 10 8 22 18 0 Z" fill="#ffd27a" ${ol(3)}/></g>`;},
 rocketpack(c){let s='';for(const g of[-1,1]){const x=100+g*(c.bw+(c.L.wool||c.L.fluffy?12:3)),y=c.by-c.bh-4;s+=`<path class="flt" d="M${x-8} ${y+46} Q${x} ${y+74} ${x+8} ${y+46} Z" fill="#ff8a3c" ${ol(3)}/><path d="M${x-4} ${y+48} Q${x} ${y+62} ${x+4} ${y+48} Z" fill="#ffe066"/><rect x="${x-11}" y="${y}" width="22" height="46" rx="10" fill="#e8423a" ${ol(3)}/><path d="M${x-11} ${y+14} h22" ${st('#fff',4,1)}/>`;}return s;},
 airtank(c){const x=100-c.bw-2,y=c.by-c.bh-8;return `<rect x="${x-12}" y="${y}" width="24" height="56" rx="11" fill="#ffd23f" ${ol(3)}/><rect x="${x-5}" y="${y-8}" width="10" height="10" fill="#8a8f99" ${ol(2.5)}/>`;},
 stego(c){let s='';for(let i=0;i<6;i++){const a=-1.6+i*.36,ca=Math.cos(a),sa=Math.sin(a),bx=100+ca*c.bw*.98,by=c.by+sa*c.bh*.98,nx=ca/c.bw,ny=sa/c.bh,nl=Math.hypot(nx,ny),ux=nx/nl,uy=ny/nl,h=36+Math.sin(i/5*Math.PI)*10,w=11;
   s+=`<path d="M${(bx-uy*w).toFixed(1)} ${(by+ux*w).toFixed(1)} L${(bx+ux*h*.7-uy*w*.7).toFixed(1)} ${(by+uy*h*.7+ux*w*.7).toFixed(1)} L${(bx+ux*h).toFixed(1)} ${(by+uy*h).toFixed(1)} L${(bx+ux*h*.7+uy*w*.7).toFixed(1)} ${(by+uy*h*.7-ux*w*.7).toFixed(1)} L${(bx+uy*w).toFixed(1)} ${(by-ux*w).toFixed(1)} Z" fill="#3fae5a" ${ol(3)}/>`;}return s;},
 saturn(c){const by=c.by+6,rx=c.bw+22;return `<ellipse cx="100" cy="${by}" rx="${rx}" ry="15" ${st(K,13,1)}/><ellipse cx="100" cy="${by}" rx="${rx}" ry="15" ${st('#e0b85a',7,1)}/>`;},
 frill(c){const cx=c.cx,cy=c.cy-c.hh*.25,r=c.hw*1.38;let d='';for(let i=0;i<=12;i++){const a=Math.PI*(1.02+i*.08),rr=i%2?r:r*.88;d+=(i?' L':'M')+(cx+Math.cos(a)*rr).toFixed(1)+' '+(cy+Math.sin(a)*rr*.9).toFixed(1);}return `<path d="${d} Z" fill="#ffc46b" ${ol(4)}/>`;}
};

/* ---------------- props, drawn round (0,0); ground props stand on y=+20 ---------------- */
const P=(d,f,w)=>`<path d="${d}" fill="${f}" ${ol(w)}/>`;
function spiral(r,turns,col,w){let d='M0 0';for(let i=1;i<=turns*14;i++){const a=i*Math.PI/7,rr=r*i/(turns*14);d+=` L${(Math.cos(a)*rr).toFixed(1)} ${(Math.sin(a)*rr).toFixed(1)}`;}return `<path d="${d}" ${st(col,w,1)}/>`;}
const PROP={
 honeypot:P('M-14 -6 q-5 16 2 26 h24 q7 -10 2 -26 Z','#e8a83a')+`<rect x="-16" y="-13" width="32" height="9" rx="4" fill="#c98a2e" ${ol(2.5)}/><path d="M-7 -4 q0 10 3 10 q3 0 3 -10" fill="#ffd23f"/><path d="M8 -10 l8 -16" ${st('#8a5a32',3,1)}/>`,
 bee:`<ellipse cx="-4" cy="-8" rx="6" ry="8" fill="#fff" fill-opacity=".85" ${ol(1.8)}/><ellipse cx="4" cy="-8" rx="6" ry="8" fill="#fff" fill-opacity=".85" ${ol(1.8)}/><ellipse cx="0" cy="0" rx="10" ry="7" fill="#ffd23f" ${ol(2.2)}/><path d="M-3 -6 v12 M3 -6 v12" ${st(K,3,1)}/><circle cx="8" cy="-1" r="1.6" fill="${K}"/>`,
 butterfly:`<g class="flt"><ellipse cx="-7" cy="-5" rx="8" ry="7" fill="#7fc8f0" ${ol(2)}/><ellipse cx="7" cy="-5" rx="8" ry="7" fill="#7fc8f0" ${ol(2)}/><ellipse cx="-5" cy="5" rx="5" ry="5" fill="#ff9ecb" ${ol(2)}/><ellipse cx="5" cy="5" rx="5" ry="5" fill="#ff9ecb" ${ol(2)}/><path d="M0 -8 v16" ${st(K,3,1)}/></g>`,
 ladybird:P('M-11 4 a11 11 0 0 1 22 0 Z','#e8423a',2.2)+`<circle cx="-4" cy="-1" r="2" fill="${K}"/><circle cx="4" cy="-3" r="2" fill="${K}"/><circle cx="3" cy="2" r="1.6" fill="${K}"/><circle cx="-12" cy="2" r="4" fill="${K}"/>`,
 basket:`<path d="M-18 0 q18 -32 36 0" ${st(K,7,1)}/><path d="M-18 0 q18 -32 36 0" ${st('#c98a4f',4,1)}/>`+P('M-20 0 h40 l-5 20 h-30 Z','#c98a4f')+`<path d="M-17 7 h34 M-15 14 h30" ${st('#8a5a32',2,1)}/><path d="M-12 0 l6 -7 l6 7 l6 -7 l6 7" fill="#e8423a" ${ol(1.6)}/>`,
 mug:P('M-12 -6 h20 v22 q0 4 -4 4 h-12 q-4 0 -4 -4 Z','#e8423a')+`<path d="M8 0 q10 0 10 7 q0 7 -10 7" ${st(K,5,1)}/><path d="M8 0 q10 0 10 7 q0 7 -10 7" ${st('#e8423a',2.5,1)}/><ellipse cx="-2" cy="-6" rx="10" ry="3" fill="#8a5a32"/><circle cx="-5" cy="-8" r="3.5" fill="#fff" ${ol(1.4)}/><circle cx="2" cy="-8" r="3.5" fill="#ffd6e6" ${ol(1.4)}/><path d="M-4 -14 q3 -5 0 -10 M3 -14 q3 -5 0 -10" ${st('#fff',2.5,.8)}/>`,
 sledge:`<path d="M-24 18 h44 q8 0 8 -8" ${st(K,6,1)}/><path d="M-24 18 h44 q8 0 8 -8" ${st('#c9d2e3',3,1)}/>`+P('M-22 2 h40 v8 h-40 Z','#c98a4f')+`<path d="M-16 10 v8 M12 10 v8" ${st(K,3,1)}/><path d="M-22 6 h40" ${st('#8a5a32',2,1)}/><path d="M20 2 q10 -10 4 -22" ${st('#e8423a',3,1)}/>`,
 snowboard:P('M-8 -42 q8 -8 16 0 v56 q-8 8 -16 0 Z','#5b8def')+`<path d="M-8 -18 l16 -8 M-8 -4 l16 -8" ${st('#ffd23f',4,1)}/>`,
 snowball:`<circle cx="0" cy="10" r="11" fill="#fff" ${ol(2.6)}/><path d="M-6 6 a5 5 0 0 1 5 -4" ${st('#c9d6e6',2.5,1)}/>`,
 bucket:P('M-13 -2 h26 l-3 22 h-20 Z','#ff6a6a')+`<path d="M-13 -2 q13 -18 26 0" ${st(K,2.5,1)}/><ellipse cx="0" cy="-2" rx="13" ry="3.5" fill="#f3d99a" ${ol(2)}/><path d="M8 -4 l10 -24" ${st(K,6,1)}/><path d="M8 -4 l10 -24" ${st('#ffd23f',3,1)}/>`+P('M15 -36 l8 3 l-3 9 l-8 -3 Z','#5b8def',2),
 surfboard:P('M-9 -48 Q0 -60 9 -48 L9 14 Q0 22 -9 14 Z','#2fb3b3')+`<path d="M0 -52 V18" ${st('#ffffff',4,1)}/><path d="M-9 -12 Q0 -16 9 -12" ${st('#ff7f9a',4,1)}/>`,
 starfish:star5(0,0,13,'#ff8a3c',K)+`<circle cx="-3" cy="-3" r="1.4" fill="#fff"/><circle cx="3" cy="2" r="1.4" fill="#fff"/>`,
 octopus:`<path d="M-10 4 q-4 10 -10 8 M-4 6 q-2 10 -6 14 M4 6 q2 10 6 14 M10 4 q4 10 10 8" ${st(K,6,1)}/><path d="M-10 4 q-4 10 -10 8 M-4 6 q-2 10 -6 14 M4 6 q2 10 6 14 M10 4 q4 10 10 8" ${st('#b58cff',3.5,1)}/><ellipse cx="0" cy="-4" rx="13" ry="12" fill="#b58cff" ${ol(2.6)}/><circle cx="-4" cy="-4" r="2.2" fill="${K}"/><circle cx="4" cy="-4" r="2.2" fill="${K}"/>`,
 lantern:`<circle class="glow" cx="0" cy="0" r="20" fill="#ffb347" opacity=".45"/><path d="M0 -26 v8" ${st(K,2.5,1)}/>`+P('M-10 -18 Q-17 0 -10 16 h20 Q17 0 10 -18 Z','#e8423a')+`<rect x="-8" y="-21" width="16" height="5" fill="#ffd23f" ${ol(2)}/><rect x="-8" y="15" width="16" height="5" fill="#ffd23f" ${ol(2)}/><path d="M-12 -6 h24 M-13 4 h26" ${st('#ffb347',2,1)}/>`,
 bostaff:`<path d="M2 -70 L-2 20" ${st(K,8,1)}/><path d="M2 -70 L-2 20" ${st('#c9b26a',5,1)}/><path d="M1.5 -48 h-4 M0.8 -24 h-4 M0 0 h-4" ${st('#8a7a3a',2,1)}/>`,
 fan:`<path d="M0 10 L-22 -10 A30 30 0 0 1 22 -10 Z" fill="#e8423a" ${ol(2.6)}/><path d="M0 10 L-11 -17 M0 10 L0 -20 M0 10 L11 -17" ${st('#ffd23f',2,1)}/><circle cx="0" cy="-6" r="5" fill="#fff" opacity=".85"/>`,
 kite:`<path d="M0 -18 L14 0 L0 22 L-14 0 Z" fill="#e8423a" ${ol(2.6)}/><path d="M0 -18 V22 M-14 0 H14" ${st('#ffd23f',2,1)}/><path d="M0 22 q6 10 -2 18 q-8 8 0 16" ${st(K,2,1)}/><path d="M-2 30 l-5 -2 M-1 44 l5 2" ${st('#3fae5a',3,1)}/>`,
 noodles:P('M-18 0 h36 q-2 18 -18 18 q-16 0 -18 -18 Z','#fff')+`<path d="M-12 6 h24" ${st('#e8423a',3,1)}/><path d="M-12 0 q4 -6 8 0 t8 0 t8 0" ${st('#ffd27a',3,1)}/><path d="M6 -2 l12 -24 M10 -2 l12 -22" ${st('#8a5a32',3,1)}/>`,
 calc:`<rect x="-14" y="-24" width="28" height="44" rx="5" fill="#8a8f99" ${ol(2.6)}/><rect x="-10" y="-20" width="20" height="10" rx="2" fill="#bfe8a0" ${ol(1.6)}/><text x="8" y="-12" font-size="8" font-weight="900" text-anchor="end" fill="${K}" font-family="Arial">56</text>`+[0,1,2,3].map(r=>[0,1,2].map(q=>`<rect x="${-10+q*7}" y="${-6+r*6.5}" width="5.5" height="5" rx="1" fill="${q===2&&r===3?'#ff8a3c':'#fff'}"/>`).join('')).join(''),
 dice:`<rect x="-20" y="2" width="18" height="18" rx="4" fill="#fff" ${ol(2.4)}/><circle cx="-15" cy="7" r="1.8" fill="${K}"/><circle cx="-11" cy="11" r="1.8" fill="${K}"/><circle cx="-7" cy="15" r="1.8" fill="${K}"/><rect x="2" y="2" width="18" height="18" rx="4" fill="#ff4f6d" ${ol(2.4)}/><circle cx="7" cy="7" r="1.8" fill="#fff"/><circle cx="15" cy="7" r="1.8" fill="#fff"/><circle cx="7" cy="15" r="1.8" fill="#fff"/><circle cx="15" cy="15" r="1.8" fill="#fff"/>`,
 ruler:`<rect x="-7" y="-44" width="14" height="64" rx="2" fill="#ffd23f" ${ol(2.6)}/>`+[...Array(9)].map((_,i)=>`<path d="M-7 ${-38+i*7} h${i%2?4:7}" ${st(K,1.6,1)}/>`).join('')+`<text x="3" y="-30" font-size="6" font-weight="900" fill="${K}" font-family="Arial">1</text><text x="3" y="-16" font-size="6" font-weight="900" fill="${K}" font-family="Arial">2</text><text x="3" y="-2" font-size="6" font-weight="900" fill="${K}" font-family="Arial">3</text>`,
 abacus:`<rect x="-20" y="-16" width="40" height="36" rx="3" fill="none" ${ol(5)}/><rect x="-20" y="-16" width="40" height="36" rx="3" fill="none" stroke="#c98a4f" stroke-width="3"/>`+[0,1,2].map(r=>`<path d="M-18 ${-6+r*10} h36" ${st(K,1.6,1)}/>`+[0,1,2,3].map(q=>`<circle cx="${-13+q*6+(r===1?8:0)}" cy="${-6+r*10}" r="3.2" fill="${['#e8423a','#ffd23f','#3fae5a'][r]}" ${ol(1.4)}/>`).join('')).join(''),
 rubik:`<path d="M0 -16 L16 -8 L16 12 L0 20 L-16 12 L-16 -8 Z" fill="#fff" ${ol(2.6)}/>`+[['#e8423a',[[0,-16],[16,-8],[0,0],[-16,-8]]],['#3fae5a',[[-16,-8],[0,0],[0,20],[-16,12]]],['#5b8def',[[0,0],[16,-8],[16,12],[0,20]]]].map(f=>{const q=f[1];let s=`<path d="M${q.map(p=>p.join(' ')).join(' L')} Z" fill="${f[0]}" ${ol(2)}/>`;
   for(const t of[1/3,2/3]){const a=[q[0][0]+(q[1][0]-q[0][0])*t,q[0][1]+(q[1][1]-q[0][1])*t],b=[q[3][0]+(q[2][0]-q[3][0])*t,q[3][1]+(q[2][1]-q[3][1])*t],c2=[q[0][0]+(q[3][0]-q[0][0])*t,q[0][1]+(q[3][1]-q[0][1])*t],d=[q[1][0]+(q[2][0]-q[1][0])*t,q[1][1]+(q[2][1]-q[1][1])*t];s+=`<path d="M${a.join(' ')} L${b.join(' ')} M${c2.join(' ')} L${d.join(' ')}" ${st(K,1.6,1)}/>`;}return s;}).join(''),
 robot:`<path d="M0 -24 v-6" ${st(K,2.5,1)}/><circle cx="0" cy="-31" r="3.5" fill="#ff4f6d" ${ol(1.6)}/><rect x="-11" y="-24" width="22" height="16" rx="4" fill="#c9d2e3" ${ol(2.4)}/><circle cx="-5" cy="-16" r="3" fill="#5cb8ff"/><circle cx="5" cy="-16" r="3" fill="#5cb8ff"/><rect x="-13" y="-6" width="26" height="20" rx="4" fill="#8a8fe0" ${ol(2.4)}/><circle cx="0" cy="4" r="4" fill="#ffd23f" ${ol(1.6)}/><rect x="-10" y="14" width="7" height="6" fill="#6b7480" ${ol(1.6)}/><rect x="3" y="14" width="7" height="6" fill="#6b7480" ${ol(1.6)}/>`,
 spanner:`<path d="M-4 18 L8 -18" ${st(K,9,1)}/><path d="M-4 18 L8 -18" ${st('#aab3c0',5,1)}/><path d="M2 -20 a10 10 0 1 1 14 4 l-5 -6 l-5 2 Z" fill="#aab3c0" ${ol(2.4)}/>`,
 torch:`<path d="M6 -14 L40 -34 L40 6 Z" fill="#fff6a8" opacity=".55"/>`+P('M-14 -18 h14 l8 -4 v16 l-8 -4 h-14 Z','#ffd23f')+`<rect x="-16" y="-20" width="4" height="12" fill="#3a3640"/>`,
 firstaid:P('M-17 -10 h34 v28 h-34 Z','#3fae5a')+`<path d="M-7 -10 q0 -8 7 -8 q7 0 7 8" ${st(K,3,1)}/><path d="M0 -4 v16 M-8 4 h16" ${st('#fff',5,1)}/>`,
 rescuetube:P('M-10 -30 q10 -6 20 0 v44 q-10 6 -20 0 Z','#e8423a')+`<path d="M-10 -14 h20 M-10 2 h20" ${st('#fff',3,1)}/><path d="M10 -24 q14 6 8 26" ${st(K,2,1)}/>`,
 rope:[16,11,6].map((r,i)=>`<ellipse cx="0" cy="${10-i*2}" rx="${r}" ry="${r*.55}" fill="none" ${ol(6)}/><ellipse cx="0" cy="${10-i*2}" rx="${r}" ry="${r*.55}" fill="none" stroke="#d9b45a" stroke-width="3.5" stroke-dasharray="3 2"/>`).join(''),
 bone:`<path d="M-16 0 H16" ${st(K,9,1)}/><path d="M-16 0 H16" ${st('#fff8e6',5,1)}/>`+[-1,1].map(g=>`<circle cx="${g*17}" cy="-4" r="5" fill="#fff8e6" ${ol(2.2)}/><circle cx="${g*17}" cy="4" r="5" fill="#fff8e6" ${ol(2.2)}/>`).join(''),
 bigbone:`<g transform="rotate(-60)"><path d="M-22 0 H22" ${st(K,11,1)}/><path d="M-22 0 H22" ${st('#f2ead2',7,1)}/>`+[-1,1].map(g=>`<circle cx="${g*23}" cy="-5" r="6.5" fill="#f2ead2" ${ol(2.4)}/><circle cx="${g*23}" cy="5" r="6.5" fill="#f2ead2" ${ol(2.4)}/>`).join('')+'</g>',
 spade:`<path d="M0 -40 V2" ${st(K,7,1)}/><path d="M0 -40 V2" ${st('#c98a4f',4,1)}/><rect x="-7" y="-46" width="14" height="6" rx="3" fill="#c98a4f" ${ol(2)}/>`+P('M-10 2 h20 v8 q0 10 -10 12 q-10 -2 -10 -12 Z','#aab3c0'),
 brush:`<path d="M-2 18 L6 -10" ${st(K,7,1)}/><path d="M-2 18 L6 -10" ${st('#c98a4f',4,1)}/>`+P('M2 -10 l10 3 l-4 -16 q-4 -3 -8 -1 Z','#f2d27a',2.2),
 ammonite:`<circle cx="0" cy="4" r="16" fill="#c9b8a0" ${ol(2.6)}/>`+spiral(14,2.4,'#8a7a62',2.4)+`<g transform="translate(0 4)">${spiral(14,2.4,'#8a7a62',2.4).replace('M0 0','M0 0')}</g>`.slice(0,0),
 egg:`<ellipse cx="0" cy="4" rx="13" ry="17" fill="#e6f2d6" ${ol(2.6)}/><circle cx="-4" cy="-4" r="2.5" fill="#8fbf5a"/><circle cx="5" cy="4" r="3" fill="#8fbf5a"/><circle cx="-3" cy="12" r="2" fill="#8fbf5a"/>`,
 comet:`<path d="M2 2 L-30 22" ${st('#ffe066',9,.5)}/><path d="M2 2 L-26 16" ${st('#fff',4,.8)}/>`+star5(4,0,10,'#ffe066',K),
 apple:`<path d="M-28 -16 l-6 -8 M-20 -20 l-2 -9 M-34 -8 l-9 -3" ${st(K,2.5,.6)}/><path d="M0 -10 C-20 -22 -24 10 -8 14 C-4 16 4 16 8 14 C24 10 20 -22 0 -10 Z" fill="#e8423a" ${ol(3.5)}/><path d="M0 -10 q1 -9 5 -12" ${st('#6b4428',3.5,1)}/><ellipse cx="10" cy="-18" rx="8" ry="4" fill="#3fae5a" ${ol(2.5)} transform="rotate(-25 10 -18)"/><ellipse cx="-9" cy="-3" rx="3.5" ry="5" fill="#fff" opacity=".55"/>`,
 peanuts:[-1,1].map(g=>`<g transform="translate(${g*9} ${8-g*4}) rotate(${g*25})"><path d="M0 -12 c7 0 8 7 4 10 c4 3 3 12 -4 12 c-7 0 -8 -9 -4 -12 c-4 -3 -3 -10 4 -10 Z" fill="#e6c08a" ${ol(2.2)}/><path d="M-3 -6 l2 1 M1 4 l2 1" ${st('#b8925a',1.6,1)}/></g>`).join(''),
 peapod:`<path d="M-22 6 Q0 -16 22 -4 Q4 18 -22 6 Z" fill="#6fbf4a" ${ol(2.6)}/>`+[-12,-4,4,12].map(x=>`<circle cx="${x}" cy="${2-x*.15}" r="4.6" fill="#a8e070" ${ol(1.6)}/>`).join('')+`<path d="M22 -4 q6 -4 8 -12" ${st('#3f8a3a',3,1)}/>`,
 magnifier:`<path d="M6 8 L18 22" ${st(K,9,1)}/><path d="M6 8 L18 22" ${st('#8a5a32',5,1)}/><circle cx="-4" cy="-4" r="14" fill="#d6f1ff" fill-opacity=".6" stroke="#aab3c0" stroke-width="5"/><circle cx="-4" cy="-4" r="16.5" ${st(K,2,1)}/><path d="M-11 -9 a8 8 0 0 1 6 -4" ${st('#fff',3,1)}/>`,
 finch:`<ellipse cx="0" cy="0" rx="10" ry="8" fill="#c98a4f" ${ol(2.2)}/><circle cx="7" cy="-6" r="6" fill="#c98a4f" ${ol(2.2)}/><path d="M12 -6 l7 2 l-7 3 Z" fill="#ffb347" ${ol(1.6)}/><circle cx="8" cy="-7" r="1.4" fill="${K}"/><path d="M-9 -2 l-9 -4 l2 7 Z" fill="#8a5a32" ${ol(1.6)}/>`,
 telescope:`<path d="M-14 20 L0 -2 L14 20 M0 -2 V20" ${st(K,3,1)}/><g transform="rotate(-35)"><rect x="-26" y="-9" width="44" height="13" rx="3" fill="#c98a2e" ${ol(2.6)}/><rect x="18" y="-11" width="10" height="17" rx="3" fill="#8a5a32" ${ol(2.4)}/><path d="M-12 -9 v13 M4 -9 v13" ${st('#8a5a32',2,1)}/></g>`,
 thermometer:`<rect x="-6" y="-44" width="12" height="54" rx="6" fill="#fff" ${ol(2.6)}/><circle cx="0" cy="12" r="9" fill="#e8423a" ${ol(2.6)}/><rect x="-2.5" y="-20" width="5" height="30" fill="#e8423a"/>`+[...Array(6)].map((_,i)=>`<path d="M6 ${-36+i*8} h-4" ${st(K,1.6,1)}/>`).join(''),
 cloud:`<path d="M0 -6 V22" ${st(K,6,1)}/><path d="M0 -6 V22" ${st('#c98a4f',3,1)}/><g transform="translate(0 -18)"><ellipse cx="0" cy="0" rx="20" ry="9" fill="#fff" ${ol(2.4)}/><circle cx="-8" cy="-6" r="8" fill="#fff" ${ol(2.4)}/><circle cx="5" cy="-9" r="10" fill="#fff" ${ol(2.4)}/><ellipse cx="0" cy="2" rx="18" ry="6" fill="#fff"/></g>`,
 camera:`<path d="M-14 20 L-2 4 L10 20" ${st(K,3,1)}/><rect x="-18" y="-14" width="22" height="20" rx="3" fill="#3a3640" ${ol(2.4)}/>`+P('M4 -12 l10 -4 v24 l-10 -4 Z','#8a5a32',2.2)+`<circle cx="16" cy="-4" r="4" fill="#9be8ff" ${ol(2)}/><rect x="-14" y="-20" width="8" height="6" fill="#aab3c0" ${ol(1.6)}/>`,
 duck:`<ellipse cx="0" cy="8" rx="15" ry="10" fill="#ffd23f" ${ol(2.6)}/><circle cx="7" cy="-6" r="9" fill="#ffd23f" ${ol(2.6)}/><path d="M14 -6 l9 2 l-9 4 Z" fill="#ff8a3c" ${ol(1.8)}/><circle cx="9" cy="-8" r="1.8" fill="${K}"/><path d="M-12 4 q-6 -8 2 -8" fill="#ffd23f" ${ol(2)}/>`,
 notebook:`<rect x="-14" y="-18" width="28" height="36" rx="3" fill="#7fc8f0" ${ol(2.6)}/><rect x="-10" y="-14" width="20" height="28" fill="#fff"/><path d="M-6 0 q4 -6 8 0 q2 -4 4 -2" ${st(K,1.8,1)}/><path d="M-7 6 h14 M-7 10 h10" ${st('#aab3c0',1.6,1)}/><path d="M12 14 L24 -12" ${st(K,5,1)}/><path d="M12 14 L24 -12" ${st('#ffd23f',2.6,1)}/>`,
 map:`<path d="M-20 -14 h34 v30 h-34 Z" fill="#fff3d0" ${ol(2.4)}/><path d="M-16 -4 q6 -6 10 2 t12 0 t10 -4 M-16 6 q8 4 14 -2 t14 4" ${st('#3d8fe0',2,1)}/><path d="M-6 -10 l4 6 l4 -4" ${st('#8a5a32',1.8,1)}/><ellipse cx="16" cy="1" rx="6" ry="16" fill="#f2e0b0" ${ol(2.4)}/>`,
 magnet:`<path d="M-14 -2 V-16 a14 14 0 0 1 28 0 V-2" ${st(K,13,1)}/><path d="M-14 -2 V-16 a14 14 0 0 1 28 0 V-2" ${st('#e8423a',8,1)}/><rect x="-18" y="-6" width="9" height="9" fill="#e6eaf0" ${ol(2)}/><rect x="9" y="-6" width="9" height="9" fill="#e6eaf0" ${ol(2)}/>`+star4(-20,12,5,'#ffd23f','twk')+star4(20,12,5,'#ffd23f','twk',.5),
 flask:`<circle class="glow" cx="0" cy="8" r="20" fill="#9bff8a" opacity=".3"/><path d="M-5 -24 v14 a14 14 0 1 0 10 0 v-14 Z" fill="#eefaff" fill-opacity=".85" ${ol(2.6)}/><path d="M-12 8 a12 12 0 0 0 24 0 Z" fill="#5cf07a"/><circle cx="-3" cy="2" r="2.4" fill="#fff"/><circle cx="3" cy="-4" r="1.6" fill="#fff"/><rect x="-7" y="-28" width="14" height="5" rx="2" fill="#c9a070" ${ol(1.8)}/>`,
 tesla:`<rect x="-12" y="10" width="24" height="10" rx="2" fill="#8a5a32" ${ol(2.4)}/><rect x="-6" y="-24" width="12" height="34" fill="#c98a2e" ${ol(2.4)}/>`+[...Array(6)].map((_,i)=>`<path d="M-6 ${-20+i*5} h12" ${st('#8a5a32',1.6,1)}/>`).join('')+`<circle cx="0" cy="-30" r="8" fill="#c9d2e3" ${ol(2.4)}/><path d="M6 -34 l8 -4 l-3 6 l9 -3" ${st('#8fd0ff',2.6,1)}/><path d="M-6 -34 l-8 -6 l2 6 l-9 -2" ${st('#8fd0ff',2.6,1)}/>`,
 dragonjar:`<path d="M-14 20 h28 l-2 -8 q6 -18 -4 -30 h-16 q-10 12 -4 30 Z" fill="#c98a2e" ${ol(2.6)}/><rect x="-10" y="-22" width="20" height="5" fill="#8a5a32" ${ol(1.8)}/><path d="M-14 -6 l-6 -3 l2 6 Z M14 -6 l6 -3 l-2 6 Z" fill="#3fae5a" ${ol(1.8)}/><circle cx="-19" cy="-2" r="2.6" fill="#ffd23f" ${ol(1.4)}/><circle cx="0" cy="22" r="0" fill="none"/><path d="M-20 22 a5 4 0 0 1 10 0 Z" fill="#3fae5a" ${ol(1.6)}/>`,
 punchcards:`<rect x="-18" y="-10" width="30" height="20" rx="2" fill="#f2e0b0" ${ol(2.2)} transform="rotate(-8)"/><rect x="-14" y="-6" width="30" height="20" rx="2" fill="#fff3d0" ${ol(2.2)}/>`+[...Array(8)].map((_,i)=>`<rect x="${-11+(i%4)*7}" y="${-2+Math.floor(i/4)*7+(i%3)}" width="3" height="4" fill="${K}"/>`).join('')+`<g transform="translate(14 14)">${[...Array(8)].map((_,i)=>`<rect x="-2" y="-10" width="4" height="5" fill="#c98a2e" transform="rotate(${i*45})"/>`).join('')}<circle r="7" fill="#c98a2e" ${ol(2)}/><circle r="2.5" fill="#fff"/></g>`,
 shell:`<path d="M-16 10 Q-20 -14 4 -16 Q20 -14 16 4 Q12 18 -4 16 Q-12 15 -16 10 Z" fill="#ffd2a8" ${ol(2.6)}/>`+spiral(12,1.6,'#e8823a',2.6),
 sunflower:`<path d="M0 -10 V22" ${st('#3f8a3a',4,1)}/><ellipse cx="6" cy="10" rx="7" ry="3.5" fill="#6fbf4a" ${ol(1.8)} transform="rotate(-30 6 10)"/>`+[...Array(10)].map((_,i)=>`<ellipse cx="0" cy="-26" rx="4" ry="9" fill="#ffd23f" ${ol(1.6)} transform="rotate(${i*36} 0 -18)"/>`).join('')+`<circle cx="0" cy="-18" r="8" fill="#8a5a32" ${ol(2)}/>`,
 setsquare:`<path d="M-18 18 L-18 -22 L18 18 Z" fill="#9be8ff" fill-opacity=".7" ${ol(2.6)}/><path d="M-12 12 L-12 -6 L6 12 Z" fill="#fffdf6"/><path d="M-18 12 h5 v6" ${st(K,1.6,1)}/>`,
 chalk:`<path d="M-20 20 L-14 4 M20 20 L14 4" ${st('#8a5a32',3,1)}/><rect x="-22" y="-26" width="44" height="32" rx="2" fill="#2e4a3e" stroke="#8a5a32" stroke-width="4"/><rect x="-22" y="-26" width="44" height="32" rx="2" fill="none" ${ol(1.6)}/>`,
 paintbrush:`<ellipse cx="-4" cy="10" rx="18" ry="11" fill="#f2d27a" ${ol(2.4)}/><circle cx="-12" cy="8" r="3" fill="#e8423a"/><circle cx="-4" cy="4" r="3" fill="#5b8def"/><circle cx="4" cy="8" r="3" fill="#3fae5a"/><circle cx="-6" cy="14" r="3.5" fill="#fffdf6" ${ol(1.6)}/><path d="M6 6 L20 -22" ${st(K,6,1)}/><path d="M6 6 L20 -22" ${st('#c98a4f',3,1)}/><path d="M18 -18 l6 -12" ${st('#e8423a',5,1)}/>`,
 testtube:`<circle class="glow" cx="0" cy="8" r="20" fill="#9bff8a" opacity=".45"/><g transform="rotate(12)"><path d="M-7 -26 v40 a7 7 0 0 0 14 0 v-40" fill="#eefaff" fill-opacity=".85" ${ol(3)}/><path d="M-6 -2 v16 a6 6 0 0 0 12 0 v-16 Z" fill="#5cf07a"/><rect x="-10" y="-30" width="20" height="6" rx="3" fill="#c9d2e3" ${ol(2.5)}/></g>`+star4(14,-22,5,'#9bff8a','twk')+star4(-14,-14,4,'#fff','twk',.5),
 phone:`<ellipse cx="0" cy="18" rx="12" ry="4" fill="#26232e" ${ol(2.2)}/><path d="M-3 16 V-14 h6 V16 Z" fill="#26232e" ${ol(2)}/><path d="M-8 -22 h16 l-3 8 h-10 Z" fill="#26232e" ${ol(2)}/><path d="M-6 -4 q-12 -2 -12 -12" ${st(K,3,1)}/><path d="M-20 -14 a5 5 0 0 1 4 -6 l4 8 Z" fill="#26232e" ${ol(2)}/><circle cx="0" cy="-22" r="0"/><path d="M14 -6 q6 -4 0 -10 M18 -2 q10 -8 0 -18" ${st('#5b8def',2.2,.8)}/>`,
 plane:`<g class="flt"><rect x="-16" y="-4" width="30" height="8" rx="4" fill="#e8423a" ${ol(2.2)}/><rect x="-6" y="-16" width="8" height="32" rx="2" fill="#f2d27a" ${ol(2)}/><rect x="-12" y="-14" width="5" height="28" rx="2" fill="#f2d27a" ${ol(2)}/><path d="M16 -8 v16" ${st(K,2.5,1)}/><path d="M-16 0 l-6 -6 v12 Z" fill="#e8423a" ${ol(1.8)}/></g>`,
 lamp:`<circle class="glow" cx="0" cy="-6" r="22" fill="#ffe680" opacity=".5"/><path d="M-12 14 h24 q-2 -10 -12 -10 q-10 0 -12 10 Z" fill="#c98a2e" ${ol(2.4)}/><path d="M-6 4 q6 -18 12 0" fill="#fff3a0" ${ol(2)}/><path d="M0 -4 q-4 -8 0 -14 q4 6 0 14 Z" fill="#ff8a3c"/><path d="M12 10 q10 -2 8 8" ${st(K,2.6,1)}/>`,
 petri:`<ellipse cx="0" cy="8" rx="20" ry="9" fill="#eefaff" fill-opacity=".9" ${ol(2.6)}/><ellipse cx="0" cy="6" rx="16" ry="6" fill="#f6f0c8"/><circle cx="-6" cy="6" r="3.5" fill="#6fbf4a"/><circle cx="5" cy="4" r="2.5" fill="#8fd0ff"/><circle cx="8" cy="8" r="2" fill="#6fbf4a"/>`,
 tooth:`<path d="M-9 -20 Q-12 4 0 22 Q12 4 9 -20 Q0 -24 -9 -20 Z" fill="#fff8e6" ${ol(2.6)}/><path d="M-4 -12 q2 14 2 22" ${st('#d8cba8',2,1)}/>`,
 fossilbasket:P('M-18 0 h36 l-4 20 h-28 Z','#c98a4f')+`<path d="M-18 0 q18 -30 36 0" ${st(K,6,1)}/><path d="M-18 0 q18 -30 36 0" ${st('#c98a4f',3.5,1)}/><path d="M-16 8 h32 M-15 14 h30" ${st('#8a5a32',2,1)}/><circle cx="2" cy="-2" r="9" fill="#c9b8a0" ${ol(2)}/><g transform="translate(2 -2)">${spiral(8,2,'#8a7a62',1.8)}</g>`,
 orrery:`<path d="M0 20 V2" ${st(K,4,1)}/><ellipse cx="0" cy="20" rx="12" ry="3.5" fill="#c98a2e" ${ol(2)}/><ellipse cx="0" cy="-10" rx="26" ry="9" ${st('#c98a2e',2,1)}/><circle cx="0" cy="-10" r="8" fill="#ffd23f" ${ol(2.2)}/><circle cx="-24" cy="-12" r="4" fill="#5b8def" ${ol(1.6)}/><circle cx="20" cy="-5" r="3.5" fill="#e8423a" ${ol(1.6)}/><circle cx="8" cy="-18" r="3" fill="#8fe39a" ${ol(1.6)}/>`,
 blackhole:`<g class="bh"><circle cx="0" cy="0" r="12" fill="#241a3d" stroke="#b58cff" stroke-width="4"/><ellipse cx="0" cy="0" rx="22" ry="7" ${st('#ff9ecb',3,1)} transform="rotate(-25)"/></g>`,
 medbag:P('M-16 -8 h32 v24 h-32 Z','#8a5a32')+`<path d="M-8 -8 q0 -8 8 -8 q8 0 8 8" ${st(K,3,1)}/><path d="M0 -2 v12 M-6 4 h12" ${st('#e8423a',4,1)}/>`,
 plasters:`<g transform="rotate(30)"><rect x="-12" y="-4" width="24" height="9" rx="4" fill="#f2c9a0" ${ol(1.8)}/><rect x="-4" y="-3" width="8" height="7" fill="#e8b48a"/></g><g transform="translate(6 10) rotate(-30)"><rect x="-12" y="-4" width="24" height="9" rx="4" fill="#f2c9a0" ${ol(1.8)}/><rect x="-4" y="-3" width="8" height="7" fill="#e8b48a"/></g>`,
 bolt:`<path d="M8 -30 L-14 4 L0 4 L-9 30 L18 -8 L4 -8 Z" fill="#ffd23f" ${ol(3)}/>`,
 flake:`<g ${st('#7fc8f0',4,1)}><path d="M-12 0 h24 M-6 -10 l12 20 M6 -10 l-12 20"/></g>`
};
PROP.ammonite=`<circle cx="0" cy="4" r="16" fill="#c9b8a0" ${ol(2.6)}/><g transform="translate(0 4)">${spiral(14,2.4,'#8a7a62',2.4)}</g>`;
/* where each prop goes: hand (by the front paw), head, friend (by the ear), mouth */
const AT={apple:'head',starfish:'head',octopus:'head',bee:'friend',butterfly:'friend',ladybird:'friend',finch:'friend',kite:'friend',comet:'friend',plane:'friend',blackhole:'friend',bolt:'friend',flake:'friend',plasters:'friend',bone:'mouth'};

/* ---------------- who wears what ----------------
   h hat [kind,colour,opts]; g glasses/face [kind,colour]; b body [kind,colour,opts]; n neck [[kind,colour,opts]...];
   f feet [kind,colour]; k back [kinds]; p props [kinds]; fur [kind,opts]; cos full costume (Spa costume key);
   space a space suit; keep/drop/add accessories; look overrides. */
const OUT={
 // Meadow Island: a light countryside touch
 buttercup:{h:['crown',['#ffd23f','#fff','#ffd23f','#fff27a','#fff','#ffd23f']]},
 barley:{h:['strawhat','#e8423a'],n:[['neckerchief','#e8423a']]},
 honey:{p:['honeypot','bee']},
 cali:{n:[['neckerchief','#3fae5a']],f:['wellies','#e8423a']},
 bumble:{cos:'bee'},
 poppy:{h:['crown',['#e8423a','#ff6a5a','#e8423a','#ff6a5a','#e8423a','#ff6a5a']]},
 hazel:{f:['wellies','#ffd23f'],p:['basket']},
 willow:{p:['ladybird']},
 lily:{h:['crown',['#fff','#ff9ecb','#fff','#ff9ecb','#fff','#ff9ecb']],drop:['bow','flower']},
 dash:{n:[['neckerchief','#3d8fe0']],p:['butterfly']},
 acorn:{h:['acorncap']},
 bluebell:{h:['crown',['#7f9cff','#5b7ae8','#9fb4ff','#5b7ae8','#7f9cff','#5b7ae8']]},
 fern:{cos:'ladybird'},
 // Snowy Summit
 bobble:{h:['beanie','#e8423a'],g:['skigog'],keep:['scarf']},
 teddy:{h:['earmuffs','#a8743a'],keep:['scarf','mittens']},
 muffin:{h:['earmuffs','#ff9ecb'],keep:['scarf']},
 biscuit:{p:['mug'],keep:['scarf','mittens']},
 juniper:{b:['jumper','#ff7fb8',{pat:'nordic'}],drop:['scarf']},
 sledge:{p:['sledge'],keep:['scarf']},
 snowdrop:{cos:'snowman'},
 fjord:{h:['beanie','#3d8fe0'],keep:['scarf']},
 yeti:{g:['skigog'],p:['snowball'],keep:['scarf','mittens']},
 pinecone:{b:['jumper','#3f8a5a',{pat:'nordic'}],drop:['cap']},
 glacier:{g:['skigog'],p:['snowboard'],keep:['scarf']},
 twinkle:{h:['beanie','#b58cff',{pom:'#fff3a0'}],drop:['bow','flake']},
 crystal:{g:['skigog'],keep:['scarf','twinkle']},
 // Coral Reef
 ripple:{p:['surfboard'],keep:['shellneck','bubbles']},
 sandy:{p:['bucket'],h:['sunhat','#7fd3f0']},
 kelp:{add:['ring'],keep:['bubbles']},
 finn:{g:['snorkel'],f:['flippers','#ffd23f'],keep:['bubbles']},
 scallop:{g:['sun'],b:['hawaiian','#ff8a3c'],drop:['shellneck']},
 starla:{p:['starfish'],keep:['shellneck']},
 anchor:{h:['sailor']},
 barnacle:{cos:'pirate'},
 gulliver:{b:['hawaiian','#3fae5a'],drop:['shellneck']},
 inky:{p:['octopus'],keep:['bubbles']},
 marina:{h:['sunhat','#ffd23f'],n:[['lei']]},
 puffin:{cos:'axolotl'},
 opal:{g:['sun','#ff7fb8'],keep:['twinkle','shellneck','bubbles']},
 // Ninja Mountains (six pups already wear ninja suits)
 dumpling:{h:['headband','#e8423a'],p:['lantern'],drop:['bow']},
 bamboo:{p:['bostaff']},
 kite:{h:['headband','#3d8fe0'],p:['kite'],drop:['scarf']},
 noodle:{h:['headband','#ffffff'],p:['noodles'],drop:['mittens']},
 ash:{b:['gi'],n:[['belt','#26232e']],drop:['scarf']},
 zippy:{b:['gi'],n:[['belt','#ffd23f']],drop:['bow']},
 ginger:{h:['headband','#ff7fb8'],p:['fan'],drop:['flower']},
 glimmer:{b:['gi'],n:[['belt','#7a5cd6']],p:['lantern']},
 // Number Kingdom
 digit:{p:['calc']},
 dot:{p:['dice'],keep:['bow']},
 doodle:{h:['numcrown','10'],drop:['flower']},
 zero:{b:['jumper','#ff8a3c'],n:[['num',null,{num:'0'}]],drop:['scarf']},
 ruler:{p:['ruler']},
 paddle:{p:['abacus'],keep:['scarf']},
 cube:{p:['rubik']},
 prism:{g:['prism'],keep:['scarf']},
 pretzel:{cos:'chef'},
 pie:{b:['jumper','#e8423a'],n:[['num',null,{num:'π'}]],drop:['bow']},
 plus:{cos:'knight'},
 seven:{b:['jumper','#5b8def'],n:[['num',null,{num:'7'}]],drop:['scarf']},
 infinity:{h:['numcrown','∞'],keep:['twinkle'],drop:['flower']},
 // Gadget Island
 sprocket:{h:['propeller']},
 widget:{p:['robot'],keep:['scarf']},
 dynamo:{h:['hardhat','#ffd23f']},
 pixel:{g:['pixel'],drop:['bow']},
 turbo:{h:['racing','#e8423a'],drop:['scarf']},
 coil:{h:['antenna','#5cb8ff',{glow:1}]},
 zap:{p:['bolt'],drop:['bow']},
 fuse:{g:['brass'],keep:['scarf']},
 cog:{k:['windkey']},
 nano:{cos:'robot'},
 rivet:{b:['jumper','#c9d2e3',{pat:'rivets'}],p:['spanner']},
 spanner:{p:['spanner'],g:['brass'],keep:['scarf']},
 chrome:{cos:'robot'},
 // Rescue Bay
 siren:{h:['sirenhat'],b:['hivis'],drop:['glow']},
 hydrant:{cos:'fire'},
 buoy:{h:['souwester'],b:['lifevest'],n:[['buckle']],drop:['scarf','glow']},
 skipper:{h:['captain']},
 patch:{b:['hivis'],n:[['whistle']],drop:['scarf']},
 plaster:{p:['plasters','firstaid']},
 flash:{p:['torch'],keep:['glow','scarf']},
 gull:{g:['sun'],p:['rescuetube'],drop:['bow']},
 scout:{n:[['binocs']],drop:['scarf']},
 ranger:{h:['ranger']},
 ladder:{cos:'fire'},
 rocky:{h:['hardhat','#e8423a'],p:['rope']},
 medal:{n:[['medal']],add:['barrel']},
 // Dino Valley
 fossil:{h:['pith'],p:['bigbone']},
 digger:{p:['spade']},
 cycad:{h:['fernhat']},
 rex:{h:['trex']},
 ammo:{p:['ammonite']},
 dusty:{h:['explorer'],p:['brush']},
 mossy:{b:['waistcoat'],n:[['binocs']]},
 bayou:{b:['camo'],h:['pith']},
 flint:{h:['trike'],k:['frill']},
 tusk:{h:['mammoth']},
 ridge:{k:['stego']},
 jura:{cos:'dino'},
 nugget:{n:[['amber']]},
 // Planet Hop
 luna:{fur:['moon']},
 sputnik:{h:['antenna','#ff4f6d',{one:1,glow:1}],keep:['scarf']},
 rusty:{h:['bubble']},
 rover:{space:{trim:'#e8423a',ant:true}},
 cosmo:{fur:['galaxy',{base:'#3a2f7a'}]},
 astra:{fur:['stars'],h:['antenna','#ffd23f']},
 saturn:{n:[['saturn']],k:['saturn']},
 halley:{p:['comet'],drop:['bow']},
 solar:{h:['visor'],g:['sun','#ff8a3c']},
 zoom:{f:['rocket']},
 speckle:{fur:['galaxy',{base:'#2b2f6e'}]},
 rocket:{k:['rocketpack']},
 stardust:{fur:['galaxy',{base:'#5a2f7a'}],keep:['bow','twinkle']},
 // Science Legends: each scientist's own look
 woofton:{p:['apple']},
 carver:{p:['peanuts'],g:['round']},
 mendoodle:{p:['peapod'],g:['round'],drop:['flower']},
 barkwin:{h:['explorer','#c9a86a'],p:['magnifier','finch'],drop:['scarf']},
 galipup:{p:['telescope'],keep:['scarf']},
 chillsius:{p:['thermometer'],keep:['scarf','flake']},
 howlard:{p:['cloud'],keep:['mittens']},
 bentpaw:{p:['camera','flake'],drop:['flake']},
 arfchimedes:{h:['laurel'],p:['duck'],drop:['bubbles']},
 woofsteau:{h:['beanie','#d9363e',{cuff:1,nopom:1}],k:['airtank'],drop:['shell']},
 barkson:{n:[['binocs']],p:['notebook'],drop:['shellneck']},
 tharpup:{p:['map'],keep:['bubbles']},
 furaday:{p:['magnet'],keep:['embers']},
 laboisier:{h:['wig'],p:['flask']},
 fetchla:{p:['tesla'],n:[['bowtie','#3d6fb0']]},
 rumble:{p:['dragonjar']},
 pawlace:{p:['punchcards'],keep:['bow']},
 fidonacci:{p:['shell','sunflower'],drop:['flower']},
 pupthagoras:{h:['laurel'],p:['setsquare'],drop:['bow']},
 pawstein:{p:['chalk'],keep:['einstein','twinkle'],chalk:'E=mc²'},
 dawoofi:{h:['beret','#3a3640'],p:['paintbrush']},
 curly:{b:['labcoat'],p:['testtube']},
 grahambark:{p:['phone'],drop:['scarf'],n:[['bowtie','#3d6fb0']]},
 bright:{h:['flycap'],p:['plane'],keep:['scarf']},
 nightintail:{h:['nursecap'],p:['lamp'],drop:['glow']},
 fleaming:{p:['petri'],g:['round']},
 brunel:{h:['tophat'],n:[['bowtie','#26232e']]},
 seacollie:{h:['headscarf','#e8423a'],p:['medbag'],drop:['scarf']},
 brownie:{h:['pith'],p:['tooth']},
 mantail:{p:['magnifier','tooth']},
 tray:{p:['fossilbasket']},
 chappup:{h:['explorer','#8a5a32'],p:['egg']},
 strelka:{space:{trim:'#e8423a',ant:false}},
 johnspup:{g:['cats'],p:['chalk'],chalk:'3×4=12'},
 copupnicus:{p:['orrery']},
 pawking:{g:['round'],p:['blackhole']},
 // the alien puppies and Zuzu: space furs
 al_wobble:{fur:['jelly']},al_peep:{fur:['glitter']},al_puff:{fur:['galaxy',{nebula:1,star:'#ffd23f'}]},al_dart:{fur:['neon',{col:'#7fe0ff'}]},
 al_glow:{fur:['galaxy',{nebula:1}]},al_echo:{fur:['ripples']},al_swatch:{fur:['rainbow']},al_boing:{fur:['planets']},al_popper:{fur:['swirl']},al_upside:{fur:['stars',{col:'#fff3a0'}]},
 al_zuzu:{fur:['galaxy',{nebula:1}]}
};

/* ---------------- hooks ---------------- */
function refOf(id){if(typeof PUPS!=='undefined'&&PUPS[id])return PUPS[id];const B=window.BHQ;if(B){if(B.ZUZU&&B.ZUZU.id===id)return B.ZUZU;const a=(B.APUPS||[]).find(q=>q.id===id);if(a)return a;}return null;}
function specOf(p){const X=p&&window.SEASONSPEC&&window.SEASONSPEC(p,D2>0);if(X)return X;if(!p||!p.id||p.uni||p.guest)return null;const S=OUT[p.id];if(!S)return null;const R=refOf(p.id);if(!R||R.breed!==p.breed)return null;return S;}
const _fl=formLook;
formLook=function(p){let L=_fl(p);const S=specOf(p);
  if(!S||L.cos||L.ninja&&!S.p&&!S.h){L._ps={id:p&&p.id,coat:p&&COAT[p.breed]};return L;}
  if(S.cos){L=applyCos(L,S.cos);L._ps={id:p.id,coat:COAT[p.breed]};return L;}
  if(!D2){if(!S.space&&!S.fur){L.acc=(L.acc||[]).slice();const drop=(S.drop||[]).slice(),keep=S.keep||[],hp=(S.p||[]).some(k=>AT[k]==='head');
      if(S.h||hp||(S.g&&UPG[S.g[0]]))drop.push('grad','cap','bow','flower','leaves','flake','tuft');if(S.n)drop.push('scarf','daisy','shellneck','barrel','moon');
      L.acc=L.acc.filter(a=>drop.indexOf(a)<0||keep.indexOf(a)>=0).concat(S.add||[]);if(S.n||S.b)L.collar=null;}
    L._ps={id:p.id,S3:S};return L;}
  L.acc=(L.acc||[]).slice();const drop=['grad','cap'].concat(S.drop||[]),keep=S.keep||[];
  if(S.h)drop.push('bow','flower','leaves','flake','tuft');if(S.n)drop.push('scarf','daisy','shellneck','barrel');if(S.b)drop.push('daisy');
  L.acc=L.acc.filter(a=>drop.indexOf(a)<0||keep.indexOf(a)>=0).concat(S.add||[]);
  if(S.n&&!S.add)L.collar=null;if(S.b)L.collar=null;
  if(S.fur&&FURBASE[S.fur[0]]&&!(S.fur[1]&&S.fur[1].nebula)){Object.assign(L,FURBASE[S.fur[0]](S.fur[1]||{}));L.spots=false;L.patch=null;L.face=null;L.blaze=null;L.headC=null;L.bodyPatch=null;L.brows=null;L.paw=null;L.collar=null;}
  if(S.space){const tr=S.space.trim;L.space={trim:tr,ant:!!S.space.ant};L.body='#eef1f7';L.belly='#ffffff';L.paw=tr;L.collar=null;L.bodyPatch=null;L.noBodySpots=true;L.wool=false;L.eyeWhite=true;L.acc=L.acc.filter(a=>['grad','cap','scarf'].indexOf(a)<0);}
  if(S.look)Object.assign(L,S.look);
  L._ps={id:p.id,coat:COAT[p.breed],S};return L;};
const _cs=critterSVG;critterSVG=function(p,o){D2++;try{return _cs(p,o);}finally{D2--;}};

function propAt(c,name,slot){const at=AT[name]||slot;let x,y,sc=1;
  if(at==='head'){x=c.cx+4;y=c.cy-c.hh-10;}
  else if(at==='friend'){x=c.cx+c.hw*.92;y=c.cy-c.hh*.78;sc=.85;}
  else if(at==='mouth'){x=c.cx;y=c.cy+c.hh*.6;sc=.85;}
  else if(at==='right'){x=Math.min(182,100+c.bw+14);y=172;}
  else{x=Math.max(18,100-c.bw-14);y=172;}
  let svg=PROP[name]||'';if(name==='chalk'){const t=(c.L._ps&&c.L._ps.S&&c.L._ps.S.chalk)||'E=mc²';svg+=`<text x="0" y="-6" font-size="${t.length>5?8.5:10}" font-weight="700" text-anchor="middle" fill="#fff" font-family="Arial">${t}</text>`;}
  return `<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) scale(${sc})">${svg}</g>`;}

const UPG={skigog:1,snorkel:1,divemask:1,brass:1};
const _f=form2D;
form2D=function(w,c){let s=_f(w,c);if(!D2)return s;const L=c.L,ps=L._ps||{},S=ps.S||{},coat=L.cos?null:ps.coat,R=hrng((ps.id||'x')+w),fur=L.fur,bodyC=L.body||L.fur,headC=L.headC||L.fur;
  const dressed=!!(S.b||L.cos||L.space||L.ninja||L.xmas||L.lava||L.atom||L.snack);
  if(w==='aura'){s+=`<ellipse cx="100" cy="194" rx="${c.bw+22}" ry="9" fill="#000" opacity=".12"/><defs><radialGradient id="${c.id}H" cx=".36" cy=".3" r=".78"><stop offset="0" stop-color="#fff" stop-opacity=".4"/><stop offset=".42" stop-color="#fff" stop-opacity="0"/><stop offset=".78" stop-color="#000" stop-opacity="0"/><stop offset="1" stop-color="#000" stop-opacity=".2"/></radialGradient>`;
    if(S.fur){const o=S.fur[1]||{};s+=o.nebula?`<radialGradient id="${c.id}N1"><stop offset="0" stop-color="#ff7fd0" stop-opacity=".55"/><stop offset="1" stop-color="#ff7fd0" stop-opacity="0"/></radialGradient><radialGradient id="${c.id}N2"><stop offset="0" stop-color="#7fe0ff" stop-opacity=".5"/><stop offset="1" stop-color="#7fe0ff" stop-opacity="0"/></radialGradient>`
      :`<radialGradient id="${c.id}N1"><stop offset="0" stop-color="#ff7fd0" stop-opacity=".75"/><stop offset="1" stop-color="#ff7fd0" stop-opacity="0"/></radialGradient><radialGradient id="${c.id}N2"><stop offset="0" stop-color="#5ce0e6" stop-opacity=".6"/><stop offset="1" stop-color="#5ce0e6" stop-opacity="0"/></radialGradient>`;}
    s+='</defs>';}
  if(w==='behind'){if(coat&&!dressed)s+=hangHair(coat,R,L,c);(S.k||[]).forEach(k=>{if(BACK[k])s+=BACK[k](c);});if(S.h&&S.h[0]==='trike'&&!(S.k||[]).length)s+=BACK.frill(c);}
  if(w==='bodyClip'){if(S.fur&&FUR[S.fur[0]])s+=FUR[S.fur[0]](c,false,S.fur[1]||{},R);
    if(S.b&&BODY[S.b[0]])s+=BODY[S.b[0]](c,S.b[1],S.b[2]||{});
    if(coat&&!dressed&&!S.fur){s+=coatMarks(coat,R,100,c.by,c.bw,c.bh,bodyC,coat==='curly'?20:coat==='silky'?7:coat==='corded'?7:15,false);if(TICKED[L._breed])s+=ticks(R,100,c.by,c.bw,c.bh,14,shade(bodyC,-.4));}
    s+=`<ellipse cx="100" cy="${c.by}" rx="${c.bw}" ry="${c.bh}" fill="url(#${c.id}H)"/>`;}
  if(w==='chest'){if(coat==='double'&&!dressed&&!S.fur&&!(S.n||[]).length&&!(S.h&&/^(trex|trike|mammoth)$/.test(S.h[0])))s+=ruff(L,c);(S.n||[]).forEach(q=>{if(NECK[q[0]])s+=NECK[q[0]](c,q[1],q[2]||{});});}
  if(w==='headClip'){if(S.fur&&FUR[S.fur[0]])s+=FUR[S.fur[0]](c,true,S.fur[1]||{},R);
    if(coat&&!S.fur&&!L.ninja&&!L.space)s+=coatMarks(coat,R,c.cx,c.cy,c.hw,c.hh,headC,coat==='curly'?15:coat==='silky'?6:coat==='corded'?6:11,true);
    s+=`<ellipse cx="${c.cx}" cy="${c.cy}" rx="${c.hw}" ry="${c.hh}" fill="url(#${c.id}H)"/>`;}
  if(w==='top'){if(coat==='wire'&&!L.cos&&!L.ninja)s+=wireFace(L,c);
    if(S.f&&FEET[S.f[0]])s+=FEET[S.f[0]](c,S.f[1]);
    const up=S.g&&UPG[S.g[0]];if(S.g&&FACE[S.g[0]]&&!up)s+=FACE[S.g[0]](c,S.g[1]);
    if(S.h&&HAT[S.h[0]])s+=HAT[S.h[0]](c,S.h[1],S.h[2]||{});
    if(up)s+=FACE[S.g[0]](c,S.g[1]);
    (S.p||[]).forEach((k,i)=>{s+=propAt(c,k,i?'right':'left');});}
  return s;};
/* breed for ticked coats */
const _fl2=formLook;formLook=function(p){const L=_fl2(p);if(p&&p.breed)L._breed=p.breed;return L;};


/* ---------------- 3D: hats, goggles, body wear, neck and back things on the pups in the world ----------------
   head group h: head about .58 wide and .52 tall round (0,0,0), facing +z, eyes at y .07; body group b: body round (0,.66,0),
   .5*bw wide, .45 tall, .64*lg long, chest front at (0,.82,cz). Boots and small hand props stay 2D only. */
const PI=Math.PI;
const H3={
 beanie(h,col,o){col=col||'#e8423a';mk('hemi',col,.57,.5,.55,0,.12,0,h);mk('cyl',o.cuff?shade(col,-.12):'#fff4e0',.6,.15,.57,0,.16,0,h);if(!o.nopom)mk('sph',o.pom||'#fff',.15,.15,.15,0,.64,0,h);},
 earmuffs(h,col){mk('arc','#8a8f99',.64,.62,.9,0,.02,0,h);[-1,1].forEach(g=>mk('sph',col||'#ff9ecb',.12,.2,.2,g*.62,.02,0,h));},
 strawhat(h,col){mk('cyl','#f2d27a',.8,.03,.76,0,.34,0,h);mk('cyl','#f2d27a',.4,.24,.38,0,.47,0,h);mk('cyl',col||'#e8423a',.41,.07,.39,0,.4,0,h);},
 sunhat(h,col){col=col||'#ff9ecb';mk('cyl',col,.86,.03,.82,0,.32,0,h);mk('hemi',col,.44,.32,.42,0,.32,0,h);mk('cyl','#fff',.45,.06,.43,0,.36,0,h);mk('sph','#fff27a',.09,.09,.09,.3,.42,.3,h);},
 sailor(h){mk('cyl','#fff',.34,.22,.34,0,.54,0,h);mk('cyl','#2b4a8a',.345,.05,.345,0,.5,0,h);mk('tor','#fff',.36,.36,.25,0,.44,0,h).rotation.x=PI/2;},
 captain(h){mk('cyl','#fff',.48,.12,.5,0,.56,0,h);mk('cyl','#2b4a8a',.42,.1,.44,0,.46,0,h);mk('sph','#26232e',.32,.04,.22,0,.42,.38,h);mk('sph','#ffd23f',.06,.06,.03,0,.47,.44,h);},
 ranger(h){mk('cyl','#a88a4a',.8,.03,.76,0,.36,0,h);mk('cone','#b89a5a',.38,.36,.36,0,.56,0,h);mk('cyl','#5a3a22',.37,.06,.35,0,.42,0,h);},
 pith(h){mk('hemi','#d8c08a',.54,.44,.52,0,.24,0,h);mk('cyl','#e6d3a0',.68,.03,.64,0,.24,0,h);mk('cyl','#8a6238',.55,.06,.53,0,.28,0,h);mk('sph','#c9a86a',.07,.05,.07,0,.68,0,h);},
 explorer(h,col){col=col||'#8a5a32';mk('cyl',col,.74,.03,.68,0,.36,0,h);mk('cyl',col,.38,.26,.36,0,.5,0,h);mk('cyl','#3a2a20',.39,.06,.37,0,.42,0,h);},
 tophat(h,col){col=col||'#2a2630';mk('cyl',col,.55,.03,.52,0,.4,0,h);mk('cyl',col,.34,.56,.32,0,.7,0,h);mk('cyl','#8a2a2a',.345,.08,.325,0,.48,0,h);},
 beret(h,col){mk('sph',col||'#3a3640',.52,.14,.5,-.05,.5,0,h).rotation.z=.18;mk('cyl',col||'#3a3640',.03,.1,.03,-.05,.64,0,h);},
 laurel(h){for(let i=0;i<12;i++){const a=i*PI/6;mk('sph','#6fbf4a',.1,.05,.06,Math.cos(a)*.55,.3,Math.sin(a)*.5,h).rotation.y=-a;}},
 flycap(h){mk('hemi','#8a5a32',.63,.56,.59,0,-.04,0,h);[-1,1].forEach(g=>{mk('sph','#8a5a32',.14,.22,.16,g*.56,-.2,.05,h);mk('tor','#b8862e',.1,.1,.25,g*.16,.36,.42,h);mk('sph','#9be8ff',.08,.08,.04,g*.16,.36,.43,h);});},
 nursecap(h){mk('box','#fff',.36,.16,.24,0,.6,.04,h);mk('box','#e8423a',.1,.03,.01,0,.62,.17,h);mk('box','#e8423a',.03,.1,.01,0,.62,.17,h);},
 headscarf(h,col){col=col||'#3d8fe0';mk('hemi',col,.62,.56,.58,0,0,0,h);mk('sph',col,.12,.1,.1,0,.6,.1,h);[-1,1].forEach(g=>mk('cone',col,.07,.14,.04,g*.1,.66,.1,h).rotation.z=-g*1.2);},
 wig(h){const W1='#f4f1ea';[-1,1].forEach(g=>{for(let i=0;i<3;i++)mk('sph',W1,.17,.17,.17,g*.6,.18-i*.22,-.05,h);});for(let i=0;i<5;i++)mk('sph',W1,.18,.16,.18,-.36+i*.18,.48,-.05,h);},
 crown(h,cols){cols=cols||['#ff9ecb','#fff','#ffd23f'];for(let i=0;i<10;i++){const a=i*PI/5;mk('sph',cols[i%cols.length],.09,.09,.09,Math.cos(a)*.5,.34,Math.sin(a)*.46,h);}},
 numcrown(h){mk('cyl','#ffd23f',.4,.16,.38,0,.58,0,h);for(let i=0;i<5;i++){const a=i*PI*2/5+PI/2;mk('cone','#ffd23f',.08,.18,.08,Math.cos(a)*.34,.74,Math.sin(a)*.32,h);}mk('sph','#ffffff',.09,.09,.05,0,.58,.4,h);},
 propeller(h){mk('hemi','#e8423a',.42,.32,.42,0,.36,0,h);mk('cyl','#5b8def',.43,.06,.43,0,.38,0,h);mk('cyl','#3a3640',.03,.14,.03,0,.74,0,h);mk('box','#3fae5a',.72,.03,.1,0,.82,0,h).rotation.y=.6;mk('sph','#ffd23f',.05,.05,.05,0,.83,0,h);},
 racing(h,col){col=col||'#e8423a';mk('hemi',col,.65,.6,.62,0,-.06,0,h);mk('box','#3a4a6a',.52,.14,.06,0,.28,.52,h);mk('box','#fff',.08,.02,.62,0,.54,0,h);},
 hardhat(h,col){col=col||'#ffd23f';mk('hemi',col,.5,.4,.48,0,.26,0,h);mk('cyl',col,.6,.03,.58,0,.26,0,h);mk('sph','#fff27a',.09,.09,.05,0,.44,.44,h,true);},
 sirenhat(h){H3.hardhat(h,'#ffffff');mk('sph','#5cb8ff',.1,.1,.1,0,.7,0,h,true);},
 souwester(h){mk('hemi','#ffd23f',.52,.42,.5,0,.24,0,h);mk('cyl','#ffd23f',.74,.03,.72,0,.22,-.04,h).rotation.x=-.15;},
 headband(h,col){col=col||'#e8423a';mk('cyl',col,.6,.1,.56,0,.24,0,h);[-1,1].forEach(g=>mk('box',col,.05,.22,.04,.2+g*.06,.12,-.55,h).rotation.z=g*.4);},
 antenna(h,col,o){(o.one?[.15]:[-.24,.24]).forEach(x=>{mk('cyl','#8a8f99',.025,.34,.025,x,.66,0,h);mk('sph',col||'#ff4f6d',.09,.09,.09,x,.86,0,h,!!o.glow);});mk('arc','#8a8f99',.6,.58,.3,0,.02,0,h);},
 acorncap(h){mk('hemi','#a8743a',.6,.48,.56,0,.12,0,h);mk('cyl','#7a4a22',.04,.2,.04,.03,.68,0,h).rotation.z=-.3;},
 fernhat(h){[[-.22,.52,.05,.5],[0,.58,0,0],[.22,.52,.05,-.5]].forEach(q=>mk('sph','#6fbf4a',.24,.04,.1,q[0],q[1],q[2],h).rotation.z=q[3]);},
 visor(h){mk('cyl','#ff8a3c',.59,.06,.55,0,.3,0,h);mk('sph','#ffd23f',.32,.03,.26,0,.33,.44,h);},
 trex(h){mk('hemi','#6fbf4a',.65,.62,.61,0,-.05,0,h);for(let i=0;i<7;i++){const a=-.9+i*.3;mk('cone','#ffffff',.05,.1,.05,Math.sin(a)*.6,-.08,Math.cos(a)*.56,h).rotation.x=PI;}
   [-1,1].forEach(g=>{mk('sph','#fff',.1,.1,.08,g*.22,.5,.32,h);mk('sph',K,.05,.05,.04,g*.22,.5,.39,h);});for(let i=0;i<4;i++)mk('cone','#ff8a3c',.06,.16,.04,0,.62-i*.04,.15-i*.2,h);},
 trike(h){mk('hemi','#ff9a4a',.65,.6,.61,0,-.05,0,h);mk('cyl','#ffc46b',.85,.04,.8,0,.2,-.34,h).rotation.x=PI/2-.3;[-1,1].forEach(g=>mk('cone','#fff3d6',.06,.32,.06,g*.22,.66,.18,h).rotation.x=.5);mk('cone','#fff3d6',.05,.16,.05,0,.18,.6,h).rotation.x=.8;},
 mammoth(h){mk('hemi','#8a5a32',.67,.62,.63,0,-.06,0,h);[-1,1].forEach(g=>{const t=mk('cone','#fff8e6',.06,.42,.06,g*.24,-.34,.58,h);t.rotation.x=2.1;t.rotation.z=-g*.3;});}};
const FACE3={
 skigog(h){mk('cyl','#3a3640',.6,.07,.56,0,.3,0,h);mk('box','#ff9a3c',.46,.16,.06,0,.32,.42,h);},
 brass(h){mk('cyl','#7a4a2a',.6,.06,.56,0,.32,0,h);[-1,1].forEach(g=>{mk('tor','#b8862e',.1,.1,.25,g*.15,.34,.42,h);mk('sph','#9be8ff',.08,.08,.04,g*.15,.34,.43,h);});},
 snorkel(h){mk('cyl','#2fb3b3',.6,.06,.56,0,.32,0,h);mk('box','#bff0ff',.42,.16,.06,0,.34,.42,h);mk('cyl','#ffd23f',.04,.5,.04,.5,.46,.25,h);},
 divemask(h){FACE3.snorkel(h);},
 round(h,col,L){const ex=.22*L.eyeD/.42,c=lum(L.headC||L.fur)<.3?'#e6c46a':K;[-1,1].forEach(g=>mk('ring',c,.13,.13,.4,g*ex,.07,.53,h));mk('box',c,.12,.02,.02,0,.1,.55,h);},
 cats(h,col,L){FACE3.round(h,col,L);},
 sun(h,col,L){const ex=.22*L.eyeD/.42;[-1,1].forEach(g=>mk('box',col||'#26232e',.2,.14,.03,g*ex,.07,.54,h));mk('box',col||'#26232e',.14,.03,.02,0,.1,.55,h);},
 pixel(h,col,L){FACE3.sun(h,'#111',L);},
 prism(h,col,L){FACE3.sun(h,'#b58cff',L);}};
const B3={jumper:'#5b8def',camo:'#7a8a4a',hawaiian:'#ff8a3c',gi:'#f6f4ee',hivis:'#d8f23a',lifevest:'#ff6a2a',labcoat:'#f6f8fb',waistcoat:'#c9b07a'};
function body3(S,L,b,c){const k=S.b[0],col=S.b[1]||B3[k],bw=c.bw,lg=c.lg;mk('sph',col,.53*bw,.48,.67*lg,0,.66,0,b);if(!L.neck)mk('sph',col,.29*Math.max(.85,bw),.29,.29,0,.97,.4*lg,b);
  if(k==='hivis'||k==='lifevest')[.72,.56].forEach(y=>mk('cyl','#c9d2e3',.535*bw,.05,.675*lg,0,y,0,b));
  if(k==='gi'||(S.n||[]).some(q=>q[0]==='belt')){const bc=((S.n||[]).find(q=>q[0]==='belt')||[0,'#26232e'])[1];mk('cyl',bc,.54*bw,.06,.68*lg,0,.6,0,b);}
  if(k==='camo')[[.3,.8,.1],[-.3,.75,-.2],[.1,.95,-.3],[-.2,.6,.4]].forEach(q=>mk('sph','#4a5a2a',.14,.1,.14,q[0]*bw,q[1],q[2]*lg,b));
  if(k==='jumper'&&S.b[2]&&S.b[2].pat==='nordic')mk('cyl','#ffffff',.54*bw,.05,.68*lg,0,.78,0,b);}
const N3={
 neckerchief(b,col,cz){mk('cone',col||'#e8423a',.2,.24,.05,0,.82,cz+.02,b).rotation.x=PI;},
 bowtie(b,col,cz){[-1,1].forEach(g=>mk('cone',col||'#e8423a',.07,.13,.04,g*.07,.9,cz,b).rotation.z=g*PI/2);},
 medal(b,col,cz){mk('box','#5b8def',.06,.18,.02,0,.86,cz,b);mk('cyl','#ffd23f',.1,.025,.1,0,.74,cz+.03,b).rotation.x=PI/2;},
 whistle(b,col,cz){mk('cyl','#c9d2e3',.04,.14,.04,0,.8,cz+.02,b).rotation.z=PI/2;},
 binocs(b,col,cz){[-1,1].forEach(g=>mk('cyl','#3f5a3a',.06,.17,.06,g*.07,.78,cz+.03,b));},
 amber(b,col,cz){mk('sph','#ffa62a',.08,.09,.05,0,.8,cz+.02,b);},
 lei(b,col,cz,c){const cols=['#ff7fb8','#ffd23f','#ff8a3c','#fff'];for(let i=0;i<10;i++){const a=i*PI/5;mk('sph',cols[i%4],.07,.07,.07,Math.cos(a)*.3,.9,.4*c.lg+Math.sin(a)*.24,b);}},
 saturn(b,col,cz,c){const r=mk('band','#ffd27a',.78*c.bw,.92*c.lg,.9,0,.7,0,b);r.rotation.x=PI/2-.25;},
 num(b,col,cz){mk('cyl','#ffd23f',.1,.02,.1,0,.72,cz+.03,b).rotation.x=PI/2;},
 buckle(b,col,cz){mk('box','#ffd23f',.12,.08,.03,0,.7,cz+.04,b);},
 belt(){}};
const K3={
 rocketpack(b,c){[-1,1].forEach(g=>{mk('cyl','#e8423a',.1,.38,.1,g*.22,.96,-.3*c.lg,b);mk('cone','#ff8a3c',.07,.18,.07,g*.22,.68,-.3*c.lg,b,true).rotation.x=PI;});},
 airtank(b,c){mk('cyl','#ffd23f',.12,.44,.12,0,1.02,-.25*c.lg,b);},
 windkey(b,c){const z=-.64*c.lg-.06;mk('cyl','#d9a83a',.03,.22,.03,0,.8,z,b).rotation.x=PI/2;[-1,1].forEach(g=>mk('tor','#ffd27a',.1,.1,.3,g*.1,.8,z-.14,b).rotation.y=PI/2);},
 stego(b,c){for(let i=0;i<5;i++)mk('pyr','#3fae5a',.04,.26-Math.abs(i-2)*.04,.16,0,1.16,.3*c.lg-i*.2*c.lg,b);},
 saturn(){},frill(){}};
const HEAD3={apple(h){mk('sph','#e8423a',.15,.14,.15,.1,.66,.05,h);mk('cyl','#6b4428',.02,.08,.02,.1,.82,.05,h);mk('sph','#3fae5a',.08,.02,.04,.16,.82,.05,h);},
 starfish(h){mk('sph','#ff8a3c',.2,.04,.2,.1,.56,.1,h);},octopus(h){mk('sph','#b58cff',.2,.18,.2,.1,.64,0,h);}};
function add3D(S,L,b,h,c){const cz=.4*c.lg+.27*c.hs;
  if(S.b&&!L.space)body3(S,L,b,c);
  (S.n||[]).forEach(q=>{if(N3[q[0]])N3[q[0]](b,q[1],cz,c);});
  (S.k||[]).forEach(k=>{if(K3[k])K3[k](b,c);});
  if(S.g&&FACE3[S.g[0]])FACE3[S.g[0]](h,S.g[1],L);
  if(S.h&&H3[S.h[0]])H3[S.h[0]](h,S.h[1],S.h[2]||{});
  (S.p||[]).forEach(k=>{if(HEAD3[k])HEAD3[k](h);});}
const _f3=form3D;form3D=function(L,b,h,c){_f3(L,b,h,c);const S=L._ps&&L._ps.S3;if(!S||L.cos||S.cos)return;try{add3D(S,L,b,h,c);}catch(e){console.warn('pup 3D outfit',e);}};

window.PSTYLE={COAT,OUT,H3,FACE3,HAT,FACE,BODY,NECK,FEET,BACK,PROP,FUR,specOf,N3,K3,B3,HEAD3,AT,d2:()=>D2>0};
})();
