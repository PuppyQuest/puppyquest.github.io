/* ================================================================
   Spring Blossom (26 Nov 2026; claude/spring-blossom-design.md sections 6, 7, 10, 12, 13): the world in spring.
   The village (blossom trees, daffodils, bunting, the Festival Tree and the Flower Board), blossom and
   daffodils on every island, the island surprises (snowdrops, turtle hatchlings, hanami, Fibonacci's
   rabbits, Tinker's greenhouse, the Countryside Code gate, the Moon tree), the spotlights (the Great Egg
   Hunt at Windmill Hill, the Nest Builder in Bluebell Wood, the Dino Egg Hatch at Long-neck's Nest), the
   spring quiz in the Lab, the Den after the festival, Arcade entries, two tunes (the opening of Spring
   from Vivaldi's Four Seasons, published 1725, and an original "Duckling Waddle") and the real-date
   daffodils from 1 to 7 March.
   ================================================================ */
(function(){
const SR=window.SPRING,SL=window.SPLOOK,XM=window.XMAS,PI=Math.PI,PINK='#ff9ac0',LEAF='#6abf4a';
const COLS=['#ff9ac0','#ffe066','#8ad0ff','#9ae07a','#c8a8ff','#ffffff'];
const G=()=>SR.GS(),acts=()=>{const s=G();s.acts=s.acts||{};return s.acts;},F=()=>SR.pal().name;
function sayOnce(k,m,ms){const a=acts();if(a['s_'+k])return;a['s_'+k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say(m);},ms||1600);}
let GRD=null;function near(A,x,z,c){if(!GRD||GRD.id!==A.id){GRD=XM.grid(A,1);GRD.id=A.id;}const k=GRD.snap(x,z,c||2);return k<0?[x,z]:GRD.xz(k);}
/* a free place near (x,z): on walkable ground, clear of the spring hiding spots, things and exits */
function spotsOf(A){const out=[];SR.areaX(A.id).forEach(p=>{const S=(window.SPSPOTS||{})[p.id];if(!S)return;if(S.x!=null)out.push([S.x,S.z,6.5]);['b','c'].forEach(k=>{if(S[k])out.push([S[k][0],S[k][1],5]);});});
  W.things.forEach(t=>{if(!t.ppal&&!t.spal&&!t.hpal)out.push([t.x,t.z,4]);});(W.exits||[]).forEach(e=>out.push([e.x,e.z,7]));return out;}
function place(A,x,z,c){const L=spotsOf(A),ok=p=>!L.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<q[2]);let p=near(A,x,z,c);if(ok(p))return p;
  for(let r=3;r<=24;r+=3)for(let i=0;i<10;i++){const a=i/10*PI*2+r,q=near(A,x+Math.cos(a)*r,z+Math.sin(a)*r,c);if(ok(q))return q;}return p;}
const big=e=>`<div style="font-size:96px;line-height:1">${e}</div>`;
function card2(art,h,p,sayT){card({art,h,p,say:sayT||p,btns:[['OK','green']]});}
function reward(k,n){const a=acts();if(a[k])return;a[k]=1;state.stars+=n||5;save();hud();}
/* spring props from instanced parts */
function btree(x,z,s,c){const y=gy(x,z);s=s||1;c=c||PINK;I('cyl','#7a5230',.22*s,2.4*s,.22*s,x,y+1.2*s,z);[[0,3.1,0,1.3],[.9,2.7,.3,.9],[-.8,2.8,-.4,.95],[.2,2.6,-.9,.85],[-.3,3.6,.4,.8]].forEach((q,i)=>I('sph',i%2?c:'#ffd0e0',q[3]*s,q[3]*.85*s,q[3]*s,x+q[0]*s,y+q[1]*s,z+q[2]*s));}
function daffs(x,z,n,R){R=R||seed(Math.round(x*7+z*13));const y=gy(x,z);for(let i=0;i<n;i++){const a=R()*PI*2,r=R()*1.3,fx=x+Math.cos(a)*r,fz=z+Math.sin(a)*r,fy=gy(fx,fz);I('cyl','#4a9a3a',.03,.6,.03,fx,fy+.3,fz);I('cone','#ffd23f',.13,.18,.13,fx,fy+.66,fz,PI,0,0);I('cyl','#ffb020',.06,.12,.06,fx,fy+.6,fz);}}
function flowers(x,z,n,R){R=R||seed(Math.round(x*5+z*11));for(let i=0;i<n;i++){const a=R()*PI*2,r=R()*1.6,fx=x+Math.cos(a)*r,fz=z+Math.sin(a)*r,fy=gy(fx,fz);I('cyl','#4a9a3a',.025,.4,.025,fx,fy+.2,fz);I('sph',COLS[i%5],.13,.08,.13,fx,fy+.42,fz);}}
function flags(cx,cz,r,y0,n){for(let i=0;i<n;i++){const a=i/n*PI*2,x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r,y=y0+Math.sin(i*PI/2)*.25;I('box',COLS[i%COLS.length],.5,.32,.04,x,y,z,0,-a,0);}}
function lamb3D(){const g=grp();mk('sph','#ffffff',.5,.42,.62,0,.7,0,g);for(let i=0;i<5;i++){const a=i/5*PI*2;mk('sph','#ffffff',.22,.2,.22,Math.cos(a)*.3,.95,Math.sin(a)*.38,g);}
  mk('sph','#3a3640',.22,.24,.26,0,.85,.6,g);[-1,1].forEach(s=>{mk('sph','#3a3640',.14,.05,.08,s*.24,.95,.58,g);mk('cyl','#3a3640',.06,.5,.06,s*.22,.25,.3,g);mk('cyl','#3a3640',.06,.5,.06,s*.22,.25,-.3,g);});
  bakeModel(g,'splamb');return g;}

/* ================= Pawprint Village in spring ================= */
let TREE=null;
function villageS(A){
  const R=seed(81);for(let i=0;i<7;i++){const a=i/7*PI*2+.4,p=place(A,Math.cos(a)*14,4+Math.sin(a)*14,1);if(Math.hypot(p[0]+5.5,p[1]-9)<3)continue;btree(p[0],p[1],.8,i%2?PINK:'#ffffff');daffs(p[0]+1.6,p[1]+.8,5,R);}
  flags(0,4,9.5,4.6,30);
  {const p=place(A,10,-9,2);TREE=festTree(p[0],p[1]);}
  flowerBoard(-9,-18);
  sayOnce('village',`Welcome to the Blossom Festival! Look at the Flower Board by the plaza: a flower blooms for every spring pup you find.`);}
/* the Festival Tree: bare twigs with little green buds, until the festival */
function festTree(x,z){const y=gy(x,z),done=!!(SR.G0()&&SR.G0().done),g=grp();mk('cyl','#6a4a2a',.35,3.2,.35,0,1.6,0,g);
  [[.9,3.4,.2,.5],[-.8,3.6,-.3,-.5],[.2,3.9,-.8,.3],[-.2,3.8,.8,-.3],[0,4.3,0,0]].forEach(q=>{const b=mk('cyl','#6a4a2a',.1,1.8,.1,q[0]*.6,q[1]-.4,q[2]*.6,g);b.rotation.z=-q[0]*.6;b.rotation.x=q[2]*.6;});
  const bl=[];[[0,4.6,0,1.5],[1.1,4.0,.4,1.1],[-1.1,4.1,-.4,1.1],[.4,4.0,-1.2,1],[-.4,4.2,1.1,1]].forEach((q,i)=>{const s=mk('sph',i%2?'#ffd0e0':PINK,q[3],q[3]*.8,q[3],q[0],q[1],q[2],g);s.visible=done;bl.push(s);});
  const bud=[];for(let i=0;i<9;i++){const a=i/9*PI*2,b=mk('sph','#8ad05a',.12,.16,.12,Math.cos(a)*1.1,3.6+(i%3)*.4,Math.sin(a)*1.1,g);b.visible=!done;bud.push(b);}
  add(g,x,z);col(x,z,1);const l=label('🌳 The Festival Tree',4.6,'#f6fff0');l.position.set(x,y+6.4,z);W.ag.add(l);
  W.things.push({x,z:z+2.4,r:3.6,icon:'🌳',label:'The Festival Tree',act:()=>{if(player.lock)return;sfx.chime();const T=SR.G0()||{};
    say(T.done?'The Festival Tree is in full blossom! Thank you for bringing back all nine buds, Seb.':`The Festival Tree is waiting for its nine special buds. ${F()} has ${SR.nBb()} of them so far!`);}});
  return {g,x,z,bl,bud};}
function bloom(){if(!TREE)return;TREE.bl.forEach(s=>s.visible=true);TREE.bud.forEach(s=>s.visible=false);floatS('🌸',TREE.x,gy(TREE.x,TREE.z)+5,TREE.z,3);}
function flowerBoard(x,z){const y=gy(x,z);[-2.1,2.1].forEach(d=>I('box','#c98a4f',.22,3.8,.22,x+d,y+1.9,z));I('box','#9ad870',4.5,2.9,.2,x,y+2.7,z);I('box','#ffd0e0',4.7,.16,.26,x,y+4.18,z);I('box','#ffd0e0',4.7,.16,.26,x,y+1.22,z);
  const n=Math.min(60,Math.round(SR.nFound()/SR.all().length*60));for(let i=0;i<60;i++){const c=i%12,r=Math.floor(i/12);I('sph',i<n?COLS[i%5]:'#6a9a5a',.13,.11,.06,x-1.9+c*.345,y+3.75-r*.48,z+.13,0,0,0,i<n);}
  const l=label('🌷 Flower Board',4.5,'#f6fff0');l.position.set(x,y+5,z);W.ag.add(l);rect(x-2.4,z-.3,x+2.4,z+.3);
  W.things.push({x,z:z+2.2,r:3.6,icon:'🌷',label:'Flower Board',act:()=>SR.board()});}

/* ================= the islands in spring ================= */
const ISL={};
function decor(A){if(!A.island||A.indoor||A.swim||A.island==='planet')return;const s=A.start||[0,0],R=seed(A.id.length*23+3);
  for(let i=0;i<2;i++){const a=R()*PI*2,d=9+R()*6,p=place(A,s[0]+Math.cos(a)*d,s[1]-4+Math.sin(a)*d,2);btree(p[0],p[1],.75,i?PINK:'#ffffff');(A.island==='snowy'?flowers:daffs)(p[0]+1.5,p[1]+.6,6,R);}}
/* Snowy Summit: snowdrops push up through the snow by the Lift Station */
function dropsSVG(){let s='<svg viewBox="0 0 320 200" width="320"><rect width="320" height="200" rx="16" fill="#e8f4ff"/><path d="M0 150 Q160 120 320 150 V200 H0 Z" fill="#ffffff"/>';
  for(let r=0;r<3;r++)for(let c=0;c<4;c++){const x=70+c*60,y=70+r*40;s+=`<g class="spdrop" style="animation-delay:${(r*4+c)*.12}s"><path d="M${x} ${y+28} Q${x+2} ${y+6} ${x+8} ${y}" stroke="#4a9a3a" stroke-width="3" fill="none"/><path d="M${x+8} ${y} q-8 4 -6 14 q6 -2 6 -14 q8 4 6 14 q-6 -2 -6 -14 Z" fill="#ffffff" stroke="#26232e" stroke-width="1.6"/><circle cx="${x+8}" cy="${y+12}" r="1.6" fill="#7ac85a"/></g>`;}
  return s+'</svg>';}
ISL.lift=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-7,2),x=p[0],z=p[1],y=gy(x,z);I('disc','#ffffff',2,1,2,x,y+.06,z);
  for(let r=0;r<3;r++)for(let c=0;c<4;c++){const fx=x-1.2+c*.8,fz=z-.8+r*.8,fy=gy(fx,fz);I('cyl','#4a9a3a',.03,.5,.03,fx,fy+.25,fz);I('sph','#ffffff',.1,.14,.1,fx+.05,fy+.48,fz,0,0,.4);}
  W.things.push({x,z:z+2.2,r:3.6,icon:'❄️',label:'Snowdrops',act:()=>{if(player.lock)return;sfx.chime();reward('snowdrops');
    card({art:`<div class="fitsvg" style="width:320px">${dropsSVG()}</div>`,h:'Snowdrops in the snow!',p:'How many snowdrops? There are 3 rows of 4: 4, 8, 12. Twelve snowdrops! Snowdrops are some of the first flowers of the year, and they can push up through thin snow.',btns:[['🌼 Lovely!','green']]});}});
  sayOnce('drops','Look! Little white flowers are pushing up through the snow by the Lift Station.',2600);};
/* Coral Reef: baby turtles swim off to the open sea */
function turtle3D(){const g=grp();mk('sph','#4a9a5a',.36,.16,.44,0,0,0,g);mk('sph','#7ac87a',.14,.12,.16,0,.02,.44,g);[-1,1].forEach(s=>{const f=mk('sph','#7ac87a',.24,.04,.1,s*.36,0,.18,g);f.rotation.y=s*.5;mk('sph','#7ac87a',.12,.04,.08,s*.26,0,-.3,g);});bakeModel(g,'spturt');return g;}
ISL.lagoon=A=>{const s=A.start||[0,0],p=place(A,s[0]+5,s[1]-8,2),x=p[0],z=p[1],L=[];for(let i=0;i<5;i++){const g=turtle3D();add(g,x,z);L.push(g);}let go=0;
  W.ticks.push(dt=>{if(W.area!==A)return true;if(go>0)go-=dt;L.forEach((g,i)=>{const a=W.t*(go>0?.9:.35)+i*1.25,r=2.4+i*.3+(go>0?(6-go)*2:0);g.position.set(x+Math.cos(a)*r,gy(x,z)+1.2+Math.sin(W.t*2+i)*.2,z+Math.sin(a)*r);g.rotation.y=-a;});});
  W.things.push({x,z:z+2,r:4,icon:'🐢',label:'Baby turtles',act:()=>{if(player.lock)return;go=6;sfx.chime();reward('turtles');
    setTimeout(()=>card2(big('🥚🐢🌊'),'Baby sea turtles!','Sea turtles lay their eggs in the warm sand on the beach. When the babies hatch, they scurry down to the sea together, and swim off to the open ocean. Many of them come back to the same beach when they are grown up.'),900);}});};
/* Ninja Mountains: hanami under the cherry blossom by the Dojo */
ISL.dojo=A=>{const s=A.start||[0,0],p=place(A,s[0]+7,s[1]-8,3),x=p[0],z=p[1],y=gy(x,z);btree(x,z,1.3,'#ffb8d0');I('box','#e8423a',2.4,.04,1.8,x+1.6,y+.04,z+1.8);I('box','#ffffff',2.4,.042,.3,x+1.6,y+.041,z+1.4);
  [0,1].forEach(k=>{const dx=x+1.2+k*.8,dz=z+1.8;I('cyl','#c9a86a',.02,.7,.02,dx,y+.35,dz,0,0,.3);['#ffb8d0','#ffffff','#9ae07a'].forEach((c,i)=>I('sph',c,.13,.13,.13,dx+.06-i*.08,y+.25+i*.2,dz,0,0,0));});col(x,z,1.2);
  W.things.push({x:x+1.6,z:z+3.4,r:3.6,icon:'🌸',label:'Hanami picnic',act:()=>{if(player.lock)return;sfx.chime();reward('hanami');for(let i=0;i<8;i++)setTimeout(()=>floatS('🌸',x+(Math.random()-.5)*3,y+3+Math.random()*2,z+(Math.random()-.5)*3,1.2),i*120);
    setTimeout(()=>card2(big('🌸🍡'),'Hanami!','In Japan, families and friends have picnics under the cherry blossom in spring. It is called hanami, which means flower watching. They eat hanami dango: pink, white and green sweet dumplings on a stick. The blossom only lasts a week or two, so everyone enjoys it while it is here!'),1100);}});
  sayOnce('hanami','The cherry blossom is out by the Dojo! There is a picnic rug under the tree.',2600);};
/* Number Kingdom: Fibonacci's rabbits in the Shape Garden */
const FIB=[1,1,2,3,5,8];
function rabbitsSVG(n){const rows=FIB.slice(0,n);let s=`<svg viewBox="0 0 340 ${30+rows.length*34}" width="340"><rect width="340" height="${30+rows.length*34}" rx="14" fill="#f0fff0"/>`;
  rows.forEach((v,i)=>{s+=`<text x="20" y="${40+i*34}" font-size="22" font-weight="900" fill="#3f6a2a" font-family="Arial">${v}</text>`;for(let k=0;k<v;k++)s+=`<text x="${56+k*34}" y="${42+i*34}" font-size="24">🐰</text>`;});return s+'</svg>';}
function fibo(){if(player.lock)return;player.lock=true;sfx.chime();
  card({art:`<div class="fitsvg" style="width:340px">${rabbitsSVG(5)}</div>`,h:'Fibonacci\'s rabbits!',p:'About 800 years ago, Leonardo Fibonacci wrote a puzzle about pairs of rabbits. Each new number is the two before it added together: 1, 1, 2, 3, 5... What comes next?<div class="sprow3">'+[8,6,7].sort(()=>Math.random()-.5).map(v=>`<button class="opt spfib" data-v="${v}">${v}</button>`).join('')+'</div>',
    say:'Fibonacci\'s rabbits! Each new number is the two before it added together. 1, 1, 2, 3, 5. What comes next?',btns:[['Back','white',()=>{player.lock=false;}]]});
  let tries=0;document.querySelectorAll('#celeCard .spfib').forEach(b=>tap(b,()=>{if(+b.dataset.v===8){sfx.fanfare();confetti(30);reward('fibo');player.lock=false;card2(`<div class="fitsvg" style="width:340px">${rabbitsSVG(6)}</div>`,'8! Brilliant!','3 add 5 makes 8. The next ones are 13, 21 and 34. You can find these numbers in nature too: count the spirals on a pine cone or a sunflower!');}
    else{tries++;sfx.oops();b.classList.add('nope');speak(tries>1?'Add the last two numbers: 3 add 5.':'Not quite. Add the two numbers before it!');}}));}
ISL.shapes=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-7,2),x=p[0],z=p[1],y=gy(x,z);I('box','#c98a4f',2.2,1.2,1.2,x,y+.6,z);I('box','#e8c08a',2.4,.12,1.4,x,y+1.26,z);I('box','#26232e',1.4,.7,.04,x,y+.65,z+.62,0,0,0,true);
  const R=seed(5);for(let i=0;i<5;i++){const bx=x-1.6+i*.8,bz=z+1.4,by=gy(bx,bz);I('sph','#f4ece4',.24,.22,.3,bx,by+.24,bz);I('sph','#f4ece4',.06,.22,.04,bx-.08,by+.6,bz+.1,0,0,.2);I('sph','#f4ece4',.06,.22,.04,bx+.08,by+.6,bz+.1,0,0,-.2);}col(x,z,1.4);
  W.things.push({x,z:z+2.6,r:3.8,icon:'🐰',label:'Fibonacci\'s rabbits',act:fibo});};
/* Gadget Island: Tinker's greenhouse */
function growSVG(){return `<svg viewBox="0 0 340 170" width="340"><rect width="340" height="170" rx="14" fill="#eaf7ff"/>`+[0,1,2].map(i=>{const x=60+i*110;return `<path d="M${x-30} 120 h60 l-8 36 h-44 Z" fill="#c8704a" stroke="#26232e" stroke-width="3"/><rect x="${x-34}" y="112" width="68" height="12" rx="4" fill="#d8805a" stroke="#26232e" stroke-width="3"/>`+
  (i===0?`<ellipse cx="${x}" cy="104" rx="7" ry="5" fill="#a87a4a" stroke="#26232e" stroke-width="2"/><text x="${x}" y="40" font-size="30" text-anchor="middle">💧</text>`:i===1?`<path d="M${x} 112 V86" stroke="#4a9a3a" stroke-width="4"/><path d="M${x} 90 q-14 -10 -18 -2 q8 8 18 2 Z M${x} 90 q14 -10 18 -2 q-8 8 -18 2 Z" fill="#7ac85a"/><text x="${x}" y="40" font-size="30" text-anchor="middle">🌡️</text>`:
  `<path d="M${x} 112 V54" stroke="#4a9a3a" stroke-width="4"/><path d="M${x} 90 q-18 -10 -22 0 q10 8 22 0 Z M${x} 76 q18 -10 22 0 q-10 8 -22 0 Z" fill="#7ac85a"/>${SL.flower2D(x,48,16,'#ff9ac0')}<text x="${x}" y="30" font-size="26" text-anchor="middle">☀️</text>`);}).join('')+'</svg>';}
ISL.workshop=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-8,3),x=p[0],z=p[1],y=gy(x,z);I('box','#bfe8ff',3,2,2,x,y+1,z,0,0,0,true);I('box','#8a92a0',3.1,.1,2.1,x,y+2.05,z);
  for(let i=0;i<4;i++){I('cyl','#c8704a',.22,.3,.22,x-1.1+i*.73,y+.85,z);I('sph',i%2?PINK:'#9ae07a',.2,.2,.2,x-1.1+i*.73,y+1.15,z);}I('box','#9b6a43',2.6,.1,.6,x,y+.7,z);col(x,z,1.8);
  W.things.push({x,z:z+2.6,r:3.8,icon:'🌱',label:'Tinker\'s greenhouse',act:()=>{if(player.lock)return;sfx.chime();reward('greenhouse');
    card2(`<div class="fitsvg" style="width:340px">${growSVG()}</div>`,'Tinker\'s greenhouse','"Watch them grow in fast-forward!" says Tinker. "A seed needs water and warmth to start growing. Once its first leaves come up, it needs light too. The glass traps the Sun\'s warmth, so my seeds grow even when it is chilly outside."');}});};
/* Rescue Bay: the Countryside Code gate at the Ranger Station */
ISL.ranger=A=>{const s=A.start||[0,0],p=place(A,s[0]+6,s[1]-8,3),x=p[0],z=p[1],y=gy(x,z);[-1.6,1.6].forEach(d=>I('box','#8a5a3a',.2,1.4,.2,x+d,y+.7,z));
  const gate=grp();for(let i=0;i<4;i++)mk('box','#c8a070',3,.12,.08,1.5,.3+i*.3,0,gate);mk('box','#c8a070',.12,1.1,.08,.1,.75,0,gate);mk('box','#c8a070',.12,1.1,.08,2.9,.75,0,gate);add(gate,x-1.5,z,y);gate.rotation.y=-1.2;
  const L=[];for(let i=0;i<3;i++){const g=lamb3D();g.scale.setScalar(.8);add(g,x-2+i*2,z-3);L.push(g);}let shut=0;
  W.ticks.push(dt=>{if(W.area!==A)return true;gate.rotation.y+=((shut?0:-1.2)-gate.rotation.y)*Math.min(1,dt*4);L.forEach((g,i)=>{g.position.y=gy(g.position.x,g.position.z)+Math.abs(Math.sin(W.t*3+i*2))*.15;g.rotation.y=Math.sin(W.t*.5+i)*.8;});});
  W.things.push({x,z:z+2.2,r:3.6,icon:'🚪',label:'The field gate',act:()=>{if(player.lock)return;shut=1;sfx.chime();reward('gate');
    setTimeout(()=>card2(big('🐑🚪✅'),'The Countryside Code','You closed the gate, so the lambs stay safe in their field! The Countryside Code says: leave gates as you find them, keep dogs on a lead near farm animals, take your litter home, and leave nests and baby animals alone.'),700);}});};
/* Planet Hop: the Moon tree at Moon Base */
ISL.moon=A=>{const s=A.start||[0,0],p=place(A,s[0]-6,s[1]-8,2),x=p[0],z=p[1],y=gy(x,z);I('cyl','#c8d0dc',1.2,.4,1.2,x,y+.2,z);I('cyl','#7a5230',.12,1.6,.12,x,y+1.2,z);I('sph','#5aaf4a',.8,.9,.8,x,y+2.4,z);I('sph','#bfe8ff',1.5,1.8,1.5,x,y+1.6,z,0,0,0,true);col(x,z,1.6);
  W.things.push({x,z:z+2.4,r:3.6,icon:'🌳',label:'The Moon tree',act:()=>{if(player.lock)return;sfx.chime();reward('moontree');
    card2(big('🌱🚀🌕🌳'),'Captain Nibbles: the Moon trees','"In 1971, astronaut Stuart Roosa took hundreds of tree seeds on Apollo 14. They flew all the way round the Moon, again and again! Back on Earth they were planted, and they grew into Moon trees, just as well as seeds that never left the ground."');}});};

/* ================= the spotlights ================= */
function prep(k){const C=COLLECT[k],A=W.area,s=[player.x,player.z],Gd=XM.grid(A,1),st=Gd.snap(s[0],s[1],1);C.items=[];if(st<0)return;const B=Gd.bfs(st),R=seed(Math.floor(Math.random()*9999)),out=[],n=C.n||8;
  for(let tries=0;tries<6000&&out.length<n;tries++){const kk=Math.floor(R()*Gd.N);if(Gd.clr[kk]<2||B.D[kk]>=1e9||B.D[kk]<6||B.D[kk]>60)continue;const p=Gd.xz(kk);if(out.some(q=>Math.hypot(q[0]-p[0],q[1]-p[1])<6))continue;out.push([p[0],p[1]]);}
  C.items=out;}
COLLECT.spegg={k:'spegg',area:'windmill',icon:'🥚',size:2,h:1,items:[],start:null,thing:'painted egg',art:'🧺',n:8,
  intro:'The Great Egg Hunt! There are 8 painted eggs hidden among the lambs and the daffodils. Find them all!',title:'All 8 painted eggs! Lambs are born in spring, when fresh new grass grows for their mums to eat.'};
const NBITS=['🪵','🌿','🪶','🌾','🪵','🌿','🪶','🌾'];
COLLECT.spnest={k:'spnest',area:'wood',icon:'🪵',size:2,h:1,items:[],start:null,thing:'nest thing',art:'🪺',n:8,
  intro:'The Nest Builder! A robin needs a nest. Collect 8 nest things: twigs, moss, feathers and grass!',title:'A cosy nest, and the robin moves in! Birds build nests to keep their eggs warm, safe and hidden.'};
function startSpot(k){if(player.lock||W.act)return;if(!W.area||W.area.id!==COLLECT[k].area)return;prep(k);if(COLLECT[k].items.length<5){say('Let\'s try that again in a moment!');return;}sfx.chime();startCollect(k);
  if(W.act&&k==='spnest')W.act.items.forEach((it,i)=>{W.ag.remove(it.sp);it.sp=spr(NBITS[i%NBITS.length],2,it.x,it.y,it.z);});}
ISL.windmill=A=>{const s=A.start||[0,0],p=place(A,s[0]+5,s[1]-6,2);sign(p[0]+1.6,p[1]-1.6,'🥚 Great Egg Hunt',3,6.4);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🧺',label:'Great Egg Hunt',act:()=>startSpot('spegg')});
  const L=[];for(let i=0;i<4;i++){const q=place(A,s[0]-6+i*3,s[1]-12,2),g=lamb3D();add(g,q[0],q[1]);L.push({g,x:q[0],z:q[1],ph:i});}
  W.ticks.push(()=>{if(W.area!==A)return true;L.forEach(o=>{const a=W.t*.3+o.ph*1.6;o.g.position.set(o.x+Math.cos(a)*1.4,gy(o.x,o.z)+Math.abs(Math.sin(W.t*4+o.ph))*.12,o.z+Math.sin(a)*1.4);o.g.rotation.y=-a;});});
  sayOnce('egghunt','Baa! There are lambs on Windmill Hill, and a Great Egg Hunt! Find the sign.',2600);};
ISL.wood=A=>{const s=A.start||[0,0],p=place(A,s[0]+5,s[1]-6,2);sign(p[0]+1.6,p[1]-1.6,'🪺 Nest Builder',3,6.4);W.things.push({x:p[0],z:p[1],r:3.8,icon:'🪺',label:'Nest Builder',act:()=>startSpot('spnest')});
  sayOnce('nestb','A robin in Bluebell Wood needs a nest! Find the Nest Builder sign.',2600);};
/* the Dino Egg Hatch at Long-neck's Nest: measure the eggs, then hatch them shortest to longest */
const ROUNDS=[{n:4,min:8,max:26},{n:5,min:10,max:32},{n:5,min:6,max:26,q:'ten'}];
let DE=null;
function eggUI(){if($('#speggs'))return;const d=el('div','ov','<div class="card" id="speCard"><h2 id="speH"></h2><div id="speBox"></div><p id="speMsg"></p><div class="btns"><button class="btn white" id="speBack">Back</button></div></div>');d.id='speggs';document.body.appendChild(d);
  tap('#speBack',()=>{sfx.boop();$('#speggs').classList.remove('on');player.lock=false;DE=null;});}
const DC=['#9ae07a','#8ad0ff','#ffb8d0','#ffe066','#c8a8ff'];
function eggRow(){const R=DE.R;let s=`<svg viewBox="0 0 640 300" id="speSvg"><rect width="640" height="300" rx="18" fill="#e8f6d0"/><path d="M0 230 Q320 200 640 230 V300 H0 Z" fill="#c8a070"/>`;
  s+=`<rect x="20" y="248" width="600" height="34" rx="6" fill="#ffe680" stroke="#8a6a2a" stroke-width="3"/>`;for(let c=0;c<=40;c++){const x=40+c*14;s+=`<path d="M${x} 248 v${c%5?8:14}" stroke="#5a4a2a" stroke-width="2"/>`+(c%10===0?`<text x="${x}" y="278" font-size="13" font-weight="900" text-anchor="middle" fill="#5a4a2a" font-family="Arial">${c}</text>`:'');}
  R.eggs.forEach((e,i)=>{const cx=e.x,h=e.cm*4.6,w=h*.72,cy=228-h/2,st=e.hatched?'hatched':e.meas?'meas':'';
    s+=`<g class="spe ${st}" data-i="${i}"><rect x="${cx-w/2-8}" y="${cy-h/2-8}" width="${w+16}" height="${h+16}" fill="transparent"/>`+
      (e.hatched?`<text x="${cx}" y="${cy+12}" font-size="${Math.max(30,h*.7)}" text-anchor="middle">🦕</text><path d="M${cx-w/2} ${228-h*.25} l${w*.2} -10 l${w*.2} 10 l${w*.2} -10 l${w*.2} 10 l${w*.2} -10 V228 H${cx-w/2} Z" fill="#f4ecd8" stroke="#26232e" stroke-width="2"/>`:
      `<path d="M${cx} ${cy-h/2} C${cx+w*.5} ${cy-h/2} ${cx+w*.56} ${cy+h*.1} ${cx+w*.5} ${cy+h*.22} C${cx+w*.44} ${cy+h/2} ${cx-w*.44} ${cy+h/2} ${cx-w*.5} ${cy+h*.22} C${cx-w*.56} ${cy+h*.1} ${cx-w*.5} ${cy-h/2} ${cx} ${cy-h/2} Z" fill="${e.col}" stroke="#26232e" stroke-width="3"/>`+[[-.2,-.15],[.15,.05],[-.1,.25],[.22,-.3]].map(q=>`<ellipse cx="${cx+q[0]*w}" cy="${cy+q[1]*h}" rx="${w*.07}" ry="${h*.05}" fill="#ffffff" opacity=".7"/>`).join(''))+
      (e.meas?`<rect x="${cx-26}" y="${cy-h/2-34}" width="52" height="26" rx="8" fill="#ffffff" stroke="#26232e" stroke-width="2.4"/><text x="${cx}" y="${cy-h/2-15}" font-size="17" font-weight="900" text-anchor="middle" fill="#26232e" font-family="Arial">${e.cm} cm</text>`:'')+`</g>`;});
  if(R.show){const e=R.eggs[R.show[0]],f=R.eggs[R.show[1]];[e,f].forEach((q,k)=>{s+=`<path d="M40 ${252-k*0} H${40+q.cm*14}" stroke="${k?'#e8427a':'#3f8a3a'}" stroke-width="7" stroke-linecap="round" opacity=".8" transform="translate(0 ${k?-10:-4})"/>`;});}
  return s+'</svg>';}
function hatch(){if(player.lock||W.act)return;eggUI();player.lock=true;hush();DE={r:0,t0:W.t};roundE();$('#speggs').classList.add('on');}
function roundE(){const D=ROUNDS[DE.r],used=new Set(),eggs=[];while(eggs.length<D.n){const cm=D.min+Math.floor(Math.random()*(D.max-D.min+1));if(used.has(cm)||[...used].some(u=>Math.abs(u-cm)<3))continue;used.add(cm);eggs.push({cm,col:DC[eggs.length%5]});}
  eggs.forEach((e,i)=>{e.x=70+i*(500/(D.n-1));});DE.R={D,eggs,next:0,tries:0,order:eggs.map((e,i)=>i).sort((a,b)=>eggs[a].cm-eggs[b].cm)};
  if(D.q==='ten'){const s=eggs[DE.R.order[0]];let t=eggs.findIndex(e=>e.cm===s.cm+10);if(t<0){const j=DE.R.order[DE.R.order.length-1];eggs[j].cm=s.cm+10;}DE.R.ten=eggs.findIndex(e=>e.cm===s.cm+10);}
  $('#speH').textContent=`🥚 Dino Egg Hatch: round ${DE.r+1} of 3`;drawE();
  const m=D.q==='ten'?'Tap each egg to measure it. Which egg is 10 centimetres longer than the smallest one?':'Tap each egg to measure it with the ruler. Then tap them in order, from the shortest to the longest, to hatch them!';$('#speMsg').textContent=m;speak(m);}
function drawE(){$('#speBox').innerHTML=eggRow();document.querySelectorAll('#speSvg .spe').forEach(g=>tap(g,()=>tapEgg(+g.dataset.i)));}
function tapEgg(i){const R=DE&&DE.R;if(!R)return;const e=R.eggs[i];if(e.hatched)return;
  if(!e.meas){e.meas=1;SR.snd.pop();drawE();const m=`That egg is ${e.cm} centimetres long.`;$('#speMsg').textContent=m;speak(m);if(R.eggs.every(q=>q.meas)){setTimeout(()=>{if(!DE||DE.R!==R||R.tapped)return;const m2=R.D.q==='ten'?`Which egg is 10 centimetres longer than the smallest? The smallest is ${R.eggs[R.order[0]].cm}.`:'Now tap them from the shortest to the longest!';$('#speMsg').textContent=m2;speak(m2);},1400);}return;}
  if(R.eggs.some(q=>!q.meas)){const m='Measure every egg first!';$('#speMsg').textContent=m;speak(m);return;}R.tapped=1;
  if(R.D.q==='ten'){if(i===R.ten){e.hatched=1;SR.snd.crack();sfx.fanfare();drawE();const s=R.eggs[R.order[0]];const m=`Yes! ${s.cm} add 10 makes ${e.cm}. Crack! A baby dinosaur!`;$('#speMsg').textContent=m;speak(m);setTimeout(()=>{R.eggs.forEach(q=>q.hatched=1);drawE();endRound();},1600);}
    else{R.tries++;sfx.oops();R.show=[R.order[0],i];drawE();R.show=null;const s=R.eggs[R.order[0]];const m=`That egg is ${e.cm} centimetres. ${s.cm} add 10 makes ${s.cm+10}. Look for the ${s.cm+10} centimetre egg!`;$('#speMsg').textContent=m;speak(m);}return;}
  const want=R.order[R.next];if(i===want){e.hatched=1;R.next++;SR.snd.crack();sfx.yip(1.4);drawE();if(R.next>=R.eggs.length){const m='They have all hatched, from the shortest to the longest!';$('#speMsg').textContent=m;speak(m);setTimeout(endRound,1600);}else{const m=`Crack! ${e.cm} centimetres. Which is next?`;$('#speMsg').textContent=m;}return;}
  R.tries++;sfx.oops();const w=R.eggs[want];R.show=[want,i];drawE();R.show=null;const m=`That egg is ${e.cm} centimetres, but this one is only ${w.cm}. Shorter eggs go first!`;$('#speMsg').textContent=m;speak(m);
  if(R.tries>=2){const g=document.querySelector(`#speSvg .spe[data-i="${want}"]`);if(g)g.classList.add('hint');}}
function endRound(){DE.r++;confetti(30);if(DE.r<ROUNDS.length){roundE();return;}const secs=W.t-DE.t0;$('#speggs').classList.remove('on');player.lock=false;DE=null;finishAct('sphatch',secs,big('🥚🦕🦕'),'Dino Hatcher! Every egg measured and hatched. Even the biggest dinosaur started as a tiny egg!',()=>hatch());}
ISL.nest=A=>{const s=A.start||[0,0],p=place(A,s[0]+5,s[1]-6,2),x=p[0],z=p[1];sign(x+1.6,z-1.6,'🥚 Dino Egg Hatch',3,6.4);const y=gy(x+2.6,z+1.4);I('tor','#9a6a3a',1.1,1.1,1.4,x+2.6,y+.3,z+1.4,PI/2,0,0);
  DC.forEach((c,i)=>I('sph',c,.3,.42,.3,x+2.6+Math.cos(i*1.3)*.5,y+.5,z+1.4+Math.sin(i*1.3)*.5));W.things.push({x,z,r:3.8,icon:'🦕',label:'Dino Egg Hatch',act:()=>hatch()});
  sayOnce('hatch','There are dinosaur eggs at Long-neck\'s Nest! Find the Dino Egg Hatch sign.',2600);};
function sTravel(area,pos,start,msg){if(!SR.on()){state.season='sp';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='sp'&&S.hide)try{S.hide();}catch(e){}});}arcadeTravel(area,pos,start,msg);}
regAct('spegg',{name:'Great Egg Hunt',icon:'🥚',island:'meadow',area:'windmill',where:'Spring Blossom, at Windmill Hill',lockSay:'Find the Great Egg Hunt on Windmill Hill in Spring Blossom, and play it there first!',play:()=>sTravel('windmill',null,()=>startSpot('spegg'),'The Great Egg Hunt!')});
regAct('spnest',{name:'Nest Builder',icon:'🪺',island:'meadow',area:'wood',where:'Spring Blossom, in Bluebell Wood',lockSay:'Find the Nest Builder in Bluebell Wood in Spring Blossom, and play it there first!',play:()=>sTravel('wood',null,()=>startSpot('spnest'),'The Nest Builder!')});
regAct('sphatch',{name:'Dino Egg Hatch',icon:'🦕',island:'dino',area:'nest',where:'Spring Blossom, at Long-neck\'s Nest',lockSay:'Find the Dino Egg Hatch at Long-neck\'s Nest in Spring Blossom, and play it there first!',play:()=>sTravel('nest',null,()=>hatch(),'The Dino Egg Hatch!')});
/* the Den: a blossom tree in a pot, a basket of painted eggs, a nest and a window box of daffodils, after the festival */
ISL.den=A=>{if(!G().done)return;const y=gy(-7,-5);I('cyl','#c8704a',.7,.8,.7,-7,y+.4,-5);btree(-7,-5,.6,PINK);
  I('cyl','#c98a4f',.6,.4,.6,6,gy(6,-4)+.2,-4);COLS.slice(0,5).forEach((c,i)=>I('sph',c,.16,.22,.16,6-.3+i*.15,gy(6,-4)+.5,-4+(i%2)*.15));
  I('tor','#9a6a3a',.5,.5,1.3,4,gy(4,-6)+.2,-6,PI/2,0,0);I('box','#c8704a',2,.4,.5,-4,gy(-4,-7)+.2,-7);daffs(-4,-7,6);};

/* ================= the Lab: a spring science quiz ================= */
const SQ=[['What does a seed need to start growing?','A seed needs water, air and warmth to start growing. Once its first leaves come up, it needs light too.',['Water, air and warmth','Chocolate','Darkness and ice'],'Water, air and warmth'],
 ['Why do birds build nests?','Nests keep the eggs and chicks warm, safe and hidden until they can look after themselves.',['To keep eggs warm and safe','To store their toys','To keep the rain off the tree'],'To keep eggs warm and safe'],
 ['About how long does a duck\'s egg take to hatch?','A duck\'s egg takes about 28 days to hatch. That is 4 weeks.',['About 4 weeks','About 4 hours','About 4 years'],'About 4 weeks'],
 ['Why do ducklings follow their mum?','Ducklings follow the first moving thing they see when they hatch, which is usually their mum. Scientists call this imprinting.',['They follow the first thing they see','They are lost','They like the smell'],'They follow the first thing they see'],
 ['What does a tadpole grow into?','A tadpole grows legs, loses its tail, and turns into a frog.',['A frog','A fish','A duck'],'A frog'],
 ['Why does spring come?','The Earth is tilted, so in spring our half of the world starts to lean towards the Sun. The days get longer and warmer.',['The Earth is tilted towards the Sun','The Moon gets closer','The clouds go away'],'The Earth is tilted towards the Sun']];
const springBG=()=>`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg"><rect width="1024" height="768" fill="#bfe4ff"/><circle cx="860" cy="140" r="64" fill="#ffe680"/>`+
  `<path d="M0 540 Q256 470 512 520 T1024 500 V768 H0 Z" fill="#9ad870"/>`+[[120,560],[300,600],[520,580],[760,610],[900,560]].map((q,i)=>SL.flower2D(q[0],q[1],22,i%2?'#ffd0e0':'#ff9ac0')).join('')+`</svg>`;
QUIZ.spring={k:'spring',name:'Spring Science',icon:'🌱',n:6,bg:springBG,introMs:3400,intro:'Professor Fizz has a spring science quiz! Seeds, nests, eggs and ducklings. Let\'s find out!',
  make:i=>{const q=SQ[i%SQ.length],o=q[2].slice().sort(()=>Math.random()-.5);return {q:q[0],say:q[0]+' '+o.join(', or ')+'?',pic:'<div style="font-size:110px;line-height:1">🌱🐣</div>',ans:q[3],opts:o,hintSay:q[1],after:`<div style="font-size:26px;font-weight:800;padding:10px">${q[1]}</div>`};},
  block:()=>'🌷',title:'Brilliant! You are a spring science star!'};
if(typeof openLab==='function'){const base=openLab;openLab=function(){base.apply(this,arguments);if(!SR.on())return;setTimeout(()=>{if(document.querySelector('#lab .spin'))return;const host=document.querySelector('#lab');if(!host)return;
  const b=el('button','btn green spin','🌱 Spring science');b.style.cssText='position:absolute;right:24px;bottom:24px;z-index:30;font-size:24px';tap(b,()=>{sfx.pop();startQuiz('lab','spring');});host.appendChild(b);},50);};}

/* ================= music ================= */
const C1=s=>tuneRow(s);
/* the opening of Spring from Vivaldi's Four Seasons (published 1725), as a music box, for the village */
TUNES.spvil={step:.22,mw:'triangle',mv:.42,hw:'sine',hv:.14,
  mel:C1('E5 G#5 G#5 G#5 F#5 E5 B5 - - B5 A5 G#5 G#5 G#5 F#5 E5 B5 - - B5 A5 G#5 A5 B5 A5 G#5 F#5 D#5 B4 - - . E5 G#5 G#5 G#5 F#5 E5 B5 - - B5 A5 G#5 G#5 G#5 F#5 E5 B5 - - B5 A5 G#5 A5 B5 A5 G#5 F#5 D#5 E5 - - .'),
  har:C1('G#5 B5 E6 B5 G#5 B5 E6 B5 F#5 A5 D#6 A5 G#5 B5 E6 B5'),
  bas:C1('E3 . . E3 . . E3 . . B2 . . E3 . . E3 . . E3 . . B2 . . A2 . . B2 . . B2 . . . . . E3 . . E3 . . E3 . . B2 . . E3 . . E3 . . E3 . . B2 . . A2 . . B2 . . E3 . . . . .'),drm:'k..h..k..h..'};
/* "Duckling Waddle", an original bouncy tune for the Lily Pond and the Festival Garden */
TUNES.spwad={step:.19,mw:'square',mv:.28,
  mel:C1('C5 . E5 . G5 G5 E5 . F5 . A5 A5 G5 . . . E5 . G5 . C6 C6 B5 . A5 . G5 . E5 . . . F5 . A5 . F5 . D5 . E5 . G5 . E5 . C5 . D5 . F5 . D5 . B4 . C5 - - .'),
  bas:C1('C3 . G2 . C3 . G2 . F2 . C3 . G2 . . . C3 . G2 . E3 . G2 . F2 . G2 . C3 . . . F2 . C3 . F2 . C3 . C3 . G2 . C3 . G2 . G2 . D3 . G2 . . . C3 . . .'),drm:'k.h.s.h.'};
const _mk=musKey;musKey=function(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;if(SR.on()&&typeof W!=='undefined'&&W&&W.area){const id=W.area.id;if(id==='village')return 'spvil';const T=SR.G0();if(id==='pond'&&T&&T.call&&!T.planted)return 'spwad';}return _mk();};
/* a little birdsong sparkle on the island tunes */
const _ps=playStep;playStep=function(T,i,t){_ps(T,i,t);if(!SR.on()||!AC||T===TUNES.spvil||T===TUNES.spwad||T===TUNES.disco)return;if(i%8===5){try{tone(3200,t,.05,'sine',.03,musF,4000);tone(3600,t+.08,.05,'sine',.025,musF,4300);}catch(e){}}};

/* ================= real-date daffodils: 1 to 7 March (St David's Day and the start of spring), by the Pup House, whatever the season ================= */
const isDaffs=()=>{const d=new Date();return d.getMonth()===2&&d.getDate()>=1&&d.getDate()<=7;};
{const _ea=enterArea;enterArea=function(id){_ea.apply(this,arguments);if(id!=='village'||!isDaffs()||!W.area||W.area.id!=='village')return;const ph=W.things.find(t=>/Pup House/.test(t.label||''));if(!ph)return;
  const p=near(W.area,ph.x+2.6,ph.z+2.2,1),q=near(W.area,ph.x-2.6,ph.z+2.2,1);daffs(p[0],p[1],8);daffs(q[0],q[1],8);flushTo(W.ag);
  if(!SR.on()){const y=new Date().getFullYear(),k='spdaff_'+y;state.acts=state.acts||{};if(!state.acts[k]){state.acts[k]=1;save();setTimeout(()=>{if(!player.lock&&!ovOpen())say('Happy St David\'s Day, and happy first week of spring, Seb! Look, there are daffodils by the Pup House!');},2600);}}};}

/* ================= build hooks ================= */
window.SPWORLD={build(A){if(A.id==='village')try{villageS(A);}catch(e){console.warn('sp village',e);}},
  after(A){GRD=null;if(A.id!=='village')TREE=null;try{decor(A);if(ISL[A.id])ISL[A.id](A);flushTo(W.ag);}catch(e){console.warn('sp island',A.id,e);}
    if(A.id==='village'&&window.SPSTORY&&SPSTORY.villageAfter)try{SPSTORY.villageAfter(A);}catch(e){}},
  btree,daffs,flowers,flags,lamb3D,turtle3D,bloom,hatch,startSpot,fibo,near,place,isDaffs,ROUNDS,tree:()=>TREE,_de:()=>DE};
const css=document.createElement('style');css.textContent=`.sprow3{display:flex;gap:14px;justify-content:center;margin:12px 0}.sprow3 .opt{font-size:34px;min-width:84px;min-height:70px;font-weight:900}.sprow3 .opt.nope{opacity:.4}
.spdrop{animation:xpop .6s both}
#speggs{z-index:60}#speCard{max-width:980px;width:96%;background:#f6fff0;padding-top:12px;padding-bottom:10px}#speCard h2{margin:0 0 4px}#speBox svg{width:760px;max-width:100%;height:auto;display:block;margin:4px auto;border-radius:16px}
#speSvg .spe{cursor:pointer}#speSvg .spe.meas{filter:drop-shadow(0 0 3px #ffffff)}#speSvg .spe.hint{animation:xhint .5s ease-in-out infinite;filter:drop-shadow(0 0 8px #ffd23f)}#speMsg{min-height:34px;font-size:24px;font-weight:800;margin:6px 0}`;
document.head.appendChild(css);
})();
