/* Puppy Quest 3: pup looks, forms and costumes, 2D drawing (from Puppy Quest 2) */
/* ============ helpers ============ */
const $=s=>document.querySelector(s);
const el=(tag,cls,html)=>{const e=document.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e;};
const INK='#5b4636';
const pick=a=>a[Math.floor(Math.random()*a.length)];
const abs=(html,x,y,w,cls,st)=>`<div class="abs" style="left:${x}px;top:${y}px;width:${w}px;${st||''}"><div class="${cls||''}">${html}</div></div>`;
function seed(n){return()=>((n=(n*9301+49297)%233280)/233280);}
let uid=0;

/* ============ ninja & legendary forms ============ */
const NINJA=[['#3a3640','#e8423a'],['#e8523a','#ffd23f'],['#5b8def','#ffffff'],['#7a5cd6','#ffd23f'],['#3fae5a','#ffffff'],['#ff8a3c','#3a3640'],['#e85d9a','#ffffff'],['#2fb3b3','#ffd23f']];
const LT={
 super:{n:'Super',icon:'💨',col:'#ff6b6b',pow:'Super Speed',pd:'you run super fast'},
 star:{n:'Star',icon:'🌠',col:'#b58cff',pow:'Wishing Star',pd:'a pup is always found the first time you search its hiding spot'},
 rainbow:{n:'Rainbow',icon:'🌈',col:'#ff9ecb',pow:'Rainbow Guide',pd:'a rainbow shows you the nearest hiding spot'},
 space:{n:'Cosmic',icon:'🌌',col:'#7f6bff',pow:'Black Hole',pd:'apples whoosh towards you from far away'},
 jewel:{n:'Jewel',icon:'💎',col:'#5ce0e6',pow:'Treasure Finder',pd:'every apple counts as two'},
 golden:{n:'Golden',icon:'👑',col:'#ffc928',pow:'Golden Luck',pd:'sparkly pups turn up much more often'},
 thunder:{n:'Thunder',icon:'⚡',col:'#5cb8ff',pow:'Thunder Bark',pd:'hiding spots fill up again super fast'},
 all:{n:'Legendary',icon:'🦄',col:'#ffb3e6',pow:'Every Power',pd:'you get every single power at once'}};
const LTK=['super','star','rainbow','space','jewel','golden','thunder'];
function shade(h,a){const n=parseInt(h.slice(1),16),f=c=>Math.max(0,Math.min(255,Math.round(a>0?c+(255-c)*a:c*(1+a))));return '#'+((1<<24)|(f(n>>16)<<16)|(f(n>>8&255)<<8)|f(n&255)).toString(16).slice(1);}
const XMAS_HATS=['santa','elf','antlers','bobble'],XMAS_JUMP=[['#d9363e','#ffffff'],['#2f9a54','#ffffff'],['#2b4a8a','#ffffff'],['#f3ead8','#d9363e'],['#8a2f5a','#ffd23f']];
const SPACE_TRIM=['#5b8def','#e8423a','#ffd23f','#3fae5a','#b58cff','#ff8a3c','#2fb3b3','#e85d9a'];
const LAVA_HAT=['#ffd23f','#ff8a3c','#e8423a','#ffd23f'],LAVA_STRIPE=['#ff8a3c','#ffd23f','#ff6b6b','#c6f04a'];
const FIRE=['#ffe066','#ffc23a','#ff9a3c','#ff6b2a','#e8423a','#c9302a'];
const KEEP2=['glow','startail','bubbles','drops','fireflies','embers','twinkle','unihorn','rmane'];
function formLook(p){
  const dk=p.dressAs!=null?p.dressAs:(!p.uni&&typeof state!=='undefined'&&state&&state.dress?state.dress[p.id+'@'+p.lv]:null);
  if(dk&&dk!=='none'&&typeof COS!=='undefined'&&COS[dk]&&!p.uni){const L=Object.assign({},p.look);L.acc=(L.acc||[]).slice();return applyCos(L,dk);}
  const L=Object.assign({},p.look);L.acc=(L.acc||[]).slice();
  if(p.form===9){if(p.uni)return L;return applyCos(L,p.cos);}
  if(p.form===2){const q=NINJA[(p.ni||0)%NINJA.length];
    L.ninja={suit:q[0],band:q[1]};L.body=q[0];L.belly=shade(q[0],.22);L.paw=shade(q[0],-.25);
    L.fluffy=false;L.fringe=null;L.blaze=null;L.spots=false;L.face=null;L.collar=null;L.bodyPatch=null;L.wool=false;L.eyeWhite=true;
    L.acc=L.acc.filter(a=>KEEP2.indexOf(a)>=0);return L;}
  if(p.form===8){if(p.uni)return L;L.snack={k:SNACKS[(p.ni||0)%SNACKS.length]};if(L.snack.k==='donut'||L.snack.k==='hotdog')L.collar=null;L.acc=L.acc.filter(a=>['barrel','ring','shellneck'].indexOf(a)<0);return L;}
  if(p.form===7){if(p.part){const P={p:['p⁺','#ff9a9a','#ff6b6b'],n:['n','#d0d8e4','#b8c4d6'],q:['q','#9be8ff','#7fe0ff']}[p.part];L.atom={st:'part',sym:P[0],num:'',tile:P[1],glow:P[2]};return L;}
    const E=p.el;if(!E)return L;L.atom={st:E.st,sym:E.sym,num:E.n,tile:EGC[E.g],col:E.col,glow:E.g==='ng'?E.col:null,melt:E.sym==='Ga'};L.collar=null;L.acc=L.acc.filter(a=>KEEP2.indexOf(a)>=0||['cap','bow','flower','glasses','scarf'].indexOf(a)>=0);if(E.st==='metal'||E.st==='liquid')L.acc=L.acc.filter(a=>['cap','bow','flower'].indexOf(a)<0);return L;}
  if(p.form===6){if(p.uni)return L;const i=p.ni||0;L.lava={hat:LAVA_HAT[i%4],stripe:LAVA_STRIPE[(i+1)%4],crystal:i%4===3};L.body='#cfd4de';L.belly='#e6e9f0';L.paw='#5a5560';L.collar=null;L.bodyPatch=null;L.noBodySpots=true;L.wool=false;L.eyeWhite=true;
    L.tailTip='#ff8a3c';L.acc=L.acc.filter(a=>KEEP2.indexOf(a)>=0&&a!=='bubbles'&&a!=='drops');if(L.acc.indexOf('glow')<0)L.acc.push('glow');return L;}
  if(p.form===5){if(p.uni)return L;const tr=SPACE_TRIM[(p.ni||0)%SPACE_TRIM.length];L.space={trim:tr,ant:(p.ni||0)%2===0};L.body='#eef1f7';L.belly='#ffffff';L.paw=tr;L.collar=null;L.bodyPatch=null;L.noBodySpots=true;L.wool=false;L.eyeWhite=true;
    L.acc=L.acc.filter(a=>KEEP2.indexOf(a)>=0&&a!=='bubbles');return L;}
  if(p.form===4){if(p.uni){L.xmas={bell:true};return L;}const i=p.ni||0,q=XMAS_JUMP[(i+Math.floor(i/4))%5],hat=XMAS_HATS[i%4];
    L.xmas={hat,jump:q[0],pat:q[1],bell:true};L.body=q[0];L.belly=shade(q[0],.2);L.collar=null;L.bodyPatch=null;L.noBodySpots=true;L.wool=false;
    L.acc=L.acc.filter(a=>KEEP2.concat(['mittens','flake']).indexOf(a)>=0);if(hat==='antlers')L.acc.push('antlers');return L;}
  if(p.form===3){const t=p.lt,a=L.acc,add=x=>{if(a.indexOf(x)<0)a.push(x);};L.legend=t;L.eyeWhite=true;
    if(t==='super')L.cape=['#e8423a','#5b8def','#7a5cd6'][(p.ni||0)%3];
    else if(t==='star'){add('startail');add('twinkle');}
    else if(t==='rainbow'){L.ear='rainbow';L.tailFill='rainbow';add('rainbow');L.iris=L.iris||'#b58cff';}
    else if(t==='space'){L.body='#eef2f8';L.belly='#dfe6f2';L.paw='#c9d2e3';L.noBodySpots=true;L.bodyPatch=null;}
    else if(t==='golden'){L.body='#f2c230';L.belly='#ffe27a';L.paw='#e0a82e';L.noBodySpots=true;L.bodyPatch=null;}
    else if(t==='thunder')L.iris='#5cb8ff';
    if(t!=='all'&&t!=='rainbow'){L.collar=null;L.acc=L.acc.filter(x=>['daisy','shellneck','barrel','moon','ring','mittens','dirt','cap','rainbow'].indexOf(x)<0);}
    return L;}
  return L;}
function gem(x,y,r,c,k){return `<path d="M${x} ${y-r} L${x+r*.8} ${y} L${x} ${y+r} L${x-r*.8} ${y} Z" fill="${c}" stroke="${k}" stroke-width="2.5" stroke-linejoin="round"/><path d="M${x-r*.32} ${y-r*.3} l${r*.25} ${-r*.25}" stroke="#fff" stroke-width="2" stroke-linecap="round"/>`;}
function bolt(x,y,c){return `<path class="twk" d="M${x+4} ${y-14} L${x-6} ${y+2} L${x+1} ${y+2} L${x-4} ${y+14} L${x+8} ${y-3} L${x+1} ${y-3} Z" fill="${c}" stroke="${INK}" stroke-width="2.5" stroke-linejoin="round"/>`;}
function form2D(w,c){
  if(c.L.cos)return cos2D(w,c);
  const L=c.L,N=L.ninja,t=L.legend,X=L.xmas,SP=L.space,LV=L.lava,AT=L.atom,SN=L.snack&&L.snack.k,cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,S3=c.S3,k=c.k,A=c.A;let s='';
  if(!N&&!t&&!X&&!SP&&!LV&&!AT&&!SN)return '';
  if(w==='aura'){const col=t&&LT[t]?LT[t].col:AT&&AT.glow;if(!col)return '';return `<defs><radialGradient id="${c.id}L"><stop offset=".3" stop-color="${col}" stop-opacity=".8"/><stop offset="1" stop-color="${col}" stop-opacity="0"/></radialGradient></defs><circle cx="100" cy="110" r="110" fill="url(#${c.id}L)"${A('glow')}/>`;}
  if(w==='behind'){
    if(SN==='hotdog'){const w2=bw+40;s+=`<rect x="${100-w2}" y="${by-bh-8}" width="${w2*2}" height="${bh*2+22}" rx="${Math.min(w2,bh+11)}" fill="#e8b46a" ${S}/><rect x="${100-w2+9}" y="${by-bh}" width="${w2*2-18}" height="${bh*2+6}" rx="${Math.min(w2-9,bh)}" fill="#f6d39a"/>`;for(const g of[-1,1]){const x=100+g*(w2-12);s+=`<path d="M${x} ${by-bh+4} l${g*-7} 9 l${g*7} 9 l${g*-7} 9 l${g*7} 9 l${g*-7} 9" stroke="#ffc928" stroke-width="6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>`;}}
    if(SN==='pizza'){const y0=by-bh-10,w2=bw+40;s+=`<path d="M${100-w2} ${y0} L${100+w2} ${y0} L100 ${by+bh+34} Z" fill="#ffd27a" ${S}/><path d="M${100-w2-4} ${y0} L${100+w2+4} ${y0}" stroke="#c98a4f" stroke-width="16" stroke-linecap="round"/><path d="M${100-w2-4} ${y0} L${100+w2+4} ${y0}" stroke="${k}" stroke-width="3" opacity=".5"/>`+[[-.82,.12],[.8,.16],[-.58,.42],[.6,.4],[0,.9]].map(q=>`<circle cx="${100+q[0]*w2}" cy="${y0+q[1]*(by+bh+34-y0)}" r="9" fill="#e8423a" stroke="${k}" stroke-width="2.5"/>`).join('');}
    if(AT&&AT.st==='crystal')for(const g of[-1,1])s+=gem(100+g*(bw+5),by-8,18,AT.col,k)+gem(100+g*(bw-6),by-bh-1,13,shade(AT.col,.35),k)+gem(100+g*(bw-18),by-bh-10,9,AT.col,k);
    if(LV&&LV.crystal)for(const g of[-1,1])s+=gem(100+g*(bw+5),by-8,18,g<0?'#5ce0e6':'#ff7fb8',k)+gem(100+g*(bw-6),by-bh-1,12,'#b58cff',k);
    if(SP)for(const g of[-1,1]){const x=100+g*(bw+5),y=by-bh-2;s+=`<path class="flt" d="M${x-8} ${y+44} Q${x} ${y+74} ${x+8} ${y+44} Z" fill="#ff8a3c" stroke="${k}" stroke-width="3" stroke-linejoin="round"/><path d="M${x-4} ${y+46} Q${x} ${y+62} ${x+4} ${y+46} Z" fill="#ffe066"/><rect x="${x-11}" y="${y}" width="22" height="46" rx="10" fill="#c9d2e3" ${S3}/><rect x="${x-11}" y="${y+12}" width="22" height="7" fill="${SP.trim}"/>`;}
    if(t==='super')s+=`<path d="M${cx-30} ${cy+hh-12} C${100-bw-34} ${by-16} ${100-bw-42} ${by+bh-6} ${100-bw-28} 196 L${100+bw+28} 196 C${100+bw+42} ${by+bh-6} ${100+bw+34} ${by-16} ${cx+30} ${cy+hh-12} Z" fill="${L.cape}" ${S}/>`;
    if(t==='jewel')for(const g of[-1,1])s+=gem(100+g*(bw+6),by-6,20,g<0?'#5ce0e6':'#ff7fb8',k)+gem(100+g*(bw-4),by-bh-2,13,'#b58cff',k);
  }
  if(w==='bodyClip'){
    if(LV)s+=`<rect x="${100-bw}" y="${by-bh*.32}" width="${bw*2}" height="9" fill="${LV.stripe}"/><rect x="${100-bw}" y="${by+bh*.3}" width="${bw*2}" height="9" fill="${LV.stripe}"/><path d="M${100-bw} ${by-bh*.32+4.5} H${100+bw} M${100-bw} ${by+bh*.3+4.5} H${100+bw}" stroke="#ffffff" stroke-width="2" stroke-dasharray="6 6" opacity=".8"/>`;
    if(SP)s+=`<rect x="${100-bw}" y="${by+bh*.18}" width="${bw*2}" height="10" fill="${SP.trim}"/><path d="M${100-bw} ${by-bh*.55} H${100+bw}" stroke="${SP.trim}" stroke-width="5"/>`;
    if(X&&X.pat){let z='';for(let x=100-bw;x<100+bw;x+=14)z+=`l7 -8 l7 8 `;s+=`<path d="M${100-bw} ${by-2} ${z}" fill="none" stroke="${X.pat}" stroke-width="5" stroke-linejoin="round"/><path d="M${100-bw} ${by+12} H${100+bw}" stroke="${X.pat}" stroke-width="3" stroke-dasharray="3 7" stroke-linecap="round"/>`;}
    if(N)s+=`<rect x="${100-bw}" y="${by+bh*.02}" width="${bw*2}" height="12" fill="${N.band}"/>`;
    if(t==='thunder')for(const g of[-1,1])s+=`<path d="M${100+g*bw*.95} ${by-18} l${-g*14} 12 l${g*9} 3 l${-g*13} 15" fill="none" stroke="#ffd23f" stroke-width="6" stroke-linejoin="round" stroke-linecap="round"/>`;
    if(t==='golden')s+=`<path d="M${100-bw} ${by+2} H${100+bw} M${100-bw} ${by+18} H${100+bw}" stroke="#c98a1e" stroke-width="3" opacity=".6"/>`;
  }
  if(w==='chest'){
    if(SN==='donut'){const ry=by+bh*.42,rx=bw+16,cols=['#ff4f6d','#ffd23f','#5cb8ff','#3fae5a','#ffffff','#b58cff'];s+=`<ellipse cx="100" cy="${ry}" rx="${rx}" ry="17" fill="none" stroke="${k}" stroke-width="30"/><ellipse cx="100" cy="${ry}" rx="${rx}" ry="17" fill="none" stroke="#e8b46a" stroke-width="23"/><path d="M${100-rx-6} ${ry+3} A${rx} 17 0 0 0 ${100+rx+6} ${ry+3}" fill="none" stroke="#ff9ecb" stroke-width="15" stroke-linecap="round"/>`;
      for(let q=0;q<9;q++){const a=Math.PI*(.1+q*.1),x=100-Math.cos(a)*rx,y=ry+Math.sin(a)*17+2;s+=`<path d="M${x-3} ${y-2} l6 3" stroke="${cols[q%6]}" stroke-width="3.5" stroke-linecap="round"/>`;}}
    if(AT){const tx=bcx-18,ty=by-16;s+=`<rect x="${tx}" y="${ty}" width="36" height="36" rx="6" fill="${AT.tile}" ${S3}/>`+(AT.num?`<text x="${tx+5}" y="${ty+11}" font-size="10" font-weight="800" fill="${k}" font-family="Arial,Helvetica,sans-serif">${AT.num}</text>`:'')+`<text x="${bcx}" y="${ty+28}" font-size="${AT.sym.length>1?17:20}" font-weight="900" fill="${k}" text-anchor="middle" font-family="Arial,Helvetica,sans-serif">${AT.sym}</text>`;}
    if(SP)s+=`<rect x="${bcx-14}" y="${by-10}" width="28" height="20" rx="5" fill="#c9d2e3" ${S3}/><circle cx="${bcx-7}" cy="${by}" r="3.5" fill="#e8423a"/><circle cx="${bcx}" cy="${by}" r="3.5" fill="#3fae5a"/><circle cx="${bcx+7}" cy="${by}" r="3.5" fill="#ffd23f"/>`;
    if(X&&X.bell){const d=`M${cx-34} ${cy+hh-14} Q${cx} ${cy+hh+30} ${cx+34} ${cy+hh-14}`,bx=cx,byl=cy+hh+12;s+=`<path d="${d}" fill="none" stroke="${k}" stroke-width="13" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#d9363e" stroke-width="7" stroke-linecap="round"/><circle cx="${bx}" cy="${byl}" r="10" fill="#ffd23f" ${S3}/><path d="M${bx-6} ${byl+2} h12" stroke="${k}" stroke-width="2.5" stroke-linecap="round"/><circle cx="${bx}" cy="${byl+5}" r="2" fill="${k}"/>`;}
    if(N)s+=`<rect x="${bcx-9}" y="${by+bh*.02-3}" width="18" height="18" rx="4" fill="#ffd23f" ${S3}/>`;
    if(t==='super')s+=`<circle cx="${bcx}" cy="${by+4}" r="14" fill="#ffd23f" ${S3}/>`+star5(bcx,by+5,10,L.cape,k);
    if(t==='space')s+=`<circle cx="${bcx}" cy="${by+6}" r="11" fill="#7f6bff" ${S3}/><ellipse cx="${bcx}" cy="${by+6}" rx="18" ry="5" fill="none" stroke="#ffd23f" stroke-width="3" transform="rotate(-20 ${bcx} ${by+6})"/>`;
    if(t==='golden')s+=star5(bcx,by+8,13,'#fff3a8',k);
    if(t==='jewel'){const d=`M${cx-36} ${cy+hh-14} Q${cx} ${cy+hh+34} ${cx+36} ${cy+hh-14}`;s+=`<path d="${d}" fill="none" stroke="${k}" stroke-width="10" stroke-linecap="round"/><path d="${d}" fill="none" stroke="#e6dcff" stroke-width="4" stroke-linecap="round"/>`;
      [-26,-13,0,13,26].forEach((x,i)=>{s+=gem(cx+x,cy+hh+11-Math.abs(x)*.5,i===2?10:6,['#ff7fb8','#5ce0e6','#b58cff','#5ce0e6','#ff7fb8'][i],k);});}
  }
  if(w==='headClip'){
    if(N){const oy=cy+hh*.22,rx=hw*.8,ry=hh*.5;
      s+=`<path fill-rule="evenodd" d="M${cx-hw-8} ${cy-hh-8} h${hw*2+16} v${hh*2+16} h${-hw*2-16} Z M${cx-rx} ${oy} a${rx} ${ry} 0 1 0 ${rx*2} 0 a${rx} ${ry} 0 1 0 ${-rx*2} 0 Z" fill="${N.suit}"/>`;
      s+=`<ellipse cx="${cx}" cy="${oy}" rx="${rx}" ry="${ry}" fill="none" stroke="${k}" stroke-width="3"/><rect x="${cx-hw-6}" y="${cy-hh*.74}" width="${hw*2+12}" height="${hh*.21}" fill="${N.band}" stroke="${k}" stroke-width="3"/>`;}
    if(t==='super')s+=`<rect x="${cx-hw-4}" y="${cy-15}" width="${hw*2+8}" height="26" rx="12" fill="${L.cape}" stroke="${k}" stroke-width="3"/>`;
    if(t==='golden')s+=`<ellipse cx="${cx}" cy="${cy-hh*.62}" rx="${hw*1.04}" ry="${hh*.52}" fill="#f2c230" stroke="${k}" stroke-width="3"/><rect x="${cx-5}" y="${cy-hh*.5}" width="10" height="${hh*.42}" rx="4" fill="#e0a82e" stroke="${k}" stroke-width="2.5"/>`;
  }
  if(w==='headOver'){
    if(N){const kx=cx+hw*.9,ky=cy-hh*.63;s+=c.two(`M${kx} ${ky} q16 -12 32 -6`,N.band,7)+c.two(`M${kx} ${ky} q18 2 30 14`,N.band,7)+`<circle cx="${kx}" cy="${ky}" r="7" fill="${N.band}" ${S3}/>`;}
  }
  if(w==='top'&&X&&X.hat){const yb=cy-hh*.6,h=X.hat;
    if(h==='santa')s+=`<path d="M${cx-hw*.8} ${yb} C${cx-hw*.62} ${yb-48} ${cx+hw*.2} ${yb-64} ${cx+hw*.9} ${yb-38} C${cx+hw*.52} ${yb-32} ${cx+hw*.72} ${yb-14} ${cx+hw*.8} ${yb} Z" fill="#d9363e" ${S}/><circle cx="${cx+hw*.94}" cy="${yb-36}" r="11" fill="#ffffff" ${S3}/><rect x="${cx-hw*.88}" y="${yb-11}" width="${hw*1.76}" height="21" rx="10.5" fill="#ffffff" ${S3}/>`;
    if(h==='elf')s+=`<path d="M${cx-hw*.74} ${yb} Q${cx-hw*.1} ${yb-44} ${cx+hw*.66} ${yb-62} Q${cx+hw*.42} ${yb-30} ${cx+hw*.74} ${yb} Z" fill="#3fae5a" ${S}/><circle cx="${cx+hw*.68}" cy="${yb-62}" r="8" fill="#ffd23f" ${S3}/><rect x="${cx-hw*.8}" y="${yb-9}" width="${hw*1.6}" height="17" rx="5" fill="#d9363e" ${S3}/><path d="M${cx-hw*.7} ${yb} h${hw*1.4}" stroke="#ffffff" stroke-width="4" stroke-dasharray="8 8"/>`;
    if(h==='antlers'){const hx=cx+hw*.18,hy=cy-hh*.82;s+=`<ellipse cx="${hx-8}" cy="${hy}" rx="11" ry="6" fill="#2f9a54" ${S3} transform="rotate(-25 ${hx-8} ${hy})"/><ellipse cx="${hx+8}" cy="${hy}" rx="11" ry="6" fill="#2f9a54" ${S3} transform="rotate(25 ${hx+8} ${hy})"/><circle cx="${hx-3}" cy="${hy+5}" r="4.5" fill="#e8423a" stroke="${k}" stroke-width="2"/><circle cx="${hx+4}" cy="${hy+6}" r="4.5" fill="#e8423a" stroke="${k}" stroke-width="2"/>`;}
    if(h==='bobble')s+=`<path d="M${cx-hw*.86} ${yb+2} A${hw*.86} ${hh*.66} 0 0 1 ${cx+hw*.86} ${yb+2} Z" fill="${X.jump}" ${S}/><path d="M${cx-hw*.7} ${yb-hh*.32} Q${cx} ${yb-hh*.44} ${cx+hw*.7} ${yb-hh*.32}" fill="none" stroke="${X.pat}" stroke-width="6" stroke-linecap="round"/><circle cx="${cx}" cy="${yb-hh*.66-6}" r="13" fill="#ffffff" ${S3}/><rect x="${cx-hw*.9}" y="${yb-8}" width="${hw*1.8}" height="17" rx="7" fill="${shade(X.jump,-.18)}" ${S3}/>`;}
  if(w==='top'&&SN==='icecream'){const sx=cx,sy=cy-hh*1.0,r=hw*.6;s+=`<rect x="${sx+r*.25}" y="${sy-r*1.35}" width="12" height="${r*.9}" rx="3" fill="#e8b46a" transform="rotate(25 ${sx+r*.3} ${sy-r*.9})" ${S3}/><path d="M${sx-r} ${sy+r*.1} Q${sx-r*1.05} ${sy-r*1.05} ${sx} ${sy-r*1.1} Q${sx+r*1.05} ${sy-r*1.05} ${sx+r} ${sy+r*.1} Q${sx+r*.8} ${sy+r*.45} ${sx+r*.55} ${sy+r*.15} Q${sx+r*.3} ${sy+r*.6} ${sx} ${sy+r*.2} Q${sx-r*.3} ${sy+r*.55} ${sx-r*.55} ${sy+r*.15} Q${sx-r*.8} ${sy+r*.45} ${sx-r} ${sy+r*.1}Z" fill="#ff9ecb" ${S}/><ellipse cx="${sx-r*.4}" cy="${sy-r*.55}" rx="${r*.22}" ry="${r*.12}" fill="#fff" opacity=".6"/><circle cx="${sx}" cy="${sy-r*1.22}" r="11" fill="#e8423a" ${S3}/><path d="M${sx} ${sy-r*1.32} q4 -14 12 -18" stroke="#3f9a46" stroke-width="3.5" fill="none" stroke-linecap="round"/>`+[[-.5,-.4,'#5cb8ff'],[.3,-.6,'#ffd23f'],[.55,-.15,'#3fae5a'],[-.15,-.15,'#ffffff']].map(q=>`<path d="M${sx+q[0]*r-3} ${sy+q[1]*r} l6 2" stroke="${q[2]}" stroke-width="3.5" stroke-linecap="round"/>`).join('');}
  if(w==='top'&&SN==='cupcake'){const sx=cx,sy=cy-hh*.92,r=hw*.5;s+=`<path d="M${sx-r} ${sy-24} L${sx+r} ${sy-24} L${sx+r*.78} ${sy+6} L${sx-r*.78} ${sy+6}Z" fill="#ff9ecb" ${S}/>`+[-.5,0,.5].map(q=>`<path d="M${sx+q*r} ${sy-22} L${sx+q*r*.8} ${sy+4}" stroke="#e86b9a" stroke-width="4"/>`).join('')+`<ellipse cx="${sx}" cy="${sy-30}" rx="${r*1.08}" ry="16" fill="#fff6f0" ${S}/><ellipse cx="${sx}" cy="${sy-46}" rx="${r*.78}" ry="14" fill="#fff6f0" ${S}/><ellipse cx="${sx}" cy="${sy-60}" rx="${r*.45}" ry="11" fill="#fff6f0" ${S}/><circle cx="${sx}" cy="${sy-76}" r="10" fill="#e8423a" ${S3}/>`+[[-.6,-32,'#5cb8ff'],[.5,-36,'#ffd23f'],[-.2,-50,'#3fae5a'],[.35,-52,'#ff4f6d']].map(q=>`<path d="M${sx+q[0]*r-3} ${sy+q[1]} l6 2" stroke="${q[2]}" stroke-width="3.5" stroke-linecap="round"/>`).join('');}
  if(w==='top'&&AT){const yb=cy-hh*.42;
    if(AT.st==='metal'){const hc=AT.col;s+=`<path d="M${cx-hw*.92} ${yb} Q${cx-hw*.92} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.92} ${cy-hh*1.2} ${cx+hw*.92} ${yb} Z" fill="${hc}" ${S}/><rect x="${cx-hw}" y="${yb-6}" width="${hw*2}" height="12" rx="6" fill="${shade(hc,-.15)}" ${S3}/><path d="M${cx-hw*.6} ${yb-12} Q${cx-hw*.56} ${cy-hh*1.0} ${cx-hw*.12} ${cy-hh*1.1}" fill="none" stroke="#ffffff" stroke-width="7" stroke-linecap="round" opacity=".85"/>`+star4(cx+hw*.62,cy-hh*1.08,9,'#ffffff','twk');
      if(AT.melt)[-.62,-.1,.48].forEach((x,i)=>{s+=`<ellipse cx="${cx+hw*x}" cy="${yb+12+i%2*4}" rx="5" ry="${9+i%2*3}" fill="${hc}" ${S3}/>`;});}
    if(AT.st==='liquid'){const y2=cy-hh*.5,hc=AT.col;s+=`<path d="M${cx-hw*.9} ${y2} Q${cx-hw*.9} ${cy-hh*1.15} ${cx} ${cy-hh*1.18} Q${cx+hw*.9} ${cy-hh*1.15} ${cx+hw*.9} ${y2} Q${cx+hw*.72} ${y2+22} ${cx+hw*.5} ${y2} Q${cx+hw*.22} ${y2+28} ${cx-hw*.05} ${y2} Q${cx-hw*.34} ${y2+24} ${cx-hw*.6} ${y2} Q${cx-hw*.8} ${y2+16} ${cx-hw*.9} ${y2} Z" fill="${hc}" fill-opacity=".92" ${S}/><ellipse cx="${cx-hw*.42}" cy="${cy-hh*.95}" rx="9" ry="6" fill="#fff" opacity=".55"/>`;}
    if(AT.st==='gas'){const top=cy-hh-8,bot=by+bh+20,r=(bot-top)/2,yc=(top+bot)/2;s+=`<circle cx="100" cy="${yc}" r="${r}" fill="#e8f6ff" fill-opacity=".13" stroke="#8fd0ff" stroke-width="4"/><path d="M${100-r*.72} ${yc-r*.42} A${r*.86} ${r*.86} 0 0 1 ${100-r*.2} ${yc-r*.82}" fill="none" stroke="#fff" stroke-width="8" stroke-linecap="round" opacity=".85"/><circle class="flt" cx="${100+r*.82}" cy="${yc-r*.62}" r="7" fill="#e8f6ff" fill-opacity=".3" stroke="#8fd0ff" stroke-width="3"/><circle cx="${100+r*.95}" cy="${yc-r*.2}" r="4" fill="#e8f6ff" fill-opacity=".3" stroke="#8fd0ff" stroke-width="2.5"/>`;}}
  if(w==='top'&&LV){const yb=cy-hh*.42,hc=LV.hat;
    s+=`<path d="M${cx-hw*.92} ${yb} Q${cx-hw*.92} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.92} ${cy-hh*1.2} ${cx+hw*.92} ${yb} Z" fill="${hc}" ${S}/><path d="M${cx} ${cy-hh*1.2} V${yb}" stroke="${shade(hc,-.2)}" stroke-width="7" stroke-linecap="round"/><rect x="${cx-hw*1.04}" y="${yb-6}" width="${hw*2.08}" height="13" rx="6.5" fill="${shade(hc,-.12)}" ${S3}/>`;
    s+=`<circle${A('glow')} cx="${cx}" cy="${cy-hh*.8}" r="24" fill="#fff6a8" opacity=".5"/><circle cx="${cx}" cy="${cy-hh*.8}" r="12" fill="#c9d2e3" ${S3}/><circle cx="${cx}" cy="${cy-hh*.8}" r="7.5" fill="#fff27a"/><circle cx="${cx-2.5}" cy="${cy-hh*.8-2.5}" r="2.5" fill="#ffffff"/>`;}
  if(w==='top'&&SP){const r=Math.max(hw,hh)+16;
    s+=`<ellipse cx="${cx}" cy="${cy+hh-2}" rx="${hw*.78}" ry="10" fill="${SP.trim}" ${S3}/><circle cx="${cx}" cy="${cy+2}" r="${r}" fill="#d6f1ff" fill-opacity=".2" stroke="${k}" stroke-width="4"/><path d="M${cx-r*.62} ${cy-r*.5} A${r*.8} ${r*.8} 0 0 1 ${cx-r*.05} ${cy-r*.84}" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" opacity=".85"/>`;
    if(SP.ant)s+=`<path d="M${cx+r*.45} ${cy-r*.82} l10 -16" stroke="${k}" stroke-width="3.5" stroke-linecap="round"/><circle class="twk" cx="${cx+r*.45+10}" cy="${cy-r*.82-17}" r="6" fill="#e8423a" stroke="${k}" stroke-width="2.5"/>`;
    s+=star4(24,40,7,'#fff','twk')+star4(178,60,6,'#ffe066','twk',.5)+star4(170,150,5,'#fff','twk',.8);}
  if(w==='top'){
    if(t==='star')s+=`<path d="M${cx-30} ${cy-hh+12} L${cx+6} ${cy-hh-50} L${cx+30} ${cy-hh+12} Z" fill="#7a5cd6" ${S}/><ellipse cx="${cx}" cy="${cy-hh+12}" rx="38" ry="9" fill="#7a5cd6" ${S}/>`+star5(cx+2,cy-hh-14,10,'#ffe066',k)+star4(cx+14,cy-hh-34,5,'#fff','twk');
    if(t==='space'){const r=Math.max(hw,hh)+17;
      s+=`<circle cx="${cx}" cy="${cy+2}" r="${r}" fill="#d6f1ff" fill-opacity=".22" stroke="${k}" stroke-width="4"/><path d="M${cx-r*.62} ${cy-r*.5} A${r*.8} ${r*.8} 0 0 1 ${cx-r*.05} ${cy-r*.84}" fill="none" stroke="#fff" stroke-width="6" stroke-linecap="round" opacity=".85"/>`;
      s+=`<g${A('bh')}><circle cx="30" cy="44" r="15" fill="#241a3d" stroke="#b58cff" stroke-width="5"/><ellipse cx="30" cy="44" rx="25" ry="9" fill="none" stroke="#ff9ecb" stroke-width="3" transform="rotate(-25 30 44)"/></g>`+star4(172,40,7,'#fff','twk')+star4(176,126,5,'#fff','twk',.6);}
    if(t==='jewel'){[[-22,8,'#5ce0e6'],[0,13,'#ff7fb8'],[22,8,'#b58cff']].forEach(q=>{s+=gem(cx+q[0],cy-hh-q[1]+8,q[1]*.95,q[2],k);});s+=star4(cx-56,cy-30,6,'#fff','twk')+star4(cx+56,cy-12,5,'#fff','twk',.4);}
    if(t==='golden')s+=`<path d="M${cx-4} ${cy-hh*1.08} q-6 -26 14 -34 q-4 16 10 22 q-14 2 -24 12 Z" fill="#e8423a" ${S3}/>`;
    if(t==='thunder')s+=bolt(cx+62,cy-44,'#ffd23f')+bolt(cx-64,cy-20,'#ffd23f')+bolt(170,150,'#5cb8ff');
    if(t==='all')s+=star4(cx-58,cy-40,8,'#fff','twk')+star4(cx+60,cy-30,7,'#ffe066','twk',.5)+star4(172,140,6,'#fff','twk',.3);
  }
  return s;
}
/* 3D overlays, added to a finished model */
function form3D(L,b,h,c){
  if(L.cos){cos3D(L,b,h,c);return;}
  const N=L.ninja,t=L.legend,X=L.xmas,SP=L.space,LV=L.lava,AT=L.atom,SN=L.snack&&L.snack.k,bw=c.bw,lg=c.lg,hs=c.hs;if(!N&&!t&&!X&&!SP&&!LV&&!AT&&!SN)return;
  if(SN){
    if(SN==='hotdog'){[-1,1].forEach(s=>mk('sph','#e8b46a',.26,.32,1.02*lg,s*(.5*bw+.16),.64,0,b));for(let q=-3;q<=3;q++)mk('box','#ffc928',.06,.05,.24,q%2?.07:-.07,1.14,q*.17*lg,b).rotation.y=q%2?.7:-.7;}
    if(SN==='donut'){const d=mk('tor','#e8b46a',.62*bw+.24,.9*lg+.24,.7,0,.66,0,b);d.rotation.x=Math.PI/2;const ic=mk('tor','#ff9ecb',.6*bw+.22,.88*lg+.22,.45,0,.76,0,b);ic.rotation.x=Math.PI/2;
      ['#ff4f6d','#ffd23f','#5cb8ff','#3fae5a','#ffffff'].forEach((c2,q)=>{const a=q*1.26+.3;mk('box',c2,.1,.04,.04,Math.cos(a)*(.62*bw+.2),.86,Math.sin(a)*(.9*lg+.2),b,true).rotation.y=a;});}
    if(SN==='pizza'){mk('box','#ffd27a',.95*bw,.06,1.15*lg,0,1.14,-.05*lg,b).rotation.x=-.06;mk('cyl','#c98a4f',.09,.95*bw,.09,0,1.18,.52*lg,b).rotation.z=Math.PI/2;[[-.22,-.1],[.2,.15],[0,-.45],[.24,-.35],[-.18,.3]].forEach(q=>mk('cyl','#e8423a',.11,.03,.11,q[0]*bw,1.19,q[1]*lg,b));}
    if(SN==='icecream'){mk('sph','#ff9ecb',.4,.34,.4,0,.62,-.02,h);[[-.3,.42,.2],[.28,.4,.22],[0,.4,.36]].forEach(q=>mk('sph','#ff9ecb',.1,.14,.1,q[0],q[1],q[2],h));mk('sph','#e8423a',.1,.1,.1,0,.98,0,h);mk('box','#e8b46a',.06,.32,.12,.18,.9,-.1,h).rotation.z=-.4;}
    if(SN==='cupcake'){mk('cyl','#ff9ecb',.3,.2,.3,0,.56,-.02,h);mk('sph','#fff6f0',.34,.14,.34,0,.7,-.02,h);mk('sph','#fff6f0',.24,.12,.24,0,.82,-.02,h);mk('sph','#fff6f0',.14,.1,.14,0,.92,-.02,h);mk('sph','#e8423a',.08,.08,.08,0,1.02,-.02,h);}
    return;}
  if(AT){if(!G.plane)G.plane=new THREE.PlaneGeometry(1,1);
    mk('box',AT.tile,.38,.38,.05,0,.82,.6*lg,b);const tp=new THREE.Mesh(G.plane,tileMat(AT));tp.scale.set(.36,.36,1);tp.position.set(0,.82,.6*lg+.03);b.add(tp);
    if(AT.st==='metal'){const hm=mk('hemi',AT.col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;mk('cyl',shade(AT.col,-.15),.7,.05,.7,0,.12,0,h).rotation.x=-.32;mk('sph','#ffffff',.12,.07,.05,-.24,.5,.3,h,true);
      if(AT.melt)[-.32,.04,.34].forEach((x,i)=>mk('sph',AT.col,.07,.14+i%2*.04,.07,x,.0,.48,h));}
    if(AT.st==='crystal')[[-.26,1.08,.1],[.26,1.04,-.2],[0,1.14,-.4],[-.22,1.0,-.55],[.3,.98,.28]].forEach((q,i)=>mk('pyr',i%2?shade(AT.col,.3):AT.col,.12,.36,.12,q[0]*bw,q[1],q[2]*lg,b,AT.sym==='C'));
    if(AT.st==='liquid'){const hm=mk('hemi',AT.col,.62,.5,.62,0,.12,0,h);hm.rotation.x=-.2;[[-.42,-.12,.22],[.44,-.06,.18],[.05,-.04,.56]].forEach(q=>mk('sph',AT.col,.08,.16,.08,q[0],q[1],q[2],h));}
    if(AT.st==='gas'){if(!mats.bub)mats.bub=new THREE.MeshLambertMaterial({color:'#e8f6ff',transparent:true,opacity:.22,depthWrite:false});const bb=new THREE.Mesh(G.sph,mats.bub);bb.scale.set(1.3*bw+.25,1.25,1.4*lg+.3);bb.position.set(0,.9,0);b.add(bb);b.position.y=.55;}
    if(AT.glow){const gg=new THREE.Mesh(G.sph,new THREE.MeshBasicMaterial({color:AT.glow,transparent:true,opacity:.2,depthWrite:false}));gg.scale.set(1.55*bw+.45,1.45,1.65*lg+.45);gg.position.set(0,.9,0);b.add(gg);}
    return;}
  if(LV){const hm=mk('hemi',LV.hat,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;mk('cyl',shade(LV.hat,-.12),.72,.05,.72,0,.12,0,h).rotation.x=-.32;mk('box',shade(LV.hat,-.2),.08,.12,.9,0,.5,0,h).rotation.x=-.32;
    mk('cyl','#c9d2e3',.14,.1,.14,0,.44,.5,h).rotation.x=Math.PI/2-.3;mk('sph','#fff27a',.11,.11,.06,0,.45,.56,h,true);
    if(!mats.beam)mats.beam=new THREE.MeshBasicMaterial({color:'#fff6a8',transparent:true,opacity:.18,depthWrite:false});const bm=new THREE.Mesh(G.cone,mats.beam);bm.scale.set(.5,1.6,.5);bm.position.set(0,.36,1.35);bm.rotation.x=-Math.PI/2-.12;h.add(bm);
    mk('band',LV.stripe,.505*bw,.645*lg,1.8,0,.84,0,b).rotation.x=Math.PI/2;mk('band',LV.stripe,.47*bw,.6*lg,1.8,0,.5,0,b).rotation.x=Math.PI/2;
    if(LV.crystal)[[-.26,1.08,.1],[.26,1.04,-.2],[0,1.14,-.4],[-.22,1.0,-.55],[.3,.98,.28]].forEach((q,i)=>mk('pyr',['#5ce0e6','#ff7fb8','#b58cff'][i%3],.12,.34,.12,q[0]*bw,q[1],q[2]*lg,b,true));
    return;}
  if(SP){if(!mats.glass)mats.glass=new THREE.MeshLambertMaterial({color:'#d6f1ff',transparent:true,opacity:.3,depthWrite:false});
    const gl=new THREE.Mesh(G.sph,mats.glass);gl.scale.setScalar(.84);gl.position.set(0,.02,.04);h.add(gl);
    mk('tor',SP.trim,.34*hs,.34*hs,.3*hs,0,.98,.4*lg,b).rotation.x=Math.PI/2-.5;mk('band',SP.trim,.505*bw,.645*lg,1.8,0,.6,0,b).rotation.x=Math.PI/2;
    mk('box','#c9d2e3',.26,.18,.06,0,.78,.62*lg,b);
    [-1,1].forEach(s=>{mk('cyl','#c9d2e3',.12,.46,.12,s*.17,1.08,-.34*lg,b);mk('cyl',SP.trim,.125,.08,.125,s*.17,1.18,-.34*lg,b);const fl=mk('cone','#ff8a3c',.09,.3,.09,s*.17,.7,-.34*lg,b,true);fl.rotation.x=Math.PI;});
    if(SP.ant){mk('cyl','#5b4636',.015,.3,.015,.28,.82,0,h).rotation.z=-.4;mk('sph','#e8423a',.06,.06,.06,.34,.96,0,h,true);}
    return;}
  if(X){if(X.pat)mk('band',X.pat,.505*bw,.645*lg,1.8,0,.72,0,b).rotation.x=Math.PI/2;
    if(X.bell){mk('tor','#d9363e',.3*hs,.3*hs,.3*hs,0,.98,.4*lg,b).rotation.x=Math.PI/2-.5;mk('sph','#ffd23f',.11,.11,.11,0,.82,.4*lg+.3*hs,b);}
    const hh=X.hat;
    if(hh==='santa'){const cn=mk('cone','#d9363e',.36,.66,.36,.06,.74,-.02,h);cn.rotation.z=-.42;mk('tor','#ffffff',.44,.44,.5,0,.42,-.02,h).rotation.x=Math.PI/2;mk('sph','#ffffff',.13,.13,.13,.26,1.0,-.02,h);}
    if(hh==='elf'){const cn=mk('cone','#3fae5a',.32,.84,.32,.04,.84,0,h);cn.rotation.z=-.22;mk('tor','#d9363e',.42,.42,.4,0,.42,0,h).rotation.x=Math.PI/2;mk('sph','#ffd23f',.09,.09,.09,.13,1.24,0,h);}
    if(hh==='antlers'){mk('sph','#2f9a54',.12,.05,.07,.16,.5,.18,h).rotation.z=.5;mk('sph','#2f9a54',.12,.05,.07,.3,.5,.16,h).rotation.z=-.5;mk('sph','#e8423a',.05,.05,.05,.23,.47,.24,h);}
    if(hh==='bobble'){mk('hemi',X.jump,.6,.48,.58,0,.2,-.03,h).rotation.x=-.2;mk('tor',shade(X.jump,-.18),.42,.42,.5,0,.24,0,h).rotation.x=Math.PI/2;mk('band',X.pat,.55,.55,1.6,0,.42,-.06,h).rotation.x=Math.PI/2-.2;mk('sph','#ffffff',.16,.16,.16,0,.72,-.1,h);}
    return;}
  if(N){const hood=mk('hemi',N.suit,.63,.57,.6,0,.02,-.03,h);hood.rotation.x=-.75;
    mk('band',N.band,.63,.61,1.4,0,.26,-.05,h).rotation.x=Math.PI/2-.55;
    [-1,1].forEach(s=>{const tl=mk('box',N.band,.07,.34,.1,s*.12,.12,-.66,h);tl.rotation.z=s*.55;tl.rotation.x=.4;});
    mk('band',N.band,.505*bw,.645*lg,1.8,0,.64,0,b).rotation.x=Math.PI/2;mk('box','#ffd23f',.16,.16,.06,0,.62,.66*lg,b);}
  if(t==='super'){const cp=mk('box',L.cape,1.12*bw,.04,1.05*lg,0,1.02,-.2*lg,b);cp.rotation.x=-.34;
    mk('sph','#ffd23f',.16,.16,.05,0,.74,.63*lg,b,true);mk('sph',L.cape,.6,.13,.535,0,.08,0,h);}
  if(t==='star'){const hat=mk('cone','#7a5cd6',.32,.72,.32,.04,.72,0,h);hat.rotation.z=-.2;mk('cyl','#7a5cd6',.44,.04,.44,0,.38,0,h);mk('sph','#ffe066',.08,.08,.03,.06,.66,.25,h,true);}
  if(t==='rainbow')RBOW.forEach((col,i)=>{const r=.68-i*.06;mk('arc',col,r,r,r*3,0,.32,-.12,h,true);});
  if(t==='space'){if(!mats.glass)mats.glass=new THREE.MeshLambertMaterial({color:'#d6f1ff',transparent:true,opacity:.3,depthWrite:false});
    const gl=new THREE.Mesh(G.sph,mats.glass);gl.scale.setScalar(.84);gl.position.set(0,.02,.04);h.add(gl);
    mk('sph','#7f6bff',.14,.14,.05,0,.76,.62*lg,b,true);
    const bh=new THREE.Group();bh.position.set(.95,1.75,-.3);b.add(bh);mk('sph','#241a3d',.22,.22,.22,0,0,0,bh,true);mk('tor','#ff9ecb',.36,.36,.25,0,0,0,bh,true).rotation.x=1.2;c.extra.push(bh);}
  if(t==='jewel'){[['#5ce0e6',-.18],['#ff7fb8',0],['#b58cff',.18]].forEach((q,i)=>mk('pyr',q[0],.09,i===1?.3:.22,.09,q[1],.58,.06,h,true));
    [[-.26,1.08,.1],[.26,1.04,-.2],[0,1.14,-.4],[-.22,1.0,-.55],[.3,.98,.28]].forEach((q,i)=>mk('pyr',['#5ce0e6','#ff7fb8','#b58cff'][i%3],.12,.34,.12,q[0]*bw,q[1],q[2]*lg,b,true));
    [-.14,0,.14].forEach((x,i)=>mk('sph',['#ff7fb8','#5ce0e6','#b58cff'][i],.07,.07,.05,x,.86,.4*lg+.27*hs,b,true));}
  if(t==='golden'){const hm=mk('hemi','#f2c230',.62,.56,.58,0,.07,-.02,h);hm.rotation.x=-.5;mk('sph','#e8423a',.08,.24,.26,0,.68,-.12,h);
    [-1,1].forEach(s=>mk('sph','#e0a82e',.22,.14,.26,s*.42*bw,1.0,.3*lg,b));mk('sph','#fff3a8',.15,.15,.05,0,.74,.63*lg,b,true);}
  if(t==='thunder')[-1,1].forEach(s=>{[[.86,.1,.5],[.7,-.08,-.5],[.54,.1,.5]].forEach(q=>{const z=mk('box','#ffd23f',.05,.22,.07,s*.5*bw,q[0],q[1]*lg,b,true);z.rotation.x=q[2];});});
}

const TILEM={};function tileMat(AT){const key=AT.sym+'|'+AT.num;if(TILEM[key])return TILEM[key];const c=document.createElement('canvas');c.width=c.height=64;const x=c.getContext('2d');
  x.fillStyle='#3a2e26';x.textAlign='center';x.font='900 '+(AT.sym.length>1?28:32)+'px Arial, Helvetica, sans-serif';x.fillText(AT.sym,32,48);
  if(AT.num){x.font='800 14px Arial, Helvetica, sans-serif';x.textAlign='left';x.fillText(AT.num,5,16);}
  const m=new THREE.MeshBasicMaterial({map:new THREE.CanvasTexture(c),transparent:true,depthWrite:false});TILEM[key]=m;return m;}
const ELEC=['#7fe0ff','#5cb8ff','#8c7bff','#c78cff','#5ce0e6','#9be8ff'];
const SNACKP=['#e8423a','#ff8a3c','#ffd23f','#9be07a','#7cc85a','#ffd23f'];

/* ============ Fancy dress costumes (Level 9 and the Dressing-Up Box) ============ */
const COS={
 pirate:{n:'Pirate',body:'#ffffff',belly:'#ffffff',paw:'#3a2a20',line:'NAME says ahoy there, and is hunting for buried treasure!'},
 fire:{n:'Firefighter',body:'#c99a3c',belly:'#d9b45a',paw:'#3a3640',line:'NAME is a brave firefighter pup, ready to help anyone who needs it.'},
 dino:{n:'Dinosaur',body:'#7cc85a',belly:'#d6f0b0',paw:'#5aa84a',line:'NAME does the loudest dinosaur roar. RAAAR!'},
 hero:{n:'Superhero',body:'#3d6be8',belly:'#3d6be8',paw:'#e8423a',line:'NAME can fly faster than a rocket. Well, almost!'},
 knight:{n:'Knight',body:'#b8c2cc',belly:'#d0d8e0',paw:'#8f97a8',line:'NAME is a brave knight who guards Puppy Park.'},
 wizard:{n:'Wizard',body:'#6b4ac8',belly:'#7d5ad8',paw:'#4a3a8a',line:'NAME is learning magic spells. Abracadabra!'},
 chef:{n:'Chef',body:'#ffffff',belly:'#ffffff',paw:'#3a3640',line:'NAME is a top chef who bakes the yummiest pup biscuits.'},
 bee:{n:'Bee',body:'#ffd23f',belly:'#ffe27a',paw:'#3a3640',line:'NAME buzzes from flower to flower. Bzzz!'},
 ladybird:{n:'Ladybird',body:'#e8423a',belly:'#2a2420',paw:'#2a2420',line:'NAME has lucky spots, just like a real ladybird.'},
 ginger:{n:'Gingerbread',body:'#c8844a',belly:'#c8844a',paw:'#a8642a',line:'Run, run, as fast as you can! NAME is the gingerbread pup!'},
 axolotl:{n:'Axolotl',body:'#ffb3d1',belly:'#ffd6e6',paw:'#ff9ec3',line:'NAME is dressed as an axolotl, just like Lottie from Animal Quest!'},
 snowman:{n:'Snowman',body:'#ffffff',belly:'#ffffff',paw:'#ffffff',line:'NAME is a snowman pup who never ever melts.'},
 robot:{n:'Robot',body:'#b8c2cc',belly:'#d6dde4',paw:'#6b7480',line:'NAME goes beep boop, and does the best robot dance.'}};
const COSK=Object.keys(COS),COS_FREE=['pirate','wizard','robot'],COS_PRICE=400;
function applyCos(L,k){const C=COS[k];if(!C)return L;L.cos=k;L.body=C.body;L.belly=C.belly;L.paw=C.paw;L.bodyPatch=null;L.noBodySpots=true;L.wool=false;L.collar=null;
  L.acc=(L.acc||[]).filter(a=>KEEP2.indexOf(a)>=0&&['bubbles','drops','embers','fireflies','glow'].indexOf(a)<0);return L;}
function cos2D(w,c){
  const L=c.L,K=L.cos,cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,S3=c.S3,k=c.k,ed=hw*(L.eyeD||.42),ey=cy-2,er=L.eyeR||8,yb=cy-hh*.42;let s='';
  const dome=(col,lo)=>`<path d="M${cx-hw*.94} ${lo} Q${cx-hw*.94} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.94} ${cy-hh*1.2} ${cx+hw*.94} ${lo} Z" fill="${col}" ${S}/>`;
  const ant=col=>[-1,1].map(g=>`<path d="M${cx+g*hw*.3} ${cy-hh*.95} Q${cx+g*hw*.42} ${cy-hh*1.5} ${cx+g*hw*.62} ${cy-hh*1.6}" stroke="${k}" stroke-width="4" fill="none" stroke-linecap="round"/><circle cx="${cx+g*hw*.62}" cy="${cy-hh*1.6}" r="8" fill="${col}" ${S3}/>`).join('');
  if(w==='behind'){
    if(K==='hero')s+=`<path d="M${100-bw*.7} ${by-bh-6} L${100+bw*.7} ${by-bh-6} L${100+bw+30} ${by+bh+24} Q100 ${by+bh+40} ${100-bw-30} ${by+bh+24} Z" fill="#e8423a" ${S}/>`;
    if(K==='bee')for(const g of[-1,1])s+=`<ellipse cx="${100+g*(bw+18)}" cy="${by-bh+4}" rx="28" ry="17" transform="rotate(${g*-30} ${100+g*(bw+18)} ${by-bh+4})" fill="#eaf6ff" fill-opacity=".85" ${S3}/>`;
    if(K==='ladybird')for(const g of[-1,1]){const x=100+g*(bw*.55+8);s+=`<ellipse cx="${x}" cy="${by-2}" rx="${bw*.62+10}" ry="${bh+12}" fill="#e8423a" ${S}/>`+[[.35,-.45],[.15,.15],[.45,.55]].map(q=>`<circle cx="${x+g*q[0]*bw}" cy="${by+q[1]*bh}" r="7.5" fill="#2a2420"/>`).join('');}
    if(K==='axolotl')for(const g of[-1,1])for(let q=0;q<3;q++){const x=cx+g*(hw+12),y=cy-hh*.55+q*hh*.42,a=g*(-28+q*28);s+=`<ellipse cx="${x}" cy="${y}" rx="20" ry="8" transform="rotate(${a} ${x} ${y})" fill="#ff7fb8" ${S3}/><path d="M${x-g*12} ${y} L${x+g*12} ${y}" transform="rotate(${a} ${x} ${y})" stroke="#e85a9a" stroke-width="3" stroke-linecap="round"/>`;}
    if(K==='dino')for(let q=0;q<4;q++){const y=by-bh*.7+q*bh*.45;for(const g of[-1,1])s+=`<path d="M${100+g*(bw-4)} ${y-9} L${100+g*(bw+16)} ${y} L${100+g*(bw-4)} ${y+9}Z" fill="#ffb000" ${S3}/>`;}
  }
  if(w==='bodyClip'){
    if(K==='pirate')for(let q=-4;q<=4;q++)s+=`<rect x="${100-bw}" y="${by+q*14-4}" width="${bw*2}" height="7" fill="#e8423a"/>`;
    if(K==='fire')s+=`<rect x="${100-bw}" y="${by-bh*.15}" width="${bw*2}" height="9" fill="#ffd23f"/><rect x="${100-bw}" y="${by+bh*.45}" width="${bw*2}" height="9" fill="#ffd23f"/><rect x="${100-bw}" y="${by-bh*.15+3}" width="${bw*2}" height="3" fill="#e6eef6"/><rect x="${100-bw}" y="${by+bh*.45+3}" width="${bw*2}" height="3" fill="#e6eef6"/>`;
    if(K==='bee')for(const q of[-.5,.05,.6])s+=`<rect x="${100-bw}" y="${by+q*bh-7}" width="${bw*2}" height="14" fill="#2a2420"/>`;
    if(K==='ladybird')s+=`<path d="M100 ${by-bh} V${by+bh}" stroke="#2a2420" stroke-width="5"/>`+[[-.5,-.3],[.5,-.2],[-.42,.42],[.45,.45]].map(q=>`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="8" fill="#2a2420"/>`).join('');
    if(K==='ginger')s+=[-.6,.62].map(q=>`<path d="M${100-bw} ${by+q*bh} q${bw/4} -8 ${bw/2} 0 t${bw/2} 0 t${bw/2} 0 t${bw/2} 0" fill="none" stroke="#ffffff" stroke-width="5" stroke-linecap="round"/>`).join('');
    if(K==='knight')for(let q=-4;q<=4;q++)for(let r=-3;r<=3;r++)s+=`<circle cx="${100+q*12+(r%2?6:0)}" cy="${by+r*10}" r="3" fill="#8f97a8"/>`;
    if(K==='robot')s+=[[-.65,-.55],[.65,-.55],[-.65,.55],[.65,.55]].map(q=>`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="3.5" fill="#6b7480"/>`).join('');
    if(K==='dino'||K==='axolotl')s+=`<ellipse cx="100" cy="${by+bh*.2}" rx="${bw*.55}" ry="${bh*.72}" fill="${K==='dino'?'#d6f0b0':'#ffe0ec'}"/>`;
    if(K==='wizard')s+=[[-.5,-.2],[.42,.3],[-.2,.55],[.55,-.4]].map(q=>star4(100+q[0]*bw,by+q[1]*bh,6,'#ffd23f')).join('');
    if(K==='chef')s+=[-.25,.25].map(q=>`<circle cx="${100+q*bw}" cy="${by-bh*.25}" r="4" fill="#c9d2e3"/><circle cx="${100+q*bw}" cy="${by+bh*.15}" r="4" fill="#c9d2e3"/>`).join('');
  }
  if(w==='headOver'&&K==='hero')s+=`<path d="M${cx-ed-er-13} ${ey-er-3} Q${cx} ${ey-er-13} ${cx+ed+er+13} ${ey-er-3} L${cx+ed+er+9} ${ey+er+6} Q${cx} ${ey+er-4} ${cx-ed-er-9} ${ey+er+6} Z" fill="#2b4a8a" ${S3}/>`;
  if(w==='chest'){
    if(K==='hero')s+=`<circle cx="${bcx}" cy="${by+2}" r="15" fill="#ffd23f" ${S3}/>`+star5(bcx,by+3,10,'#e8423a',k);
    if(K==='knight')s+=`<path d="M${bcx-16} ${by-14} H${bcx+16} V${by+2} Q${bcx+16} ${by+18} ${bcx} ${by+24} Q${bcx-16} ${by+18} ${bcx-16} ${by+2} Z" fill="#3d6be8" ${S3}/><path d="M${bcx} ${by-12} V${by+20} M${bcx-14} ${by} H${bcx+14}" stroke="#ffd23f" stroke-width="5"/>`;
    if(K==='chef')s+=`<path d="M${cx-28} ${cy+hh-12} L${cx+28} ${cy+hh-12} L${cx} ${cy+hh+20} Z" fill="#e8423a" ${S3}/>`;
    if(K==='ginger')['#e8423a','#3fae5a','#5cb8ff'].forEach((col,q)=>{s+=`<circle cx="${bcx}" cy="${by-bh*.35+q*bh*.38}" r="7" fill="${col}" ${S3}/>`;});
    if(K==='snowman'){s+=[0,1,2].map(q=>`<circle cx="${bcx}" cy="${by-bh*.25+q*bh*.38}" r="6" fill="#2a2420"/>`).join('');const yN=cy+hh-8;
      s+=`<path d="M${cx-hw*.7} ${yN} Q${cx} ${yN+18} ${cx+hw*.7} ${yN}" fill="none" stroke="${k}" stroke-width="17" stroke-linecap="round"/><path d="M${cx-hw*.7} ${yN} Q${cx} ${yN+18} ${cx+hw*.7} ${yN}" fill="none" stroke="#e8423a" stroke-width="11" stroke-linecap="round"/><rect x="${cx+hw*.32}" y="${yN+4}" width="14" height="32" rx="5" fill="#e8423a" ${S3} transform="rotate(-12 ${cx+hw*.38} ${yN})"/>`;}
    if(K==='robot')s+=`<rect x="${bcx-19}" y="${by-15}" width="38" height="30" rx="5" fill="#8f97a8" ${S3}/><circle cx="${bcx-9}" cy="${by-6}" r="4" fill="#e8423a"/><circle cx="${bcx+2}" cy="${by-6}" r="4" fill="#3fae5a"/><circle cx="${bcx+12}" cy="${by-6}" r="3" fill="#ffd23f"/><rect x="${bcx-12}" y="${by+4}" width="24" height="5" rx="2" fill="#5cb8ff"/>`;
    if(K==='fire')s+=`<rect x="${bcx-8}" y="${by-14}" width="16" height="13" rx="3" fill="#3a3640" ${S3}/><path d="M${bcx+4} ${by-14} v-9" stroke="${k}" stroke-width="3"/>`;
  }
  if(w==='top'){
    if(K==='pirate')s+=`<path d="M${cx-hw*1.08} ${yb+4} Q${cx-hw*.95} ${cy-hh*1.05} ${cx-hw*.5} ${cy-hh*1.28} Q${cx} ${cy-hh*1.02} ${cx+hw*.5} ${cy-hh*1.28} Q${cx+hw*.95} ${cy-hh*1.05} ${cx+hw*1.08} ${yb+4} Q${cx} ${yb-10} ${cx-hw*1.08} ${yb+4}Z" fill="#2a2420" ${S}/><circle cx="${cx}" cy="${cy-hh*.9}" r="9" fill="#ffffff"/><rect x="${cx-5}" y="${cy-hh*.9+5}" width="10" height="6" rx="2" fill="#fff"/><circle cx="${cx-3}" cy="${cy-hh*.92}" r="2" fill="#2a2420"/><circle cx="${cx+3}" cy="${cy-hh*.92}" r="2" fill="#2a2420"/>`
      +`<path d="M${cx-hw*.92} ${ey-er-16} L${cx+hw*.92} ${ey+er+4}" stroke="#2a2420" stroke-width="4"/><ellipse cx="${cx+ed}" cy="${ey}" rx="${er+5}" ry="${er+4}" fill="#2a2420" ${S3}/>`;
    if(K==='fire')s+=dome('#e8423a',yb)+`<path d="M${cx-hw*1.1} ${yb+3} Q${cx} ${yb+16} ${cx+hw*1.1} ${yb+3} L${cx+hw*1.0} ${yb-8} Q${cx} ${yb+4} ${cx-hw*1.0} ${yb-8}Z" fill="#c8302a" ${S3}/><path d="M${cx-12} ${cy-hh*1.08} H${cx+12} V${cy-hh*.8} Q${cx} ${cy-hh*.66} ${cx-12} ${cy-hh*.8}Z" fill="#ffd23f" ${S3}/>`;
    if(K==='dino'){s+=dome('#7cc85a',yb);for(const t of[-.62,-.31,0,.31,.62]){const x=cx+t*hw,y=cy-hh*(1.2-.32*t*t);s+=`<path d="M${x-9} ${y+4} L${x} ${y-16} L${x+9} ${y+4}Z" fill="#ffb000" ${S3}/>`;}}
    if(K==='knight')s+=dome('#c9d2e3',yb)+`<rect x="${cx-hw*.95}" y="${yb-14}" width="${hw*1.9}" height="16" rx="5" fill="#8f97a8" ${S3}/>`+[-.5,-.2,.1,.4].map(q=>`<rect x="${cx+q*hw}" y="${yb-10}" width="${hw*.18}" height="5" rx="2" fill="#3a3640"/>`).join('')+`<path d="M${cx} ${cy-hh*1.2} Q${cx-18} ${cy-hh*1.75} ${cx+20} ${cy-hh*1.85} Q${cx+8} ${cy-hh*1.5} ${cx+6} ${cy-hh*1.2}Z" fill="#e8423a" ${S3}/>`;
    if(K==='wizard')s+=`<path d="M${cx-hw*.78} ${yb} L${cx+hw*.12} ${cy-hh*2.15} L${cx+hw*.78} ${yb}Z" fill="#6b4ac8" ${S}/><ellipse cx="${cx}" cy="${yb}" rx="${hw*1.08}" ry="11" fill="#5a3ab0" ${S3}/>`+star4(cx-hw*.2,cy-hh*1.05,9,'#ffd23f','twk')+star4(cx+hw*.18,cy-hh*1.55,7,'#ffffff','twk',.4)+`<path d="M${cx+hw*.3} ${cy-hh*.9} a9 9 0 1 0 6 10 a7 7 0 1 1 -6 -10z" fill="#ffd23f"/>`;
    if(K==='chef')s+=`<rect x="${cx-hw*.55}" y="${yb-24}" width="${hw*1.1}" height="26" rx="5" fill="#fff" ${S3}/><circle cx="${cx-hw*.36}" cy="${yb-36}" r="${hw*.32}" fill="#fff" ${S3}/><circle cx="${cx+hw*.36}" cy="${yb-36}" r="${hw*.32}" fill="#fff" ${S3}/><circle cx="${cx}" cy="${yb-48}" r="${hw*.38}" fill="#fff" ${S3}/><rect x="${cx-hw*.5}" y="${yb-28}" width="${hw}" height="8" fill="#fff"/>`;
    if(K==='bee'||K==='ladybird')s+=ant('#2a2420');
    if(K==='ginger')s+=dome('#c8844a',yb)+`<path d="M${cx-hw*.9} ${yb-4} q${hw*.15} -10 ${hw*.3} 0 t${hw*.3} 0 t${hw*.3} 0 t${hw*.3} 0 t${hw*.3} 0 t${hw*.3} 0" fill="none" stroke="#ffffff" stroke-width="5" stroke-linecap="round"/>`;
    if(K==='axolotl')s+=dome('#ffb3d1',yb)+`<circle cx="${cx-hw*.35}" cy="${cy-hh*.9}" r="5" fill="#2a2420"/><circle cx="${cx+hw*.35}" cy="${cy-hh*.9}" r="5" fill="#2a2420"/><path d="M${cx-8} ${cy-hh*.78} q8 6 16 0" stroke="#2a2420" stroke-width="3" fill="none" stroke-linecap="round"/>`;
    if(K==='snowman')s+=`<rect x="${cx-hw*.45}" y="${cy-hh*1.62}" width="${hw*.9}" height="${hh*.78}" rx="4" fill="#2a2420" ${S}/><rect x="${cx-hw*.78}" y="${cy-hh*.9}" width="${hw*1.56}" height="11" rx="5" fill="#2a2420" ${S3}/><rect x="${cx-hw*.45+2}" y="${cy-hh*1.08}" width="${hw*.9-4}" height="9" fill="#e8423a"/>`;
    if(K==='robot')s+=`<rect x="${cx-hw*.88}" y="${cy-hh*1.18}" width="${hw*1.76}" height="${hh*.74}" rx="10" fill="#c9d2e3" ${S}/>`+[-.6,-.2,.2,.6].map(q=>`<circle cx="${cx+q*hw}" cy="${cy-hh*.55}" r="3" fill="#6b7480"/>`).join('')+`<path d="M${cx} ${cy-hh*1.18} V${cy-hh*1.58}" stroke="${k}" stroke-width="4"/><circle cx="${cx}" cy="${cy-hh*1.64}" r="9" fill="#e8423a" ${S3}/>`+[-1,1].map(g=>`<circle cx="${cx+g*hw*.98}" cy="${cy}" r="10" fill="#8f97a8" ${S3}/>`).join('');
  }
  return s;}
function cos3D(L,b,h,c){const K=L.cos,bw=c.bw,lg=c.lg;
  const helm=col=>{const hm=mk('hemi',col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;return hm;};
  const band=(col,y,th)=>{mk('band',col,.51*bw,.65*lg,th||1.8,0,y,0,b).rotation.x=Math.PI/2;};
  const ant=col=>[-1,1].forEach(s=>{mk('cyl','#2a2420',.02,.42,.02,s*.18,.62,.05,h).rotation.z=-s*.35;mk('sph',col,.07,.07,.07,s*.27,.82,.05,h);});
  switch(K){
   case'pirate':mk('sph','#2a2420',.66,.16,.52,0,.5,-.02,h);mk('sph','#2a2420',.42,.3,.38,0,.6,-.04,h);mk('sph','#ffffff',.08,.08,.03,0,.64,.34,h,true);mk('cyl','#2a2420',.13,.04,.13,.21,.06,.5,h).rotation.x=Math.PI/2;band('#e8423a',.86,1.2);band('#e8423a',.56,1.2);break;
   case'fire':helm('#e8423a');mk('cyl','#c8302a',.76,.05,.76,0,.12,0,h).rotation.x=-.32;mk('box','#ffd23f',.18,.18,.04,0,.48,.46,h).rotation.x=-.6;band('#ffd23f',.86,1.1);band('#ffd23f',.54,1.1);break;
   case'dino':helm('#7cc85a');[[.0,.66,.25],[0,.72,0],[0,.66,-.28]].forEach(q=>mk('cone','#ffb000',.09,.24,.09,q[0],q[1],q[2],h));for(let q=0;q<4;q++)mk('cone','#ffb000',.09,.26,.09,0,1.16,(.3-q*.3)*lg,b);break;
   case'hero':{const cp=mk('box','#e8423a',.95*bw,.05,1.15*lg,0,1.08,-.18*lg,b);cp.rotation.x=-.28;mk('box','#2b4a8a',.62,.12,.06,0,.1,.5,h);mk('cyl','#ffd23f',.15,.03,.15,0,.82,.6*lg,b).rotation.x=Math.PI/2;break;}
   case'knight':helm('#c9d2e3');mk('box','#8f97a8',.66,.12,.12,0,.22,.44,h);mk('sph','#e8423a',.1,.26,.3,0,.8,-.12,h);break;
   case'wizard':mk('cone','#6b4ac8',.42,1.0,.42,0,.92,-.05,h);mk('cyl','#5a3ab0',.72,.04,.72,0,.42,-.03,h);mk('sph','#ffd23f',.07,.07,.07,.14,.82,.2,h,true);mk('sph','#ffffff',.05,.05,.05,-.1,1.08,.12,h,true);break;
   case'chef':mk('cyl','#ffffff',.34,.3,.34,0,.6,0,h);mk('sph','#ffffff',.44,.3,.44,0,.86,0,h);mk('cone','#e8423a',.2,.22,.08,0,.62,.62*lg,b).rotation.x=Math.PI;break;
   case'bee':band('#2a2420',.92,1.1);band('#2a2420',.62,1.1);band('#2a2420',.34,1.1);[-1,1].forEach(s=>{const wg=mk('sph','#eaf6ff',.06,.32,.42,s*(.42*bw+.1),1.2,-.1*lg,b);wg.rotation.z=s*.5;});ant('#2a2420');break;
   case'ladybird':mk('hemi','#e8423a',.62*bw+.06,.5,.82*lg,0,.98,-.05*lg,b);mk('box','#2a2420',.04,.02,1.5*lg,0,1.47,-.05*lg,b);[[-.2,.2],[.22,.1],[-.15,-.35],[.2,-.4]].forEach(q=>mk('sph','#2a2420',.11,.05,.11,q[0]*bw,1.4,q[1]*lg,b));ant('#2a2420');break;
   case'ginger':helm('#c8844a');band('#ffffff',.98,.5);band('#ffffff',.42,.5);['#e8423a','#3fae5a','#5cb8ff'].forEach((col,q)=>mk('sph',col,.07,.07,.05,0,.95-q*.2,.63*lg,b));break;
   case'axolotl':helm('#ffb3d1');[-1,1].forEach(s=>{for(let q=0;q<3;q++){const gl=mk('sph','#ff7fb8',.06,.24,.06,s*.62,.3-q*.2,-.05,h);gl.rotation.z=s*(1.1-q*.55);}});break;
   case'snowman':mk('cyl','#2a2420',.36,.5,.36,0,.78,-.02,h);mk('cyl','#2a2420',.62,.05,.62,0,.5,-.02,h);mk('cyl','#e8423a',.37,.08,.37,0,.58,-.02,h);mk('tor','#e8423a',.3,.3,.32,0,.98,.4*lg,b).rotation.x=Math.PI/2-.5;[0,1,2].forEach(q=>mk('sph','#2a2420',.06,.06,.04,0,.92-q*.2,.63*lg,b));break;
   case'robot':mk('box','#c9d2e3',.86,.46,.86,0,.4,0,h);mk('cyl','#5b4636',.02,.3,.02,0,.78,0,h);mk('sph','#e8423a',.09,.09,.09,0,.96,0,h,true);[-1,1].forEach(s=>mk('cyl','#8f97a8',.14,.08,.14,s*.6,0,0,h).rotation.z=Math.PI/2);
     mk('box','#8f97a8',.34,.26,.05,0,.82,.6*lg,b);['#e8423a','#3fae5a','#ffd23f'].forEach((col,q)=>mk('sph',col,.04,.04,.03,-.08+q*.08,.86,.63*lg,b,true));break;}}

'use strict';
/* ============ animal drawing (2D) ============ */
const DEF={fur:'#e8b877',belly:'#fff4dc',muzzle:'#fff4dc',ear:null,earIn:'#f9b9c6',ears:'floppy',tail:'wag',tailTip:null,hw:58,hh:52,bw:44,bh:40,hx:0,scale:1,
  nose:'#3a2a25',eye:'#3a2a25',iris:null,eyeWhite:false,fluffy:false,acc:[],snout:'dog',limbs:'paws',eyeR:9.5,eyeD:.42,neck:0,earS:1};
const RBOW=['#ff8fb3','#ffc46b','#fff27a','#8fe39a','#7fc8f0','#b58cff'];
function star4(x,y,r,fill,cls,delay){return `<path${cls?` class="${cls}"`:''}${delay?` style="animation-delay:${delay}s"`:''} d="M${x} ${y-r} Q${x} ${y} ${x+r} ${y} Q${x} ${y} ${x} ${y+r} Q${x} ${y} ${x-r} ${y} Q${x} ${y} ${x} ${y-r}Z" fill="${fill}"/>`;}
function star5(x,y,r,fill,stroke){const pts=[];for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.45:r;pts.push((x+Math.cos(a)*rr).toFixed(1)+','+(y+Math.sin(a)*rr).toFixed(1));}
  return `<polygon points="${pts.join(' ')}" fill="${fill}" stroke="${stroke||'none'}" stroke-width="3" stroke-linejoin="round"/>`;}
function svgDefs(id,cx,cy,hw,hh,by,bw,bh){return `<defs><linearGradient id="${id}r" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ff8fb3"/><stop offset=".25" stop-color="#ffc46b"/><stop offset=".45" stop-color="#fff27a"/><stop offset=".65" stop-color="#8fe39a"/><stop offset=".82" stop-color="#7fc8f0"/><stop offset="1" stop-color="#b58cff"/></linearGradient><linearGradient id="${id}f" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffe066"/><stop offset=".35" stop-color="#ffb03a"/><stop offset=".7" stop-color="#ff6b2a"/><stop offset="1" stop-color="#d9363e"/></linearGradient><linearGradient id="${id}s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e8423a"/><stop offset=".35" stop-color="#ff8a3c"/><stop offset=".6" stop-color="#ffd23f"/><stop offset="1" stop-color="#7cc85a"/></linearGradient><linearGradient id="${id}e" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#9be8ff"/><stop offset=".35" stop-color="#5cb8ff"/><stop offset=".7" stop-color="#8c7bff"/><stop offset="1" stop-color="#c78cff"/></linearGradient><radialGradient id="${id}a"><stop offset=".4" stop-color="#ffe066" stop-opacity=".85"/><stop offset="1" stop-color="#ffe066" stop-opacity="0"/></radialGradient><clipPath id="${id}c"><ellipse cx="${cx}" cy="${cy}" rx="${hw}" ry="${hh}"/></clipPath><clipPath id="${id}b"><ellipse cx="100" cy="${by}" rx="${bw}" ry="${bh}"/></clipPath></defs>`;}
function sparkles(an){let s='';[[20,44,9,0],[180,62,8,.3],[26,150,7,.6],[176,158,9,.9],[100,6,8,.45]].forEach(q=>{s+=star4(q[0],q[1],q[2],'#ffc928',an?'twk':'',q[3]);});return s;}
function eyesSVG(L,cx,ey,hw,o,A,k){
  let s='';const ed=hw*L.eyeD,r=L.eyeR;
  if(o.sleep){for(const g of[-1,1])s+=`<path d="M${cx+g*ed-9} ${ey} q9 8 18 0" fill="none" stroke="${k}" stroke-width="4" stroke-linecap="round"/>`;return s;}
  s+=`<g${A('blink')}>`;for(const g of[-1,1]){const x=cx+g*ed;if(L.eyeWhite)s+=`<circle cx="${x}" cy="${ey}" r="${r+3}" fill="#fff"/>`;
    s+=`<circle cx="${x}" cy="${ey}" r="${r}" fill="${L.iris||L.eye}"/>`;if(L.iris)s+=`<circle cx="${x}" cy="${ey}" r="${r*.53}" fill="${L.eye}"/>`;
    s+=`<circle cx="${x-r*.32}" cy="${ey-r*.37}" r="${r*.34}" fill="#fff"/><circle cx="${x+r*.32}" cy="${ey+r*.37}" r="${r*.16}" fill="#fff" opacity=".8"/>`;}
  return s+'</g>';
}
function octoSVG(L,o){
  const id='g'+(++uid),k=INK,an=o.anim!==false,A=c=>an?` class="${c}"`:'',S=`stroke="${k}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"`;
  let s=svgDefs(id,100,86,64,60,150,40,30);if(o.sparkly)s+=`<circle cx="100" cy="112" r="112" fill="url(#${id}a)"${A('glow')}/>`;
  [-2.5,-1.5,-.5,.5,1.5,2.5].forEach((i,n)=>{const x=100+i*19,d=`M${x} 128 q${i*5} 34 ${i*11} 50 q${i>0?9:-9} 13 ${i>0?18:-18} 0`;
    s+=`<g${A('flt')} style="animation-delay:${n*.2}s"><path d="${d}" fill="none" stroke="${k}" stroke-width="21" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${L.fur}" stroke-width="13" stroke-linecap="round"/></g>`;});
  s+=`<ellipse cx="100" cy="86" rx="64" ry="60" fill="${L.fur}" ${S}/><ellipse cx="100" cy="112" rx="40" ry="26" fill="${L.belly}" opacity=".7"/>`;
  [[-36,-34,8],[30,-40,6],[46,-10,5],[-10,-48,5]].forEach(q=>{s+=`<circle cx="${100+q[0]}" cy="${86+q[1]}" r="${q[2]}" fill="#fff" opacity=".45"/>`;});
  for(const g of[-1,1])s+=`<circle cx="${100+g*42}" cy="110" r="9" fill="#ff9aa8" opacity=".6"/>`;
  s+=eyesSVG(Object.assign({},L,{eyeR:11,eyeD:.4}),100,92,64,o,A,k);
  s+=`<path d="M88 114 Q100 126 112 114" fill="none" stroke="${k}" stroke-width="3.5" stroke-linecap="round"/>`;
  s+=`<path d="M118 34 l-13 -9 v18 Z M118 34 l13 -9 v18 Z" fill="#ff7fb8" stroke="${k}" stroke-width="3" stroke-linejoin="round"/><circle cx="118" cy="34" r="5" fill="#ff9ecb" stroke="${k}" stroke-width="2.5"/>`;
  if(o.sparkly)s+=sparkles(an);
  return `<svg class="pup" viewBox="0 0 200 210" xmlns="http://www.w3.org/2000/svg">${s}</svg>`;
}
function critterSVG(p,o){
  o=o||{};const L=Object.assign({},DEF,formLook(p));if(L.kind==='octo')return octoSVG(L,o);
  const id='g'+(++uid),k=INK,an=o.anim!==false,A=c=>an?` class="${c}"`:'';
  const cx=100+L.hx,cy=82-L.neck,hw=L.hw,hh=L.hh,bw=L.bw,bh=L.bh,by=192-bh,bcx=100+L.hx*.75;
  const rb=L.fire?`url(#${id}f)`:L.elec?`url(#${id}e)`:L.snack===true?`url(#${id}s)`:`url(#${id}r)`,earC=L.ear==='rainbow'?rb:(L.ear||L.fur),acc=L.acc,has=a=>acc.indexOf(a)>=0,headC=L.headC||L.fur,bodyC=L.body||L.fur,spotC=L.spotC||'#3a3338',SC=k=>L.spotCs?L.spotCs[k%L.spotCs.length]:spotC,SG=(x,y,r)=>L.spotGlow?`<circle cx="${x}" cy="${y}" r="${r*1.9}" fill="${spotC}" opacity=".35"/>`:'',es=L.earS;
  const S=`stroke="${k}" stroke-width="4" stroke-linejoin="round" stroke-linecap="round"`,S3=`stroke="${k}" stroke-width="3" stroke-linejoin="round" stroke-linecap="round"`;
  const two=(d,c,w)=>`<path d="${d}" fill="none" stroke="${k}" stroke-width="${w+7}" stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round"/>`;
  let s=svgDefs(id,cx,cy,hw,hh,by,bw,bh);
  const C={L,cx,cy,hw,hh,bw,bh,by,bcx,S,S3,k,A,id,two};s+=form2D('aura',C);
  if(o.sparkly)s+=`<circle cx="100" cy="112" r="112" fill="url(#${id}a)"${A('glow')}/>`;
  // things behind the body
  s+=form2D('behind',C);
  if(has('dwings'))for(const g of[-1,1])s+=`<path d="M${100+g*(bw-8)} ${by-8} q${g*46} -58 ${g*66} -14 q${-g*12} 2 ${-g*16} 14 q${-g*12} -6 ${-g*18} 8 q${-g*10} -8 ${-g*22} 6 Z" fill="${L.wingC||'#ffb3d4'}" ${S}/>`;
  if(has('spikes')){const pts=[];for(let i=0;i<=30;i++){const a=Math.PI*.82+i*Math.PI*1.36/30,r=i%2?1.13:1;pts.push((100+Math.cos(a)*74*r).toFixed(1)+','+(128+Math.sin(a)*106*r).toFixed(1));}s+=`<polygon points="${pts.join(' ')}" fill="${L.spikeC}" ${S}/>`;}
  if(has('shell')){s+=`<ellipse cx="100" cy="${by-6}" rx="${bw+18}" ry="${bh+16}" fill="${L.shellC}" ${S}/>`;[200,235,270,305,340].forEach(d=>{const a=d*Math.PI/180;s+=`<circle cx="${(100+Math.cos(a)*(bw+7)).toFixed(1)}" cy="${(by-6+Math.sin(a)*(bh+5)).toFixed(1)}" r="8" fill="${L.shellC2}"/>`;});}
  // tail
  const tx=100+bw-10,ty=by+bh*.25,tc=L.tailFill==='rainbow'?rb:(L.tailC||L.fur);
  if(L.tail!=='none'){
    const T={wag:['q30 -4 32 -40',14,32,-40],curl:['q36 -2 30 -34 q-6 -20 -22 -8',14,8,-42],plume:['q34 -4 34 -44',22,34,-44],thin:['q28 -4 30 -40',7,30,-40],stub:['q12 -3 16 -12',14,16,-12],pom:['q26 -4 28 -36',7,28,-36],
      bunny:['q6 2 10 6',6,10,6],fox:['q40 -6 38 -52',27,38,-52],long:['q46 4 38 -38 q-6 -18 10 -24',7,48,-62],fin:['q30 -12 42 -40',20,42,-40]}[L.tail];
    const ex=tx+T[2],ey=ty+T[3];
    s+=`<g${A('tail')} style="transform-origin:${tx}px ${ty}px"><path d="M${tx} ${ty} ${T[0]}" fill="none" stroke="${k}" stroke-width="${T[1]+8}" stroke-linecap="round"/><path d="M${tx} ${ty} ${T[0]}" fill="none" stroke="${tc}" stroke-width="${T[1]}" stroke-linecap="round"/>`;
    if(L.tailTip)s+=`<circle cx="${ex}" cy="${ey}" r="${Math.max(6,T[1]/2)}" fill="${L.tailTip}"/>`;
    if(L.tail==='pom')s+=`<circle cx="${ex}" cy="${ey}" r="12" fill="${L.fur}" ${S}/>`;
    if(L.tail==='bunny')s+=`<circle cx="${ex+2}" cy="${ey}" r="15" fill="${L.tailTip||L.fur}" ${S}/>`;
    if(L.tailTuft)s+=`<circle cx="${ex}" cy="${ey}" r="10" fill="${L.tailTuft}" ${S}/>`;
    if(has('startail'))s+=star5(ex,ey-4,15,'#ffe066',k)+star4(ex+20,ey+18,6,'#ffe066','twk')+star4(ex+24,ey-16,5,'#ffffff','twk',.5);
    if(has('glow'))s+=`<circle cx="${ex}" cy="${ey}" r="19" fill="#ffb347"${A('glow')} opacity=".5"/><circle cx="${ex}" cy="${ey}" r="9" fill="#ffe066"/>`;
    s+='</g>';
  }
  // body
  if(L.wool){for(let i=0;i<12;i++){const a=i*Math.PI/6+.2;s+=`<circle cx="${(100+Math.cos(a)*bw*.92).toFixed(1)}" cy="${(by+Math.sin(a)*bh*.9).toFixed(1)}" r="15" fill="${bodyC}" ${S}/>`;}s+=`<ellipse cx="100" cy="${by}" rx="${bw}" ry="${bh}" fill="${bodyC}"/>`;}
  else s+=`<ellipse cx="100" cy="${by}" rx="${bw}" ry="${bh}" fill="${bodyC}" ${S}/>`;
  s+=`<ellipse cx="${bcx}" cy="${by+6}" rx="${Math.min(bw*.6,30)}" ry="${bh*.72}" fill="${L.belly}"/>`;
  let bm='';
  if(L.spots&&!L.noBodySpots)[[-24,-8,6],[27,4,7],[14,-22,5],[-31,14,5]].forEach((q,k)=>{bm+=SG(100+q[0],by+q[1],q[2])+`<circle cx="${100+q[0]}" cy="${by+q[1]}" r="${q[2]}" fill="${SC(k+2)}"/>`;});
  if(L.bodyPatch)bm+=`<circle cx="${100-bw*.6}" cy="${by-bh*.35}" r="${bh*.5}" fill="${L.bodyPatch}"/><circle cx="${100+bw*.62}" cy="${by+bh*.3}" r="${bh*.42}" fill="${L.bodyPatch}"/>`;
  if(L.stripes)for(const g of[-1,1])bm+=`<path d="M${100+g*bw} ${by-12} h${-g*15} M${100+g*bw} ${by+5} h${-g*17}" stroke="${L.stripes}" stroke-width="6" stroke-linecap="round" fill="none"/>`;
  bm+=form2D('bodyClip',C);
  if(bm)s+=`<g clip-path="url(#${id}b)">${bm}</g>`+(L.wool?'':`<ellipse cx="100" cy="${by}" rx="${bw}" ry="${bh}" fill="none" ${S}/>`);
  if(has('ring')){const r=`cx="100" cy="${by+8}" rx="${bw+6}" ry="14" fill="none"`;s+=`<ellipse ${r} stroke="${k}" stroke-width="20"/><ellipse ${r} stroke="#ff6b6b" stroke-width="13"/><ellipse ${r} stroke="#fff" stroke-width="13" stroke-dasharray="16 22"/>`;}
  const col=has('scarf')?L.scarfC:(L.collar||(has('daisy')?'#6fcf73':has('shellneck')?'#7fd3f0':has('barrel')?'#8a5326':has('moon')?'#9a86e8':null));
  if(col){const d=`M${cx-36} ${cy+hh-14} Q${cx} ${cy+hh+34} ${cx+36} ${cy+hh-14}`,w=has('scarf')?11:7;s+=`<path d="${d}" fill="none" stroke="${k}" stroke-width="${w+7}" stroke-linecap="round"/><path d="${d}" fill="none" stroke="${col}" stroke-width="${w}" stroke-linecap="round"/>`;
    if(has('scarf'))s+=`<rect x="${cx+12}" y="${cy+hh+2}" width="14" height="26" rx="6" fill="${col}" ${S3}/>`;}
  s+=form2D('chest',C);
  // limbs
  if(L.limbs==='wings'){for(const g of[-1,1]){const x=100+g*(bw-1);s+=`<ellipse cx="${x}" cy="${by+6}" rx="13" ry="23" fill="${L.wingC||bodyC}" ${S} transform="rotate(${-g*16} ${x} ${by-16})"/>`;}
    for(const x of[bcx-14,bcx+14])s+=`<ellipse cx="${x}" cy="190" rx="12" ry="6.5" fill="${L.feetC||'#ff9a3c'}" ${S3}/>`;}
  else if(L.limbs==='flippers'&&L.upright){for(const g of[-1,1]){const x=100+g*(bw-1);s+=`<ellipse cx="${x}" cy="${by+6}" rx="12" ry="24" fill="${L.flipC||bodyC}" ${S} transform="rotate(${-g*20} ${x} ${by-16})"/>`;}
    for(const x of[bcx-14,bcx+14])s+=`<ellipse cx="${x}" cy="190" rx="12" ry="6.5" fill="${L.feetC||'#ff9a3c'}" ${S3}/>`;}
  else if(L.limbs==='flippers'){for(const g of[-1,1]){const x=100+g*(bw+2),y=by+bh*.4;s+=`<ellipse cx="${x}" cy="${y}" rx="22" ry="10" fill="${L.flipC||bodyC}" ${S} transform="rotate(${g*28} ${x} ${y})"/>`;}
    if(L.feetC)for(const x of[bcx-14,bcx+14])s+=`<ellipse cx="${x}" cy="190" rx="12" ry="6.5" fill="${L.feetC}" ${S3}/>`;}
  else{const pawC=L.limbs==='hooves'?L.hoofC:(has('mittens')?'#e85d5d':(L.paw||bodyC)),paws=[bcx-17,bcx+17];if(L.long)paws.push(100+bw-36,100+bw-10);
    paws.forEach(x=>{s+=`<ellipse cx="${x}" cy="188" rx="13" ry="9" fill="${pawC}" ${S}/>`;if(has('mittens'))s+=`<rect x="${x-12}" y="176" width="24" height="7" rx="3.5" fill="#fff" stroke="${k}" stroke-width="2.5"/>`;});}
  if(has('dirt'))s+=`<ellipse cx="${cx+52}" cy="190" rx="22" ry="10" fill="#9a6b43" ${S}/>`;
  // neck
  if(L.neck){s+=`<rect x="${cx-17}" y="${cy+hh-12}" width="34" height="${L.neck+22}" fill="${L.fur}" ${S}/>`;if(L.spots)s+=`<circle cx="${cx-6}" cy="${cy+hh+14}" r="6" fill="${SC(0)}"/><circle cx="${cx+7}" cy="${cy+hh+34}" r="6" fill="${SC(1)}"/>`;}
  // ears behind the head
  const E=L.ears;
  if(E==='pointy'||E==='bat')for(const g of[-1,1]){const big=E==='bat';
    const a=[cx+g*hw*(big?.98:.86),cy-hh*(big?.15:.3)],b=[cx+g*hw*(big?1.02:.7),cy-hh-(big?34:24)],c=[cx+g*hw*.14,cy-hh*.84];
    const m=[(a[0]+b[0]+c[0])/3,(a[1]+b[1]+c[1])/3],q=t=>[(m[0]+(t[0]-m[0])*.5).toFixed(1),(m[1]+(t[1]-m[1])*.5).toFixed(1)];
    s+=`<path d="M${a} L${b} L${c} Z" fill="${earC}" ${S}/><path d="M${q(a)} L${q(b)} L${q(c)} Z" fill="${L.earIn}"/>`;}
  if(E==='round')for(const g of[-1,1]){const x=cx+g*hw*.7,y=cy-hh*.76;s+=`<circle cx="${x}" cy="${y}" r="${19*es}" fill="${earC}" ${S}/><circle cx="${x}" cy="${y}" r="${10*es}" fill="${L.earIn}"/>`;}
  if(E==='roundSide')for(const g of[-1,1]){const x=cx+g*(hw+6),y=cy-2;s+=`<circle cx="${x}" cy="${y}" r="17" fill="${earC}" ${S}/><circle cx="${x}" cy="${y}" r="9" fill="${L.earIn}"/>`;}
  if(E==='ele')for(const g of[-1,1]){const x=cx+g*(hw+16),y=cy+2;s+=`<ellipse cx="${x}" cy="${y}" rx="32" ry="40" fill="${earC}" ${S}/><ellipse cx="${x-g*4}" cy="${y}" rx="20" ry="28" fill="${L.earIn}"/>`;}
  if(E==='bunny')for(const g of[-1,1]){const x=cx+g*hw*.36,y=cy-hh-20,t=`transform="rotate(${g*9} ${x} ${cy-hh+10})"`;s+=`<ellipse cx="${x}" cy="${y}" rx="14" ry="36" fill="${earC}" ${S} ${t}/><ellipse cx="${x}" cy="${y+3}" rx="6.5" ry="25" fill="${L.earIn}" ${t}/>`;}
  if(E==='side')for(const g of[-1,1]){const big=L.earBig?1.2:1,x=cx+g*(hw+10*big),y=cy-hh*.3,t=`transform="rotate(${-g*24} ${x} ${y})"`;s+=`<ellipse cx="${x}" cy="${y}" rx="${23*big}" ry="${12*big}" fill="${earC}" ${S} ${t}/><ellipse cx="${x}" cy="${y}" rx="${13*big}" ry="${6*big}" fill="${L.earIn}" ${t}/>`;}
  if(has('gills'))for(const g of[-1,1])for(let i=0;i<3;i++)s+=two(`M${cx+g*(hw-8)} ${cy-16+i*15} q${g*20} ${-12+i*9} ${g*36} ${-20+i*14}`,L.gillC,7);
  if(has('rmane'))[[-.92,-8,19],[-.98,18,17],[-.84,40,14]].forEach(q=>{s+=`<circle cx="${cx+q[0]*hw}" cy="${cy+q[1]}" r="${q[2]}" fill="${rb}" ${S}/>`;});
  if(has('horns'))for(const g of[-1,1]){const hs=L.hornS||1,x=cx+g*hw*.34,y=cy-hh+8;s+=`<path d="M${x-g*7} ${y} q${g*2*hs} ${-30*hs} ${g*22*hs} ${-34*hs} q${-g*2*hs} ${14*hs} ${-g*6*hs} ${34*hs} Z" fill="${L.hornC}" ${S}/>`;}
  if(has('antlers'))for(const g of[-1,1]){const x=cx+g*hw*.34,y=cy-hh+8;s+=two(`M${x} ${y} v-26 M${x} ${y-12} l${g*12} -10 M${x} ${y-20} l${-g*9} -9`,'#c9a070',5);}
  if(has('ossicones'))for(const g of[-1,1]){const x=cx+g*hw*.32,y=cy-hh+6;s+=two(`M${x} ${y} v-15`,L.fur,6)+`<circle cx="${x}" cy="${y-18}" r="6.5" fill="#8a6238" ${S3}/>`;}
  if(has('dhorns'))for(const g of[-1,1]){const x=cx+g*hw*.5,y=cy-hh*.72;s+=`<path d="M${x-9} ${y+8} L${x+g*8} ${y-22} L${x+10} ${y+6} Z" fill="#fff3a8" ${S}/>`;}
  // head
  const bumps=c=>{let t='';for(let i=0;i<12;i++){const a=i*Math.PI/6+.26;t+=`<circle cx="${(cx+Math.cos(a)*hw*.9).toFixed(1)}" cy="${(cy+Math.sin(a)*hh*.9).toFixed(1)}" r="17" fill="${c}" ${S}/>`;}return t;};
  if(has('mane'))s+=bumps(L.maneC).replace(/r="17"/g,'r="20"');
  if(L.fluffy)s+=bumps(headC)+`<ellipse cx="${cx}" cy="${cy}" rx="${hw}" ry="${hh}" fill="${headC}"/>`;
  else s+=`<ellipse cx="${cx}" cy="${cy}" rx="${hw}" ry="${hh}" fill="${headC}" ${S}/>`;
  let m='';
  if(L.face){const fy=L.faceLow?cy+hh*.62:cy+hh*.36,ry=L.faceLow?hh*.46:hh*.62;for(const g of[-1,1])m+=`<ellipse cx="${cx+g*hw*.42}" cy="${fy}" rx="${hw*.5}" ry="${ry}" fill="${L.face}"/>`;m+=`<ellipse cx="${cx}" cy="${cy+hh*.7}" rx="${hw*.7}" ry="${hh*.45}" fill="${L.face}"/>`;}
  if(L.blaze)m+=`<path d="M${cx-8} ${cy-hh-2} L${cx+8} ${cy-hh-2} L${cx+13} ${cy+hh*.3} L${cx-13} ${cy+hh*.3} Z" fill="${L.blaze}"/>`;
  if(L.patch)for(const g of(L.patch.side?[L.patch.side]:[-1,1]))m+=`<ellipse cx="${cx+g*hw*.46}" cy="${cy-4}" rx="${hw*.36}" ry="${hh*.48}" fill="${L.patch.c||L.patch}"/>`;
  if(L.spots&&!L.spotsBody)[[-32,-30,9],[30,-36,7],[44,2,6],[-46,6,5],[4,-44,5]].forEach((q,k)=>{m+=SG(cx+q[0]*hw/58,cy+q[1]*hh/52,q[2])+`<circle cx="${cx+q[0]*hw/58}" cy="${cy+q[1]*hh/52}" r="${q[2]}" fill="${SC(k+3)}"/>`;});
  if(L.stripes){m+=`<path d="M${cx-13} ${cy-hh} v15 M${cx} ${cy-hh} v21 M${cx+13} ${cy-hh} v15" stroke="${L.stripes}" stroke-width="6" stroke-linecap="round" fill="none"/>`;
    for(const g of[-1,1])m+=`<path d="M${cx+g*hw} ${cy-18} h${-g*15} M${cx+g*hw} ${cy-2} h${-g*18}" stroke="${L.stripes}" stroke-width="6" stroke-linecap="round" fill="none"/>`;}
  if(L.brows)for(const g of[-1,1])m+=`<ellipse cx="${cx+g*hw*.42}" cy="${cy-19}" rx="7" ry="5" fill="${L.brows}"/>`;
  if(L.wrinkle)m+=`<path d="M${cx-12} ${cy-30} q12 -7 24 0 M${cx-8} ${cy-22} q8 -5 16 0" fill="none" stroke="${k}" stroke-width="2.5" stroke-linecap="round" opacity=".6"/>`;
  m+=form2D('headClip',C);
  s+=`<g clip-path="url(#${id}c)">${m}</g>`;
  if(!L.fluffy)s+=`<ellipse cx="${cx}" cy="${cy}" rx="${hw}" ry="${hh}" fill="none" ${S}/>`;
  s+=form2D('headOver',C);
  const sn=L.snout,ny=cy+hh*.3;
  if(L.muzzle&&sn!=='trunk')s+=`<ellipse cx="${cx}" cy="${cy+hh*.44}" rx="${hw*(L.muzzleBig?.5:.4)}" ry="${hh*(L.muzzleBig?.4:.32)}" fill="${L.muzzle}"/>`;
  for(const g of[-1,1])s+=`<circle cx="${cx+g*hw*.66}" cy="${cy+hh*.36}" r="8" fill="#ff9aa8" opacity=".6"/>`;
  if(L.fringe){s+=`<g clip-path="url(#${id}c)">`;for(const x of[-40,-20,0,20,40])s+=`<circle cx="${cx+x}" cy="${cy-1}" r="15" fill="${L.fringe}" ${S}/>`;s+=`<ellipse cx="${cx}" cy="${cy-20}" rx="${hw}" ry="24" fill="${L.fringe}"/></g>`;}
  else s+=eyesSVG(L,cx,cy-2,hw,o,A,k);
  // nose and mouth
  const mouth=`<path d="M${cx} ${ny+4} v7 q-8 9 -15 1 M${cx} ${ny+11} q8 9 15 1" fill="none" stroke="${k}" stroke-width="3" stroke-linecap="round"/>`;
  if(L.teeth)s+=`<rect x="${cx-5.5}" y="${ny+11}" width="11" height="9" rx="2.5" fill="#fff" stroke="${k}" stroke-width="2"/>`;
  if(sn==='dog'){if(L.tongue&&!o.sleep)s+=`<ellipse cx="${cx}" cy="${ny+17}" rx="6" ry="8" fill="${L.tongueC||'#ff8fa3'}" stroke="${k}" stroke-width="2.5"/>`;
    if(has('einstein')&&!o.sleep)s+=`<path d="M${cx-11} ${ny+11} Q${cx-12} ${ny+40} ${cx} ${ny+41} Q${cx+12} ${ny+40} ${cx+11} ${ny+11} Z" fill="#ff7f98" stroke="${k}" stroke-width="3" stroke-linejoin="round"/><path d="M${cx} ${ny+16} v16" stroke="#d9506e" stroke-width="2.5" stroke-linecap="round"/>`;
    s+=mouth+`<ellipse cx="${cx}" cy="${ny}" rx="9" ry="6.5" fill="${L.nose}"/><ellipse cx="${cx-3}" cy="${ny-2}" rx="3" ry="1.6" fill="#fff" opacity=".6"/>`;}
  else if(sn==='cat')s+=mouth+`<path d="M${cx-6.5} ${ny-2} h13 l-6.5 7.5 Z" fill="${L.noseC||'#ff8fa3'}" stroke="${k}" stroke-width="2" stroke-linejoin="round"/>`;
  else if(sn==='beak'){const b=L.beakBig?1.45:1;s+=`<path d="M${cx-10*b} ${ny-4} Q${cx} ${ny-4-6*b} ${cx+10*b} ${ny-4} L${cx} ${ny+12*b} Z" fill="${L.beakC}" ${S3}/>`;if(L.beakBig)s+=`<path d="M${cx-12} ${ny-3} Q${cx} ${ny-10} ${cx+12} ${ny-3}" fill="none" stroke="#5b8def" stroke-width="5" stroke-linecap="round"/>`;}
  else if(sn==='bill')s+=`<ellipse cx="${cx}" cy="${ny+5}" rx="17" ry="9.5" fill="${L.beakC}" ${S3}/><path d="M${cx-11} ${ny+5} q11 5 22 0" fill="none" stroke="${k}" stroke-width="2" stroke-linecap="round"/>`;
  else if(sn==='pig')s+=`<ellipse cx="${cx}" cy="${ny+3}" rx="17" ry="12" fill="#ff9eb5" ${S3}/><ellipse cx="${cx-6}" cy="${ny+3}" rx="3" ry="4.5" fill="#c9607a"/><ellipse cx="${cx+6}" cy="${ny+3}" rx="3" ry="4.5" fill="#c9607a"/><path d="M${cx-8} ${ny+20} q8 6 16 0" fill="none" stroke="${k}" stroke-width="3" stroke-linecap="round"/>`;
  else if(sn==='cow')s+=`<ellipse cx="${cx-9}" cy="${ny+1}" rx="3.5" ry="5" fill="${L.nose}"/><ellipse cx="${cx+9}" cy="${ny+1}" rx="3.5" ry="5" fill="${L.nose}"/><path d="M${cx-10} ${ny+13} q10 8 20 0" fill="none" stroke="${k}" stroke-width="3" stroke-linecap="round"/>`;
  else if(sn==='trunk')s+=two(`M${cx} ${cy+hh*.12} q-3 30 8 46 q9 12 19 2`,L.fur,15)+`<path d="M${cx-9} ${cy+hh*.5} h14 M${cx-6} ${cy+hh*.72} h13" stroke="${k}" stroke-width="2" opacity=".35" stroke-linecap="round"/>`;
  else if(sn==='smile')s+=`<path d="M${cx-hw*.28} ${ny+2} Q${cx} ${ny+18} ${cx+hw*.28} ${ny+2}" fill="none" stroke="${k}" stroke-width="3.5" stroke-linecap="round"/>`;
  if(has('einstein')){const W1='#f6f5f0';s+=`<path d="M${cx} ${ny+4} Q${cx-10} ${ny-1} ${cx-22} ${ny+5} Q${cx-30} ${ny+10} ${cx-27} ${ny+17} Q${cx-14} ${ny+11} ${cx} ${ny+12} Q${cx+14} ${ny+11} ${cx+27} ${ny+17} Q${cx+30} ${ny+10} ${cx+22} ${ny+5} Q${cx+10} ${ny-1} ${cx} ${ny+4} Z" fill="${W1}" stroke="${k}" stroke-width="2.5" stroke-linejoin="round"/>`;
    s+=`<ellipse cx="${cx}" cy="${ny}" rx="9" ry="6.5" fill="${L.nose}"/><ellipse cx="${cx-3}" cy="${ny-2}" rx="3" ry="1.6" fill="#fff" opacity=".6"/>`;
    for(const g of[-1,1])s+=`<path d="M${cx+g*hw*.2} ${cy-17} Q${cx+g*hw*.42} ${cy-34} ${cx+g*hw*.66} ${cy-22} Q${cx+g*hw*.44} ${cy-25} ${cx+g*hw*.2} ${cy-17} Z" fill="${W1}" stroke="${k}" stroke-width="2.5" stroke-linejoin="round"/>`;}
  if(has('dirt'))s+=`<circle cx="${cx+7}" cy="${ny-7}" r="4" fill="#9a6b43"/>`;
  if(L.whiskers)for(const g of[-1,1])s+=`<path d="M${cx+g*hw*.34} ${ny+5} l${g*22} -6 M${cx+g*hw*.34} ${ny+9} l${g*24} 1 M${cx+g*hw*.34} ${ny+13} l${g*20} 8" stroke="${k}" stroke-width="2" stroke-linecap="round" opacity=".55"/>`;
  // ears in front
  if(E==='floppy'||E==='long'){const len=L.earLen||(E==='long'?42:30);for(const g of[-1,1]){const x=cx+g*(hw+1),top=cy-hh*.55;
    s+=`<ellipse cx="${x}" cy="${top+len}" rx="15" ry="${len}" fill="${earC}" ${S} transform="rotate(${-g*10} ${x} ${top})"/>`;}}
  if(E==='fold')for(const g of[-1,1])s+=`<path d="M${cx+g*hw*.3} ${cy-hh*.93} Q${cx+g*hw*1.3} ${cy-hh*1.12} ${cx+g*hw*1.06} ${cy-hh*.06} Q${cx+g*hw*.78} ${cy-hh*.52} ${cx+g*hw*.3} ${cy-hh*.93} Z" fill="${earC}" ${S}/>`;
  if(E==='pom'){for(const g of[-1,1])s+=`<circle cx="${cx+g*(hw+6)}" cy="${cy+8}" r="23" fill="${earC}" ${S}/>`;s+=`<circle cx="${cx}" cy="${cy-hh-8}" r="22" fill="${earC}" ${S}/>`;}
  // hats and hair
  if(has('rmane'))s+=`<circle cx="${cx-22}" cy="${cy-hh+10}" r="15" fill="${rb}" ${S}/><circle cx="${cx+24}" cy="${cy-hh+9}" r="11" fill="${rb}" ${S}/>`;
  if(has('unihorn'))s+=`<path d="M${cx-10} ${cy-hh+8} L${cx+1} ${cy-hh-38} L${cx+12} ${cy-hh+8} Z" fill="#ffd86b" ${S}/><path d="M${cx-6} ${cy-hh-6} l14 -5 M${cx-3} ${cy-hh-20} l9 -4" stroke="${k}" stroke-width="2.5" stroke-linecap="round"/>`;
  if(has('einstein')){const W1='#f6f5f0',rx=hw,ry=hh,pts=[],N=17,a0=Math.PI*.92,a1=Math.PI*2.08;
    for(let i=0;i<=N;i++){const t=a0+(a1-a0)*i/N,out=i%2?1.34:1.12,wob=1+((i*37)%7)/40;pts.push([cx+Math.cos(t)*rx*out*wob,cy+Math.sin(t)*ry*out*wob]);}
    for(let i=N;i>=0;i--){const t=a0+(a1-a0)*i/N;pts.push([cx+Math.cos(t)*rx*.86,cy+Math.sin(t)*ry*.8]);}
    s+=`<path d="M${pts.map(q=>q[0].toFixed(1)+' '+q[1].toFixed(1)).join(' L')} Z" fill="${W1}" stroke="${k}" stroke-width="3" stroke-linejoin="round"/>`;
    for(const q of[[-.5,-1.02],[0,-1.12],[.5,-1.02],[-1.02,-.3],[1.02,-.3]])s+=`<path d="M${cx+q[0]*rx} ${cy+q[1]*ry} q${q[0]*10} -6 ${q[0]*14+4} -2" fill="none" stroke="#d8d6cc" stroke-width="2.5" stroke-linecap="round"/>`;}
  if(has('tuft'))s+=two(`M${cx} ${cy-hh+2} q-5 -15 -13 -13 M${cx} ${cy-hh+2} q0 -17 3 -20 M${cx} ${cy-hh+2} q7 -13 14 -10`,L.tuftC||headC,5);
  if(has('dspikes'))for(const x of[-16,0,16])s+=`<path d="M${cx+x-8} ${cy-hh+4+Math.abs(x)*.2} l8 -18 l8 18 Z" fill="#ff8a4c" ${S3}/>`;
  if(has('grad'))s+=`<path d="M${cx-34} ${cy-hh+2} L${cx} ${cy-hh-14} L${cx+34} ${cy-hh+2} L${cx} ${cy-hh+16} Z" fill="#3a3640" ${S}/><path d="M${cx} ${cy-hh+1} L${cx+30} ${cy-hh+8} v14" fill="none" stroke="#ffd23f" stroke-width="3.5" stroke-linecap="round"/><circle cx="${cx+30}" cy="${cy-hh+24}" r="5" fill="#ffd23f" stroke="${k}" stroke-width="2"/>`;
  if(has('flower')){const fx=cx+24,fy=cy-hh+4;for(let i=0;i<5;i++){const a=i*Math.PI*2/5;s+=`<circle cx="${(fx+Math.cos(a)*8).toFixed(1)}" cy="${(fy+Math.sin(a)*8).toFixed(1)}" r="6.5" fill="#ff9ecb" stroke="${k}" stroke-width="2"/>`;}s+=`<circle cx="${fx}" cy="${fy}" r="5" fill="#ffd23f"/>`;}
  if(has('bow')){const bx=cx+26,b2=cy-hh+8;s+=`<path d="M${bx} ${b2} l-15 -10 v20 Z M${bx} ${b2} l15 -10 v20 Z" fill="#ff7fb8" ${S3}/><circle cx="${bx}" cy="${b2}" r="5" fill="#ff9ecb" stroke="${k}" stroke-width="2.5"/>`;}
  const chy=cy+hh+9;
  if(has('daisy'))for(const x of[-18,0,18])s+=`<circle cx="${cx+x}" cy="${chy-(x?5:0)}" r="6.5" fill="#fff" stroke="${k}" stroke-width="2"/><circle cx="${cx+x}" cy="${chy-(x?5:0)}" r="2.5" fill="#ffd23f"/>`;
  if(has('shellneck'))s+=`<path d="M${cx-10} ${chy+6} Q${cx-13} ${chy-9} ${cx} ${chy-9} Q${cx+13} ${chy-9} ${cx+10} ${chy+6} Z" fill="#ffc2d1" stroke="${k}" stroke-width="2.5" stroke-linejoin="round"/><path d="M${cx} ${chy+5} v-12 M${cx-5} ${chy+5} l-2 -10 M${cx+5} ${chy+5} l2 -10" stroke="${k}" stroke-width="1.5" fill="none"/>`;
  if(has('barrel'))s+=`<rect x="${cx-14}" y="${chy-8}" width="28" height="20" rx="7" fill="#c98a4f" stroke="${k}" stroke-width="3"/><path d="M${cx-6} ${chy-8} v20 M${cx+6} ${chy-8} v20" stroke="${k}" stroke-width="2"/>`;
  if(has('moon'))s+=`<circle cx="${cx}" cy="${chy}" r="8" fill="#ffe066" stroke="${k}" stroke-width="2.5"/><circle cx="${cx+4}" cy="${chy-2}" r="6" fill="${L.belly}"/>`+star4(cx-30,cy-34,7,'#fff','twk')+star4(cx+34,cy+34,6,'#fff','twk',.6)+star4(96,by-6,6,'#fff','twk',.3);
  if(has('leaves'))[[-30,-hh+10,-30],[20,-hh+2,25],[42,-22,60]].forEach(q=>{s+=`<ellipse cx="${cx+q[0]}" cy="${cy+q[1]}" rx="10" ry="5" fill="#6fcf73" stroke="${k}" stroke-width="2" transform="rotate(${q[2]} ${cx+q[0]} ${cy+q[1]})"/>`;});
  if(has('flake')){const fx=cx+26,fy=cy-hh+2;s+=`<g stroke="#7fc8f0" stroke-width="3.5" stroke-linecap="round"><path d="M${fx-10} ${fy} h20 M${fx-5} ${fy-9} l10 18 M${fx+5} ${fy-9} l-10 18"/></g>`;}
  if(has('rainbow'))['#ff8fb3','#ffe066','#7fc8f0'].forEach((c,i)=>{const r=30-i*7;s+=`<path d="M${cx-r} ${cy-hh+8} A${r} ${r} 0 0 1 ${cx+r} ${cy-hh+8}" fill="none" stroke="${c}" stroke-width="7"/>`;});
  if(has('bubbles'))[[60,-40,9,0],[74,-14,6,.5],[-66,-30,7,1],[52,-66,5,1.4]].forEach(q=>{s+=`<circle${A('flt')} style="animation-delay:${q[3]}s" cx="${cx+q[0]}" cy="${cy+q[1]}" r="${q[2]}" fill="#ffffff" fill-opacity=".6" stroke="#7fd3f0" stroke-width="2.5"/>`;});
  if(has('drops'))[[70,-20],[-72,-6],[58,-52]].forEach((q,i)=>{s+=`<path${A('flt')} style="animation-delay:${i*.4}s" d="M${cx+q[0]} ${cy+q[1]-9} q7 9 0 14 q-7 -5 0 -14Z" fill="#7fd3f0" stroke="${k}" stroke-width="2"/>`;});
  if(has('fireflies'))[[66,-44,0],[-70,-30,.7],[76,10,1.2],[-58,-62,.3]].forEach(q=>{s+=`<g${A('flt')} style="animation-delay:${q[2]}s"><circle cx="${cx+q[0]}" cy="${cy+q[1]}" r="9" fill="#fff27a" opacity=".4"/><circle cx="${cx+q[0]}" cy="${cy+q[1]}" r="4" fill="#fff27a" stroke="#e0b93a" stroke-width="1.5"/></g>`;});
  if(has('embers'))s+=star4(cx+64,cy-46,8,'#ffb347','twk')+star4(cx-66,cy-54,6,'#ff7a45','twk',.5)+star4(cx+78,cy-6,5,'#ffd23f','twk',.9);
  if(has('twinkle'))s+=star4(cx-32,cy-30,7,'#ffe066','twk')+star4(cx+30,cy-36,6,'#ffe066','twk',.5)+star4(100+27,by+4,6,'#ffe066','twk',.9);
  if(has('cap'))s+=`<path d="M${cx-27} ${cy-hh+10} Q${cx} ${cy-hh-32} ${cx+27} ${cy-hh+10} Z" fill="#5b8def" ${S}/><rect x="${cx-31}" y="${cy-hh+5}" width="62" height="10" rx="5" fill="#fff" ${S}/>`;
  s+=form2D('top',C);
  if(o.sparkly)s+=sparkles(an);
  return `<svg class="pup" viewBox="0 0 200 210" xmlns="http://www.w3.org/2000/svg"><g transform="translate(100 196) scale(${L.scale}) translate(-100 -196)">${s}</g></svg>`;
}
const pupSVG=critterSVG;

/* ============ people ============ */
function sebSVG(wave){
  const k=INK,skin='#c9905f',hair='#3a2416',g='#3fae5a',gd='#2e8b47';
  return `<svg viewBox="0 0 120 190" xmlns="http://www.w3.org/2000/svg" style="overflow:visible"><g stroke="${k}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round">
  <rect x="28" y="86" width="64" height="46" rx="14" fill="${gd}"/>
  <rect x="44" y="140" width="13" height="30" rx="5" fill="${skin}"/><rect x="63" y="140" width="13" height="30" rx="5" fill="${skin}"/>
  <ellipse cx="48" cy="174" rx="13" ry="8" fill="#7a4f2a"/><ellipse cx="72" cy="174" rx="13" ry="8" fill="#7a4f2a"/>
  <rect x="39" y="122" width="42" height="26" rx="9" fill="#8a7355"/>
  <rect x="36" y="86" width="48" height="46" rx="16" fill="${g}"/>
  <path d="M46 88 v40 M74 88 v40" stroke="${gd}" stroke-width="5"/>
  <circle cx="60" cy="108" r="8" fill="#ffd23f"/>
  <ellipse cx="29" cy="106" rx="8" ry="17" fill="${g}" transform="rotate(14 29 106)"/><circle cx="25" cy="122" r="7" fill="${skin}"/>
  ${wave?`<ellipse cx="94" cy="88" rx="8" ry="17" fill="${g}" transform="rotate(-140 94 88)"/><circle cx="105" cy="72" r="7" fill="${skin}"/>`:`<ellipse cx="91" cy="106" rx="8" ry="17" fill="${g}" transform="rotate(-14 91 106)"/><circle cx="95" cy="122" r="7" fill="${skin}"/>`}
  <circle cx="27" cy="58" r="7" fill="${skin}"/><circle cx="93" cy="58" r="7" fill="${skin}"/>
  <circle cx="60" cy="54" r="34" fill="${skin}"/>
  <path d="M27 44 Q20 64 31 76 Q33 60 40 48 Z M93 44 Q100 64 89 76 Q87 60 80 48 Z" fill="${hair}"/>
  <path d="M30 46 Q38 66 48 53 Q58 66 68 53 Q80 66 90 46 Q80 34 60 34 Q40 34 30 46Z" fill="${hair}"/>
  <path d="M26 44 Q26 10 60 10 Q94 10 94 44 Z" fill="${g}"/>
  <path d="M22 44 Q60 34 98 44 Q104 54 60 50 Q16 54 22 44Z" fill="${gd}"/>
  <circle cx="60" cy="26" r="9" fill="#fff"/></g>
  <g fill="${gd}"><circle cx="60" cy="28" r="3.6"/><circle cx="55" cy="23" r="1.9"/><circle cx="60" cy="21" r="1.9"/><circle cx="65" cy="23" r="1.9"/></g>
  <g fill="${k}"><circle cx="60" cy="110" r="3"/><circle cx="56" cy="105.500" r="1.5"/><circle cx="60" cy="104" r="1.5"/><circle cx="64" cy="105.500" r="1.5"/></g>
  <circle cx="47" cy="64" r="5.5" fill="#2e211c"/><circle cx="73" cy="64" r="5.5" fill="#2e211c"/><circle cx="45.500" cy="62" r="2" fill="#fff"/><circle cx="71.500" cy="62" r="2" fill="#fff"/>
  <circle cx="38" cy="74" r="6" fill="#ff8f8f" opacity=".5"/><circle cx="82" cy="74" r="6" fill="#ff8f8f" opacity=".5"/>
  <path d="M50 76 Q60 86 70 76" fill="#fff" stroke="${k}" stroke-width="3" stroke-linejoin="round"/></svg>`;
}
function grannySVG(){
  const k=INK,skin='#f0c8a0';
  return `<svg viewBox="0 0 130 200" xmlns="http://www.w3.org/2000/svg" style="overflow:visible"><g stroke="${k}" stroke-width="3.5" stroke-linejoin="round" stroke-linecap="round">
  <ellipse cx="48" cy="188" rx="14" ry="8" fill="#b58cff"/><ellipse cx="82" cy="188" rx="14" ry="8" fill="#b58cff"/>
  <path d="M30 186 Q26 100 65 96 Q104 100 100 186 Z" fill="#c8b3f5"/>
  <path d="M44 184 Q42 122 65 120 Q88 122 86 184 Z" fill="#fff"/>
  <ellipse cx="28" cy="130" rx="9" ry="22" fill="#c8b3f5" transform="rotate(16 28 130)"/><ellipse cx="102" cy="130" rx="9" ry="22" fill="#c8b3f5" transform="rotate(-16 102 130)"/>
  <circle cx="22" cy="150" r="7" fill="${skin}"/><circle cx="108" cy="150" r="7" fill="${skin}"/>
  <circle cx="65" cy="20" r="16" fill="#e6e6ee"/><circle cx="65" cy="62" r="38" fill="${skin}"/>
  <path d="M28 58 Q30 24 65 24 Q100 24 102 58 Q84 38 65 40 Q46 38 28 58Z" fill="#e6e6ee"/>
  <circle cx="50" cy="66" r="11" fill="#fff" fill-opacity=".5"/><circle cx="80" cy="66" r="11" fill="#fff" fill-opacity=".5"/><path d="M61 66 h8" fill="none"/>
  <path d="M54 84 Q65 94 76 84" fill="none"/></g>
  <circle cx="50" cy="67" r="4" fill="#2e211c"/><circle cx="80" cy="67" r="4" fill="#2e211c"/>
  <circle cx="40" cy="80" r="6" fill="#ff8f8f" opacity=".5"/><circle cx="90" cy="80" r="6" fill="#ff8f8f" opacity=".5"/>
  <g fill="#ff9ecb"><circle cx="65" cy="156" r="8"/><circle cx="55" cy="144" r="4"/><circle cx="65" cy="140" r="4"/><circle cx="75" cy="144" r="4"/></g></svg>`;
}
function gateSVG(){
  const k=INK;
  return `<svg viewBox="0 0 320 240" xmlns="http://www.w3.org/2000/svg" style="overflow:visible"><g stroke="${k}" stroke-width="4" stroke-linejoin="round">
  <rect x="40" y="70" width="26" height="170" rx="6" fill="#c98a4f"/><rect x="254" y="70" width="26" height="170" rx="6" fill="#c98a4f"/>
  <path d="M30 80 Q160 -20 290 80 L290 50 Q160 -54 30 50 Z" fill="#ffd86b"/>
  <path d="M40 120 L-20 150 L-20 240 L40 230 Z" fill="#e0a56a"/><path d="M280 120 L340 150 L340 240 L280 230 Z" fill="#e0a56a"/></g>
  <text x="160" y="24" text-anchor="middle" font-size="23" font-weight="900" fill="${k}" font-family="inherit">Puppy Park</text></svg>`;
}

/* ============ backgrounds ============ */
const cloudS=(x,y,sc,f,o)=>`<g transform="translate(${x} ${y}) scale(${sc||1})" fill="${f||'#fff'}" opacity="${o==null?1:o}"><ellipse cx="0" cy="0" rx="62" ry="26"/><circle cx="-28" cy="-14" r="24"/><circle cx="6" cy="-24" r="30"/><circle cx="36" cy="-8" r="20"/></g>`;
const treeS=(x,y,r,c,t)=>`<rect x="${x-r*.14}" y="${y-r*.3}" width="${r*.28}" height="${r*1.1}" rx="4" fill="${t||'#9a6b43'}"/><circle cx="${x}" cy="${y-r*.8}" r="${r}" fill="${c}"/><circle cx="${x-r*.3}" cy="${y-r*1.05}" r="${r*.3}" fill="#fff" opacity=".18"/>`;
const pineS=(x,y,h,c,snow)=>`<rect x="${x-h*.06}" y="${y-h*.2}" width="${h*.12}" height="${h*.22}" fill="#8a5a3a"/><path d="M${x} ${y-h} L${x+h*.3} ${y-h*.52} L${x+h*.16} ${y-h*.52} L${x+h*.38} ${y-h*.16} L${x-h*.38} ${y-h*.16} L${x-h*.16} ${y-h*.52} L${x-h*.3} ${y-h*.52} Z" fill="${c}"/>${snow?`<path d="M${x} ${y-h} L${x+h*.14} ${y-h*.78} Q${x} ${y-h*.7} ${x-h*.14} ${y-h*.78} Z" fill="#fff"/>`:''}`;
function bg(id){
  const u='b'+(++uid),R=seed(id.length*31+id.charCodeAt(0));let s='';
  const grad=(a,b,c)=>`<defs><linearGradient id="${u}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/>${c?`<stop offset=".5" stop-color="${c}"/>`:''}<stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="1024" height="768" fill="url(#${u})"/>`;
  if(id==='meadow'||id==='park'){
    s+=grad('#a6dfff','#f0fbff')+`<circle cx="890" cy="130" r="84" fill="#ffe27a" opacity=".35"/><circle cx="890" cy="130" r="60" fill="#ffe27a"/>`+cloudS(180,150,1.2)+cloudS(560,110,.9)+cloudS(380,230,.7,'#fff',.8);
    s+=`<path d="M0 420 Q180 330 400 400 T800 380 T1024 400 V768 H0Z" fill="#c9efb0"/>`+treeS(690,372,40,'#8fd67c')+treeS(120,380,34,'#8fd67c')+treeS(240,372,24,'#9fdc8a');
    s+=`<path d="M0 490 Q260 420 520 490 T1024 460 V768 H0Z" fill="#a8e08c"/><path d="M0 560 Q500 520 1024 570 V768 H0Z" fill="#8cd574"/>`;
    if(id==='park'){s+=`<g stroke="${INK}" stroke-width="3" fill="#fff8e6">`;for(let x=10;x<1024;x+=54)s+=`<rect x="${x}" y="248" width="18" height="62" rx="8"/>`;s+=`<rect x="0" y="266" width="1024" height="10"/><rect x="0" y="290" width="1024" height="10"/></g><ellipse cx="800" cy="690" rx="170" ry="52" fill="#9bdcff" stroke="#fff" stroke-width="6"/>`;}
    for(let i=0;i<34;i++){const x=R()*1024,y=585+R()*175,c=pick2(R,['#fff','#ffc4dc','#fff27a','#c9b6ff']);s+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="6" fill="${c}"/><circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="2.4" fill="#ffb347"/>`;}
  }else if(id==='jungle'){
    s+=grad('#bdebd6','#f0fff6')+`<circle cx="860" cy="120" r="60" fill="#ffe27a"/>`+cloudS(220,140,1.1)+cloudS(600,100,.8);
    s+=`<path d="M0 430 Q200 340 420 410 T820 380 T1024 410 V768 H0Z" fill="#8fdca0"/>`;
    [[110,440,1],[300,420,.8],[700,430,.9],[900,440,1.1],[520,410,.7]].forEach(q=>{const x=q[0],y=q[1],k=q[2];s+=`<path d="M${x} ${y} q${10*k} ${-70*k} ${-4*k} ${-150*k}" stroke="#a9773f" stroke-width="${16*k}" fill="none" stroke-linecap="round"/>`;for(let i=0;i<6;i++)s+=`<ellipse cx="${x-4*k}" cy="${y-190*k}" rx="${13*k}" ry="${46*k}" fill="${i%2?'#3fa85c':'#58c070'}" transform="rotate(${i*60+30} ${x-4*k} ${y-150*k})"/>`;});
    s+=`<path d="M0 500 Q260 430 520 495 T1024 470 V768 H0Z" fill="#6fcf82"/><path d="M0 570 Q500 530 1024 580 V768 H0Z" fill="#58b866"/>`;
    for(let i=0;i<30;i++){const x=R()*1024,y=590+R()*170,c=pick2(R,['#ff7fb8','#ffb347','#fff27a','#ff6b6b']);s+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="7" fill="${c}"/><circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="2.6" fill="#fff"/>`;}
  }else if(id==='micro'){
    s+=grad('#eef8ff','#dcefff','#cfe7f8');
    for(let i=0;i<20;i++)s+=`<path d="M${i*54} 0 V768" stroke="#b8d4ea" stroke-width="2" opacity=".6"/>`;for(let j=0;j<15;j++)s+=`<path d="M0 ${j*54} H1024" stroke="#b8d4ea" stroke-width="2" opacity=".6"/>`;
    const ball=(x,y,r,c)=>{let o='';for(let k=0;k<14;k++){const a=k*Math.PI/7;o+=`<path d="M${x+Math.cos(a-.18)*r*.9} ${y+Math.sin(a-.18)*r*.9} L${x+Math.cos(a)*r*1.35} ${y+Math.sin(a)*r*1.35} L${x+Math.cos(a+.18)*r*.9} ${y+Math.sin(a+.18)*r*.9}Z" fill="#ffb000"/>`;}return o+`<circle cx="${x}" cy="${y}" r="${r}" fill="${c}"/><circle cx="${x-r*.35}" cy="${y-r*.35}" r="${r*.25}" fill="#fff6c8"/>`;};
    s+=ball(130,560,70,'#ffd23f')+ball(880,600,46,'#ffe27a');
    const fl=(x,y,r)=>{let o='';for(let k=0;k<6;k++){const a=k*Math.PI/3,ex=x+Math.cos(a)*r,ey=y+Math.sin(a)*r;o+=`<path d="M${x} ${y} L${ex} ${ey}" stroke="#ffffff" stroke-width="10" stroke-linecap="round"/>`;for(const f of[.5,.75])for(const s2 of[-1,1]){const bx=x+Math.cos(a)*r*f,by=y+Math.sin(a)*r*f,aa=a+s2*.8;o+=`<path d="M${bx} ${by} L${bx+Math.cos(aa)*r*.25} ${by+Math.sin(aa)*r*.25}" stroke="#ffffff" stroke-width="7" stroke-linecap="round"/>`;}}return o;};
    s+=fl(860,170,90)+fl(250,150,50);
    [[520,140,40],[640,250,26],[380,300,18],[740,420,30],[300,430,22]].forEach(q=>{s+=`<circle cx="${q[0]}" cy="${q[1]}" r="${q[2]}" fill="#ffffff" fill-opacity=".35" stroke="#9fd8ff" stroke-width="4"/><circle cx="${q[0]-q[2]*.4}" cy="${q[1]-q[2]*.4}" r="${q[2]*.2}" fill="#fff"/>`;});
    s+=`<g transform="translate(560 600)"><ellipse rx="120" ry="38" fill="none" stroke="#7fe0ff" stroke-width="6"/><ellipse rx="120" ry="38" fill="none" stroke="#7fe0ff" stroke-width="6" transform="rotate(60)"/><ellipse rx="120" ry="38" fill="none" stroke="#7fe0ff" stroke-width="6" transform="rotate(-60)"/><circle r="22" fill="#e8423a"/><circle cx="12" cy="-8" r="14" fill="#b8c4d6"/><circle cx="120" r="10" fill="#5cb8ff"/></g>`;
    s+=`<circle cx="512" cy="384" r="640" fill="none" stroke="#4a4f5e" stroke-width="320" opacity=".55"/>`;
  }else if(id==='cave'){
    s+=grad('#2a1c16','#4a2e22','#3a241c');
    [[60,420,'#ff8a3c'],[880,380,'#ff7fb8'],[500,300,'#5ce0e6']].forEach(q=>{s+=`<circle cx="${q[0]}" cy="${q[1]}" r="160" fill="${q[2]}" opacity=".08"/>`;});
    for(let i=0;i<16;i++){const x=i*68+R()*30,h=50+R()*90;s+=`<path d="M${x-22} 0 L${x} ${h} L${x+22} 0Z" fill="#3a2a22"/>`;}
    s+=`<path d="M0 470 Q260 420 520 460 T1024 440 V768 H0Z" fill="#5a463c"/>`;
    [[120,520,'#ff9ecb'],[330,500,'#5ce0e6'],[760,510,'#b58cff'],[930,530,'#ffffff']].forEach(q=>{for(let k=0;k<3;k++){const h=40+k*22,x=q[0]+k*18-18;s+=`<path d="M${x-10} ${q[1]} L${x} ${q[1]-h} L${x+10} ${q[1]}Z" fill="${q[2]}" opacity=".9"/>`;}s+=`<circle cx="${q[0]}" cy="${q[1]-30}" r="60" fill="${q[2]}" opacity=".12"/>`;});
    s+=`<path d="M0 620 Q300 580 520 615 T1024 600 V680 Q700 660 520 690 T0 680Z" fill="#ff6a1a"/><path d="M0 620 Q300 580 520 615 T1024 600" fill="none" stroke="#ffd23f" stroke-width="8" opacity=".8"/><path d="M0 680 Q300 700 520 690 T1024 680 V768 H0Z" fill="#4a3a32"/>`;
    for(let i=0;i<8;i++)s+=`<circle cx="${(R()*1024)|0}" cy="${(615+R()*50)|0}" r="${(5+R()*6)|0}" fill="#ffd23f" opacity=".8"/>`;
  }else if(id==='space'){
    s+=grad('#0b0b26','#2a2060','#16163e');for(let i=0;i<70;i++)s+=star4((R()*1024)|0,(R()*768)|0,2+R()*4,'#fff',i%3?'':'twk',(R()*2).toFixed(1));
    s+=`<circle cx="840" cy="150" r="80" fill="#ff9e6b"/><ellipse cx="840" cy="150" rx="140" ry="26" fill="none" stroke="#ffd27a" stroke-width="12" transform="rotate(-15 840 150)"/><circle cx="150" cy="120" r="46" fill="#c9ccd6"/><circle cx="135" cy="108" r="9" fill="#aeb3bf"/><circle cx="168" cy="134" r="7" fill="#aeb3bf"/>`;
    s+=`<path d="M0 600 Q512 520 1024 600 V768 H0Z" fill="#c9ccd6"/><path d="M0 640 Q512 580 1024 650 V768 H0Z" fill="#b7bcc9"/>`;[[200,660,40],[520,700,28],[820,670,34]].forEach(q=>{s+=`<ellipse cx="${q[0]}" cy="${q[1]}" rx="${q[2]}" ry="${q[2]*.35}" fill="#9aa0ad"/>`;});
  }else if(id==='bay'){
    s+=grad('#a6dfff','#fff6dc')+`<circle cx="150" cy="120" r="60" fill="#ffe27a"/>`+cloudS(520,130,1.1)+cloudS(840,190,.8);
    s+=`<rect y="330" width="1024" height="230" fill="#7fd3f0"/><rect y="330" width="1024" height="40" fill="#a5e2f7"/>`;
    for(let i=0;i<9;i++){const x=40+R()*900,y=380+R()*110;s+=`<path d="M${x.toFixed(0)} ${y.toFixed(0)} q14 -10 28 0 q14 10 28 0" fill="none" stroke="#fff" stroke-width="5" stroke-linecap="round" opacity=".8"/>`;}
    s+=`<path d="M0 520 Q250 480 520 510 T1024 490 V768 H0Z" fill="#fbe7b0"/><path d="M0 520 Q250 480 520 510 T1024 490" fill="none" stroke="#fff" stroke-width="10" opacity=".8"/>`;
    ['#ff9ecb','#8fe39a','#ffd86b','#9bdcff'].forEach((c,i)=>{const x=60+i*84;s+=`<g stroke="${INK}" stroke-width="3" stroke-linejoin="round"><rect x="${x}" y="470" width="64" height="70" fill="${c}"/><path d="M${x-6} 470 L${x+32} 436 L${x+70} 470Z" fill="#fff"/><rect x="${x+22}" y="496" width="20" height="44" rx="3" fill="#fff"/></g>`;});
    for(let i=0;i<12;i++){const x=R()*1024,y=570+R()*180;s+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="${(3+R()*4).toFixed(0)}" fill="#f0cf86"/>`;}
  }else if(id==='hills'){
    s+=grad('#ffc78f','#fff0d8')+`<circle cx="512" cy="330" r="130" fill="#ffe27a" opacity=".5"/><circle cx="512" cy="330" r="96" fill="#ffd45c"/>`+cloudS(170,150,1.1,'#fff5e6')+cloudS(830,120,.9,'#fff5e6');
    s+=`<path d="M0 420 Q160 300 340 400 T700 360 T1024 410 V768 H0Z" fill="#f7a56b"/>`+treeS(150,392,36,'#e8623a')+treeS(250,400,26,'#ffb347')+treeS(830,380,40,'#f08c2e')+treeS(930,400,28,'#e8623a');
    s+=`<path d="M0 500 Q260 420 540 490 T1024 470 V768 H0Z" fill="#f2915a"/><path d="M0 570 Q500 530 1024 580 V768 H0Z" fill="#f6c088"/>`;
    for(let i=0;i<26;i++){const x=R()*1024,y=590+R()*170,c=pick2(R,['#e8623a','#ffb347','#ffd23f','#c9532b']);s+=`<ellipse cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" rx="9" ry="5" fill="${c}" transform="rotate(${(R()*180).toFixed(0)} ${x.toFixed(0)} ${y.toFixed(0)})"/>`;}
  }else if(id==='snow'){
    s+=grad('#c4e4ff','#f6fcff')+cloudS(200,130,1.1)+cloudS(800,110,.9);
    s+=`<path d="M60 470 L300 170 L540 470Z" fill="#e3f0fc"/><path d="M300 170 L372 260 L330 250 L300 290 L262 246 L236 250 Z" fill="#fff"/><path d="M430 480 L700 130 L980 480Z" fill="#d7e9fa"/><path d="M700 130 L782 236 L734 226 L700 270 L660 222 L624 228 Z" fill="#fff"/>`;
    s+=`<path d="M0 450 Q260 400 520 450 T1024 430 V768 H0Z" fill="#f0f8ff"/>`+pineS(110,470,130,'#5fae8a',1)+pineS(200,480,90,'#6fbf9a',1)+pineS(920,470,140,'#5fae8a',1)+pineS(830,480,90,'#6fbf9a',1);
    s+=`<path d="M0 540 Q500 500 1024 550 V768 H0Z" fill="#ffffff"/>`;
    for(let i=0;i<8;i++){const x=R()*1024,y=580+R()*170;s+=`<ellipse cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" rx="${(40+R()*50).toFixed(0)}" ry="10" fill="#e2f0fb"/>`;}
    for(let i=0;i<30;i++)s+=`<circle cx="${(R()*1024).toFixed(0)}" cy="${(R()*520).toFixed(0)}" r="${(2+R()*3).toFixed(1)}" fill="#fff"/>`;
  }else if(id==='woods'){
    s+=grad('#24224f','#5a4a9a')+`<circle cx="840" cy="130" r="80" fill="#fff6c9" opacity=".25"/><circle cx="840" cy="130" r="56" fill="#fff6c9"/><circle cx="822" cy="118" r="10" fill="#f0e3a8"/><circle cx="858" cy="146" r="7" fill="#f0e3a8"/>`;
    for(let i=0;i<46;i++)s+=star4((R()*1024)|0,(R()*380)|0,3+R()*4,'#fff',i%3?'':'twk',(R()*2).toFixed(1));
    s+=`<path d="M0 440 Q260 380 520 430 T1024 410 V768 H0Z" fill="#3a3478"/>`;
    [[70,470,70],[210,450,50],[360,460,40],[640,455,44],[770,465,56],[960,470,72]].forEach(q=>{s+=treeS(q[0],q[1],q[2],'#2c2860','#241f4f');});
    s+=`<path d="M0 540 Q500 500 1024 550 V768 H0Z" fill="#4a4390"/>`;
    for(let i=0;i<22;i++){const x=R()*1024,y=560+R()*190;s+=`<circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="4" fill="#fff27a" opacity=".8"/><circle cx="${x.toFixed(0)}" cy="${y.toFixed(0)}" r="10" fill="#fff27a" opacity=".2"/>`;}
  }else if(id==='cloud'){
    s+=grad('#ffd6ec','#bfe6ff','#ded4ff');
    ['#ff8fb3','#ffc46b','#fff27a','#8fe39a','#7fc8f0','#b58cff'].forEach((c,i)=>{s+=`<circle cx="512" cy="860" r="${690-i*26}" fill="none" stroke="${c}" stroke-width="26" opacity=".85"/>`;});
    for(let i=0;i<24;i++)s+=star4((R()*1024)|0,(R()*500)|0,4+R()*5,'#fff',i%2?'twk':'',(R()*2).toFixed(1));
    s+=cloudS(140,250,1.3)+cloudS(880,300,1.2)+cloudS(520,170,.9,'#fff',.9);
    for(let x=0;x<1100;x+=120)s+=cloudS(x,700+((x/120)%2)*20,2.2);s+=`<rect y="710" width="1024" height="60" fill="#fff"/>`;
  }else if(id==='map'){
    s+=grad('#bfe9ff','#e6f7ff')+`<path d="M40 330 Q30 150 250 130 Q420 60 600 130 Q780 70 950 110 Q1010 300 980 520 Q900 610 700 580 Q500 640 300 590 Q60 600 40 330Z" fill="#fff3c4" stroke="#fff" stroke-width="14"/>`;
    s+=`<path d="M70 340 Q70 180 260 160 Q420 100 600 160 Q780 110 930 140 Q980 300 950 500 Q890 570 700 550 Q500 600 300 560 Q90 570 70 340Z" fill="#d3f2bd"/>`;
  }
  return `<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">${s}</svg>`;
}
function pick2(R,a){return a[Math.floor(R()*a.length)];}


