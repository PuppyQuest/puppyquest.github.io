/* ================================================================
   Summer Beach Party (Pup Seasons 4, 26 Nov 2026; claude/summer-beach-design.md): how the pups look.
   - Breeze (Wetterhoun) and Sorbet (Peruvian Inca Orchid), the two secret season pups;
   - a summer fact for each of the 119 summer pups (stable science, written 26 Nov 2026);
   - summer kits per island (sun hats, sunglasses, snorkels, swim rings, life jackets...),
     one full costume per island, the crab suit for the Spa;
   - new pieces: bucket hat, swim ring, beach ball, ice lolly (2D and 3D where they show);
   - window.SEASONSPEC is wrapped: in Summer Beach Party every pup in 3D wears its summer outfit,
     and in 2D any copy made with SBLOOK.sp(p).
   ================================================================ */
(function(){
const PS=window.PSTYLE,K=INK,PI=Math.PI;
const ol=w=>`stroke="${K}" stroke-width="${w||2.6}" stroke-linejoin="round" stroke-linecap="round"`;
const st=(c,w,o)=>`fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${o==null?1:o}"`;
const GOLD='#ffd23f',SEA='#2fb3d8',SAND='#f2d896',CORAL='#ff7f6a';
const HATC=['#ff7fb8','#ffd23f','#5ab8ff','#8ae05a','#ff8a3c','#b88aff'];

/* ---------------- the two secret season pups ---------------- */
const SPUPS={
 breeze:{id:'breeze',name:'Breeze',breed:'Wetterhoun',area:'harbour',island:'rescue',type:'water',pitch:1.1,season:'sb',
   look:{fur:'#4a2e24',ear:'#3a2418',ears:'floppy',fluffy:true,muzzle:'#4a2e24',belly:'#ffffff',paw:'#ffffff',tail:'curl',collar:'#2fb3d8',acc:[]},
   fact:'The Wetterhoun is a rare curly dog from Friesland in the Netherlands. Its name means water dog, and its tight curls help keep it warm and dry when it swims.',
   hint:'Breeze is somewhere near the Sandcastle Contest at the Harbour.'},
 sorbet:{id:'sorbet',name:'Sorbet',breed:'Peruvian Inca Orchid',area:'village',island:'village',type:'fire',pitch:1.25,season:'sb',
   look:{fur:'#d99a7a',ears:'pointy',earBig:true,muzzle:'#d99a7a',belly:'#e8b49a',tail:'thin',spots:true,hw:42,hh:52,eyeWhite:true,collar:'#ff7fb8',acc:[]},
   fact:'The Peruvian Inca Orchid is a dog from Peru that often has no fur at all. With bare skin, it needs shade and dog-safe sun cream in strong sunshine.',
   hint:'Sorbet is waiting near the Beach Party in the village.'}};
if(window.CARDS&&CARDS.BREEDS){if(!CARDS.BREEDS.Wetterhoun)CARDS.BREEDS.Wetterhoun={sz:'m',spd:7,brn:8,cud:7,brv:9,g:'splash'};if(!CARDS.BREEDS['Peruvian Inca Orchid'])CARDS.BREEDS['Peruvian Inca Orchid']={sz:'m',spd:9,brn:7,cud:8,brv:6,g:'zoom'};}
if(PS&&PS.COAT){PS.COAT.Wetterhoun='curly';PS.COAT['Peruvian Inca Orchid']='smooth';}

/* ---------------- summer facts, one per pup, in island order (I.pups then the sparkly pup) ---------------- */
const SF={
 meadow:['Bees visit flowers all summer long, collecting nectar to make honey.',
  'Young sunflowers turn to follow the Sun across the sky. Grown-up sunflowers mostly face east.',
  'In summer the days are long. In Britain the longest day of the year is around 21 June.',
  'Dogs cool down by panting, because they can only sweat a tiny bit, through the pads on their paws.',
  'Grasshoppers make their chirping song by rubbing their back legs against their wings.',
  'Butterflies taste with their feet! They stand on a flower to find out if it is good to eat.',
  'Strawberries wear their seeds on the outside, about 200 on each one.',
  'Dragonflies were zooming about long before the dinosaurs.',
  'Frogs can breathe through their skin, as well as with their lungs.',
  'Swifts can stay up in the air for months, eating and even sleeping as they fly.',
  'A ladybird\'s bright spots warn birds that it tastes nasty.',
  'On hot days, always leave out fresh water for pets, and never leave a dog in a hot car.',
  'Thunderstorms happen most often in summer, when warm, damp air rises up fast.'],
 snowy:['On very high mountains, some snow stays all summer long.',
  'Snow reflects lots of sunlight, so mountain climbers wear sunglasses even in summer.',
  'The higher you climb, the colder it gets: about 6 degrees colder for every kilometre up.',
  'Mountain flowers bloom in a rush, because summer up high is very short.',
  'Glaciers are rivers of ice that slide very slowly downhill.',
  'Arctic foxes swap their white winter coat for a brown summer coat when the snow melts.',
  'Near the North Pole the Sun does not set in midsummer, so it stays light all night.',
  'In Iceland in midsummer, the Sun hardly sets at all.',
  'Melting snow on the mountains fills the rivers in summer.',
  'Marmots sunbathe on warm rocks in summer, then hibernate all winter.',
  'Your shadow is shortest at midday, when the Sun is highest in the sky.',
  'Ice floats, because it is a little lighter than the same amount of water.',
  'A snowball melts faster in the sunshine than in the shade, because sunlight carries heat.'],
 reef:['The sea is salty because rain washes tiny bits of salt out of rocks, and rivers carry it down to the sea.',
  'It is easier to float in the sea than in a swimming pool, because salty water holds you up better.',
  'Giant kelp can grow more than half a metre in a single day!',
  'Fish breathe with gills, which take the oxygen they need out of the water.',
  'Scallops have lots of tiny eyes all round the edge of their shell.',
  'Starfish have no blood. They pump sea water round their bodies instead.',
  'Coral reefs are built by tiny animals called coral polyps.',
  'Barnacles glue themselves head first onto rocks and boats, and kick food into their mouths with their feet.',
  'Sea turtles come back to the beach to lay their eggs in the warm sand.',
  'Dolphins sleep with only half of their brain at a time, so they can keep swimming.',
  'Seahorses are fish, even though they swim standing up.',
  'Puffins can flap their wings about 400 times a minute.',
  'Tiny sea plants called phytoplankton make lots of the oxygen we breathe.'],
 ninja:['In Japan, people hang glass wind chimes called fūrin in summer. Their tinkle is meant to help you feel cool.',
  'Watermelons are more than nine tenths water.',
  'Folding fans were invented in Japan more than a thousand years ago.',
  'Bamboo is a giant grass, and some kinds can grow almost a metre in one day.',
  'Kites have been flown in China for more than 2,000 years.',
  'In Japan, many summer festivals end with big firework shows.',
  'Sweat cools you down: as it dries on your skin, it takes heat away with it.',
  'Cicadas sing loudly in Japanese summers. The males click with drum-like parts on their bodies.',
  'Thunder is the sound of air that lightning has heated, spreading out very fast.',
  'Light travels faster than sound, so you see lightning before you hear the thunder.',
  'Shade under a tree feels cool, because the leaves block the sunlight and give off water into the air.',
  'Morning glory flowers open in the morning and close by the afternoon. They are a Japanese summer favourite.',
  'White clothes reflect sunlight, so they keep you cooler on a sunny day than dark ones.'],
 number:['Most beaches have 2 high tides and 2 low tides every day.',
  'High tides come about every 12 hours and 25 minutes.',
  'A starfish usually has 5 arms, so 3 starfish have 15 arms.',
  'A crab has 10 legs, counting its 2 claws.',
  'Summer in Britain is June, July and August: 30 add 31 add 31 makes 92 days.',
  'The Earth takes about 365 days to go round the Sun. That is one year.',
  'A sundial uses the shadow of the Sun to tell the time.',
  'Water freezes at 0 degrees and boils at 100 degrees Celsius.',
  'A bucket of dry sand is heavier than the same bucket full of water.',
  'Honeycomb cells are hexagons, with 6 sides each.',
  'The Sun is about 150 million kilometres away from the Earth.',
  'Light from the Sun takes about 8 minutes to reach us.',
  'Scientists think there are more stars in space than grains of sand on all the beaches on Earth.'],
 gadget:['Solar panels turn sunlight into electricity.',
  'A fridge keeps food cold by pumping the heat out from inside it.',
  'A fan does not make the air colder. It cools you by moving air over your skin.',
  'Sun cream protects your skin from the Sun\'s ultraviolet light, which you cannot see.',
  'Good sunglasses block the Sun\'s ultraviolet light to protect your eyes.',
  'Wind turbines turn moving air into electricity.',
  'A thermometer tells you how hot or cold something is.',
  'Dark colours soak up more sunlight than light colours, so a black car gets hotter in the sun.',
  'Metal slides and seats can get very hot in the sun, so check before you sit!',
  'Hot air rises, which is why hot-air balloons float up into the sky.',
  'Water parks use pumps to push water up to the top of the slides.',
  'Robots can explore deep under the sea, where it is too deep for people to dive.',
  'The Sun is a giant ball of hot gas, and its light gives energy to nearly all life on Earth.'],
 rescue:['On beaches with lifeguards, swim between the red and yellow flags, where they can see you.',
  'A red flag on the beach means danger: do not go in the water.',
  'If you get into trouble in the water, float on your back like a starfish and shout for help.',
  'In an emergency by the sea in Britain, call 999 and ask for the Coastguard.',
  'On hot days, wear a sun hat and sun cream, and drink plenty of water.',
  'Lifeguards use rescue boards and floats to reach swimmers quickly.',
  'Rip currents are strong currents that pull away from the beach. Lifeguards look out for them.',
  'Some gulls stamp their feet on the grass to make worms come up.',
  'Grey seals can stay underwater for more than 10 minutes.',
  'Rock pools stay full of sea water when the tide goes out, and they are full of tiny creatures.',
  'Always check the tide times before exploring a beach, so the sea cannot cut you off.',
  'Sand gets very hot in the sunshine, so wear something on your feet on a hot beach.',
  'Lifeboat crews in Britain, most of them volunteers, have saved more than 140,000 lives since 1824.'],
 dino:['Fossils are often found on beaches, where the waves wear away the cliffs.',
  'Mary Anning found famous fossils on the beach at Lyme Regis, more than 200 years ago.',
  'When the dinosaurs lived, the Earth was warmer than it is today.',
  'Crocodiles cool down by lying in the sun with their mouths wide open.',
  'Ammonites were sea creatures with spiral shells, related to squid and octopuses.',
  'Some sand is made of tiny bits of broken shells and coral.',
  'Elephants spray water and roll in mud to keep cool in hot sunshine.',
  'Giant sea reptiles called ichthyosaurs swam in the sea while dinosaurs walked on land.',
  'Lizards bask in the sun to warm up, because their bodies cannot make their own heat.',
  'Dinosaur footprints have been found in old beach and lake mud that slowly turned to stone.',
  'Most sand is made of tiny bits of rock, worn down by water and wind over a very long time.',
  'Horseshoe crabs have been around for more than 400 million years, longer than the dinosaurs.',
  'Amber is old tree resin that went hard, and pieces of it wash up on the beaches of the Baltic Sea.'],
 planet:['The Moon\'s gravity pulls on the sea, and that makes the tides.',
  'The Sun pulls on the sea too. When the Sun and Moon line up, we get extra big tides called spring tides.',
  'Summer happens because the Earth is tilted, so our half of the world leans towards the Sun.',
  'When it is summer in Britain, it is winter in Australia.',
  'A day on Mars is only about 40 minutes longer than a day on Earth.',
  'Scientists think Europa, a moon of Jupiter, has a salty ocean hidden under its ice.',
  'Saturn\'s rings are made of chunks of ice and rock.',
  'Halley\'s Comet comes back near the Earth about every 76 years.',
  'The Sun is a star, the closest star to the Earth.',
  'Never look straight at the Sun, even with sunglasses on.',
  'Astronauts on the space station see about 16 sunrises every day.',
  'There is no wind on the Moon, so the astronauts\' footprints there could last for millions of years.',
  'Titan, Saturn\'s biggest moon, has lakes and seas, but they are full of liquid methane, not water.']};
const FACT={breeze:SPUPS.breeze.fact,sorbet:SPUPS.sorbet.fact};
ISLANDS.forEach(I=>{const L=SF[I.id];if(!L)return;I.pups.concat(I.bonus||[]).forEach((p,i)=>{if(L[i])FACT[p.id]=L[i];});});

/* ---------------- new pieces (2D) ---------------- */
const shell2D=(x,y,s,col)=>{s=s||1;col=col||'#ffd2a8';return `<path d="M${x-10*s} ${y+6*s} Q${x-12*s} ${y-8*s} ${x} ${y-10*s} Q${x+12*s} ${y-8*s} ${x+10*s} ${y+6*s} Q${x} ${y+12*s} ${x-10*s} ${y+6*s} Z" fill="${col}" ${ol(1.6)}/><path d="M${x} ${y+8*s} L${x} ${y-8*s} M${x} ${y+8*s} L${x-6*s} ${y-6*s} M${x} ${y+8*s} L${x+6*s} ${y-6*s}" ${st('#c8865a',1.2,1)}/>`;};
const star2D=(x,y,r,col)=>{let d='';for(let i=0;i<10;i++){const a=-PI/2+i*PI/5,rr=i%2?r*.5:r;d+=(i?'L':'M')+(x+Math.cos(a)*rr).toFixed(1)+' '+(y+Math.sin(a)*rr).toFixed(1);}return `<path d="${d}Z" fill="${col||'#ff8a3c'}" ${ol(1.6)}/>`;};
const ringSVG=(x,y,rx,ry,c1,c2)=>`<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="none" stroke="${K}" stroke-width="${ry*.9+4}"/><ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="none" stroke="${c1}" stroke-width="${ry*.9}"/>`+
  `<ellipse cx="${x}" cy="${y}" rx="${rx}" ry="${ry}" fill="none" stroke="${c2}" stroke-width="${ry*.9}" stroke-dasharray="${(rx*.5).toFixed(1)} ${(rx*.5).toFixed(1)}"/>`;
if(PS){
 Object.assign(PS.HAT,{
  buckethat(c,col){const cx=c.cx,yb=c.cy-c.hh*.52,hw=c.hw;col=col||'#5ab8ff';
   return `<path d="M${cx-hw*1.08} ${yb+8} Q${cx} ${yb+20} ${cx+hw*1.08} ${yb+8} L${cx+hw*.78} ${yb-6} Q${cx} ${yb+2} ${cx-hw*.78} ${yb-6} Z" fill="${col}" ${ol(3)}/>`+
    `<path d="M${cx-hw*.72} ${yb-4} Q${cx-hw*.7} ${yb-hw*.62} ${cx} ${yb-hw*.66} Q${cx+hw*.7} ${yb-hw*.62} ${cx+hw*.72} ${yb-4} Q${cx} ${yb+4} ${cx-hw*.72} ${yb-4} Z" fill="${col}" ${ol(3)}/>`+
    `<path d="M${cx-hw*.7} ${yb-10} Q${cx} ${yb-2} ${cx+hw*.7} ${yb-10}" ${st('#ffffff',5,1)}/>`+shell2D(cx+hw*.38,yb-hw*.32,.7,'#ffe0c0');}});
 PS.BACK.swimring=c=>{const bw=c.bw,bh=c.bh,by=c.by;return ringSVG(100,by+bh*.1,bw+16,14,'#ff6a6a','#ffffff');};
 Object.assign(PS.PROP,{
  beachball:`<circle cx="0" cy="-2" r="17" fill="#ffffff" ${ol(2.6)}/><path d="M0 -19 Q-12 -2 0 15 Z" fill="#e8423a"/><path d="M0 -19 Q12 -2 0 15 Z" fill="#5ab8ff"/><path d="M-17 -2 Q0 -10 17 -2 Q0 6 -17 -2 Z" fill="#ffd23f" opacity=".9"/><circle cx="0" cy="-2" r="17" fill="none" ${ol(2.6)}/><circle cx="-6" cy="-9" r="3" fill="#fff" opacity=".8"/>`,
  icelolly:`<rect x="-3" y="2" width="6" height="18" rx="2" fill="#e6c08a" ${ol(2)}/><path d="M-11 4 V-22 Q-11 -32 0 -32 Q11 -32 11 -22 V4 Z" fill="#ff7fb8" ${ol(2.6)}/><path d="M-11 -8 H11" ${st('#ffd23f',6,1)}/><path d="M-11 -18 H11" ${st('#ff8a3c',6,1)}/>`,
  swimring:ringSVG(0,4,17,8,'#ff6a6a','#ffffff')});
}
/* ---------------- new pieces (3D) ---------------- */
if(PS){
 Object.assign(PS.H3,{buckethat(h,col){col=col||'#5ab8ff';mk('cyl',col,.64,.05,.6,0,.33,0,h);mk('cyl',col,.42,.24,.4,0,.46,0,h);mk('cyl','#ffffff',.43,.06,.41,0,.38,0,h);}});
 PS.K3.swimring=(b,c)=>{const r=mk('tor','#ff6a6a',.62*c.bw+.18,.62*c.bw+.18,.5,0,.62,0,b);r.rotation.x=PI/2;r.scale.z=.55;};
}

/* ---------------- full costumes ---------------- */
const SC={
 lolly:{n:'Ice Lolly',body:'#ff7fb8',belly:'#ffd23f',paw:'#ff8a3c',line:'NAME is a stripy ice lolly. Lick, lick!'},
 shark:{n:'Shark',body:'#7a98b8',belly:'#ffffff',paw:'#5a7898',line:'NAME is a friendly shark. Doo doo, doo doo!'},
 sbcrab:{n:'Crab',body:'#e8503a',belly:'#ff9a7a',paw:'#c8402a',line:'NAME is a little crab, scuttling sideways!'},
 sbstar:{n:'Starfish',body:'#ff8a3c',belly:'#ffb07a',paw:'#e86a2a',line:'NAME is a starfish with five arms!'},
 sbmelon:{n:'Watermelon',body:'#3fae5a',belly:'#ff6a7a',paw:'#2a7a3a',line:'NAME is a juicy slice of watermelon!'},
 sbsun:{n:'Sunshine',body:'#ffd23f',belly:'#fff0a0',paw:'#ff9a2a',line:'NAME is a ray of sunshine!'}};
const SKEYS=Object.keys(SC),isS=k=>SKEYS.indexOf(k)>=0;
for(const k in SC){SC[k].sb=true;COS[k]=SC[k];}
if(typeof COS_ICON!=='undefined')Object.assign(COS_ICON,{lolly:'🍭',shark:'🦈',sbcrab:'🦀',sbstar:'⭐',sbmelon:'🍉',sbsun:'☀️'});
const _c2=cos2D;cos2D=function(w,c){let s=_c2(w,c);const L=c.L,Kc=L.cos;if(!isS(Kc))return s;
  const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,yb=cy-hh*.42;
  const dome=(col,lo)=>`<path d="M${cx-hw*.94} ${lo} Q${cx-hw*.94} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.94} ${cy-hh*1.2} ${cx+hw*.94} ${lo} Z" fill="${col}" ${S}/>`;
  if(w==='behind'){
    if(Kc==='shark')s+=`<path d="M${100-bw*.2} ${by-bh+2} L${100+bw*.15} ${by-bh-34} L${100+bw*.55} ${by-bh+2} Z" fill="#7a98b8" ${ol(3)}/>`;
    if(Kc==='sbcrab')for(const g of[-1,1]){const x=100+g*(bw+16),y=by-bh*.2;s+=`<path d="M${x-g*12} ${y+10} Q${x} ${y} ${x+g*4} ${y-14}" ${st(K,9,1)}/><path d="M${x-g*12} ${y+10} Q${x} ${y} ${x+g*4} ${y-14}" ${st('#e8503a',5,1)}/>`+
      `<path d="M${x+g*4} ${y-14} q${g*18} -14 ${g*8} -30 q${-g*4} 10 ${-g*12} 12 q${g*10} -2 ${g*12} 6 q${-g*8} 8 ${-g*8} 12 Z" fill="#e8503a" ${ol(2.6)}/>`;}
    if(Kc==='sbstar'){let d='';for(let i=0;i<10;i++){const a=-PI/2+i*PI/5,r=i%2?bw*.55:bw+30;d+=(i?'L':'M')+(100+Math.cos(a)*r).toFixed(1)+' '+(by+Math.sin(a)*r).toFixed(1);}s+=`<path d="${d}Z" fill="#ff8a3c" ${ol(3)}/>`;}
    if(Kc==='sbsun')for(let i=0;i<12;i++){const a=i/12*PI*2,x1=cx+Math.cos(a)*hw*1.05,y1=cy-hh*.3+Math.sin(a)*hh*1.05,x2=cx+Math.cos(a)*hw*1.45,y2=cy-hh*.3+Math.sin(a)*hh*1.45;s+=`<path d="M${x1.toFixed(1)} ${y1.toFixed(1)} L${x2.toFixed(1)} ${y2.toFixed(1)}" ${st(K,10,1)}/><path d="M${x1.toFixed(1)} ${y1.toFixed(1)} L${x2.toFixed(1)} ${y2.toFixed(1)}" ${st('#ffb020',6,1)}/>`;}}
  if(w==='bodyClip'){
    if(Kc==='lolly')for(let q=-3;q<=3;q++)s+=`<rect x="${100-bw}" y="${by+q*16-5}" width="${bw*2}" height="9" fill="${['#ff7fb8','#ffd23f','#ff8a3c'][(q+3)%3]}"/>`;
    if(Kc==='shark')s+=`<path d="M${100-bw*.6} ${by-bh*.3} l6 6 l6 -6 M${100+bw*.3} ${by-bh*.3} l6 6 l6 -6" ${st('#5a7898',2.4,1)}/>`;
    if(Kc==='sbcrab')[[-.45,-.3],[.35,-.45],[.5,.3],[-.2,.45]].forEach(q=>{s+=`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="4.5" fill="#ff9a7a"/>`;});
    if(Kc==='sbstar')[[-.5,-.3],[.3,-.45],[.55,.25],[-.25,.4],[0,0],[.1,.5]].forEach(q=>{s+=`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="4" fill="#ffd2a8" ${ol(1.2)}/>`;});
    if(Kc==='sbmelon')for(const t of[-.6,-.2,.2,.6])s+=`<path d="M${100+t*bw} ${by-bh} Q${100+t*bw*1.25} ${by} ${100+t*bw} ${by+bh}" ${st('#2a7a3a',5,1)}/>`;
    if(Kc==='sbsun')s+=`<circle cx="${bcx}" cy="${by}" r="${Math.min(bw,bh)*.55}" fill="#ffb020" opacity=".55"/>`;}
  if(w==='top'){
    if(Kc==='lolly')s+=dome('#ff7fb8',yb)+`<path d="M${cx-hw*.8} ${cy-hh*.98} H${cx+hw*.8}" ${st('#ffd23f',7,1)}/><rect x="${cx-5}" y="${cy-hh*1.62}" width="10" height="${hh*.44}" rx="4" fill="#e6c08a" ${ol(2.4)}/>`;
    if(Kc==='shark')s+=dome('#7a98b8',yb)+`<path d="M${cx-4} ${cy-hh*1.15} L${cx+hw*.25} ${cy-hh*1.72} L${cx+hw*.5} ${cy-hh*1.06} Z" fill="#7a98b8" ${ol(3)}/>`+
      `<path d="M${cx-hw*.86} ${yb-3} ${Array.from({length:8},(v,i)=>`l${(hw*.215).toFixed(1)} ${i%2?-9:9}`).join(' ')}" fill="#ffffff" ${ol(2)}/>`;
    if(Kc==='sbcrab')s+=dome('#e8503a',yb)+[-1,1].map(g=>{const x=cx+g*hw*.42,y=cy-hh*1.1;return `<path d="M${x} ${y} L${x+g*4} ${y-24}" ${st(K,6,1)}/><path d="M${x} ${y} L${x+g*4} ${y-24}" ${st('#e8503a',3,1)}/><circle cx="${x+g*4}" cy="${y-28}" r="8" fill="#ffffff" ${ol(2.4)}/><circle cx="${x+g*5}" cy="${y-28}" r="4" fill="${K}"/>`;}).join('');
    if(Kc==='sbstar')s+=dome('#ff8a3c',yb)+[[-.45,-1.0],[.4,-1.08],[0,-1.25],[-.1,-.95]].map(q=>`<circle cx="${cx+q[0]*hw}" cy="${cy+q[1]*hh}" r="4.5" fill="#ffd2a8" ${ol(1.2)}/>`).join('');
    if(Kc==='sbmelon')s+=dome('#ff6a7a',yb)+`<path d="M${cx-hw*.94} ${yb} Q${cx} ${yb+6} ${cx+hw*.94} ${yb}" ${st('#3fae5a',10,1)}/><path d="M${cx-hw*.94} ${yb-7} Q${cx} ${yb-1} ${cx+hw*.94} ${yb-7}" ${st('#e8fff0',4,1)}/>`+
      [[-.5,-1.0],[0,-1.1],[.5,-1.0],[-.25,-.85],[.25,-.85]].map(q=>`<ellipse cx="${cx+q[0]*hw}" cy="${cy+q[1]*hh}" rx="3" ry="5" fill="#26232e"/>`).join('');
    if(Kc==='sbsun')s+=dome('#ffd23f',yb)+`<path d="M${cx-hw*.4} ${cy-hh*.98} Q${cx} ${cy-hh*1.12} ${cx+hw*.4} ${cy-hh*.98}" ${st('#ffb020',4,1)}/>`;}
  return s;};
const _c3=cos3D;cos3D=function(L,b,h,c){const Kc=L.cos;if(!isS(Kc))return _c3(L,b,h,c);
  const bw=c.bw,lg=c.lg,helm=col=>{const hm=mk('hemi',col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;return hm;};
  switch(Kc){
   case'lolly':helm('#ff7fb8');mk('cyl','#e6c08a',.06,.5,.06,0,.78,-.05,h);mk('cyl','#ffd23f',.63*bw,.12,.72*lg,0,.68,0,b);break;
   case'shark':helm('#7a98b8');{const f=mk('cone','#7a98b8',.12,.5,.26,0,.82,-.1,h);f.rotation.x=-.3;}mk('cone','#7a98b8',.1,.45,.3,0,1.3,-.1*lg,b);break;
   case'sbcrab':helm('#e8503a');[-1,1].forEach(s=>{mk('cyl','#e8503a',.03,.3,.03,s*.2,.72,.12,h);mk('sph','#ffffff',.09,.09,.09,s*.2,.9,.12,h);mk('sph','#e8503a',.2,.14,.24,s*(.5*bw+.25),.85,.3*lg,b);});break;
   case'sbstar':helm('#ff8a3c');for(let i=0;i<5;i++){const a=i/5*PI*2;const cn=mk('cone','#ff8a3c',.12,.34,.08,Math.cos(a)*.42,.3,Math.sin(a)*.42,h);cn.rotation.z=-Math.cos(a)*1.3;cn.rotation.x=Math.sin(a)*1.3;}break;
   case'sbmelon':helm('#ff6a7a');mk('tor','#3fae5a',.62,.62,.6,0,.1,-.02,h).rotation.x=PI/2-.32;break;
   case'sbsun':helm('#ffd23f');for(let i=0;i<8;i++){const a=i/8*PI*2,cn=mk('cone','#ffb020',.07,.26,.07,Math.cos(a)*.66,.25+Math.sin(a)*.5,-.05,h);cn.rotation.z=a-PI/2;}break;}};

/* ---------------- who wears what in summer ---------------- */
const NUMS={digit:'1',dot:'2',doodle:'10',zero:'0',ruler:'12',paddle:'5',cube:'8',prism:'3',pie:'π',seven:'7',infinity:'∞',plus:'+',pretzel:'6'};
const KIT={
 meadow:(i,p)=>{const k=i%3;return {h:k===0?['strawhat',HATC[i%6]]:k===1?['sunhat',HATC[(i+2)%6]]:['buckethat',HATC[(i+4)%6]],g:i%2?['sun',['#26232e','#e8423a','#5ab8ff'][i%3]]:null,n:k===2?[['lei']]:null,p:[['bucket','spade','icelolly','beachball'][i%4]],drop:['scarf','bow','flower']};},
 snowy:(i,p)=>({h:i%2?['visor']:['buckethat',HATC[i%6]],g:['sun',i%3?'#26232e':'#3a4ab8'],drop:['scarf','mittens']}),
 reef:(i,p)=>({g:i%3===2?null:['snorkel'],k:i%2?['swimring']:null,f:i%3===2?['flippers',HATC[i%6]]:null,keep:['bubbles'],drop:['shellneck']}),
 ninja:(i,p)=>({h:['headband',['#ff7fb8','#5ab8ff','#ffd23f','#8ae05a'][i%4]],g:i%2?['sun']:null,p:['fan'],drop:['scarf','bow']}),
 number:(i,p)=>({h:['visor'],n:[['num',GOLD,{num:NUMS[p.id]||String(i+1)}]],p:i%2?['bucket']:null,drop:['scarf','flower','bow']}),
 gadget:(i,p)=>({h:i%2?['propeller']:null,g:['pixel'],p:i%2?null:['fan'],drop:['scarf','bow']}),
 rescue:(i,p)=>({h:['visor'],b:i%2?['lifevest']:null,n:[['whistle']],p:i%2?null:['rescuetube'],drop:['scarf','glow']}),
 dino:(i,p)=>({h:i%2?['explorer']:['pith'],g:['sun'],p:[['spade','bucket'][i%2]]}),
 planet:(i,p)=>({space:{trim:GOLD},g:['sun'],k:i%2?['swimring']:null})};
const COSTUME={meadow:'lolly',snowy:'snowman',reef:'shark',ninja:'sbcrab',number:'sbstar',gadget:'robot',rescue:'pirate',dino:'sbmelon',planet:'sbsun'};
const SBOUT={breeze:{h:['buckethat','#2fb3d8'],k:['swimring']},sorbet:{h:['sunhat','#ff7fb8'],g:['sun','#e8423a'],n:[['lei']]}};
const CWHO={};
ISLANDS.forEach(I=>{const f=KIT[I.id];if(!f)return;const cp=I.pups.find((p,i)=>i>=4&&!(p.look&&p.look.ninja));I.pups.concat(I.bonus||[]).forEach((p,i)=>{const cs=p===cp&&COSTUME[I.id];if(cs)CWHO[p.id]=cs;SBOUT[p.id]=cs?{cos:cs}:f(i,p);const S=SBOUT[p.id];for(const k in S)if(S[k]==null)delete S[k];});});
/* the unicorns in summer: a sun hat, sunglasses and a flower garland */
const UNI={h:['sunhat','#ff7fb8'],g:['sun','#26232e'],n:[['lei']]};
const isPup=p=>!!(p&&p.id&&(PUPS[p.id]||SPUPS[p.id]));
const sOn=()=>!!(typeof state!=='undefined'&&state&&state.season==='sb');
const s0=window.SEASONSPEC;
window.SEASONSPEC=function(p,is2D){const prev=()=>s0?s0(p,is2D):null;if(!p||!p.id||p.guest)return prev();
  if(p.sb){if(p.uni)return UNI;if(!isPup(p))return null;const R=PUPS[p.id]||SPUPS[p.id];if(R.breed!==p.breed)return null;return SBOUT[p.id]||null;}
  if(!is2D&&sOn()&&!p.xmas&&!p.glow&&!p.hw){if(p.uni||!isPup(p))return null;const R=PUPS[p.id]||SPUPS[p.id];if(R.breed!==p.breed)return null;return SBOUT[p.id]||null;}
  return prev();};

/* a summer copy of a pup, for 2D pictures and cards */
const sp=p=>p?Object.assign({},p,{sb:true}):p;
window.SBLOOK={SPUPS,FACT,SBOUT,sp,UNI,COSTUME,CWHO,GOLD,SEA,SAND,CORAL,shell2D,star2D,ringSVG};
})();
