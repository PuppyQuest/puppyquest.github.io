/* ================================================================
   Night Glow (Pup Seasons 2, 25 Nov 2026; claude/night-glow-design.md): how the pups look.
   - Foxfire (Finnish Spitz) and Dusk (Ibizan Hound), the two secret season pups;
   - a night fact for each of the 119 Night Glow pups (stable science, written 25 Nov 2026);
   - glow outfits from each island's kit, one full costume per island, star pyjamas for the Spa;
   - new pieces: night cap, firefly antennae, headlamp, lantern hat, star pyjamas, circuit top,
     glow collar, aurora scarf, glow pearls, star cape, LED goggles (2D and 3D);
   - window.SEASONSPEC is wrapped: in Night Glow every pup in 3D wears its glow outfit, and in
     2D any copy made with GLOOK.gp(p).
   ================================================================ */
(function(){
const PS=window.PSTYLE,K=INK,PI=Math.PI;
const ol=w=>`stroke="${K}" stroke-width="${w||2.6}" stroke-linejoin="round" stroke-linecap="round"`;
const st=(c,w,o)=>`fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${o==null?1:o}"`;
const NAVY='#2b3a7a',GOLD='#ffd23f',NE=['#c8ff4a','#5cf0ff','#ff7fe0','#ffd23f','#a98bff','#5cffb0'],PJ=['#2b3a7a','#5a3a8a','#1f6a8a','#8a2f5a','#2f6a4a'];

/* ---------------- the two secret season pups ---------------- */
const GPUPS={
 foxfire:{id:'foxfire',name:'Foxfire',breed:'Finnish Spitz',area:'eagle',island:'snowy',type:'snow',pitch:1.15,season:'glow',
   look:{fur:'#d9752e',ear:'#c4621f',ears:'pointy',fluffy:true,muzzle:'#f3d2a8',belly:'#f6dcb6',paw:'#f3d2a8',tail:'curl',collar:'#5cffb0',acc:[]},
   fact:'The Finnish Spitz is the fox-red national dog of Finland. In Finnish the Northern Lights are called revontulet, "fox fires", from an old story about a fox whose tail swept sparks up into the sky.',
   hint:'Foxfire is watching the Northern Lights on Eagle Peak.'},
 dusk:{id:'dusk',name:'Dusk',breed:'Ibizan Hound',area:'village',island:'village',type:'star',pitch:1.0,season:'glow',
   look:{fur:'#c45a32',ear:'#b04a28',ears:'bat',muzzle:'#f6efe6',belly:'#fbf6ef',paw:'#fbf6ef',tail:'thin',collar:GOLD,acc:[],tail2:0},
   fact:'Ibizan Hounds are ancient hunting dogs from the islands of Spain. Their huge upright ears catch the tiniest sounds, and they can leap very high from standing still.',
   hint:'Dusk is somewhere near the telescope at the Star Party.'}};
if(window.CARDS&&CARDS.BREEDS){if(!CARDS.BREEDS['Finnish Spitz'])CARDS.BREEDS['Finnish Spitz']={sz:'m',spd:7,brn:7,cud:6,brv:8,g:'yodel'};if(!CARDS.BREEDS['Ibizan Hound'])CARDS.BREEDS['Ibizan Hound']={sz:'l',spd:9,brn:6,cud:6,brv:7,g:'zoom'};}
if(PS&&PS.COAT)PS.COAT['Finnish Spitz']='double';

/* ---------------- night facts, one per pup, in island order (I.pups then the sparkly pup) ---------------- */
const NF={
 meadow:['Fireflies are not flies at all. They are beetles, and they make their light inside their tails.',
  'A firefly\'s light is called cold light, because it gives off almost no heat.',
  'Every kind of firefly flashes its own pattern, like a secret code, so it can find its friends in the dark.',
  'Glow-worms are beetles too. On summer nights in Britain, the female glow-worm glows so that a male can find her.',
  'Owls can\'t move their eyes, so they turn their whole head instead, nearly all the way round.',
  'Barn owls fly almost silently, because their feathers have soft, fringed edges.',
  'Hedgehogs come out at night to snuffle for beetles and worms, and can walk a mile or more in one night.',
  'Some flowers, like evening primrose, open in the evening, and moths visit them in the dark.',
  'Crickets chirp by rubbing their wings together, and they chirp faster on warm nights.',
  'Badgers live in tunnels called setts, and come out after dark to look for earthworms.',
  'Some moths use the stars to find their way on long night journeys.',
  'Dogs see much better than people in dim light. A shiny layer at the back of their eyes is why their eyes glow in a torch beam.',
  'Dogs dream too! When a sleeping dog twitches its paws, it may be dreaming about running.'],
 snowy:['The Northern Lights happen when tiny bits blown from the Sun crash into the air high above the Earth and make it glow.',
  'Green is the most common colour of the Northern Lights. It comes from oxygen high up in the sky.',
  'Near the North Pole the Sun does not rise for weeks in winter. This is called the polar night.',
  'Snowy owls hunt in daylight as well as at night, which helps in the Arctic summer, when the Sun never sets.',
  'Frost forms on clear nights, when the ground is so cold that water in the air freezes onto it as ice crystals.',
  'Clear winter nights are colder than cloudy ones, because clouds work like a blanket and keep the warmth in.',
  'Arctic foxes have fur on the bottoms of their paws to keep their feet warm on the snow.',
  'Snow makes the night brighter, because it reflects the light of the Moon and the stars.',
  'Mountains are great places to see the stars, because the air up high is thin and clear.',
  'Huskies can curl up in the snow with their fluffy tail over their nose to keep warm.',
  'Stars seem to twinkle because the air above us is always moving, bending their light a tiny bit.',
  'Frozen lakes can sing! On cold nights the ice booms and whoops as it cracks and shifts.',
  'The Northern Lights have a twin in the south, called the Southern Lights.'],
 reef:['Some tiny plankton glow blue when the water moves, so the waves sparkle at night.',
  'About three quarters of the animals in the deep sea can make their own light.',
  'An anglerfish has a glowing lure on its head, like a fishing rod with a light on the end.',
  'Lanternfish have rows of glowing spots, and they swim up towards the surface at night to feed.',
  'Many corals release their eggs all at once, on a few nights after a full moon.',
  'Baby sea turtles hatch at night and head for the sea, which looks brighter than the land.',
  'The Moon\'s pull makes the tides, so the sea rises and falls about twice a day.',
  'Some squid glow on their bellies to match the moonlight, so fish below can\'t see their shadow.',
  'Some jellyfish glow green, and scientists use their glowing protein to study how living things work.',
  'Octopuses can change colour in a flash, even though scientists think they are colour-blind.',
  'Sunlight never reaches the deepest parts of the ocean, so it is dark there all day and all night.',
  'Some parrotfish blow a bubble of slime around themselves, like a sleeping bag, to sleep in at night.',
  'Sea otters sometimes hold paws while they sleep, so they don\'t drift apart.'],
 ninja:['Paper lanterns have been made in China and Japan for hundreds of years, and lantern festivals fill the night with glowing lights.',
  'In Japan, people celebrate the autumn full moon with a moon-viewing festival called Tsukimi.',
  'In Japan and China, people tell a story about a rabbit who lives on the Moon. Look at the dark patches and you might see it!',
  'In Japan, fireflies are called hotaru, and people go out on summer evenings to watch them glow.',
  'Red pandas sleep in the trees by day and are busiest at dawn, at dusk and at night.',
  'Some kinds of bamboo can grow almost a metre in a single day.',
  'Snow monkeys in Japan keep warm on winter nights by huddling together.',
  'The stars are suns, very far away. Our Sun is a star too.',
  'The Moon doesn\'t make its own light. It shines because sunlight bounces off it.',
  'A full moon rises around sunset and sets around sunrise.',
  'While you sleep, your brain sorts out your day and stores what you have learned.',
  'In Japan, looking at cherry blossom lit up at night has its own name: yozakura.',
  'A Japanese paper lantern that folds up like an accordion is called a chochin.'],
 number:['On a clear, dark night you can see about 2,000 to 3,000 stars at once with just your eyes.',
  'The Moon takes about 29 and a half days to go through all its shapes, from one new moon to the next.',
  'The Earth spins round once every 24 hours. That is why we have day and night.',
  'Light from the Moon takes just over 1 second to reach us.',
  'Light from the Sun takes about 8 minutes to reach the Earth.',
  'The Moon is about 384,000 kilometres away. About 30 Earths would fit in the gap.',
  'There are 88 constellations, star pictures that cover the whole sky.',
  'The Plough is made of 7 bright stars, in the shape of a saucepan.',
  'Orion\'s Belt is a row of 3 bright stars in a line.',
  'The Moon is about a quarter as wide as the Earth.',
  'The Earth takes 365 days to go once round the Sun. Every 4 years there is a leap year, with 366 days.',
  'Light travels about 300,000 kilometres every second. Nothing goes faster.',
  'Our galaxy, the Milky Way, has more than 100 billion stars.'],
 gadget:['LED light bulbs use much less electricity than old bulbs, and can last for years.',
  'A glow stick glows when you snap it, because two chemicals mix inside and make light.',
  'Neon signs glow red-orange because of the neon gas inside. Other colours use other gases or coatings.',
  'Glow-in-the-dark toys soak up light, then slowly give it back in the dark.',
  'Night vision cameras can see warmth and infrared light, which our eyes can\'t.',
  'Solar garden lights store sunshine in a battery by day and switch on by themselves at night.',
  'A laser makes a very narrow beam of light, all one colour.',
  'The first electric street lights lit up cities more than 140 years ago.',
  'Light travels in straight lines. That is why a torch makes a beam.',
  'Seen from space at night, cities glow like spiders\' webs of light.',
  'Robots on Mars have to rest and keep warm through freezing Martian nights.',
  'White light is all the colours of the rainbow mixed together.',
  'Thomas Edison\'s team made a light bulb that could glow for more than 1,200 hours.'],
 rescue:['Every lighthouse flashes its own pattern, so sailors can tell which lighthouse they are looking at.',
  'Reflective strips bounce light straight back, so drivers can see you at night.',
  'Sailors once used the North Star to find north, because it stays in almost the same place all night.',
  'Rescue helicopters use heat cameras to spot people by the warmth of their bodies.',
  'Lifeboat crews train in the dark, so they are ready to help at any time, day or night.',
  'A lighthouse lens bends the light into a beam that can be seen far out at sea.',
  'Firefighters use heat cameras to find people in dark, smoky rooms.',
  'Foxes often live in towns, and come out at night to look for food.',
  'Search and rescue dogs can find people by smell, even in the dark.',
  'Bloodhounds can follow a scent trail that is more than a day old.',
  'At night, ships show a red light on their left side and a green light on their right side.',
  'Glow-in-the-dark signs can show the way out of a building even when the lights go off.',
  'Coastguards keep watch over the sea all through the night.'],
 dino:['Some dinosaurs may have hunted at night. Shuvuuia, a small dinosaur, had eyes and ears like a barn owl\'s.',
  'Fireflies were glowing in the time of the dinosaurs. One was found in amber about 99 million years old.',
  'Some mushrooms glow in the dark. Their glow is sometimes called foxfire.',
  'Some fossils glow under ultraviolet light, which helps scientists see tiny details.',
  'Crocodiles hunt mostly at night, and their eyes shine red in torchlight.',
  'Lava glows red-hot at night. It can be hotter than 1,000 degrees Celsius.',
  'Many frogs croak loudest at night, calling to each other across the swamp.',
  'New fern leaves uncurl from tight spirals called fiddleheads.',
  'Dragonflies were around before the dinosaurs, and some ancient ones were as big as crows.',
  'The tuatara of New Zealand comes from a family of reptiles that lived alongside the dinosaurs, and it is busiest at night.',
  'The Moon is slowly drifting away from the Earth, by about 4 centimetres a year.',
  'In the time of the dinosaurs, a day was a little shorter, about 23 and a half hours.',
  'Many small mammals that lived alongside the dinosaurs came out at night to stay safe.'],
 planet:['Shooting stars are not stars. They are bits of space dust, many no bigger than a grain of sand, burning up high in the air.',
  'On the Moon the stars don\'t twinkle, because there is no air to wobble their light.',
  'The brightest planet in our night sky is Venus. It is called the Evening Star, but it is a planet.',
  'Astronauts on the space station see about 16 sunrises and 16 sunsets every day.',
  'On Mars, sunsets are blue.',
  'Jupiter has northern lights too, much bigger and brighter than ours.',
  'Mars has two little moons, called Phobos and Deimos.',
  'Saturn\'s rings are made of billions of chunks of ice and rock.',
  'The footprints on the Moon could last for millions of years, because there is no wind to blow them away.',
  'The Milky Way is the galaxy we live in. On a dark night it looks like a misty band across the sky.',
  'Europa, one of Jupiter\'s moons, has an icy shell with a salty ocean underneath.',
  'A black hole pulls so hard that not even light can escape.',
  'New stars are born inside huge clouds of gas and dust called nebulas.']};
const FACT={foxfire:GPUPS.foxfire.fact,dusk:GPUPS.dusk.fact};
function buildFacts(){ISLANDS.forEach(I=>{const L=NF[I.id];if(!L)return;I.pups.concat(I.bonus||[]).forEach((p,i)=>{if(L[i])FACT[p.id]=L[i];});});}
buildFacts();

/* ---------------- 2D helpers ---------------- */
const moon=(x,y,r,col)=>`<path d="M${x} ${y-r} A${r} ${r} 0 1 0 ${x} ${y+r} A${(r*.4).toFixed(1)} ${r} 0 1 1 ${x} ${y-r} Z" fill="${col||GOLD}" ${ol(1.8)}/>`;
const star5=(x,y,r,col)=>{let d='';for(let i=0;i<10;i++){const a=-PI/2+i*PI/5,rr=i%2?r*.45:r;d+=(i?'L':'M')+(x+Math.cos(a)*rr).toFixed(1)+' '+(y+Math.sin(a)*rr).toFixed(1);}return `<path d="${d}Z" fill="${col||GOLD}" ${ol(1.4)}/>`;};
const gdot=(x,y,r,col)=>`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${(r*2.3).toFixed(1)}" fill="${col}" opacity=".3"/><circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="${r}" fill="${col}"/><circle cx="${(x-r*.3).toFixed(1)}" cy="${(y-r*.3).toFixed(1)}" r="${(r*.35).toFixed(1)}" fill="#fff" opacity=".8"/>`;
const neckPts=(c,n,dip)=>{const out=[],y0=c.cy+c.hh-10;for(let i=-n;i<=n;i++)out.push([c.cx+i*(c.hw*.62/n),y0+(n*n-i*i)/(n*n)*(dip||12)]);return out;};
const SPOTS=[[-.6,-.5],[.2,-.62],[.62,.08],[-.3,.3],[.12,.6],[-.68,.62],[.7,-.45],[0,0]];
if(PS){
 Object.assign(PS.HAT,{
  nightcap(c,col,o){const cx=c.cx,hw=c.hw,yb=c.cy-c.hh*.6;col=col||NAVY;return `<path d="M${cx-hw*.82} ${yb} C${cx-hw*.7} ${yb-52} ${cx+hw*.3} ${yb-64} ${cx+hw*1.08} ${yb-20} C${cx+hw*.7} ${yb-26} ${cx+hw*.72} ${yb-10} ${cx+hw*.82} ${yb} Z" fill="${col}" ${ol(3.5)}/>`+
    (o.moon?moon(cx-hw*.12,yb-30,9,GOLD):star5(cx-hw*.12,yb-30,8,GOLD))+star5(cx+hw*.4,yb-36,5,'#fff')+`<circle cx="${cx+hw*1.1}" cy="${yb-16}" r="10" fill="${o.pom||'#fff'}" ${ol(2.5)}/><rect x="${cx-hw*.88}" y="${yb-10}" width="${hw*1.76}" height="19" rx="9.5" fill="#fff" ${ol(2.5)}/>`;},
  boppers(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||NE[0];let s=`<path d="M${cx-hw*.86} ${cy-hh*.3} Q${cx} ${cy-hh*1.28} ${cx+hw*.86} ${cy-hh*.3}" ${st(K,10,1)}/><path d="M${cx-hw*.86} ${cy-hh*.3} Q${cx} ${cy-hh*1.28} ${cx+hw*.86} ${cy-hh*.3}" ${st('#3a3640',6,1)}/>`;
    for(const g of[-1,1]){const x=cx+g*hw*.38,y=cy-hh*.92;s+=`<path d="M${x} ${y} q${g*-10} -14 ${g*4} -26 q${g*12} -10 ${g*6} -22" ${st(K,3.4,1)}/>`+gdot(x+g*10,y-48,7,col);}return s;},
  headlamp(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,y=cy-hh*.62;col=col||'#3a3640';const d=`M${cx-hw*.92} ${y+8} Q${cx} ${y-8} ${cx+hw*.92} ${y+8}`;
    return `<path d="${d}" ${st(K,13,1)}/><path d="${d}" ${st(col,8.5,1)}/><circle cx="${cx}" cy="${y-6}" r="20" fill="#fff6b0" opacity=".35"/><rect x="${cx-13}" y="${y-16}" width="26" height="19" rx="6" fill="#8a8f99" ${ol(2.5)}/><circle cx="${cx}" cy="${y-6.5}" r="7.5" fill="#fff6b0" ${ol(2)}/>`;},
  lanternhat(c,col){const cx=c.cx,yb=c.cy-c.hh*.72;col=col||'#e8423a';return `<circle cx="${cx}" cy="${yb-22}" r="32" fill="#ffd27a" opacity=".3"/><rect x="${cx-12}" y="${yb-47}" width="24" height="7" rx="2" fill="#26232e" ${ol(1.6)}/><ellipse cx="${cx}" cy="${yb-22}" rx="25" ry="20" fill="${col}" ${ol(3)}/>`+
    `<path d="M${cx-13} ${yb-40} Q${cx-22} ${yb-22} ${cx-13} ${yb-4} M${cx} ${yb-42} V${yb-2} M${cx+13} ${yb-40} Q${cx+22} ${yb-22} ${cx+13} ${yb-4}" ${st(shade(col,-.28),2.2,1)}/><ellipse cx="${cx-7}" cy="${yb-29}" rx="7" ry="4.5" fill="#fff6c2" opacity=".65"/><rect x="${cx-11}" y="${yb-5}" width="22" height="6" rx="2" fill="#26232e" ${ol(1.6)}/><path d="M${cx} ${yb+1} v8" ${st(GOLD,3,1)}/>`;}});
 Object.assign(PS.BODY,{
  pjs(c,col,o){const by=c.by,bw=c.bw,bh=c.bh,x1=100-bw;col=col||NAVY;let s=`<rect x="${x1}" y="${by-bh}" width="${bw*2}" height="${bh*2}" fill="${col}"/>`;
   if(o.pat==='num'){s+=`<text x="${100+bw*.3}" y="${by+14}" font-size="${String(o.num).length>1?28:36}" font-weight="900" text-anchor="middle" fill="${GOLD}" stroke="${K}" stroke-width="1.6" font-family="Arial">${o.num}</text>`;SPOTS.slice(0,4).forEach((q,i)=>{s+=star5(100+q[0]*bw*.9,by+q[1]*bh,4.5,i%2?'#fff':GOLD);});}
   else SPOTS.forEach((q,i)=>{const x=100+q[0]*bw,y=by+q[1]*bh;s+=o.pat==='moon'&&i%2?moon(x,y,6,GOLD):star5(x,y,5.5,i%3?GOLD:'#fff');});
   [0,1,2].forEach(i=>{s+=`<circle cx="${c.bcx}" cy="${by-bh*.55+i*bh*.5}" r="3" fill="#fff" ${ol(1)}/>`;});return s;},
  circuit(c,col,o){const by=c.by,bw=c.bw,bh=c.bh,x1=100-bw,x2=100+bw,g=o.c||NE[1];col=col||'#2a3040';let s=`<rect x="${x1}" y="${by-bh}" width="${bw*2}" height="${bh*2}" fill="${col}"/>`;
   const d=`M${x1} ${by-bh*.4} H${100-bw*.3} V${by+bh*.2} H${100+bw*.25} V${by-bh*.5} H${x2} M${100-bw*.6} ${by+bh} V${by+bh*.5} H${100+bw*.1} M${100+bw*.55} ${by+bh} V${by+bh*.3}`;
   s+=`<path d="${d}" ${st(g,7,.3)}/><path d="${d}" ${st(g,2.6,1)}/>`;[[100-bw*.3,by-bh*.4],[100+bw*.25,by+bh*.2],[100+bw*.1,by+bh*.5],[100+bw*.55,by+bh*.3]].forEach(q=>{s+=gdot(q[0],q[1],3.2,g);});return s;}});
 Object.assign(PS.NECK,{
  glowcollar(c,col){const cx=c.cx,y=c.cy+c.hh-8,d=`M${cx-c.hw*.58} ${y} Q${cx} ${y+14} ${cx+c.hw*.58} ${y}`;col=col||NE[5];return `<path d="${d}" ${st(col,20,.28)}/><path d="${d}" ${st(K,10,1)}/><path d="${d}" ${st(col,6.5,1)}/><path d="${d}" ${st('#ffffff',2,.75)}/>`;},
  aurora(c){const cx=c.cx,y=c.cy+c.hh-12,d=`M${cx-c.hw*.66} ${y} Q${cx} ${y+16} ${cx+c.hw*.66} ${y}`;return `<path d="${d}" ${st(K,22,1)}/><path d="${d}" ${st('#3fd9a0',16,1)}/><path d="M${cx-c.hw*.6} ${y+2} Q${cx} ${y+17} ${cx+c.hw*.6} ${y+2}" ${st('#8a6aff',4,.95)}/><path d="M${cx-c.hw*.6} ${y-3} Q${cx} ${y+11} ${cx+c.hw*.6} ${y-3}" ${st('#5cf0ff',3,.9)}/>`+
    `<g transform="rotate(-10 ${cx+c.hw*.32} ${y+6})"><rect x="${cx+c.hw*.22}" y="${y+4}" width="17" height="40" rx="5" fill="#3fd9a0" ${ol(2.6)}/><path d="M${cx+c.hw*.22} ${y+18} h17" ${st('#8a6aff',4,1)}/><path d="M${cx+c.hw*.22} ${y+28} h17" ${st('#5cf0ff',3.5,1)}/></g>`;},
  pearls(c,col){col=col||'#fff6c2';const P=neckPts(c,5,13);return `<path d="M${P.map(p=>p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' L')}" ${st('#8a8f99',2,1)}/>`+P.map(p=>gdot(p[0],p[1]+1,3.6,col)).join('');}});
 Object.assign(PS.BACK,{
  starcape(c,col){col=col||NAVY;const x1=100-c.bw-6,x2=100+c.bw+6,y=c.by-c.bh-2,yb=c.by+c.bh+8;let s=`<path d="M${x1+12} ${y} Q100 ${y-10} ${x2-12} ${y} L${x2+16} ${yb} Q100 ${yb+14} ${x1-16} ${yb} Z" fill="${col}" ${ol(3)}/>`;
   [[x1-6,yb-14],[x2+6,yb-10],[x1+2,y+24],[x2-2,y+30]].forEach((q,i)=>{s+=star5(q[0],q[1],i%2?5:6.5,i%3?'#fff':GOLD);});return s;}});
 Object.assign(PS.FACE,{
  ledgog(c,col){const cx=c.cx,y=c.cy-c.hh*.58,hw=c.hw;col=col||NE[1];return `<path d="M${cx-hw*.9} ${y+4} Q${cx} ${y-6} ${cx+hw*.9} ${y+4}" ${st(K,9,1)}/><path d="M${cx-hw*.9} ${y+4} Q${cx} ${y-6} ${cx+hw*.9} ${y+4}" ${st('#3a3640',5,1)}/>`+[-1,1].map(g=>`<circle cx="${cx+g*hw*.34}" cy="${y}" r="15" fill="#3a3640" ${ol(2.5)}/>`+gdot(cx+g*hw*.34,y,9,col)).join('');}});
}
/* glow extras, drawn after the outfit (x: gspots, gspikes, glamp, gtwk) */
function extra2D(w,c,X){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;let s='';
  if(w==='behind'&&X.gspikes)for(let i=0;i<5;i++){const x=100-c.bw*.7+i*c.bw*.32,y=c.by-c.bh+2;s+=`<path d="M${x-8} ${y+4} L${x} ${y-14} L${x+8} ${y+4} Z" fill="${X.gspikes}" opacity=".35" transform="scale(1.25) translate(${-x*.2} ${-y*.2})"/><path d="M${x-8} ${y+4} L${x} ${y-14} L${x+8} ${y+4} Z" fill="${X.gspikes}" ${ol(2.2)}/>`;}
  if(w==='top'){if(X.gspots)SPOTS.slice(0,6).forEach(q=>{s+=gdot(100+q[0]*c.bw*.85,c.by+q[1]*c.bh*.8,3.4,X.gspots);});
    if(X.glamp){const y=cy-hh*.66;s+=`<circle cx="${cx}" cy="${y}" r="17" fill="#fff6b0" opacity=".35"/><rect x="${cx-11}" y="${y-9}" width="22" height="17" rx="5" fill="#8a8f99" ${ol(2.4)}/><circle cx="${cx}" cy="${y}" r="6.5" fill="#fff6b0" ${ol(2)}/>`;}
    if(X.gtwk)[[cx-hw*1.05,cy-hh*.9,7],[cx+hw*1.0,cy-hh*1.05,8],[cx+hw*.2,cy-hh*1.35,6]].forEach(q=>{s+=star4(q[0],q[1],q[2],'#fff7c2','twk');});}
  return s;}
function extra3D(X,L,b,h,c){const lg=c.lg,bw=c.bw;
  if(X.gspots)[[-.42,.85,.3],[.42,.9,0],[-.4,.95,-.35],[.44,.75,-.42],[0,1.12,.1],[.2,.6,.5]].forEach(q=>mk('sph',X.gspots,.06,.06,.06,q[0]*bw,q[1],q[2]*lg,b,true));
  if(X.gspikes)for(let i=0;i<5;i++)mk('cone',X.gspikes,.07,.22,.07,0,1.16,(.4-i*.2)*lg,b,true);
  if(X.glamp){mk('box','#8a8f99',.16,.12,.08,0,.5,.44,h);mk('sph','#fff6b0',.06,.06,.03,0,.5,.49,h,true);}
  if(X.gtwk)[[-.5,.8,.1],[.5,.9,0],[0,1.05,-.1]].forEach(q=>mk('sph','#fff7c2',.05,.05,.05,q[0],q[1],q[2],h,true));}
function pjs3D(S,b,c){if(!S.b)return;const k=S.b[0],lg=c.lg,bw=c.bw;
  if(k==='pjs')[[-.3,.82,.4],[.32,.9,.2],[-.2,.62,-.3],[.35,.7,-.4],[0,1.0,-.1]].forEach(q=>mk('sph',GOLD,.05,.05,.05,q[0]*bw,q[1],q[2]*lg,b,true));
  if(k==='circuit'){const g=(S.b[2]&&S.b[2].c)||NE[1];[[-.35,.8,.45],[.3,.7,.5],[.0,.95,.48]].forEach(q=>mk('box',g,.18,.025,.025,q[0]*bw,q[1],q[2]*lg,b,true));}}
if(PS){
 Object.assign(PS.H3,{
  nightcap(h,col,o){const cn=mk('cone',col||NAVY,.36,.72,.36,.12,.72,-.04,h);cn.rotation.z=-.75;mk('tor','#ffffff',.44,.44,.5,0,.42,-.02,h).rotation.x=PI/2;mk('sph',(o&&o.pom)||'#ffffff',.13,.13,.13,.46,.84,-.04,h);},
  boppers(h,col){mk('arc','#3a3640',.6,.6,1.2,0,.08,0,h);[-1,1].forEach(s=>{const a=mk('cyl','#3a3640',.02,.42,.02,s*.2,.72,0,h);a.rotation.z=-s*.3;mk('sph',col||NE[0],.09,.09,.09,s*.3,.93,0,h,true);});},
  headlamp(h,col){mk('tor',col||'#3a3640',.47,.47,.35,0,.32,0,h).rotation.x=PI/2;mk('box','#8a8f99',.16,.12,.08,0,.36,.46,h);mk('sph','#fff6b0',.06,.06,.03,0,.36,.51,h,true);},
  lanternhat(h,col){mk('sph',col||'#e8423a',.26,.22,.26,0,.7,0,h,true);mk('cyl','#26232e',.14,.05,.14,0,.93,0,h);mk('cyl','#26232e',.14,.05,.14,0,.48,0,h);}});
 Object.assign(PS.N3,{
  glowcollar(b,col,cz,c){mk('tor',col||NE[5],.3*c.hs,.3*c.hs,.35*c.hs,0,.98,.4*c.lg,b,true).rotation.x=PI/2-.5;},
  aurora(b,col,cz,c){mk('tor','#3fd9a0',.3*c.hs,.3*c.hs,.55*c.hs,0,.98,.4*c.lg,b).rotation.x=PI/2-.5;mk('box','#8a6aff',.13,.38,.06,.14,.78,cz+.06,b).rotation.z=.15;},
  pearls(b,col,cz,c){mk('tor','#8a8f99',.3*c.hs,.3*c.hs,.12*c.hs,0,.98,.4*c.lg,b).rotation.x=PI/2-.5;for(let i=0;i<5;i++){const a=-.9+i*.45;mk('sph',col||'#fff6c2',.05,.05,.05,Math.sin(a)*.3*c.hs,.9,.4*c.lg+Math.cos(a)*.24*c.hs,b,true);}}});
 Object.assign(PS.K3,{starcape(b,c){mk('box',NAVY,.98*c.bw,.04,1.0*c.lg,0,1.17,-.12*c.lg,b);[[-.25,.2],[.2,-.1],[0,-.4],[-.15,-.3],[.3,.3]].forEach(q=>mk('sph',GOLD,.045,.045,.045,q[0]*c.bw,1.21,q[1]*c.lg,b,true));}});
 Object.assign(PS.FACE3,{ledgog(h,col){mk('cyl','#3a3640',.6,.06,.56,0,.52,0,h);[-1,1].forEach(g=>mk('sph',col||NE[1],.1,.1,.04,g*.15,.54,.43,h,true));}});
 Object.assign(PS.B3,{pjs:NAVY,circuit:'#2a3040'});
}

/* ---------------- full costumes ---------------- */
const GC={
 firefly:{n:'Firefly',body:'#5a4030',belly:'#6a5038',paw:'#3a2a20',line:'NAME is a little firefly, with a tail that glows!'},
 owl:{n:'Snowy Owl',body:'#ffffff',belly:'#f6f7fa',paw:'#d8dde6',line:'NAME is a snowy owl, wide awake at night. Hoo hoo!'},
 jelly:{n:'Jellyfish',body:'#d9b8ff',belly:'#ecdcff',paw:'#c9a0ff',line:'NAME is a glowing jellyfish, bobbing in the Glowing Bay!'},
 lantern:{n:'Paper Lantern',body:'#e8423a',belly:'#ff6a4a',paw:'#b8322a',line:'NAME is a glowing paper lantern, ready for the Lantern Festival!'},
 moon:{n:'The Moon',body:'#f3e7b0',belly:'#fff6d6',paw:'#d8c98a',line:'NAME is the Moon, shining over the night!'},
 glowbot:{n:'Glow Robot',body:'#9aa6b8',belly:'#c8d2e0',paw:'#6a7688',line:'NAME is a glow robot. Beep boop, lights on!'},
 lighthouse:{n:'Lighthouse',body:'#ffffff',belly:'#ffffff',paw:'#d9363e',line:'NAME is a lighthouse, flashing the way home for the ships!'},
 glowworm:{n:'Glow-worm',body:'#8a7a4a',belly:'#a89a6a',paw:'#6a5a3a',line:'NAME is a glow-worm, with a little light on the end!'},
 star:{n:'Star',body:'#ffd23f',belly:'#fff2a8',paw:'#e0a400',line:'NAME is a twinkly star, shining in the night sky!'},
 gpjs:{n:'Star Pyjamas',body:NAVY,belly:NAVY,paw:'#1f2a5a',line:'NAME is wearing cosy star pyjamas and a night cap. Sleep tight!'}};
const GKEYS=Object.keys(GC),isG=k=>GKEYS.indexOf(k)>=0;
for(const k in GC){GC[k].glow=true;COS[k]=GC[k];}
if(typeof COS_ICON!=='undefined')Object.assign(COS_ICON,{firefly:'✨',owl:'🦉',jelly:'🪼',lantern:'🏮',moon:'🌙',glowbot:'🤖',lighthouse:'🗼',glowworm:'🐛',star:'⭐',gpjs:'🌙'});
const _c2=cos2D;cos2D=function(w,c){let s=_c2(w,c);const L=c.L,Kc=L.cos;if(!isG(Kc))return s;
  const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,S3=c.S3,yb=cy-hh*.42;
  const dome=(col,lo)=>`<path d="M${cx-hw*.94} ${lo} Q${cx-hw*.94} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.94} ${cy-hh*1.2} ${cx+hw*.94} ${lo} Z" fill="${col}" ${S}/>`;
  const ant=(tip)=>[-1,1].map(g=>{const x=cx+g*hw*.3,y=cy-hh*1.12;return `<path d="M${x} ${y} q${g*6} -18 ${g*20} -22" ${st(K,3.4,1)}/>`+(tip?gdot(x+g*20,y-23,5,tip):`<circle cx="${x+g*20}" cy="${y-23}" r="4.5" fill="#3a2a20"/>`);}).join('');
  if(w==='behind'){
    if(Kc==='firefly')for(const g of[-1,1]){const x=100+g*(bw-2),y=by-bh;s+=`<ellipse cx="${x+g*20}" cy="${y+6}" rx="30" ry="15" transform="rotate(${g*-28} ${x+g*20} ${y+6})" fill="#e8f4ff" opacity=".75" ${S3}/>`;}
    if(Kc==='owl')for(const g of[-1,1]){const x=100+g*(bw-2);s+=`<ellipse cx="${x}" cy="${by-2}" rx="15" ry="${bh*.75}" fill="#ffffff" transform="rotate(${g*18} ${x} ${by})" ${S3}/><path d="M${x-5} ${by-8} q3 3 6 0 M${x-4} ${by+6} q3 3 6 0" ${st('#5a5a66',2,1)}/>`;}
    if(Kc==='jelly'){const y=by+bh-4;for(let i=0;i<6;i++){const x=100-bw*.8+i*bw*.32,col=i%2?'#5cf0ff':'#ff7fe0';s+=`<path d="M${x} ${y} q-6 12 0 22 q6 10 0 22" ${st(col,7,.3)}/><path d="M${x} ${y} q-6 12 0 22 q6 10 0 22" ${st(col,3,1)}/>`;}}
    if(Kc==='star'){let d='';for(let i=0;i<10;i++){const a=-PI/2+i*PI/5,r=i%2?hw*.7:hw*1.55;d+=(i?'L':'M')+(cx+Math.cos(a)*r).toFixed(1)+' '+(cy-6+Math.sin(a)*r).toFixed(1);}s+=`<path d="${d}Z" fill="#ffe680" opacity=".5" transform="translate(${cx} ${cy-6}) scale(1.12) translate(${-cx} ${-(cy-6)})"/><path d="${d}Z" fill="${GOLD}" ${S}/>`;}}
  if(w==='bodyClip'){
    if(Kc==='firefly')s+=`<rect x="${100-bw}" y="${by+bh*.35}" width="${bw*2}" height="${bh}" fill="#d8ff5a"/><rect x="${100-bw}" y="${by+bh*.35}" width="${bw*2}" height="5" fill="#a8d83a"/><ellipse cx="${bcx}" cy="${by+bh*.7}" rx="${bw*.5}" ry="${bh*.25}" fill="#ffffff" opacity=".5"/>`;
    if(Kc==='owl')[[-.6,-.3],[.2,-.5],[.5,.2],[-.2,.35],[-.55,.6],[.65,-.1],[.1,.75]].forEach(q=>{s+=`<path d="M${100+q[0]*bw-5} ${by+q[1]*bh} q5 4 10 0" ${st('#5a5a66',2.4,1)}/>`;});
    if(Kc==='jelly')SPOTS.forEach((q,i)=>{s+=gdot(100+q[0]*bw,by+q[1]*bh,3.2,i%2?'#5cf0ff':'#ff7fe0');});
    if(Kc==='lantern'){s+=`<ellipse cx="${bcx}" cy="${by}" rx="${bw*.6}" ry="${bh*.7}" fill="#ffd27a" opacity=".55"/>`;for(const t of[-.6,-.2,.2,.6])s+=`<path d="M${100+t*bw} ${by-bh} Q${100+t*bw*1.25} ${by} ${100+t*bw} ${by+bh}" ${st('#a8262c',2.4,1)}/>`;s+=`<rect x="${100-bw}" y="${by-bh}" width="${bw*2}" height="9" fill="${GOLD}"/><rect x="${100-bw}" y="${by+bh-9}" width="${bw*2}" height="9" fill="${GOLD}"/>`;}
    if(Kc==='moon')[[-.5,-.3,9],[.35,-.45,6],[.5,.3,8],[-.25,.45,5],[.05,.05,4]].forEach(q=>{s+=`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="${q[2]}" fill="#e0d090" ${ol(1.4)}/>`;});
    if(Kc==='glowbot'){s+=`<rect x="${bcx-bw*.45}" y="${by-bh*.55}" width="${bw*.9}" height="${bh*1.05}" rx="6" fill="#3a4250" ${S3}/>`;[['#c8ff4a',-.25],['#ffd23f',0],['#5cf0ff',.25]].forEach(q=>{s+=gdot(bcx+q[1]*bw*1.2,by-bh*.1,4.5,q[0]);});s+=`<path d="M${bcx-bw*.3} ${by+bh*.25} h${bw*.6}" ${st('#5cf0ff',3,1)}/>`+[[-.85,-.75],[.85,-.75],[-.85,.75],[.85,.75]].map(q=>`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="3" fill="#6a7688"/>`).join('');}
    if(Kc==='lighthouse')for(const t of[-.55,.15])s+=`<rect x="${100-bw}" y="${by+t*bh}" width="${bw*2}" height="${bh*.32}" fill="#d9363e"/>`;
    if(Kc==='glowworm'){for(const t of[-.6,-.25,.1,.45])s+=`<path d="M${100-bw} ${by+t*bh} Q100 ${by+t*bh+8} ${100+bw} ${by+t*bh}" ${st('#6a5a3a',3,1)}/>`;s+=`<rect x="${100-bw}" y="${by+bh*.62}" width="${bw*2}" height="${bh*.5}" fill="#d8ff5a"/>`;}
    if(Kc==='star')[[-.5,-.3],[.4,.2],[-.1,.55],[.6,-.5]].forEach(q=>{s+=star4(100+q[0]*bw,by+q[1]*bh,6,'#fff7c2');});
    if(Kc==='gpjs'){SPOTS.forEach((q,i)=>{const x=100+q[0]*bw,y=by+q[1]*bh;s+=i%2?moon(x,y,6,GOLD):star5(x,y,5.5,i%3?GOLD:'#fff');});[0,1,2].forEach(i=>{s+=`<circle cx="${bcx}" cy="${by-bh*.55+i*bh*.5}" r="3" fill="#fff"/>`;});}}
  if(w==='top'){
    if(Kc==='firefly')s+=dome('#5a4030',yb)+`<path d="M${cx-hw*.92} ${yb} Q${cx} ${yb-16} ${cx+hw*.92} ${yb} L${cx+hw*.86} ${yb-10} Q${cx} ${yb-26} ${cx-hw*.86} ${yb-10} Z" fill="#e8603a" ${S3}/>`+ant(null);
    if(Kc==='owl')s+=dome('#ffffff',yb)+`<path d="M${cx-8} ${cy-hh*1.02} l8 10 l8 -10 Z" fill="#3a3640"/>`+[-1,1].map(g=>`<circle cx="${cx+g*hw*.42}" cy="${cy-hh*.98}" r="9" fill="${GOLD}" ${ol(2)}/><circle cx="${cx+g*hw*.42}" cy="${cy-hh*.98}" r="4" fill="#26232e"/>`).join('');
    if(Kc==='jelly')s+=`<path d="M${cx-hw*1.0} ${yb} Q${cx-hw*1.0} ${cy-hh*1.4} ${cx} ${cy-hh*1.42} Q${cx+hw*1.0} ${cy-hh*1.4} ${cx+hw*1.0} ${yb} q-12 10 -24 0 q-12 10 -24 0 q-12 10 -24 0 q-12 10 -24 0 Z" fill="#e8c8ff" opacity=".9" ${S}/>`+[[-.5,-1.05],[.2,-1.2],[.55,-.85],[-.15,-.82]].map((q,i)=>gdot(cx+q[0]*hw,cy+q[1]*hh,3.6,i%2?'#5cf0ff':'#ff7fe0')).join('');
    if(Kc==='lantern')s+=PS.HAT.lanternhat(c,'#e8423a');
    if(Kc==='moon')s+=moon(cx+hw*.45,cy-hh*1.12,30,'#f3e7b0')+star5(cx-hw*.6,cy-hh*1.1,7,'#fff')+star5(cx-hw*.1,cy-hh*1.42,5,GOLD);
    if(Kc==='glowbot')s+=dome('#9aa6b8',yb)+`<path d="M${cx} ${cy-hh*1.2} v-18" ${st(K,4,1)}/>`+gdot(cx,cy-hh*1.2-22,7,'#c8ff4a')+[-1,1].map(g=>`<circle cx="${cx+g*hw*.94}" cy="${yb-8}" r="7" fill="#6a7688" ${ol(2)}/>`).join('');
    if(Kc==='lighthouse'){const y=cy-hh*.95;s+=`<path d="M${cx-30} ${y-18} L${cx-120} ${y-44} L${cx-120} ${y+8} Z" fill="#fff6b0" opacity=".35"/><rect x="${cx-24}" y="${y-24}" width="48" height="26" rx="4" fill="#fff6b0" ${S3}/><path d="M${cx-8} ${y-24} v26 M${cx+8} ${y-24} v26" ${st(K,2,1)}/><path d="M${cx-30} ${y-24} Q${cx} ${y-54} ${cx+30} ${y-24} Z" fill="#d9363e" ${S3}/><circle cx="${cx}" cy="${y-50}" r="5" fill="#d9363e" ${ol(2)}/><rect x="${cx-34}" y="${y+2}" width="68" height="8" rx="3" fill="#3a3640" ${ol(2)}/>`;}
    if(Kc==='glowworm')s+=dome('#8a7a4a',yb)+ant('#d8ff5a');
    if(Kc==='star')[[cx-hw*1.1,cy-hh*.2],[cx+hw*1.15,cy-hh*.5]].forEach(q=>{s+=star4(q[0],q[1],8,'#fff7c2','twk');});
    if(Kc==='gpjs')s+=PS.HAT.nightcap(c,NAVY,{pom:GOLD,moon:1});}
  return s;};
const _c3=cos3D;cos3D=function(L,b,h,c){const Kc=L.cos;if(!isG(Kc))return _c3(L,b,h,c);
  const bw=c.bw,lg=c.lg,helm=col=>{const hm=mk('hemi',col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;return hm;},band=(col,y,th,un)=>{mk('band',col,.51*bw,.65*lg,th||1.8,0,y,0,b,un).rotation.x=PI/2;};
  const ants=tip=>[-1,1].forEach(s=>{mk('cyl','#3a2a20',.025,.36,.025,s*.18,.74,.05,h).rotation.z=-s*.35;mk('sph',tip||'#3a2a20',.06,.06,.06,s*.3,.9,.05,h,!!tip);});
  switch(Kc){
   case'firefly':helm('#5a4030');ants(null);[-1,1].forEach(s=>{const wg=mk('sph','#e8f4ff',.06,.36,.5,s*(.42*bw+.1),1.15,-.1*lg,b);wg.rotation.z=s*.6;});mk('sph','#d8ff5a',.42*bw,.36,.32*lg,0,.66,-.42*lg,b,true);break;
   case'owl':helm('#ffffff');[-1,1].forEach(s=>mk('sph','#ffffff',.08,.3,.48*lg,s*(.5*bw+.04),.85,-.05,b));[[-.3,.9,.3],[.25,.8,-.3],[.1,1.0,.45]].forEach(q=>mk('sph','#5a5a66',.05,.03,.05,q[0]*bw,q[1],q[2]*lg,b));break;
   case'jelly':{const hm=mk('hemi','#e8c8ff',.7,.62,.66,0,.1,-.02,h,true);hm.rotation.x=-.32;for(let i=0;i<6;i++){const a=i/6*PI*2;mk('cyl',i%2?'#5cf0ff':'#ff7fe0',.03,.5,.03,Math.cos(a)*.35*bw,.2,Math.sin(a)*.45*lg,b,true);}break;}
   case'lantern':band(GOLD,1.0,1.1);band(GOLD,.42,1.1);mk('sph','#ffd27a',.3*bw,.3,.3,0,.7,.42*lg,b,true);PS.H3.lanternhat(h,'#e8423a');break;
   case'moon':helm('#f3e7b0');[[-.3,.9,.25],[.25,.8,-.3],[.1,1.0,.45]].forEach(q=>mk('sph','#e0d090',.09,.04,.09,q[0]*bw,q[1],q[2]*lg,b));mk('tor','#fff6c2',.32,.32,.5,.2,.85,-.05,h,true).rotation.y=PI/2;break;
   case'glowbot':helm('#9aa6b8');mk('box','#3a4250',.5*bw,.36,.06,0,.75,.62*lg,b);['#c8ff4a','#ffd23f','#5cf0ff'].forEach((q,i)=>mk('sph',q,.05,.05,.03,(i-1)*.14*bw,.8,.66*lg,b,true));mk('cyl','#3a3640',.02,.25,.02,0,.78,0,h);mk('sph','#c8ff4a',.08,.08,.08,0,.92,0,h,true);break;
   case'lighthouse':band('#d9363e',.82,1.3);band('#d9363e',.52,1.3);mk('cyl','#fff6b0',.22,.2,.22,0,.72,0,h,true);mk('cone','#d9363e',.28,.22,.28,0,.92,0,h);break;
   case'glowworm':helm('#8a7a4a');ants('#d8ff5a');mk('sph','#d8ff5a',.4*bw,.32,.3*lg,0,.62,-.44*lg,b,true);break;
   case'star':for(let i=0;i<5;i++){const a=i*PI*2/5,cn=mk('cone',GOLD,.16,.42,.1,Math.sin(a)*.62,.12+Math.cos(a)*.62,-.25,h,true);cn.rotation.z=-a;}break;
   case'gpjs':[[-.3,.82,.4],[.32,.9,.2],[-.2,.62,-.3],[.35,.7,-.4],[0,1.0,-.1]].forEach(q=>mk('sph',GOLD,.05,.05,.05,q[0]*bw,q[1],q[2]*lg,b,true));PS.H3.nightcap(h,NAVY,{pom:GOLD});break;}};

/* ---------------- who wears what at night ---------------- */
const NUMS={digit:'1',dot:'2',doodle:'10',zero:'0',ruler:'12',paddle:'5',cube:'8',prism:'3',pie:'π',seven:'7',infinity:'∞',plus:'+',pretzel:'6'};
const KIT={
 meadow:(i,p)=>({h:i%3===1?['nightcap',PJ[i%5],{pom:NE[i%6],moon:i%2}]:['boppers',NE[i%6]],n:i%3!==2?[['glowcollar',NE[(i+2)%6]]]:null,b:i%2?['pjs',PJ[(i+1)%5],{pat:i%4===1?'moon':'star'}]:null,drop:['scarf','bow']}),
 snowy:(i,p)=>({h:i%3===2?['earmuffs',NE[i%6]]:['beanie',PJ[i%5],{pom:NE[(i+1)%6]}],x:{glamp:i%3!==2?1:0},n:i%2?[['aurora']]:[['glowcollar',NE[(i+3)%6]]],k:i%3===0?['starcape']:null,drop:['scarf']}),
 reef:(i,p)=>({n:i%3!==1?[['pearls',NE[(i+1)%6]]]:[['glowcollar',NE[i%6]]],x:{gspots:i%3!==2?NE[(i+4)%6]:0},k:i%4===3?['starcape']:null,g:i%4===0?['snorkel']:null,keep:['bubbles'],drop:['shellneck']}),
 ninja:(i,p)=>{const k=i%4;if(k===0)return {h:['lanternhat',['#e8423a','#ffb000','#ff7fb8'][i%3]],n:[['glowcollar',NE[i%6]]],drop:['scarf','bow']};
   return {h:['headband',NE[i%6]],k:k!==2?['starcape',PJ[i%5]]:null,b:k===3?['gi']:null,n:k===2?[['glowcollar',NE[(i+1)%6]]]:null,x:{gtwk:k===1?1:0},drop:['scarf','bow']};},
 number:(i,p)=>({b:['pjs',PJ[i%5],{pat:'num',num:NUMS[p.id]||String(i+1)}],h:i%2?['nightcap',PJ[(i+2)%5],{pom:GOLD,moon:1}]:['numcrown'],n:i%3===0?[['glowcollar',NE[i%6]]]:null,drop:['scarf','flower','bow']}),
 gadget:(i,p)=>({g:['ledgog',NE[i%6]],b:i%3!==2?['circuit','#2a3040',{c:NE[(i+1)%6]}]:null,h:i%3===2?['headlamp']:null,n:i%3===2?[['glowcollar',NE[(i+2)%6]]]:null,drop:['scarf','bow']}),
 rescue:(i,p)=>({b:['hivis'],h:i%2?['hardhat',i%4>1?'#e8423a':'#ffd23f']:['headlamp','#e8423a'],x:{glamp:i%2},n:[['glowcollar',NE[(i+3)%6]]],drop:['scarf','glow']}),
 dino:(i,p)=>({h:['explorer',['#8a5a32','#a8743a','#6a4428'][i%3]],x:{glamp:1,gspikes:NE[i%6]},n:i%2?[['glowcollar',NE[(i+2)%6]]]:null}),
 planet:(i,p)=>({space:{trim:NE[i%6],ant:i%3===1},k:i%2?['starcape']:null,n:i%2?null:[['glowcollar',NE[(i+1)%6]]]})};
const COSTUME={meadow:'firefly',snowy:'owl',reef:'jelly',ninja:'lantern',number:'moon',gadget:'glowbot',rescue:'lighthouse',dino:'glowworm',planet:'star'};
const GOUT={foxfire:{h:['beanie',NAVY,{pom:NE[5]}],n:[['aurora']],x:{glamp:1}},dusk:{k:['starcape'],n:[['glowcollar',GOLD]],x:{gtwk:1}}};
const CWHO={};
function buildOut(){ISLANDS.forEach(I=>{const f=KIT[I.id];if(!f)return;const cp=I.pups.find((p,i)=>i>=4&&!(p.look&&p.look.ninja));I.pups.concat(I.bonus||[]).forEach((p,i)=>{const cs=p===cp&&COSTUME[I.id];if(cs)CWHO[p.id]=cs;GOUT[p.id]=cs?{cos:cs}:f(i,p);const S=GOUT[p.id];for(const k in S)if(S[k]==null)delete S[k];});});}
buildOut();
/* the unicorns at night: a glowing collar and twinkles */
const UNI={n:[['glowcollar','#fff6a8']],x:{gtwk:1}};
const isPup=p=>!!(p&&p.id&&(PUPS[p.id]||GPUPS[p.id]));
const gOn=()=>!!(typeof state!=='undefined'&&state&&state.season==='glow');
const s0=window.SEASONSPEC;
window.SEASONSPEC=function(p,is2D){const prev=()=>s0?s0(p,is2D):null;if(!p||!p.id||p.guest)return prev();
  if(p.glow){if(p.uni)return UNI;if(!isPup(p))return null;const R=PUPS[p.id]||GPUPS[p.id];if(R.breed!==p.breed)return null;return GOUT[p.id]||null;}
  if(!is2D&&gOn()&&!p.xmas){if(p.uni||!isPup(p))return null;const R=PUPS[p.id]||GPUPS[p.id];if(R.breed!==p.breed)return null;return GOUT[p.id]||null;}
  return prev();};
const _f2=form2D;form2D=function(w,c){let s=_f2(w,c);const ps=c.L&&c.L._ps,S=ps&&(ps.S||ps.S3);if(S&&S.x&&!c.L.cos)s+=extra2D(w,c,S.x);return s;};
const _f3=form3D;form3D=function(L,b,h,c){_f3(L,b,h,c);const S=L._ps&&L._ps.S3;if(S&&!L.cos)try{if(S.x)extra3D(S.x,L,b,h,c);pjs3D(S,b,c);}catch(e){console.warn('glow 3D',e);}};

/* a Night Glow copy of a pup, for 2D pictures and cards */
const gp=p=>p?Object.assign({},p,{glow:true}):p;
window.GLOOK={GPUPS,FACT,GOUT,gp,UNI,COSTUME,CWHO,NE,NAVY,GOLD,moon,star5,gdot};
})();
