/* ================================================================
   Seb's Puppy Quest 3: the finale, the Great Pup Conga World Tour
   (25 Nov 2026; plan section 4.13). Built on Puppy Quest 2's Great
   Pup Conga: ten legs of ten pups, counting in tens to 100.
   - Opens when all nine islands are done: a sparkly invitation, and
     Muddle's giant disco ball on top of the Map Tower, with a tall
     pink paw flag in the plaza where the tour starts and carries on.
   - Leg 1: Pawprint Village at night, with lights over the plaza,
     Muddle as DJ and all nine unicorns dancing. Legs 2 to 9: one area
     on each island, reached by that island's ride (a short ride scene
     with the pups just picked): round the windmill, skiing down the
     Green Run, under the sea in diving helmets, round the Dojo, round
     Number Castle, the Workshop, Town Square and Dig Camp. Leg 10: on
     the Moon, under the Earth; then all 100 dance in three circles,
     and if the Black Hole quest is done Zuzu and her 10 puppies fly in
     through a wormhole. Then credits, "The End?" and a Pup Seasons
     teaser (Christmas Snow, coming soon).
   - Each leg: Seb picks 10 pups (Surprise me picks for him), walks
     through 10 glowing numbered rings with a pup waiting at each, and
     every pup hops into the line just behind his team. The line
     follows his trail; earlier pups start coiled up behind him.
   - Leg 1 can use pups from anywhere, but always leaves 10 for every
     island's own leg. Seb's team leads the line and is never picked.
   - Saved after every leg: state.conga = {leg, pups:[ids], best, inv,
     intro, next, nextLeg, done, tours, zuzu}. Leaving mid-leg keeps
     the picks, so the picker opens with them next time.
   - Line pups are not animated (only moved), as in Puppy Quest 2, so
     100 can dance at once (about 300 draw calls); helmets and ski
     boards are one instanced shape each.
   - Grown-ups: Settings has a preview row (any leg, or the credits)
     that saves nothing, so Seb's tour stays a surprise.
   ================================================================ */
(function(){
const TAU=Math.PI*2,q=s=>document.querySelector(s);
const LEGS=[
  {k:'village',area:'village',name:'Pawprint Village',icon:'🏡',c:[0,0],r:[10.5,10.5]},
  {k:'meadow',area:'windmill',c:[0,-13],r:[11.5,11.5],say:'Round and round the windmill!'},
  {k:'snowy',area:'green',ski:true,say:'Conga skiing, down the Green Run!'},
  {k:'reef',area:'lagoon',c:[0,2],r:[15,13],say:'Under the sea, in diving helmets!'},
  {k:'ninja',area:'dojo',c:[0,-15],r:[15,13.5],say:'Round the Dojo, ninja style! Hi-yah!'},
  {k:'number',area:'castle',c:[0,-1],r:[17,12],say:'Round Number Castle!'},
  {k:'gadget',area:'workshop',c:[0,-10],r:[16,13.5],say:'Round the Workshop, past Tinker the robot!'},
  {k:'rescue',area:'townsq',c:[0,0],r:[13,13],say:'Round the Town Square!'},
  {k:'dino',area:'digcamp',c:[0,4],r:[15,13],say:'Round Dig Camp!'},
  {k:'planet',area:'moon',name:'the Moon',icon:'🌙',c:[-2,6],r:[17,15],say:'On the Moon, under the Earth!'}];
const ISL=L=>L.k==='village'?null:islandOf(L.k);
const legName=L=>L.name||ISL(L).name;
const legIcon=L=>L.icon||ISL(L).icon;
const lc=s=>s?s.charAt(0).toLowerCase()+s.slice(1):s;
const rideName=L=>{const I=ISL(L);return I?lc(I.rideName||I.ride||'the ride'):'';};
const NUMW=['zero','one','two','three','four','five','six','seven','eight','nine','ten'];
const mix=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const wrapD=d=>{const A=W.area;return A&&A.planet?PLANET.wrapD(d,A.planet.L):d;};

/* ----- the save ----- */
function S(){const s=state.conga||(state.conga={});if(!Array.isArray(s.pups))s.pups=[];s.leg=s.leg|0;s.best=s.best|0;return s;}
const best=()=>state&&state.conga?state.conga.best|0:0;
const unlocked=()=>!!state&&!!state.islDone&&ISLANDS.every(I=>state.islDone[I.id]);
const bhDone=()=>!!(state.bh&&state.bh.done);

let C=null;          /* the conga in the world right now */
let PV=null;         /* grown-ups preview: {line:[ids]} (nothing saved) */
let INLEG=false;     /* set while the conga itself moves Seb to a new area */
let BALL=null;       /* the disco ball on the Map Tower */

/* pups that can dance: found ones (any in a preview), never Seb's own team */
function pool(pv){const team=new Set(teamIds());return Object.values(PUPS).filter(p=>p&&!p.uni&&(pv||isFound(p.id))&&!team.has(p.id));}
const lineIds=pv=>pv?(PV?PV.line:[]):S().pups;

/* ============ styles and screens ============ */
{const st=document.createElement('style');st.textContent=`
#cgPick .card{width:960px;max-height:740px;padding:16px 22px 18px;box-sizing:border-box}
#cgPick h2{font-size:38px}
.cgSub{font-size:23px;font-weight:800;margin:2px 0 4px}
.cgCnt{display:inline-block;background:#ffd6f2;border:4px solid #5b4636;border-radius:30px;padding:2px 18px;font-size:26px;font-weight:900}
.cgTabs{display:flex;gap:8px;justify-content:center;margin:10px 0 0}
.cgTab{position:relative;width:78px;height:64px;border:4px solid #5b4636;border-radius:20px;background:#fff;font-size:36px;padding:0}
.cgTab.on{background:#ffd86b;box-shadow:0 0 0 4px #fff27a}
.cgTab b{position:absolute;right:-8px;top:-10px;background:#3fae5a;color:#fff;border:3px solid #5b4636;border-radius:50%;width:30px;height:30px;line-height:25px;font-size:17px}
.cgGrid{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;max-height:424px;overflow-y:auto;margin-top:8px;padding:6px 2px;-webkit-overflow-scrolling:touch}
.cgGrid,.cgGrid *{touch-action:pan-y}
.cgPup{position:relative;width:118px;height:130px;border:4px solid #5b4636;border-radius:22px;background:#fffaf0;padding:2px;display:flex;flex-direction:column;align-items:center;justify-content:flex-end}
.cgPup .fitsvg{width:92px;margin:0}.cgPup span{font-size:16px;font-weight:900;line-height:1.1;white-space:nowrap;overflow:hidden;max-width:110px}
.cgPup span.lg{font-size:13px}.cgPup.sel{background:#c9f5cf;box-shadow:0 0 0 5px #3fae5a}
.cgPup b{position:absolute;left:-8px;top:-10px;background:#ff6fb5;color:#fff;border:3px solid #5b4636;border-radius:22px;min-width:38px;height:38px;line-height:33px;font-size:20px;padding:0 4px}
#cgPick .btns{margin-top:12px}#cgPick .btn.dim{opacity:.55}
.cgLegs{display:flex;gap:5px;justify-content:center;align-items:center;flex-wrap:wrap;min-height:0!important}
.cgLegs i{font-style:normal;width:48px;height:48px;border:4px solid #5b4636;border-radius:50%;background:#fff;font-size:25px;line-height:42px;opacity:.6;position:relative}
.cgLegs i.done{background:#8fe39a;opacity:1}.cgLegs i.nx{opacity:1;background:#ffd86b;box-shadow:0 0 0 5px #fff27a;transform:scale(1.12)}
.cgLegs i.done:after{content:'✓';position:absolute;right:-6px;bottom:-8px;font-size:22px;font-weight:900;color:#2c7a3a}
#cgRide{background:radial-gradient(circle at 20% 30%,#fff 1px,transparent 2px) 0 0/90px 90px,radial-gradient(circle at 70% 60%,#fff 1px,transparent 2px) 0 0/130px 130px,linear-gradient(#1d1b4a,#3b2a6e 60%,#6a4a9a);overflow:hidden;z-index:70}
#cgRide.off{animation:cgOut .4s forwards}#cgRide.on{animation:cgIn .3s}
@keyframes cgIn{from{opacity:0}to{opacity:1}}@keyframes cgOut{from{opacity:1}to{opacity:0}}
#cgRideT{position:absolute;left:30px;right:30px;top:150px;text-align:center;color:#fff;font-size:44px;font-weight:900;line-height:1.15;text-shadow:3px 3px 0 #5b4636}
#cgRideS{position:absolute;left:0;right:0;top:268px;text-align:center;color:#ffd86b;font-size:34px;font-weight:900;text-shadow:3px 3px 0 #5b4636}
#cgTrain{position:absolute;top:400px;left:0;display:flex;align-items:flex-end;gap:4px;white-space:nowrap;animation:cgRun 3.4s linear forwards}
#cgTrain .veh{font-size:150px;line-height:1;display:inline-block}#cgTrain .veh.fl{transform:scaleX(-1)}
#cgTrain .pp{width:96px;animation:cgBob .38s ease-in-out infinite alternate}#cgTrain .pp .fitsvg{width:96px}
@keyframes cgRun{from{transform:translateX(1060px)}to{transform:translateX(-1450px)}}
@keyframes cgBob{from{transform:translateY(0)}to{transform:translateY(-16px)}}
#cgPill{right:14px;top:92px;display:none;background:#ffd6f2;font-size:30px}
#cgCred{background:#1a1440;color:#fff;z-index:75;display:none;overflow:hidden;align-items:flex-start}
#cgCred.on{display:block}
#cgTrack{position:absolute;left:0;right:0;top:100%;text-align:center;will-change:transform}
#cgTrack h1{font-size:62px;color:#ffd23f;margin:30px 0 6px}#cgTrack h2{font-size:40px;color:#ff9be6;margin:50px 0 10px}#cgTrack p{font-size:26px;font-weight:700;margin:4px 110px;line-height:1.4}
#cgTrack .fitsvg{width:190px;margin:10px auto}#cgTrack .row{display:flex;justify-content:center;gap:6px;flex-wrap:wrap;margin:0 80px}#cgTrack .row .fitsvg{width:96px;margin:0}
#cgSkip{position:absolute;right:20px;bottom:20px;z-index:2;color:#5b4636}
`;document.head.appendChild(st);}
{const stage=q('#stage');stage.insertAdjacentHTML('beforeend',
  `<div id="cgPick" class="ov"><div class="card" id="cgPickC"></div></div>`+
  `<div id="cgRide" class="ov"><div id="cgRideT"></div><div id="cgRideS"></div><div id="cgTrain"></div></div>`+
  `<div id="cgCred" class="ov"><div id="cgTrack"></div><button class="btn white" id="cgSkip">Skip ▶</button></div>`);
  q('#world').insertAdjacentHTML('beforeend','<div class="pill" id="cgPill"></div>');}
function pill(){const p=q('#cgPill');if(!C){p.style.display='none';return;}const n=C.line.length;p.style.display='';p.textContent=`💃 ${n}${C.party?'':' / 100'}`;}

/* ============ materials, little models ============ */
const MAT={};
function addMat(c,op){const k=c+op;return MAT[k]||(MAT[k]=new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:op,blending:THREE.AdditiveBlending,depthWrite:false}));}
const RING_C=['#ff4fa0','#ffd23f','#5cb8ff','#7be07b','#b58cff'];
const NUMT={};
function numTex(n){if(NUMT[n])return NUMT[n];const c=document.createElement('canvas');c.width=c.height=128;const x=c.getContext('2d');
  x.fillStyle=RING_C[(n-1)%5];x.strokeStyle='#5b4636';x.lineWidth=8;x.beginPath();x.arc(64,64,56,0,TAU);x.fill();x.stroke();
  x.font=`900 ${n>=100?52:64}px ui-rounded,"Arial Rounded MT Bold",system-ui,sans-serif`;x.textAlign='center';x.textBaseline='middle';x.lineWidth=10;x.strokeText(String(n),64,70);x.fillStyle='#ffffff';x.fillText(String(n),64,70);
  return NUMT[n]=new THREE.CanvasTexture(c);}
function numSprite(n,s){const m=new THREE.SpriteMaterial({map:numTex(n),transparent:true,depthWrite:false});W.disp.push(m);const sp=new THREE.Sprite(m);sp.scale.set(s||2.6,s||2.6,1);return sp;}
function floatNum(n,x,y,z){const sp=numSprite(n,3.4);sp.position.set(x,y,z);scene.add(sp);W.fl.push({sp,t:0,life:1.8});}
function emo(ch,s){const m=new THREE.SpriteMaterial({map:emojiTex(ch),transparent:true,depthWrite:false,fog:false});W.disp.push(m);const sp=new THREE.Sprite(m);sp.scale.set(s,s,1);return sp;}
function noCull(o){o.traverse(m=>{m.frustumCulled=false;});return o;}
/* one instanced shape for every pup's diving helmet, space helmet or ski board */
function extras(kind){const n=110,geo=kind==='board'?G.box:G.sph,mat=kind==='board'?new THREE.MeshLambertMaterial({color:'#3d8fe0'}):new THREE.MeshLambertMaterial({color:'#dff4ff',transparent:true,opacity:.14,depthWrite:false});
  const im=new THREE.InstancedMesh(geo,mat,n);im.frustumCulled=false;im.count=0;W.ag.add(im);W.disp.push(mat);return {kind,im,d:new THREE.Object3D()};}
/* every line pup's shadow is one instanced shape too (saves 100 draw calls) */
function unshadow(l){const g=l.g,m=g.children.find(o=>o.isMesh&&o.geometry===G.disc&&o.position.y<.1);if(!m)return;l.sh=m.scale.x*(g.userData.s||1);
  if(!C.shad){const im=new THREE.InstancedMesh(G.disc,m.material,110);im.frustumCulled=false;im.count=0;W.ag.add(im);C.shad={im,d:new THREE.Object3D()};}g.remove(m);}
function shadowsTick(){const S2=C.shad;if(!S2)return;let i=0;const d=S2.d;C.line.forEach(l=>{if(!l.sh||i>=110)return;d.position.set(l.x,gyC(l)+.05,l.z);d.rotation.set(0,0,0);d.scale.set(l.sh,1,l.sh);d.updateMatrix();S2.im.setMatrixAt(i++,d.matrix);});
  S2.im.count=i;S2.im.instanceMatrix.needsUpdate=true;}
function gyC(l){if(l.cy==null||Math.abs(l.x-l.cx)+Math.abs(l.z-l.cz)>.25){l.cx=l.x;l.cz=l.z;l.cy=walkY(l.x,l.z);}return l.cy;}
function extrasTick(){shadowsTick();const X=C.extra;if(!X)return;let i=0;const put=(g,h)=>{if(i>=110||!g.visible)return;const s=g.userData.s||1,d=X.d;
    if(X.kind==='board'){d.position.set(g.position.x,g.position.y+.06,g.position.z);d.rotation.set(0,h,0);d.scale.set(.75*s,.09,2.1*s);}
    else{d.position.set(g.position.x,g.position.y+1.05*s,g.position.z);d.rotation.set(0,0,0);d.scale.setScalar(1.12*s);}
    d.updateMatrix();X.im.setMatrixAt(i++,d.matrix);};
  C.line.forEach(l=>put(l.g,l.g.rotation.y));if(X.kind==='board')followers.forEach(f=>put(f.grp,f.grp.rotation.y));
  X.im.count=i;X.im.instanceMatrix.needsUpdate=true;}

/* ============ the night party look ============ */
function setLight(L){if(!W.hemi)return;W.hemi.color.set(L.sky);W.hemi.groundColor.set(L.gr);W.hemi.intensity=L.hi;
  const dl=scene.children.find(o=>o.isDirectionalLight);if(dl){dl.color.set(L.dir);dl.intensity=L.di;dl.position.set(L.pos[0],L.pos[1],L.pos[2]);}
  const lp=player.grp.children.find(o=>o.isPointLight);if(lp)lp.intensity=L.lantern||0;}
let STARS=null;
function night(){const A=W.area;if(A.planet)return;
  if(A.swim){scene.background.set('#1f4f8a');scene.fog.color.set('#1f4f8a');setLight({sky:'#c4e6ff',gr:'#21406e',hi:.7,dir:'#d6ecff',di:.36,pos:[-40,80,-30],lantern:1.2});return;}
  scene.background.set('#1c1948');scene.fog.color.set('#1c1948');scene.fog.near=45;scene.fog.far=175;
  setLight({sky:'#9a94f0',gr:'#2c2458',hi:.56,dir:'#ffd6f0',di:.34,pos:[-60,70,-90],lantern:1.5});
  if(!STARS){const n=380,p=new Float32Array(n*3);let sd=777;const R=()=>((sd=(sd*9301+49297)%233280)/233280);for(let i=0;i<n;i++){const az=R()*TAU,el=.08+R()*1.35,d=420;p[i*3]=Math.cos(az)*Math.cos(el)*d;p[i*3+1]=Math.sin(el)*d;p[i*3+2]=Math.sin(az)*Math.cos(el)*d;}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));STARS=new THREE.Points(g,new THREE.PointsMaterial({color:'#ffffff',size:2.2,sizeAttenuation:false,fog:false}));}
  W.ag.add(STARS);const mn=emo('🌕',40);mn.position.set(-150,190,-230);W.ag.add(mn);}
/* sweeping coloured beams round a leg's loop */
function beams(cx,cz,r){const out=[];['#ff4fa0','#5cb8ff','#ffd23f','#7be07b'].forEach((c,i)=>{const a=i*TAU/4+.4,x=cx+Math.sin(a)*r,z=cz+Math.cos(a)*r,pv=grp(),b=new THREE.Mesh(G.cone,addMat(c,.16));
    b.scale.set(4,34,4);b.rotation.x=Math.PI;b.position.y=17;pv.add(b);pv.position.set(x,gy(x,z),z);W.ag.add(noCull(pv));out.push({pv,ph:i*1.7});});
  W.ticks.push(()=>{if(!C)return true;const t=W.t;out.forEach(o=>{o.pv.rotation.set(Math.sin(t*.7+o.ph)*.55,t*.5+o.ph,Math.cos(t*.6+o.ph)*.35);});});}

/* ============ Pawprint Village: the disco ball, the flag and the party ============ */
const FLAG=[8.5,15];
function discoTex(){const c=document.createElement('canvas');c.width=256;c.height=128;const x=c.getContext('2d');
  for(let i=0;i<32;i++)for(let j=0;j<16;j++){const v=150+Math.floor(Math.random()*105),b=Math.random()<.12;x.fillStyle=b?`rgb(${v-40},${v},255)`:`rgb(${v},${v},${v+12})`;x.fillRect(i*8,j*8,7,7);}
  x.fillStyle='#ffffff';for(let k=0;k<14;k++)x.fillRect(Math.floor(Math.random()*32)*8,Math.floor(Math.random()*16)*8,7,7);return new THREE.CanvasTexture(c);}
function villageDay(){/* built on every visit once the tour is open */
  const g=grp(),tex=discoTex(),m=new THREE.MeshBasicMaterial({map:tex});W.disp.push(tex,m);const geo=new THREE.SphereGeometry(1,18,12);W.disp.push(geo);
  const ball=new THREE.Mesh(geo,m);ball.scale.setScalar(2.4);g.add(ball);mk('cyl','#3a3338',.06,1.6,.06,0,2.9,0,g);g.position.set(0,22.6,-4);W.ag.add(g);mk('cyl','#3a3338',.08,1.8,.08,0,20.1,-4,W.ag);
  const glints=[];for(let i=0;i<5;i++){const s=emo('✨',1.4);W.ag.add(s);glints.push(s);}
  BALL={g,ball,glints,rays:null};
  W.ticks.push(dt=>{if(!BALL||BALL.g.parent!==W.ag)return true;const t=W.t;BALL.ball.rotation.y+=dt*.6;BALL.glints.forEach((s,i)=>{const a=t*.9+i*1.26,k=Math.max(0,Math.sin(t*3.1+i*2));s.position.set(Math.cos(a)*2.6,22.6+Math.sin(t*1.3+i)*1.6,-4+Math.sin(a)*2.6);s.scale.setScalar(.4+k*1.5);});
    if(BALL.rays){BALL.rays.rotation.y=-t*.5;}});
  /* the pink paw flag where the tour starts and carries on */
  const fx=FLAG[0],fz=FLAG[1],y=gy(fx,fz),f=grp();mk('cyl','#ff6fb5',.18,7.4,.18,0,3.7,0,f);mk('box','#ff6fb5',2.4,1.5,.1,1.25,6.5,0,f);mk('sph','#ffd23f',.3,.3,.3,0,7.5,0,f);
  const bm=new THREE.Mesh(G.cyl,addMat('#ff9ad0',.2));bm.scale.set(.9,60,.9);bm.position.y=30;f.add(bm);f.position.set(fx,y,fz);W.ag.add(f);col(fx,fz,.5);
  const paw=emo('🐾',1.5);paw.position.set(fx+1.25,y+6.5,fz+.1);W.ag.add(paw);const lb=label('🪩 Conga World Tour',7.5,'#ffd6f2');lb.position.set(fx,y+9.2,fz);W.ag.add(lb);
  W.things.push({x:fx,z:fz+1.2,r:4.2,icon:'🪩',label:'Conga!',act:openTour});}
function villageNight(R){/* lights over the plaza, rays from the ball, DJ Muddle and the dancing unicorns */
  const far=(x,z,d)=>!R||[R.start].concat(R.rings).every(p=>Math.hypot(x-p.x,z-p.z)>=d);
  const poles=[],bulbs=[];for(let k=0;k<8;k++){const a=(k+.5)*TAU/8;let pt=null;for(let r=17;r<=20&&!pt;r+=.75)if(clearPt(Math.sin(a)*r,Math.cos(a)*r,.8)&&far(Math.sin(a)*r,Math.cos(a)*r,3))pt=[Math.sin(a)*r,Math.cos(a)*r];poles.push(pt||[Math.sin(a)*17,Math.cos(a)*17]);}
  const pm=new THREE.InstancedMesh(G.cyl,M('#d9b48a'),8),d=new THREE.Object3D();poles.forEach((p,i)=>{d.position.set(p[0],gy(p[0],p[1])+4.6,p[1]);d.rotation.set(0,0,0);d.scale.set(.1,9.2,.1);d.updateMatrix();pm.setMatrixAt(i,d.matrix);col(p[0],p[1],.35);});
  pm.frustumCulled=false;W.ag.add(pm);
  const top=p=>[p[0],gy(p[0],p[1])+9.2,p[1]];
  const str=(a,b,n,sag)=>{for(let i=1;i<n;i++){const u=i/n;bulbs.push([a[0]+(b[0]-a[0])*u,a[1]+(b[1]-a[1])*u-sag*4*u*(1-u),a[2]+(b[2]-a[2])*u]);}};
  poles.forEach((p,i)=>{const dx=p[0],dz=p[1]+4,dd=Math.hypot(dx,dz)||1;str([dx/dd*2.4,11.8,-4+dz/dd*2.4],top(p),14,.7);str(top(p),top(poles[(i+1)%8]),8,.5);});
  const bmesh=new THREE.InstancedMesh(G.sph,new THREE.MeshBasicMaterial({color:'#ffffff'}),bulbs.length);W.disp.push(bmesh.material);const cols=['#ff4fa0','#ffd23f','#5cb8ff','#7be07b','#ff9b3a','#c58cff'].map(c=>new THREE.Color(c));
  bulbs.forEach((b,i)=>{d.position.set(b[0],b[1],b[2]);d.scale.setScalar(.2);d.updateMatrix();bmesh.setMatrixAt(i,d.matrix);bmesh.setColorAt(i,cols[i%cols.length]);});bmesh.frustumCulled=false;W.ag.add(bmesh);
  let tw=0;W.ticks.push(dt=>{if(!C)return true;tw+=dt;if(tw<.45)return;tw=0;const o=Math.floor(W.t*2.2);bulbs.forEach((b,i)=>bmesh.setColorAt(i,cols[(i+o)%cols.length]));bmesh.instanceColor.needsUpdate=true;});
  /* rays of light from the disco ball */
  if(BALL){const R=grp();['#ff4fa0','#5cb8ff','#ffd23f','#7be07b','#c58cff','#ff9b3a'].forEach((c,i)=>{const pv=grp(),tilt=grp(),b=new THREE.Mesh(G.cone,addMat(c,.13));b.scale.set(3.4,30,3.4);b.position.y=-15;tilt.rotation.x=1.05;tilt.add(b);pv.add(tilt);pv.rotation.y=i*TAU/6;R.add(pv);});
    R.position.set(0,22.6,-4);W.ag.add(noCull(R));BALL.rays=R;}
  /* DJ Muddle */
  const bx=-6,bz=1,by=gy(bx,bz),b=grp();b.rotation.y=Math.atan2(-bx+0,12-bz);mk('box','#3a3338',3.4,1.2,1.3,0,.6,0,b);mk('box','#ff6fb5',3.42,.22,1.32,0,.95,0,b);
  const tts=[-.8,.8].map(x=>{const t=mk('cyl','#26232e',.46,.08,.46,x,1.25,0,b);mk('box','#ffd23f',.08,.1,.3,x,1.32,.2,b);return t;});
  const spk=[-2.4,2.4].map(x=>{const s=grp();s.position.set(x,0,0);mk('box','#26232e',1,1.9,.9,0,.95,0,s);mk('cyl','#5b6378',.32,.06,.32,0,1.35,.46,s).rotation.x=Math.PI/2;mk('cyl','#5b6378',.22,.06,.22,0,.6,.46,s).rotation.x=Math.PI/2;b.add(s);return s;});
  const mg=magpie3D();mg.scale.setScalar(1.35);mg.position.set(0,.35,-1.25);b.add(mg);const hp=new THREE.Mesh(G.band,M('#ff4fa0'));hp.scale.setScalar(.42);hp.position.set(0,1.98,.32);hp.rotation.y=Math.PI/2;mg.add(hp);
  [-1,1].forEach(s=>mk('cyl','#ff4fa0',.16,.12,.16,s*.38,1.78,.34,mg).rotation.z=Math.PI/2);
  add(b,bx,bz,by);col(bx,bz,2);col(bx-2.2,bz+1.2,.9);col(bx+2.2,bz-1.2,.9);const dl=label('🎧 DJ Muddle',6,'#ffd6f2');dl.position.set(bx,by+5.4,bz);W.ag.add(dl);
  W.ticks.push(()=>{if(!C)return true;const t=W.t,beat=Math.abs(Math.sin(t*Math.PI/.6));tts.forEach(o=>{o.rotation.y=t*6;});spk.forEach(s=>s.scale.set(1+beat*.06,1+beat*.06,1+beat*.06));
    mg.position.y=.35+beat*.25;mg.rotation.y=Math.sin(t*1.7)*.5;if(Math.random()<.012)floatS(pick(['🎵','🎶']),bx+(Math.random()-.5)*3,by+3.4,bz,1.6);});
  /* all nine unicorns dancing round the plaza */
  const unis=[];ISLANDS.forEach((I,i)=>{const u=I.boss&&I.boss.uni;if(!u)return;let a=(i+.5)*TAU/9,pt=null;
    for(let r=14.5;r<=19&&!pt;r+=1.1)for(const da of [0,.12,-.12,.24,-.24]){const x=Math.sin(a+da)*r,z=Math.cos(a+da)*r;if(clearPt(x,z,1.8)&&far(x,z,4)){pt=[x,z];break;}}
    if(!pt)return;const g=pup3D(u,true);add(g,pt[0],pt[1]);g.rotation.y=Math.atan2(-pt[0],-pt[1]);col(pt[0],pt[1],1.2);unis.push({g,x:pt[0],z:pt[1],ph:i*.7});});
  W.ticks.push(()=>{if(!C)return true;const t=W.t;unis.forEach((u,i)=>{animPup(u.g,t,true);u.g.position.y=gy(u.x,u.z)+Math.abs(Math.sin(t*5.2+u.ph))*.5;
    const sp=(t*.35+u.ph)%6<1?((t*.35+u.ph)%6)*TAU:0;u.g.rotation.y=Math.atan2(-u.x,-u.z)+Math.sin(t*2+u.ph)*.35+sp;});});}

/* ============ routes ============ */
function clearPt(x,z,m){const A=W.area;m=m==null?2:m;
  for(const o of W.cols)if(Math.hypot(wrapD(x-o.x),wrapD(z-o.z))<o.r+m)return false;
  for(const r of W.rects)if(x>r.x1-m&&x<r.x2+m&&z>r.z1-m&&z<r.z2+m)return false;
  if(!A.planet){if(A.rect){const B=A.rect;if(x<B.x1+4||x>B.x2-4||z<B.z1+4||z>B.z2-4)return false;}else if(Math.hypot(x,z)>A.R-5)return false;}
  for(const e of (C&&C.keep?C.keep.exits:W.exits))if(Math.hypot(wrapD(x-e.x),wrapD(z-e.z))<8)return false;
  return true;}
function freePt(p,c){const ok=(x,z)=>clearPt(x,z,1.2);if(ok(p.x,p.z))return p;const dx=p.x-c[0],dz=p.z-c[1],d=Math.hypot(dx,dz)||1,ux=dx/d,uz=dz/d;
  for(let s=1;s<=8;s++)for(const sg of [1,-1]){const x=p.x+ux*s*sg,z=p.z+uz*s*sg;if(ok(x,z))return {x,z};}
  for(let s=1;s<=6;s++)for(const sg of [1,-1]){const x=p.x-uz*s*sg,z=p.z+ux*s*sg;if(ok(x,z))return {x,z};}
  return p;}
function route(L){const A=W.area;
  if(L.ski){const S2=A.ski;return {ski:true,start:{x:S2.start[0],z:S2.start[1]},a0:0,rings:S2.gates.slice(0,10).map(g=>({x:g[0],z:g[1]}))};}
  const c=L.c,r=L.r,st=TAU/10,a0=-.45*st,pt=a=>({x:c[0]+r[0]*Math.sin(a),z:c[1]+r[1]*Math.cos(a)});
  const rings=[];for(let k=1;k<=10;k++)rings.push(freePt(pt(k*st),c));
  return {start:freePt(pt(a0),c),a0,rings};}
/* where the pups already in the conga stand at the start of a leg: coiled up behind Seb */
function backPath(L,R,need){const pts=[];let len=0,px=R.start.x,pz=R.start.z;const push=(x,z)=>{len+=Math.hypot(x-px,z-pz);px=x;pz=z;pts.push({x,z,y:null});};
  if(R.ski){const z0=R.start.z;for(let row=0;row<6&&len<need;row++){const zr=z0-1.6-row*2.2,xs=row%2?[28,-28]:[-28,28];for(let u=0;u<=1.0001&&len<need+5;u+=.05)push(xs[0]+(xs[1]-xs[0])*u,zr);}return pts;}
  const c=L.c||[0,0],r=L.r||[11,11];for(let j=1;j<3000&&len<need+5;j++){const a=R.a0-j*.07,gr=2.6+j*.07/TAU*2.8;push(c[0]+(r[0]+gr)*Math.sin(a),c[1]+(r[1]+gr)*Math.cos(a));}
  return pts;}

/* ============ starting and ending a leg ============ */
function keepCam(A,d,h){C.cam={A,had:[('camD' in A),('camH' in A)],d:A.camD,h:A.camH};A.camD=d;A.camH=h;}
function endC(){if(!C)return;const K=C.cam;if(K){if(K.had[0])K.A.camD=K.d;else delete K.A.camD;if(K.had[1])K.A.camH=K.h;else delete K.A.camH;}
  if(C.L&&C.L.ski&&player.ski&&C.skiOwn){player.ski=null;skiKit(false);}
  followers.forEach(f=>{f.grp.visible=true;});music(false);C=null;pill();}
function newC(o){C=Object.assign({mode:'free',li:-1,L:null,pv:false,picks:[],idx:0,rings:[],line:[],trail:[],inLine:new Set(),t:0,wx:null,snap:true,keep:null,extra:null},o);C.area=W.area.id;return C;}
function stash(){C.keep={things:W.things,spots:W.spots,exits:W.exits};W.things=[];W.spots=[];W.exits=[];}
function unstash(){if(!C||!C.keep)return;W.things=C.keep.things.concat(W.things);W.spots=C.keep.spots;W.exits=C.keep.exits;C.keep=null;}
function noWanderers(){(W.wanderers||[]).forEach(w=>W.ag.remove(w.grp));W.wanderers=[];}
function buildLine(ids){ids.slice().reverse().forEach(id=>{const p=PUPS[id];if(!p)return;const g=pup3D(p,p.shiny||bestFriend(p.id));if(W.area.planet)noCull(g);W.ag.add(g);
  const l={p,g,x:player.x,z:player.z,h:0,jump:0};unshadow(l);C.line.push(l);C.inLine.add(id);});}
function placeSeb(s,face){const P=player,A=W.area;P.x=s.x;P.z=s.z;P.h=face;W.camYaw=face;P.y=walkY(s.x,s.z)+(A.swim?1.2:0);syncFollowers(true);camUpdate(0,true);}
function startTrail(L,R){const need=(C.line.length+followers.length+2)*1.8+6;C.trail=[{x:player.x,z:player.z,y:player.y}].concat(C.line.length?backPath(L,R,need):[]);
  if(W.area.swim)C.trail.forEach(p=>{if(p.y==null)p.y=walkY(p.x,p.z)+1.2;});}

function enterLeg(li,picks,pv){const L=LEGS[li],I=ISL(L);
  INLEG=pv?'pv':true;const line0=I?`All aboard ${rideName(L)}! Next stop, ${legName(L)}!`:'Party time in Pawprint Village!';
  try{enterArea(L.area,null,line0);}finally{INLEG=false;}
  const A=W.area;if(!A||A.id!==L.area)return;
  newC({mode:'leg',li,L,pv,picks});stash();noWanderers();
  const R=route(L);C.R=R;if(L.k==='village')villageNight(R);
  const n1=R.rings[0];placeSeb(R.start,R.ski?0:Math.atan2(wrapD(n1.x-R.start.x),wrapD(n1.z-R.start.z)));
  keepCam(A,(A.camD||11)+(L.k==='village'?0:2),(A.camH||5.4)+(L.k==='village'?.4:1.2));
  night();if(L.k!=='village')beams(L.c?L.c[0]:0,L.c?L.c[1]:0,L.c?Math.max(L.r[0],L.r[1])+7:12);
  if(A.swim||A.planet)C.extra=extras('bub');else if(L.ski)C.extra=extras('board');
  buildLine(lineIds(pv));startTrail(L,R);buildRings(R,picks,li);
  W.ticks.push(tick);music(true);pill();player.lock=true;}
function legIntro(){if(!C||C.mode!=='leg')return;const L=C.L,n=C.li+1;
  if(L.k==='village')say('Muddle is the DJ tonight, and the unicorns are dancing! Walk through the glowing rings. A pup is waiting at every ring. Follow the light beam!');
  else if(L.ski){say(`Leg 3! ${L.say} Steer through the rings. 3, 2, 1, go!`);setTimeout(skiGo,3600);}
  else say(`Leg ${n}! ${L.say} Follow the light beam to the next ring!`);}
function skiGo(){if(!C||!C.L||!C.L.ski||C.mode!=='leg'||player.ski||cur!=='world')return;const R=C.R;player.x=R.start.x;player.z=R.start.z;player.h=0;W.camYaw=0;skiKit(true,false);
  player.ski={t:0,v:3,vx:0,passed:0,gates:[],lastZ:player.z};C.skiOwn=true;sfx.chime();hud();}

/* the ten rings, each with a pup waiting beside it */
function buildRings(R,picks,li){const A=W.area,bub=A.swim||A.planet;R.rings.forEach((r,k)=>{const nx=R.rings[k+1],pv=k?R.rings[k-1]:R.start,dx=wrapD((nx||r).x-pv.x),dz=wrapD((nx||r).z-pv.z),h=R.ski?0:Math.atan2(dx,dz);
  const y=gy(r.x,r.z),g=grp();g.position.set(r.x,y,r.z);g.rotation.y=h;
  const ri=new THREE.Mesh(G.tor,new THREE.MeshBasicMaterial({color:RING_C[k%5]}));W.disp.push(ri.material);ri.scale.set(2.1,2.1,.7);ri.position.y=2.4;g.add(ri);
  const p=picks[k],m=pup3D(p,p.shiny||bestFriend(p.id)),off=R.ski?5:3.1;m.position.set(off,0,0);m.rotation.y=-Math.PI/2;g.add(m);
  let hb=null;if(bub){hb=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#dff4ff',transparent:true,opacity:.22,depthWrite:false}));W.disp.push(hb.material);const s=m.userData.s||1;hb.scale.setScalar(1.12*s);hb.position.set(off,1.05*s,0);g.add(hb);}
  const bm=new THREE.Mesh(G.cyl,addMat('#fff2a8',.24));bm.scale.set(.95,60,.95);bm.position.y=30;bm.visible=false;g.add(bm);W.ag.add(A.planet?noCull(g):g);
  const num=numSprite(li*10+k+1);num.position.set(r.x,y+5.6,r.z);W.ag.add(num);
  C.rings.push({x:r.x,z:r.z,y,g,ri,m,hb,bm,num,p,k,h,off});});}

/* ============ every frame ============ */
function sample(ds){const P=player,tr=C.trail,out=[];let a=0,px=P.x,pz=P.z,py=P.y,k=0;
  for(let i=0;i<ds.length;i++){const d=ds[i];let got=null;
    while(k<tr.length){const q2=tr[k],s=Math.hypot(q2.x-px,q2.z-pz);if(a+s>=d){const e=(d-a)/(s||1);got={x:px+(q2.x-px)*e,z:pz+(q2.z-pz)*e,y:py+((q2.y==null?py:q2.y)-py)*e,hx:px,hz:pz};break;}a+=s;px=q2.x;pz=q2.z;py=q2.y==null?py:q2.y;k++;}
    out.push(got||{x:px,z:pz,y:py,hx:px,hz:pz,end:true});}
  if(k+30<tr.length)tr.length=k+30;return out;}
function shift(sx,sz){C.trail.forEach(p=>{p.x+=sx;p.z+=sz;});C.line.forEach(l=>{l.x+=sx;l.z+=sz;});if(C.dc){C.dc.x+=sx;C.dc.z+=sz;}}
function tick(dt){if(!C||!W.area||W.area.id!==C.area)return true;const P=player,t=W.t,A=W.area;C.t+=dt;
  if(A.planet){const Lp=A.planet.L;if(C.wx!=null){const ex=P.x-C.wx,ez=P.z-C.wz;const sx=ex>Lp/2?Lp:ex<-Lp/2?-Lp:0,sz=ez>Lp/2?Lp:ez<-Lp/2?-Lp:0;if(sx||sz)shift(sx,sz);}C.wx=P.x;C.wz=P.z;}
  if(C.mode==='dance'){danceTick(dt,t);extrasTick();return false;}
  const tr=C.trail,h0=tr[0];if(!h0||Math.hypot(P.x-h0.x,P.z-h0.z)>.3)tr.unshift({x:P.x,z:P.z,y:P.y});
  const fl=followers.filter(f=>!C.inLine.has(f.id));followers.forEach(f=>{if(C.inLine.has(f.id))f.grp.visible=false;});
  const ds=[];fl.forEach((f,i)=>ds.push(2.3+i*2));const base=fl.length?2.3+(fl.length-1)*2+1.9:1.9;C.line.forEach((l,i)=>ds.push(base+i*1.6));
  const Sm=sample(ds);
  fl.forEach((f,i)=>{const s=Sm[i];f.x=s.x;f.z=s.z;const hx=s.hx-s.x,hz=s.hz-s.z;if(hx*hx+hz*hz>1e-6)f.h=Math.atan2(hx,hz);f.grp.visible=true;
    const fy=A.swim?(f.y!=null?f.y:P.y):walkY(f.x,f.z);f.grp.position.set(f.x,fy,f.z);f.grp.rotation.y=f.h;});
  const k=C.snap?1:Math.min(1,dt*(P.ski?14:9));
  C.line.forEach((l,i)=>{const s=Sm[fl.length+i];l.x+=(s.x-l.x)*k;l.z+=(s.z-l.z)*k;let y=gyC(l);if(A.swim)y=Math.max(y+.2,(s.y!=null?s.y:y)-.5);
    if(l.jump>0)l.jump=Math.max(0,l.jump-dt*1.8);const hop=Math.abs(Math.sin(t*7.7+i*.55))*.26+(l.jump>0?Math.sin((1-l.jump)*Math.PI)*1.6:0);
    l.g.position.set(l.x,y+hop,l.z);const hx=s.hx-s.x,hz=s.hz-s.z;if(hx*hx+hz*hz>1e-6)l.h=Math.atan2(hx,hz);l.g.rotation.set(0,l.h,Math.sin(t*3.85+i*.5)*.14);});
  C.snap=false;extrasTick();
  if(C.L&&C.L.ski){q('#wAct').style.display='none';if(C.mode!=='leg'&&P.ski&&C.skiOwn){P.ski.v=Math.max(0,P.ski.v-dt*16);if(P.ski.v<1.2){P.ski=null;C.skiOwn=false;skiKit(false);hud();}}}
  if(C.mode==='leg')ringsTick(dt,t);
  return false;}
function ringsTick(dt,t){const P=player;C.rings.forEach((w,k)=>{if(w.gone)return;const nx=k===C.idx;w.bm.visible=nx;const sc=nx?1+Math.sin(t*6)*.08:1;w.ri.scale.set(2.1*sc,2.1*sc,.7);w.ri.rotation.z=t*.8;
    animPup(w.m,t,false);w.m.position.y=Math.abs(Math.sin(t*4+k))*.4;w.m.rotation.y=-Math.PI/2+Math.sin(t*2+k)*.6;if(w.hb)w.hb.position.y=w.m.position.y+1.05*(w.m.userData.s||1);
    w.num.position.y=w.y+5.6+(nx?Math.sin(t*4)*.3:0);const cd=Math.hypot(wrapD(cam.position.x-w.x),wrapD(cam.position.z-w.z));w.g.visible=cd>6;w.num.visible=cd>4.5;});
  const w=C.rings[C.idx];if(!w)return;
  const hit=C.R.ski?P.z>=w.z:Math.hypot(wrapD(P.x-w.x),wrapD(P.z-w.z))<2.9;if(hit)join(w);}
function join(w){C.idx++;w.gone=true;const wp=new THREE.Vector3();w.m.getWorldPosition(wp);
  w.g.remove(w.m);W.ag.remove(w.g);W.ag.remove(w.num);const m=w.m;m.position.copy(wp);m.rotation.set(0,0,0);W.ag.add(m);
  const l={p:w.p,g:m,x:wp.x,z:wp.z,h:w.h,jump:1};unshadow(l);C.line.unshift(l);C.inLine.add(w.p.id);
  const n=C.li*10+C.idx;sfx.pop();sfx.yip(w.p.pitch||1);floatNum(n,w.x,w.y+5,w.z);for(let i=0;i<5;i++)floatS(pick(['✨','🎉','⭐','💖']),w.x+(Math.random()-.5)*4,w.y+1+Math.random()*3,w.z+(Math.random()-.5)*4,1.6,1.2);
  const through=!C.R.ski||Math.abs(player.x-w.x)<4;
  say(C.idx<10?`${n}! ${w.p.name} joins the conga!${through?'':' Hop on!'}`:`${n}! ${w.p.name} joins the conga!`);pill();
  if(C.idx>=10)legDone();}

/* ============ a leg is done ============ */
function legDone(){const li=C.li,n=(li+1)*10;C.mode='done';player.cheer=2.5;sfx.fanfare();confetti(90);C.line.forEach((l,i)=>{setTimeout(()=>{if(C)l.jump=1;},i*25);});
  if(!C.pv){const s=S(),first=!s.done;s.pups=s.pups.concat(C.picks.map(p=>p.id));s.leg=li+1;s.best=Math.max(s.best,li+1);delete s.next;delete s.nextLeg;
    if(first)state.stars+=20;if(li===9){if(first)state.stars+=100;s.done=s.done||Date.now();}save();hud();}
  else PV.line=PV.line.concat(C.picks.map(p=>p.id));
  setTimeout(()=>{if(!C||C.mode!=='done')return;say(li===9?`${n}! One hundred pups! The biggest conga in the whole universe!`:`${n} pups in the conga! Leg ${li+1} done!`);},900);
  const me=C;setTimeout(()=>{if(C!==me)return;if(li===9)finaleCard();else legCard(li);},li===9?3400:3000);}
function legCard(li){const n=(li+1)*10,L2=LEGS[li+1];player.lock=true;
  card({art:legRow(li+1),h:`🎉 Leg ${li+1} done!`,p:`${n} pups in the Great Pup Conga! Next stop: ${legName(L2)}, on ${rideName(L2)}.`,
    btns:[['▶ Next leg!','green',()=>openPick(li+1,C?C.pv:false)],[C&&C.pv?'⏹ End preview':'💃 Dance here','white',()=>{if(C&&C.pv){endPreview();return;}freeMode();}]]});}
function freeMode(){if(!C)return;C.mode='free';player.lock=false;unstash();C.rings.forEach(w=>{if(!w.gone){W.ag.remove(w.g);W.ag.remove(w.num);}});C.rings=[];
  say(C.pv?'Preview: the conga follows you here.':'Dance round with your conga! When you want the next leg, tap the pink paw flag in Pawprint Village.');}
function legRow(nx){return `<div class="cgLegs">${LEGS.map((L,i)=>`<i class="${i<nx?'done':i===nx?'nx':''}">${legIcon(L)}</i>`).join('')}</div>`;}

/* ============ the picker ============ */
let P=null;
function openPick(li,pv){if(li>=10)return;const used=new Set(lineIds(pv)),all=pool(pv).filter(p=>!used.has(p.id)),L=LEGS[li],isl=L.k==='village'?null:L.k;
  const by={};ISLANDS.forEach(I=>{by[I.id]=all.filter(p=>p.island===I.id).sort((a,b)=>(a.sci?1:0)-(b.sci?1:0));});
  const fut=new Set(LEGS.slice(li+1).map(l=>l.k)),own=!!isl&&by[isl].length>=10;
  const tabs=(own?[isl]:isl?[isl].concat(ISLANDS.map(I=>I.id).filter(k=>k!==isl)):ISLANDS.map(I=>I.id)).filter(k=>by[k]&&by[k].length);
  if(!tabs.length){sfx.oops();say('There are no more pups to pick!');return;}
  const s=pv?null:S(),pre=s&&s.next&&s.nextLeg===li?s.next.filter(id=>all.some(p=>p.id===id)):[];
  P={li,pv,by,all,fut,tabs,tab:tabs[0],sel:pre.slice(0,10),own,isl};player.lock=true;hush();drawPick();q('#cgPick').classList.add('on');
  speak(li?`Leg ${li+1}! Pick ten pups${own?` from ${legName(L)}`:''} to join the conga. Tap your favourites, or tap Surprise me.`:'Pick ten of your favourite pups to start the conga! Tap your favourites, or tap Surprise me.');}
function capLeft(k){if(!P.fut.has(k))return 99;return Math.max(0,P.by[k].length-10)-P.sel.filter(id=>PUPS[id].island===k).length;}
function drawPick(){const L=LEGS[P.li],n=P.sel.length,base=P.li*10,g0=q('#cgPickC .cgGrid'),sc=g0?g0.scrollTop:0,keep=P.keep;P.keep=false;
  let h=`<h2>🐾 Leg ${P.li+1}: ${legName(L)}</h2><div class="cgSub">${P.li?(P.own?`Pick 10 pups from ${legName(L)} to join the conga!`:'Pick 10 pups to join the conga!'):'Pick 10 of your favourite pups to start the conga!'}</div><div class="cgCnt">${n} of 10 picked</div>`;
  if(P.tabs.length>1)h+=`<div class="cgTabs">${P.tabs.map(k=>{const I=islandOf(k),c=P.sel.filter(id=>PUPS[id].island===k).length;return `<button class="cgTab${k===P.tab?' on':''}" data-k="${k}">${I.icon}${c?`<b>${c}</b>`:''}</button>`;}).join('')}</div>`;
  h+=`<div class="cgGrid">${P.by[P.tab].map(p=>{const i=P.sel.indexOf(p.id);return `<button class="cgPup${i>=0?' sel':''}" data-id="${p.id}">${pupBox(p,{anim:false})}<span${p.name.length>11?' class="lg"':''}>${p.name}</span>${i>=0?`<b>${base+i+1}</b>`:''}</button>`;}).join('')}</div>`;
  h+=`<div class="btns"><button class="btn blue" data-b="sur">🎲 Surprise me</button><button class="btn green${n<10?' dim':''}" data-b="go">Let's conga! ▶</button><button class="btn white" data-b="no">Not now</button></div>`;
  const c=q('#cgPickC');c.innerHTML=h;if(keep)c.querySelector('.cgGrid').scrollTop=sc;}
q('#cgPickC').addEventListener('click',ev=>{if(!P)return;initAudio();const t=ev.target.closest('button');if(!t)return;
  if(t.classList.contains('cgTab')){P.tab=t.dataset.k;sfx.boop();drawPick();return;}
  if(t.classList.contains('cgPup')){const id=t.dataset.id,p=PUPS[id],i=P.sel.indexOf(id);P.keep=true;
    if(i>=0){P.sel.splice(i,1);sfx.boop();drawPick();return;}
    if(P.sel.length>=10){sfx.oops();say('You have 10 pups! Tap a pup to take it out, or tap Let\'s conga!');return;}
    if(capLeft(p.island)<=0){const I=islandOf(p.island);sfx.oops();say(`Save the other ${I.name} pups for the ${I.name} leg! Pick some from another island.`);return;}
    P.sel.push(id);sfx.pop();sfx.yip(p.pitch||1);drawPick();if(P.sel.length===10)say('10 pups! Tap Let\'s conga!');return;}
  const b=t.dataset.b;
  if(b==='sur'){sfx.chime();const put=list=>mix(list).forEach(p=>{if(P.sel.length<10&&P.sel.indexOf(p.id)<0&&capLeft(p.island)>0)P.sel.push(p.id);});
    if(P.isl)put(P.by[P.isl]);put(P.tabs.reduce((a,k)=>a.concat(P.by[k]),[]));if(P.sel.length<10)put(P.all);P.keep=true;drawPick();say('Surprise! Here are your conga pups. Tap Let\'s conga!');return;}
  if(b==='go'){if(P.sel.length<10){sfx.oops();const m=10-P.sel.length;say(`Pick ${m} more pup${m===1?'':'s'}, or tap Surprise me.`);return;}
    sfx.pop();if(!P.pv){const s=S();s.next=P.sel.slice();s.nextLeg=P.li;save();}const li=P.li,pv=P.pv,picks=P.sel.map(id=>PUPS[id]);closePick();goLeg(li,picks,pv);return;}
  if(b==='no'){sfx.boop();const pv=P.pv;if(!pv){const s=S();if(P.sel.length){s.next=P.sel.slice();s.nextLeg=P.li;save();}}closePick();player.lock=false;
    if(C&&C.mode==='done')freeMode();else if(pv)endPreview();else if(cur==='world')say('The pink paw flag in the village plaza is waiting for you, whenever you are ready!');}});
function closePick(){q('#cgPick').classList.remove('on');P=null;}

/* ============ the ride between legs ============ */
function goLeg(li,picks,pv){const L=LEGS[li],I=ISL(L),o=q('#cgRide');player.lock=true;hush();closeOv('cele');
  const veh=I?I.rideIcon:'🪩',flip=/✈️|🚀/.test(veh);
  q('#cgRideT').textContent=I?`All aboard ${rideName(L)}!`:'🪩 Party time!';q('#cgRideS').textContent=I?`Next stop: ${legName(L)} ${legIcon(L)}`:'Pawprint Village, at night!';
  q('#cgTrain').innerHTML=`<span class="veh${flip?' fl':''}">${veh}</span>`+picks.map((p,i)=>`<div class="pp" style="animation-delay:${-i*.13}s">${pupBox(p,{anim:false})}</div>`).join('');
  const tr=q('#cgTrain');tr.style.animation='none';void tr.offsetWidth;tr.style.animation='';
  o.classList.remove('off');o.classList.add('on');sfx.chime();
  setTimeout(()=>{try{enterLeg(li,picks,pv);}catch(e){console.error(e);}},140);
  setTimeout(()=>{o.classList.add('off');setTimeout(()=>{o.classList.remove('on','off');if(C&&C.mode==='leg'){player.lock=false;legIntro();}},400);},3600);}

/* ============ the finale on the Moon ============ */
function finaleCard(){player.lock=true;card({art:'<div style="font-size:120px;line-height:1">💯</div>',h:'One hundred pups!',p:'The biggest conga in the whole universe! Let\'s all dance under the Earth!',
  btns:[['🕺 Dance!','green',()=>fadeTo(danceStart,['🪩','Dance time!'])]]});}
function danceSpot(){const c=C.L.c;let best=null,bs=-1e9;for(let gx=-12;gx<=12;gx+=3)for(let gz=-12;gz<=12;gz+=3){const x=c[0]+gx,z=c[1]+gz;let m=14;
    W.cols.forEach(o=>{m=Math.min(m,Math.hypot(wrapD(x-o.x),wrapD(z-o.z))-o.r);});(C.keep?C.keep.exits:W.exits).forEach(e=>{m=Math.min(m,Math.hypot(wrapD(x-e.x),wrapD(z-e.z))-3);});
    const sc=m-Math.hypot(gx,gz)*.05;if(sc>bs){bs=sc;best={x,z};}}return best;}
function danceStart(){if(!C)return;const P2=player,c=danceSpot();C.mode='dance';C.dc=c;C.d0=W.t;C.rings.forEach(w=>{if(!w.gone){W.ag.remove(w.g);W.ag.remove(w.num);}});C.rings=[];
  placeSeb({x:c.x,z:c.z},Math.PI);P2.lock=true;const A=W.area;A.camD=19;A.camH=9;
  const R3s=[[5.2,24],[7.8,34],[10.4,42]],n=C.line.length;let at=0;
  R3s.forEach((r,m)=>{const cnt=m<2?Math.round(n*r[1]/100):n-at;for(let j=0;j<cnt&&at<n;j++,at++){const l=C.line[at];l.ring=r[0];l.w=(m%2?-1:1)*(.32-m*.05);l.a0=j/cnt*TAU;}});
  danceTick(0,W.t);camUpdate(0,true);beams(c.x,c.z,15);
  if(!C.pv){const s=S();if(bhDone()&&!s.zuzu){s.zuzu=Date.now();save();}}
  const zz=bhDone()||C.pv;say('Everybody dance! One hundred pups, under the Earth!');sfx.jingle();confetti(80);
  const me=C;if(zz)setTimeout(()=>{if(C===me)zuzuArrive();},3000);
  setTimeout(()=>{if(C===me)endCard(zz);},zz?17000:11000);}
function danceTick(dt,t){const c=C.dc,P2=player;
  C.line.forEach((l,i)=>{const a=l.a0+l.w*(t-C.d0),x=c.x+Math.cos(a)*l.ring,z=c.z+Math.sin(a)*l.ring,sg=l.w>0?1:-1;l.x=x;l.z=z;l.h=Math.atan2(-Math.sin(a)*sg,Math.cos(a)*sg);
    l.g.position.set(x,gyC(l)+Math.abs(Math.sin(t*7.7+i*.55))*.35,z);l.g.rotation.set(0,l.h,Math.sin(t*3.85+i*.5)*.18);});
  followers.forEach((f,i)=>{const a=t*.8+i*TAU/Math.max(1,followers.length),x=c.x+Math.cos(a)*2,z=c.z+Math.sin(a)*2;f.x=x;f.z=z;f.h=a+Math.PI;f.grp.visible=true;f.grp.position.set(x,walkY(x,z)+Math.abs(Math.sin(t*6+i))*.4,z);f.grp.rotation.y=Math.atan2(c.x-x,c.z-z);});
  P2.cheer=Math.max(P2.cheer||0,.6);if(C.zz&&C.zz.t<11)W.camYaw=lerpAng(W.camYaw,Math.PI,Math.min(1,dt*1.5));else W.camYaw+=dt*.2;
  if(Math.random()<dt*.25)confetti(14);if(Math.random()<dt*1.5)floatS(pick(['🎵','🎶','✨','💖','⭐']),c.x+(Math.random()-.5)*20,walkY(c.x,c.z)+2+Math.random()*3,c.z+(Math.random()-.5)*20,1.8);
  if(C.zz)zuzuTick(dt,t);}
function wormhole(){const g=grp(),cv=document.createElement('canvas');cv.width=cv.height=128;const x=cv.getContext('2d'),gr=x.createRadialGradient(64,64,4,64,64,64);
  gr.addColorStop(0,'#000000');gr.addColorStop(.35,'#1a0a3a');gr.addColorStop(.6,'#8a4fff');gr.addColorStop(.8,'#ff9be6');gr.addColorStop(1,'rgba(0,0,0,0)');x.fillStyle=gr;x.fillRect(0,0,128,128);
  const tx=new THREE.CanvasTexture(cv),m=new THREE.MeshBasicMaterial({map:tx,transparent:true,depthWrite:false,side:THREE.DoubleSide});W.disp.push(tx,m);
  const d=new THREE.Mesh(G.disc,m);d.rotation.x=Math.PI/2;d.scale.set(9,1,9);g.add(d);const r1=new THREE.Mesh(G.tor,addMat('#c58cff',.7));r1.scale.set(8,8,1.2);g.add(r1);const r2=new THREE.Mesh(G.tor,addMat('#ff9be6',.6));r2.scale.set(6,6,1);g.add(r2);
  g.userData={r1,r2,d};return noCull(g);}
function zuzuArrive(){const BH=window.BHQ;if(!BH||!BH.stargazer3D||!BH.ZUZU)return;const c=C.dc,wh=wormhole(),sy=walkY(c.x,c.z-38)+20;wh.position.set(c.x,sy,c.z-38);wh.scale.setScalar(.01);W.ag.add(wh);
  const sh=noCull(BH.stargazer3D({map:true}));sh.position.set(c.x,sy,c.z-38);sh.visible=false;W.ag.add(sh);C.zz={wh,sh,t:0,land:{x:c.x,z:c.z-18.5},sy,pups:[],out:false};
  sfx.chime();say('Look up! Something is coming through a wormhole!');}
function zuzuTick(dt,t){const Z=C.zz,c=C.dc;Z.t+=dt;const u=Z.wh.userData;Z.wh.userData.r1.rotation.z=t*2;u.r2.rotation.z=-t*3;
  const wk=Z.t<1.2?Z.t/1.2:Z.t<5?1:Math.max(.01,1-(Z.t-5)/1);Z.wh.scale.setScalar(Math.max(.01,wk));
  if(Z.t>1.2&&Z.t<4.6){const k=(Z.t-1.2)/3.4,e=k*k*(3-2*k),ly=walkY(Z.land.x,Z.land.z);Z.sh.visible=true;Z.sh.position.set(c.x,Z.sy+(ly-Z.sy)*e+Math.sin(k*Math.PI)*4,c.z-38+(Z.land.z-(c.z-38))*e);Z.sh.rotation.x=-.25*(1-e);Z.sh.userData.flame.visible=true;}
  if(Z.t>=4.6&&!Z.out){Z.out=true;Z.sh.position.set(Z.land.x,walkY(Z.land.x,Z.land.z),Z.land.z);Z.sh.rotation.x=0;Z.sh.userData.flame.visible=false;const BH=window.BHQ,mkA=BH.alien3D||pup3D;
    /* they hop out of the ship, right over the crowd, into the middle to dance round Seb */
    [BH.ZUZU].concat(BH.APUPS).forEach((p,i)=>{const fx=Z.land.x+(i-5)*.5,fz=Z.land.z+3,g=noCull(mkA(p));add(g,fx,fz);Z.pups.push({g,fx,fz,a0:Math.PI*1.5+i*TAU/11,x:fx,z:fz,ph:i*.6,d:i*.12});});
    for(let k=0;k<6;k++)floatS('✨',Z.land.x+(Math.random()-.5)*6,walkY(Z.land.x,Z.land.z)+2+Math.random()*3,Z.land.z+3,1.8,1.2);
    sfx.jingle();confetti(40);say(`Whoosh! ${window.BHQ.ZUZU.name} and her ten puppies flew through the wormhole to dance with you!`);Z.t0=Z.t;}
  Z.pups.forEach(p=>{const a=p.a0-.55*(t-C.d0),tx=c.x+Math.cos(a)*3.8,tz=c.z+Math.sin(a)*3.8,k=Math.max(0,Math.min(1,(Z.t-Z.t0-p.d)/1.8)),e=k*k*(3-2*k);
    p.x=p.fx+(tx-p.fx)*e;p.z=p.fz+(tz-p.fz)*e;animPup(p.g,t,true);
    p.g.position.set(p.x,walkY(p.x,p.z)+Math.sin(e*Math.PI)*7+(k>=1?Math.abs(Math.sin(t*6.5+p.ph))*.55:0)+(p.g.userData.float||0),p.z);
    p.g.rotation.y=k<1?Math.atan2(tx-p.fx,tz-p.fz):Math.atan2(Math.sin(a),-Math.cos(a))+Math.sin(t*2.4+p.ph)*.4;});}
function endCard(zz){if(C&&C.replay){card({art:'<div style="font-size:100px;line-height:1">🌍🌙</div>',h:'What a dance!',p:`100 pups dancing on the Moon${zz?', with Zuzu and her puppies':''}!`,
    btns:[['🏡 Home to the village','green',()=>{player.lock=false;fadeTo(()=>enterArea('village',null,'Home again! Tap the pink paw flag to party again.'));}],['🎬 The credits','blue',()=>credits(false)]]});return;}
  card({art:`<div class="fitsvg" style="width:120px">${sebSVG(true)}</div><div style="font-size:100px;line-height:1">🌍</div>`,h:'The Great Pup Conga World Tour!',
  p:`Seb led 100 pups round Pawprint Village, all eight islands, and up to the Moon!${zz?' Zuzu and her puppies came all the way through the wormhole to dance too!':''}`,
  btns:[['🎬 The credits','green',()=>credits(false)]]});}

/* ============ credits, "The End?" and the Pup Seasons teaser ============ */
function credits(again){const pv=C?C.pv:!!PV;player.lock=true;let ids=lineIds(pv);if(ids.length<100)ids=ids.concat(mix(pool(true).map(p=>p.id).filter(id=>ids.indexOf(id)<0))).slice(0,100);
  const ps=ids.map(id=>PUPS[id]).filter(Boolean),bud=state.buddy&&pupById(state.buddy),U=ISLANDS.map(I=>I.boss&&I.boss.uni).filter(Boolean),BH=window.BHQ;
  let h=`<h1>Seb's Puppy Quest 3</h1><h2>Starring</h2><div class="fitsvg">${sebSVG(true)}</div><p style="font-size:44px;font-weight:900">SEB</p><p>the leader of the Great Pup Conga</p>`;
  if(bud)h+=`<h2>And his best buddy</h2>${pupBox(bud)}<p style="font-size:34px;font-weight:900">${bud.name}</p>`;
  h+=`<h2>The Great Pup Conga</h2><div class="row">${ps.slice(0,10).map(p=>pupBox(p,{anim:false})).join('')}</div>`;
  for(let i=0;i<ps.length;i+=10)h+=`<p><b style="color:#ffd23f">${i+1} to ${Math.min(i+10,ps.length)}:</b> ${ps.slice(i,i+10).map(p=>p.name).join(' · ')}</p>`;
  h+=`<h2>The Unicorns</h2><div class="row">${U.map(u=>pupBox(u,{anim:false})).join('')}</div><p>${U.map(u=>u.name).join(' · ')}</p>`;
  h+=`<h2>On the decks</h2><div class="fitsvg" style="width:150px">${magpieSVG()}</div><p>DJ Muddle the Magpie</p>`;
  if(BH&&BH.ZUZU&&(bhDone()||pv))h+=`<h2>From the far side of the galaxy</h2><p>${BH.ZUZU.name} and her puppies: ${BH.APUPS.map(p=>p.name).join(' · ')}</p>`;
  h+=`<h2>Special guests</h2><p>Granny Paws · Sensei Mochi · Professor Hoot · Chief Woofles · Tinker the robot · Dr Digby · Captain Nibbles · Mr Crumbs</p>`;
  h+=`<h2>Made with love for Seb</h2><h1 style="margin-top:120px">The End?</h1><div style="height:220px"></div>`;
  hush();closeOv('cele');const o=q('#cgCred'),tr=q('#cgTrack');tr.innerHTML=h;tr.style.transform='';o.classList.add('on');confetti(60);speak('Seb\'s Puppy Quest 3. Starring Seb, the leader of the Great Pup Conga!');
  const H=tr.scrollHeight+768,t0=performance.now(),dur=Math.max(42000,H*11);let done=false;
  const fin=()=>{if(done)return;done=true;o.classList.remove('on');tr.style.transform='';teaser();};
  const stepF=ts=>{if(done)return;if(!o.classList.contains('on')){done=true;return;}const e=(ts-t0)/dur;tr.style.transform=`translateY(${-e*H}px)`;if(e>=1)return fin();requestAnimationFrame(stepF);};requestAnimationFrame(stepF);
  CRED.fin=fin;}
const CRED={fin:null};q('#cgSkip').addEventListener('click',()=>{initAudio();sfx.pop();if(CRED.fin)CRED.fin();});
function teaser(){const mg=`<div class="fitsvg" style="width:150px">${magpieSVG()}</div>`;
  story([{art:`<div style="font-size:120px;line-height:1">❄️</div>${mg}`,t:'But wait! What is this, drifting down from the sky? It is... snow!'},
    {art:`${mg}<div style="font-size:110px;line-height:1">🧣</div>`,t:'"Brrr!" says Muddle, in a woolly scarf. "Winter is coming to the islands, and the pups want to play hide and seek in the snow!"'},
    {art:'<div style="font-size:110px;line-height:1">🎄❄️🎁</div>',t:'The End? No! The first Pup Season is here: Christmas Snow!'}],
    ()=>{const pv=C?C.pv:!!PV;player.lock=false;if(pv){endPreview();return;}if(window.XMAS){fadeTo(()=>{enterArea('village');XMAS.fromConga();});return;}fadeTo(()=>enterArea('village',null,'Welcome home, Seb! Tap the pink paw flag to party with all 100 pups again.'));});}

/* ============ the flag: start, carry on, or party again ============ */
function openTour(){if(!unlocked()){sfx.oops();return;}hush();sfx.chime();
  if(C&&C.party){card({art:'<div style="font-size:110px;line-height:1">🪩</div>',h:'Stop the party?',p:'The pups can have a rest, and Pawprint Village goes back to daytime.',
    btns:[['🌞 Stop the party','green',()=>fadeTo(()=>enterArea('village'))],['Keep dancing','white']]});return;}
  const s=S();PV=null;
  if(!s.intro){introStory(()=>openPick(0,false));return;}
  if(s.leg>=10){doneCard();return;}
  card({art:legRow(s.leg),h:'🪩 The Great Pup Conga World Tour',p:s.leg?`${s.leg*10} pups are in your conga! Next: leg ${s.leg+1}, ${legName(LEGS[s.leg])}.`:'Lead a conga line of 100 pups! 10 pups in each place: Pawprint Village, all eight islands, and then the Moon!',
    btns:[[s.leg?'▶ Next leg!':'▶ Let\'s go!','green',()=>openPick(s.leg,false)],['Not now','white']]});}
function introStory(then){const s=S();const mg=`<div class="fitsvg" style="width:150px">${magpieSVG()}</div>`,ball='<div style="font-size:110px;line-height:1">🪩</div>';
  story([{art:mg+ball,t:'Muddle the Magpie has put the giant disco ball from the Puppy Disco on top of the Map Tower in Pawprint Village. All nine stars are home, and they make it sparkle!'},
    {art:`${mg}<div class="fitsvg">${critterSVG(ISLANDS[0].boss.uni)}</div>`,t:'"Let\'s have the biggest party ever!" says Muddle. "The Great Pup Conga World Tour!"'},
    {art:`<div class="fitsvg" style="width:120px">${sebSVG(true)}</div><div style="font-size:90px;line-height:1">🐶</div>`,t:'Lead a conga line of 100 pups! Pick 10 pups in each place: Pawprint Village, all eight islands, and then up to the Moon!'}],
    ()=>{s.intro=1;s.inv=1;save();if(then)then();});}
function doneCard(){const s=S();card({art:'<div style="font-size:100px;line-height:1">💃🪩🕺</div>',h:'🌍 World Tour complete!',p:`You led all 100 pups round the world and up to the Moon.${bhDone()&&!s.zuzu?' Zuzu and her puppies want to come to the Moon dance too!':''} What next?`,
  btns:[['🕺 Party with all 100','green',party],['🌙 Dance on the Moon','blue',moonParty],['🎬 Watch the ending','blue',()=>credits(true)],['🔄 New tour','white',()=>card({art:'<div style="font-size:100px;line-height:1">🔄</div>',h:'Start a new World Tour?',p:'The conga starts again from zero, with new pups to pick. Your badges and certificate stay!',
    btns:[['🔄 Yes, start again','green',()=>{s.leg=0;s.pups=[];s.tours=(s.tours|0)+1;delete s.next;delete s.nextLeg;save();openPick(0,false);}],['No','white']]})],['Not now','white']]});}
function party(){fadeTo(()=>{INLEG=true;try{enterArea('village',null,'Party time! Dance round the village with all 100 pups!');}finally{INLEG=false;}
  if(!W.area||W.area.id!=='village')return;newC({mode:'free',party:true});noWanderers();villageNight(null);const st={x:0,z:12},R={start:st,a0:0};placeSeb(st,Math.PI);
  keepCam(W.area,13,5.8);night();buildLine(S().pups);startTrail({c:[0,0],r:[12,12]},R);W.ticks.push(tick);music(true);pill();},['🪩','Party time!']);}

/* the Moon dance again, with all 100 (and Zuzu's family once the Black Hole quest is done), without doing every leg (25 Nov 2026) */
function moonParty(){fadeTo(()=>{INLEG=true;try{enterArea('moon',null,'Back on the Moon, for the big dance!');}finally{INLEG=false;}
  if(!W.area||W.area.id!=='moon')return;newC({mode:'free',li:9,L:LEGS[9],replay:true});stash();C.extra=extras('bub');buildLine(S().pups);
  startTrail(LEGS[9],{start:{x:player.x,z:player.z},a0:0});W.ticks.push(tick);music(true);pill();danceStart();},['🌙','Off to the Moon for the big dance!']);}

/* the invitation, once all nine islands are done */
function invite(){const s=S();s.inv=1;save();player.lock=true;hush();sfx.jingle();
  story([{art:'<div style="font-size:120px;line-height:1">💌</div>',t:'A sparkly envelope flutters down! It says: "Dear Seb, you are invited to a party in Pawprint Village, tonight! Love from Muddle and the unicorns."'}],
    ()=>introStory(()=>card({art:'<div style="font-size:110px;line-height:1">🪩</div>',h:'Go to the party?',p:'The pink paw flag in the village plaza starts the World Tour.',
      btns:[['🪩 Go now!','green',()=>{player.lock=false;if(W.area&&W.area.id==='village')openPick(0,false);else fadeTo(()=>{enterArea('village',[FLAG[0]-2,FLAG[1]-3,Math.PI],'Here is the pink paw flag!');setTimeout(()=>openPick(0,false),900);});}],
        ['Later','white',()=>{player.lock=false;say('The pink paw flag in the village plaza is waiting for you, whenever you are ready!');}]]})));}
setInterval(()=>{try{if(!state||cur!=='world'||!W.area||player.lock||ovOpen()||C||PV)return;if(state.conga&&state.conga.inv)return;if(!unlocked())return;
  if(typeof AQ!=='undefined'&&AQ.some(a=>a.c))return;if(typeof toastUntil!=='undefined'&&Date.now()<toastUntil)return;invite();}catch(e){}},2500);

/* ============ conga music: the disco tune in audio.js (TUNES.disco) ============ */
function music(on){if(typeof MUSIC!=='undefined')MUSIC.over=on?'disco':null;}

/* ============ grown-ups preview (nothing is saved) ============ */
function preview(li){closeOv('settings');initAudio();const all=mix(pool(true));PV={line:[],keep:{where:state.where}};
  for(let i=0;i<li;i++){const k=LEGS[i].k,fromI=all.filter(p=>(k==='village'||p.island===k)&&PV.line.indexOf(p.id)<0).slice(0,10);PV.line=PV.line.concat(fromI.map(p=>p.id));}
  const k=LEGS[li].k,picks=all.filter(p=>(k==='village'||p.island===k)&&PV.line.indexOf(p.id)<0).slice(0,10);goLeg(li,picks,true);}
function endPreview(){PV=null;closeOv('cele');q('#cgCred').classList.remove('on');player.lock=false;if(C){const c0=C;endC();}showTitle();}
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=q('#setCard');if(!c)return;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`🪩 Conga finale preview<div class="opts">${LEGS.map((L,i)=>`<button class="opt cgPv" data-i="${i}">${i+1}</button>`).join('')}<button class="opt cgPv" data-i="c">🎬</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent='For grown-ups: play any leg of the World Tour with surprise pups, or watch the credits. Nothing is saved, so Seb\'s tour stays a surprise.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.cgPv').forEach(b=>tap(b,()=>{sfx.boop();if(b.dataset.i==='c'){closeOv('settings');PV={line:[],keep:{where:state.where}};credits(true);}else preview(+b.dataset.i);}));};}

/* ============ a tile in the Games Arcade (25 Nov 2026) ============ */
if(typeof openGames==='function'){const base=openGames;openGames=function(tab){base.apply(this,arguments);try{if(arcTab!=='games')return;const g=q('#menuCard .gcols');if(!g||g.querySelector('[data-g="conga"]'))return;
  const u=unlocked(),s=u?S():null,r=!u?'🔒':s.leg>=10?'Done! 🎉':s.leg?`Leg ${s.leg+1} next`:'New!';
  const b=el('button','grow'+(u?'':' lock'),`<span class="gi">🪩</span><span class="gn">Conga World Tour${u?'':' 🔒'}</span><span class="gb">${r}</span>`);b.dataset.g='conga';g.appendChild(b);}catch(e){}};}
if(typeof startGame==='function'){const base=startGame;startGame=function(k){if(k==='conga'){if(!unlocked()){sfx.oops();say('The Conga World Tour opens when all nine islands are done!');return;}openTour();return;}return base.apply(this,arguments);};}

/* ============ hooks into the engine ============ */
{const base=enterArea;enterArea=function(id,pos,msg){const leaving=C&&C.mode==='leg'&&!INLEG,keep=PV&&INLEG==='pv'?{where:state.where,seen:state.seen[id]}:null;
  if(C)endC();if(PV&&!INLEG&&!(q('#cgCred').classList.contains('on')))PV=null;
  base(id,pos,msg);
  if(keep){state.where=keep.where;if(!keep.seen)delete state.seen[id];save();}
  if(id==='village'&&W.area&&W.area.id==='village'&&(unlocked()||INLEG))villageDay();
  if(leaving&&!PV)setTimeout(()=>{if(cur==='world')say('The conga is having a rest. Tap the pink paw flag in the village plaza to carry on!');},2600);};}
{const base=grannyHint;grannyHint=function(){if(unlocked()&&best()<10&&!C){sfx.chime();return say('Muddle is having a party! Tap the pink paw flag in the plaza for the Great Pup Conga World Tour.');}return base.apply(this,arguments);};}

/* ============ badges and certificate ============ */
MERITS.push(
  {id:'cgline',icon:'🐾',name:'Conga Line',how:'Lead a conga line of 10 pups.',ok:()=>best()>=1},
  {id:'cgski',icon:'⛷️',name:'Conga Skier',how:'Ski down the Green Run with your conga line.',ok:()=>best()>=3},
  {id:'cgcrowd',icon:'🐕',name:'Conga Crowd',how:'Lead a conga line of 50 pups.',ok:()=>best()>=5},
  {id:'cgtour',icon:'🌍',name:'World Tour',how:'Take the conga round the world and up to the Moon.',ok:()=>best()>=10},
  {id:'cgzuzu',icon:'👽',name:'Space Dance',how:'Dance on the Moon with Zuzu and her puppies.',ok:()=>!!(state.conga&&state.conga.zuzu)});
CERTS.push({id:'cgchamp',icon:'🪩',title:'Conga World Champion',why:'for leading 100 pups on the Great Pup Conga World Tour, round the islands and up to the Moon',ok:()=>best()>=10});

window.CONGA={moonParty,LEGS,get C(){return C;},get P(){return P;},get PV(){return PV;},S,unlocked,openTour,openPick,goLeg,preview,credits,invite,party,finaleCard,danceStart,legDone,route};
})();
