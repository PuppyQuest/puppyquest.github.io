/* ================================================================
   Dino Valley: Region 7 (Stone pups), reached by Professor Fizz's
   time machine next to the Science Lab. Dig Camp (start) opens the
   Fern Forest (after 2 pups) and the Fossil Cliffs (needs the riding
   saddle, so Boulder can carry Seb up the cliff path). The Forest
   leads to the Misty Swamp, the Cliffs to Volcano Ridge (a Stone pup
   digs through the rockfall). Both lead to the Long-neck's Nest
   (boss). Bonus: Amber Cave off Volcano Ridge, behind a boulder a
   Comet pup from Planet Hop can float away.
   Thrills, all friendly: a T. rex patrols Volcano Ridge and roars
   (and sneezes Seb out of the way if he gets too close), triceratops
   stampede across the Fern Forest, a long-neck bursts out of the
   swamp, and pterosaurs swoop low over the Fossil Cliffs.
   ================================================================ */
(function(){
const R=seed(7171),inw=(x,z,f)=>[x*(f||.68),z*(f||.68),Math.atan2(-x,-z)];
const {EDGES,BACKS,SETS}=LOOKS,D2=Math.PI/180;

/* ----------------- orientation helper: yaw then pitch, as XYZ angles for I() ----------------- */
const _q=new THREE.Quaternion(),_e=new THREE.Euler(),_e2=new THREE.Euler();
function yp(yaw,pitch,roll){_e2.set(pitch,yaw,roll||0,'YXZ');_q.setFromEuler(_e2);_e.setFromQuaternion(_q,'XYZ');return [_e.x,_e.y,_e.z];}
/* a flat leaf or plank from (x,y,z), pointing along yaw, drooping by pitch; returns its far end */
function blade(x,y,z,yaw,pitch,len,w,c,th){const r=yp(yaw,pitch),h=len/2,cp=Math.cos(pitch);I('box',c,w,th||.06,len,x+Math.sin(yaw)*cp*h,y-Math.sin(pitch)*h,z+Math.cos(yaw)*cp*h,r[0],r[1],r[2]);
  return [x+Math.sin(yaw)*cp*len,y-Math.sin(pitch)*len,z+Math.cos(yaw)*cp*len];}
const glowM=(c,o)=>{const m=new THREE.MeshBasicMaterial(Object.assign({color:c},o||{}));W.disp.push(m);return m;};

/* ----------------- plants from dinosaur times ----------------- */
const FERN=['#4f9e3a','#5fae46','#3f8a34','#6bb84e'];
function treeFern(x,z,s,c){s=s||1;const y=gy(x,z),h=5.2*s;I('cylL','#5a3f2a',.45*s,h,.45*s,x,y+h/2,z);
  const top=y+h,n=11;for(let i=0;i<n;i++){const a=i/n*6.283+s*3,cc=c||FERN[i%FERN.length],e=blade(x,top,z,a,-.35,2.4*s,.75*s,cc);blade(e[0],e[1],e[2],a,.6,2.2*s,.6*s,cc);}
  I('sphL','#6b4a2a',.7*s,.5*s,.7*s,x,top,z);col(x,z,.55*s);}
function cycad(x,z,s){s=s||1;const y=gy(x,z);for(let k=0;k<3;k++)I('cylL','#7a5a3a',(.7-.08*k)*s,.62*s,(.7-.08*k)*s,x,y+(.3+k*.56)*s,z);const top=y+1.8*s;
  for(let i=0;i<14;i++)blade(x,top,z,i/14*6.283,-.55+(i%2)*.45,2.4*s,.45*s,i%2?'#3f7e34':'#4f8e3a');I('coneL','#c9a040',.45*s,.9*s,.45*s,x,top+.35*s,z);col(x,z,.8*s);}
function monkeyPuzzle(x,z,s){s=s||1;const y=gy(x,z),h=11*s;I('cylL','#6b5a4a',.5*s,h,.5*s,x,y+h/2,z);
  for(let w=0;w<4;w++){const hh=y+h*(.55+w*.13),L=(3.2-w*.6)*s;for(let i=0;i<5;i++){const e=blade(x,hh,z,i/5*6.283+w*.6,-.14,L,.35*s,'#5a4a3a',.35*s);I('sphL','#2f5a32',1*s,.7*s,1*s,e[0],e[1]+.2*s,e[2]);}}
  I('sphL','#2f5a32',1.4*s,1*s,1.4*s,x,y+h+.3*s,z);col(x,z,.7*s);}
function horsetail(x,z,s){s=s||1;const y=gy(x,z);for(let i=0;i<5;i++){const dx=(i%3-1)*.4*s,dz=((i*7)%3-1)*.4*s,h=(1.6+(i%3)*.5)*s;I('cylL','#7a9a4a',.07*s,h,.07*s,x+dx,y+h/2,z+dz);
  for(let k=1;k<4;k++)I('cylL','#3a4a2a',.09*s,.05,.09*s,x+dx,y+h*k/4,z+dz);I('coneL','#8a7a4a',.1*s,.3*s,.1*s,x+dx,y+h+.1*s,z+dz);}}
function fernClump(x,z,s,c){const y=gy(x,z);for(let i=0;i<7;i++)blade(x,y+.1,z,i/7*6.283+s,-.6,1.4*s,.4*s,c||'#5fae46');}
function footprint(x,z,a,s){s=s||1;const c='#6b4a2a';I('cyl',c,.9*s,.04,1.1*s,x,gy(x,z)+.05,z,0,a,0);
  [-.6,0,.6].forEach(o=>{const tx=x+Math.sin(a+o)*1.5*s,tz=z+Math.cos(a+o)*1.5*s;I('cyl',c,.32*s,.04,.6*s,tx,gy(tx,tz)+.05,tz,0,a+o,0);});}
function mossRock(x,z,s,c){const y=gy(x,z);I('sphL',c||'#8a7a6a',s*1.2,s*.7,s,x,y+s*.2,z,0,x*3,0);I('sphL','#5f8e3a',s,s*.25,s*.9,x,y+s*.5,z);if(s>.9)col(x,z,s);}
function bigBush(x,z,s){const y=gy(x,z);I('sphL',pick(['#3f7e3a','#4f8e3a','#356e32']),2.4*s,2*s,2.4*s,x,y+1.2*s,z);I('sphL',pick(['#4f9e3a','#5a8a3a']),1.7*s,1.5*s,1.7*s,x+1.3*s,y+.9*s,z+.6*s);}
/* see-through shafts of sunlight and drifting pollen */
function beams(n,c){const m=glowM(c||'#fff2c0',{transparent:true,opacity:.1,depthWrite:false,blending:THREE.AdditiveBlending});const A=W.area;
  for(let i=0;i<n;i++){const a=R()*6.283,r=6+R()*(A.R-16),x=Math.cos(a)*r,z=Math.sin(a)*r,b=new THREE.Mesh(G.box,m);b.scale.set(2.2+R()*2.4,36,.2);b.position.set(x,gy(x,z)+15,z);b.rotation.set(0,R()*3,.4);b.userData.noBake=true;W.ag.add(b);}}
function pollen(n,c,sz){const A=W.area,p=new Float32Array(n*3),base=[];for(let i=0;i<n;i++){const a=R()*6.283,r=R()*(A.R-4);base.push([Math.cos(a)*r,Math.sin(a)*r,R()*6.28,1+R()*6]);}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));const m=new THREE.PointsMaterial({color:c||'#fff6c8',size:(sz||.22)*12,sizeAttenuation:false,transparent:true,opacity:.85});const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);
  W.ticks.push(()=>{const t=W.t;base.forEach((b,i)=>{const x=b[0]+Math.sin(t*.2+b[2])*2,z=b[1]+Math.cos(t*.17+b[2])*2;p[i*3]=x;p[i*3+1]=gy(x,z)+b[3]+Math.sin(t*.5+b[2]);p[i*3+2]=z;});g.attributes.position.needsUpdate=true;});}

/* ----------------- dinosaur sounds and a camera shake ----------------- */
let shakeT=0,shakeA=0;
const _cu=camUpdate;camUpdate=function(dt){_cu.apply(this,arguments);if(shakeT>0){shakeT-=dt||.016;const a=shakeA*Math.min(1,shakeT*2);cam.position.x+=(Math.random()-.5)*a;cam.position.y+=(Math.random()-.5)*a;cam.position.z+=(Math.random()-.5)*a;}};
function shake(a,t){if(shakeT<=0||a>shakeA)shakeA=a;shakeT=Math.max(shakeT,t);}
const DS={roar(v){if(!fxOk())return;v=v||1;const t=AC.currentTime;tone(170,t,1.4,'sawtooth',.26*v,null,65);tone(340,t,1.3,'square',.1*v,null,140);tone(700,t+.05,1.1,'sawtooth',.1*v,null,240);tone(1150,t+.1,.7,'triangle',.07*v,null,480);
    /* the growl iPad speakers can play (25 Nov 2026): a mid roar and rough noise */tone(330,t,1.2,'sawtooth',.16*v,null,170);nzHit(t,1.3,.34*v,'bandpass',520,null,1.1);nzHit(t+.05,1,.2*v,'bandpass',1250,null,1.4);},
  thump(v){if(!fxOk())return;v=v||1;const t=AC.currentTime;tone(110,t,.3,'sine',.35*v,null,50);tone(250,t,.16,'triangle',.18*v,null,120);nzHit(t,.14,.26*v,'lowpass',700);},
  rumble(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,1.6,.26,'lowpass',520);for(let i=0;i<10;i++){tone(80+(i%3)*12,t+i*.16,.2,'sawtooth',.12,null,60);tone(230+(i%2)*30,t+i*.16,.12,'triangle',.1,null,180);}},
  screech(){if(!fxOk())return;const t=AC.currentTime;tone(1500,t,.35,'sawtooth',.07,null,900);tone(2100,t+.06,.3,'triangle',.08,null,1300);},
  purr(){if(!fxOk())return;const t=AC.currentTime;for(let i=0;i<7;i++)tone(230+(i%2)*20,t+i*.11,.09,'triangle',.14,null,200);},
  splash(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.55,.26,'highpass',2200);tone(900,t,.3,'sine',.14,null,200);tone(320,t,.45,'triangle',.14,null,110);tone(1400,t+.08,.2,'sine',.08,null,500);},
  sneeze(){if(!fxOk())return;const t=AC.currentTime;tone(500,t,.25,'triangle',.18,null,900);tone(900,t+.3,.25,'sawtooth',.12,null,250);nzHit(t+.3,.4,.5,'highpass',1700);nzHit(t+.3,.3,.3,'bandpass',3200,null,1.2);}};

/* ----------------- dinosaurs (joined into one shape each, like the pups) ----------------- */
function sauro3D(C){C=C||'#8a9a7a';const D=shade(C,-.12),B=shade(C,.15),g=grp(),body=grp();body.position.y=7;g.add(body);
  mk('sph',C,3.2,2.8,5,0,0,0,body);mk('sph',B,2.8,2,4.4,0,-.9,0,body);for(let i=0;i<6;i++)mk('sph',D,.7,.35,.9,0,2.6,-3+i*1.2,body);
  const legs=[];[[-1,1],[1,1],[-1,-1],[1,-1]].forEach(q=>{const L=grp();L.position.set(q[0]*1.9,-1.4,q[1]*2.8);body.add(L);mk('cyl',C,1,5.6,1,0,-2.8,0,L);mk('cyl',D,1.2,.5,1.2,0,-5.5,.1,L);legs.push(L);});
  const neck=[];let par=body;for(let i=0;i<6;i++){const n=grp();n.position.set(0,i?2.2:1.3,i?0:4);n.rotation.x=i?-.12:.75;par.add(n);mk('cyl',C,1.15-i*.1,2.6,1.15-i*.1,0,1.1,0,n);if(i<5)mk('sph',D,.35,.25,.35,0,1.1,-(1.05-i*.1),n);neck.push(n);par=n;}
  const head=grp();head.position.set(0,2.3,0);head.rotation.x=1;par.add(head);mk('sph',C,.95,.85,1.5,0,0,.6,head);mk('sph',B,.7,.4,1.2,0,-.4,.8,head);
  [-1,1].forEach(s=>{mk('sph','#ffffff',.25,.28,.2,s*.72,.35,.75,head);mk('sph','#26232e',.13,.16,.12,s*.8,.35,.8,head);});
  const tail=[];par=body;for(let i=0;i<6;i++){const t=grp();t.position.set(0,i?0:.2,i?-1.9:-4.6);t.rotation.x=i?.06:-.12;par.add(t);mk('sph',C,1.2-.17*i,1.1-.16*i,2.2,0,0,-1,t);tail.push(t);par=t;}
  g.userData.d={body,legs,neck,head,tail};bakeModel(g,'sauro'+C);return g;}
function sauroAnim(g,t,walk,sp){const d=g.userData.d;sp=sp||1;const ph=t*sp*1.6;d.legs.forEach((L,i)=>{L.rotation.x=walk?Math.sin(ph+(i===0||i===3?0:Math.PI))*.28:0;});
  d.body.position.y=7+(walk?Math.abs(Math.sin(ph))*.15:Math.sin(t*.8)*.06);d.neck[0].rotation.y=Math.sin(t*.35)*.18;d.neck[3].rotation.y=Math.sin(t*.5+1)*.08;
  d.tail.forEach((s,i)=>{s.rotation.y=Math.sin(t*.9-i*.5)*.1;});}
function trex3D(){const g=grp(),C='#5f7f3a',D='#3f5a28',B='#d8c89a';const hip=grp();hip.position.y=5;g.add(hip);
  mk('sph',C,2,2.2,3.6,0,0,.6,hip);mk('sph',B,1.6,1.6,3,0,-.7,.9,hip);for(let i=0;i<6;i++)mk('sph',D,.4,.35,.55,0,2.05-Math.abs(i-2)*.12,-1.6+i*1,hip);
  const neck=grp();neck.position.set(0,.9,3.4);neck.rotation.x=-.2;hip.add(neck);mk('sph',C,1.3,1.5,1.6,0,.4,.6,neck);
  const head=grp();head.position.set(0,1.1,1.3);neck.add(head);mk('box',C,1.7,1.3,2.9,0,.3,1.3,head);mk('box',D,1.2,.3,2.2,0,1,1.1,head);
  [-1,1].forEach(s=>{mk('sph','#ffffff',.34,.34,.22,s*.82,.75,.8,head);mk('sph','#26232e',.18,.22,.12,s*.9,.75,.88,head);mk('box',D,.5,.2,.7,s*.7,1.08,.75,head);mk('sph','#26232e',.1,.1,.1,s*.35,.72,2.72,head);
    for(let i=0;i<5;i++){const tt=mk('cone','#ffffff',.12,.36,.12,s*.68,-.48,.5+i*.48,head);tt.rotation.x=Math.PI;}});
  const jaw=grp();jaw.position.set(0,-.3,.1);head.add(jaw);mk('box',B,1.5,.42,2.6,0,-.25,1.2,jaw);mk('box',C,1.55,.26,2.6,0,-.5,1.2,jaw);mk('box','#e86a7a',.9,.1,1.6,0,0,1,jaw);
  [-1,1].forEach(s=>{for(let i=0;i<4;i++)mk('cone','#ffffff',.11,.32,.11,s*.6,.1,.6+i*.55,jaw);});
  const arms=[];[-1,1].forEach(s=>{const a=grp();a.position.set(s*1.35,-.2,2.6);hip.add(a);const u=mk('cyl',C,.24,1.1,.24,0,-.45,.25,a);u.rotation.x=.8;mk('cone','#f4ead0',.08,.25,.08,0,-.75,.75,a).rotation.x=1.6;arms.push(a);});
  const legs=[],shins=[];[-1,1].forEach(s=>{const L=grp();L.position.set(s*1.5,-.3,0);hip.add(L);mk('sph',C,1.15,2,1.5,0,-1,0,L);
    const sh=grp();sh.position.set(0,-2.1,-.2);L.add(sh);mk('cyl',C,.5,2.5,.55,0,-1.15,-.2,sh);const ft=grp();ft.position.set(0,-2.4,-.3);sh.add(ft);mk('box',D,1,.4,1.5,0,0,.5,ft);
    [-.3,0,.3].forEach(o=>{const k=mk('cone','#f4ead0',.12,.4,.12,o,-.05,1.35,ft);k.rotation.x=Math.PI/2;});legs.push(L);shins.push(sh);});
  const tail=[];let par=hip;[2.5,2.3,2,1.8].forEach((len,i)=>{const t=grp();t.position.set(0,i?0:.3,i?-[2.5,2.3,2][i-1]*.85:-2.4);t.rotation.x=i?.05:-.05;par.add(t);mk('sph',C,1.35-.25*i,1.3-.25*i,len,0,0,-len*.45,t);if(i<3)mk('sph',D,.28,.25,.4,0,1.2-.25*i,-len*.45,t);tail.push(t);par=t;});
  g.userData.d={hip,neck,head,jaw,arms,legs,shins,tail};bakeModel(g,'trex');return g;}
function trexAnim(g,t,o){const d=g.userData.d,ph=o.ph;const walk=o.walk;
  d.legs.forEach((L,i)=>{L.rotation.x=walk?Math.sin(ph+i*Math.PI)*.5:0;d.shins[i].rotation.x=walk?Math.max(0,Math.sin(ph+i*Math.PI+1))*.5:0;});
  d.hip.position.y=5+(walk?Math.abs(Math.sin(ph))*.25:Math.sin(t*1.5)*.06);d.hip.rotation.z=walk?Math.sin(ph)*.05:0;
  d.tail.forEach((s,i)=>{s.rotation.y=Math.sin(t*1.4-i*.6)*.12;});d.arms.forEach((a,i)=>{a.rotation.x=Math.sin(t*3+i)*.25;});
  const roar=o.roar||0,sniff=o.sniff||0;d.neck.rotation.x=-.2-roar*.55+sniff*.75;d.head.rotation.x=-roar*.2+sniff*.25;d.jaw.rotation.x=roar*.75+Math.max(0,Math.sin(t*1.1))*.06;
  d.head.rotation.y=o.look||0;}
function trike3D(C,F,baby,horn){const g=grp(),k=baby?.62:1,body=grp();body.position.y=2.4*k;g.add(body);const D=shade(C,-.14),B=shade(C,.16);
  mk('sph',C,2*k,1.7*k,3*k,0,0,0,body);mk('sph',B,1.7*k,1.2*k,2.6*k,0,-.6*k,0,body);for(let i=0;i<5;i++)mk('sph',D,.5*k,.3*k,.6*k,0,1.55*k,-1.6*k+i*.8*k,body);
  const legs=[];[[-1,1],[1,1],[-1,-1],[1,-1]].forEach(q=>{const L=grp();L.position.set(q[0]*1.25*k,-.6*k,q[1]*1.6*k);body.add(L);mk('cyl',C,.5*k,2*k,.5*k,0,-1*k,0,L);mk('cyl',D,.58*k,.25*k,.58*k,0,-1.95*k,.05,L);legs.push(L);});
  const head=grp();head.position.set(0,.4*k,2.8*k);body.add(head);mk('sph',C,1*k,.9*k,1.3*k,0,0,.6*k,head);const bk=mk('cone','#5a4a3a',.4*k,.8*k,.4*k,0,-.15*k,1.95*k,head);bk.rotation.x=Math.PI/2;
  const fr=mk('cyl',F,1.9*k,.22*k,1.9*k,0,.9*k,-.25*k,head);fr.rotation.x=-1.15;for(let i=0;i<9;i++){const a=-1.2+i*.3;mk('sph',shade(F,-.12),.32*k,.32*k,.22*k,Math.sin(a)*1.85*k,.9*k+Math.cos(a)*1.75*k*.42,-.25*k-Math.cos(a)*1.75*k*.9,head);}
  if(baby)[[-.7,.7],[.7,.7],[0,.85]].forEach((p,i)=>{mk('sph','#f4ead0',.24*k,.24*k,.24*k,p[0]*k*(i<2?1:0),.65*k+(i<2?.25*k:-.3*k),(i<2?.7:1.55)*k,head);});
  else{[-1,1].forEach(s=>{const h=mk('cone','#f4ead0',.24,1.8,.24,s*.55,1.05,1.15,head);h.rotation.x=1.05;});const n=mk('cone','#f4ead0',.2,.8,.2,0,.3,1.75,head);n.rotation.x=.8;}
  [-1,1].forEach(s=>{mk('sph','#ffffff',.26*k*(baby?1.5:1),.28*k*(baby?1.5:1),.2*k,s*.7*k,.35*k,.95*k,head);mk('sph','#26232e',.14*k*(baby?1.5:1),.17*k*(baby?1.5:1),.12*k,s*.76*k,.35*k,1.02*k,head);});
  if(baby)[-1,1].forEach(s=>mk('sph','#ff9ecb',.18,.12,.1,s*.62*k,.05*k,1.25*k,head));
  const tail=grp();tail.position.set(0,0,-2.6*k);body.add(tail);const tl=mk('cone',C,.7*k,2.4*k,.7*k,0,-.2*k,-1*k,tail);tl.rotation.x=-Math.PI/2-.2;
  g.userData.d={body,legs,head,tail,k};return g;}
function trikeAnim(g,t,walk,sp){const d=g.userData.d,ph=t*(sp||2.4);d.legs.forEach((L,i)=>{L.rotation.x=walk?Math.sin(ph+(i===0||i===3?0:Math.PI))*.55:0;});
  d.body.position.y=2.4*d.k+(walk?Math.abs(Math.sin(ph))*.18*d.k:Math.sin(t*1.6)*.04);d.head.rotation.x=walk?Math.sin(ph*2)*.05:Math.sin(t*.9)*.08;d.tail.rotation.y=Math.sin(t*2)*.25;}
function ptero3D(){const g=grp(),C='#b5603a',WG='#e08a5a';mk('sph',C,.5,.45,1.2,0,0,0,g);const h=grp();h.position.set(0,.3,1);g.add(h);mk('sph',C,.4,.4,.55,0,0,0,h);
  const bk=mk('cone','#e8d080',.16,1.6,.16,0,-.05,.95,h);bk.rotation.x=Math.PI/2;mk('box',WG,.08,.7,1,0,.45,-.45,h).rotation.x=-.6;[-1,1].forEach(s=>mk('sph','#26232e',.08,.1,.08,s*.3,.12,.25,h));
  const wings=[];[-1,1].forEach(s=>{const w=grp();w.position.set(s*.4,.1,.1);g.add(w);mk('box',WG,2.6,.06,1.3,s*1.3,0,-.1,w);mk('box',WG,1.7,.06,.8,s*3.3,0,-.25,w);mk('box',C,2.6,.1,.15,s*1.3,.02,.5,w);wings.push(w);});
  const tl=mk('cone',C,.12,1.2,.12,0,0,-1.3,g);tl.rotation.x=-Math.PI/2;g.userData.wings=wings;bakeModel(g,'ptero');return g;}
function flap(g,t,k){const w=g.userData.wings,a=Math.sin(t*(k||5))*.55;w[0].rotation.z=a;w[1].rotation.z=-a;}
/* pterosaurs circling high up */
function pteroFlock(n,cx,cz,r,h){const L=[];for(let i=0;i<n;i++){const g=ptero3D();W.ag.add(g);L.push({g,a:i/n*6.28,r:r*(.7+i*.15),h:h+i*3});}
  W.ticks.push(dt=>{L.forEach((o,i)=>{o.a+=dt*.22;const x=cx+Math.cos(o.a)*o.r,z=cz+Math.sin(o.a)*o.r;o.g.position.set(x,o.h+Math.sin(W.t*.7+i)*2,z);o.g.rotation.y=Math.atan2(-Math.sin(o.a),Math.cos(o.a));o.g.rotation.z=.35;flap(o.g,W.t+i,i%2?4:2.5);});});}
/* now and then one swoops low right over Seb */
function pteroSwoop(every){const g=ptero3D();g.visible=false;W.ag.add(g);let t=6+R()*6,run=-1,a=0,said=false;
  W.ticks.push(dt=>{if(run<0){t-=dt;if(t<0&&!W.act&&!player.lock){run=0;a=R()*6.283;g.visible=true;}return;}
    run+=dt/3.2;const k=run*2-1,P=player,dx=Math.cos(a),dz=Math.sin(a),x=P.x+dx*k*44,z=P.z+dz*k*44,y=walkY(P.x,P.z)+4.2+k*k*14;g.position.set(x,y,z);g.rotation.y=Math.atan2(dx,dz);g.rotation.x=-k*.5;flap(g,W.t,7);
    if(Math.abs(k)<.12&&!g.userData.sc){g.userData.sc=1;DS.screech();shake(.12,.3);floatS('💨',P.x,walkY(P.x,P.z)+3.5,P.z,1.6);if(!said){said=true;say('Whoosh! A pterosaur swoops right over your head!');}}
    if(run>=1){run=-1;t=every*(.7+R()*.6);g.visible=false;g.userData.sc=0;}});}

/* ----------------- Dr Digby the badger, and Boulder the baby triceratops ----------------- */
function badger3D(){const g=grp();mk('sph','#8a8a92',.85,.8,1,0,1,0,g);mk('sph','#26232e',.7,.5,.85,0,.75,.05,g);
  [-1,1].forEach(s=>{mk('cyl','#26232e',.2,.6,.2,s*.4,.3,.3,g);mk('cyl','#26232e',.2,.6,.2,s*.4,.3,-.4,g);});
  mk('sph','#ffffff',.55,.5,.6,0,1.8,.35,g);[-1,1].forEach(s=>{mk('box','#26232e',.16,.42,.75,s*.24,1.9,.42,g);mk('sph','#ffffff',.1,.1,.06,s*.24,1.92,.85,g);mk('sph','#26232e',.06,.07,.04,s*.24,1.92,.9,g);mk('sph','#c9c9d0',.14,.12,.08,s*.42,2.28,.25,g);});
  mk('sph','#26232e',.12,.1,.1,0,1.72,.92,g);mk('cyl','#c9a86a',1,.06,1,0,2.3,.3,g);mk('cyl','#b8945a',.5,.4,.5,0,2.5,.3,g);mk('cyl','#5b4636',.52,.08,.52,0,2.42,.3,g);
  const br=mk('box','#9b6a43',.1,.7,.1,.7,1.2,.6,g);br.rotation.z=-.5;mk('box','#f4ead0',.25,.25,.12,.86,1.55,.6,g);
  const lens=mk('tor','#c9a040',.22,.22,.22,-.75,1.5,.6,g);mk('cyl','#bfe8ff',.2,.03,.2,-.75,1.5,.6,g).rotation.x=Math.PI/2;return g;}
const DIG=['Dr Digby says: hello, explorer! I dig up fossils. The riding saddle is on the stand by my tent. Boulder loves a ride!','Dr Digby says: a fossil is the remains of a living thing, turned to stone over millions of years.','Dr Digby says: two pups found here will open the trail to the Fern Forest.','Dr Digby says: watch out for the triceratops stampede in the Fern Forest. Stand back when the ground rumbles!','Dr Digby says: a big T. rex lives on Volcano Ridge. It roars a lot, but it is all bark and no bite!','Dr Digby says: there is a boulder in front of Amber Cave. A Comet pup from Planet Hop could float it away.','Dr Digby says: Amber the Dino Unicorn is waiting at the Long-neck\'s Nest.'];
function boulder3D(){return trike3D('#e0a05a','#5fae9a',true);}
regRide('boulder',()=>{const g=boulder3D();g.userData.tick=(t,mv)=>trikeAnim(g,t,mv,8);return g;},1.05);

/* ----------------- scenery sets for the island look ----------------- */
function ringPts(A,r,step,gap){const out=[],n=Math.ceil(2*Math.PI*r/step);for(let i=0;i<n;i++){const a=i/n*Math.PI*2,x=Math.cos(a)*r,z=Math.sin(a)*r;
  if(W.exits.some(e=>!e.noArch&&Math.hypot(x-e.x,z-e.z)<gap))continue;if((A.edgeGaps||[]).some(g=>Math.hypot(x-g[0],z-g[1])<(g[2]||gap)))continue;out.push([x,z,a,i]);}return out;}
EDGES.jungle=function(A){const Rr=A.R,Rn=seed(Rr*7+A.id.length*3);
  ringPts(A,Rr+2.6,3,4.8).forEach((p,i)=>{const s=.9+Rn()*.6;bigBush(p[0],p[1],s);if(i%3===0)treeFern(p[0]*1.05,p[1]*1.05,1.1+Rn()*.5);else if(i%3===1)cycad(p[0]*1.04,p[1]*1.04,1+Rn()*.4);});
  ringPts(A,Rr+8,5.4,7).forEach((p,i)=>{i%3===0?monkeyPuzzle(p[0],p[1],1+Rn()*.5):treeFern(p[0],p[1],1.4+Rn()*.6);});
  ringPts(A,Rr+14,8,9).forEach((p,i)=>{i%2?monkeyPuzzle(p[0],p[1],1.3+Rn()*.4):bigBush(p[0],p[1],2+Rn());});};
SETS.jungle=function(A,S){const {spot,n,Rn,pk}=S,k=A.dense||1;
  for(let i=0;i<n(9*k);i++){const p=spot(1.4,5);if(p)treeFern(p[0],p[1],.75+Rn()*.6);}
  for(let i=0;i<n(9*k);i++){const p=spot(1.2,4);if(p)cycad(p[0],p[1],.7+Rn()*.5);}
  for(let i=0;i<n(3*k);i++){const p=spot(1.6,6);if(p)monkeyPuzzle(p[0],p[1],.8+Rn()*.4);}
  for(let i=0;i<n(40*k);i++){const p=spot(.5,2);if(p)fernClump(p[0],p[1],.7+Rn()*.6,pk(FERN));}
  for(let i=0;i<n(9);i++){const p=spot(.6,3);if(p)horsetail(p[0],p[1],.8+Rn()*.5);}
  for(let i=0;i<n(10);i++){const p=spot(.8,3);if(p)mossRock(p[0],p[1],.5+Rn()*.9,pk(['#8a7a6a','#9a8a72','#7a6a5a']));}
  for(let i=0;i<n(5);i++){const p=spot(2,4,8);if(p)footprint(p[0],p[1],Rn()*6,1+Rn()*.4);}
  for(let i=0;i<n(5*k);i++){const p=spot(1.2,3);if(p)bush(p[0],p[1],.6+Rn()*.4,pk(['#3f7e3a','#4f8e3a','#5a8a3a']));}};
SETS.fossils=function(A,S){const {spot,n,Rn,pk}=S;
  for(let i=0;i<n(26);i++){const p=spot(.8,3);if(p)mossRock(p[0],p[1],.5+Rn()*1,pk(['#d8ccb0','#c9bca0','#8a96a4']));}
  for(let i=0;i<n(10);i++){const p=spot(1.4,3);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#7fd3f0',1.3,.04,1,p[0],y+.05,p[1],0,Rn()*3,0);for(let k=0;k<7;k++){const a=k/7*6.28;I('sphL',pk(['#a89a8a','#c9bca0']),.42,.3,.4,p[0]+Math.cos(a)*1.5,y+.12,p[1]+Math.sin(a)*1.1);}}
  for(let i=0;i<n(10);i++){const p=spot(1,3);if(!p)continue;const y=gy(p[0],p[1])+.1,s=.6+Rn()*.6;for(let k=0;k<4;k++)I('tor','#c9b48a',s*(1-k*.22),s*(1-k*.22),.5*s,p[0]+k*.12*s,y+.15,p[1],Math.PI/2,0,0);I('sph','#b8a078',.18*s,.12,.18*s,p[0]+.5*s,y+.15,p[1]);}
  for(let i=0;i<n(30);i++){const p=spot(.4,2);if(p){const y=gy(p[0],p[1]);for(let j=0;j<4;j++)I('coneL',pk(['#6a8a4a','#7a9a5a']),.08,.6+Rn()*.4,.08,p[0]+(Rn()-.5)*.5,y+.3,p[1]+(Rn()-.5)*.5,(Rn()-.5)*.4,0,(Rn()-.5)*.4);}}
  for(let i=0;i<n(4);i++){const p=spot(1.2,4);if(p)cycad(p[0],p[1],.6+Rn()*.3);}};
SETS.swamp=function(A,S){const {spot,n,Rn,pk}=S;
  for(let i=0;i<n(24);i++){const p=spot(.6,3);if(p)horsetail(p[0],p[1],.9+Rn()*.7);}
  for(let i=0;i<n(10);i++){const p=spot(1.4,4);if(p){const y=gy(p[0],p[1]);I('cyl','#5a4a32',.45,3+Rn()*2,.45,p[0],y+.35,p[1],0,Rn()*3,Math.PI/2);I('sphL','#5f8e3a',.7,.2,1.6,p[0],y+.75,p[1]);col(p[0],p[1],1);}}
  for(let i=0;i<n(16);i++){const p=spot(.4,2);if(p){const y=gy(p[0],p[1]);I('cyl','#f4ead0',.07,.3,.07,p[0],y+.15,p[1]);I('hemi',pk(['#e8b04a','#c9a06a','#d8d0a0']),.24,.18,.24,p[0],y+.28,p[1]);}}
  for(let i=0;i<n(30);i++){const p=spot(.5,2);if(p)fernClump(p[0],p[1],.6+Rn()*.5,pk(['#5a8a3a','#4a7a32','#6a9a4a']));}
  for(let i=0;i<n(8);i++){const p=spot(1.4,5);if(p)treeFern(p[0],p[1],.7+Rn()*.5,pk(['#4a7a32','#5a8a3a']));}
  for(let i=0;i<n(20);i++){const p=spot(.4,2);if(p){const y=gy(p[0],p[1]);for(let j=0;j<5;j++)I('cylL','#6a7a3a',.05,1.4+Rn(),.05,p[0]+(Rn()-.5)*.6,y+.7,p[1]+(Rn()-.5)*.6,(Rn()-.5)*.2,0,(Rn()-.5)*.2);I('cylL','#5a3a22',.09,.4,.09,p[0],y+1.6,p[1]);}}};
SETS.lava=function(A,S){const {spot,n,Rn,pk}=S;
  for(let i=0;i<n(30);i++){const p=spot(.8,3);if(p){const y=gy(p[0],p[1]),s=.5+Rn()*1.1;I('sphL',pk(['#2a2426','#3a3234','#4a3c3a']),s*1.2,s*.8,s,p[0],y+s*.25,p[1],0,Rn()*3,0);if(s>.9)col(p[0],p[1],s);}}
  for(let i=0;i<n(14);i++){const p=spot(.6,3,8);if(!p)continue;let x=p[0],z=p[1],a=Rn()*6;for(let j=0;j<3;j++){const L=1+Rn();I('box','#ff7a2a',L,.03,.12,x,gy(x,z)+.04,z,0,a,0,true);x+=Math.cos(a)*L*.5;z-=Math.sin(a)*L*.5;a+=(Rn()-.5)*1.2;}}
  for(let i=0;i<n(5);i++){const p=spot(1,4);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#4a3c3a',.8,.3,.8,p[0],y+.15,p[1]);I('cyl','#26201f',.5,.05,.5,p[0],y+.31,p[1]);const x=p[0],z=p[1];let t=Rn()*2;W.ticks.push(dt=>{t-=dt;if(t<0){t=.5+Math.random()*.5;floatS('💨',x+(Math.random()-.5)*.6,y+1,z,1.6,2.4);}});col(x,z,.8);}
  for(let i=0;i<n(5);i++){const p=spot(1.2,4);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#3a2e2a',.25,3.2,.3,p[0],y+1.6,p[1]);[-.6,.7].forEach((a,k)=>I('cyl','#3a2e2a',.12,1.4,.12,p[0]+Math.sin(a)*.6,y+2.4+k*.5,p[1],0,0,a));col(p[0],p[1],.4);}
  for(let i=0;i<n(10);i++){const p=spot(.5,2);if(p)fernClump(p[0],p[1],.5+Rn()*.3,'#6a7a3a');}};

/* ----------------- the volcano on the skyline, and jungle hills ----------------- */
BACKS.volcano=function(A,o){const d=o.d||210,s=o.s||1,a=(o.az!=null?o.az:-90)*D2,x=Math.cos(a)*d,z=Math.sin(a)*d,H=62*s,Rb=74*s;
  I('cone','#4a3a3a',Rb,H,Rb,x,H/2-6,z);I('cone','#3a2e30',Rb*.55,H*.5,Rb*.55,x,H*.75-6,z);I('cyl','#ff8a2a',Rb*.2,1,Rb*.2,x,H-5.6,z,0,0,0,true);I('cyl','#ffd23f',Rb*.12,1.2,Rb*.12,x,H-5.4,z,0,0,0,true);
  for(let i=0;i<5;i++){const yaw=a+Math.PI+(i-2)*.32,pitch=Math.atan2(H,Rb),L=H*.55/Math.sin(pitch),sx=x+Math.sin(yaw)*Rb*.18,sz=z+Math.cos(yaw)*Rb*.18,r=yp(yaw,pitch),h=L/2,cp=Math.cos(pitch);
    I('box',i%2?'#ff6a1a':'#ff9a3a',2.2*s,.8,L,sx+Math.sin(yaw)*cp*h+Math.sin(yaw)*1.2,H-6-Math.sin(pitch)*h+.8,sz+Math.cos(yaw)*cp*h+Math.cos(yaw)*1.2,r[0],r[1],r[2],true);}
  const pm=new THREE.MeshLambertMaterial({color:'#8a8088',transparent:true,opacity:.55,depthWrite:false});W.disp.push(pm);const puffs=[];
  for(let i=0;i<8;i++){const m=new THREE.Mesh(G.sph,pm);m.userData.noBake=true;W.ag.add(m);puffs.push({m,k:i/8});}
  W.ticks.push(dt=>{puffs.forEach(p=>{p.k+=dt*.035;if(p.k>1)p.k-=1;const sc=(6+p.k*22)*s;p.m.scale.set(sc,sc*.7,sc);p.m.position.set(x+p.k*30*s,H-6+p.k*70*s,z+p.k*8);});});
  const Rn=seed(5+A.id.length),Rr=A.R;for(let i=0;i<26;i++){const an=i/26*6.283+Rn()*.2,r=Rr+40+Rn()*50,hx=Math.cos(an)*r,hz=Math.sin(an)*r,hs=14+Rn()*16;I('sphL',pick(['#4f7a42','#5a8a4a','#46703c','#6a8a52']),hs*1.6,hs*.8,hs*1.6,hx,-2,hz);}
  if(o.necks)o.necks.forEach(q=>{const g=sauro3D(q[3]||'#7a8a6a');g.scale.setScalar(q[2]||1.4);g.rotation.y=Math.atan2(-q[0],-q[1]);add(g,q[0],q[1],gy(q[0],q[1]));W.ticks.push(()=>{sauroAnim(g,W.t+q[0],false);});});};

/* ----------------- props ----------------- */
function tent(x,z,ang,c,w){w=w||5;const y=gy(x,z),L=w*1.3;[-1,1].forEach(s=>{const r=yp(ang,0,-s*.85);I('box',c||'#d8c49a',w*.62,.08,L,x+Math.cos(ang)*s*w*.24,y+w*.3,z-Math.sin(ang)*s*w*.24,r[0],r[1],r[2]);});
  I('box','#5b4636',.12,w*.62,.12,x+Math.sin(ang)*L/2,y+w*.31,z+Math.cos(ang)*L/2);I('box','#5b4636',.12,w*.62,.12,x-Math.sin(ang)*L/2,y+w*.31,z-Math.cos(ang)*L/2);col(x,z,w*.42);}
function digPit(x,z,w,d){const m=new THREE.Mesh(G.plane,M('#8a6440'));m.scale.set(w,1,d);m.position.set(x,gy(x,z)+.06,z);W.ag.add(m);
  [[-1,-1],[1,-1],[1,1],[-1,1]].forEach(q=>{const px=x+q[0]*w/2,pz=z+q[1]*d/2;I('cyl','#9b6a43',.07,1,.07,px,gy(px,pz)+.5,pz);});
  [[w,0,-d/2],[w,0,d/2],[0,d,-w/2],[0,d,w/2]].forEach(q=>{const px=q[0]?x:x+q[2],pz=q[0]?z+q[2]:z;I('box','#ffd23f',q[0]||.03,.03,q[1]||.03,px,gy(px,pz)+.9,pz);});}
function skeleton(x,z,ang){const y=gy(x,z)+.15,c='#f2e6cc',dx=Math.sin(ang),dz=Math.cos(ang);
  const at=(f,s,h)=>[x+dx*f+dz*s,y+(h||0),z+dz*f-dx*s];
  {const p=at(5.2,0,.6);I('box',c,1.6,1.1,2.4,p[0],p[1],p[2],0,ang,0);[-1,1].forEach(s=>{const q=at(5.5,s*.6,.95);I('sph','#5a4030',.3,.3,.3,q[0],q[1],q[2]);});for(let i=0;i<5;i++){const q=at(5.9+i*.0,(i-2)*.28,.1);I('cone','#ffffff',.08,.3,.08,q[0]+dx*.9,q[1],q[2]+dz*.9);}}
  for(let i=0;i<14;i++){const p=at(3.6-i*.75,0,.45-Math.max(0,i-6)*.05);I('sph',c,.32,.28,.3,p[0],p[1],p[2]);}
  for(let i=0;i<6;i++){const p=at(2.6-i*.6,0,.35);I('arc',c,1.2-i*.08,1.2-i*.08,1.2-i*.08,p[0],p[1],p[2],-Math.PI/2,ang+Math.PI/2,0);}
  [-1,1].forEach(s=>{const p=at(-1.4,s*1.4,.25);I('cyl',c,.22,2.6,.22,p[0],p[1],p[2],Math.PI/2,ang,s*.3);const q=at(1.8,s*.9,.3);I('cyl',c,.1,.8,.1,q[0],q[1],q[2],Math.PI/2,ang+s*.4,0);});}
function wheelbarrow(x,z,a){const y=gy(x,z);I('box','#3d8fe0',1.2,.5,1.6,x,y+.7,z,0,a,0);I('cyl','#26232e',.35,.15,.35,x+Math.sin(a)*1,y+.35,z+Math.cos(a)*1,0,a,Math.PI/2);
  [-1,1].forEach(s=>I('box','#9b6a43',.08,.08,1.6,x+Math.cos(a)*s*.45-Math.sin(a)*1.1,y+.8,z-Math.sin(a)*s*.45-Math.cos(a)*1.1,0,a,0));I('sphL','#a8865a',.55,.3,.7,x,y+.95,z);col(x,z,1);}
function sieve(x,z){const y=gy(x,z);I('cyl','#c9905f',.8,.25,.8,x,y+.5,z);I('cyl','#8a8f99',.75,.02,.75,x,y+.6,z);[[-.5,-.5],[.5,-.5],[0,.6]].forEach(q=>I('cyl','#9b6a43',.05,.5,.05,x+q[0],y+.25,z+q[1]));col(x,z,.8);}
function nest(x,z,eggs,c){const y=gy(x,z);I('tor','#8a6a3a',1.3,1.3,1.6,x,y+.3,z,Math.PI/2,0,0);I('cyl','#a8865a',1.2,.2,1.2,x,y+.15,z);for(let i=0;i<eggs;i++){const a=i/eggs*6.28;I('sph',c||'#f4ead0',.32,.42,.32,x+Math.cos(a)*.55,y+.5,z+Math.sin(a)*.55);I('sph','#c9a06a',.08,.08,.08,x+Math.cos(a)*.55+.1,y+.62,z+Math.sin(a)*.55+.25);}col(x,z,1.3);}

/* ----------------- big moments ----------------- */
/* the T. rex on Volcano Ridge: patrols, roars, and sneezes Seb out of the way if he gets too close */
function trexPatrol(cx,cz,rx,rz){const g=trex3D();W.ag.add(g);const c={x:cx+rx,z:cz,r:2.8},cf={x:c.x,z:c.z,r:1.7},ct={x:c.x,z:c.z,r:2},ct2={x:c.x,z:c.z,r:1.4};W.cols.push(c,cf,ct,ct2);W.rexCols=[c,cf,ct,ct2];let a=0,state='walk',st=0,cool=3,said=0,stepPh=0,lastStep=0;const o={ph:0,walk:true};let tum=null;
  W.ticks.push(dt=>{const P=player,dx=P.x-c.x,dz=P.z-c.z,d=Math.hypot(dx,dz);st+=dt;cool-=dt;
    /* the sneeze: Seb is blown well back, spinning, in a high hop with a trail of puffs (made bigger 24 Nov 2026: it was hard to see) */
    if(tum){const u0=tum.u;tum.u=Math.min(1,tum.u+dt*1.25);const e=1-Math.pow(1-tum.u,2),r=resolve(tum.x0+(tum.tx-tum.x0)*e,tum.z0+(tum.tz-tum.z0)*e);P.x=r[0];P.z=r[1];
      P.grp.position.set(P.x,walkY(P.x,P.z)+Math.sin(tum.u*Math.PI)*3.2,P.z);P.h+=dt*14;P.grp.rotation.y=P.h;P.grp.rotation.x=-Math.sin(tum.u*Math.PI)*.45;
      if(Math.floor(tum.u*7)!==Math.floor(u0*7))floatS('💨',P.x,walkY(P.x,P.z)+1.4,P.z,2,1);
      if(tum.u>=1){tum=null;P.lock=false;P.grp.rotation.x=0;P.wow=.8;}}
    if(state==='walk'){a+=dt*.1;const x=cx+Math.cos(a)*rx,z=cz+Math.sin(a)*rz,hx=-Math.sin(a)*rx,hz=Math.cos(a)*rz;c.x=x;c.z=z;g.rotation.y=Math.atan2(hx,hz);o.walk=true;o.ph+=dt*2.6;o.roar=0;o.sniff=0;o.look=0;
      if(!W.act&&!player.lock){if(d<7.5&&cool<2){state='sniff';st=0;}else if(d<17&&cool<=0){state='roar';st=0;}}}
    else if(state==='roar'){o.walk=false;const want=Math.atan2(dx,dz);g.rotation.y=lerpAng(g.rotation.y,want,Math.min(1,dt*3));o.roar=st<.5?st/.5:st<2.2?1:Math.max(0,1-(st-2.2)/.5);
      if(st>.45&&st-dt<=.45){DS.roar();shake(.55,1.3);floatS('💥',c.x,8.5,c.z,3);followers.forEach(f=>floatS('😱',f.x,gy(f.x,f.z)+2.4,f.z,1.4));
        say(said++%2?'ROOOAAAR! The T. rex just wants everyone to know it is the biggest!':'ROOOAAAR! The T. rex is saying hello. Very, very loudly!');}
      if(st>2.8){state='walk';cool=11;}}
    else if(state==='sniff'){o.walk=false;const want=Math.atan2(dx,dz);g.rotation.y=lerpAng(g.rotation.y,want,Math.min(1,dt*3));o.sniff=Math.min(1,st/.8);o.roar=0;
      if(st>.8&&st-dt<=.8){sfx.sniff();floatS('👃',c.x+Math.sin(g.rotation.y)*5,6,c.z+Math.cos(g.rotation.y)*5,1.6);}
      if(st>1.6&&st-dt<=1.6){DS.sneeze();shake(.6,.9);const k=Math.max(d,.01),push=Math.max(11,20-d);P.lock=true;tum={u:0,x0:P.x,z0:P.z,tx:P.x+dx/k*push,tz:P.z+dz/k*push};
        for(let i=0;i<5;i++)floatS('💨',cf.x+(Math.random()-.5)*3,6+Math.random()*2,cf.z+(Math.random()-.5)*3,3.4,1.4);floatS('💨',P.x,walkY(P.x,P.z)+2,P.z,3.6);say('Aaa... CHOO! The T. rex sneezed, and Seb tumbles out of the way. Phew! Sneak past while it is not looking!');
}
      if(st>2.4){state='walk';cool=14;}}
    trexAnim(g,W.t,o);g.position.set(c.x,gy(c.x,c.z),c.z);
    /* the T. rex is solid from nose to tail, and pushes Seb aside if it walks into him */
    {const h=g.rotation.y,fx=Math.sin(h),fz=Math.cos(h);cf.x=c.x+fx*3.9;cf.z=c.z+fz*3.9;ct.x=c.x-fx*3.6;ct.z=c.z-fz*3.6;ct2.x=c.x-fx*6.6;ct2.z=c.z-fz*6.6;
      if(!tum&&!P.lock&&Math.hypot(P.x-c.x,P.z-c.z)<12){const r=resolve(P.x,P.z);if(Math.abs(r[0]-P.x)+Math.abs(r[1]-P.z)>1e-3){P.x=r[0];P.z=r[1];P.grp.position.x=P.x;P.grp.position.z=P.z;}}}
    if(o.walk){const s=Math.floor(o.ph/Math.PI);if(s!==lastStep){lastStep=s;if(d<45){DS.thump(Math.max(.15,1-d/45));if(d<26)shake(.14*(1-d/26),.2);}}}});
  return g;}
/* a triceratops stampede across a lane every so often: rumble first, then the herd charges past */
function stampede(lz,every){const herd=[];for(let i=0;i<4;i++){const g=trike3D(i%2?'#8a7a5a':'#7a6a4a',i%2?'#c96a3a':'#d8803a',false);bakeModel(g,'trike'+(i%2));g.visible=false;W.ag.add(g);herd.push({g,dz:(i%2?-1:1)*(1+i*.6),lag:i*4.5});}
  let t=10,run=-1,dir=1,first=true;
  W.ticks.push(dt=>{const P=player;if(run<0){t-=dt;if(t<3.2&&t+dt>=3.2){DS.rumble();shake(.25,3);floatS('⚠️',P.x,walkY(P.x,P.z)+4,P.z,2.2);if(first){first=false;say('Rumble, rumble! The ground is shaking. A triceratops stampede is coming! Stand back from the dusty trail!');}}
      if(t<0){run=0;dir=R()<.5?1:-1;herd.forEach(h=>{h.g.visible=true;});}return;}
    run+=dt;let alive=false;herd.forEach((h,i)=>{const x=dir*(-74+(run*15-h.lag)),z=lz+h.dz;if(Math.abs(x)<80)alive=true;h.g.visible=Math.abs(x)<80;h.g.position.set(x,gy(x,z),z);h.g.rotation.y=dir>0?Math.PI/2:-Math.PI/2;trikeAnim(h.g,W.t+i,true,9);
      if(h.g.visible&&Math.abs(P.x-x)<3.6&&Math.abs(P.z-z)<3.4&&!P.lock){const side=P.z<lz?-1:1,r=resolve(P.x,lz+side*7.5);P.x=r[0];P.z=r[1];floatS('💨',P.x,walkY(P.x,P.z)+2,P.z,2.4);sfx.oops();say('Whoa! Seb jumps out of the way just in time!');}});
    if(Math.floor(run*2.5)!==Math.floor((run-dt)*2.5)){const d=Math.abs(P.z-lz);if(d<40){DS.thump(Math.max(.2,1-d/40));shake(.18,.25);}}
    if(run>2&&!alive){run=-1;t=every*(.8+R()*.4);herd.forEach(h=>{h.g.visible=false;});}});}
/* a long-neck hiding in a pond: it bursts up when Seb comes close */
function pondNeck(px,pz,r){const g=sauro3D('#6a8a7a');g.scale.setScalar(1.1);add(g,px,pz,-30);let st=-1,cool=0,said=false;const y0=gy(px,pz);
  W.ticks.push(dt=>{const P=player,d=Math.hypot(P.x-px,P.z-pz);cool-=dt;
    if(st<0){g.position.y=y0-30;if(d<r+5&&cool<=0&&!W.act){st=0;DS.splash();shake(.3,.8);for(let i=0;i<8;i++)floatS('💦',px+(Math.random()-.5)*r,y0+1+Math.random()*2,pz+(Math.random()-.5)*r,1.6,1.6);
        if(!said){said=true;say('SPLASH! A long-neck was hiding under the swamp water! It just wanted a look at you.');}}return;}
    st+=dt;const up=st<1.4?st/1.4:st<7?1:Math.max(0,1-(st-7)/2);g.position.y=y0-24+up*12.8;g.rotation.y=Math.atan2(P.x-px,P.z-pz);sauroAnim(g,W.t,false);
    if(st>9){st=-1;cool=16;}});}

/* ----------------- the 12 Stone pups ----------------- */
const P=[
 {id:'fossil',name:'Fossil',breed:'Plott Hound',area:'digcamp',pitch:1,spot:{x:-28,z:20,kind:'tent'},hint:'Look in a tent at Dig Camp.',
  fact:'Plott Hounds come from the mountains of North Carolina in America. Their stripy brindle coats help them hide in the woods.',rescue:{icon:'⛏️',verb:'Dig',say:'Fossil is buried up to her nose in sand! Tap to dig her out!'},
  look:{fur:'#8a5a32',stripes:true,ear:'#6b4428',ears:'long',muzzle:'#6b4428',belly:'#9a6a40',tail:'thin',eyeWhite:true}},
 {id:'digger',name:'Digger',breed:'Mudi',area:'digcamp',pitch:1.2,spot:{x:24,z:6,kind:'crate'},tag:{x:-12,z:-30,kind:'leafpile'},hint:'Digger plays tag. Look in a crate by the sieves, then in a pile of leaves.',
  fact:'Mudis are clever, curly herding dogs from Hungary. They can learn tricks very quickly!',rescue:{icon:'🪣',verb:'Tip',say:'Digger is stuck in a bucket of soil! Tap to tip him out!'},
  look:{fur:'#3a3640',fluffy:true,wool:true,ears:'pointy',muzzle:'#3a3640',belly:'#4a4650',tail:'stub',scale:.85,collar:'#ffd23f'}},
 {id:'cycad',name:'Cycad',breed:'Bergamasco',area:'fernforest',pitch:.9,spot:{x:-24,z:-16,kind:'fern'},hint:'Look in the giant ferns in the Fern Forest.',
  fact:'Bergamascos are sheepdogs from the Italian mountains. Their coats grow into flat, felty mats that keep them warm and dry.',rescue:{icon:'🌿',verb:'Untangle',say:'Cycad is tangled in fern fronds! Tap to untangle him!'},
  look:{fur:'#8a8a86',fluffy:true,wool:true,ears:'floppy',muzzle:'#9a9a94',belly:'#9a9a94',tail:'plume',hw:44,hh:52,scale:1.05}},
 {id:'rex',name:'Rex',breed:'Dogue de Bordeaux',area:'fernforest',pitch:.8,spot:{x:24,z:-24,kind:'stump'},tag:{x:-30,z:22,kind:'log'},hint:'Rex plays tag. Look behind a tree stump, then inside a hollow log.',
  fact:'Dogues de Bordeaux are big, strong mastiffs from France, with wrinkly faces and red coats. They are gentle giants!',rescue:{icon:'🦕',verb:'Lift',say:'Rex is stuck in a giant dinosaur footprint! Tap to lift him out!'},
  look:{fur:'#b5642a',ears:'floppy',muzzle:'#8a4420',muzzleBig:true,wrinkle:true,belly:'#c4743a',tail:'thin',bw:46,bh:40,scale:1.1}},
 {id:'ammo',name:'Ammo',breed:'Norwegian Lundehund',area:'cliffs',pitch:1.2,spot:{x:-20,z:-14,kind:'rockpool'},hint:'Look in a rock pool at the Fossil Cliffs.',
  fact:'Norwegian Lundehunds have six toes on each foot, and very bendy necks. They were made for climbing steep cliffs!',rescue:{icon:'🪨',verb:'Lift',say:'Ammo is wedged between two rocks on the cliff! Tap to lift her free!'},
  look:{fur:'#c98a4a',ears:'pointy',patch:{c:'#ffffff'},muzzle:'#b5763a',belly:'#ffffff',paw:'#ffffff',tail:'curl',scale:.85}},
 {id:'dusty',name:'Dusty',breed:'Canaan Dog',area:'cliffs',pitch:1.05,spot:{x:18,z:10,kind:'boulder'},tag:{x:-26,z:24,kind:'rockpool'},hint:'Dusty plays tag. Look behind a boulder, then in a rock pool.',
  fact:'Canaan Dogs are an ancient breed from the deserts of Israel. They are alert, clever and very fast.',rescue:{icon:'🌊',verb:'Catch',say:'Dusty is paddling after a wave! Tap to catch her!'},
  look:{fur:'#e6d4b0',ears:'pointy',patch:{c:'#c9a06a',side:1},muzzle:'#e6d4b0',belly:'#f4ead0',tail:'curl'}},
 {id:'mossy',name:'Mossy',breed:'Komondor',area:'swamp',pitch:.85,spot:{x:-22,z:14,kind:'log'},hint:'Look behind a mossy log in the Misty Swamp.',
  fact:'Komondors are big Hungarian guard dogs. Their white coats grow into long cords, like a mop!',rescue:{icon:'🧽',verb:'Wash',say:'Mossy is covered in swamp mud! Tap to wash him clean!'},
  look:{fur:'#f4efe2',fluffy:true,wool:true,ears:'floppy',fringe:'#f4efe2',muzzle:'#f4efe2',belly:'#f4efe2',tail:'plume',bw:48,bh:42,scale:1.12}},
 {id:'bayou',name:'Bayou',breed:'Catahoula Leopard Dog',area:'swamp',pitch:1.05,spot:{x:22,z:20,kind:'mushroom'},tag:{x:-6,z:-30,kind:'fern'},hint:'Bayou plays tag. Look by the giant mushrooms, then in the ferns.',
  fact:'Catahoula Leopard Dogs come from the swamps of Louisiana in America. Some have eyes of two different colours!',rescue:{icon:'🐸',verb:'Shoo',say:'Bayou is surrounded by croaky frogs! Tap to shoo them away!'},
  look:{fur:'#9aa4b4',spots:true,spotCs:['#3a3640','#6a5a50','#c9b8a0'],ears:'floppy',muzzle:'#c98a5a',belly:'#c9b8a0',tail:'thin',iris:'#7fc8f0',eyeWhite:true}},
 {id:'flint',name:'Flint',breed:'Xoloitzcuintli',area:'ridge',pitch:1.1,spot:{x:-24,z:20,kind:'boulder'},hint:'Look behind a black boulder on Volcano Ridge.',
  fact:'Xoloitzcuintlis are an ancient breed from Mexico, over 3,000 years old. Most have almost no hair at all!',rescue:{icon:'💨',verb:'Fan',say:'Flint is lost in the steam from a vent! Tap to fan it away!'},
  look:{fur:'#4a4248',ears:'pointy',earBig:true,muzzle:'#4a4248',belly:'#5a5258',tail:'thin',hw:42,hh:52,eyeWhite:true}},
 {id:'tusk',name:'Tusk',breed:'Neapolitan Mastiff',area:'ridge',pitch:.75,spot:{x:30,z:-24,kind:'boulder'},tag:{x:30,z:14,kind:'crater'},hint:'Tusk plays tag. Look behind a boulder past the lava bridge, then in a crater.',
  fact:'Neapolitan Mastiffs come from Naples in Italy. They are huge and very wrinkly, and they love a good snooze.',rescue:{icon:'🌋',verb:'Shade',say:'Tusk is too hot by the lava! Tap to shade him!'},
  look:{fur:'#6a6a72',ears:'floppy',muzzle:'#5a5a62',muzzleBig:true,wrinkle:true,belly:'#7a7a82',tail:'thin',bw:48,bh:42,scale:1.15}},
 {id:'ridge',name:'Ridge',breed:'Rhodesian Ridgeback',area:'nest',pitch:.95,spot:{x:-24,z:-6,kind:'leafpile'},hint:'Look in a pile of leaves by the nests.',
  fact:'Rhodesian Ridgebacks have a stripe of fur along their back that grows the wrong way, a bit like a dinosaur crest!',rescue:{icon:'🥚',verb:'Catch',say:'Ridge is juggling a giant egg! Tap to catch it before it drops!'},
  look:{fur:'#c98a4a',ears:'floppy',muzzle:'#8a5a32',belly:'#d89a5a',tail:'thin',bw:42,bh:36}},
 {id:'jura',name:'Jura',breed:'Pharaoh Hound',area:'nest',pitch:1.1,spot:{x:24,z:-14,kind:'bush'},tag:{x:-16,z:22,kind:'fern'},hint:'Jura plays tag. Look in a bush on the plateau, then in the ferns.',
  fact:'Pharaoh Hounds come from the island of Malta. When they are happy, their noses and ears blush pink!',rescue:{icon:'🌅',verb:'Wake',say:'Jura is dozing in the sunset! Tap to wake her up!'},
  look:{fur:'#d8803a',ears:'pointy',earBig:true,earIn:'#ff9ecb',muzzle:'#d8803a',nose:'#e8908a',belly:'#e89a5a',tail:'thin',hw:42,hh:54}}];
const NUGGET={id:'nugget',name:'Nugget',breed:'Cirneco dell\'Etna',area:'ambercave',pitch:1.25,spot:{x:-8,z:-10,kind:'crystal'},hint:'A sparkly pup is hiding in Amber Cave.',
  fact:'Nugget is a sparkly pup! Cirnechi dell\'Etna are small ginger hounds from Sicily. They hunted on the slopes of a real volcano, Mount Etna. You found a secret pup!',rescue:{icon:'✨',verb:'Polish',say:'Nugget is curled up behind a glowing amber crystal! Tap to polish it!'},
  look:{fur:'#e0903a',ears:'pointy',earBig:true,muzzle:'#e0903a',belly:'#f0b060',tail:'thin',scale:.85,acc:['twinkle']}};
const AMBER={id:'amberuni',name:'Amber',breed:'Dino Unicorn',uni:true,lv:1,pitch:1.1,fact:'Amber the Dino Unicorn has a coat like golden honey, with fern patterns, and a horn like a polished fossil spiral.',
  look:{fur:'#f0a830',ears:'side',earIn:'#ffd890',spots:true,spotCs:['#c97a1a','#ffd27a','#8ab84a'],muzzle:'#ffd27a',belly:'#ffd27a',nose:'#8a5a1a',iris:'#3a8a3a',limbs:'hooves',hoofC:'#8a5a2a',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','leaves'],scale:.98}};

/* ----------------- the areas ----------------- */
const HAZE={sky:'#fff0cc',gr:'#7a6a3a',hi:.7,dir:'#ffd890',di:.55,pos:[-70,45,-60]};
const DG={ground:'#c9a86a',ground2:'#b8945a',sky:'#f6d6a0',fog:[50,360],fogC:'#f2cf98',hedgeC:'#3f6e3a',noEdgeTrees:true,light:HAZE,edge:{style:'jungle'},backdrop:{style:'volcano'},biome:'jungle'};
const DA=o=>Object.assign({},DG,o);
const digcamp=DA({id:'digcamp',name:'Dig Camp',icon:'⛺',R:52,start:[0,30,Math.PI],ground:'#d8b87e',ground2:'#c49a5a',sky:'#f8dcae',fogC:'#f6d8a8',dense:.6,
  backdrop:{style:'volcano',d:230,necks:[[-34,-92,1.5]]},
  hf:(x,z)=>Math.sin(x*.06)*.5+Math.cos(z*.07)*.4,
  hello:'Welcome to Dino Valley, millions of years ago! Look, a real long-neck! Two pups are hiding at Dig Camp. Say hello to Dr Digby.',how:'Take the time machine next to the Science Lab in the village.',
  exits:[{x:-38,z:-34,to:'fernforest',arrive:inw(36,36),name:'Fern Forest',icon:'🌿',open:()=>foundIn(areaPups('digcamp'))>=2,lock:()=>{const n=foundIn(areaPups('digcamp'));return `The trail to the Fern Forest is closed. Find ${2-n} more ${2-n>1?'pups':'pup'} at Dig Camp to open it!`;}},
    {x:38,z:-34,to:'cliffs',arrive:inw(-36,34),name:'Fossil Cliffs',icon:'🐚',open:()=>!!state.gear.saddle,lock:'The cliff path is too steep to walk! Boulder could carry you, but he needs a riding saddle. Look by Dr Digby\'s tent.',ride:['🦕','Boulder carries you up the cliff path!']}],
  build(){
    {timePod(0,46.5,Math.PI,.8);W.things.push({x:0,z:43,r:4,icon:'🏡',label:'Go home',act:goHome});}
    tent(-24,8,.3,'#d8c49a',6);tent(-30,-4,.8,'#c9b48a',5);tent(-14,-14,.1,'#e0cca0',7);sign(-10,-6,'⛺ Dr Digby\'s tent',3,6);
    {const g=badger3D();add(g,-6,-2);col(-6,-2,1);const l=label('🦡 Dr Digby',4.5);l.position.set(-6,gy(-6,-2)+3.8,-2);W.ag.add(l);let k=0;
      W.ticks.push(()=>{g.rotation.y=Math.atan2(player.x+6,player.z+2);g.position.y=gy(-6,-2)+Math.abs(Math.sin(W.t*2))*.06;});
      W.things.push({x:-6,z:-2,r:4,icon:'💬',label:'Dr Digby',act:()=>{sfx.chime();say(state.gear.saddle?DIG[1+(k++)%(DIG.length-1)]:DIG[0]);}});}
    {const x=-14,z=-4,y=gy(x,z),st=grp();I('box','#9b6a43',2,.2,.9,x,y+1.2,z);[[-.8,-.3],[.8,-.3],[-.8,.3],[.8,.3]].forEach(q=>I('box','#5b4636',.15,1.2,.15,x+q[0],y+.6,z+q[1]));
      mk('box','#8a3a2a',1.4,.35,1,0,0,0,st);mk('box','#5a2a1a',1.5,.2,1.1,0,-.2,0,st);mk('cyl','#c9a040',.15,.25,.15,0,.25,.35,st);[-1,1].forEach(s=>{mk('box','#5a2a1a',.12,.9,.2,s*.7,-.6,0,st);mk('tor','#c9a040',.18,.18,.18,s*.72,-1.05,0,st);});
      add(st,x,z,y+1.55);st.visible=!state.gear.saddle;col(x,z,1.2);W.ticks.push(()=>{st.rotation.y+=.02;});
      W.things.push({x,z:z+2.4,r:3.4,icon:'🐎',label:'Saddle',show:()=>!state.gear.saddle,act:()=>{state.gear.saddle=true;state.stars+=5;save();hud();st.visible=false;sfx.jingle();confetti(30);
        card({art:'<div style="font-size:110px;line-height:1">🦕</div>',h:'You found the riding saddle!',p:'Now Boulder can carry you up the cliff path to the Fossil Cliffs. Its trail is on the right of Dig Camp!'});}});}
    digPit(16,-16,14,9);skeleton(16,-16,Math.PI/2+.1);sign(8,-10,'🦖 T. rex dig',3,5);
    sieve(20,2);sieve(28,4);wheelbarrow(10,-4,.6);{const y=gy(26,-2);for(let i=0;i<3;i++)I('cyl',['#e8423a','#3d8fe0','#ffd23f'][i],.4,.6,.4,26+i*.9,y+.3,-2);col(27,-2,1.4);}
    sign(8,14,'🦴 Bone Dig',3,5);W.things.push({x:8,z:12,r:4,icon:'🦴',label:'Bone Dig',act:()=>{sfx.chime();startCollect('bonedig');}});
    {const g=boulder3D();add(g,-8,18);col(-8,18,1.3);const l=label('🦕 Boulder',4.5);l.position.set(-8,gy(-8,18)+3.4,18);W.ag.add(l);let wob=0;
      W.ticks.push(dt=>{wob=Math.max(0,wob-dt);g.rotation.y=Math.atan2(player.x+8,player.z-18)+Math.sin(W.t*.6)*.3;trikeAnim(g,W.t,false);g.rotation.z=Math.sin(wob*20)*.08*wob;});
      W.things.push({x:-8,z:18,r:4,icon:'💗',label:'Pat Boulder',act:()=>{wob=1.2;DS.purr();floatS('💗',-8,gy(-8,18)+3,18,1.8);
        say(state.gear.saddle?'Boulder purrs like a cat! He loves giving rides. Try Dino Dash in the Fern Forest!':'Boulder purrs like a cat! He wants to give you a ride, but he needs a saddle first.');}});}
    beams(5);pollen(60);
    let far=25;W.ticks.push(dt=>{far-=dt;if(far<0&&!W.act){far=38+Math.random()*20;DS.roar(.35);shake(.08,.8);say('Did you hear that? A far-away ROAR, from up by the volcano!');}});}});
const fernforest=DA({id:'fernforest',name:'Fern Forest',icon:'🌿',R:54,start:inw(36,36),ground:'#6aa04a',ground2:'#4f8a3a',sky:'#e8e0a8',fogC:'#d8dca0',fog:[40,330],dense:1.6,
  light:{sky:'#f4ffd8',gr:'#4a6a2a',hi:.68,dir:'#fff0b0',di:.6,pos:[-70,60,-40]},edgeGaps:[[30,-46,12],[37,-57,12],[44,-68,14]],
  backdrop:{style:'volcano',d:215},
  hf:(x,z)=>Math.sin(x*.08+1)*.6+Math.cos(z*.06)*.5,
  hello:'The Fern Forest! Giant ferns and trees from dinosaur times. Listen for rumbling, and stay off the dusty trail when the triceratops stampede! Two pups are hiding.',how:'Find 2 pups at Dig Camp.',
  exits:[{x:36,z:36,to:'digcamp',arrive:inw(-38,-34),name:'Dig Camp',icon:'⛺'},
    {x:0,z:-50,to:'swamp',arrive:inw(0,48),name:'Misty Swamp',icon:'🐸',open:()=>foundIn(areaPups('fernforest'))>=2,lock:()=>{const n=foundIn(areaPups('fernforest'));return `Boulder will wade across the river to the Misty Swamp when the Forest pups are safe. Find ${2-n} more ${2-n>1?'pups':'pup'}!`;},ride:['🦕','Boulder wades across the river!']}],
  build(){
    {const m=new THREE.Mesh(G.plane,M('#b8945a'));m.scale.set(110,1,5.5);m.position.set(0,gy(0,2)+.06,2);W.ag.add(m);}
    [-30,30].forEach(x=>sign(x,-3,'⚠️ Stampede crossing',3,6));
    stampede(2,26);
    {const w=new THREE.Mesh(G.plane,M('#6cc6ef'));w.scale.set(240,1,14);w.position.set(40,1.4,-82);W.ag.add(w);W.disp.push(w.material);
      for(let i=0;i<3;i++){const g=sauro3D(i%2?'#8a9a7a':'#7a8a6a');g.scale.setScalar(.8+i*.15);W.ag.add(g);const o={x:-60+i*36,sp:1.6+i*.3};
        W.ticks.push(dt=>{o.x+=dt*o.sp;if(o.x>130)o.x=-60;g.position.set(o.x,0,-80+i*3);g.rotation.y=Math.PI/2;sauroAnim(g,W.t+i,true,.8);});}}
    for(let i=0;i<5;i++){const a=i*1.3,r=10+i*6;footprint(Math.cos(a)*r,Math.sin(a)*r+16,a+1,1.3);}
    sign(-12,24,'🦕 Dino Dash',3,5);W.things.push({x:-12,z:22,r:4,icon:'🦕',label:'Dino Dash',act:()=>{sfx.chime();if(!state.gear.saddle){say('Boulder wants to race, but he needs his riding saddle. It is by Dr Digby\'s tent at Dig Camp!');return;}startCollect('dinodash');}});
    {const g=boulder3D();add(g,-16,24);col(-16,24,1.2);W.ticks.push(()=>{g.visible=!W.act;trikeAnim(g,W.t,false);g.rotation.y=Math.atan2(player.x+16,player.z-24);});}
    beams(9);pollen(70);
    {const L=[];for(let i=0;i<5;i++){const g=grp();mk('cyl','#3d8fe0',.08,1.1,.08,0,0,0,g).rotation.x=Math.PI/2;[-1,1].forEach(s=>{const w=mk('box','#dff4ff',.9,.02,.25,s*.45,.05,.15,g);w.material=glowM('#dff4ff',{transparent:true,opacity:.6});});W.ag.add(g);L.push({g,a:i*1.3,r:6+i*5,h:1.5+i*.4});}
      W.ticks.push(dt=>{L.forEach((o,i)=>{o.a+=dt*(.5+i*.08);const x=Math.cos(o.a)*o.r,z=Math.sin(o.a*1.3)*o.r*.6-10;o.g.position.set(x,gy(x,z)+o.h+Math.sin(W.t*3+i)*.3,z);o.g.rotation.y=o.a+Math.PI;});});}}});
const cliffs=DA({id:'cliffs',name:'Fossil Cliffs',icon:'🐚',R:52,start:inw(-36,34),ground:'#d8ccb0',ground2:'#c9b896',sky:'#bfe0f4',fogC:'#d8e8f0',fog:[60,360],biome:'fossils',
  light:{sky:'#ffffff',gr:'#a89a7a',hi:.72,dir:'#fff6e0',di:.55,pos:[70,80,30]},
  edge:{style:'cliff',c:['#e8dcc0','#d8ccb0','#c9bca0'],band:'#8a96a4',cap:'#7aa85a',h:[7,13]},edgeGaps:[[52,4,24]],backdrop:{style:'volcano',d:205},
  gmix:(x,z)=>x>34?1:(Math.sin(x*.21)+Math.sin(z*.17+x*.05)+2)*.25,
  hello:'The Fossil Cliffs! Stripy cliffs full of ammonites, and the sea is full of sea reptiles. Look up for the pterosaurs! Two pups are hiding.',how:'Bring the riding saddle from Dig Camp, so Boulder can carry you up the cliff path.',
  exits:[{x:-36,z:34,to:'digcamp',arrive:inw(38,-34),name:'Dig Camp',icon:'⛺'},
    {x:0,z:-50,to:'ridge',arrive:inw(0,48),name:'Volcano Ridge',icon:'🌋',gate:{type:'stone',key:'ridge_rocks',look:'rockfall',verb:'digs through the rockfall',done:'Dig, dig, dig! The rockfall is cleared. The path to Volcano Ridge is open!'}}],
  build(){
    {const w=new THREE.Mesh(G.plane,M('#4fb8d8'));w.scale.set(300,1,300);w.position.set(150,-2.2,0);W.ag.add(w);W.disp.push(w.material);}
    [[78,-18,1],[96,16,1.2],[70,30,.9]].forEach((q,i)=>{const g=grp(),C='#4a7a8a';let par=g;for(let k=0;k<5;k++){const n=grp();n.position.set(0,k?1.6:0,0);n.rotation.x=k?-.1:.5;par.add(n);mk('cyl',C,.6-k*.06,1.8,.6-k*.06,0,.8,0,n);par=n;}
      const h=grp();h.position.set(0,1.8,0);h.rotation.x=1.2;par.add(h);mk('sph',C,.6,.5,1.1,0,0,.4,h);[-1,1].forEach(s=>mk('sph','#26232e',.12,.14,.1,s*.42,.18,.6,h));mk('sph',C,2.6,.8,3.6,0,-.4,-1.2,g);
      g.scale.setScalar(q[2]*1.6);add(g,q[0],q[1],-2.4);bakeModel(g,'plesio');W.ticks.push(()=>{g.position.y=-2.6+Math.sin(W.t*.8+i)*.4;g.rotation.y=Math.sin(W.t*.2+i)*.8-Math.PI/2;});});
    pteroFlock(3,10,-10,34,24);pteroSwoop(22);
    sign(-6,10,'🐚 Ammonite Hunt',3,6);W.things.push({x:-6,z:8,r:4,icon:'🐚',label:'Ammonite Hunt',act:()=>{sfx.chime();startCollect('ammonites');}});
    [[-30,-20],[-8,-30],[26,-24]].forEach(p=>{const y=gy(p[0],p[1]);for(let k=0;k<5;k++)I('tor','#c9b48a',2-k*.38,2-k*.38,1.2,p[0]+k*.3,y+2.1,p[1],0,.4,0);I('cyl','#b8a078',1.9,.3,1.9,p[0],y+2.1,p[1],Math.PI/2,.4,0);I('box','#a8987a',.8,2.1,.8,p[0],y+1,p[1]);col(p[0],p[1],1.6);});
    pollen(30,'#ffffff',.16);}});
cliffs.hf=(x,z)=>{const h=Math.sin(x*.08)*.5+Math.cos(z*.07)*.4,t=Math.max(0,Math.min(1,(x-36)/10)),u=Math.max(0,Math.min(1,(Math.hypot(x,z)-50)/6));return h*(1-t)-1.5*t-3*u;};
const swamp=DA({id:'swamp',name:'Misty Swamp',icon:'🐸',R:50,start:inw(0,48),ground:'#6a7a3a',ground2:'#4a5a2a',sky:'#a9c294',fogC:'#b9cfa6',fog:[16,120],biome:'swamp',
  light:{sky:'#e0f0d0',gr:'#3a4a2a',hi:.72,dir:'#e8f4d8',di:.35,pos:[-30,80,-30]},skyObj:{flies:70},backdrop:{style:'volcano',d:180},
  hf:(x,z)=>Math.sin(x*.09)*.4+Math.cos(z*.08+1)*.4,
  hello:'The Misty Swamp. Soft green fog, giant lily pads and croaky frogs. Something big is hiding in the water... Two pups are hiding too.',how:'Find 2 pups in the Fern Forest, and Boulder will wade across the river.',
  exits:[{x:0,z:50,to:'fernforest',arrive:inw(0,-50),name:'Fern Forest',icon:'🌿'},
    {x:36,z:-34,to:'nest',arrive:inw(-38,30),name:'Long-neck\'s Nest',icon:'🥚',nlock:{key:'nl_nest',kind:['times','add','take'],n:3,done:'Click! The explorer\'s padlock opens. The path to the Long-neck\'s Nest is clear!'}}],
  build(){
    const ponds=[[14,-12,10],[-20,-14,6],[-8,26,5]];ponds.forEach(p=>{pond(p[0],p[1],p[2],'#5f9a8a');for(let i=0;i<Math.round(p[2]*1.2);i++){const a=i*2.4,r=p[2]*.3+((i*37)%10)/10*p[2]*.55,x=p[0]+Math.cos(a)*r,z=p[1]+Math.sin(a)*r;I('cyl','#5fae46',.9+(i%3)*.3,.12,.9+(i%3)*.3,x,gy(p[0],p[1])+.16,z);if(i%3===0)I('sph','#ff9ecb',.25,.2,.25,x+.3,gy(p[0],p[1])+.3,z);}});
    pondNeck(14,-12,10);
    {const L=[];for(let i=0;i<6;i++){const p=ponds[i%3],a=i*1.7,x=p[0]+Math.cos(a)*p[2]*.5,z=p[1]+Math.sin(a)*p[2]*.5,s=spr('🐸',1.1,x,gy(p[0],p[1])+.6,z);L.push({s,x,z,y:gy(p[0],p[1])+.6,t:Math.random()*4});}
      W.ticks.push(dt=>{L.forEach(o=>{o.t-=dt;if(o.t<0){o.t=2+Math.random()*4;}const k=Math.max(0,1-Math.abs(o.t-.4)/.4);o.s.position.y=o.y+k*1.2;});});}
    {const y=gy(-26,0);for(let i=0;i<10;i++){const x=-34+i*2.2,z=-2+Math.sin(i*.5)*2;I('box','#9b6a43',2.1,.2,2.4,x,gy(x,z)+.25,z,0,.2,0);}}
    sign(-12,8,'🪷 Lily Pad Steps',3,6);W.things.push({x:-12,z:6,r:4,icon:'🪷',label:'Lily Pad Steps',act:()=>{sfx.chime();startStones('activity','lilysteps');}});
    pollen(40,'#e8ffd0',.18);}});
const ridge=DA({id:'ridge',name:'Volcano Ridge',icon:'🌋',R:50,start:inw(0,48),ground:'#4a3e3e',ground2:'#6a5248',sky:'#e8865a',fogC:'#d8784e',fog:[40,300],biome:'lava',
  light:{sky:'#ffd0b0',gr:'#6a3a2a',hi:.74,dir:'#ffb070',di:.72,pos:[0,40,-90]},backdrop:{style:'volcano',d:190,s:1.3},edge:{style:'cliff',c:['#2a2426','#3a3234','#4a3c3a'],band:'#ff6a1a',cap:'#26201f',h:[6,12]},
  hf:(x,z)=>{const t=Math.max(0,1-Math.abs(z+14)/5.5);return Math.sin(x*.07)*.5+Math.cos(z*.09)*.4-t*t*(3-2*t)*7;},gmix:(x,z)=>Math.abs(z+14)<5?1:(Math.sin(x*.21)+Math.sin(z*.17+x*.05)+2)*.25,
  hello:'Volcano Ridge! Black rock, hissing steam and a river of glowing lava far below the bridge. Shh... a T. rex lives here. Two pups are hiding.',how:'A Stone pup digs through the rockfall at the Fossil Cliffs.',
  exits:[{x:0,z:50,to:'cliffs',arrive:inw(0,-50),name:'Fossil Cliffs',icon:'🐚'},
    {x:-36,z:-34,to:'nest',arrive:inw(38,30),name:'Long-neck\'s Nest',icon:'🥚',open:()=>foundIn(areaPups('ridge'))>=2,lock:()=>{const n=foundIn(areaPups('ridge'));return `The path to the Long-neck's Nest opens when the Ridge pups are safe. Find ${2-n} more ${2-n>1?'pups':'pup'}!`;}},
    {x:50,z:2,to:'ambercave',arrive:inw(-30,0,.7),name:'Amber Cave',icon:'🟠',gate:{type:'comet',key:'amber_float',look:'floatrock',need:0,verb:'switches off gravity, and the giant boulder floats away',done:'Whoosh! The boulder floats up and away. Amber Cave is open!'},lock:'A giant boulder blocks Amber Cave. A Comet pup from Planet Hop could float it away!'}],
  build(){
    {const lv=new THREE.Mesh(G.plane,glowM('#ff6a1a'));lv.scale.set(120,1,6);lv.position.set(0,-5.6,-14);lv.userData.noBake=true;W.ag.add(lv);W.ticks.push(()=>{lv.material.color.setHSL(.06+Math.sin(W.t*1.5)*.012,1,.52+Math.sin(W.t*2.3)*.05);});
      let t=0;W.ticks.push(dt=>{t-=dt;if(t<0){t=.25;floatS(pick(['🔥','✨']),(Math.random()-.5)*80,-4,-14+(Math.random()-.5)*4,1.4,1.4);}});}
    rect(-60,-19.5,-3,-8.5);rect(3,-19.5,60,-8.5);
    {const y=gy(0,-3.5);I('box','#6a5a52',5.4,1,13,0,y-.4,-14);[-1,1].forEach(s=>{for(let i=0;i<6;i++)I('box','#4a3c3a',.5,1.1,.5,s*2.5,y+.6,-19+i*2);I('box','#5a4a44',.3,.25,12,s*2.5,y+1.2,-14);});W.decks.push({x1:-2.6,z1:-20.5,x2:2.6,z2:-7.5,y:y+.1});}
    trexPatrol(2,-34,18,7);pteroFlock(3,0,-20,38,26);
    sign(-16,16,'🦕 Baby Dino Round-up',3,6.5);W.things.push({x:-16,z:14,r:4,icon:'🦕',label:'Round-up',act:()=>{sfx.chime();startHerd('activity','babydinos');}});
    pollen(50,'#ffb070',.2);}});
const nestA=DA({id:'nest',name:'Long-neck\'s Nest',icon:'🥚',R:50,start:inw(-38,30),ground:'#c9a46a',ground2:'#a8904a',sky:'#f6b07a',fogC:'#f4c090',fog:[50,330],dense:.5,
  light:{sky:'#ffd6b0',gr:'#7a4a3a',hi:.66,dir:'#ff9a5a',di:.66,pos:[-90,28,-60]},backdrop:{style:'volcano',d:175,s:1.2,az:-70},
  hello:'The Long-neck\'s Nest, high on a plateau at sunset. The mother long-neck is watching over her eggs. Two pups are hiding.',how:'Open the explorer\'s padlock in the Misty Swamp, or find 2 pups on Volcano Ridge.',
  exits:[{x:-38,z:30,to:'swamp',arrive:inw(36,-34),name:'Misty Swamp',icon:'🐸'},{x:38,z:30,to:'ridge',arrive:inw(-36,-34),name:'Volcano Ridge',icon:'🌋'}],
  build(){
    {const g=sauro3D('#9a8a6a');g.scale.setScalar(1.3);add(g,0,-34);g.rotation.y=0;W.cols.push({x:0,z:-34,r:6},{x:0,z:-26,r:2.5});let lean=0;
      W.ticks.push(dt=>{const d=Math.hypot(player.x,player.z+26),want=d<20?1:0;lean+=(want-lean)*Math.min(1,dt*1.2);sauroAnim(g,W.t,false);const n=g.userData.d.neck;n[0].rotation.x=.75+lean*.5;n[1].rotation.x=-.12+lean*.25;n[2].rotation.x=-.12+lean*.2;
        n[0].rotation.y=lean*Math.atan2(player.x,player.z+26)*.25+Math.sin(W.t*.35)*.18*(1-lean);if(lean>.9&&Math.random()<dt*.4)floatS('💗',player.x,walkY(player.x,player.z)+5,player.z,1.6);});}
    nest(2.6,-3.5,0);[[-12,-14,5],[12,-14,4],[-16,2,6],[16,4,5],[-8,14,4],[10,16,6]].forEach(q=>nest(q[0],q[1],q[2]));
    pteroFlock(2,0,0,40,30);
    sign(20,18,'🥚 Egg Catch',3,5);W.things.push({x:20,z:16,r:4,icon:'🥚',label:'Egg Catch',act:()=>{sfx.chime();startFlies('activity','eggcatch');}});
    pollen(50,'#ffe0a0',.2);}});
const ambercave=DA({id:'ambercave',name:'Amber Cave',icon:'🟠',R:32,start:inw(-30,0,.7),ground:'#8a5a2a',ground2:'#b8762a',sky:'#2a1808',fogC:'#4a2a10',fog:[20,90],hedgeC:'#5a3a1a',noEnrich:true,backdrop:null,
  light:{sky:'#ffd890',gr:'#5a3010',hi:.85,dir:'#ffc060',di:.4,pos:[0,60,10]},edge:{style:'cliff',c:['#5a3a1a','#6a4420','#4a2e14'],band:'#e8a030',cap:'#3a2410',h:[9,14]},indoor:true,
  hello:'Amber Cave! Glowing golden amber, millions of years old. Look closely: some have tiny insects inside. A secret sparkly pup and a treasure chest are hidden here!',how:'A Comet pup from Planet Hop floats away the boulder on Volcano Ridge.',
  exits:[{x:-32,z:0,to:'ridge',arrive:inw(50,0,.85),name:'Volcano Ridge',icon:'🌋'}],
  build(){const am=glowM('#ffb030'),am2=new THREE.MeshLambertMaterial({color:'#ff9a20',transparent:true,opacity:.72,emissive:'#7a3a00'});W.disp.push(am2);
    [[-14,-14],[14,-12],[16,12],[-12,16],[0,-22],[22,0],[-22,-4],[4,20]].forEach((p,i)=>{const y=gy(p[0],p[1]);for(let k=0;k<4;k++){const m=new THREE.Mesh(G.cone,k%2?am:am2),h=2+k*.9+(i%3);m.scale.set(.7+k*.15,h,.7+k*.15);m.position.set(p[0]+(k-1.5)*.9,y+h/2,p[1]+(k%2)*.7);m.rotation.z=(k-1.5)*.2;W.ag.add(m);}
      if(i%2===0){const bug=grp();mk('sph','#3a2a1a',.12,.1,.22,0,0,0,bug);[-1,1].forEach(s=>mk('box','#c9b8a0',.25,.02,.12,s*.15,.06,0,bug));add(bug,p[0]-.9,p[1]+.1,y+1.4);}col(p[0],p[1],2);});
    treasureChest(10,-8,'ambercave');pollen(40,'#ffd27a',.2);}});

/* ----------------- activities ----------------- */
const bgSVG=(sky,gr,extra)=>()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="${sky}"/><path d="M380 520 L560 120 L740 520Z" fill="#5a4a4a" opacity=".55"/><rect x="530" y="112" width="60" height="18" fill="#ff8a2a" opacity=".8"/><rect y="520" width="1024" height="248" fill="${gr}"/>${extra||''}</svg>`;
function babyDinoSVG(){const k=INK;return `<svg viewBox="0 0 100 90"><ellipse cx="50" cy="56" rx="28" ry="22" fill="#8fd170" stroke="${k}" stroke-width="4"/><path d="M24 60 Q8 60 6 46 Q16 54 26 52Z" fill="#8fd170" stroke="${k}" stroke-width="4" stroke-linejoin="round"/>
  <circle cx="72" cy="34" r="17" fill="#8fd170" stroke="${k}" stroke-width="4"/><circle cx="77" cy="30" r="5" fill="#fff" stroke="${k}" stroke-width="2"/><circle cx="78" cy="30" r="2.5" fill="${k}"/><path d="M76 42 Q82 45 87 40" fill="none" stroke="${k}" stroke-width="3" stroke-linecap="round"/>
  <circle cx="86" cy="38" r="3" fill="#ff9ecb" opacity=".8"/><path d="M40 36 L44 28 L48 36 M52 35 L56 27 L60 35" fill="#ffd23f" stroke="${k}" stroke-width="3" stroke-linejoin="round"/><rect x="36" y="72" width="9" height="12" rx="4" fill="#6fb85a" stroke="${k}" stroke-width="3"/><rect x="58" y="72" width="9" height="12" rx="4" fill="#6fb85a" stroke="${k}" stroke-width="3"/></svg>`;}
const swampBG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#a9c294"/><rect y="300" width="1024" height="468" fill="#5f9a8a"/>`;for(let i=0;i<14;i++)s+=`<ellipse cx="${(i*151)%1000+20}" cy="${330+(i*67)%400}" rx="46" ry="16" fill="#5fae46" opacity=".8"/>`;
  for(let i=0;i<8;i++)s+=`<rect x="${i*130+20}" y="${150+(i%3)*30}" width="8" height="${160-(i%3)*30}" fill="#6a7a3a"/>`;return s+'<text x="960" y="120" font-size="60" text-anchor="middle">🐸</text></svg>';};
const dinoPen=()=>bgSVG('#e8865a','#3a3234','<rect y="560" width="1024" height="30" fill="#ff6a1a" opacity=".6"/>')().replace('</svg>','')+penBox2('🥚 Safe nest','#c9a46a','#8a6a3a','#5b4636')+'</svg>';
const nestBG=()=>{let s=bgSVG('#f6b07a','#c9a46a')().replace('</svg>','');s+='<path d="M0 520 Q300 380 1024 300 L1024 520Z" fill="#b8904a"/>';s+='<ellipse cx="900" cy="620" rx="110" ry="40" fill="#8a6a3a" stroke="#5b4636" stroke-width="6"/>';return s+'</svg>';};
COLLECT.bonedig={k:'bonedig',area:'digcamp',icon:'🦴',size:2,h:1.6,items:[[-30,-18],[28,-26],[-34,24],[32,20],[2,-30],[-2,26]],start:[8,9,Math.PI],thing:'dinosaur bone',art:'🦴',
  intro:'Bone Dig! Find 6 dinosaur bones around Dig Camp for Dr Digby\'s museum!',title:'You found all the bones! Dr Digby can build a whole dinosaur!'};
COLLECT.dinodash={k:'dinodash',area:'fernforest',icon:'🌿',size:2.2,h:1.8,items:[[-34,-12],[-8,-28],[20,-34],[34,-8],[18,22],[-30,30]],start:[-12,19,Math.PI],thing:'juicy fern',art:'🦕',ride:'boulder',
  intro:'Dino Dash! Ride Boulder through the Fern Forest and collect 6 juicy ferns for his lunch. Watch out for the stampede!',title:'Boulder munched all the juicy ferns! What a ride!'};
COLLECT.ammonites={k:'ammonites',area:'cliffs',icon:'🐚',size:2,h:1.6,items:[[-34,-4],[-14,-36],[14,-34],[30,-14],[24,26],[-16,30]],start:[-6,5,Math.PI],thing:'ammonite',art:'🐚',
  intro:'Ammonite Hunt! Ammonites were sea animals with spiral shells. Find 6 ammonite fossils along the Fossil Cliffs!',title:'You found all the ammonites! A real fossil hunter!'};
COUNTS.lilysteps={k:'lilysteps',icon:'🪷',rounds:[{step:6,word:'sixes'},{step:7,word:'sevens'},{start:60,step:-5,word:'fives, counting down'}],bg:swampBG,cls:'',intro:'Hop across the giant lily pads in the Misty Swamp! Count the jumps.',title:'You hopped all the way across the swamp!'};
HERDS.babydinos={k:'babydinos',icon:'🦕',n:6,animal:babyDinoSVG,herder:()=>buddyPup(),bg:dinoPen,title:'All the baby dinosaurs are safe in the nest!',
  intro:p=>`Some baby dinosaurs have wandered too close to the steam vents! Help ${p.name} guide them back to the safe nest. Drag your finger and ${p.name} will follow. The babies scurry away from ${p.name}!`};
CATCH.eggcatch={k:'eggcatch',icon:'🥚',need:15,bg:nestBG,cls:'',inner:'<b>🥚</b>',art:'🥚🪺',fall:true,intro:'The eggs are rolling down the hill! Tap an egg while it wobbles to catch it and pop it back in the nest. Catch 15!',tip:'Wait until it wobbles, then tap!',title:'All the eggs are safe in the nest!'};
regAct('bonedig',{name:'Bone Dig',icon:'🦴',island:'dino',area:'digcamp',where:'Dig Camp',play:()=>arcadeTravel('digcamp',COLLECT.bonedig.start,()=>startCollect('bonedig'),'Bone Dig is about to start!')});
regAct('dinodash',{name:'Dino Dash',icon:'🦕',island:'dino',area:'fernforest',where:'the Fern Forest',play:()=>arcadeTravel('fernforest',COLLECT.dinodash.start,()=>startCollect('dinodash'),'Dino Dash is about to start!')});
regAct('ammonites',{name:'Ammonite Hunt',icon:'🐚',island:'dino',area:'cliffs',where:'the Fossil Cliffs',play:()=>arcadeTravel('cliffs',COLLECT.ammonites.start,()=>startCollect('ammonites'),'Ammonite Hunt is about to start!')});
regAct('lilysteps',{name:'Lily Pad Steps',icon:'🪷',island:'dino',area:'swamp',where:'the Misty Swamp',play:()=>startStones('arcade','lilysteps')});
regAct('babydinos',{name:'Baby Dino Round-up',icon:'🦕',island:'dino',area:'ridge',where:'Volcano Ridge',play:()=>startHerd('arcade','babydinos')});
regAct('eggcatch',{name:'Egg Catch',icon:'🥚',island:'dino',area:'nest',where:'the Long-neck\'s Nest',play:()=>startFlies('arcade','eggcatch')});

regIsland({id:'dino',name:'Dino Valley',icon:'🦕',type:'stone',req:['gadget','rescue'],rideName:'The time machine',ride:'the time machine',from:'time machine next to the Science Lab',rideIcon:'⏳',
  rideSay:'Whirr! The clock hands spin faster and faster, the sky flicks from day to night, and whoosh! Back to the time of the dinosaurs!',
  homeSay:'The time machine whirrs forward, all the way back to today!',homePos:[-11.5,-24.5,Math.atan2(11.5,24.5)],
  badge:'Dino Badge',cert:'Seb, Dino Valley Hero!',bossHint:'Amber the Dino Unicorn is waiting at the Long-neck\'s Nest!',
  nextSay:'Hooray! Dino Valley is safe! Have you been to Planet Hop too?',
  map:{shape:'M60 420 Q30 250 140 160 Q260 60 430 40 Q600 60 720 160 Q830 250 800 420 Q600 470 430 460 Q260 470 60 420Z',
    nodes:{digcamp:[430,368],fernforest:[230,300],cliffs:[630,300],swamp:[200,140],ridge:[660,140],nest:[430,80],ambercave:[772,250]},
    links:[['digcamp','fernforest'],['digcamp','cliffs'],['fernforest','swamp'],['cliffs','ridge'],['swamp','nest'],['ridge','nest'],['ridge','ambercave']]},
  boss:{area:'nest',x:0,z:-4,perch:.7,uni:AMBER,
    story:[['m','Muddle the Magpie is sitting on a nest, trying to hatch the shiny Dino Star as if it were an egg. "Shh, Seb! It will hatch any minute!"'],
      ['b','Crack! Crack! The real eggs beside him wobble and hatch, and the baby long-necks think Muddle is their mum! "Mama!" they squeak.'],
      ['u','Amber the Dino Unicorn laughs softly. "Every egg needs its own family, Muddle. Waiting for good things is better than borrowing shiny ones."'],
      ['m','"You are right," says Muddle, and he gives back the shiny Dino Star. "Can I be the babysitter instead?"'],
      ['b','The mother long-neck nods, and all 12 Stone pups cheer! Amber gives Seb the Dino Badge. Hooray for Seb!']],
    after:['Amber says: thank you for finding every pup in Dino Valley!','Muddle says: I am the best babysitter in the whole valley!','Amber says: the mother long-neck says thank you, too.']},
  pups:P,bonus:[NUGGET],areas:[digcamp,fernforest,cliffs,swamp,ridge,nestA,ambercave]});

/* ----------------- Professor Fizz's time machine in the village ----------------- */
function timePod(x,z,face,s){s=s||1;const g=grp(),y=gy(x,z);mk('cyl','#8a6a3a',2.8*s,.5*s,2.8*s,0,.25*s,0,g);mk('sph','#c9a040',2.3*s,2.4*s,2.3*s,0,2.8*s,0,g);mk('cyl','#b8862a',2.35*s,.3*s,2.35*s,0,2.8*s,0,g);
  mk('cyl','#ffffff',1.1*s,.15*s,1.1*s,0,3.1*s,2.15*s,g).rotation.x=Math.PI/2;mk('tor','#8a5a1a',1.1*s,1.1*s,.6*s,0,3.1*s,2.2*s,g);
  const hands=[];[[.75,.12],[.5,.16]].forEach((q,i)=>{const h=grp();h.position.set(0,3.1*s,2.28*s);g.add(h);mk('box','#26232e',q[1]*s,q[0]*s,.05*s,0,q[0]*s/2,0,h);hands.push(h);});
  mk('cyl','#9bdcff',.6*s,.1*s,.6*s,-1.4*s,3.9*s,1.4*s,g).rotation.set(Math.PI/2,0,-.8);[[-1.6,1.9],[1.7,2.2],[1.4,3.6]].forEach(q=>{mk('cyl','#3a3338',.25*s,.2*s,.25*s,q[0]*s,q[1]*s,1.4*s,g).rotation.x=Math.PI/2;});
  const lev=grp();lev.position.set(1.9*s,2.6*s,.8*s);g.add(lev);mk('cyl','#5b6378',.08*s,1.2*s,.08*s,0,.5*s,0,lev);mk('sph','#3fae5a',.25*s,.25*s,.25*s,0,1.1*s,0,lev);lev.rotation.z=-.5;
  mk('cone','#c9a040',.4*s,.8*s,.4*s,0,5.4*s,0,g);mk('sph','#ffd23f',.25*s,.25*s,.25*s,0,5.9*s,0,g,true);
  g.rotation.y=face;add(g,x,z,y);col(x,z,2.6*s);W.ticks.push(()=>{hands[0].rotation.z=-W.t*1.2;hands[1].rotation.z=-W.t*.1;});return g;}
const vb=AREAS.village.build;AREAS.village.build=function(){vb.apply(this,arguments);
  const x=-15.5,z=-29.5,fc=Math.atan2(-x,-z);timePod(x,z,fc,1);const open=islOpen('dino'),lb=label(open?'⏳ Time machine to Dino Valley':'⏳ Dino Valley 🔒',8);lb.position.set(x,gy(x,z)+8,z);W.ag.add(lb);
  W.things.push({x:x+Math.sin(fc)*3.8,z:z+Math.cos(fc)*3.8,r:4,icon:'⏳',label:'Time machine',act:()=>{if(!islOpen('dino')){rideTo('dino');return;}player.lock=true;DS.rumble();shake(.3,1.4);
    for(let i=0;i<10;i++)setTimeout(()=>floatS(pick(['⏳','✨','💫']),x+(Math.random()-.5)*4,gy(x,z)+2+Math.random()*4,z+(Math.random()-.5)*4,1.6),i*120);setTimeout(()=>rideTo('dino'),1300);}});};
window.DINO={sauro3D,trex3D,trike3D,ptero3D,shake,DS,treeFern,cycad,monkeyPuzzle};
})();
