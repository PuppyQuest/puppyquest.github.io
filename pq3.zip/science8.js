/* ================================================================
   Seb's Puppy Quest 3: Release 8, eight more science pups.
   Dino Valley: Barnum Brownie, Gideon Man-tail, Tray (Mary Anning's
   real dog) and Roy Chap-pup Andrews. Planet Hop: Strelka (a real
   space dog), Katherine Johnspup, Nicolaus Copupnicus and Stephen
   Pawking. Facts are about the real people and dogs (checked 23 Nov
   2026); the pups are characters inspired by them. Try-at-home cards
   are safe and need a grown-up where it matters.
   Also: Release 8 badges and certificates, card shapes for the new
   breeds.
   ================================================================ */
(function(){
const {sortExp,tapExp,choiceRow,bigBtn,place,labBenchSVG}=SCIX,k=INK;
const svgEl=(w,h,inner,vb)=>`<svg viewBox="${vb||`0 0 ${w} ${h}`}" width="${w}" height="${h}">${inner}</svg>`;
const stars=(n,c)=>Array.from({length:n},(_,i)=>`<circle cx="${(i*173)%1010+7}" cy="${(i*97)%760}" r="${1+i%3}" fill="${c||'#fff'}" opacity="${.4+(i%3)*.2}"/>`).join('');
const glow=c=>{const m=new THREE.MeshBasicMaterial({color:c});W.disp.push(m);return m;};

/* ----------------- the 8 science pups ----------------- */
const S=[
 /* Dino Valley */
 {id:'brownie',name:'Barnum Brownie',who:'Barnum Brown',breed:'Treeing Walker Coonhound',island:'dino',area:'digcamp',spot:{x:30,z:-22,kind:'crate'},prop:'🦖',exp:'rexbuild',expName:'Build a T. rex',
  hint:'Look in a crate next to the T. rex dig.',
  fact:'Barnum Brownie is named after the real Barnum Brown, a fossil hunter from America. In 1902, in Montana, he found the first skeleton of a Tyrannosaurus rex that anyone had ever found! People called him Mr Bones.',
  home:'Build a dinosaur skeleton on dark paper with pasta shapes. Long pasta for the backbone and legs, curly pasta for the ribs, and a cracker for the skull!',
  rescue:{icon:'🦴',verb:'Brush',say:'Barnum Brownie is covered in dust from the dig! Tap to brush him clean!'},
  look:{fur:'#ffffff',ear:'#b5642a',ears:'long',patch:{c:'#26232e'},headC:'#c98a4a',muzzle:'#ffffff',belly:'#ffffff',tail:'thin',acc:['grad']},
  deco(x,z){const cx=x-4.5,cz=z+1,y=gy(cx,cz);I('box','#9b6a43',2,1.1,1.4,cx,y+.55,cz);I('box','#f2e6cc',1.4,.8,1.1,cx,y+1.5,cz);I('box','#f2e6cc',1.2,.25,1,cx,y+1.02,cz);
    for(let i=0;i<4;i++)I('cone','#ffffff',.08,.25,.08,cx-.45+i*.3,y+1.05,cz+.5,Math.PI,0,0);I('sph','#5a4030',.15,.15,.12,cx-.3,y+1.65,cz+.52);col(cx,cz,1.2);
    const fx=x+3.6,fz=z-1,fy=gy(fx,fz);I('cyl','#5b4636',.08,2.4,.08,fx,fy+1.2,fz);I('box','#5b4636',1.4,.08,.08,fx,fy+2.3,fz);I('cylL','#8a6a4a',.6,1.6,.45,fx,fy+1.5,fz);col(fx,fz,.6);
    sign(x-1,z+4.5,'🦖 Mr Bones\' dig',2.6,5.6);}},
 {id:'mantail',name:'Gideon Man-tail',who:'Gideon Mantell',breed:'Sussex Spaniel',island:'dino',area:'fernforest',spot:{x:-32,z:-28,kind:'fern'},prop:'🦷',exp:'teeth',expName:'Tooth Detective',
  hint:'Look in the ferns by the Fern Forest\'s far edge, near a table of fossil teeth.',
  fact:'Gideon Man-tail is named after the real Gideon Mantell, a doctor from Sussex in England. He and his wife Mary Ann collected big fossil teeth that looked like giant iguana teeth. In 1825 he named the animal Iguanodon, which means iguana tooth. It was one of the very first dinosaurs to get a name!',
  home:'Look at your teeth in a mirror. Find the pointy ones at the front for biting, and the flat, bumpy ones at the back for chewing. People have both, because we eat plants and meat!',
  rescue:{icon:'🦷',verb:'Lift',say:'Gideon Man-tail is stuck under a pile of fossil teeth! Tap to lift them off!'},
  look:{fur:'#8a4a2a',ears:'floppy',fluffy:true,muzzle:'#8a4a2a',belly:'#9a5a3a',tail:'stub',bw:46,bh:34,acc:['grad']},
  deco(x,z){const tx=x+4,tz=z+2,y=gy(tx,tz);I('box','#9b6a43',2.4,.2,1.4,tx,y+1.1,tz);[[-1,-.5],[1,-.5],[-1,.5],[1,.5]].forEach(q=>I('box','#5b4636',.12,1.1,.12,tx+q[0],y+.55,tz+q[1]));
    for(let i=0;i<3;i++)I('cone','#e8dcc0',.16,.5,.12,tx-.6+i*.6,y+1.45,tz,0,0,.2);spr('🔍',.8,tx+.9,y+1.7,tz);spr('🦎',1,tx-1.6,y+.5,tz+1);col(tx,tz,1.3);
    sign(x+1,z+4.5,'🦷 Mantell\'s teeth',2.6,5.6);}},
 {id:'tray',name:'Tray',who:'Mary Anning',breed:'Mixed breed',island:'dino',area:'cliffs',spot:{x:12,z:28,kind:'boulder'},prop:'🔨',exp:'ichthy',expName:'Fossil Dig',
  hint:'Look behind a boulder on the beach, next to a fossil basket.',
  fact:'Tray was Mary Anning\'s real dog! Mary lived in Lyme Regis in England over 200 years ago. When she was 12, her brother Joseph found a strange skull, and Mary dug out the rest of the skeleton. It was an ichthyosaur, a sea reptile from the time of the dinosaurs! Tray trotted along beside her on her fossil hunts.',
  home:'Make your own fossil! Press a shell or a toy dinosaur into play dough, lift it out carefully, and look at the print it leaves. Real fossils form in rock over millions of years.',
  rescue:{icon:'🌊',verb:'Catch',say:'Tray is chasing the waves along the beach! Tap to catch up with Tray!'},
  look:{fur:'#ffffff',ear:'#26232e',ears:'fold',patch:{c:'#26232e'},muzzle:'#ffffff',belly:'#ffffff',tail:'thin',scale:.85,acc:['grad']},
  deco(x,z){const bx=x-4,bz=z-1,y=gy(bx,bz);I('cyl','#c9905f',.7,.7,.55,bx,y+.35,bz);I('tor','#9b6a43',.6,.6,.6,bx,y+.95,bz,0,0,Math.PI/2);for(let i=0;i<3;i++)I('tor','#c9b48a',.25,.25,.3,bx-.2+i*.2,y+.75,bz,Math.PI/2,0,0);
    I('cyl','#9b6a43',.06,.8,.06,bx+1,y+.1,bz+.4,0,0,Math.PI/2);I('box','#5b6378',.25,.2,.4,bx+1.4,y+.12,bz+.4);col(bx,bz,.9);
    sign(x+1.5,z-4.5,'🐚 Mary Anning\'s beach',2.6,6);}},
 {id:'chappup',name:'Roy Chap-pup Andrews',who:'Roy Chapman Andrews',breed:'Mongolian Bankhar',island:'dino',area:'nest',spot:{x:30,z:4,kind:'tent'},prop:'🥚',exp:'eggs',expName:'Egg Count',
  hint:'Look in an explorer\'s tent on the plateau.',
  fact:'Roy Chap-pup Andrews is named after the real Roy Chapman Andrews, an explorer from America. In 1923, his team found nests of dinosaur eggs at the Flaming Cliffs in the Gobi Desert, in Mongolia. They were the first dinosaur eggs that scientists knew were dinosaur eggs!',
  home:'Hide some plastic eggs or small toys in a tray of sand or rice, then dig them out gently with a spoon and a paintbrush, like a real fossil hunter!',
  rescue:{icon:'🥚',verb:'Lift',say:'Roy Chap-pup Andrews is guarding a nest of eggs and will not move! Tap to help him lift the eggs to safety!'},
  look:{fur:'#26232e',brows:'#c98a4a',muzzle:'#c98a4a',paw:'#c98a4a',belly:'#3a3640',ears:'floppy',fluffy:true,tail:'plume',scale:1.1,acc:['grad']},
  deco(x,z){const cx=x-5,cz=z+1,y=gy(cx,cz),c='#5a6a3a';I('box',c,2,1,3.4,cx,y+1,cz);I('box',c,1.8,.8,1.4,cx,y+1.9,cz+.5);I('box','#9bdcff',1.6,.6,.05,cx,y+1.95,cz+1.22);
    [[-1,-1.1],[1,-1.1],[-1,1.1],[1,1.1]].forEach(q=>I('cyl','#26232e',.45,.3,.45,cx+q[0]*1.05,y+.45,cz+q[1],0,0,Math.PI/2));col(cx,cz,1.9);
    const ex=x+4,ez=z-1,ey=gy(ex,ez);I('cyl','#c96a3a',1,.25,1,ex,ey+.12,ez);for(let i=0;i<6;i++){const a=i/6*6.28;I('sph','#e8dcc0',.22,.34,.22,ex+Math.cos(a)*.55,ey+.4,ez+Math.sin(a)*.55);}col(ex,ez,1);
    sign(x,z+4.5,'🥚 Flaming Cliffs eggs',2.6,6);}},
 /* Planet Hop */
 {id:'strelka',name:'Strelka',who:'Belka and Strelka, the space dogs',breed:'Mixed breed',island:'planet',area:'moon',spot:{x:26,z:-4,kind:'satellite'},prop:'🛰️',exp:'spacedogs',expName:'Space Dog Mission',
  hint:'Look behind a satellite dish at Moon Base, next to a little space capsule.',
  fact:'Strelka is named after a real space dog! On 19 August 1960, Belka and Strelka flew round the Earth 17 times in a spaceship, then landed safely the next day. Later, Strelka had puppies, and one of them, Pushinka, was given to the family of the American president.',
  home:'On a clear night, look up at the sky with a grown-up. Satellites look like stars that glide slowly and steadily across the sky, without twinkling. Can you spot one?',
  rescue:{icon:'🛰️',verb:'Untangle',say:'Strelka is tangled in her capsule\'s parachute! Tap to untangle her!'},
  look:{fur:'#ffffff',patch:{c:'#c98a4a',side:1},ear:'#c98a4a',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',tail:'curl',scale:.85,acc:['grad']},
  deco(x,z){const cx=x-4,cz=z+2,y=gy(cx,cz);I('sph','#c9d2e3',1.3,1.3,1.3,cx,y+1.3,cz);I('cyl','#9bdcff',.4,.1,.4,cx,y+1.5,cz+1.25,Math.PI/2,0,0);for(let i=0;i<4;i++){const a=i*1.57;I('cyl','#8a8f99',.05,1.4,.05,cx+Math.cos(a)*1.4,y+2.4,cz+Math.sin(a)*1.4,Math.sin(a)*.6,0,-Math.cos(a)*.6);}
    I('cone','#ff6b6b',1.4,.5,1.4,cx,y+3.4,cz);col(cx,cz,1.4);sign(x+2,z+4.5,'🛰️ Space dog capsule',2.6,6);}},
 {id:'johnspup',name:'Katherine Johnspup',who:'Katherine Johnson',breed:'American Foxhound',island:'planet',area:'mars',spot:{x:20,z:10,kind:'pod'},prop:'🧮',exp:'path',expName:'Rocket Path',
  hint:'Look in an escape pod by the Mars landing pad.',
  fact:'Katherine Johnspup is named after the real Katherine Johnson, a brilliant mathematician at NASA in America. In 1962, the astronaut John Glenn asked her to check the computer\'s numbers before his flight round the Earth. She also worked out the path for Apollo 11, the first trip to land people on the Moon!',
  home:'Draw a grid of squares, put a toy rocket on one square, and give a grown-up directions like 3 squares right and 2 squares up. Do they land on the right square?',
  rescue:{icon:'🧮',verb:'Tidy',say:'Katherine Johnspup is buried in a pile of sums! Tap to tidy the papers!'},
  look:{fur:'#ffffff',ear:'#c98a4a',ears:'long',patch:{c:'#26232e'},headC:'#c98a4a',muzzle:'#ffffff',belly:'#ffffff',tail:'thin',acc:['grad']},
  deco(x,z){const bx=x+4,bz=z-1,y=gy(bx,bz);I('box','#2f4f3a',2.6,1.8,.12,bx,y+1.6,bz,0,-.4,0);I('box','#9b6a43',2.8,.12,.2,bx,y+.7,bz,0,-.4,0);[-1.1,1.1].forEach(s=>I('cyl','#5b4636',.07,1.6,.07,bx+s*Math.cos(.4),y+.8,bz+s*Math.sin(.4)));
    spr('🧮',.9,bx,y+1.7,bz+.2);col(bx,bz,1.2);sign(x-2,z+4.5,'🧮 Mission maths',2.6,5.6);}},
 {id:'copupnicus',name:'Nicolaus Copupnicus',who:'Nicolaus Copernicus',breed:'Polish Hound',island:'planet',area:'station',spot:{x:-26,z:6,kind:'satellite'},prop:'☀️',exp:'order',expName:'Planet Parade',
  hint:'Look behind a satellite dish at the Solar Station, by the model of the planets.',
  fact:'Nicolaus Copupnicus is named after the real Nicolaus Copernicus, an astronomer from Poland. Long ago, most people thought the Sun went round the Earth. In 1543, his book showed a new idea: the Earth and the other planets go round the Sun!',
  home:'With a grown-up, switch on a lamp to be the Sun. Walk slowly round it while you spin. That is how the Earth moves: it spins round once a day, and goes round the Sun once a year.',
  rescue:{icon:'🪐',verb:'Stop',say:'Nicolaus Copupnicus is spinning round with the planet model! Tap to stop it!'},
  look:{fur:'#26232e',muzzle:'#b5642a',belly:'#b5642a',brows:'#b5642a',paw:'#b5642a',ears:'floppy',tail:'thin',acc:['grad']},
  deco(x,z){const ox=x+4.5,oz=z+1,y=gy(ox,oz);I('cyl','#9b6a43',.25,1.4,.25,ox,y+.7,oz);const g=grp();mk('sph','#ffd23f',.5,.5,.5,0,0,0,g,true);
    const arms=[];[['#a8a8b0',.9,.12],['#3d8fe0',1.4,.18],['#c4643a',1.9,.15],['#d8a070',2.5,.3]].forEach((q,i)=>{const a=grp();g.add(a);mk('box','#c9a040',q[1],.03,.03,q[1]/2,0,0,a);mk('sph',q[0],q[2],q[2],q[2],q[1],0,0,a);arms.push(a);});
    add(g,ox,oz,y+1.6);W.ticks.push(dt=>{arms.forEach((a,i)=>{a.rotation.y+=dt*(1.2-i*.25);});});col(ox,oz,1);sign(x-1,z+4.5,'☀️ Copernicus\' model',2.6,6);}},
 {id:'pawking',name:'Stephen Pawking',who:'Stephen Hawking',breed:'Field Spaniel',island:'planet',area:'blackhole',spot:{x:16,z:-30,kind:'crystal'},prop:'🌀',exp:'gravity',expName:'Gravity Sheet',
  hint:'Look by the glowing crystals near the Black Hole, next to a telescope.',
  fact:'Stephen Pawking is named after the real Stephen Hawking, a scientist from England who studied black holes. In 1974 he showed that black holes are not completely black: they glow very, very faintly. He wrote a famous book called A Brief History of Time, and he talked using a computer voice.',
  home:'With a grown-up, hold a towel or a sheet stretched tight, and put a heavy ball in the middle. Now roll a marble near it. Does it curve round and fall in? That is a bit like how a black hole pulls things!',
  rescue:{icon:'🌀',verb:'Hold',say:'Stephen Pawking is floating towards the swirl! Tap to hold on to him!'},
  look:{fur:'#3a2a26',ears:'floppy',fluffy:true,muzzle:'#3a2a26',belly:'#4a3a36',tail:'stub',acc:['grad']},
  deco(x,z){const tx=x-4,tz=z+1,y=gy(tx,tz);[0,2.09,4.19].forEach(a=>I('cyl','#5b4636',.06,1.8,.06,tx+Math.sin(a)*.5,y+.8,tz+Math.cos(a)*.5,Math.cos(a)*.25,0,-Math.sin(a)*.25));
    I('cyl','#f4f6fb',.25,2.2,.25,tx,y+2,tz,.8,0,0);I('cyl','#26232e',.27,.15,.27,tx,y+2.75,tz+.75,.8,0,0);col(tx,tz,.8);sign(x+1,z+4.5,'🌀 Black hole study',2.6,5.6);}}];
regSci(S);

/* ----------------- experiments ----------------- */
/* Barnum Brownie: build a T. rex skeleton in the museum */
XP.rexbuild=(st,p)=>{const bone='#f2e6cc';
  $('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#f4ead8"/>${[0,1,2,3,4].map(i=>`<rect x="${i*220+30}" y="40" width="160" height="220" rx="80" fill="#e8dcc4"/>`).join('')}<rect y="610" width="1024" height="158" fill="#c9a06a"/><rect x="150" y="590" width="720" height="40" rx="8" fill="#9b6a43" stroke="${k}" stroke-width="4"/></svg>`;
  const P=[{k:'legs',l:'Legs',e:'🦵',d:'M465 330 L435 450 L478 548 L445 592 M528 325 L512 450 L548 548 L520 592',w:16},
    {k:'back',l:'Backbone',e:'〰️',d:'M300 335 Q470 300 640 300',w:18},
    {k:'tail',l:'Tail',e:'🦎',d:'M300 335 Q200 360 105 450',w:14},
    {k:'ribs',l:'Ribs',e:'🦴',d:[0,1,2,3,4,5].map(i=>`M${415+i*34} ${318-i*3} q -14 52 8 86`).join(' '),w:9},
    {k:'arms',l:'Tiny arms',e:'💪',d:'M640 345 L668 382 L690 378',w:8},
    {k:'skull',l:'Skull',e:'🦷',d:'M630 262 Q640 218 715 222 L792 250 Q806 292 772 306 L700 312 L640 302 Z',w:10,fill:1}];
  const ov=place(el('div','',''),0,0,1024,768);ov.style.pointerEvents='none';st.appendChild(ov);const done={};
  const draw=hl=>{let s='';P.forEach(q=>{if(done[q.k]){s+=`<path d="${q.d}" fill="${q.fill?k:'none'}" stroke="${k}" stroke-width="${q.w+7}" stroke-linecap="round" stroke-linejoin="round"/><path d="${q.d}" fill="${q.fill?bone:'none'}" stroke="${bone}" stroke-width="${q.w}" stroke-linecap="round" stroke-linejoin="round"/>`;
      if(q.k==='skull')s+=`<circle cx="690" cy="252" r="12" fill="${k}"/><path d="M660 304 l8 14 l8 -14 l8 14 l8 -14 l8 14 l8 -14 l8 14 l8 -14" fill="none" stroke="#ffffff" stroke-width="4"/>`;}
    else s+=`<path d="${q.d}" fill="none" stroke="${hl===q.k?'#ffb030':'#b9c4d0'}" stroke-width="${hl===q.k?q.w+4:q.w}" stroke-dasharray="10 12" stroke-linecap="round"/>`;});ov.innerHTML=svgEl(1024,768,s);};
  let i=0;const next=()=>{if(i>=P.length){draw();say('A whole T. rex! Barnum Brown\'s team dug the first T. rex bones out of the rock in Montana in 1902, and took them to a museum in New York.');setTimeout(()=>sciDone(p),7600);return;}
    const q=P[i];draw(q.k);const others=shuffle(P.filter(o=>o.k!==q.k)).slice(0,2);
    say(i?'Which bone goes in the glowing space next?':'Let us build a T. rex skeleton for the museum! Which bone goes in the glowing space?');
    choiceRow(st,shuffle([[q.k,`${q.e}<small>${q.l}</small>`]].concat(others.map(o=>[o.k,`${o.e}<small>${o.l}</small>`,`Not the ${o.l.toLowerCase()}! Look at the shape of the glowing space.`]))),q.k,()=>{done[q.k]=1;draw();sfx.pop();say(`Yes! The ${q.l.toLowerCase()}.`);i++;setTimeout(next,1500);},640);};
  next();};

/* Gideon Man-tail: plant-eater or meat-eater? */
XP.teeth=(st,p)=>sortExp(st,{bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e8f0c8"/><rect y="520" width="1024" height="248" fill="#8fd170"/>${[0,1,2,3,4,5].map(i=>`<path d="M${i*190+40} 520 q 30 -160 70 -10 q 20 -120 60 0" fill="#4f9e3a"/>`).join('')}</svg>`,n:8,
  bins:[{k:'plant',icon:'🌿',label:'Plant-eater'},{k:'meat',icon:'🍖',label:'Meat-eater'}],
  intro:'Tooth detective! Sharp, pointy teeth are for meat. Flat, bumpy teeth are for chewing plants. Is each animal a plant-eater or a meat-eater?',ask:it=>`The ${it.n}. Plant-eater or meat-eater?`,
  end:'Brilliant detective work! Gideon Mantell looked at flat, bumpy fossil teeth and worked out they came from a giant plant-eater. He called it Iguanodon.',
  items:[{e:'🦖',n:'T. rex',k:'meat',why:'T. rex had huge, sharp teeth for eating meat.',hint:'Think of those big pointy teeth!'},{e:'🦕',n:'long-neck',k:'plant',why:'Long-necks stretched up to munch leaves from tall trees.',hint:'What grows up in the tall trees?'},
    {e:'🦁',n:'lion',k:'meat',why:'Lions have sharp teeth for meat.',hint:'Lions hunt for their food.'},{e:'🐄',n:'cow',k:'plant',why:'Cows have flat teeth for chewing grass.',hint:'What do cows munch in the field?'},
    {e:'🦈',n:'shark',k:'meat',why:'Sharks have rows of sharp teeth for catching fish.',hint:'Sharks catch fish.'},{e:'🐰',n:'rabbit',k:'plant',why:'Rabbits nibble grass and carrots.',hint:'What do rabbits nibble?'},
    {e:'🐊',n:'crocodile',k:'meat',why:'Crocodiles have pointy teeth for catching fish and meat.',hint:'Snap, snap!'},{e:'🦒',n:'giraffe',k:'plant',why:'Giraffes eat leaves from the tops of trees.',hint:'Giraffes reach up high to eat.'},
    {e:'🐺',n:'wolf',k:'meat',why:'Wolves have sharp teeth for meat.',hint:'Wolves hunt together.'},{e:'🐘',n:'elephant',k:'plant',why:'Elephants eat grass, leaves and fruit.',hint:'Elephants pick plants with their trunks.'},
    {e:'🦷',n:'Iguanodon',k:'plant',why:'Iguanodon had flat, bumpy teeth for chewing plants, like a giant iguana.',hint:'Its teeth were flat and bumpy.'}]},p);

/* Tray: chip away the rock to find Mary Anning's ichthyosaur */
const ichthySVG=()=>{const b='#f2e6cc';let s=`<g stroke="${k}" stroke-width="4" stroke-linejoin="round"><path d="M250 400 Q330 300 520 320 Q700 330 790 390 Q700 450 520 460 Q330 470 250 400 Z" fill="${b}"/>
  <path d="M250 400 L120 385 L250 412 Z" fill="${b}"/><path d="M790 390 L880 300 L860 395 L885 480 Z" fill="${b}"/><path d="M430 450 L390 520 L470 465 Z" fill="${b}"/><path d="M620 450 L600 510 L660 455 Z" fill="${b}"/><path d="M560 322 L580 270 L620 326 Z" fill="${b}"/></g>
  <circle cx="300" cy="385" r="26" fill="none" stroke="${k}" stroke-width="5"/><circle cx="300" cy="385" r="9" fill="${k}"/>`;
  for(let i=0;i<10;i++)s+=`<path d="M${380+i*36} 340 q -8 50 4 100" stroke="#c9b48a" stroke-width="6" fill="none"/>`;return s;};
XP.ichthy=(st,p)=>{const T=[];for(let r=0;r<3;r++)for(let c=0;c<6;c++)T.push({e:'🪨',x:150+c*120+(r%2)*40,y:240+r*95,s:125,ok:true});
  tapExp(st,{bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#bfe0f4"/><rect y="170" width="1024" height="598" fill="#8a96a4"/>${[0,1,2,3,4].map(i=>`<rect y="${200+i*110}" width="1024" height="18" fill="#d8ccb0" opacity=".7"/>`).join('')}${ichthySVG()}</svg>`,
    intro:'Mary Anning has found something in the cliff! Tap the rocks to chip them away gently, and see what is hiding inside.',end:'An ichthyosaur! It was a sea reptile that swam at the time of the dinosaurs, with big eyes and flippers. Mary Anning dug one out of the cliffs when she was only 12!',
    targets:T,onHit:b=>{b.style.transition='all .4s';b.style.opacity='0';b.style.transform='scale(.3) rotate(40deg)';sfx.boop();}},p);};

/* Roy Chap-pup Andrews: count the eggs in each nest */
XP.eggs=(st,p)=>{const ov=place(el('div','',''),0,0,1024,768);ov.style.pointerEvents='none';st.appendChild(ov);
  $('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#ffd8a8"/><path d="M0 300 L120 200 L260 240 L380 150 L560 230 L700 170 L860 240 L1024 190 L1024 768 L0 768Z" fill="#d8703a"/><path d="M0 330 L1024 300 L1024 768 L0 768Z" fill="#e8a060"/><circle cx="880" cy="90" r="50" fill="#fff2b0"/></svg>`;
  const R=[[2,3],[3,4],[4,5]];let r=0;
  const draw=(a,b)=>{const w=b*70+60,h=a*70+50,x0=512-w/2,y0=380-h/2;let s=`<ellipse cx="512" cy="380" rx="${w/2+40}" ry="${h/2+30}" fill="#9b6a43" stroke="${k}" stroke-width="5"/><ellipse cx="512" cy="380" rx="${w/2+10}" ry="${h/2+6}" fill="#c9905f"/>`;
    for(let i=0;i<a;i++)for(let j=0;j<b;j++){const x=x0+60+j*70,y=y0+50+i*70;s+=`<ellipse cx="${x}" cy="${y}" rx="24" ry="32" fill="#f2e6cc" stroke="${k}" stroke-width="4"/><circle cx="${x+7}" cy="${y-10}" r="4" fill="#c9a06a"/>`;}ov.innerHTML=svgEl(1024,768,s);};
  const ask=()=>{if(r>=R.length){say('Super counting! In 1923, Roy Chapman Andrews\' team found nests of dinosaur eggs at the Flaming Cliffs in Mongolia. Before that, nobody knew for sure that dinosaurs laid eggs!');setTimeout(()=>sciDone(p),7600);return;}
    const [a,b]=R[r],n=a*b;draw(a,b);say(`${r?'Another nest! ':'The explorers have found a dinosaur nest! '}There are ${a} rows of ${b} eggs. How many eggs altogether?`);
    choiceRow(st,shuffle([n,n+a,n-b]).map(v=>[v,`🥚 ${v}`,v>n?'Too many! Count the eggs in each row again.':'Not enough! Count every row.']),n,()=>{say(`Yes! ${a} rows of ${b} eggs make ${n} eggs.`);r++;setTimeout(ask,2800);},640);};
  ask();};

/* Strelka: pack the space capsule */
XP.spacedogs=(st,p)=>sortExp(st,{bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#0b1030"/>${stars(70)}<circle cx="860" cy="140" r="90" fill="#3d8fe0"/><path d="M800 110 q40 -30 70 0 q20 40 -30 60 Z" fill="#3fae5a"/></svg>`,n:8,
  bins:[{k:'yes',icon:'🛰️',label:'Take it'},{k:'no',icon:'🏠',label:'Leave it'}],
  intro:'Belka and Strelka are going to fly round the Earth! What do they need in their space capsule? Take it, or leave it at home?',ask:it=>`The ${it.n}. Take it into space, or leave it at home?`,
  end:'Mission ready! Belka and Strelka flew round the Earth 17 times. Then their capsule came back down, and they landed safely the next day. Hooray for the space dogs!',
  items:[{e:'💨',n:'air to breathe',k:'yes',why:'There is no air in space, so the capsule carries air to breathe.',hint:'Can dogs breathe without air?'},{e:'🍖',n:'special space food',k:'yes',why:'Space dogs need food, even in orbit.',hint:'Do they get hungry?'},
    {e:'💧',n:'water',k:'yes',why:'Space dogs need water to drink.',hint:'Do they get thirsty?'},{e:'📺',n:'TV camera',k:'yes',why:'A TV camera let the scientists watch the dogs from Earth.',hint:'How could scientists see them?'},
    {e:'🪂',n:'parachute',k:'yes',why:'A parachute helps the capsule land gently.',hint:'How do they land softly?'},{e:'🌡️',n:'cosy warm capsule',k:'yes',why:'The capsule keeps the dogs at a comfy temperature.',hint:'Space is very cold!'},
    {e:'⚽',n:'football',k:'no',why:'No room for football in a tiny capsule!',hint:'Is there room to play?'},{e:'☂️',n:'umbrella',k:'no',why:'It never rains in space!',hint:'Does it rain in space?'},
    {e:'🚲',n:'bicycle',k:'no',why:'A bicycle is far too big, and there are no roads in space!',hint:'Would that fit?'},{e:'🪣',n:'bucket and spade',k:'no',why:'There is no beach in space!',hint:'Is there sand up there?'}]},p);

/* Katherine Johnspup: plot the rocket's path on a grid */
XP.path=(st,p)=>{const S2=70,X0=170,Y0=560;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#0b1030"/>${stars(50)}`;
  for(let i=0;i<=8;i++)s+=`<line x1="${X0+i*S2}" y1="${Y0}" x2="${X0+i*S2}" y2="${Y0-6*S2}" stroke="#3a4a7a" stroke-width="3"/><text x="${X0+i*S2}" y="${Y0+34}" font-size="24" fill="#9bdcff" text-anchor="middle">${i}</text>`;
  for(let j=0;j<=6;j++)s+=`<line x1="${X0}" y1="${Y0-j*S2}" x2="${X0+8*S2}" y2="${Y0-j*S2}" stroke="#3a4a7a" stroke-width="3"/><text x="${X0-28}" y="${Y0-j*S2+8}" font-size="24" fill="#9bdcff" text-anchor="middle">${j}</text>`;
  $('#sciBg').innerHTML=s+'</svg>';
  const tg=place(el('div','xobj',''),0,0,70,70);tg.style.fontSize='54px';st.appendChild(tg);const rk=place(el('div','xobj','🚀'),X0-30,Y0-30,60,60);rk.style.fontSize='46px';rk.style.transition='left 1s linear,top 1s linear';st.appendChild(rk);
  const R=[{tx:4,ty:0,e:'🔴',q:'Mars is straight along the bottom. How many squares right does the rocket go?',opts:[[4,'➡️ 4'],[3,'➡️ 3','Count the squares again, one by one.'],[5,'➡️ 5','Count the squares again, one by one.']],ans:4},
    {tx:3,ty:2,e:'🌙',q:'The Moon is 3 squares right. How many squares up?',opts:[[2,'⬆️ 2'],[3,'⬆️ 3','Count up from the bottom line.'],[1,'⬆️ 1','Count up from the bottom line.']],ans:2},
    {tx:6,ty:4,e:'🪐',q:'Saturn! How many squares right, and how many up?',opts:[['64','6 right, 4 up'],['46','4 right, 6 up','Go right first, along the bottom.'],['63','6 right, 3 up','Count the squares going up again.']],ans:'64'}];
  let r=0;const go=()=>{if(r>=R.length){say('Perfect paths! Katherine Johnson worked out flight paths with maths, and John Glenn trusted her. He said: if she says the numbers are good, I am ready to go.');setTimeout(()=>sciDone(p),7600);return;}
    const o=R[r];rk.style.transition='none';rk.style.left=(X0-30)+'px';rk.style.top=(Y0-30)+'px';tg.style.left=(X0+o.tx*S2-35)+'px';tg.style.top=(Y0-o.ty*S2-38)+'px';tg.textContent=o.e;say(o.q);
    choiceRow(st,o.opts,o.ans,()=>{rk.style.transition='left 1s linear,top 1s linear';rk.style.left=(X0+o.tx*S2-30)+'px';setTimeout(()=>{rk.style.top=(Y0-o.ty*S2-30)+'px';},1050);sfx.boop();
      setTimeout(()=>{sfx.chime();say('Landed right on target! Great maths!');r++;setTimeout(go,2000);},2300);},640);};
  go();};

/* Nicolaus Copupnicus: put the planets in order from the Sun */
const PLN=[['Mercury','#a8a8b0',24,'Mercury is the smallest planet, and the closest to the Sun.'],['Venus','#e8c890',32,'Venus is the hottest planet.'],['Earth','#3d8fe0',34,'Earth, our home!'],['Mars','#c4643a',28,'Mars, the red planet.'],
  ['Jupiter','#d8a070',58,'Jupiter, the biggest planet!'],['Saturn','#e8d090',52,'Saturn, with its beautiful rings.'],['Uranus','#9be8f0',42,'Uranus spins on its side!'],['Neptune','#3d5fe0',42,'Neptune, the windiest planet, far, far away.']];
XP.order=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#0b1030"/>${stars(60)}<circle cx="-60" cy="260" r="200" fill="#ffd23f"/><circle cx="-60" cy="260" r="240" fill="#ffb347" opacity=".25"/><line x1="140" y1="260" x2="1010" y2="260" stroke="#3a4a7a" stroke-width="4" stroke-dasharray="8 10"/></svg>`;
  const ov=place(el('div','',''),0,0,1024,768);ov.style.pointerEvents='none';st.appendChild(ov);let n=0;
  const dot=(q,d)=>`<span style="display:inline-block;width:${d}px;height:${d}px;border-radius:50%;background:${q[1]};border:3px solid ${k};vertical-align:middle"></span>`;
  const drawRow=()=>{let s='';for(let i=0;i<n;i++){const q=PLN[i],x=180+i*104;s+=`<circle cx="${x}" cy="260" r="${q[2]}" fill="${q[1]}" stroke="${k}" stroke-width="4"/>${q[0]==='Saturn'?`<ellipse cx="${x}" cy="260" rx="${q[2]+22}" ry="10" fill="none" stroke="#c9a040" stroke-width="5"/>`:''}<text x="${x}" y="${330+(i%2)*28}" font-size="22" fill="#ffffff" text-anchor="middle">${q[0]}</text>`;}ov.innerHTML=svgEl(1024,768,s);};
  const order=shuffle(PLN.slice()),rows=[place(el('div','xrow',''),0,470,1024),place(el('div','xrow',''),0,610,1024)];rows.forEach(rw=>st.appendChild(rw));
  order.forEach((q,i)=>{const b=bigBtn(`${dot(q,Math.min(40,q[2]))}<small>${q[0]}</small>`,'white',()=>{if(b.disabled)return;if(q[0]===PLN[n][0]){b.disabled=true;b.style.opacity='.35';n++;drawRow();sfx.chime();
      if(n>=PLN.length){say('All eight planets in order round the Sun! Copernicus put the Sun in the middle, and he was right.');setTimeout(()=>sciDone(p),6000);}else say(`${q[3]} Which planet comes next?`);}
    else{sfx.oops();anim(b,'t-shake',500);say(`Not yet! Which planet is the next closest to the Sun, after ${n?PLN[n-1][0]:'the Sun itself'}?`);}});rows[i<4?0:1].appendChild(b);});
  drawRow();say('Copernicus said the planets go round the Sun. Put them in order, starting with the planet closest to the Sun!');};

/* Stephen Pawking: a stretchy space sheet shows how gravity pulls */
XP.gravity=(st,p)=>{let dip=0;const sheet=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#120a24"/>${stars(50,'#e0c8ff')}<defs><radialGradient id="gw"><stop offset="0" stop-color="#000" stop-opacity="${Math.min(.9,dip/140)}"/><stop offset="1" stop-color="#000" stop-opacity="0"/></radialGradient></defs>`;
    for(let i=0;i<=10;i++){const y=230+i*32,f=Math.max(0,1-Math.abs(y-390)/190);s+=`<path d="M90 ${y} C 330 ${y} 380 ${y+dip*f*1.6} 512 ${y+dip*f*1.6} C 644 ${y+dip*f*1.6} 694 ${y} 934 ${y}" stroke="#9a7aff" stroke-width="3" fill="none"/>`;}
    for(let j=0;j<=12;j++){const x=90+j*70.33,f=Math.max(0,1-Math.abs(x-512)/430);s+=`<path d="M${x} 230 Q${512+(x-512)*(1-f*dip/300)} ${390+dip*f*1.4} ${x} 550" stroke="#7a5ad6" stroke-width="2.5" fill="none"/>`;}
    return s+`<ellipse cx="512" cy="${390+dip*.7}" rx="${60+dip*1.6}" ry="${30+dip*.6}" fill="url(#gw)"/></svg>`;};
  const ball=place(el('div','xobj',''),482,330,70,70);ball.style.fontSize='60px';ball.style.transition='top .8s ease-in';st.appendChild(ball);
  const sag=(to,cb)=>{const t0=performance.now(),d0=dip;const step=()=>{const u=Math.min(1,(performance.now()-t0)/900);dip=d0+(to-d0)*u;$('#sciBg').innerHTML=sheet();if(u<1)requestAnimationFrame(step);else if(cb)cb();};step();};
  $('#sciBg').innerHTML=sheet();say('Stephen Hawking studied black holes. Their gravity pulls very, very hard. Let us make a stretchy space sheet! Which ball will make the deepest dip?');
  choiceRow(st,[['bowl','🎳<small>Bowling ball</small>'],['ping','🏓<small>Ping-pong ball</small>','That is very light. It hardly makes a dip! Which is the heaviest?'],['apple','🍎<small>Apple</small>','An apple makes a little dip. Which is the heaviest?']],'bowl',()=>{
    ball.textContent='🎳';ball.style.top='400px';sag(110,()=>{say('A big, deep dip! Now roll a marble across the sheet. Watch what happens!');
      const row=place(el('div','xrow',''),0,640,1024);row.appendChild(bigBtn('🔵<small>Roll a marble</small>','white',b=>{row.remove();const m=place(el('div','xobj','🔵'),900,300,40,40);m.style.fontSize='34px';st.appendChild(m);const t0=performance.now();
        const roll=()=>{const u=Math.min(1,(performance.now()-t0)/3200),a=u*10,r=380*(1-u);m.style.left=(512-20+Math.cos(a)*r)+'px';m.style.top=(410-20+Math.sin(a)*r*.42+u*40)+'px';m.style.transform=`scale(${1-u*.6})`;
          if(u<1)requestAnimationFrame(roll);else{m.remove();sfx.pop();say('Round and round, and in it goes! A black hole pulls even harder than that. Can anything escape from the very middle of a black hole?');
            choiceRow(st,[['none','🚫<small>Nothing, not even light</small>'],['light','💡<small>Light can</small>','Even light cannot get out of the very middle! That is why it looks black.'],['all','🚀<small>Everything can</small>','Even light cannot get out of the very middle!']],'none',()=>{
              say('Right! Not even light. But Stephen Hawking showed that black holes glow very, very faintly, so they are not completely black after all!');setTimeout(()=>sciDone(p),7000);},640);}};roll();}));st.appendChild(row);});},640);};

/* ----------------- card shapes for the new breeds (leg length, snout length) ----------------- */
[['Borzoi',1.35,1.6],['Silken Windhound',1.3,1.4],['Azawakh',1.45,1.4],['Pharaoh Hound',1.25,1.35],['Xoloitzcuintli',1.15,1.2],['Cirneco dell\'Etna',1.15,1.25],['Rhodesian Ridgeback',1.15,1.2],
 ['Neapolitan Mastiff',.95,.7],['Dogue de Bordeaux',.95,.6],['Clumber Spaniel',.75,1],['Miniature Pinscher',1,1.1],['Bolognese',.88,.8],['Löwchen',.9,.8],['Biewer Terrier',.85,.85],
 ['Komondor',1,.9],['Bergamasco',1,.95],['Plott Hound',1.1,1.2],['Bluetick Coonhound',1.1,1.25],['Redbone Coonhound',1.1,1.25],['Treeing Walker Coonhound',1.1,1.25],['American Foxhound',1.15,1.25],
 ['Polish Hound',1.1,1.25],['Sussex Spaniel',.75,1.05],['Field Spaniel',.85,1.1],['Mongolian Bankhar',1.05,.95],['Canaan Dog',1.05,1.1],['Norwegian Lundehund',.95,1],['Mudi',1,1.1],['Pumi',1,1.15],
 ['Schipperke',.85,1],['Australian Kelpie',1.05,1.15],['Catahoula Leopard Dog',1.1,1.15]].forEach(q=>{if(!BREED_SHAPE[q[0]])BREED_SHAPE[q[0]]=[q[1],q[2]];});

/* ----------------- badges and certificates ----------------- */
const S8=()=>S.filter(q=>isFound(q.id)).length;
MERITS.push(
  {id:'dino',icon:'🦕',name:'Dino Hero',how:'Find all 12 pups in Dino Valley.',ok:()=>!!state.islDone.dino},
  {id:'planet',icon:'🪐',name:'Planet Hero',how:'Find all 12 pups on Planet Hop.',ok:()=>!!state.islDone.planet},
  {id:'explorerkit',icon:'🥾',name:'Explorer Kit',how:'Find the riding saddle and the moon boots.',ok:()=>!!(state.gear.saddle&&state.gear.moonboots)},
  {id:'stonepower',icon:'🪨',name:'Stone Power',how:'Use a Stone pup to dig through the rocks.',ok:()=>!!(state.vines.ridge_rocks||state.vines.neb_rubble)},
  {id:'cometpower',icon:'☄️',name:'Comet Power',how:'Use a Comet pup to float a giant rock away.',ok:()=>!!(state.vines.rings_float||state.vines.amber_float)},
  {id:'rider',icon:'🚙',name:'Dino Rider, Space Driver',how:'Ride Boulder in Dino Dash and drive the rover in Rover Rally.',ok:()=>!!((state.acts||{}).dinodash&&(state.acts||{}).roverrally)},
  {id:'nugget',icon:'🟠',name:'Amber Find',how:'Find the sparkly pup in Amber Cave.',ok:()=>isFound('nugget')},
  {id:'stardust',icon:'🌸',name:'Stardust Find',how:'Find the sparkly pup in the Nebula Nursery.',ok:()=>isFound('stardust')},
  {id:'sci8',icon:'🔭',name:'Dinosaurs and Stars',how:'Find the 8 science pups in Dino Valley and on Planet Hop.',ok:()=>S8()>=8});
CERTS.push(
  {id:'dino',icon:'🦕',title:'Dino Valley Hero',why:'for finding all 12 pups in Dino Valley',ok:()=>!!state.islDone.dino},
  {id:'planet',icon:'🪐',title:'Planet Hop Hero',why:'for finding all 12 pups on Planet Hop',ok:()=>!!state.islDone.planet},
  {id:'spacequiz',icon:'🚀',title:'Space Expert',why:'for finishing the Space Quiz',ok:()=>!!(state.acts||{}).spacequiz},
  {id:'sci36',icon:'🌌',title:'Science Legend',why:'for finding 36 science pups',ok:()=>sciFound().length>=36});
})();
