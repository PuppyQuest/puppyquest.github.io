/* ================================================================
   Coral Reef: Region 2 (Water pups), reached by the submarine.
   Every area is underwater: Seb swims, and holds the Swim up button
   to float higher. Lagoon (start) opens two paths: the Kelp Forest
   (needs flippers) and the Coral Garden (after 2 pups). The Kelp
   Forest leads to the Shipwreck, the Coral Garden to the Deep
   Trench; strong currents that a Water pup calms stand in the way,
   and both lead on to the Pearl Palace (boss).
   Bonus: the Sunken Garden, past a hot vent that a Snow pup cools,
   with a shiny pup and treasure.
   ================================================================ */
(function(){
const R=seed(9191),CORALS=['#ff7f9e','#ffb347','#c78cff','#ff6b6b','#7fd3f0','#ffd23f'];
function reefEdge(Rad,gaps,n){for(let a=0;a<360;a+=8){if(gaps.some(g=>Math.abs(((a-g+540)%360)-180)<11))continue;const an=(a+R()*5)*D2R,r=Rad+3+R()*6,x=Math.cos(an)*r,z=Math.sin(an)*r;if(R()<.5)seaRock(x,z,1.2+R()*.8);else coral(x,z,1.2+R()*.6,pick(CORALS),pick(['branch','fan','brain']));}}
function seagrass(n,Rad,c){for(let i=0;i<n;i++){const a=R()*6.28,r=6+R()*(Rad-10),x=Math.cos(a)*r,z=Math.sin(a)*r,y=gy(x,z);for(let k=0;k<3;k++)I('box',c||'#5fae4a',.12,1+R()*1.2,.05,x+k*.25,y+.6,z,0,R()*3,(k-1)*.25);}}
function shells(n,Rad){for(let i=0;i<n;i++){const a=R()*6.28,r=5+R()*(Rad-8);shellAt(Math.cos(a)*r,Math.sin(a)*r,pick(['#ffd9e6','#fff4dc','#ffe0b8']));}}
function kelpField(n,Rad,keep){for(let i=0;i<n;i++){const a=R()*6.28,r=8+R()*(Rad-12),x=Math.cos(a)*r,z=Math.sin(a)*r;if(keep&&keep(x,z))continue;const y=gy(x,z),h=6+R()*8;for(let k=0;k<Math.round(h/1.4);k++)I('box',k%2?'#3f9e46':'#4fae4a',.5,1.5,.12,x+Math.sin(k*.8)*.3,y+.7+k*1.4,z,0,x,Math.sin(k)*.2);col(x,z,.5);}}
const WATER={ground:'#f0dca8',ground2:'#d9c48e',hedgeC:'#b9805f'};

/* ----- the 12 Water pups ----- */
const PUPS12=[
 {id:'ripple',name:'Ripple',breed:'Spanish Water Dog',area:'lagoon',pitch:1.1,spot:{x:14,z:20,kind:'sandcastle'},hint:'Look by the sandcastle in the Lagoon.',
  fact:'Spanish Water Dogs have woolly curls, and they help fishermen and farmers.',rescue:{icon:'🐚',verb:'Tickle',say:'Ripple is stuck in a giant clam! Tap to tickle the clam so it opens!'},
  look:{fur:'#8a5a3a',ears:'floppy',ear:'#7a4a2a',fluffy:true,wool:true,muzzle:'#a87050',belly:'#a87050',tail:'plume',acc:['shellneck','bubbles']}},
 {id:'sandy',name:'Sandy',breed:'Nova Scotia Duck Tolling Retriever',area:'lagoon',pitch:1.15,spot:{x:-28,z:10,kind:'boulder'},tag:{x:24,z:-24,kind:'rockpool'},hint:'Sandy plays tag. Look behind a big rock, then by a ring of stones.',
  fact:'Tollers are the smallest retrievers, and they love to splash about and play fetch!',rescue:{icon:'🌿',verb:'Untangle',say:'Sandy is tangled in seaweed! Tap to untangle her!'},
  look:{fur:'#d9783a',ear:'#c0652c',ears:'floppy',blaze:'#ffffff',muzzle:'#ffffff',belly:'#f3c49a',paw:'#ffffff',tail:'plume',tailTip:'#ffffff',acc:['shellneck']}},
 {id:'kelp',name:'Kelp',breed:'Lagotto Romagnolo',area:'kelp',pitch:1.05,spot:{x:-24,z:18,kind:'log'},hint:'Look by a sunken log in the Kelp Forest.',
  fact:'Lagotto Romagnolos are curly Italian dogs, famous for sniffing out treasure called truffles!',rescue:{icon:'🌿',verb:'Untangle',say:'Kelp is all wrapped up in kelp! Tap to untangle him!'},
  look:{fur:'#f3ead8',ears:'floppy',ear:'#9a6a44',patch:{c:'#9a6a44',side:-1},fluffy:true,wool:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',acc:['bubbles']}},
 {id:'finn',name:'Finn',breed:'Flat-coated Retriever',area:'kelp',pitch:1,spot:{x:26,z:-6,kind:'boulder'},tag:{x:-20,z:-30,kind:'log'},hint:'Finn plays tag. Look behind a rock, then by a log deep in the kelp.',
  fact:'Flat-coated Retrievers are always happy, and their tails never stop wagging!',rescue:{icon:'🦀',verb:'Ask',say:'A crab is pinching Finn\'s tail! Tap to ask the crab to let go!'},
  look:{fur:'#2b2730',ears:'floppy',muzzle:'#3a3540',belly:'#3a3540',tail:'plume',eyeWhite:true,acc:['bubbles','shellneck']}},
 {id:'scallop',name:'Scallop',breed:'Boston Terrier',area:'coral',pitch:1.25,spot:{x:20,z:16,kind:'bucket'},hint:'Look by an old bucket in the Coral Garden.',
  fact:'Boston Terriers have black and white coats that look like a smart little suit!',rescue:{icon:'🪣',verb:'Wiggle',say:'Scallop is stuck inside a bucket! Tap to wiggle him out!'},
  look:{fur:'#2b2730',ears:'bat',blaze:'#ffffff',muzzle:'#ffffff',belly:'#ffffff',paw:'#ffffff',tail:'stub',eyeWhite:true,scale:.85,acc:['shellneck']}},
 {id:'starla',name:'Starla',breed:'Cavapoo',area:'coral',pitch:1.35,spot:{x:-22,z:-8,kind:'rockpool'},tag:{x:24,z:-26,kind:'boulder'},hint:'Starla plays tag. Look by a ring of stones, then behind a rock near the back.',
  fact:'Cavapoos are part Cavalier and part Poodle, and they love a cuddle!',rescue:{icon:'⭐',verb:'Pop',say:'A starfish is stuck on Starla\'s nose! Tap to pop it off!'},
  look:{fur:'#e9b07a',ears:'long',ear:'#d99a5a',fluffy:true,wool:true,muzzle:'#f3cfa0',belly:'#f3cfa0',tail:'plume',acc:['shellneck','flower']}},
 {id:'anchor',name:'Anchor',breed:'Boxer',area:'ship',pitch:.9,spot:{x:-20,z:14,kind:'crate'},hint:'Look in a crate by the shipwreck.',
  fact:'Boxers bounce about and play with their front paws, just like they are boxing!',rescue:{icon:'📦',verb:'Open',say:'Anchor is stuck in a crate! Tap to open the lid!'},
  look:{fur:'#d99a5a',ears:'fold',ear:'#b87a40',muzzle:'#3a2a25',muzzleBig:true,blaze:'#ffffff',belly:'#ffffff',wrinkle:true,tail:'stub',acc:['cap']}},
 {id:'barnacle',name:'Barnacle',breed:'Otterhound',area:'ship',pitch:.85,spot:{x:24,z:18,kind:'crate'},tag:{x:-24,z:-20,kind:'bucket'},hint:'Barnacle plays tag. Look in a crate, then by an old bucket behind the ship.',
  fact:'Otterhounds have webbed feet and a shaggy waterproof coat, so they are super swimmers!',rescue:{icon:'🎣',verb:'Untangle',say:'Barnacle is caught in an old fishing net! Tap to untangle him!'},
  look:{fur:'#9a8f80',ears:'long',ear:'#7a6f60',fluffy:true,muzzle:'#b8ae9e',muzzleBig:true,brows:'#b8ae9e',belly:'#b8ae9e',tail:'plume',acc:['bubbles']}},
 {id:'gulliver',name:'Gulliver',breed:'Irish Water Spaniel',area:'trench',pitch:1,spot:{x:-22,z:-14,kind:'boulder'},hint:'Look behind a rock in the dark Deep Trench.',
  fact:'Irish Water Spaniels have curly coats and a long thin tail like a rat\'s tail!',rescue:{icon:'🔦',verb:'Shine',say:'Gulliver is lost in the dark! Tap to shine your torch so he can see!'},
  look:{fur:'#6b3a24',ears:'long',ear:'#5a2e1c',fluffy:true,wool:true,muzzle:'#7a4a30',belly:'#7a4a30',tail:'thin',acc:['shellneck']}},
 {id:'inky',name:'Inky',breed:'Curly-coated Retriever',area:'trench',pitch:.95,spot:{x:22,z:-8,kind:'crystal'},tag:{x:-6,z:26,kind:'rockpool'},hint:'Inky plays tag. Look by a glowing crystal, then by a ring of stones.',
  fact:'Curly-coated Retrievers are covered in tight little curls that keep the water out.',rescue:{icon:'🐙',verb:'Tickle',say:'An octopus is giving Inky a big hug and will not let go! Tap to tickle the octopus!'},
  look:{fur:'#2b2730',ears:'floppy',fluffy:true,wool:true,muzzle:'#3a3540',belly:'#3a3540',tail:'plume',eyeWhite:true,acc:['bubbles']}},
 {id:'marina',name:'Marina',breed:'Landseer',area:'palace',pitch:.8,spot:{x:-24,z:6,kind:'crystal'},hint:'Look by a sparkly crystal in the Pearl Palace.',
  fact:'Landseers are big gentle swimmers, famous for helping people out of the water.',rescue:{icon:'🚪',verb:'Push',say:'Marina is stuck behind a pearly door! Tap to push it open!'},
  look:{fur:'#ffffff',headC:'#2b2730',blaze:'#ffffff',ears:'floppy',ear:'#2b2730',patch:{c:'#2b2730',side:1},muzzle:'#ffffff',belly:'#ffffff',hw:62,hh:56,bw:50,bh:42,tail:'plume',acc:['shellneck']}},
 {id:'puffin',name:'Puffin',breed:'Boykin Spaniel',area:'palace',pitch:1.15,spot:{x:24,z:4,kind:'rockpool'},tag:{x:-8,z:-26,kind:'boulder'},hint:'Puffin plays tag. Look by a ring of stones, then behind a rock at the back of the palace.',
  fact:'Boykin Spaniels are small brown spaniels that love to swim, and they fit in a little boat!',rescue:{icon:'📿',verb:'Untangle',say:'Puffin is tangled in a pearl necklace! Tap to untangle her!'},
  look:{fur:'#6b3a24',ears:'long',ear:'#5a2e1c',fluffy:true,muzzle:'#7a4a30',belly:'#7a4a30',tail:'stub',acc:['bubbles','shellneck']}}];
const OPAL={id:'opal',name:'Opal',breed:'Havanese',area:'garden',pitch:1.4,spot:{x:12,z:-8,kind:'crystal'},hint:'A sparkly pup is hiding in the Sunken Garden.',
  fact:'Opal is a sparkly pup! Havanese pups come from Cuba, and they have soft silky coats. You found a secret pup!',rescue:{icon:'🐠',verb:'Wave',say:'A shy fish is guarding Opal! Tap to wave hello!'},
  look:{fur:'#f6efe6',ears:'long',ear:'#e0d2c0',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',scale:.85,acc:['twinkle','shellneck','bubbles']}};
const PEARL={id:'pearl',name:'Pearl',breed:'Sea Unicorn',uni:true,lv:1,pitch:1.25,fact:'Pearl looks after every creature on the reef.',
  look:{fur:'#f2f8ff',ears:'side',earIn:'#ffc4dc',muzzle:'#ffffff',belly:'#ffffff',nose:'#c98aa6',iris:'#ff7fb8',limbs:'hooves',hoofC:'#f0d8e6',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','shellneck','bubbles'],scale:.96}};

/* ----- areas ----- */
const lagoon=Object.assign({},WATER,{id:'lagoon',name:'Lagoon',icon:'🏝️',R:52,sky:'#5fc6e8',fog:[20,120],fogC:'#5fc6e8',swim:{top:8.5},start:[0,30,Math.PI],
  hf:(x,z)=>Math.sin(x*.1)*.5+Math.cos(z*.09)*.5,
  hello:'Welcome to Coral Reef! You are underwater in the Lagoon. Hold the Swim up button to float up, and let go to sink down. Two pups are hiding here!',how:'Take the submarine from the village.',
  exits:[{x:-38,z:-36,to:'kelp',arrive:[0,38,Math.PI],name:'Kelp Forest',icon:'🌿',open:()=>!!state.gear.flippers,lock:'The Kelp Forest is too far to swim without flippers! Look for them in the Lagoon.'},
         {x:38,z:-36,to:'coral',arrive:[0,38,Math.PI],name:'Coral Garden',icon:'🪸',open:()=>foundIn(areaPups('lagoon'))>=2,lock:()=>{const n=foundIn(areaPups('lagoon'));return `A sleepy whale is blocking the way to the Coral Garden. Find ${2-n} more ${2-n>1?'pups':'pup'} in the Lagoon, and it will swim away!`;}}],
  build(){underwater({surface:10});
    const sb=sub3D();add(sb,0,44,gy(0,44)+2);sb.rotation.y=Math.PI/2;W.ticks.push(()=>{sb.position.y=gy(0,44)+2+Math.sin(W.t)*.2;});col(0,44,3.4);
    const sl=label('🚢 Submarine',6);sl.position.set(0,gy(0,44)+6,44);W.ag.add(sl);W.things.push({x:0,z:39,r:4.6,icon:'🚢',label:'Go home',act:goHome});
    /* the flippers in an open clam */
    const cl=grp();mk('hemi','#ffd9e6',1.6,.7,1.3,0,.1,0,cl);const top=mk('hemi','#ffc4dc',1.6,.7,1.3,0,.3,-.4,cl);top.rotation.x=-2.2;mk('box','#3d8fe0',.5,.08,1,-.3,.5,0,cl);mk('box','#3d8fe0',.5,.08,1,.3,.5,.1,cl);const fs=sprite('🤿',1.2);fs.position.y=2.2;cl.add(fs);add(cl,-18,-6);col(-18,-6,1.4);
    W.things.push({x:-18,z:-3.5,r:3.8,icon:'🤿',label:'Flippers',show:()=>!state.gear.flippers,act:()=>{state.gear.flippers=true;state.stars+=5;save();hud();fs.visible=false;sfx.jingle();confetti(30);
      card({art:'<div style="font-size:110px;line-height:1">🤿</div>',h:'You found flippers!',p:'Now you can swim faster, all the way to the Kelp Forest. Its arch is on the left!'});}});
    if(state.gear.flippers)fs.visible=false;
    sign(16,6,'🦪 Pearl Dive',3,6);W.things.push({x:14,z:9,r:4,icon:'🦪',label:'Pearl Dive',show:()=>!W.act,act:()=>startCollect('pearls')});
    I('sph','#e8d29a',1.6,1.1,1.6,14,gy(14,24)+.5,24);I('cone','#e8d29a',.6,1.6,.6,14,gy(14,24)+1.8,24);
    for(let i=0;i<14;i++){const a=R()*6.28,r=10+R()*34;coral(Math.cos(a)*r,Math.sin(a)*r,.8+R()*.5,pick(CORALS),pick(['branch','fan','brain']));}
    seaRock(-28,14,1.3);seaRock(30,-8);seagrass(40,50);shells(30,50);
    fishSchool(0,5,0,12,9,'🐠',.3);fishSchool(-16,3,-20,6,6,'🐟',.5);const tt=sprite('🐢',2.6);W.ag.add(tt);W.ticks.push(()=>{const a=W.t*.15;tt.position.set(Math.cos(a)*24,6,Math.sin(a)*24);});
    sign(-30,-28,'🌿 Kelp Forest',3,6);sign(30,-28,'🪸 Coral Garden',3,6);reefEdge(52,[angOf(-38,-36),angOf(38,-36),90]);}});

const kelpA=Object.assign({},WATER,{id:'kelp',name:'Kelp Forest',icon:'🌿',R:52,sky:'#3f9c8f',fog:[14,85],fogC:'#3f9c8f',ground:'#a89a70',ground2:'#7d8a5a',swim:{top:15},start:[0,38,Math.PI],
  hf:(x,z)=>Math.sin(x*.12)*.8+Math.cos(z*.1)*.8,
  hello:'The Kelp Forest! The kelp grows taller than a house. Two pups are hiding here, and a school of little fish needs your help.',how:'You need flippers from the Lagoon.',
  exits:[{x:0,z:52,to:'lagoon',arrive:[-30,-26,Math.PI*1.25],name:'Lagoon',icon:'🏝️'},
         {x:0,z:-52,to:'ship',arrive:[0,36,Math.PI],name:'Shipwreck',icon:'⚓',gate:{type:'water',key:'current_ship',look:'current',verb:'calms the swirling current',done:'The current is calm! Swim on to the Shipwreck!'}}],
  build(){underwater({beams:6,speck:'#d9ffe8'});
    for(let i=0;i<14;i++){const a=R()*6.28,r=10+R()*36,x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.abs(x)<6&&Math.abs(z)>20)continue;if(Math.hypot(x+24,z-18)<5||Math.hypot(x-26,z+6)<5||Math.hypot(x+20,z+30)<5||Math.hypot(x-14,z-8)<6)continue;kelp(x,z,8+R()*7,R()<.5?'#3f9e46':'#5aa846');}
    kelpField(70,50,(x,z)=>Math.abs(x)<6&&Math.abs(z)>18||Math.hypot(x+24,z-18)<5||Math.hypot(x-26,z+6)<5||Math.hypot(x+20,z+30)<5||Math.hypot(x-14,z-8)<7);
    sign(18,10,'🐠 Fish Round-up',3,7);W.things.push({x:14,z:8,r:4,icon:'🐠',label:'Fish',act:()=>{sfx.chime();startHerd('activity','fishherd');}});
    fishSchool(14,4,8,5,8,'🐟',.6);fishSchool(-10,8,-10,14,8,'🐠',.25);seaRock(-34,0,1.2);seaRock(32,-24,1.1);seagrass(30,48,'#4f9e46');
    reefEdge(52,[90,270]);}});

const coralA=Object.assign({},WATER,{id:'coral',name:'Coral Garden',icon:'🪸',R:52,sky:'#4fb6e0',fog:[20,110],fogC:'#4fb6e0',swim:{top:13},start:[0,38,Math.PI],
  hf:(x,z)=>Math.sin(x*.1)*.7+Math.cos(z*.12)*.7,
  hello:'The Coral Garden! Look at all the colours! Two pups are hiding here, and starfish are hiding in the coral.',how:'Find 2 pups in the Lagoon to open the way.',
  exits:[{x:0,z:52,to:'lagoon',arrive:[30,-26,Math.PI*.75],name:'Lagoon',icon:'🏝️'},
         {x:0,z:-52,to:'trench',arrive:[0,36,Math.PI],name:'Deep Trench',icon:'🌑',gate:{type:'water',key:'current_trench',look:'current',verb:'calms the swirling current',done:'The current is calm! Swim down to the Deep Trench!'}},
         {x:-52,z:0,to:'garden',arrive:[0,24,Math.PI],name:'Sunken Garden',icon:'🌺',gate:{type:'snow',key:'vent',look:'vent',need:0,verb:'cools the hot bubbly vent',done:'The vent is cool! Swim through to the secret Sunken Garden!'},lock:'A hot bubbly vent is in the way! A Snow pup from Snowy Summit could cool it down.'}],
  build(){underwater({beams:12});
    for(let i=0;i<40;i++){const a=R()*6.28,r=8+R()*40,x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.abs(x)<5||Math.abs(z)<5)continue;if(Math.hypot(x-20,z-16)<5||Math.hypot(x+22,z+8)<5||Math.hypot(x-24,z+26)<5)continue;coral(x,z,1+R()*.8,pick(CORALS),pick(['branch','fan','brain','branch']));}
    sign(-12,12,'⭐ Starfish Hunt',3,6);W.things.push({x:-10,z:10,r:4,icon:'⭐',label:'Starfish',show:()=>!W.act,act:()=>startCollect('starfish')});
    fishSchool(0,6,0,16,10,'🐠',.25);fishSchool(16,3,-14,5,6,'🐡',.5);seagrass(30,48,'#6fbf5a');shells(30,48);reefEdge(52,[90,270,180]);}});

const ship=Object.assign({},WATER,{id:'ship',name:'Shipwreck',icon:'⚓',R:50,sky:'#2f7fa8',fog:[14,90],fogC:'#2f7fa8',ground:'#c9b88a',ground2:'#9c8f6a',swim:{top:14},start:[0,36,Math.PI],
  hf:(x,z)=>Math.sin(x*.1)*.8+Math.cos(z*.1)*.8,
  hello:'The Shipwreck! An old pirate ship sank here long ago. Two pups are hiding here, and gold coins are scattered all around!',how:'A Water pup calms the current at the back of the Kelp Forest.',
  exits:[{x:0,z:50,to:'kelp',arrive:[0,-40,0],name:'Kelp Forest',icon:'🌿'},
         {x:30,z:-40,to:'palace',arrive:[-16,28,Math.PI*.85],name:'Pearl Palace',icon:'🏰',gate:{type:'water',key:'current_palace_s',look:'current',verb:'calms the swirling current',done:'The current is calm! Swim on to the Pearl Palace!'}}],
  build(){underwater({beams:5});
    const hull=grp();mk('box','#7a4f2a',7,4,20,0,2,0,hull);mk('box','#5b3a20',7.4,.6,20.4,0,4,0,hull);mk('cone','#7a4f2a',3.6,5,2.2,0,2,12.4,hull).rotation.x=Math.PI/2;mk('box','#9b6a43',5,2.4,4,0,5.2,-7,hull);
    const mast=mk('cyl','#9b6a43',.35,14,.35,0,10,2,hull);mast.rotation.z=.35;mk('box','#e8e0cc',5,3.6,.1,1.6,11,2,hull).rotation.z=.35;for(let i=0;i<3;i++)mk('cyl','#3a2a20',.6,.3,.6,3.55,2+i*.9,-4+i*5,hull,true).rotation.z=Math.PI/2;
    hull.rotation.set(0,.5,.18);add(hull,-4,-6,gy(-4,-6)-.5);rect(-10,-16,4,4);const sl=label('⚓ The old ship',6);sl.position.set(-4,13,-6);W.ag.add(sl);
    sign(10,14,'🪙 Treasure Hunt',3,6);W.things.push({x:10,z:11,r:4,icon:'🪙',label:'Treasure',show:()=>!W.act,act:()=>startCollect('treasure')});
    [[12,-18],[-18,20],[16,24]].forEach(p=>{I('box','#9b6a43',1.6,1.6,1.6,p[0],gy(p[0],p[1])+.8,p[1],0,p[0],0);col(p[0],p[1],1.2);});
    I('cyl','#5b4636',.5,6,.5,-28,gy(-28,-4)+.5,-4,0,0,Math.PI/2);I('tor','#5b4636',1.2,1.2,1.2,-25,gy(-28,-4)+.6,-4,Math.PI/2,0,0);
    for(let i=0;i<14;i++){const a=R()*6.28,r=14+R()*30;coral(Math.cos(a)*r,Math.sin(a)*r,.8+R()*.4,pick(CORALS),pick(['fan','brain']));}
    fishSchool(-4,9,-6,12,7,'🐟',.3);const sh=sprite('🦈',3);W.ag.add(sh);W.ticks.push(()=>{const a=W.t*.12;sh.position.set(Math.cos(a)*34,11,Math.sin(a)*34);});
    seagrass(20,46,'#5f8e4a');reefEdge(50,[90,angOf(30,-40)]);}});

const trench=Object.assign({},WATER,{id:'trench',name:'Deep Trench',icon:'🌑',R:50,sky:'#123a5e',fog:[10,70],fogC:'#123a5e',ground:'#3a4f6e',ground2:'#2a3a56',hedgeC:'#3a4a66',swim:{top:16},start:[0,36,Math.PI],
  hf:(x,z)=>-8*Math.exp(-(x*x+z*z)/500)+Math.sin(x*.15)*.6+Math.cos(z*.13)*.6,
  hello:'The Deep Trench. It is dark down here, but the fish glow like lanterns! Two pups are hiding in the dark.',how:'A Water pup calms the current at the back of the Coral Garden.',
  exits:[{x:0,z:50,to:'coral',arrive:[0,-40,0],name:'Coral Garden',icon:'🪸'},
         {x:-30,z:-40,to:'palace',arrive:[16,28,Math.PI*1.15],name:'Pearl Palace',icon:'🏰',gate:{type:'water',key:'current_palace_t',look:'current',verb:'calms the swirling current',done:'The current is calm! Swim up to the Pearl Palace!'}}],
  build(){underwater({beams:2,speck:'#9be8ff'});
    for(let i=0;i<30;i++){const a=R()*6.28,r=6+R()*40,x=Math.cos(a)*r,z=Math.sin(a)*r,y=gy(x,z),c=pick(['#7fffe0','#ff7fd0','#b58cff','#7fd3ff']);for(let k=0;k<5;k++)I('cyl',c,.08,1+R(),.08,x+Math.cos(k*1.3)*.3,y+.6,z+Math.sin(k*1.3)*.3,Math.cos(k)*.3,0,Math.sin(k)*.3,true);I('sph',c,.18,.18,.18,x,y+1.3,z,0,0,0,true);}
    const jel=[0,1,2,3,4].map(i=>{const s=sprite('🪼',2);W.ag.add(s);return s;});W.ticks.push(()=>jel.forEach((s,i)=>{s.position.set(Math.cos(i*1.3+W.t*.1)*20,4+i*2+Math.sin(W.t+i)*1.2,Math.sin(i*1.3+W.t*.1)*20);}));
    fishSchool(0,2,0,10,8,'🐟',.4);seaRock(-30,10,1.4,'#4a5a76');seaRock(28,18,1.2,'#4a5a76');seaRock(10,-30,1.5,'#4a5a76');
    sign(12,18,'✨ Glow-fish Catch',3,7);W.things.push({x:10,z:16,r:4,icon:'🐟',label:'Glow-fish',act:()=>{sfx.chime();startFlies('activity','glowfish');}});
    reefEdge(50,[90,angOf(-30,-40)]);}});

const palace=Object.assign({},WATER,{id:'palace',name:'Pearl Palace',icon:'🏰',R:46,sky:'#5fb0e8',fog:[20,110],fogC:'#7fc0ec',ground:'#f6e8f0',ground2:'#e0cfe8',hedgeC:'#e8d0e8',swim:{top:16},start:[-16,28,Math.PI*.85],
  hf:(x,z)=>Math.sin(x*.12)*.4+Math.cos(z*.12)*.4,
  hello:'The Pearl Palace! It shines like the inside of a shell. Two pups are hiding here, and Pearl the Sea Unicorn lives in the palace.',how:'A Water pup calms a current in the Shipwreck or the Deep Trench.',
  exits:[{x:-28,z:32,to:'ship',arrive:[22,-28,Math.PI*.8],name:'Shipwreck',icon:'⚓'},{x:28,z:32,to:'trench',arrive:[-22,-28,Math.PI*1.2],name:'Deep Trench',icon:'🌑'}],
  build(){underwater({beams:10});
    [[-14,-26,10],[14,-26,10],[0,-32,15],[-26,-12,7],[26,-12,7]].forEach(t=>{const y=gy(t[0],t[1]);I('cyl','#f6eef8',2.4,t[2],2.4,t[0],y+t[2]/2,t[1]);I('hemi','#ffb3cf',2.8,2.6,2.8,t[0],y+t[2],t[1]);I('sph','#ffffff',.6,.6,.6,t[0],y+t[2]+2.8,t[1],0,0,0,true);col(t[0],t[1],2.6);});
    I('box','#f6eef8',22,6,3,0,gy(0,-28)+3,-28);rect(-11,-29.5,11,-26.5);const pl=label('🏰 Pearl Palace',7);pl.position.set(0,gy(0,-30)+20,-30);W.ag.add(pl);
    for(let i=0;i<10;i++){const a=i/10*6.28,x=Math.cos(a)*18,z=Math.sin(a)*18+2;if(z>14)continue;I('sph','#fff8fb',.7,.7,.7,x,gy(x,z)+.7,z,0,0,0,true);}
    [[-30,4],[30,0]].forEach(p=>{I('hemi','#ffc4dc',2.2,1,1.8,p[0],gy(p[0],p[1]),p[1]);I('sph','#ffffff',.6,.6,.6,p[0],gy(p[0],p[1])+.6,p[1],0,0,0,true);col(p[0],p[1],2);});
    sign(8,16,'🐚 Shell Steps',3,6);W.things.push({x:6,z:14,r:4,icon:'🐚',label:'Shell Steps',act:()=>{sfx.chime();startStones('activity','shellsteps');}});
    fishSchool(0,10,-6,18,10,'🐠',.2);shells(30,42);reefEdge(46,[angOf(-28,32),angOf(28,32)]);}});

const garden=Object.assign({},WATER,{id:'garden',name:'Sunken Garden',icon:'🌺',R:34,sky:'#4fc6c0',fog:[18,90],fogC:'#4fc6c0',ground:'#d9e8b0',ground2:'#b8d890',swim:{top:12},start:[0,24,Math.PI],
  hf:(x,z)=>Math.sin(x*.2)*.5+Math.cos(z*.2)*.5,
  hello:'The secret Sunken Garden! Glowing flowers grow under the sea here. A sparkly pup and a treasure chest are hidden somewhere!',how:'A Snow pup cools the hot vent in the Coral Garden.',
  exits:[{x:0,z:34,to:'coral',arrive:[-40,0,Math.PI*.5],name:'Coral Garden',icon:'🪸'}],
  build(){underwater({beams:8});for(let i=0;i<60;i++){const a=R()*6.28,r=4+R()*26,x=Math.cos(a)*r,z=Math.sin(a)*r,y=gy(x,z),c=pick(['#ff9ecb','#fff27a','#9be8ff','#c9b6ff']);I('cyl','#4fae4a',.06,1.2,.06,x,y+.6,z);I('sph',c,.35,.3,.35,x,y+1.3,z,0,0,0,true);}
    treasureChest(-10,-14,'garden');coral(18,-16,1.4,'#ff7f9e');coral(-20,8,1.3,'#c78cff','fan');fishSchool(0,5,0,10,8,'🐠',.3);reefEdge(34,[90]);}});

/* ----- activities ----- */
COLLECT.pearls={k:'pearls',area:'lagoon',icon:'🦪',size:2,items:[[-10,-20,1.5],[20,-16,4],[-26,-4,6],[24,12,2],[-6,10,7],[6,-34,3]],start:[10,16,Math.PI],thing:'pearl',art:'🦪',
  intro:'Pearl Dive! Collect the 6 pearls. Some are floating high up, so hold the Swim up button to reach them!',title:'You collected all the pearls!'};
COLLECT.starfish={k:'starfish',area:'coral',icon:'⭐',size:2,items:[[-30,-20,1],[28,-10,3],[-14,-36,5],[34,20,2],[-34,22,4],[10,-20,6]],start:[-6,16,Math.PI],thing:'starfish',art:'⭐',
  intro:'Starfish Hunt! Find the 6 golden starfish hiding among the coral. Some are up high!',title:'You found all the starfish!'};
COLLECT.treasure={k:'treasure',area:'ship',icon:'🪙',size:2,items:[[-4,-6,7],[14,-18,1.5],[-20,6,2],[22,8,4],[-26,-22,3],[2,20,5]],start:[10,18,Math.PI],thing:'gold coin',art:'🪙',
  intro:'Treasure Hunt! Find the 6 gold coins around the old shipwreck. One is right up on the deck!',title:'You found all the treasure!'};
function fishSVG(){const k=INK;return `<svg viewBox="0 0 90 70"><g stroke="${k}" stroke-width="3.5"><path d="M20 35 L4 20 L6 50Z" fill="#ff8a3c"/><ellipse cx="46" cy="35" rx="30" ry="20" fill="#ffb347"/><path d="M36 17 Q46 4 56 17" fill="#ff8a3c"/></g>
  <path d="M40 18 Q46 35 40 52" stroke="#fff" stroke-width="6" fill="none"/><circle cx="64" cy="31" r="6" fill="#fff" stroke="${k}" stroke-width="2.5"/><circle cx="66" cy="31" r="3" fill="${k}"/><path d="M70 42 q4 3 8 0" stroke="${k}" stroke-width="2.5" fill="none"/></svg>`;}
function seaPenSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="sea2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5fc6e8"/><stop offset="1" stop-color="#2f8fbf"/></linearGradient></defs><rect width="1024" height="768" fill="url(#sea2)"/>`;
  for(let i=0;i<10;i++)s+=`<path d="M${i*110} 0 L${i*110+60} 768" stroke="#fff" stroke-width="30" opacity=".05"/>`;
  for(let i=0;i<24;i++)s+=`<path d="M${(i*137)%1000+12} 768 q-10 -60 0 -${80+(i%4)*30} q10 -40 0 -60" stroke="#3f9e46" stroke-width="7" fill="none" opacity=".7"/>`;
  for(let i=0;i<30;i++)s+=`<circle cx="${(i*151)%1010+8}" cy="${160+(i*83)%590}" r="${3+i%4}" fill="#ffffff" opacity=".25"/>`;
  s+=penBoxSea();return s+'</svg>';}
function penBoxSea(){const k=INK,P=PEN;let s=`<rect x="${P.x1}" y="${P.y1}" width="${P.x2-P.x1}" height="${P.y2-P.y1}" rx="30" fill="#ffd9e6" opacity=".55"/>`;
  const wall=(x1,y1,x2,y2)=>{let t='';const d=Math.hypot(x2-x1,y2-y1),n=Math.ceil(d/34);for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,y=y1+(y2-y1)*i/n;t+=`<circle cx="${x}" cy="${y-8}" r="20" fill="${['#ff7f9e','#ffb347','#c78cff','#7fd3f0'][i%4]}" stroke="${k}" stroke-width="3"/>`;}return t;};
  s+=wall(P.x1,P.y1,P.x2,P.y1)+wall(P.x2,P.y1,P.x2,P.y2)+wall(P.x1,P.y2,P.x2,P.y2)+wall(P.x1,P.y1,P.x1,P.gy1)+wall(P.x1,P.gy2,P.x1,P.y2);
  s+=`<g transform="translate(${(P.x1+P.x2)/2+20} ${(P.y1+P.y2)/2+40})">`;for(let i=0;i<9;i++)s+=`<path d="M0 0 q${-40+i*10} -50 ${-30+i*8} -90" stroke="#ff9ecb" stroke-width="10" stroke-linecap="round" fill="none"/>`;s+=`</g>`;
  return s+`<g transform="translate(${P.x1+80} ${P.y1+50})"><rect x="-72" y="-30" width="144" height="40" rx="10" fill="#fff" stroke="${k}" stroke-width="4"/><text x="0" y="-2" font-size="22" font-weight="900" text-anchor="middle" fill="${k}">🪸 Anemone</text></g>
  <path d="M${P.x1-70} ${(P.gy1+P.gy2)/2} l40 0 m-14 -14 l14 14 l-14 14" stroke="#fff" stroke-width="8" fill="none" stroke-linecap="round" stroke-linejoin="round" opacity=".9"/>`;}
function deepSVG(){let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="dp" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a4a76"/><stop offset="1" stop-color="#081a30"/></linearGradient></defs><rect width="1024" height="768" fill="url(#dp)"/>`;
  for(let i=0;i<50;i++)s+=`<circle cx="${(i*211)%1010+7}" cy="${(i*67)%640+10}" r="${1+i%3}" fill="#9be8ff" opacity="${.2+(i%4)*.1}"/>`;
  for(let i=0;i<16;i++)s+=`<path d="M${(i*131)%1000+20} 768 q-14 -40 0 -${60+(i%3)*30}" stroke="${['#7fffe0','#ff7fd0','#b58cff'][i%3]}" stroke-width="6" fill="none" opacity=".7"/>`;
  return s+`<path d="M0 650 Q260 610 512 640 T1024 630 V768 H0Z" fill="#132a46"/></svg>`;}
function palaceSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#4fa8dc"/><rect width="1024" height="150" fill="#bfe6ff"/>`;
  for(let i=0;i<6;i++){const x=80+i*175;s+=`<rect x="${x}" y="40" width="40" height="110" fill="#f6eef8" stroke="${k}" stroke-width="3"/><path d="M${x-6} 44 a26 26 0 0 1 52 0Z" fill="#ffb3cf" stroke="${k}" stroke-width="3"/>`;}
  for(let i=0;i<24;i++)s+=`<circle cx="${(i*173)%980+20}" cy="${200+(i*97)%540}" r="${4+i%3}" fill="#ffffff" opacity=".35"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#f6e8f0" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#f6e8f0" stroke="${k}" stroke-width="5"/>`;
  return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🦄</text></svg>`;}
HERDS.fishherd={k:'fishherd',icon:'🐠',n:6,animal:()=>fishSVG(),herder:()=>buddyPup(),bg:()=>seaPenSVG(),title:'All the little fish are safe!',
  intro:p=>`The little fish have swum away from their anemone home! Help ${p.name} round them up. Drag your finger and ${p.name} will follow. The fish swim away from ${p.name}!`};
CATCH.glowfish={k:'glowfish',icon:'🐟',need:15,bg:()=>deepSVG(),cls:'fish',inner:'<b>🐠</b>',art:'🫙🐟',swim:true,intro:'Catch the glow-fish! Tap a fish while it is glowing, and it will swim into your jar. Catch 15!',tip:'Wait until it glows, then tap!',title:'You caught 15 glow-fish!'};
COUNTS.shellsteps={k:'shellsteps',icon:'🐚',rounds:[{step:5,word:'fives'},{step:4,word:'fours'},{start:80,step:-10,word:'tens, going backwards'}],bg:()=>palaceSVG(),cls:'shell',intro:'Help your pup hop across the palace pool on the shells!',title:'You counted across the palace pool!'};
regAct('pearls',{name:'Pearl Dive',icon:'🦪',island:'reef',area:'lagoon',where:'the Lagoon',play:()=>arcadeTravel('lagoon',COLLECT.pearls.start,()=>startCollect('pearls'),'Pearl Dive is about to start!')});
regAct('fishherd',{name:'Fish Round-up',icon:'🐠',island:'reef',area:'kelp',where:'the Kelp Forest',play:()=>startHerd('arcade','fishherd')});
regAct('starfish',{name:'Starfish Hunt',icon:'⭐',island:'reef',area:'coral',where:'the Coral Garden',play:()=>arcadeTravel('coral',COLLECT.starfish.start,()=>startCollect('starfish'),'Starfish Hunt is about to start!')});
regAct('treasure',{name:'Treasure Hunt',icon:'🪙',island:'reef',area:'ship',where:'the Shipwreck',play:()=>arcadeTravel('ship',COLLECT.treasure.start,()=>startCollect('treasure'),'Treasure Hunt is about to start!')});
regAct('glowfish',{name:'Glow-fish Catch',icon:'🐟',island:'reef',area:'trench',where:'the Deep Trench',play:()=>startFlies('arcade','glowfish')});
regAct('shellsteps',{name:'Shell Steps',icon:'🐚',island:'reef',area:'palace',where:'the Pearl Palace',play:()=>startStones('arcade','shellsteps')});

regIsland({id:'reef',name:'Coral Reef',icon:'🐠',type:'water',rideName:'The submarine',ride:'the submarine',from:'harbour in the village',rideIcon:'🚢',rideSay:'Diving down in the yellow submarine!',
  homeSay:'Back up to the village in the submarine!',homePos:[-33,24,-0.8],
  badge:'Sea Badge',cert:'Seb, Coral Reef Hero!',bossHint:'Pearl the Sea Unicorn is waiting at the Pearl Palace!',
  nextSay:'Hooray! Coral Reef is safe! Have you been to Snowy Summit too?',
  map:{shape:'M100 380 Q40 240 130 140 Q230 30 430 40 Q640 30 740 140 Q830 250 760 380 Q600 455 430 445 Q260 455 100 380Z',
    nodes:{lagoon:[430,330],kelp:[210,250],coral:[650,250],ship:[170,95],trench:[700,95],palace:[430,80],garden:[765,335]},
    links:[['lagoon','kelp'],['lagoon','coral'],['kelp','ship'],['coral','trench'],['ship','palace'],['trench','palace'],['coral','garden']]},
  boss:{area:'palace',x:0,z:-18,perch:0,uni:PEARL,
    story:[['m','Muddle the Magpie bobs over in a bubble helmet. "Sorry, Seb! I tried to borrow the shiniest pearl in the palace, and all the pups swam off to hide!"'],
      ['u','Pearl the Sea Unicorn smiles. "Muddle, the pearls belong to the sea. Let\'s give the shiny Sea Star back."'],
      ['b','Muddle gives back the Sea Star, and all 12 Water pups do happy flips! Pearl gives Seb the Sea Badge.']],
    after:['Pearl says: thank you for finding every pup on Coral Reef!','Muddle says: blub blub! I mean, thank you!','Pearl says: the fish say hello!']},
  pups:PUPS12,bonus:[OPAL],areas:[lagoon,kelpA,coralA,ship,trench,palace,garden]});
})();
