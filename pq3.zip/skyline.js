/* ================================================================
   The village skyline (24 Nov 2026): Pawprint Village sits on its own
   island, and every region can be seen across the sea, in the
   direction its ride leaves from: Meadow Island (south, the ferry),
   Snowy Summit (east, the chairlift; built in village.js), Coral Reef
   (south-west, the submarine), Gadget Island (south-south-west, the
   flying machine), Rescue Bay (south-east, the fire engine's bridge),
   Number Kingdom's giant cube (north-east, the train), Ninja Mountains
   (west, the dragon kite), Dino Valley's volcano (north, the time
   machine) and the Moon in the western sky (Planet Hop's rocket).
   ================================================================ */
(function(){
const V=AREAS.village;
V.fog=[90,430];
{const oh=V.hf;V.hf=(x,z)=>oh(x,z)-6*sstep(78,94,Math.hypot(x,z));}
const isle=(x,z,r,sand,grass,h,sq)=>{sq=sq||.8;I('cyl',sand||'#f0dca0',r,1.6,r*sq,x,-1.9,z);if(grass)I('sph',grass,r*.86,h||6,r*sq*.84,x,-1.3,z);};
const canvasTex=(w,h,draw)=>{const c=document.createElement('canvas');c.width=w;c.height=h;draw(c.getContext('2d'),w,h);const t=new THREE.CanvasTexture(c);W.disp.push(t);return t;};

function meadow(){/* the old green dome stays; add a beach, a windmill and trees */
  I('cyl','#f0dca0',64,1.2,44,0,-1.6,200);
  const y=7.6,x=12,z=194,g=grp();I('cyl','#fff8e6',1.7,9,1.7,x,y+4.5,z);I('cone','#c26a32',2.2,3,2.2,x,y+10.4,z);add(g,x,z-1.9,y+8.6);
  const sails=grp();for(let i=0;i<4;i++){const arm=grp();arm.rotation.z=i*Math.PI/2;sails.add(arm);mk('box','#ffffff',1.2,8,.15,0,4.2,0,arm);mk('box','#c26a32',.25,8.6,.2,0,4.3,-.1,arm);}g.add(sails);
  W.ticks.push(dt=>{sails.rotation.z+=dt*.5;});
  [[-20,198],[-28,206],[24,206],[30,198],[-4,214]].forEach(p=>{I('sphL','#5fbf5a',4,3.4,4,p[0],5.5,p[1]);I('cylL','#9b6a43',.5,3,.5,p[0],3.2,p[1]);});}
function reef(){const x=-172,z=122;
  I('cyl','#7fe0e8',38,.3,30,x,-1.25,z);I('tor','#ffffff',38,30,6,x,-1.2,z,Math.PI/2,0,0);
  [[x-14,z-6,7],[x+10,z+8,5],[x+16,z-12,4]].forEach(q=>{I('sph','#f0dca0',q[2],2.2,q[2]*.8,q[0],-1.4,q[1]);
    for(let k=0;k<2;k++){const px=q[0]+k*2-1,pz=q[1]+k,h=6+k;I('cylL','#9b6a43',.35,h,.35,px+.6,-.6+h/2,pz,0,0,-.15);
      for(let f=0;f<5;f++){const a=f/5*6.28;I('coneL','#3fae5a',.5,3.2,.25,px+1.2+Math.cos(a)*1.3,h-.6,pz+Math.sin(a)*1.3,Math.sin(a)*1.1,0,-Math.cos(a)*1.1);}}});
  for(let i=0;i<14;i++){const a=i/14*6.28,r=26+(i%3)*3;I('sph',pick(['#ff8fb3','#ff9a3c','#b58cff','#ffd23f']),2,1,2,x+Math.cos(a)*r,-1.15,z+Math.sin(a)*r*.8);}
  const sub=grp();mk('sph','#ffd23f',2.6,1.2,1.4,0,0,0,sub);mk('cyl','#ffd23f',.3,2.4,.3,0,1.6,0,sub);mk('box','#ffd23f',.3,.3,1.2,0,2.8,.5,sub);add(sub,x+4,z-2,-1.1);
  W.ticks.push(()=>{sub.position.y=-1.1+Math.sin(W.t*1.2)*.2;});}
function gadget(){const x=-96,z=196;isle(x,z,30,'#c9c2b8','#9aa0a8',3,.7);
  const B=[[-14,-6,8,22,'#7a8898'],[-4,-10,7,30,'#8e9aa8'],[6,-6,9,18,'#5b6378'],[14,2,7,14,'#c9905f'],[-12,6,10,12,'#a8b0ba'],[2,6,8,24,'#7a8898']];
  B.forEach(b=>{const bx=x+b[0],bz=z+b[1],h=b[3];I('box',b[4],b[2],h,b[2],bx,h/2,bz);for(let k=2;k<h-1;k+=3)I('box','#ffe9a0',b[2]*.8,.8,.2,bx,k,bz-b[2]/2-.05,0,0,0,true);});
  [[x+18,z-8],[x+22,z-2]].forEach((p,i)=>{for(let k=0;k<5;k++)I('cyl',k%2?'#ffffff':'#e8423a',1.4,4,1.4,p[0],2+k*4,p[1]);});
  const pm=new THREE.MeshLambertMaterial({color:'#c9c2c8',transparent:true,opacity:.6,depthWrite:false});W.disp.push(pm);const P=[];
  for(let i=0;i<6;i++){const m=new THREE.Mesh(G.sph,pm);m.userData.noBake=true;W.ag.add(m);P.push({m,k:i/6,x:i%2?x+22:x+18,z:i%2?z-2:z-8});}
  W.ticks.push(dt=>{P.forEach(p=>{p.k=(p.k+dt*.06)%1;const s=2+p.k*6;p.m.scale.set(s,s*.7,s);p.m.position.set(p.x+p.k*10,22+p.k*20,p.z);});});
  I('box','#ffd23f',1.2,34,1.2,x-22,17,z);I('box','#ffd23f',26,1,1.2,x-14,34,z,0,.5,0);I('box','#5b6378',3,3,3,x-24,32,z);I('cyl','#3a3338',.08,12,.08,x-4,28,z+4.5);}
function rescue(){const x=142,z=150;isle(x,z,28,'#f0dca0','#7fcf6a',4);
  for(let k=0;k<6;k++)I('cyl',k%2?'#ffffff':'#e8423a',2.4-k*.12,3,2.4-k*.12,x-14,2+k*3,z-4);I('cyl','#fff8c0',1.6,2.2,1.6,x-14,20,z-4,0,0,0,true);I('cone','#e8423a',2.2,2.6,2.2,x-14,22.5,z-4);
  const bm=new THREE.MeshBasicMaterial({color:'#fff6b0',transparent:true,opacity:.28,depthWrite:false});W.disp.push(bm);const beam=grp();
  [0,Math.PI].forEach(a=>{const c=new THREE.Mesh(G.cone,bm);c.scale.set(3,40,3);c.rotation.z=Math.PI/2;c.position.x=20;const h=grp();h.rotation.y=a;h.add(c);beam.add(h);});add(beam,x-14,z-4,20);W.ticks.push(dt=>{beam.rotation.y+=dt*.8;});
  [[0,4,'#ff9ecb'],[6,2,'#9bdcff'],[12,6,'#fff27a'],[-4,10,'#c9b6ff'],[8,12,'#ffb347']].forEach(c=>{const hx=x+c[0],hz=z+c[1];I('box',c[2],4,3.4,3.6,hx,3,hz);I('pyr','#6a6a78',3.4,2,3,hx,5.6,hz,0,Math.PI/4,0);});
  I('box','#e8423a',4,1.4,1.8,x+2,-1,z-16);I('box','#ffffff',2,1,1.4,x+2,.1,z-16);}
function number(){const x=152,z=-138;isle(x,z,32,'#e8dcc4','#d8ccb0',2,.9);
  const g=grp();mk('box','#f4efe6',34,34,34,0,0,0,g);[[0,0,17.1,0,'1','#3d8fe0'],[17.1,0,0,Math.PI/2,'2','#e8423a'],[0,0,-17.1,Math.PI,'3','#3fae5a'],[-17.1,0,0,-Math.PI/2,'4','#ffb030']].forEach(f=>{
    const t=canvasTex(128,128,(c,w,h)=>{c.fillStyle=f[5];c.beginPath();c.roundRect?c.roundRect(6,6,116,116,20):c.rect(6,6,116,116);c.fill();c.fillStyle='#fff';c.font='900 92px sans-serif';c.textAlign='center';c.textBaseline='middle';c.fillText(f[4],64,70);});
    const m=new THREE.MeshBasicMaterial({map:t});W.disp.push(m);const pl=new THREE.Mesh(new THREE.PlaneGeometry(26,26),m);W.disp.push(pl.geometry);pl.position.set(f[0],f[1],f[2]);pl.rotation.y=f[3];pl.userData.noBake=true;g.add(pl);});
  for(let i=0;i<4;i++){const e=mk('box','#ffd23f',35,1,1,0,0,0,g);e.position.set(0,17,i<2?(i?17:-17):0);if(i>=2){e.rotation.y=Math.PI/2;e.position.set(i===2?17:-17,17,0);}}
  g.rotation.y=-.43;g.scale.setScalar(1.2);add(g,x,z,19);}
function ninja(){const x=-204,z=-46;isle(x,z,34,'#d8a070',null);
  [[0,0,12,36,'#c96a3a'],[-14,10,9,26,'#b8572f'],[12,-12,8,22,'#a84f2e'],[16,10,7,16,'#c96a3a'],[-10,-14,6,14,'#b8572f']].forEach(m=>{I('cyl',m[4],m[2],m[3],m[2]*.92,x+m[0],m[3]/2-1.5,z+m[1]);I('cyl','#8a3f22',m[2]*1.01,1.2,m[2]*.93,x+m[0],m[3]*.55,z+m[1]);});
  const py=34.5;[[7,3.4],[5.6,3],[4.2,2.6],[2.8,2.2]].forEach((t,i)=>{const yy=py+i*3.6;I('box','#fff2d8',t[0],t[1],t[0],x,yy+t[1]/2,z);I('pyr','#3a3338',t[0]*.95,1.6,t[0]*.95,x,yy+t[1]+.6,z,0,Math.PI/4,0);});
  I('cone','#e8423a',.5,4,.5,x,py+16.5,z);
  [-1,1].forEach(s=>I('cyl','#e8423a',.6,8,.6,x+20+s*3,2.5,z+18));I('box','#e8423a',9,.8,1,x+20,7,z+18);I('box','#3a3338',10,.6,1.2,x+20,7.8,z+18);
  [[x+24,z-6],[x-24,z+4],[x+6,z+24]].forEach(p=>{I('cylL','#6b4a32',.5,3,.5,p[0],0,p[1]);I('sphL','#ffb3cf',3.4,2.6,3.4,p[0],2.6,p[1]);});}
function dino(){const x=-104,z=-198;isle(x,z,36,'#d8b87e','#3f7e3a',8);
  const vx=x+6,vz=z-8;I('cone','#5a4a44',26,40,26,vx,18,vz);I('cyl','#ff8a2a',5,1,5,vx,37.6,vz,0,0,0,true);for(let i=0;i<3;i++){const a=2.4+i*.5;I('box','#ff6a1a',1.2,18,.6,vx+Math.cos(a)*9,27,vz+Math.sin(a)*9,Math.sin(a)*.55,0,-Math.cos(a)*.55,true);}
  const pm=new THREE.MeshLambertMaterial({color:'#8a8088',transparent:true,opacity:.55,depthWrite:false});W.disp.push(pm);const P=[];
  for(let i=0;i<5;i++){const m=new THREE.Mesh(G.sph,pm);m.userData.noBake=true;W.ag.add(m);P.push({m,k:i/5});}
  W.ticks.push(dt=>{P.forEach(p=>{p.k=(p.k+dt*.04)%1;const s=3+p.k*10;p.m.scale.set(s,s*.7,s);p.m.position.set(vx+p.k*14,39+p.k*26,vz);});});
  for(let i=0;i<14;i++){const a=i/14*6.28,r=22+(i%3)*4;I('sphL',pick(['#2f6a32','#3f7e3a','#4f8e3a']),4,4.4,4,x+Math.cos(a)*r,3+(i%2),z+Math.sin(a)*r*.8);}
  if(window.DINO&&DINO.sauro3D){const g=DINO.sauro3D('#7a8a6a');g.scale.setScalar(1.5);g.rotation.y=Math.atan2(-x,-z)+.6;add(g,x-14,z+14,-1);}}
function moon(){const t=canvasTex(256,256,(c,w,h)=>{const gl=c.createRadialGradient(128,128,70,128,128,128);gl.addColorStop(0,'rgba(255,255,240,.5)');gl.addColorStop(1,'rgba(255,255,240,0)');c.fillStyle=gl;c.fillRect(0,0,w,h);
    const g=c.createRadialGradient(108,104,10,128,128,84);g.addColorStop(0,'#ffffff');g.addColorStop(1,'#d8dce6');c.fillStyle=g;c.beginPath();c.arc(128,128,84,0,6.283);c.fill();
    c.fillStyle='rgba(150,156,176,.45)';[[100,100,16],[150,90,10],[140,150,20],[96,160,9],[170,128,7]].forEach(q=>{c.beginPath();c.arc(q[0],q[1],q[2],0,6.283);c.fill();});});
  const s=new THREE.Sprite(new THREE.SpriteMaterial({map:t,transparent:true,fog:false,depthWrite:false}));W.disp.push(s.material);s.scale.set(80,80,1);s.position.set(-390,96,96);W.ag.add(s);}

const vb=V.build;V.build=function(){vb.apply(this,arguments);
  {const sea=W.ag.children.find(m=>m.isMesh&&m.geometry===G.plane&&m.scale.x===500&&Math.abs(m.position.y+1.4)<.01);if(sea)sea.scale.set(1400,1,1400);}
  meadow();reef();gadget();rescue();number();ninja();dino();moon();};
})();
