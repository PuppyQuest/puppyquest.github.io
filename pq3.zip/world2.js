/* ================================================================
   Seb's Puppy Quest 3: engine extensions for Snowy Summit and
   Coral Reef: island opening, long rectangular areas, skiing,
   swimming, Pup Type gates, bonus treasure, and shared scenery
   builders for snow and sea.
   ================================================================ */
const islOpen=id=>{if(id==='meadow'||state.set.openIsl||(window.XOPEN&&XOPEN()))return true;const IS=islandOf(id),r=(IS&&IS.req)||['meadow'];return r.every(k=>!!state.islDone[k]);};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const areaBox=A=>A.rect||{x1:-A.R,z1:-A.R,x2:A.R,z2:A.R};

/* ----- hedges along the edge of a rectangular area ----- */
function edgeRect(B,skip,c){c=c||'#4f9e46';const per=[[B.x1-.8,B.z1-.8,B.x2+.8,B.z1-.8],[B.x2+.8,B.z1-.8,B.x2+.8,B.z2+.8],[B.x2+.8,B.z2+.8,B.x1-.8,B.z2+.8],[B.x1-.8,B.z2+.8,B.x1-.8,B.z1-.8]];let i=0;
  per.forEach(s=>{const d=Math.hypot(s[2]-s[0],s[3]-s[1]),n=Math.ceil(d/1.1);for(let k=0;k<n;k++,i++){const x=s[0]+(s[2]-s[0])*k/n,z=s[1]+(s[3]-s[1])*k/n;if(skip&&skip(x,z))continue;if(W.exits.some(e=>!e.noArch&&Math.hypot(x-e.x,z-e.z)<3.4))continue;
    const y=gy(x,z),h=1+(i*37%10)/40;I('sph',c,1.35,1.5*h,1.35,x,y+1.1*h,z);if(i%3===0)I('sph',shade(c,.12),.95,.8,.95,x,y+2.3*h,z);}});}
/* move an exit onto the edge of its area */
function snapExit(A,e){if(e.noArch)return;if(!A.rect){const d=Math.hypot(e.x,e.z)||1;e.x=e.x/d*(A.R-.5);e.z=e.z/d*(A.R-.5);return;}
  const B=A.rect,o=[Math.abs(e.x-B.x1),Math.abs(B.x2-e.x),Math.abs(e.z-B.z1),Math.abs(B.z2-e.z)],m=Math.min(...o);
  if(m===o[0])e.x=B.x1+.5;else if(m===o[1])e.x=B.x2-.5;else if(m===o[2])e.z=B.z1+.5;else e.z=B.z2-.5;}

/* ----- Seb's extra kit: a diving helmet, an air tank and a snowboard ----- */
function addKit(){const g=player.grp,u=g.userData;
  const hm=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#bfe8ff',transparent:true,opacity:.35,depthWrite:false}));hm.scale.set(.82,.8,.82);hm.position.set(0,2.75,0);g.add(hm);
  const tank=mk('cyl','#ffd23f',.22,.9,.22,0,1.75,-.45,g);const rim=mk('tor','#c9c2b8',.82,.82,.82,0,2.3,0,g);rim.rotation.x=Math.PI/2;
  u.helmet=[hm,tank,rim];u.helmet.forEach(m=>m.visible=false);if(u.head&&u.tor){u.head.add(hm);hm.position.set(0,.02,0);u.tor.add(tank);tank.position.set(0,.7,-.45);u.tor.add(rim);rim.position.set(0,1.25,0);}
  u.board=mk('box','#3d8fe0',.75,.1,2.4,0,.06,.1,g);u.board.visible=false;g.rotation.order='YXZ';}

/* ================= skiing ================= */
function skiKit(on,board){const u=player.grp.userData;u.skis.forEach(m=>m.visible=on&&!board);u.board.visible=on&&!!board;}
function startSki(){const A=W.area,S=A.ski;if(!S||player.ski)return;const gear=S.board?'snowboard':'skis';
  if(!state.gear[gear]){sfx.oops();say(S.board?'You need the snowboard for this run. Look for it at the Mountain Hut!':'You need skis! Look in the ski hire hut at the Lift Station.');return;}
  hush();player.x=S.start[0];player.z=S.start[1];player.h=0;W.camYaw=0;skiKit(true,S.board);
  player.ski={t:0,v:3,vx:0,passed:0,gates:S.gates.map(g=>({x:g[0],z:g[1],done:false})),lastZ:player.z};sfx.chime();
  say(`${S.board?'Snowboard':'Ski'} time! Steer left and right with your finger. Go between the flags for stars!`);hud();}
function skiUpdate(dt,ix){const P=player,K=P.ski,S=W.area.ski;K.t+=dt;
  K.v+=(S.vmax-K.v)*Math.min(1,dt*.7);K.vx+=(clamp(ix,-1,1)*S.turn-K.vx)*Math.min(1,dt*5);
  const wx=P.x+K.vx*dt,wz=P.z+K.v*dt,r=resolve(wx,wz);
  if(Math.hypot(r[0]-wx,r[1]-wz)>.05){K.v*=.45;K.vx*=-.4;if(W.t-(K.bumpT||0)>.6){K.bumpT=W.t;sfx.oops();floatS(pick(['💨','❄️']),P.x,gy(P.x,P.z)+1.5,P.z,1.6,.8);}}
  P.x=r[0];P.z=r[1];P.h=Math.atan2(K.vx,K.v);P.moving=true;W.camYaw=lerpAng(W.camYaw,0,Math.min(1,dt*3));
  K.gates.forEach(g=>{if(!g.done&&K.lastZ<g.z&&P.z>=g.z){g.done=true;if(Math.abs(P.x-g.x)<3.4){K.passed++;sfx.chime();floatS('⭐',P.x,gy(P.x,P.z)+3,P.z,2);}else sfx.boop();}});K.lastZ=P.z;
  if(Math.floor(K.t*4)!==Math.floor((K.t-dt)*4))hud();
  if(P.z>=S.end){const t=K.t,n=K.passed,tot=K.gates.length;P.ski=null;skiKit(false);state.stars+=n;hud();
    finishAct(S.key,t,`<div style="font-size:110px;line-height:1">${S.board?'🏂':'⛷️'}</div>`,`You finished the ${S.name}!`,()=>{player.x=S.start[0];player.z=S.start[1];startSki();},false,`🚩 ${n} of ${tot} flags (+${n} stars)`);}}
/* build the slalom flags, the start and the lift back up */
function skiFurniture(A){const S=A.ski;
  S.gates.forEach((g,i)=>{const c=i%2?'#e8423a':'#3d8fe0';[-1,1].forEach(s=>{const x=g[0]+s*3.4,y=gy(x,g[1]);I('cyl','#ffffff',.08,2.2,.08,x,y+1.1,g[1]);I('box',c,.08,.9,1,x,y+1.8,g[1]+.5);});});
  const sx=S.start[0],sz=S.start[1]+3,y=gy(sx,sz);I('box','#e8423a',.4,3,.4,sx-4,y+1.5,sz);I('box','#e8423a',.4,3,.4,sx+4,y+1.5,sz);I('box','#e8423a',8.4,.8,.3,sx,y+3.2,sz);
  const st=label(`${S.board?'🏂':'⛷️'} ${S.name}`,7);st.position.set(sx,y+5,sz);W.ag.add(st);
  W.things.push({x:sx,z:S.start[1]-1,r:5,icon:S.board?'🏂':'⛷️',label:S.board?'Snowboard!':'Ski down!',show:()=>!player.ski,act:startSki});
  const bx=S.start[0]+12,bz=S.end+4,by=gy(bx,bz);I('box','#8a8f99',5,3.4,4,bx,by+1.7,bz);I('box','#e8423a',5.4,.6,4.4,bx,by+3.6,bz);const bl=label('🚡 Lift to the top',6);bl.position.set(bx,by+6,bz);W.ag.add(bl);rect(bx-2.5,bz-2,bx+2.5,bz+2);camBlock(bx-2.5,bz-2,bx+2.5,bz+2);
  W.things.push({x:bx-4.5,z:bz,r:4.5,icon:'🚡',label:'Lift up',show:()=>!player.ski,act:()=>{player.lock=true;sfx.chime();fadeTo(()=>{player.x=S.start[0];player.z=S.start[1]-2;player.h=0;W.camYaw=0;player.lock=false;syncFollowers(true);camUpdate(0,true);say('Back at the top!');},['🚡','Up the lift!']);}});
  /* chairlift line down the side of the run */
  const lx=A.rect.x2-6,z1=A.rect.z1+8,z2=A.rect.z2-8;for(let z=z1;z<=z2;z+=40){const y=gy(lx,z);I('cyl','#8a8f99',.35,10,.35,lx,y+5,z);I('box','#8a8f99',3.4,.3,.3,lx,y+10,z);col(lx,z,.6);}
  const chairs=[];for(let i=0;i<8;i++){const c=grp();mk('box','#3d8fe0',1.4,.2,.9,0,0,0,c);mk('box','#3d8fe0',1.4,.9,.2,0,.45,-.4,c);mk('cyl','#5b4636',.05,2.2,.05,0,1.2,0,c);W.ag.add(c);chairs.push({c,k:i/8});}
  W.ticks.push(dt=>chairs.forEach(o=>{o.k=(o.k+dt*.01)%1;const z=z2-(z2-z1)*o.k,x=lx+1.6;o.c.position.set(x,gy(lx,z)+7.6,z);}));}

/* ================= swimming ================= */
function swimY(dt){const P=player,A=W.area,fl=gy(P.x,P.z)+.4;if(P.float)P.vy=Math.min(5.5,(P.vy||0)+16*dt);else P.vy=Math.max(-2.4,(P.vy||0)-(P.vy>0?14:5)*dt);
  P.y+=P.vy*dt;if(P.y<fl){P.y=fl;if(P.vy<0)P.vy=0;}if(P.y>A.swim.top){P.y=A.swim.top;if(P.vy>0)P.vy=0;}}
(function(){const b=$('#floatBtn');if(!b)return;const on=e=>{e.preventDefault();e.stopPropagation();initAudio();player.float=true;b.classList.add('down');},off=()=>{player.float=false;b.classList.remove('down');};
  b.addEventListener('pointerdown',on);['pointerup','pointercancel','pointerleave'].forEach(k=>b.addEventListener(k,off));
  window.addEventListener('keydown',e=>{if(e.code==='KeyE')player.float=true;});window.addEventListener('keyup',e=>{if(e.code==='KeyE')player.float=false;});})();
/* sunbeams, drifting specks, rising bubbles and fish for underwater areas */
function underwater(o){o=o||{};const A=W.area,B=areaBox(A),w=B.x2-B.x1,d=B.z2-B.z1;
  if(o.surface!=null){const s=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#bfeeff',transparent:true,opacity:.55,side:THREE.DoubleSide,depthWrite:false}));s.scale.set(w+200,1,d+200);s.position.y=o.surface;W.ag.add(s);W.disp.push(s.material);}
  const R=seed(A.R*3+7);for(let i=0;i<(o.beams||10);i++){const m=new THREE.Mesh(G.cyl,new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.07,depthWrite:false}));m.scale.set(2+R()*3,40,2+R()*3);m.position.set(B.x1+R()*w,10,B.z1+R()*d);m.rotation.z=.25;W.ag.add(m);W.disp.push(m.material);}
  const n=500,pos=new Float32Array(n*3);for(let i=0;i<n;i++){pos[i*3]=(R()-.5)*60;pos[i*3+1]=R()*16;pos[i*3+2]=(R()-.5)*60;}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));const pts=new THREE.Points(geo,new THREE.PointsMaterial({color:o.speck||'#e8fbff',size:.12,transparent:true,opacity:.7}));W.ag.add(pts);W.disp.push(geo,pts.material);
  let bt=0;W.ticks.push(dt=>{pts.position.set(player.x,gy(player.x,player.z),player.z);pts.rotation.y+=dt*.05;bt-=dt;if(bt<0){bt=.9;floatS('🫧',player.x+(Math.random()-.5)*.6,player.y+3.2,player.z,.7,1.6);}});}
function fishSchool(cx,cy,cz,r,n,emoji,sp){const F=[];for(let i=0;i<n;i++){const s=sprite(emoji||'🐟',1+Math.random()*.6);W.ag.add(s);F.push({s,a:i/n*6.28,o:(Math.random()-.5)*2,h:(Math.random()-.5)*2});}
  W.ticks.push(dt=>F.forEach(f=>{f.a+=dt*(sp||.35);f.s.position.set(cx+Math.cos(f.a)*(r+f.o),cy+f.h+Math.sin(W.t+f.a)*.4,cz+Math.sin(f.a)*(r+f.o));}));}
/* falling snow that follows Seb */
function snowfall(n){const R=seed(99),pos=new Float32Array((n||600)*3);for(let i=0;i<(n||600);i++){pos[i*3]=(R()-.5)*70;pos[i*3+1]=R()*24;pos[i*3+2]=(R()-.5)*70;}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.BufferAttribute(pos,3));const pts=new THREE.Points(geo,new THREE.PointsMaterial({color:'#ffffff',size:.28,transparent:true,opacity:.9}));W.ag.add(pts);W.disp.push(geo,pts.material);
  W.ticks.push(dt=>{const a=geo.attributes.position;for(let i=0;i<a.count;i++){let y=a.getY(i)-dt*2.2;if(y<0)y+=24;a.setY(i,y);a.setX(i,a.getX(i)+Math.sin(W.t+i)*dt*.3);}a.needsUpdate=true;pts.position.set(player.x,player.y-2,player.z);});}

/* ================= Pup Type gates ================= */
/* an exit with gate:{type,key,look,need,done} is blocked until a pup of that type, with Seb, uses its power */
function buildTypeGate(e){const Gt=e.gate,T=TYPES[Gt.type],A=W.area;const base=e.isOpen;e.isOpen=()=>state.set.openAreas||(window.XOPEN&&XOPEN())||(!!state.vines[Gt.key]&&(!e.open||e.open()));
  if(!e.lock)e.lock=Gt.lock||`The way is blocked. A ${T.name} pup could help! Stand by the ${T.icon} sign and tap the button.`;
  const d=Math.hypot(e.x,e.z)||1,ux=-e.x/d,uz=-e.z/d,bx=e.x+ux*1.5,bz=e.z+uz*1.5,blk=grp(),grow=grp();blk.rotation.y=Math.atan2(ux,uz);grow.rotation.y=blk.rotation.y;
  const L=Gt.look||'drift';
  if(L==='drift'){[[0,1.6,0,2.6],[-1.8,1,0,1.8],[1.8,1.1,.2,1.9],[0,3.2,0,1.6]].forEach(q=>mk('sph',q[1]>3?'#ffffff':'#f4f8ff',q[3],q[3]*.8,q[3]*.9,q[0],q[1],q[2],blk));}
  else if(L==='current'){for(let i=0;i<4;i++){const m=new THREE.Mesh(G.tor,new THREE.MeshBasicMaterial({color:'#9be8ff',transparent:true,opacity:.45,depthWrite:false}));m.scale.set(2.4-i*.3,2.4-i*.3,2.4-i*.3);m.position.y=1.5+i*1.1;m.rotation.x=Math.PI/2;blk.add(m);W.disp.push(m.material);}
    W.ticks.push(dt=>{blk.children.forEach((m,i)=>{m.rotation.z+=dt*(2+i);});if(blk.visible&&Math.random()<dt*4)floatS('🫧',bx+(Math.random()-.5)*3,gy(bx,bz)+1,bz,1,1.2);});}
  else if(L==='cliff'){mk('box','#b9c6d6',6,7,1.6,0,3.5,0,blk);mk('box','#e8f4ff',6.2,.6,1.8,0,7,0,blk);for(let i=0;i<6;i++)mk('cyl','#3f9e46',.12,6.5,.12,-2+i*.8,3.3,.9,grow);for(let i=0;i<8;i++)mk('box','#5fbf5a',4.6,.14,.14,0,.7+i*.8,1,grow);}
  else if(GATE_LOOKS[L])GATE_LOOKS[L](blk,grow,bx,bz);
  else if(L==='vent'){mk('cyl','#6b5146',1.6,1.2,1.6,0,.6,0,blk);const gl=new THREE.Mesh(G.sph,new THREE.MeshBasicMaterial({color:'#ff8a3c',transparent:true,opacity:.6,depthWrite:false}));gl.scale.set(1.2,2.4,1.2);gl.position.y=2.4;blk.add(gl);W.disp.push(gl.material);
    W.ticks.push(dt=>{if(blk.visible&&Math.random()<dt*6)floatS(pick(['🫧','🔥']),bx+(Math.random()-.5)*2,gy(bx,bz)+2,bz,1,1.4);});}
  add(blk,bx,bz);add(grow,bx,bz);const done=!!state.vines[Gt.key];blk.visible=!done;grow.scale.set(1,done?1:.001,1);grow.visible=done;
  const tx=e.x+ux*7,tz=e.z+uz*7,sg=label(`${T.icon} ${T.name} power`,5.5);sg.position.set(tx+2.5,gy(tx,tz)+4,tz);W.ag.add(sg);sg.visible=!done;
  W.things.push({x:tx,z:tz,r:4.8,icon:T.icon,label:`${T.name} power`,show:()=>!state.vines[Gt.key],act:()=>typePower(e,blk,grow,sg)});
}
function typeHelper(type){for(const id of teamIds()){const p=pupById(id);if(p&&p.type===type)return p;}return null;}
function typePower(e,blk,grow,sg){const Gt=e.gate,T=TYPES[Gt.type],A=W.area,need=Gt.need!=null?Gt.need:2,n=foundIn(areaPups(A.id).filter(p=>!p.bonus)),hp=typeHelper(Gt.type);
  if(n<need){sfx.oops();say(`Find ${need-n} more ${need-n>1?'pups':'pup'} in ${A.name} first, then a ${T.name} pup can help here!`);return;}
  if(!hp){sfx.oops();say(`You need a ${T.name} pup with you. A ${T.name} pup ${Gt.verb||T.power}! Choose one as your buddy or in your pack in the Pup House.`);return;}
  player.lock=true;hush();const f=followers.find(q=>q.id===hp.id);if(f)f.grp.userData.jump=.6;sfx.yip(hp.pitch);say(`${T.name} power! ${hp.name} ${Gt.verb||T.power}!`);
  grow.visible=true;let k=0;const bp=blk.position;
  W.ticks.push(dt=>{k+=dt/2.2;const e1=Math.min(1,k);blk.scale.setScalar(Math.max(.001,1-e1));grow.scale.y=Math.max(.001,e1);if(Math.random()<.3)floatS(T.icon,bp.x+(Math.random()-.5)*4,bp.y+1.5,bp.z,1.3,1);
    if(k>=1){blk.visible=false;sg.visible=false;state.vines[Gt.key]=true;state.stars+=5;save();hud();sfx.jingle();player.lock=false;say(Gt.done||`Hooray! ${hp.name} opened the way to ${e.name}!`);return true;}});}

/* ================= bonus treasure ================= */
function treasureChest(x,z,key,y){const g=grp();mk('box','#9b6a43',2.2,1.2,1.4,0,.6,0,g);mk('box','#ffd23f',2.3,.2,1.5,0,.9,0,g);const lid=grp();lid.position.set(0,1.2,-.7);g.add(lid);mk('box','#b9814f',2.2,.5,1.4,0,.2,.7,lid);mk('box','#ffd23f',.4,.5,.2,0,.1,1.42,lid);
  add(g,x,z,y);col(x,z,1.4);const opened=!!(state.chests||{})[key];if(opened)lid.rotation.x=-1.2;
  W.things.push({x,z,y:y!=null?y:undefined,r:3.6,icon:'🎁',label:'Treasure',show:()=>!(state.chests||{})[key],act:()=>{state.chests=state.chests||{};state.chests[key]=Date.now();state.stars+=50;save();hud();lid.rotation.x=-1.2;sfx.fanfare();confetti(60);
    card({art:'<div style="font-size:110px;line-height:1">💎</div>',h:'Secret treasure!',p:'You found a hidden treasure chest! Plus 50 stars!'});}});}

/* ================= shared scenery: snow ================= */
function snowPine(x,z,s){s=s||1;const y=gy(x,z);I('cyl','#7a5236',.3*s,2*s,.3*s,x,y+1*s,z);I('cone','#2f7a4a',2*s,3.4*s,2*s,x,y+3.2*s,z);I('cone','#3a8a55',1.5*s,2.8*s,1.5*s,x,y+4.8*s,z);I('cone','#ffffff',.9*s,1.2*s,.9*s,x,y+6.2*s,z);I('sph','#ffffff',1.6*s,.35*s,1.6*s,x,y+2.4*s,z);col(x,z,.8*s);}
function snowRock(x,z,s){s=s||1;const y=gy(x,z);I('sph','#9aa3b0',1.3*s,.9*s,1.1*s,x,y+.4*s,z,0,x%3,0);I('sph','#ffffff',1.1*s,.4*s,.9*s,x,y+1.1*s,z);col(x,z,1.1*s);}
function snowman(x,z,s){s=s||1;const y=gy(x,z);I('sph','#ffffff',1*s,.9*s,1*s,x,y+.9*s,z);I('sph','#ffffff',.7*s,.65*s,.7*s,x,y+2.2*s,z);I('sph','#ffffff',.5*s,.48*s,.5*s,x,y+3.2*s,z);I('cone','#ff8a3c',.1*s,.5*s,.1*s,x,y+3.2*s,z+.6*s,Math.PI/2,0,0);I('cyl','#e8423a',.52*s,.16*s,.52*s,x,y+2.85*s,z);I('cyl','#3a3338',.38*s,.5*s,.38*s,x,y+3.75*s,z);col(x,z,.9*s);}
function chalet(x,z,w,d,c,rot){const y=gy(x,z);I('box',c||'#b9814f',w,4.5,d,x,y+2.25,z,0,rot||0,0);I('pyr','#7a4f2a',w*.82,3,d*.82,x,y+6,z,0,(rot||0)+Math.PI/4,0);I('pyr','#ffffff',w*.84,1,d*.84,x,y+7.2,z,0,(rot||0)+Math.PI/4,0);
  I('box','#5b4636',1.8,3,.3,x,y+1.5,z+d/2+.05);I('box','#ffe27a',1.3,1.3,.2,x-w/4,y+2.8,z+d/2+.05,0,0,0,true);I('box','#ffe27a',1.3,1.3,.2,x+w/4,y+2.8,z+d/2+.05,0,0,0,true);rect(x-w/2,z-d/2,x+w/2,z+d/2);camBlock(x-w/2,z-d/2,x+w/2,z+d/2);}
function penguin3D(){const g=grp();mk('sph','#26232e',.5,.7,.45,0,.75,0,g);mk('sph','#ffffff',.38,.55,.3,0,.7,.2,g);mk('sph','#26232e',.36,.34,.34,0,1.45,0,g);mk('cone','#ffb347',.08,.25,.08,0,1.42,.36,g).rotation.x=Math.PI/2;
  [-1,1].forEach(s=>{mk('sph','#ffffff',.06,.07,.04,s*.12,1.52,.3,g,true);mk('sph','#26232e',.15,.4,.08,s*.48,.8,0,g).rotation.z=s*.4;mk('sph','#ffb347',.14,.06,.2,s*.18,.05,.12,g);});return g;}
function penguinWaddle(list,cx,cz,r){W.ticks.push(dt=>list.forEach((p,i)=>{const a=W.t*.3+i*1.3;const x=cx+Math.cos(a)*r*(.6+.4*Math.sin(i)),z=cz+Math.sin(a)*r*.7;p.position.set(x,gy(x,z),z);p.rotation.y=-a;p.rotation.z=Math.sin(W.t*8+i)*.12;}));}

/* ================= shared scenery: sea ================= */
function coral(x,z,s,c,kind){s=s||1;const y=gy(x,z);c=c||pick(['#ff7f9e','#ffb347','#c78cff','#ff6b6b','#7fd3f0']);
  if(kind==='fan'){I('cyl',shade(c,-.2),.15*s,1.2*s,.15*s,x,y+.6*s,z);I('sph',c,1.6*s,1.4*s,.25*s,x,y+2*s,z,0,x%3,0);}
  else if(kind==='brain'){I('sph',c,1.4*s,.9*s,1.4*s,x,y+.4*s,z);}
  else{for(let i=0;i<5;i++){const a=i*1.25,r=.5*s;I('cyl',c,.22*s,(1.6+i%3*.6)*s,.22*s,x+Math.cos(a)*r,y+(.8+i%3*.3)*s,z+Math.sin(a)*r,Math.sin(a)*.35,0,Math.cos(a)*.35);I('sph',shade(c,.2),.3*s,.3*s,.3*s,x+Math.cos(a)*r*1.6,y+(1.7+i%3*.6)*s,z+Math.sin(a)*r*1.6);}}
  col(x,z,.9*s);}
function kelp(x,z,h,c){h=h||8;const y=gy(x,z),g=grp();for(let i=0;i<Math.round(h/1.2);i++){const m=mk('box',c||'#3f9e46',.5,1.3,.12,Math.sin(i*.7)*.25,.6+i*1.2,0,g);m.rotation.z=Math.sin(i)*.25;}add(g,x,z,y);g.rotation.y=x;
  W.ticks.push(()=>{g.rotation.z=Math.sin(W.t*.9+x*.3)*.08;g.rotation.x=Math.cos(W.t*.7+z*.3)*.06;});col(x,z,.5);return g;}
function seaRock(x,z,s,c){s=s||1;I('sph',c||'#8a7f8f',1.6*s,1.1*s,1.4*s,x,gy(x,z)+.5*s,z,0,x%3,0);col(x,z,1.4*s);}
function shellAt(x,z,c){I('cone',c||'#ffd9e6',.35,.2,.35,x,gy(x,z)+.1,z,0,0,0);}
function sub3D(){const g=grp();mk('sph','#ffd23f',3.4,1.9,1.9,0,0,0,g);mk('cyl','#ffd23f',.8,1.4,.8,.4,1.8,0,g);mk('cyl','#8a8f99',.12,1.2,.12,.6,2.9,0,g);[-1.4,0,1.4].forEach(x=>{mk('cyl','#9bdcff',.42,.2,.42,x,.2,1.8,g).rotation.x=Math.PI/2;});mk('cone','#e8423a',.6,.9,.6,-3.6,0,0,g).rotation.z=Math.PI/2;return g;}
function seaPup(p){return p;}
