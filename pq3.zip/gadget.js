/* ================================================================
   Gadget Island: Region 5 (Sky pups), reached by Seb's home-made
   flying machine. Workshop (start) opens the Factory (after 2 pups)
   and the Light Lab (needs the safety goggles). The Factory leads to
   the Magnet Mine (a Sky pup floats a bridge over the gap), the Light
   Lab to the Launch Range (a code lock). Both lead to the Robot Yard
   (boss). Bonus: the Invention Vault off the Factory, through fog that
   a Star pup from Rescue Bay can shine through.
   ================================================================ */
(function(){
const R=seed(5151),inw=(x,z,f)=>[x*(f||.68),z*(f||.68),Math.atan2(-x,-z)];
const GG={ground:'#9fd87a',ground2:'#b5e290',sky:'#bfe3ff',fog:[70,230],fogC:'#dceefa',hedgeC:'#5b8a4a',biome:'gadget'};
const GA=o=>Object.assign({},GG,o);
function pathTo(x1,z1,x2,z2,w,c){const d=Math.hypot(x2-x1,z2-z1),m=new THREE.Mesh(G.plane,M(c||'#555a62'));m.scale.set(w||5,1,d);m.rotation.y=Math.atan2(x2-x1,z2-z1);m.position.set((x1+x2)/2,gy((x1+x2)/2,(z1+z2)/2)+.07,(z1+z2)/2);W.ag.add(m);
  for(let t=.08;t<1;t+=.14){const x=x1+(x2-x1)*t,z=z1+(z2-z1)*t;I('box','#ffd23f',.5,.04,.12,x,gy(x,z)+.1,z,0,Math.atan2(x2-x1,z2-z1),0);}}
function wanderers(n,mkf,cx,cz,r,sp){for(let i=0;i<n;i++){const g=mkf(i);W.ag.add(g);const o={a:i*2.1,s:(sp||.25)+R()*.1};W.ticks.push(dt=>{o.a+=dt*o.s;const x=cx+Math.cos(o.a)*r,z=cz+Math.sin(o.a)*r*.8;g.position.set(x,gy(x,z),z);g.rotation.y=Math.atan2(-Math.sin(o.a),Math.cos(o.a)*.8);});}}
function bench(x,z,tools){const y=gy(x,z);I('box','#9b6a43',4,.3,1.8,x,y+1.4,z);[[-1.8,-.7],[1.8,-.7],[-1.8,.7],[1.8,.7]].forEach(q=>I('box','#5b4636',.2,1.4,.2,x+q[0],y+.7,z+q[1]));(tools||['🔧','🔨','🪛']).forEach((e,i)=>spr(e,.8,x-1.2+i*1.2,y+1.9,z));col(x,z,1.8);}
function pipeRun(x1,z1,x2,z2,h,c){const d=Math.hypot(x2-x1,z2-z1);I('cyl',c||'#8a8f99',.5,d,.5,(x1+x2)/2,gy(x1,z1)+h,(z1+z2)/2,Math.PI/2,Math.atan2(x2-x1,z2-z1)-Math.PI/2,0);
  [[x1,z1],[x2,z2]].forEach(p=>{I('cyl',c||'#8a8f99',.4,h,.4,p[0],gy(p[0],p[1])+h/2,p[1]);col(p[0],p[1],.5);});}
function chimney(x,z,h){const y=gy(x,z);I('cyl','#b35a3a',1,h,1,x,y+h/2,z);for(let i=0;i<3;i++)I('cyl','#ffffff',1.05,.3,1.05,x,y+h*.4+i*h*.2,z);let t=0;W.ticks.push(dt=>{t-=dt;if(t<0){t=.7;floatS('💨',x,y+h+.5,z,2,2.6);}});col(x,z,1.1);}
function crystalCluster(x,z,c){const y=gy(x,z);for(let k=0;k<4;k++)I('cone',c||pick(['#9be8ff','#c9b6ff','#7fffe0']),.4,1.4+k*.5,.4,x+(k-1.5)*.5,y+.7+k*.25,z+(k%2)*.4,0,0,(k-1.5)*.25,true);col(x,z,1);}
function landingPad(x,z){const y=gy(x,z);I('cyl','#c9905f',4.2,.5,4.2,x,y+.25,z);I('cyl','#3fae5a',3.6,.06,3.6,x,y+.52,z);spr('✈️',1.2,x,y+.9,z);const fm=flyMachine3D();add(fm,x+5.5,z+1,y+.2+.3);fm.rotation.y=-.6;W.ticks.push(()=>{fm.userData.tick(W.t);fm.position.y=y+.5+Math.sin(W.t*2)*.15;});col(x+5.5,z+1,1.8);
  const l=label('✈️ Flying machine home',6.5);l.position.set(x+5.5,y+7,z+1);W.ag.add(l);W.things.push({x,z:z-3,r:4.6,icon:'✈️',label:'Go home',act:goHome});}

/* ----------------- the 12 Sky pups ----------------- */
const P=[
 {id:'sprocket',name:'Sprocket',breed:'Wire Fox Terrier',area:'workshop',pitch:1.2,spot:{x:-24,z:-24,kind:'crate'},hint:'Look in a crate behind the Workshop.',
  fact:'Wire Fox Terriers have wiry coats and boundless energy. They love to dig, explore and solve puzzles!',rescue:{icon:'🔧',verb:'Untangle',say:'Sprocket is tangled in a bundle of wires! Tap to untangle them!'},
  look:{fur:'#ffffff',ear:'#c8843a',ears:'side',muzzle:'#ffffff',belly:'#ffffff',patch:'#c8843a',fluffy:true,tail:'stub',acc:['cap']}},
 {id:'widget',name:'Widget',breed:'Chihuahua',area:'workshop',pitch:1.6,spot:{x:22,z:22,kind:'toybox'},tag:{x:-30,z:22,kind:'crate'},hint:'Widget plays tag. Look in the toy box by the shed, then in a crate.',
  fact:'Chihuahuas are the smallest dogs in the world, but they have very big personalities!',rescue:{icon:'🔩',verb:'Lift',say:'Widget is stuck under a pile of bolts! Tap to lift them off!'},
  look:{fur:'#e8c79a',ear:'#e8c79a',ears:'pointy',earBig:true,muzzle:'#f2dcb8',belly:'#f2dcb8',tail:'curl',scale:.75,eyeWhite:true,acc:['scarf'],scarfC:'#ffd23f'}},
 {id:'dynamo',name:'Dynamo',breed:'Basenji',area:'factory',pitch:1.1,spot:{x:-22,z:16,kind:'crate'},hint:'Look in a crate by the conveyor belts in the Factory.',
  fact:'Basenjis do not bark! They make a funny yodelling sound instead, and they clean themselves like cats.',rescue:{icon:'📦',verb:'Unpack',say:'Dynamo got packed into a box on the conveyor belt! Tap to unpack Dynamo!'},
  look:{fur:'#c8642a',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',face:'#ffffff',faceLow:true,paw:'#ffffff',tail:'curl',acc:['cap']}},
 {id:'pixel',name:'Pixel',breed:'Pomeranian',area:'factory',pitch:1.5,spot:{x:24,z:-6,kind:'toybox'},tag:{x:-24,z:-24,kind:'crate'},hint:'Pixel plays tag. Look in the toy box by the big pipes, then in a crate.',
  fact:'Pomeranians are tiny fluffballs with fox-like faces. They were once much bigger sled dogs!',rescue:{icon:'💨',verb:'Fan',say:'Pixel is fluffed up by the steam! Tap to fan Pixel dry!'},
  look:{fur:'#e8903a',ears:'pointy',fluffy:true,muzzle:'#e8903a',belly:'#f2b060',tail:'plume',scale:.75,acc:['bow']}},
 {id:'turbo',name:'Turbo',breed:'Vizsla',area:'mine',pitch:1,spot:{x:22,z:14,kind:'minecart'},hint:'Look in a minecart in the Magnet Mine.',
  fact:'Vizslas are speedy golden-red dogs from Hungary. They are called velcro dogs because they love to stay close to their people!',rescue:{icon:'🧲',verb:'Unstick',say:'Turbo\'s collar is stuck to a giant magnet! Tap to pull Turbo free!'},
  look:{fur:'#c8743a',ear:'#b8642a',ears:'floppy',muzzle:'#c8743a',belly:'#d8844a',tail:'thin',acc:['scarf'],scarfC:'#3d8fe0'}},
 {id:'coil',name:'Coil',breed:'Puli',area:'mine',pitch:.95,spot:{x:-20,z:-12,kind:'crystal'},tag:{x:-14,z:28,kind:'boulder'},hint:'Coil plays tag. Look by the glowing crystals, then behind a rock.',
  fact:'Pulis have long cords of fur, like a mop! They were sheepdogs in Hungary for over a thousand years.',rescue:{icon:'🧹',verb:'Comb',say:'Coil\'s cords are full of mine dust! Tap to shake it out!'},
  look:{fur:'#3a3338',ears:'floppy',fluffy:true,wool:true,fringe:'#3a3338',muzzle:'#3a3338',belly:'#4a4248',tail:'plume',acc:['cap']}},
 {id:'zap',name:'Zap',breed:'Yorkshire Terrier',area:'lightlab',pitch:1.55,spot:{x:-22,z:10,kind:'books'},hint:'Look by the pile of books in the Light Lab.',
  fact:'Yorkshire Terriers are tiny dogs with long silky coats. Long ago they caught mice in clothes mills!',rescue:{icon:'🪞',verb:'Turn',say:'Zap is dazzled by a mirror! Tap to turn the mirror away!'},
  look:{fur:'#3a4a5a',ear:'#c8944a',ears:'pointy',fluffy:true,fringe:'#c8944a',muzzle:'#c8944a',belly:'#3a4a5a',tail:'stub',scale:.75,acc:['bow']}},
 {id:'fuse',name:'Fuse',breed:'Brussels Griffon',area:'lightlab',pitch:1.3,spot:{x:22,z:-10,kind:'satellite'},tag:{x:-12,z:30,kind:'schoolbag'},hint:'Fuse plays tag. Look by the satellite dish, then by a school bag.',
  fact:'Brussels Griffons have big eyes and bushy beards. They look a bit like little wise old men!',rescue:{icon:'💡',verb:'Switch',say:'Fuse switched off all the lights and cannot see! Tap to switch them back on!'},
  look:{fur:'#a0582a',ears:'side',muzzle:'#7a4020',muzzleBig:true,fringe:'#a0582a',belly:'#a0582a',tail:'stub',scale:.8,eyeWhite:true,acc:['scarf'],scarfC:'#ff9ecb'}},
 {id:'cog',name:'Cog',breed:'Cairn Terrier',area:'launch',pitch:1.25,spot:{x:-22,z:14,kind:'crater'},hint:'Look in a crater at the Launch Range.',
  fact:'Cairn Terriers come from the Scottish Highlands. They are brave, scruffy and full of fun!',rescue:{icon:'🚀',verb:'Dust',say:'Cog is covered in rocket smoke! Tap to dust Cog off!'},
  look:{fur:'#c8a070',ears:'pointy',fluffy:true,muzzle:'#a8805a',belly:'#d8b080',tail:'thin',acc:['cap']}},
 {id:'nano',name:'Nano',breed:'Affenpinscher',area:'launch',pitch:1.45,spot:{x:20,z:-4,kind:'pod'},tag:{x:-24,z:-22,kind:'meteor'},hint:'Nano plays tag. Look in the space pod, then behind a space rock.',
  fact:'Affenpinschers are little dogs with monkey-like faces. Their name means monkey terrier in German!',rescue:{icon:'🧑‍🚀',verb:'Unzip',say:'Nano is zipped up in a tiny space suit! Tap to unzip it!'},
  look:{fur:'#26232e',ears:'pointy',fluffy:true,muzzle:'#26232e',muzzleBig:true,belly:'#3a3338',tail:'stub',scale:.75,eyeWhite:true,acc:['scarf'],scarfC:'#e8423a'}},
 {id:'rivet',name:'Rivet',breed:'Airedale Terrier',area:'robotyard',pitch:.95,spot:{x:-22,z:6,kind:'crate'},hint:'Look in a crate by the robot charging dock.',
  fact:'Airedales are the biggest terriers, and they are called the King of Terriers. They are clever and brave.',rescue:{icon:'🤖',verb:'Wave',say:'A little robot is guarding Rivet! Tap to wave hello so it rolls away!'},
  look:{fur:'#c8843a',ears:'floppy',fluffy:true,muzzle:'#c8843a',belly:'#c8843a',bodyPatch:'#26232e',tail:'stub',acc:['cap']}},
 {id:'spanner',name:'Spanner',breed:'French Bulldog',area:'robotyard',pitch:1.15,spot:{x:22,z:12,kind:'toybox'},tag:{x:-16,z:26,kind:'bucket'},hint:'Spanner plays tag. Look in the toy box by the scrap pile, then by a bucket.',
  fact:'French Bulldogs have big bat ears and love to snuggle. They snore very loudly!',rescue:{icon:'🔧',verb:'Tighten',say:'Spanner is wobbling on a loose bolt! Tap to tighten it!'},
  look:{fur:'#e8d0a8',ear:'#e8d0a8',ears:'pointy',earBig:true,muzzle:'#c8a880',wrinkle:true,belly:'#f2e0c0',tail:'stub',scale:.85,acc:['scarf'],scarfC:'#3fae5a'}}];
const CHROME={id:'chrome',name:'Chrome',breed:'Kerry Blue Terrier',area:'vault',pitch:1.1,spot:{x:-10,z:-8,kind:'satellite'},hint:'A sparkly pup is hiding in the Invention Vault.',
  fact:'Chrome is a sparkly pup! Kerry Blue Terriers are born black and turn a lovely silvery blue as they grow. You found a secret pup!',rescue:{icon:'✨',verb:'Polish',say:'Chrome is hiding behind a shiny invention! Tap to polish it!'},
  look:{fur:'#7d8ea8',ears:'floppy',fluffy:true,wool:true,muzzle:'#8a9ab0',belly:'#8a9ab0',tail:'stub',acc:['twinkle','cap']}};
const GIZMO={id:'gizmouni',name:'Gizmo',breed:'Gadget Unicorn',uni:true,lv:1,pitch:1.2,fact:'Gizmo the Gadget Unicorn helps inventors fix things that are broken.',
  look:{fur:'#e6ecf5',ears:'side',earIn:'#c9d6e6',muzzle:'#ffffff',belly:'#ffffff',nose:'#8a9ab0',iris:'#3d8fe0',limbs:'hooves',hoofC:'#c9a86a',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','twinkle'],scale:.96}};
const TINK_SAY=['Tinker says: beep boop! Safety goggles first! They are on the workbench.','Tinker says: Sky pups can float a bridge across a gap. Bring one with you!','Tinker says: the Launch Range door has a code. You are good at sums!','Tinker says: there is a foggy door in the Factory. A Star pup from Rescue Bay could shine through it.','Tinker says: Gizmo the Gadget Unicorn is in the Robot Yard.','Tinker says: beep! Have you tried Gear Grab? Find all 6 gears!'];

/* ----------------- areas ----------------- */
const workshop=GA({id:'workshop',name:'Workshop',icon:'🔧',R:52,start:[0,36,Math.PI],
  hf:(x,z)=>Math.sin(x*.07)*.4+Math.cos(z*.06)*.4,
  hello:'Welcome to Gadget Island! Two pups are hiding in the Workshop. Say hello to Tinker the robot!',how:'Fly Seb\'s home-made flying machine from the village.',
  exits:[{x:-38,z:-34,to:'factory',arrive:inw(36,36),name:'Factory',icon:'🏭',open:()=>foundIn(areaPups('workshop'))>=2,lock:()=>{const n=foundIn(areaPups('workshop'));return `The Factory gate is locked. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Workshop to open it!`;}},
         {x:38,z:-34,to:'lightlab',arrive:inw(-36,34),name:'Light Lab',icon:'💡',open:()=>!!state.gear.goggles,lock:'The Light Lab is very bright! You need safety goggles first. Look on the workbench.'}],
  build(){landingPad(0,44);pathTo(0,40,0,-2,4.5);pathTo(-2,-4,-34,-30,4);pathTo(2,-4,34,-30,4);
    house(0,-18,{w:16,d:10,h:6,wall:'#e6dccf',roof:'#8a8f99',trim:'#ffd23f',win:3,label:'🔧 Workshop',lw:6});for(let i=0;i<4;i++)I('pyr','#a8b0bc',4,1.6,10.4,-6+i*4,gy(0,-18)+7.4,-18,0,0,0);
    bench(-10,4,['🔧','🔨','🪛']);bench(10,4,['⚙️','📐','🔩']);gearSpin(-15,4,-6,2.4,'#c9a86a',0,.5);gearSpin(-12.2,5.6,-6,1.4,'#8a8f99',0,-.86);col(-14,-6,2.2);
    {const g=robot3D('#7fc8f0',1);add(g,5,-4);col(5,-4,1);const l=label('🤖 Tinker',4);l.position.set(5,gy(5,-4)+5.4,-4);W.ag.add(l);let k=0;W.ticks.push(()=>{g.rotation.y=Math.atan2(player.x-5,player.z+4);g.position.y=gy(5,-4)+Math.abs(Math.sin(W.t*3))*.08;});
      W.things.push({x:5,z:-4,r:4,icon:'💬',label:'Tinker',act:()=>{sfx.chime();say(state.gear.goggles?TINK_SAY[(k++)%TINK_SAY.length]:TINK_SAY[0]);}});}
    {const gx=10,gz=4,y=gy(gx,gz);const gog=grp();[-.35,.35].forEach(q=>{mk('tor','#3a3338',.3,.3,.3,q,0,0,gog);mk('cyl','#9bdcff',.25,.05,.25,q,0,0,gog).rotation.x=Math.PI/2;});mk('box','#e8423a',1.6,.12,.05,0,0,-.1,gog);add(gog,gx+.2,gz+.2,y+2.4);gog.visible=!state.gear.goggles;W.ticks.push(()=>{gog.rotation.y+=.03;});
      W.things.push({x:gx,z:gz+2.2,r:3.4,icon:'🥽',label:'Goggles',show:()=>!state.gear.goggles,act:()=>{state.gear.goggles=true;state.stars+=5;save();hud();gog.visible=false;sfx.jingle();confetti(30);card({art:'<div style="font-size:110px;line-height:1">🥽</div>',h:'You found safety goggles!',p:'Now you can visit the Light Lab. Its arch is on the right of the Workshop!'});}});}
    house(-30,10,{w:7,d:6,wall:'#c9e6ff',roof:'#5b8def',face:'e'});house(30,16,{w:7,d:6,wall:'#fff2b8',roof:'#e8423a',face:'w'});crane(24,-6,-.6);
    sign(-16,16,'⚙️ Gear Grab',3,6);W.things.push({x:-15,z:13,r:4,icon:'⚙️',label:'Gear Grab',act:()=>{sfx.chime();startCollect('parts');}});
    wanderers(2,i=>{const g=robot3D(['#ffd23f','#ff9ecb'][i],.45);return g;},0,14,8,.35);
    [[-20,-4],[16,-10],[-8,23],[11,25]].forEach(p=>{const y=gy(p[0],p[1]);I('cyl','#26232e',.8,.5,.8,p[0],y+.25,p[1]);I('tor','#26232e',.8,.8,.8,p[0],y+.5,p[1],Math.PI/2,0,0);col(p[0],p[1],1);});
    edgeTrees(52,[angOf(-38,-34),angOf(38,-34),90],['#5fbf5a','#7fcf6a'],null,R);}});

const factory=GA({id:'factory',name:'Factory',icon:'🏭',R:50,start:inw(36,36),ground:'#b7bcc9',ground2:'#c9c2b8',sky:'#d9e4ef',
  hf:(x,z)=>Math.sin(x*.05)*.3,hello:'The Factory! Conveyor belts carry parts round and round, and the chimneys puff steam. Two pups are hiding here.',how:'Find 2 pups at the Workshop.',
  exits:[{x:36,z:36,to:'workshop',arrive:inw(-38,-34),name:'Workshop',icon:'🔧'},
    {x:0,z:-50,to:'mine',arrive:inw(0,48),name:'Magnet Mine',icon:'🧲',gate:{type:'sky',key:'mine_gap',look:'gap',verb:'floats a bridge across the gap',done:'Whoosh! The bridge floats across the gap on balloons. The Magnet Mine is this way!'},lock:'There is a big gap in the bridge to the Magnet Mine. A Sky pup could float a bridge across!'},
    {x:-50,z:0,to:'vault',arrive:inw(30,0,.7),name:'Invention Vault',icon:'🗄️',gate:{type:'star',key:'vault_fog',look:'fog',need:0,verb:'shines a way through the fog',done:'The fog clears! The Invention Vault is open!'},lock:'Thick fog hides the Invention Vault. A Star pup from Rescue Bay could shine the way!'}],
  build(){pathTo(30,30,0,0,5);pathTo(0,0,0,-42,5);pathTo(0,0,-42,0,5);
    house(0,-22,{w:18,d:10,h:7,wall:'#c9b6a0',roof:'#5b6378',trim:'#ffd23f',win:4,chimney:false,label:'🏭 Factory',lw:6});chimney(-6,-28,14);chimney(6,-28,12);
    conveyor(-14,4,14,0);conveyor(14,6,14,0);conveyor(-6,18,12,Math.PI/2);pipeRun(18,-12,30,-2,4,'#3d8fe0');pipeRun(-28,-14,-18,-6,3.4,'#e8423a');
    for(let i=0;i<3;i++){const x=-28+i*2.2,z=-26;I('box','#c9905f',2,2,2,x,gy(x,z)+1+(i%2)*0,z);}rect(-29.5,-27.5,-22.5,-24.5);
    {const px=18,pz=18,y=gy(px,pz);I('box','#5b6378',3,2,1.4,px,y+1,pz);for(let i=0;i<6;i++)I('cyl',['#ff6b6b','#8fe39a','#ffd23f'][i%3],.15,.1,.15,px-1+(i%3)*1,y+2.05,pz-.3+Math.floor(i/3)*.6,0,0,0,true);col(px,pz,1.6);}
    sign(-4,12,'🔩 Bolt Catch',3,6);W.things.push({x:-3,z:10,r:4,icon:'🔩',label:'Bolt Catch',act:()=>{sfx.chime();startFlies('activity','bolts');}});
    wanderers(3,i=>robot3D(['#8a8f99','#7fc8f0','#ffd23f'][i],.5),0,-6,14,.3);
    edgeTrees(50,[angOf(36,36),270,180],['#5f8a4a','#7f9a6a'],null,R);}});

const mine=GA({id:'mine',name:'Magnet Mine',icon:'🧲',R:50,start:inw(0,48),ground:'#8a6a50',ground2:'#9b7a5a',sky:'#9ab0c8',fog:[40,160],fogC:'#7a8aa0',hedgeC:'#5b4636',
  hf:(x,z)=>Math.sin(x*.09)*.8+Math.cos(z*.08)*.7,hello:'The Magnet Mine! Giant magnets pull the minecarts along the rails. Two pups are hiding here.',how:'A Sky pup floats a bridge across the gap in the Factory.',
  exits:[{x:0,z:50,to:'factory',arrive:inw(0,-50),name:'Factory',icon:'🏭'},
    {x:36,z:-34,to:'robotyard',arrive:inw(-38,30),name:'Robot Yard',icon:'🤖',open:()=>foundIn(areaPups('mine'))>=2,lock:()=>{const n=foundIn(areaPups('mine'));return `The mine lift is stuck. Find ${2-n} more ${2-n>1?'pups':'pup'} in the Magnet Mine to fix it!`;}}],
  build(){{const y=gy(0,-30);I('hemi','#6b5146',14,10,10,0,y-1,-34);I('box','#1a1418',7,6,1,0,y+3,-25.2);[-3.6,3.6].forEach(s=>I('box','#9b6a43',.6,7,.6,s,y+3.5,-25));I('box','#9b6a43',8,.6,.6,0,y+7,-25);rect(-14,-44,14,-26);camBlock(-14,-44,14,-26);
      const l=label('⛏️ Magnet Mine',6);l.position.set(0,y+11,-30);W.ag.add(l);}
    for(let z=-24;z<=30;z+=1.4)I('box','#5b4636',2.6,.15,.4,-12,gy(-12,z)+.08,z);[-1,1].forEach(q=>I('box','#8a8f99',.12,.12,54,-12+q*.8,gy(-12,0)+.2,3));
    {const cart=grp();mk('box','#8a8f99',1.8,1,2.4,0,.9,0,cart);mk('box','#5b4636',1.6,.3,2.2,0,1.3,0,cart);for(let i=0;i<4;i++)mk('sph',['#9be8ff','#c9b6ff','#ffd23f','#7fffe0'][i],.3,.3,.3,-.4+(i%2)*.8,1.5,-.5+Math.floor(i/2),cart);add(cart,-12,0);W.ticks.push(()=>{const z=-20+((W.t*4)%48);cart.position.set(-12,gy(-12,z),z);});}
    {const mx=14,mz=-14,y=gy(mx,mz),g=grp();mk('tor','#e8423a',2,2,3,0,5,0,g);[-1,1].forEach(q=>{mk('box','#e8423a',1,3,1.4,q*2,3,0,g);mk('box','#c9c2b8',1.05,.8,1.45,q*2,1.4,0,g);});add(g,mx,mz,y);col(mx-2,mz,.9);col(mx+2,mz,.9);for(let i=0;i<3;i++){const s=sprite('📎',.8);W.ag.add(s);W.ticks.push(()=>s.position.set(mx-2+i*2,y+1+Math.abs(Math.sin(W.t*2+i))*.5,mz+1.2));}}
    [[-24,-10],[26,10],[-26,24],[24,-28],[8,22],[-6,-16]].forEach(p=>crystalCluster(p[0],p[1]));
    [[-6,8],[6,-4],[18,26],[-28,4]].forEach(p=>{const y=gy(p[0],p[1]);I('cyl','#5b4636',.12,2.6,.12,p[0],y+1.3,p[1]);I('box','#fff27a',.5,.6,.5,p[0],y+2.8,p[1],0,0,0,true);col(p[0],p[1],.3);});
    sign(4,12,'🛤️ Minecart Count',3,6);W.things.push({x:5,z:10,r:4,icon:'🛤️',label:'Minecart Count',act:()=>{sfx.chime();startStones('activity','carts');}});
    for(let a=0;a<360;a+=7){if(Math.abs(((a-90+540)%360)-180)<11||Math.abs(((a-angOf(36,-34)+540)%360)-180)<11)continue;const an=a*D2R,r=54+R()*5,y=gy(Math.cos(an)*r,Math.sin(an)*r);I('pyr',pick(['#6b5146','#5b4636','#7a5a46']),3+R()*2,6+R()*5,3+R()*2,Math.cos(an)*r,y+3,Math.sin(an)*r,0,R()*3,0);}}});

const lightlab=GA({id:'lightlab',name:'Light Lab',icon:'💡',R:50,start:inw(-36,34),ground:'#e8f0e0',ground2:'#d8e8d0',sky:'#d9f0ff',
  hf:(x,z)=>Math.sin(x*.06)*.3+Math.cos(z*.06)*.3,hello:'The Light Lab! Mirrors bounce the light and a giant prism makes rainbows. Two pups are hiding here.',how:'Put on the safety goggles from the Workshop.',
  exits:[{x:-36,z:34,to:'workshop',arrive:inw(38,-34),name:'Workshop',icon:'🔧'},
    {x:0,z:-50,to:'launch',arrive:inw(0,48),name:'Launch Range',icon:'🚀',nlock:{key:'nl_launch',kind:['add','times','take'],n:3,done:'Beep beep! The code is right and the door to the Launch Range slides open!'}}],
  build(){house(0,-18,{w:14,d:10,h:5,wall:'#ffffff',roof:'#7fc8f0',trim:'#3d8fe0',win:3,chimney:false,label:'💡 Light Lab',lw:6});I('hemi','#c9d6e6',3.4,3,3.4,0,gy(0,-18)+8.4,-18);
    {const px=-12,pz=2,y=gy(px,pz);I('box','#c9c2b8',2,1,2,px,y+.5,pz);I('pyr','#e8f6ff',1.6,2.6,1.6,px,y+2.3,pz,0,0,0,true);['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff'].forEach((c,i)=>{const b=new THREE.Mesh(G.box,new THREE.MeshBasicMaterial({color:c}));b.scale.set(9,.25,.25);b.position.set(px+5.5,y+2.2+i*.22,pz+i*.35);b.rotation.y=-.3;W.ag.add(b);W.disp.push(b.material);});
      const w=new THREE.Mesh(G.box,new THREE.MeshBasicMaterial({color:'#ffffff'}));w.scale.set(8,.35,.35);w.position.set(px-5,y+2.3,pz);W.ag.add(w);W.disp.push(w.material);col(px,pz,1.4);}
    [[10,8,.6],[18,-2,-.4],[-22,-6,.9],[22,20,-.8]].forEach(m=>{const y=gy(m[0],m[1]);I('cyl','#8a8f99',.1,1.6,.1,m[0],y+.8,m[1]);I('box','#c9d6e6',1.8,1.8,.15,m[0],y+2.4,m[1],0,m[2],0);I('box','#ffffff',1.6,1.6,.17,m[0],y+2.4,m[1],0,m[2],0,true);col(m[0],m[1],.6);});
    [[-26,14],[-20,22],[26,-20]].forEach(p=>{const y=gy(p[0],p[1]);I('box','#2a3a5a',3,.1,2,p[0],y+1.4,p[1],-.4,0,0);I('cyl','#8a8f99',.1,1.4,.1,p[0],y+.7,p[1]);col(p[0],p[1],1.4);});
    sign(6,8,'🌈 Colour Quiz',3,6);W.things.push({x:6,z:5,r:4,icon:'🌈',label:'Colour Quiz',act:()=>{sfx.chime();startQuiz('activity','colours');}});
    edgeTrees(50,[angOf(-36,34),270],['#5fbf5a','#7fcf6a','#ffb7d5'],null,R);}});

const launch=GA({id:'launch',name:'Launch Range',icon:'🚀',R:50,start:inw(0,48),ground:'#c9c2a8',ground2:'#d8d0b8',sky:'#a9d8ff',
  hf:(x,z)=>Math.sin(x*.05)*.2,hello:'The Launch Range! Rockets stand ready on their pads. Two pups are hiding here. Can you count down for blast off?',how:'Crack the code lock in the Light Lab.',
  exits:[{x:0,z:50,to:'lightlab',arrive:inw(0,-50),name:'Light Lab',icon:'💡'},
    {x:-36,z:-34,to:'robotyard',arrive:inw(38,30),name:'Robot Yard',icon:'🤖',open:()=>foundIn(areaPups('launch'))>=2,lock:()=>{const n=foundIn(areaPups('launch'));return `The gate to the Robot Yard is locked. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Launch Range to open it!`;}}],
  build(){[[-14,-20,'#e8423a',1.2],[0,-26,'#3d8fe0',1.5],[14,-20,'#3fae5a',1.1]].forEach(r=>{const y=gy(r[0],r[1]);I('cyl','#8a8f99',3,.6,3,r[0],y+.3,r[1]);const g=rocket3D(r[2],r[3]);add(g,r[0],r[1],y+.6);col(r[0],r[1],2.4);
      [-1,1].forEach(q=>{I('box','#8a8f99',.3,6*r[3],.3,r[0]+q*2,y+3*r[3],r[1]);});});
    {const tx=24,tz=10,H=house(tx,tz,{w:7,d:6,h:4,wall:'#e6ecf5',roof:'#5b6378',face:'w',label:'🎛️ Control',lw:4.6});I('box','#9bdcff',6,1.2,.1,tx-3.55,H.y+3,tz,0,Math.PI/2,0);}
    {const bx=-6,bz=6,y=gy(bx,bz);I('box','#26232e',6,3,.3,bx,y+3,bz);[-2.6,2.6].forEach(q=>I('cyl','#8a8f99',.12,3,.12,bx+q,y+1.5,bz));const l=label('10 9 8 7 6 5 4 3 2 1 🚀',5.6,'#26232e','#7fffe0');l.position.set(bx,y+3,bz+.2);W.ag.add(l);col(bx,bz,.5);}
    {const wx=-24,wz=16,y=gy(wx,wz);I('cyl','#8a8f99',.1,5,.1,wx,y+2.5,wz);const ws=grp();for(let i=0;i<4;i++)mk('cone',i%2?'#ffffff':'#ff8a3c',.45-i*.08,1,.45-i*.08,0,0,.9+i*.9,ws).rotation.x=Math.PI/2;add(ws,wx,wz,y+5);W.ticks.push(()=>{ws.rotation.y=Math.sin(W.t*.5)*.6;});col(wx,wz,.3);}
    [[-26,-4],[22,-30],[28,24]].forEach(p=>{const y=gy(p[0],p[1]);I('cyl','#a8a090',2,.2,2,p[0],y+.05,p[1]);I('tor','#8a8070',2,2,.8,p[0],y+.1,p[1],Math.PI/2,0,0);});
    sign(6,14,'🚀 Rocket Countdown',3,7);W.things.push({x:7,z:11,r:4,icon:'🚀',label:'Countdown',act:()=>{sfx.chime();startStones('activity','countdown');}});
    edgeTrees(50,[90,angOf(-36,-34)],['#5fbf5a','#7fcf6a'],null,R);}});

const robotyard=GA({id:'robotyard',name:'Robot Yard',icon:'🤖',R:48,start:inw(-38,30),ground:'#a8b0a0',ground2:'#b8c0b0',
  hf:(x,z)=>3*Math.exp(-(x*x+(z+18)*(z+18))/500)+Math.sin(x*.1)*.3,hello:'The Robot Yard! Friendly robots are charging up for the night. Two pups are hiding here.',how:'Find 2 pups in the Magnet Mine or at the Launch Range.',
  exits:[{x:-38,z:30,to:'mine',arrive:inw(36,-34),name:'Magnet Mine',icon:'🧲'},{x:38,z:30,to:'launch',arrive:inw(-36,-34),name:'Launch Range',icon:'🚀'}],
  build(){{const g=robot3D('#7fc8f0',4);add(g,0,-32);g.rotation.y=0;col(0,-32,4);const l=label('🤖 Mega Bot',6);l.position.set(0,gy(0,-32)+18,-32);W.ag.add(l);}
    {const px=-22,pz=-6;fence(px-6,pz-5,px+6,pz-5,'#ffd23f');fence(px-6,pz+5,px+6,pz+5,'#ffd23f');fence(px-6,pz-5,px-6,pz+5,'#ffd23f');spr('🔋',1.6,px,gy(px,pz)+2,pz);sign(px+8,pz+6,'🤖 Robot Round-up',3,7);W.things.push({x:px+8,z:pz+3,r:4,icon:'🤖',label:'Robot Round-up',act:()=>{sfx.chime();startHerd('activity','robots');}});}
    [[20,-8],[26,4],[-30,-16]].forEach(p=>{const y=gy(p[0],p[1]);for(let i=0;i<6;i++)I(pick(['box','cyl','sph']),pick(['#8a8f99','#c9c2b8','#5b6378','#c97a3e']),1+R(),1+R(),1+R(),p[0]+(R()-.5)*3,y+.5+i*.4,p[1]+(R()-.5)*3,R(),R(),R());col(p[0],p[1],2.4);});
    crane(30,-20,.8);wanderers(4,i=>robot3D(['#ffd23f','#ff9ecb','#8fe39a','#c9b6ff'][i],.5),0,8,12,.3);
    edgeTrees(48,[angOf(-38,30),angOf(38,30)],['#5f8a4a','#7f9a6a'],null,R);}});

const vault={id:'vault',name:'Invention Vault',icon:'🗄️',R:32,ground:'#5b6378',ground2:'#6b7388',sky:'#2a3040',fog:[30,110],fogC:'#3a4258',hedgeC:'#8a8f99',noEnrich:true,start:inw(30,0,.7),hf:()=>0,
  hello:'The Invention Vault! Every amazing invention is kept here. A secret sparkly pup and a treasure chest are hidden inside!',how:'A Star pup from Rescue Bay shines through the fog in the Factory.',
  exits:[{x:32,z:0,to:'factory',arrive:inw(-50,0,.85),name:'Factory',icon:'🏭'}],
  build(){const dome=new THREE.Mesh(G.hemi,new THREE.MeshLambertMaterial({color:'#8a8f99',side:THREE.BackSide}));dome.scale.set(36,18,36);W.ag.add(dome);W.disp.push(dome.material);
    [['💡',-14,-14],['📞',-18,4],['✈️',-10,18],['🔭',6,20],['⚙️',14,-18],['🤖',4,-22],['🚲',-22,-4]].forEach(q=>{I('box','#c9c2b8',2,1.6,2,q[1],.8,q[2]);I('box','#ffd23f',2.2,.15,2.2,q[1],1.65,q[2]);spr(q[0],1.6,q[1],2.8,q[2]);col(q[1],q[2],1.4);});
    for(let i=0;i<6;i++){const b=new THREE.Mesh(G.box,new THREE.MeshBasicMaterial({color:'#ff6b6b'}));b.scale.set(.12,.12,30);b.position.set(-10+i*4,1+(i%2),0);b.rotation.y=.3;W.ag.add(b);W.disp.push(b.material);}
    treasureChest(8,-6,'vault');}};

/* ----------------- activities ----------------- */
const factorySVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#d9e4ef"/><rect y="600" width="1024" height="168" fill="#8a8f99"/>`;for(let i=0;i<8;i++)s+=`<rect x="${i*140}" y="560" width="120" height="40" fill="#3a3338" stroke="${k}" stroke-width="3"/><circle cx="${i*140+20}" cy="600" r="14" fill="#c9c2b8"/><circle cx="${i*140+100}" cy="600" r="14" fill="#c9c2b8"/>`;
  return s+`<text x="80" y="140" font-size="80">⚙️</text><text x="860" y="140" font-size="80">⚙️</text></svg>`;};
const roboPenSVG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#b8c0b0"/>`;for(let i=0;i<30;i++)s+=`<circle cx="${(i*151)%1010+8}" cy="${160+(i*83)%590}" r="${3+i%4}" fill="#a8b0a0"/>`;return s+penBox2('🔋 Charging dock','#fff6c9','#ffd23f','#5b6378')+'</svg>';};
function robotSVG(){const k=INK;return `<svg viewBox="0 0 90 90"><g stroke="${k}" stroke-width="3.5"><rect x="26" y="34" width="38" height="34" rx="8" fill="#7fc8f0"/><rect x="30" y="10" width="30" height="24" rx="6" fill="#c9c2b8"/><line x1="45" y1="10" x2="45" y2="2"/><circle cx="45" cy="2" r="4" fill="#e8423a"/>
  <circle cx="23" cy="74" r="8" fill="#5b6378"/><circle cx="67" cy="74" r="8" fill="#5b6378"/></g><circle cx="39" cy="22" r="4" fill="#26232e"/><circle cx="51" cy="22" r="4" fill="#26232e"/><rect x="38" y="44" width="14" height="10" rx="2" fill="#ffd23f"/></svg>`;}
const mineSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#3a3030"/><rect width="1024" height="150" fill="#6b5146"/>`;for(let i=0;i<24;i++)s+=`<path d="M${(i*137)%1000} ${200+(i*71)%540} l14 -26 l14 26z" fill="${['#9be8ff','#c9b6ff','#7fffe0'][i%3]}" opacity=".7"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#6b5146" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#6b5146" stroke="${k}" stroke-width="5"/>`;return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🛤️</text></svg>`;};
const launchSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="lsg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#1a2050"/><stop offset="1" stop-color="#7fb0e0"/></linearGradient></defs><rect width="1024" height="768" fill="url(#lsg)"/>`;for(let i=0;i<40;i++)s+=`<circle cx="${(i*173)%1010}" cy="${(i*97)%300}" r="${1+i%3}" fill="#fff" opacity=".7"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#c9c2a8" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#c9c2a8" stroke="${k}" stroke-width="5"/>`;return s+`<text x="964" y="140" font-size="44" text-anchor="middle">🚀</text></svg>`;};
const swatch=(cols)=>`<div style="display:flex;gap:16px;align-items:center;font-size:60px;font-weight:900">${cols.map(c=>c==='+'||c==='='||c==='?'?`<span>${c}</span>`:`<span style="display:inline-block;width:90px;height:90px;border-radius:50%;background:${c};border:5px solid #5b4636"></span>`).join('')}</div>`;
CATCH.bolts={k:'bolts',icon:'🔩',need:15,bg:factorySVG,cls:'',inner:'<b>🔩</b>',art:'📦🔩',fall:true,intro:'The bolts are falling off the conveyor belt! Tap a bolt while it shines to catch it in the box. Catch 15!',tip:'Wait until it shines, then tap!',title:'You caught 15 bolts! The machines are fixed!'};
HERDS.robots={k:'robots',icon:'🤖',n:6,animal:robotSVG,herder:()=>buddyPup(),bg:roboPenSVG,title:'All the robots are charging up!',
  intro:p=>`The little robots need charging before bedtime! Help ${p.name} guide them into the charging dock. Drag your finger and ${p.name} will follow. The robots roll away from ${p.name}!`};
COUNTS.carts={k:'carts',icon:'🛤️',rounds:[{step:3,word:'threes'},{step:6,word:'sixes'},{step:9,word:'nines'}],bg:mineSVG,cls:'stone',intro:'Help your pup hop along the minecart track! Count the jumps.',title:'You counted all the way through the mine!'};
COUNTS.countdown={k:'countdown',icon:'🚀',rounds:[{start:100,step:-10,word:'tens, counting down'},{start:50,step:-5,word:'fives, counting down'},{start:20,step:-2,word:'twos, counting down'}],bg:launchSVG,cls:'stone',intro:'Rocket countdown! Hop across the stones counting backwards, ready for blast off!',title:'3, 2, 1, blast off! Brilliant countdown!'};
QUIZ.colours={k:'colours',name:'Colour Quiz',icon:'🌈',n:8,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#f2f8ff"/>${['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#5b6fe0','#c9b6ff'].map((c,i)=>`<path d="M-100 ${900} A700 700 0 0 1 1124 900" fill="none" stroke="${c}" stroke-width="30" opacity=".35" transform="translate(0 ${-i*30})"/>`).join('')}</svg>`,
  intro:'The Light Lab Colour Quiz! Let us mix colours and make rainbows.',
  make:i=>[{q:'<b>Red</b> and <b>yellow</b> paint make...',say:'Red and yellow paint mixed together make which colour?',pic:swatch(['#e8423a','+','#ffd23f','=','?']),ans:'Orange',opts:['Orange','Green','Purple'],hintSay:'Think of the colour of a carrot!'},
    {q:'<b>Blue</b> and <b>yellow</b> paint make...',say:'Blue and yellow paint make which colour?',pic:swatch(['#3d8fe0','+','#ffd23f','=','?']),ans:'Green',opts:['Green','Pink','Orange'],hintSay:'Think of the colour of grass!'},
    {q:'<b>Red</b> and <b>blue</b> paint make...',say:'Red and blue paint make which colour?',pic:swatch(['#e8423a','+','#3d8fe0','=','?']),ans:'Purple',opts:['Purple','Yellow','Green'],hintSay:'Think of the colour of grapes!'},
    {q:'<b>Red</b> and <b>white</b> paint make...',say:'Red and white paint make which colour?',pic:swatch(['#e8423a','+','#ffffff','=','?']),ans:'Pink',opts:['Pink','Black','Blue'],hintSay:'White makes colours paler.'},
    {q:'How many colours are in a <b>rainbow</b>?',say:'How many colours are in a rainbow?',pic:swatch(['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#5b6fe0','#c9b6ff']).replace(/90px/g,'50px'),ans:7,opts:[5,7,10],hintSay:'Red, orange, yellow, green, blue, indigo, violet. Count them!'},
    {q:'White light through a <b>prism</b> makes...',say:'When white light shines through a prism, what does it make?',pic:'<div style="font-size:90px">🔺💡</div>',ans:'A rainbow',opts:['A rainbow','A shadow','A sound'],hintSay:'The prism splits the light into lots of colours.'},
    {q:'A <b>shadow</b> happens when something blocks the...',say:'A shadow happens when something blocks the what?',pic:'<div style="font-size:90px">🔦🧸</div>',ans:'Light',opts:['Light','Water','Wind'],hintSay:'Shadows are dark places where light cannot reach.'},
    {q:'Which colour is at the <b>top</b> of a rainbow?',say:'Which colour is at the top of a rainbow?',pic:'<div style="font-size:110px">🌈</div>',ans:'Red',opts:['Red','Green','Violet'],hintSay:'A rainbow starts with red, orange, yellow.'}][i],
  block:()=>'🌈',title:'You are a colour expert!'};
COLLECT.parts={k:'parts',area:'workshop',icon:'⚙️',size:2,items:[[-24,6],[20,-2],[-8,28],[16,30],[-28,-14],[26,8]],start:[-14,12,Math.PI],thing:'gear',art:'⚙️',
  intro:'Gear Grab! Tinker dropped 6 gears round the Workshop. Run and collect them all!',title:'You found all the gears! Tinker can build again!'};
regAct('parts',{name:'Gear Grab',icon:'⚙️',island:'gadget',area:'workshop',where:'the Workshop',play:()=>arcadeTravel('workshop',COLLECT.parts.start,()=>startCollect('parts'),'Gear Grab is about to start!')});
regAct('bolts',{name:'Bolt Catch',icon:'🔩',island:'gadget',area:'factory',where:'the Factory',play:()=>startFlies('arcade','bolts')});
regAct('carts',{name:'Minecart Count',icon:'🛤️',island:'gadget',area:'mine',where:'the Magnet Mine',play:()=>startStones('arcade','carts')});
regAct('colours',{name:'Colour Quiz',icon:'🌈',island:'gadget',area:'lightlab',where:'the Light Lab',play:()=>startQuiz('arcade','colours')});
regAct('countdown',{name:'Rocket Countdown',icon:'🚀',island:'gadget',area:'launch',where:'the Launch Range',play:()=>startStones('arcade','countdown')});
regAct('robots',{name:'Robot Round-up',icon:'🤖',island:'gadget',area:'robotyard',where:'the Robot Yard',play:()=>startHerd('arcade','robots')});

regIsland({id:'gadget',name:'Gadget Island',icon:'⚙️',type:'sky',req:['ninja','number'],rideName:"Seb's flying machine",ride:"Seb's flying machine",from:'launch pad in the village',rideIcon:'✈️',rideSay:'Pedal hard! Seb\'s home-made flying machine flaps its wings and takes off for Gadget Island!',
  homeSay:'The flying machine flaps back down to the village!',homePos:[-11,29,Math.atan2(-5,5)],
  badge:'Gadget Badge',cert:'Seb, Gadget Island Hero!',bossHint:'Gizmo the Gadget Unicorn is waiting in the Robot Yard!',
  nextSay:'Hooray! Gadget Island is safe! Have you been to Rescue Bay too?',
  map:{shape:'M80 410 L110 170 L250 110 L430 50 L610 110 L750 170 L780 410 Q600 470 430 460 Q260 470 80 410Z',
    nodes:{workshop:[430,350],factory:[230,260],lightlab:[630,260],mine:[200,120],launch:[660,120],robotyard:[430,80],vault:[95,345]},
    links:[['workshop','factory'],['workshop','lightlab'],['factory','mine'],['lightlab','launch'],['mine','robotyard'],['launch','robotyard'],['factory','vault']]},
  boss:{area:'robotyard',x:0,z:-16,perch:0,uni:GIZMO,
    story:[['m','Muddle the Magpie rattles out from behind a scrap pile in a cardboard robot suit. "Sorry, Seb! I took the shiny Gadget Star to build a robot friend, but I wired it all wrong and the robots went whizzing everywhere. They scared all the pups!"'],
      ['u','Gizmo the Gadget Unicorn chuckles. "Oh, Muddle! The best inventions help everyone, and inventors always fix their mistakes. Now give back the shiny Gadget Star."'],
      ['b','Muddle gives back the Gadget Star, and all 12 Sky pups cheer! Tinker the robot does a happy spin, and Gizmo gives Seb the Gadget Badge.']],
    after:['Gizmo says: thank you for finding every pup on Gadget Island!','Muddle says: beep boop! I am fixing my robot suit.','Gizmo says: the Mega Bot is waving at you!']},
  pups:P,bonus:[CHROME],areas:[workshop,factory,lightlab,mine,launch,robotyard,vault]});
})();
