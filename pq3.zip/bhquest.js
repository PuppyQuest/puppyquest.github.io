/* ================================================================
   Seb's Puppy Quest 3: the Black Hole side quest (24 Nov 2026).
   Part 1 of 2. Black Hole Tours opens on the Black Hole planet after
   Nebula is helped. Seb takes the old striped tour ship, the Stargazer,
   with his pups and Stephen Pawking, who reads real black hole facts.
   A space pebble stops the engine, the lever snaps off, everyone holds
   on, and the ship falls through a wormhole hiding next to the black
   hole: stretched like spaghetti, then dark, then a pinprick of light,
   then a rainbow tunnel and a burst of colour on the far side of the
   galaxy. The ship limps down to a candy-coloured planet and Seb names
   it. Part 2 (alien.js) is the planet, Zuzu and her 10 puppies. This
   file also has the flight home through the wormhole (steer through
   rings of light), the homecoming, the card set, badges and the
   certificate. Cutscenes are drawn on their own canvas screen (#bhcut).
   Save: state.bh = {name, found:{id:time}, sub:{}, met, seenFall,
   landed, fixed, done}.
   ================================================================ */
(function(){
const PL=96,wd=d=>PLANET.wrapD(d,PL),INKC='#26232e';
const BHQ=window.BHQ={FAST:1};
function S(){if(!state.bh)state.bh={found:{},sub:{}};const b=state.bh;b.found=b.found||{};b.sub=b.sub||{};return b;}
const pname=()=>(state&&state.bh&&state.bh.name)||'the alien planet';
BHQ.S=S;BHQ.pname=pname;

/* ----------------- sounds made on the spot ----------------- */
let NB=null;
const nbuf=()=>{if(NB)return NB;const n=AC.sampleRate*2;NB=AC.createBuffer(1,n,AC.sampleRate);const d=NB.getChannelData(0);for(let i=0;i<n;i++)d[i]=Math.random()*2-1;return NB;};
function noise(d,f0,f1,v,type,q,dl){if(!fxOk())return;try{const t=AC.currentTime+(dl||0),s=AC.createBufferSource();s.buffer=nbuf();const f=AC.createBiquadFilter();f.type=type||'bandpass';f.Q.value=q||1;
  f.frequency.setValueAtTime(f0,t);f.frequency.exponentialRampToValueAtTime(f1||f0,t+d);const g=AC.createGain();g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v||.3,t+Math.min(.08,d/3));g.gain.exponentialRampToValueAtTime(.0001,t+d);
  s.connect(f);f.connect(g);g.connect(sfxG);s.start(t);s.stop(t+d+.05);}catch(e){}}
const T=(f,dl,d,ty,v,to)=>{if(fxOk())tone(f,AC.currentTime+(dl||0),d,ty,v,null,to);};
const snd={
  clonk(){T(220,0,.18,'square',.3,90);T(140,.02,.3,'triangle',.35,60);noise(.3,900,300,.5,'bandpass',2);},
  cough(){[0,.4,.9].forEach((d,i)=>{noise(.25,500,180,.45,'lowpass',1,d);T(90-i*15,d,.22,'sawtooth',.16,50);});},
  whoosh(d){noise(d||1.4,250,3200,.5,'bandpass',1.2);},
  whooshDown(d){noise(d||1.2,2600,220,.4,'bandpass',1.2);},
  slide(){T(260,0,1.4,'sine',.25,1150);},
  beep(n){if(!fxOk())return;for(let i=0;i<(n||3);i++)T(900+Math.random()*900,i*.11,.09,'sine',.18);},
  chirp(){if(!fxOk())return;const b=1800+Math.random()*1400;T(b,0,.08,'sine',.07,b*1.3);T(b*1.1,.13,.08,'sine',.06,b*1.45);},
  squish(){T(160,0,.28,'sine',.32,55);noise(.25,600,150,.25,'lowpass',1);},
  boing(){T(170,0,.45,'triangle',.3,620);},
  thump(){T(70,0,.3,'sine',.55,36);noise(.25,300,80,.35,'lowpass',1);},
  heart(){T(62,0,.18,'sine',.55,40);T(58,.24,.2,'sine',.45,38);},
  tink(){T(2400,0,.15,'sine',.15);T(3200,.05,.12,'sine',.1);},
  ring(){[1568,2093,2637].forEach((f,i)=>T(f,i*.05,.35,'sine',.16));},
  sparkle(){[2093,2637,3136,4186].forEach((f,i)=>T(f,i*.06,.25,'sine',.12));},
  note(i){const F=[523,659,784,1047,880,587];const f=F[i%F.length];T(f,0,.6,'triangle',.32);T(f*2,0,.4,'sine',.08);},
  pop(){T(300,0,.12,'sine',.3,900);},
  clank(){T(800,0,.12,'square',.15,500);noise(.12,3000,1500,.3,'highpass',1);},
  snap(){noise(.1,4000,2000,.6,'highpass',1);T(1200,0,.06,'square',.2,400);},
  siren(hi){T(hi?880:660,0,.38,'square',.07);},
  zap(){T(1800,0,.25,'sawtooth',.08,300);T(900,.05,.25,'sine',.15,1800);}};
BHQ.snd=snd;BHQ.noise=noise;
/* a sound that keeps going (engine hum, the deep pull) */
function hum(){if(!fxOk())return {set(){},stop(){}};try{const o=AC.createOscillator(),o2=AC.createOscillator(),f=AC.createBiquadFilter(),g=AC.createGain();
  o.type='sawtooth';o.frequency.value=44;o2.type='sine';o2.frequency.value=33;f.type='lowpass';f.frequency.value=200;g.gain.value=.0001;o.connect(f);o2.connect(f);f.connect(g);g.connect(sfxG);o.start();o2.start();
  let dead=false;return {set(v,p){if(dead)return;const t=AC.currentTime;g.gain.setTargetAtTime(Math.max(.0001,v),t,.35);if(p){o.frequency.setTargetAtTime(p,t,.6);o2.frequency.setTargetAtTime(p*.75,t,.6);}},
    stop(){if(dead)return;dead=true;try{const t=AC.currentTime;g.gain.setTargetAtTime(.0001,t,.12);o.stop(t+.7);o2.stop(t+.7);}catch(e){}}};}catch(e){return {set(){},stop(){}};}}
const hums=[];function humOn(v,p){const h=hum();h.set(v,p);hums.push(h);return h;}
const loops=[];function loop(ms,fn){const id=setInterval(fn,ms);loops.push(id);return id;}
function stopLoop(id){clearInterval(id);const i=loops.indexOf(id);if(i>=0)loops.splice(i,1);}
function stopSounds(){loops.forEach(clearInterval);loops.length=0;hums.forEach(h=>h.stop());hums.length=0;}
/* tunes: a twinkly one for the slow descent, a brave one for flying home */
function tune(notes,ms,ty,v){let i=0;return loop(ms,()=>{const f=notes[i++%notes.length];if(f&&fxOk())T(f,0,ms/1000*1.6,ty||'triangle',v||.12);});}
let musV=null;function muteMusic(on){if(typeof musG==='undefined'||!musG)return;if(on){if(musV==null)musV=musG.gain.value;musG.gain.value=0;}else if(musV!=null){musG.gain.value=musV;musV=null;}}
BHQ.humOn=humOn;BHQ.loop=loop;BHQ.stopLoop=stopLoop;BHQ.stopSounds=stopSounds;BHQ.tune=tune;BHQ.muteMusic=muteMusic;

/* ----------------- alien antennae on the 2D pictures ----------------- */
function alienSVG(p,o){let s=critterSVG(p,o);if(!p.ant)return s;const L=Object.assign({},DEF,formLook(p)),cx=100+L.hx,cy=82-L.neck,hw=L.hw,hh=L.hh,c=p.ant,k=INK;
  let a='';[-1,1].forEach(sd=>{const x0=cx+sd*hw*.32,y0=cy-hh*.72,x1=cx+sd*hw*.62,y1=cy-hh-22;
    a+=`<path d="M${x0} ${y0} Q${x0+sd*4} ${y1+16} ${x1} ${y1}" fill="none" stroke="${k}" stroke-width="9" stroke-linecap="round"/><path d="M${x0} ${y0} Q${x0+sd*4} ${y1+16} ${x1} ${y1}" fill="none" stroke="${p.antS||L.fur}" stroke-width="4.5" stroke-linecap="round"/>`+
      `<circle cx="${x1}" cy="${y1}" r="15" fill="${c}" opacity=".35"/><circle cx="${x1}" cy="${y1}" r="8.5" fill="${c}" stroke="${k}" stroke-width="3"/><circle cx="${x1-2.5}" cy="${y1-2.5}" r="2.6" fill="#fff"/>`;});
  return s.replace(/(<svg class="pup"[^>]*><g[^>]*>)/,'$1'+a);}
BHQ.alienSVG=alienSVG;
const art=(p,o)=>{try{return p.ant?alienSVG(p,o):critterSVG(p,o);}catch(e){return '<div style="font-size:80px;text-align:center">🐶</div>';}};
BHQ.art=art;

/* ----------------- the Stargazer, an old striped tour ship ----------------- */
function stargazer3D(o){o=o||{};const g=grp(),body=grp();g.add(body);const Y=2.7;
  const cream='#f4ecd8',red='#e8423a';
  mk('cyl',cream,2,7,2,0,Y,0,body).rotation.x=Math.PI/2;
  [-2.3,-.7,.9].forEach(z=>{mk('cyl',red,2.05,.6,2.05,0,Y,z,body).rotation.x=Math.PI/2;});
  mk('sph',cream,2,2,2.6,0,Y,3.4,body);mk('cone',red,.9,1.5,.9,0,Y,5.8,body).rotation.x=Math.PI/2;
  mk('sph',cream,2,2,1.5,0,Y,-3.4,body);mk('cyl','#5b6378',1.25,1.4,1.25,0,Y,-4.9,body).rotation.x=Math.PI/2;
  const flame=new THREE.Mesh(G.cone,new THREE.MeshBasicMaterial({color:'#ffb347',transparent:true,opacity:.85,depthWrite:false}));flame.scale.set(.95,2.6,.95);flame.rotation.x=-Math.PI/2;flame.position.set(0,Y,-6.9);body.add(flame);
  const can=new THREE.Mesh(G.hemi,new THREE.MeshLambertMaterial({color:'#9bdcff',transparent:true,opacity:.62,depthWrite:false}));can.scale.set(1.45,1.25,1.9);can.position.set(0,Y+1.55,1.9);body.add(can);
  [-1,1].forEach(s=>[-1.6,0,1.6].forEach(z=>{if(s>0&&z>1)return;mk('cyl','#9bdcff',.42,.1,.42,s*2,Y+.3,z,body).rotation.z=Math.PI/2;}));
  const fins=[];[0,2.09,4.19].forEach((a,i)=>{const f=mk('box',red,.2,2.3,2.4,Math.sin(a)*2.35,Y+Math.cos(a)*2.35,-3.7,body);f.rotation.z=-a;fins.push(f);});
  const wm=new THREE.MeshBasicMaterial({color:'#ff3a3a'}),wl=new THREE.Mesh(G.sph,wm);wl.scale.setScalar(.26);wl.position.set(0,Y+2.05,-.6);body.add(wl);
  [0,2.09,4.19].forEach(a=>{const lx=Math.sin(a)*1.5,lz=Math.cos(a)*1.5-.3;const l=mk('cyl','#8a8f99',.12,2.2,.12,lx,1,lz,g);l.rotation.set(Math.cos(a)*.35,0,-Math.sin(a)*.35);mk('cyl','#5b6378',.42,.14,.42,lx*1.25,.07,lz*1.25,g);});
  const hatch=grp();hatch.position.set(2.04,Y-1.05,1.2);body.add(hatch);mk('box','#d8cdb2',.1,1.9,1.4,0,.95,0,hatch);mk('sph','#c9a040',.12,.12,.12,.05,1.05,.5,hatch);
  if(o.map){const m=mk('box','#7fe0ff',.6,.05,.45,.6,Y+1.8,2.6,body,true);m.rotation.x=-.5;}
  shadow(g,3.4);g.userData={body,flame,wl,wm,hatch,fins,can};
  if(o.crash){body.rotation.set(-.1,0,.22);body.position.y=-.55;fins[1].rotation.z+=.6;flame.visible=false;wm.color.set('#5a2020');}
  g.traverse(m=>{m.frustumCulled=false;});return g;}
BHQ.stargazer3D=stargazer3D;
/* Captain Nibbles, a hamster in a space suit, for the homecoming */
function nibbles3D(){const g=grp();mk('sph','#f4f6fb',.75,.85,.7,0,1,0,g);mk('sph','#e8a85a',.5,.48,.46,0,1.95,.02,g);
  [-1,1].forEach(s=>{mk('sph','#e8a85a',.15,.17,.08,s*.3,2.35,0,g);mk('sph','#26232e',.07,.08,.04,s*.17,2.02,.42,g);mk('cyl','#f4f6fb',.2,.6,.2,s*.62,1.1,0,g).rotation.z=s*.6;});
  mk('sph','#ffffff',.25,.18,.15,0,1.84,.42,g);mk('sph','#ff9ecb',.07,.06,.05,0,1.92,.52,g);mk('box','#3d8fe0',.4,.3,.08,0,1.25,.68,g);
  const h=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#dff4ff',transparent:true,opacity:.28,depthWrite:false}));h.scale.setScalar(.72);h.position.y=1.95;g.add(h);W.disp.push(h.material);shadow(g,.8);return g;}

/* ================= the cutscene screen ================= */
const DPR=Math.min(2,window.devicePixelRatio||1);
let SC=null;const V={};let capDone=null;
function scr(){if(SC)return SC;const st=$('#stage'),B=el('div','screen','');B.id='bhcut';
  B.innerHTML=`<canvas id="bhC" width="${1024*DPR}" height="${768*DPR}"></canvas><div id="bhCrew"></div><div id="bhUI"></div><div id="bhCap"><span id="bhWho"></span><span id="bhTxt"></span></div><button class="btn rnd green" id="bhNext">▶</button><button class="btn white" id="bhSkip">⏭ Skip</button><div id="bhBig"></div><div id="bhFlash"></div>`;
  st.insertBefore(B,$('#bubble'));SC={B,cv:$('#bhC'),c:$('#bhC').getContext('2d'),crew:$('#bhCrew'),ui:$('#bhUI'),cap:$('#bhCap')};
  tap('#bhNext',()=>{if(capDone)capDone();});tap('#bhSkip',()=>{$('#bhSkip').style.display='none';skipAll();});
  const pos=e=>{const r=SC.cv.getBoundingClientRect();return [(e.clientX-r.left)/r.width*1024,(e.clientY-r.top)/r.height*768];};
  B.addEventListener('pointerdown',e=>{initAudio();if(V.ptr){const p=pos(e);V.ptr('down',p[0],p[1],e);}});
  B.addEventListener('pointermove',e=>{if(V.ptr){const p=pos(e);V.ptr('move',p[0],p[1],e);}});
  B.addEventListener('pointerup',e=>{if(V.ptr){const p=pos(e);V.ptr('up',p[0],p[1],e);}});
  return SC;}
const MODES={};BHQ.MODES=MODES;
function open(mode){scr();Object.keys(V).forEach(k=>delete V[k]);Object.assign(V,{mode:mode||'cock',t:0,sh:0,shT:0,tw:[],stars:mkStars(260),flow:.02,streak:0,skip:false});
  SC.crew.innerHTML='';SC.ui.innerHTML='';capOff();$('#bhSkip').style.display='none';$('#bhBig').className='';$('#bhFlash').style.opacity=0;
  hush();quiet();joyReset();show('bhcut');muteMusic(true);document.body.classList.add('bhDark');if(!V.run){V.run=true;V.last=0;requestAnimationFrame(frameBH);}}
function closeScr(){stopSounds();muteMusic(false);capOff();document.body.classList.remove('bhDark');if(SC){SC.crew.innerHTML='';SC.ui.innerHTML='';}V.ptr=null;V.tick=null;}
function frameBH(ts){if(cur!=='bhcut'){V.run=false;return;}requestAnimationFrame(frameBH);const dt=Math.min(.05,((ts-(V.last||ts))/1000)||0)*BHQ.FAST;V.last=ts;V.t+=dt;
  V.tw=V.tw.filter(q=>{q.t+=dt;const u=Math.min(1,q.t/q.d),e=u*u*(3-2*u);q.o[q.k]=q.a+(q.b-q.a)*e;if(u>=1){q.r();return false;}return true;});
  if(V.shT>0){V.shT-=dt;if(V.shT<=0)V.sh=0;}if(V.tick)V.tick(dt);
  const c=SC.c;c.setTransform(DPR,0,0,DPR,0,0);c.save();if(V.sh>0)c.translate((Math.random()-.5)*V.sh*26,(Math.random()-.5)*V.sh*26);
  try{(MODES[V.mode]||MODES.cock)(c,dt);}catch(e){console.warn('bh draw',e);}c.restore();}
function tw(o,k,to,s){return new Promise(r=>V.tw.push({o,k,a:o[k],b:to,d:Math.max(.01,s),t:0,r}));}
const pend=new Set();
function wait(ms){return new Promise(r=>{const o={r};o.id=setTimeout(()=>{pend.delete(o);r();},ms/BHQ.FAST);pend.add(o);});}
function skipAll(){V.skip=true;pend.forEach(o=>{clearTimeout(o.id);o.r();});pend.clear();if(capDone)capDone();V.tw.forEach(q=>{q.o[q.k]=q.b;q.r();});V.tw=[];if(V.onSkip){const f=V.onSkip;V.onSkip=null;f();}}
const SKIP={skip:1};const go=async p=>{await p;if(V.skip)throw SKIP;};
function shakeS(a,s){V.sh=Math.max(V.sh,a);V.shT=Math.max(V.shT,s);}
function flash(a,col){const f=$('#bhFlash');f.style.background=col||'#fff';f.style.transition='none';f.style.opacity=a;void f.offsetWidth;f.style.transition='opacity .7s';setTimeout(()=>{f.style.opacity=0;},60);}
function big(txt,cls){const b=$('#bhBig');b.textContent=txt;b.className='';void b.offsetWidth;b.className='on '+(cls||'');}
const face=who=>who==='seb'?sebSVG(true):art(who);
function cap(who,text,o){o=o||{};scr();return new Promise(res=>{const C=SC.cap;C.classList.add('on');const w=$('#bhWho');w.innerHTML=who?face(who):'';w.style.display=who?'block':'none';$('#bhTxt').textContent=text;if(o.speak!==false)speak(text);
  const n=$('#bhNext');n.style.display=o.noNext?'none':'block';let tm=null;
  const fin=()=>{if(capDone!==fin)return;capDone=null;clearTimeout(tm);n.style.display='none';res();};capDone=fin;
  tm=setTimeout(fin,(o.dur||readT(text))*1000/BHQ.FAST);});}
const readT=t=>Math.max(2.6,t.split(/\s+/).length/2.3+1.5);
function capOff(){if(!SC)return;SC.cap.classList.remove('on');capDone=null;$('#bhNext').style.display='none';}
BHQ.scr={open,close:closeScr,V,tw,wait,go,cap,capOff,flash,big,shake:shakeS,SKIP,face,crewAdd,skipAll};

/* ----------------- drawing helpers ----------------- */
function mkStars(n){const a=[];for(let i=0;i<n;i++)a.push({a:Math.random()*6.283,d:.03+Math.random()*1.2,w:.8+Math.random()*1.8});return a;}
function stars(c,dt,cx,cy,al){const R=780;for(const s of V.stars){if(V.flow){s.d+=s.d*V.flow*dt*3;if(s.d>1.3||s.d<.01){s.d=.02+Math.random()*.12;s.a=Math.random()*6.283;}}
  const x=cx+Math.cos(s.a)*s.d*R,y=cy+Math.sin(s.a)*s.d*R*.8,L=V.streak*s.d*R*.5;c.globalAlpha=Math.min(1,(.35+s.d))*(al==null?1:al);
  if(L>1.5){c.strokeStyle='#fff';c.lineWidth=s.w;c.beginPath();c.moveTo(x,y);c.lineTo(cx+Math.cos(s.a)*(s.d*R-L),cy+Math.sin(s.a)*(s.d*R-L)*.8);c.stroke();}
  else{c.fillStyle='#fff';c.fillRect(x-s.w/2,y-s.w/2,s.w,s.w);}}c.globalAlpha=1;}
function glow(c,x,y,r0,r1,col,a){const g=c.createRadialGradient(x,y,r0,x,y,r1);g.addColorStop(0,col);g.addColorStop(1,'rgba(0,0,0,0)');c.globalAlpha=a==null?1:a;c.fillStyle=g;c.beginPath();c.arc(x,y,r1,0,6.283);c.fill();c.globalAlpha=1;}
/* a black hole: back of the glowing disc, the bent light over the top, the dark shadow, then the front of the disc */
function hole(c,x,y,R,t){if(R<=0)return;glow(c,x,y,R*.6,R*4.4,'rgba(255,160,80,.38)');glow(c,x,y,R,R*3,'rgba(190,90,255,.25)');
  const disc=front=>{for(let i=0;i<16;i++){const k=i/15,r=R*(1.5+i*.12),h=((45-k*135)+360)%360;c.strokeStyle=`hsla(${h},100%,${76-k*30}%,${.8-k*.55})`;c.lineWidth=R*.13;
      c.setLineDash([R*(.5+k*.4),R*.22]);c.lineDashOffset=-t*R*(3.2-k*2.4);c.beginPath();c.ellipse(x,y,r,r*.24,-.08,front?0:Math.PI,front?Math.PI:6.283);c.stroke();}c.setLineDash([]);};
  disc(false);
  for(let i=0;i<8;i++){const k=i/7,r=R*(1.16+i*.075);c.strokeStyle=`hsla(${42-k*30},100%,${80-k*25}%,${.75-k*.6})`;c.lineWidth=R*.08;c.beginPath();c.arc(x,y,r,Math.PI*1.04,Math.PI*1.96);c.stroke();}
  c.fillStyle='#000';c.beginPath();c.arc(x,y,R,0,6.283);c.fill();c.strokeStyle='#ffe6a8';c.lineWidth=Math.max(1.5,R*.05);c.beginPath();c.arc(x,y,R*1.03,0,6.283);c.stroke();
  disc(true);}
function neb(c,x,y,r,col,a){glow(c,x,y,0,r,col,a);}
function galaxy(c,x,y,r,t,label){glow(c,x,y,0,r*1.6,'rgba(220,210,255,.5)');for(let arm=0;arm<2;arm++)for(let k=0;k<40;k++){const a=k*.22+arm*Math.PI+t*.25,rr=r*.08+k*r*.022;c.fillStyle=`rgba(255,${235-k*2},${255-k},${.9-k*.018})`;c.beginPath();c.arc(x+Math.cos(a)*rr,y+Math.sin(a)*rr*.55,1.6+(40-k)*.03,0,6.283);c.fill();}
  glow(c,x,y,0,r*.35,'rgba(255,250,220,1)');
  if(label){c.save();c.font='900 26px sans-serif';c.textAlign='left';c.fillStyle='#fff';c.strokeStyle=INKC;c.lineWidth=6;c.strokeText('HOME',x+r*1.9,y+r*1.6+8);c.fillText('HOME',x+r*1.9,y+r*1.6+8);
    c.strokeStyle='#fff';c.lineWidth=4;c.beginPath();c.moveTo(x+r*1.85,y+r*1.3);c.lineTo(x+r*.95,y+r*.7);c.stroke();c.beginPath();c.moveTo(x+r*.95,y+r*.7);c.lineTo(x+r*1.3,y+r*.72);c.moveTo(x+r*.95,y+r*.7);c.lineTo(x+r*1.1,y+r*1.02);c.stroke();c.restore();}}
/* the far side: two suns, nebulas, our galaxy far away */
function farSky(c,dt,o){o=o||{};const g=c.createLinearGradient(0,0,0,768);g.addColorStop(0,'#160634');g.addColorStop(.6,'#3a1066');g.addColorStop(1,'#5a1a7a');c.fillStyle=g;c.fillRect(0,0,1024,768);
  neb(c,250,330,330,'rgba(255,110,200,.55)');neb(c,820,420,360,'rgba(90,230,220,.45)');neb(c,560,160,300,'rgba(170,120,255,.5)');neb(c,880,120,200,'rgba(255,190,110,.4)');
  stars(c,dt,512,330,.9);
  glow(c,300,165,30,190,'rgba(255,120,200,.75)');glow(c,300,165,0,52,'#fff0fa');c.fillStyle='#ffb3e0';c.beginPath();c.arc(300,165,46,0,6.283);c.fill();
  glow(c,770,230,20,140,'rgba(110,180,255,.75)');glow(c,770,230,0,38,'#f0f8ff');c.fillStyle='#a8d4ff';c.beginPath();c.arc(770,230,32,0,6.283);c.fill();
  if(o.home!==false)galaxy(c,o.gx||190,o.gy||175,26,V.t,true);}
/* the cockpit: windscreen, frame and dashboard */
function winPath(c){c.beginPath();c.moveTo(70,96);c.quadraticCurveTo(512,14,954,96);c.lineTo(992,476);c.quadraticCurveTo(512,560,32,476);c.closePath();}
function gauge(c,x,y,r,a){c.fillStyle='#f4f6fb';c.beginPath();c.arc(x,y,r,0,6.283);c.fill();c.lineWidth=5;c.strokeStyle='#1b2236';c.stroke();
  for(let i=0;i<7;i++){const q=-2.4+i*.8;c.lineWidth=2;c.beginPath();c.moveTo(x+Math.cos(q)*r*.72,y+Math.sin(q)*r*.72);c.lineTo(x+Math.cos(q)*r*.88,y+Math.sin(q)*r*.88);c.stroke();}
  c.strokeStyle='#e8423a';c.lineWidth=4;c.beginPath();c.moveTo(x,y);c.lineTo(x+Math.cos(a-1.57)*r*.75,y+Math.sin(a-1.57)*r*.75);c.stroke();c.fillStyle='#1b2236';c.beginPath();c.arc(x,y,5,0,6.283);c.fill();}
function dash(c){const t=V.t;c.save();c.beginPath();c.moveTo(0,544);c.quadraticCurveTo(512,488,1024,544);c.lineTo(1024,768);c.lineTo(0,768);c.closePath();
  const g=c.createLinearGradient(0,490,0,768);g.addColorStop(0,'#62749e');g.addColorStop(.1,'#40507a');g.addColorStop(1,'#1e2638');c.fillStyle=g;c.fill();c.lineWidth=6;c.strokeStyle='#1b2236';c.stroke();
  const al=V.warn==='alarm';gauge(c,262,640,44,al?Math.sin(t*9)*1.3:Math.sin(t*.7)*.3);gauge(c,382,660,34,al?Math.cos(t*7)*1.5:.4+Math.sin(t*.9)*.2);
  for(let i=0;i<6;i++){const on=((t*2.4+i*1.7)%3)<1.5;c.fillStyle=on?(al?'#ff5a5a':['#7fe0ff','#8fe39a','#ffd23f'][i%3]):'#2a3550';c.beginPath();c.arc(210+i*34,584,8,0,6.283);c.fill();}
  const bl=al?(Math.sin(t*14)>0?1:.25):V.warn==='blink'?((t%1.7)<.28?1:.15):.15;
  if(bl>.5)glow(c,512,586,4,70,'rgba(255,60,60,.85)');c.fillStyle=`rgb(${Math.round(110+145*bl)},${Math.round(20+30*bl)},${Math.round(25+25*bl)})`;c.beginPath();c.arc(512,586,18,0,6.283);c.fill();c.lineWidth=4;c.strokeStyle='#1b2236';c.stroke();
  c.fillStyle='#1b2236';rr(c,620,612,40,104,10);c.fill();
  if(V.lever<2){const a=-.45+(V.lever||0)*1.05;c.save();c.translate(640,700);c.rotate(a);c.fillStyle='#c9d2e3';c.fillRect(-7,-112,14,112);c.strokeStyle='#1b2236';c.lineWidth=3;c.strokeRect(-7,-112,14,112);
    c.fillStyle='#e8423a';c.beginPath();c.arc(0,-120,22,0,6.283);c.fill();c.lineWidth=4;c.stroke();c.fillStyle='rgba(255,255,255,.6)';c.beginPath();c.arc(-7,-127,6,0,6.283);c.fill();c.restore();}
  else{c.fillStyle='#c9d2e3';c.fillRect(633,664,14,40);c.strokeStyle='#1b2236';c.lineWidth=3;c.strokeRect(633,664,14,40);}
  if(V.hand){const h=V.hand;c.save();c.translate(h.x,h.y);c.rotate(h.r);c.fillStyle='#c9d2e3';c.fillRect(-7,0,14,70);c.fillStyle='#e8423a';c.beginPath();c.arc(0,-8,20,0,6.283);c.fill();c.restore();}
  c.fillStyle='#c9a040';rr(c,420,706,184,40,8);c.fill();c.fillStyle=INKC;c.font='900 23px sans-serif';c.textAlign='center';c.fillText('STARGAZER',512,734);c.restore();}
function cockpit(c,dt){c.fillStyle='#2b3756';c.fillRect(0,0,1024,768);
  for(let i=0;i<12;i++){c.fillStyle='#3d4b72';c.beginPath();c.arc(30+i*88,40,5,0,6.283);c.fill();}
  c.save();winPath(c);c.clip();space(c,dt);c.restore();
  winPath(c);c.lineWidth=20;c.strokeStyle='#1b2236';c.stroke();c.lineWidth=6;c.strokeStyle='#7484aa';c.stroke();
  dash(c);
  if(V.alarm>0){c.fillStyle=`rgba(255,30,30,${V.alarm*(.1+.09*Math.sin(V.t*12))})`;c.fillRect(0,0,1024,768);}
  if(V.dark>0){c.fillStyle=`rgba(0,0,0,${V.dark})`;c.fillRect(0,0,1024,768);if(V.dark>.8)eyes(c);}}
function space(c,dt){const sp=V.sp||'hole';
  if(sp==='hole'){c.fillStyle='#04020c';c.fillRect(0,0,1024,768);const H=V.hole||{x:560,y:250,r:8};stars(c,dt,H.x,H.y);hole(c,H.x,H.y,H.r,V.t);
    if(V.pl!=null&&V.pl<700){c.fillStyle='#3a2a5a';c.beginPath();c.arc(512,1180+V.pl,720,0,6.283);c.fill();c.fillStyle='#7a3fb0';c.beginPath();c.arc(512,1188+V.pl,700,Math.PI*1.2,Math.PI*1.8);c.lineTo(512,1188+V.pl);c.fill();
      for(let i=0;i<7;i++){const a=Math.PI*(1.25+i*.08),x=512+Math.cos(a)*720,y=1180+V.pl+Math.sin(a)*720;c.fillStyle=['#ff5fa8','#c9b6ff','#7fe0ff'][i%3];c.beginPath();c.moveTo(x-9,y+6);c.lineTo(x,y-36);c.lineTo(x+9,y+6);c.fill();}}
    if(V.peb){const p=V.peb;c.fillStyle='#8a8278';c.beginPath();c.ellipse(p.x,p.y,p.s,p.s*.8,p.x*.01,0,6.283);c.fill();c.fillStyle='#6a625a';c.beginPath();c.arc(p.x-p.s*.3,p.y-p.s*.1,p.s*.25,0,6.283);c.fill();c.strokeStyle='rgba(255,255,255,.35)';c.lineWidth=3;c.beginPath();c.moveTo(p.x+p.s*1.2,p.y-p.s*.9);c.lineTo(p.x+p.s*3,p.y-p.s*2.4);c.stroke();}
    if(V.ring>0){const r=V.ring;c.strokeStyle=`rgba(255,215,140,${1-r})`;c.lineWidth=140*(1-r)+10;c.beginPath();c.ellipse(512,290,80+r*1100,(80+r*1100)*.5,0,0,6.283);c.stroke();}}
  else if(sp==='stretch'){c.fillStyle='#0a0416';c.fillRect(0,0,1024,768);glow(c,512,290,0,420,'rgba(120,40,200,.35)');stars(c,dt,512,290);}
  else if(sp==='black'){c.fillStyle='#000';c.fillRect(0,0,1024,768);}
  else if(sp==='pin'){c.fillStyle='#000';c.fillRect(0,0,1024,768);const r=V.pin||0;if(r>0){glow(c,512,290,0,r*6,'rgba(255,250,230,.5)');glow(c,512,290,0,r,'#ffffff');
      c.strokeStyle='rgba(255,255,255,.5)';c.lineWidth=2;for(let i=0;i<8;i++){const a=i*.785+V.t*.3;c.beginPath();c.moveTo(512+Math.cos(a)*r*1.2,290+Math.sin(a)*r*1.2);c.lineTo(512+Math.cos(a)*r*4,290+Math.sin(a)*r*4);c.stroke();}}}
  else if(sp==='tunnel'){tunnel(c,dt);}
  else if(sp==='burst'){farSky(c,dt);puffs(c,dt);}}
function tunnel(c,dt,dim){V.tz=(V.tz||0)+dt*(V.tsp||1.6);c.fillStyle='#14041f';c.fillRect(0,0,1024,768);const cx=512+Math.sin(V.t*.8)*24,cy=300+Math.cos(V.t*.6)*16,f=V.tz%1;
  for(let i=26;i>=0;i--){const r=10*Math.pow(1.2,i+f),h=(i*27-V.t*220)%360;c.strokeStyle=dim?`hsla(${(h+360)%360},55%,32%,${Math.min(.55,.1+i*.03)})`:`hsla(${(h+360)%360},100%,65%,${Math.min(1,.15+i*.05)})`;c.lineWidth=r*.16;c.beginPath();c.ellipse(cx,cy,r,r*.82,V.t*.2,0,6.283);c.stroke();}
  glow(c,cx,cy,0,70,'rgba(255,255,255,.9)');}
function puffs(c,dt){V.puffs=V.puffs||[];if(V.smoke&&Math.random()<dt*5)V.puffs.push({x:900+Math.random()*80,y:520,r:24+Math.random()*20,vx:-40-Math.random()*50,vy:-60-Math.random()*40,a:.7});
  V.puffs=V.puffs.filter(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.r+=dt*20;p.a-=dt*.22;if(p.a<=0)return false;c.fillStyle=`rgba(90,90,100,${p.a})`;c.beginPath();c.arc(p.x,p.y,p.r,0,6.283);c.fill();return true;});}
function eyes(c){const t=V.t;V.eyes&&V.eyes.forEach((e,i)=>{glow(c,e.x,e.y-34,0,70,'rgba(255,240,200,.16)');const bl=((t+i*1.3)%3.4)<.15;c.fillStyle='#fff';
  [-1,1].forEach(s=>{c.beginPath();c.ellipse(e.x+s*12,e.y,7,bl?1:8,0,0,6.283);c.fill();});if(!bl){c.fillStyle='#000';[-1,1].forEach(s=>{c.beginPath();c.arc(e.x+s*12+1,e.y+1,3.4,0,6.283);c.fill();});}});}
MODES.cock=cockpit;
/* the Stargazer from the side, for the descent and the repair */
function ship2D(c,x,y,s,rot,o){o=o||{};c.save();c.translate(x,y);c.rotate(rot||0);c.scale(s,s);const k=INKC,br=o.broken||{};
  if(o.flame){const f=18+Math.sin(V.t*30)*5;c.fillStyle='#ffb347';c.beginPath();c.moveTo(-64,-11);c.lineTo(-64-f*2,0);c.lineTo(-64,11);c.fill();c.fillStyle='#fff3a0';c.beginPath();c.moveTo(-64,-6);c.lineTo(-64-f,0);c.lineTo(-64,6);c.fill();}
  c.lineJoin='round';c.lineWidth=4;c.strokeStyle=k;
  c.fillStyle='#e8423a';c.save();if(br.fin)c.rotate(.25);c.beginPath();c.moveTo(-40,-18);c.lineTo(-66,-46);c.lineTo(-58,-46);c.lineTo(-22,-20);c.closePath();c.fill();c.stroke();c.restore();
  c.beginPath();c.moveTo(-40,18);c.lineTo(-66,44);c.lineTo(-58,44);c.lineTo(-22,20);c.closePath();c.fill();c.stroke();
  c.fillStyle='#5b6378';c.fillRect(-68,-13,14,26);c.strokeRect(-68,-13,14,26);
  c.beginPath();c.moveTo(-54,-22);c.lineTo(40,-22);c.quadraticCurveTo(78,-20,84,0);c.quadraticCurveTo(78,20,40,22);c.lineTo(-54,22);c.quadraticCurveTo(-62,0,-54,-22);c.closePath();c.fillStyle='#f4ecd8';c.fill();
  c.save();c.clip();c.fillStyle='#e8423a';[-36,-10,16].forEach(sx=>c.fillRect(sx,-30,11,60));c.fillRect(66,-30,30,60);
  if(br.dent){c.fillStyle='rgba(60,50,40,.35)';c.beginPath();c.ellipse(-20,10,12,7,0,0,6.283);c.fill();}
  if(br.scorch){c.fillStyle='rgba(30,30,30,.45)';c.beginPath();c.ellipse(-44,-4,14,12,0,0,6.283);c.fill();}c.restore();
  c.beginPath();c.moveTo(-54,-22);c.lineTo(40,-22);c.quadraticCurveTo(78,-20,84,0);c.quadraticCurveTo(78,20,40,22);c.lineTo(-54,22);c.quadraticCurveTo(-62,0,-54,-22);c.closePath();c.stroke();
  c.fillStyle='rgba(155,220,255,.85)';c.beginPath();c.arc(34,-22,19,Math.PI,0);c.closePath();c.fill();c.stroke();
  if(br.crack){c.strokeStyle='#fff';c.lineWidth=2;c.beginPath();c.moveTo(28,-38);c.lineTo(34,-30);c.lineTo(30,-24);c.moveTo(34,-30);c.lineTo(42,-28);c.stroke();c.strokeStyle=k;c.lineWidth=4;}
  [-22,2].forEach(wx=>{c.fillStyle='#9bdcff';c.beginPath();c.arc(wx,2,7,0,6.283);c.fill();c.stroke();});
  const on=o.light==='alarm'?Math.sin(V.t*14)>0:o.light==='off'?false:(V.t%1.7)<.3;c.fillStyle=on?'#ff3a3a':'#7a2a2a';c.beginPath();c.arc(-2,-26,5,0,6.283);c.fill();c.stroke();
  if(br.bolts){c.fillStyle='#ffd23f';[[-48,-14],[-48,14],[56,12]].forEach(b=>{c.beginPath();c.arc(b[0],b[1],3.5,0,6.283);c.fill();});}
  c.restore();}
BHQ.ship2D=ship2D;BHQ.farSky=farSky;BHQ.glow=glow;BHQ.stars=stars;BHQ.galaxy=galaxy;BHQ.tunnel=tunnel;
/* the candy planet seen from space */
function planet2D(c,x,y,R){glow(c,x,y,R*.96,R*1.14,'rgba(255,170,230,.65)');c.save();c.beginPath();c.arc(x,y,R,0,6.283);c.clip();
  const g=c.createRadialGradient(x-R*.3,y-R*.4,R*.1,x,y,R);g.addColorStop(0,'#ffe0f6');g.addColorStop(.6,'#e0b0ff');g.addColorStop(1,'#8a5ad0');c.fillStyle=g;c.fillRect(x-R,y-R,R*2,R*2);
  [['rgba(160,240,210,.55)',-.55,.12],['rgba(255,240,150,.5)',-.2,.08],['rgba(140,200,255,.45)',.15,.1],['rgba(255,170,210,.5)',.45,.12]].forEach(b=>{c.fillStyle=b[0];c.beginPath();c.ellipse(x,y+R*b[1],R*1.1,R*b[2],Math.sin(V.t*.2)*.04,0,6.283);c.fill();});
  for(let i=0;i<40;i++){const a=i*2.4,r=R*((i*37)%100)/105;c.fillStyle=['#fff27a','#7ff6ff','#ff9ee0'][i%3];c.globalAlpha=.6+.4*Math.sin(V.t*2+i);c.beginPath();c.arc(x+Math.cos(a)*r,y+Math.sin(a)*r,R*.012,0,6.283);c.fill();}c.globalAlpha=1;
  const sh=c.createRadialGradient(x-R*.4,y-R*.5,R*.5,x,y,R*1.05);sh.addColorStop(0,'rgba(0,0,0,0)');sh.addColorStop(.75,'rgba(40,0,60,.08)');sh.addColorStop(1,'rgba(40,0,60,.45)');c.fillStyle=sh;c.fillRect(x-R,y-R,R*2,R*2);c.restore();
  for(let i=0;i<14;i++){const a=Math.PI*(1.12+i*.055),bx=x+Math.cos(a)*R,by=y+Math.sin(a)*R,s=R*(.025+((i*7)%5)*.006);
    if(i%3===0){c.fillStyle=['#a0f0d0','#ffb3e0','#fff0a0'][i%3];c.beginPath();c.arc(bx,by,s*1.6,Math.PI,0);c.fill();}
    else if(i%3===1){c.fillStyle=['#c9a8ff','#7fe0ff'][i%2];c.beginPath();c.moveTo(bx-s*.5,by);c.lineTo(bx,by-s*3);c.lineTo(bx+s*.5,by);c.fill();}
    else{c.fillStyle='#7fd6c8';c.beginPath();c.arc(bx,by-s*1.2,s*1.1,0,6.283);c.fill();c.fillStyle='#9b6a43';c.fillRect(bx-s*.15,by-s*.6,s*.3,s*.8);}}
  [[1.32,.12],[1.6,.15],[1.78,.1]].forEach((q,i)=>{const a=Math.PI*q[0],ix=x+Math.cos(a)*R*(1+q[1]),iy=y+Math.sin(a)*R*(1+q[1]),s=R*.05;c.fillStyle='#ffd1f0';c.beginPath();c.ellipse(ix,iy,s*1.6,s*.45,0,0,6.283);c.fill();
    c.fillStyle='#9a7ad0';c.beginPath();c.moveTo(ix-s*1.4,iy);c.lineTo(ix,iy+s*1.3);c.lineTo(ix+s*1.4,iy);c.fill();c.fillStyle='#7fd6c8';c.beginPath();c.moveTo(ix-s*.3,iy+s*.3);c.lineTo(ix,iy+s*1.1);c.lineTo(ix+s*.3,iy+s*.3);c.fill();});}
function cloud(c,x,y,s,kind){c.fillStyle='rgba(255,240,255,.85)';const p=(a,b,r)=>{c.beginPath();c.arc(x+a*s,y+b*s,r*s,0,6.283);c.fill();};
  if(kind===0){p(0,0,22);p(26,-4,18);p(-24,4,16);p(44,-22,14);p(52,-36,6);p(40,-38,6);p(-44,-6,8);}
  else{p(0,0,24);p(-28,2,18);p(30,6,16);p(-48,-18,14);p(-54,-34,10);p(-40,-36,10);p(46,-8,7);}}
MODES.out=(c,dt)=>{farSky(c,dt,{home:V.home!==false});cloud(c,(V.t*14)%1300-150,420,1.1,0);cloud(c,1200-(V.t*10)%1400,520,.9,1);
  if(V.pr)planet2D(c,V.px,V.py,V.pr);
  V.puffs=V.puffs||[];if(V.smoke&&Math.random()<dt*6)V.puffs.push({x:V.sx-50*V.ss*Math.cos(V.sr),y:V.sy-50*V.ss*Math.sin(V.sr),r:8*V.ss,vx:-10,vy:-25,a:.6});
  V.puffs=V.puffs.filter(p=>{p.x+=p.vx*dt;p.y+=p.vy*dt;p.r+=dt*12*V.ss;p.a-=dt*.3;if(p.a<=0)return false;c.fillStyle=`rgba(110,105,120,${p.a})`;c.beginPath();c.arc(p.x,p.y,p.r,0,6.283);c.fill();return true;});
  if(V.ss)ship2D(c,V.sx,V.sy,V.ss,V.sr,{light:'off',flame:false});
  if(V.white){c.fillStyle=`rgba(255,250,255,${V.white})`;c.fillRect(0,0,1024,768);}};

/* ----------------- the crew in the cockpit ----------------- */
function crewAdd(id,p,x,y,sz){const d=el('div','bhP','<div class="hel"></div><div class="pic">'+art(p)+'</div>');d.style.left=x+'px';d.style.top=y+'px';if(sz)d.style.setProperty('--s',sz);SC.crew.appendChild(d);d.dataset.id=id;return d;}
function team(){return teamIds().map(id=>({id,p:pupById(id)})).filter(q=>q.p).slice(0,3);}
function crewSetup(){SC.crew.innerHTML='';const pw=PUPS.pawking,out=[];out.push(crewAdd('pawking',pw,34,560));
  team().forEach((q,i)=>out.push(crewAdd(q.id,q.p,700+i*104,566)));V.crew=out;return out;}

/* ================= the tour and the fall ================= */
const FACTS=['You can\'t actually see a black hole. That dark circle is its shadow. The glow round it is hot gas, swirling round and round, super fast!',
  'The edge of a black hole is called the event horizon. Past it, nothing can get out. Not even light! That\'s why it looks black.',
  'Its gravity is so strong that it bends light. See the glowing ring over the top? That\'s light from behind the black hole, bent round towards us!',
  'Near a black hole, time goes slower! If you stayed close to one for a while, you\'d come home and find everyone else had got older than you.',
  'Scientists took the first ever photo of a black hole in 2019. Then in 2022, they took a photo of the giant black hole in the middle of our own galaxy!',
  'And a fact from the real Stephen Hawking, who I\'m named after. He worked out that black holes glow very, very faintly. So they\'re not completely black after all!'];
BHQ.FACTS=FACTS;
function prompt(txt,x,y,w){return new Promise(res=>{const b=el('button','bhPrompt',txt);b.style.left=x+'px';b.style.top=y+'px';if(w)b.style.width=w+'px';SC.ui.appendChild(b);
  tap(b,()=>{b.remove();res();});V.onSkip=()=>{b.remove();res();};});}
/* hold on to your pups: they float apart, Seb taps each one to pull it close */
function huddle(){const pups=V.crew.filter(d=>d.dataset.id!=='pawking');if(!pups.length)return wait(1200);
  return new Promise(res=>{let left=pups.length;const done=()=>{if(left<=0)return;left=0;clearTimeout(tm);res();};
    pups.forEach((d,i)=>{d.classList.add('drift');d.style.transform=`translate(${-120-i*70}px,${-190-(i%2)*70}px) rotate(${(i%2?1:-1)*25}deg)`;
      tap(d,()=>{if(!d.classList.contains('drift'))return;d.classList.remove('drift');d.style.transform='';sfx.yip((pupById(d.dataset.id)||{}).pitch||1);
        const h=el('div','bhHeart','💖');h.style.left=(parseInt(d.style.left)+40)+'px';h.style.top=(parseInt(d.style.top)-20)+'px';SC.ui.appendChild(h);setTimeout(()=>h.remove(),1200);
        left--;if(left<=0){left=1;done();}});});
    const tm=setTimeout(()=>{pups.forEach(d=>{d.classList.remove('drift');d.style.transform='';});done();},16000/BHQ.FAST);V.onSkip=()=>{pups.forEach(d=>{d.classList.remove('drift');d.style.transform='';});done();};});}
async function tourFall(mode){const B=S(),PW=PUPS.pawking;open('cock');crewSetup();V.sp='hole';V.warn='blink';V.pl=0;V.hole={x:600,y:250,r:7};V.flow=.03;V.lever=0;
  const eng=humOn(.05,62);
  if(B.seenFall&&mode!=='again'){$('#bhSkip').style.display='block';}
  try{
    await go(cap(PW,'Welcome aboard the Stargazer, Seb! Bubble helmets on, pups. Off we go!'));
    tw(V,'pl',800,7);tw(V.hole,'r',18,9);V.flow=.12;sfx.chime();
    await go(wait(1800));
    await go(cap(PW,'Oh, that little red light? Don\'t worry. It always does that.'));
    for(let i=0;i<FACTS.length;i++){tw(V.hole,'r',22+i*5,6);tw(V.hole,'x',600-i*12,6);await go(cap(PW,FACTS[i]));}
    if(mode==='again'){await go(cap(PW,'And that\'s the end of the tour! The engine works perfectly now, thanks to ten alien puppies. Back we go!'));eng.stop();closeScr();backToBooth('Thanks for coming on the Black Hole Tour!');return;}
    await go(cap(PW,'Right, team. Time to turn round and go home.',{dur:3}));
    V.peb={x:1080,y:60,s:22};tw(V.peb,'x',740,1.1);tw(V.peb,'y',430,1.1);snd.whooshDown(1);await go(wait(1100));
    snd.clonk();shakeS(1,.9);flash(.7);V.peb=null;V.warn='alarm';V.alarm=1;eng.set(.0001);setTimeout(()=>snd.cough(),300);
    let hi=0;loop(420,()=>snd.siren(hi=!hi));
    await go(cap(PW,'CLONK! A space pebble hit the engine!',{dur:3}));
    await go(cap(PW,'Oh dear. The engine has stopped!',{dur:3}));
    const deep=humOn(.08,40);tw(V.hole,'x',512,5);tw(V.hole,'y',290,5);tw(V.hole,'r',70,10);tw(V,'streak',.12,6);V.flow=.25;
    cap(PW,'The black hole is pulling us in! Quick, Seb! Pull the big lever to start the engine!',{noNext:true,dur:60});
    await go(prompt('👇 PULL!',588,500,110));capOff();
    snd.clank();await tw(V,'lever',1,.35);snd.snap();shakeS(.4,.3);V.lever=2;V.hand={x:640,y:560,r:0};tw(V.hand,'y',200,.5);tw(V.hand,'x',560,.5);tw(V.hand,'r',4,.5);setTimeout(()=>{if(V.hand){tw(V.hand,'y',900,.8);tw(V.hand,'r',8,.8);}},500/BHQ.FAST);
    await go(cap(PW,'Oh no! The lever snapped right off!',{dur:3}));
    deep.set(.16,34);tw(V.hole,'r',120,8);tw(V,'streak',.3,6);
    cap(PW,team().length?'We\'re being pulled in! Hold on to your pups, Seb! Tap each one to pull it close!':'We\'re being pulled in! Hold on tight, Seb!',{noNext:true,dur:60});
    await go(huddle());capOff();
    await go(cap(PW,'Everybody hold on tight. Here we go!',{dur:2.6}));
    /* the fall: over the glowing edge */
    deep.set(.3,26);tw(V.hole,'r',1400,2.6);V.flow=.8;tw(V,'streak',.8,2);snd.whoosh(2.4);await go(wait(1900));
    V.ring=.01;tw(V,'ring',1,1);flash(1);shakeS(1,1.2);await go(wait(900));
    V.sp='stretch';V.alarm=0;V.warn='off';stopSounds();const pull=humOn(.18,30);V.flow=2.2;V.streak=1.2;
    V.crew.forEach(d=>d.classList.add('spag'));snd.slide();big('Stretched like spaghetti!','spag');
    await go(cap(PW,'Whoa! We\'re being stretched like spaghetti! Scientists really call this spaghettification!',{dur:6.5}));
    /* dark */
    pull.stop();V.sp='black';V.dark=1;V.crew.forEach(d=>{d.classList.remove('spag');d.classList.add('gone');});
    V.eyes=V.crew.map(d=>({x:parseInt(d.style.left)+59,y:parseInt(d.style.top)+52}));capOff();
    snd.heart();loop(1150,()=>snd.heart());await go(wait(2600));
    const bud=team()[0];await go(cap(bud?bud.p:null,bud?`It's very dark. ${bud.p.name} gives your helmet a big lick. Slurp! You're all here together.`:'It\'s very dark and very quiet. But you\'re all here together.',{dur:5}));
    await go(cap(PW,'Hold on tight, team. I can see something!',{dur:3.4}));
    /* a pinprick of light grows */
    capOff();V.sp='pin';V.pin=1;V.dark=0;V.eyes=null;V.crew.forEach(d=>d.classList.remove('gone'));tw(V,'pin',70,4.5);const rise=humOn(.05,90);rise.set(.12,220);await go(wait(4500));
    /* the rainbow tunnel, then out */
    stopSounds();V.sp='tunnel';V.tsp=2.6;snd.whoosh(2.8);shakeS(.5,2.6);await go(wait(2600));
    V.sp='burst';V.flow=.03;V.streak=0;flash(1);snd.whoosh(.8);sfx.fanfare();V.smoke=1;
    B.seenFall=Date.now();save();
    big('WHOOSH!','whoosh');
    await go(cap(PW,'WOW! We came out the other side! Look, Seb. Two suns! A pink one and a blue one!'));
    await go(cap(PW,'In real life, nothing ever comes back out of a black hole. I think we fell through a wormhole hiding right next to it!'));
    await go(cap(PW,'A wormhole is a tunnel through space. Scientists have imagined them, but nobody has ever found one. Until now!'));
    await go(cap(PW,'See that tiny swirl? That\'s our galaxy. Home is all the way over there!'));
    await go(cap(PW,'Uh oh. The engine is smoking, and the lever is broken. We can\'t go back the way we came. Look, a planet! Let\'s land and find help.'));
    await descent();
  }catch(e){if(e!==SKIP)console.warn('bh tour',e);stopSounds();closeScr();if(mode==='again'){backToBooth();return;}B.seenFall=B.seenFall||Date.now();save();land();}}
BHQ.tourFall=tourFall;
/* the slow descent to the candy planet */
async function descent(){capOff();V.mode='out';V.px=512;V.py=1500;V.pr=820;V.sx=1120;V.sy=200;V.ss=.9;V.sr=.2;V.smoke=1;V.flow=.01;V.home=false;
  SC.crew.innerHTML='';const tn=tune([784,0,988,0,1175,0,1568,0,1175,0,988,0,880,0,1047,0],300,'sine',.07);loop(2200,()=>snd.chirp());
  V.tick=dt=>{V.ang=(V.ang||0)+dt*.5;};
  tw(V,'sx',300,6);tw(V,'sy',260,6);tw(V,'sr',-.15,6);tw(V,'py',1250,10);tw(V,'pr',1000,10);
  await go(cap(null,'The Stargazer limps down in slow, wobbly circles towards a strange, candy-coloured planet.',{dur:5}));
  tw(V,'sx',760,5);tw(V,'sy',380,5);tw(V,'ss',.6,5);tw(V,'sr',.25,5);
  await go(cap(null,'Jelly hills! Crystal trees! Floating islands! And look, that cloud is shaped like a puppy!',{dur:5}));
  tw(V,'sx',512,4);tw(V,'sy',470,4);tw(V,'ss',.35,4);tw(V,'sr',.6,4);tw(V,'py',1700,4.5);tw(V,'pr',1700,4.5);
  await go(cap(PW_(),'Hold on, everyone. Landing in the glowing flower meadow!',{dur:3.6}));
  tw(V,'white',1,1.2);await go(wait(1300));stopLoop(tn);closeScr();land();}
const PW_=()=>PUPS.pawking;

/* ================= landing on the planet (3D) ================= */
let stash=null;
function hideTeam(){stash=followers.splice(0);stash.forEach(f=>scene.remove(f.grp));player.grp.visible=false;}
function showTeam(at){player.grp.visible=true;if(stash){stash.forEach(f=>{scene.add(f.grp);followers.push(f);});stash=null;}
  if(at)followers.forEach((f,i)=>{f.x=at[0]+(i-1)*1.4;f.z=at[1]+1.5+i*.4;f.grp.userData.jump=.6;});}
BHQ.hideTeam=hideTeam;BHQ.showTeam=showTeam;
/* the camera can be taken over for a scene: W.cine={cam(dt)} */
let cs={a:0,t:0};function cineShake(a,s){cs.a=Math.max(cs.a,a);cs.t=Math.max(cs.t,s);}
const _cu=camUpdate;camUpdate=function(dt){if(W.cine&&W.cine.cam){W.cine.cam(dt||0);if(cs.t>0){cs.t-=dt||.016;const a=cs.a*Math.min(1,cs.t*2);cam.position.x+=(Math.random()-.5)*a;cam.position.y+=(Math.random()-.5)*a;cam.position.z+=(Math.random()-.5)*a;}else cs.a=0;return;}return _cu.apply(this,arguments);};
BHQ.cineShake=cineShake;
function land(){const B=S();show('world');enterArea('alien',null,null);if(!W.area||W.area.id!=='alien')return;
  const A=BHQ.alien;if(!A||!A.ship){player.lock=false;return;}
  const sh=A.ship,K=A.K,u=sh.userData;hideTeam();player.lock=true;player.x=K[0]+4.2;player.z=K[1]+1.4;player.h=Math.PI/2;
  const y0=sh.position.y;sh.position.y=y0+34;let t=0,bumped=false,opened=false;u.body.rotation.z=.6;
  loop(2600,()=>snd.chirp());const eh=humOn(.06,52);
  W.cine={cam(dt){t+=dt;const k=Math.min(1,t/5.5),e=1-(1-k)*(1-k);sh.position.y=y0+34*(1-e)+Math.sin(t*3)*.4*(1-k);u.body.rotation.z=.6*(1-e)+.22*e;sh.rotation.y=Math.sin(t*1.3)*(1-k)*.4;
      if(Math.random()<dt*8*(1-k*.5))floatS('💨',sh.position.x-1+Math.random()*2,sh.position.y+2,sh.position.z-4,1.6,1.2);
      if(k>=1&&!bumped){bumped=true;eh.stop();snd.thump();snd.squish();cineShake(.8,.7);sh.position.y=y0;floatS('💥',K[0],gy(K[0],K[1])+1.5,K[1],3);for(let i=0;i<5;i++)floatS('💨',K[0]-3+i*1.5,gy(K[0],K[1])+1,K[1]+(i%2)*2,2,1.6);}
      if(t>7&&!opened){opened=true;u.hatch.rotation.z=-1.35;snd.clank();}
      if(t>8.2&&!player.grp.visible){showTeam([player.x+1.2,player.z]);snd.squish();player.cheer=1.2;say('Squish! The ground is soft and bouncy. Strange birds are singing.');}
      const cx=K[0]+16,cz=K[1]+20,cy=gy(K[0],K[1])+9+Math.max(0,(1-t/6))*14;cam.position.set(cx,cy,cz);cam.lookAt(K[0],sh.position.y+2.5,K[1]);
      if(t>10.5){W.cine=null;stopSounds();B.landed=B.landed||Date.now();save();const lk=A.look||[0,0];player.h=Math.atan2(lk[0]-player.x,lk[1]-player.z);W.camYaw=player.h;camUpdate(0,true);if(!B.name)nameCard(()=>{player.lock=false;BHQ.afterName&&BHQ.afterName();});else player.lock=false;}}};}
BHQ.land=land;
/* Seb names the planet */
const SUG=['Planet Seb','Jellybean World','Planet Zibble-Zoom','Wobbleberry'];
function cleanName(s){s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,22);if(!s)return '';return s.charAt(0).toUpperCase()+s.slice(1);}
function nameCard(done){const B=S();player.lock=true;sfx.chime();
  card({art:'<div style="font-size:96px;line-height:1">🪐</div>',h:'Name the planet!',p:`You are the very first explorer ever to land here, so you get to name it!<input id="bhName" maxlength="22" autocomplete="off" placeholder="Type a name..."><span class="bhSug">${SUG.map(s=>`<button class="opt">${s}</button>`).join('')}</span>`,
    say:'You are the very first explorer ever to land here, so you get to name it! Type a name, or pick one.',
    btns:[['✓ That\'s its name!','green',()=>{const n=cleanName($('#bhName').value)||pick(SUG);B.name=n;save();hud();sfx.fanfare();confetti(50);player.cheer=1.6;
      say(`Welcome to ${n}! You are the first explorer ever to set foot here.`);if(BHQ.flag)BHQ.flag();if(done)done();}]]});
  const inp=$('#bhName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .bhSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));}
BHQ.nameCard=nameCard;

/* ================= the flight home and the homecoming ================= */
async function flyHome(){const B=S();open('flight');V.mode='flight';V.sx=0;V.sy=0;V.tx=0;V.ty=0;V.rings=[];V.hit=0;V.total=12;V.made=0;V.tz=0;V.tsp=1.4;V.bye=1;
  const fam=[BHQ.ZUZU].concat(BHQ.APUPS||[]);fam.forEach((p,i)=>{const d=crewAdd(p.id,p,i?150+((i-1)%5)*150+(i>5?70:0):452,i?(i>5?610:500):330,i?.7:1.1);d.classList.add('bye');d.querySelector('.hel').style.display='none';});
  V.ptr=(k,x,y)=>{if(k==='up')return;V.tx=Math.max(-330,Math.min(330,x-512));V.ty=Math.max(-160,Math.min(220,y-430));};
  const tn=tune([523,659,784,1047,784,659,784,0,587,698,880,1175,880,698,880,0],260,'triangle',.08);
  try{await go(cap(BHQ.ZUZU,'Beep beep! Goodbye, Seb! Thank you for finding my puppies! Follow the star map home!',{dur:4.5}));
    SC.crew.querySelectorAll('.bhP').forEach(d=>{d.style.opacity=0;});V.bye=0;snd.whoosh(2);
    await go(cap(null,'Drag your finger to steer the Stargazer through the rings of light!',{dur:4}));capOff();
    for(let i=0;i<V.total;i++){V.rings.push({x:(Math.random()-.5)*520,y:(Math.random()-.5)*260+30,z:1,h:(i*40)%360});await go(wait(1900));}
    await go(wait(2400));
    flash(1);snd.whoosh(1);sfx.fanfare();await go(cap(null,V.hit>=V.total-2?`Brilliant flying! You went through ${V.hit} rings of light!`:`Great flying! You went through ${V.hit} rings of light!`,{dur:3.6}));
  }catch(e){if(e!==SKIP)console.warn(e);}
  stopLoop(tn);closeScr();homecoming();}
BHQ.flyHome=flyHome;
MODES.flight=(c,dt)=>{if(V.bye){farSky(c,dt,{home:false});planet2D(c,512,1320,820);return;}tunnel(c,dt,true);V.sx+=(V.tx-V.sx)*Math.min(1,dt*5);V.sy+=(V.ty-V.sy)*Math.min(1,dt*5);
  const cx=512,cy=300;V.rings=V.rings.filter(r=>{r.z-=dt*.42;if(r.z<=.08){if(!r.done){r.done=1;const d=Math.hypot(r.x-V.sx,r.y-V.sy);if(d<115){V.hit++;snd.ring();big('✨','ringhit');}else snd.whooshDown(.5);}return false;}
    const s=.12/r.z,f=Math.min(1,.15/r.z),x=cx+r.x*f,y=cy+(r.y+130)*f,R=90*s,a=Math.min(1,(1-r.z)*2);glow(c,x,y,R*.75,R*1.35,`hsla(${r.h},100%,75%,${.45*a})`);
    c.strokeStyle=`rgba(255,255,255,${a})`;c.lineWidth=Math.max(4,R*.2);c.beginPath();c.arc(x,y,R,0,6.283);c.stroke();c.strokeStyle=`hsla(${r.h},100%,70%,${a})`;c.lineWidth=Math.max(2,R*.09);c.stroke();return true;});
  const x=512+V.sx,y=430+V.sy;glow(c,x,y+8,0,80,'rgba(255,170,70,.55)');c.save();c.translate(x,y);c.rotate((V.tx-V.sx)*.002);c.strokeStyle=INKC;c.lineWidth=4;c.lineJoin='round';c.fillStyle='#e8423a';
  [[-1,1],[1,1]].forEach(q=>{c.beginPath();c.moveTo(q[0]*26,4);c.lineTo(q[0]*74,34);c.lineTo(q[0]*70,46);c.lineTo(q[0]*22,24);c.closePath();c.fill();c.stroke();});
  c.beginPath();c.moveTo(-9,-30);c.lineTo(0,-76);c.lineTo(9,-30);c.closePath();c.fill();c.stroke();
  c.fillStyle='#f4ecd8';c.beginPath();c.arc(0,4,38,0,6.283);c.fill();c.stroke();c.strokeStyle='#e8423a';c.lineWidth=9;c.beginPath();c.arc(0,4,30,0,6.283);c.stroke();c.strokeStyle=INKC;c.lineWidth=4;
  c.fillStyle='#5b6378';c.beginPath();c.arc(0,4,17,0,6.283);c.fill();c.stroke();const fl=10+Math.sin(V.t*30)*3;glow(c,0,4,0,fl*2.2,'rgba(255,200,90,.9)');c.fillStyle='#fff3a0';c.beginPath();c.arc(0,4,fl*.6,0,6.283);c.fill();c.restore();
  c.font='900 30px sans-serif';c.textAlign='left';c.fillStyle='#fff';c.strokeStyle=INKC;c.lineWidth=6;const tx=`✨ ${V.hit} / ${V.total}`;c.strokeText(tx,24,744);c.fillText(tx,24,744);};
/* back beside the Black Hole planet: fireworks, Captain Nibbles and Nebula */
function homecoming(){const B=S();BHQ.homing=true;show('world');enterArea('blackhole',[DOCK[0]+5,DOCK[1]-6,Math.PI],null);hideTeam();player.lock=true;
  const sh=BHQ.dockShip;if(!sh){showTeam();player.lock=false;finale();return;}const u=sh.userData,y0=sh.position.y;sh.position.y=y0+30;u.flame.visible=true;
  const nb=nibbles3D();add(nb,DOCK[0]-7,DOCK[1]-9);nb.rotation.y=.6;const IS=islandOf('planet'),neb=pup3D(IS.boss.uni,true);add(neb,DOCK[0]-10,DOCK[1]-5);neb.rotation.y=1;
  let t=0,landed=false,out=false,fw=0;const eh=humOn(.06,70);
  W.ticks.push(dt=>{nb.position.y=gy(nb.position.x,nb.position.z)+Math.abs(Math.sin(W.t*4))*.5;animPup(neb,W.t,false);if(!W.cine&&t>20)return false;});
  W.cine={cam(dt){t+=dt;const k=Math.min(1,t/4.5),e=1-(1-k)*(1-k);sh.position.y=y0+30*(1-e);if(k>=1&&!landed){landed=true;eh.stop();snd.thump();cineShake(.5,.5);u.flame.visible=false;}
      if(t>5.5&&!out){out=true;u.hatch.rotation.z=-1.35;snd.clank();showTeam([DOCK[0]+5,DOCK[1]-3]);player.cheer=2;player.wave=2;}
      if(t>3&&(fw-=dt)<0){fw=.35;const x=DOCK[0]-12+Math.random()*24,z=DOCK[1]-14+Math.random()*10;floatS(pick(['🎆','🎇','✨','🌟']),x,gy(x,z)+14+Math.random()*6,z,4,1.4);if(fxOk())T(300+Math.random()*500,0,.4,'sawtooth',.05,80);}
      cam.position.set(DOCK[0]+14,gy(DOCK[0],DOCK[1])+8,DOCK[1]-16);cam.lookAt(DOCK[0]-2,sh.position.y+2,DOCK[1]-2);
      if(t>8){W.cine=null;stopSounds();W.camYaw=Math.PI;camUpdate(0,true);finale();}}};}
function finale(){const B=S(),IS=islandOf('planet');BHQ.homing=false;confetti(80);sfx.fanfare();
  const z=`<div class="fitsvg" style="width:130px">${art(BHQ.ZUZU)}</div>`,sb=`<div class="fitsvg" style="width:110px">${sebSVG(true)}</div>`,nb='<div style="font-size:90px;line-height:1">🐹</div>',un=`<div class="fitsvg" style="width:130px">${critterSVG(IS.boss.uni)}</div>`;
  story([{art:nb+un,t:`Captain Nibbles squeaks with joy. "Seb! You fell into the black hole, and you came back! Where have you been?"`},
    {art:sb+z,t:`"Through a wormhole, all the way to ${pname()}! We found ten alien puppies for their mum, Zuzu, and the puppies fixed our ship!"`},
    {art:un,t:`Nebula the Galaxy Unicorn smiles. "Seb, you are the first explorer ever to go through a black hole and come back!"`}],()=>{
    B.done=B.done||Date.now();state.certs=state.certs||{};state.certs.blackhole=Date.now();state.stars+=100;save();hud();sfx.fanfare();confetti(90);
    card({cls:'cert',art:`${sb}<div style="font-size:84px;line-height:1">🌀</div>${z}`,h:'Certificate',h3:'🏅 Black Hole Explorer',p:`Awarded to <b>Seb</b>, the first explorer to go through a black hole and come back! Plus 100 stars.`,
      say:'Certificate! Black Hole Explorer! Awarded to Seb, the first explorer to go through a black hole and come back! Plus 100 stars.',
      btns:[['🎉 Hooray!','green',()=>{card({art:z,h:'See you soon, Zuzu!',p:`Zuzu and her ten puppies say they will fly through the wormhole to dance at the big party on the Moon! And there's a new card pack for ${pname()}.`,
        btns:[['👍 OK','green',()=>{player.lock=false;try{CARDS.announce();}catch(e){}rebuildBooth();say('You can fly the Stargazer back to visit Zuzu any time from Black Hole Tours.');}]]});}]]});});}
BHQ.homecoming=homecoming;

/* ================= Black Hole Tours, on the Black Hole planet ================= */
const BOOTH=[-7,27],DOCK=[3,33];
function clearZone(x,z,r){for(const k in instMap){const o=instMap[k];o.m=o.m.filter(m=>{const e=m.elements;return Math.hypot(wd(e[12]-x),wd(e[14]-z))>r;});}
  W.cols=W.cols.filter(c=>Math.hypot(wd(c.x-x),wd(c.z-z))>r);}
let boothBits=[];
function buildBooth(){boothBits.forEach(o=>{W.ag.remove(o);});boothBits=[];W.things=W.things.filter(t=>!t.bh);BHQ.dockShip=null;
  const B=S(),keep=o=>{boothBits.push(o);return o;};
  {const [x,z]=BOOTH,y=gy(x,z),k=keep(grp());
    mk('box','#7a3fb0',4.2,2.4,2.6,0,1.2,0,k);[-1.5,-.5,.5,1.5].forEach((dx,i)=>mk('box',i%2?'#ffd23f':'#7a3fb0',1,.5,2.75,dx,2.2,0,k));mk('box','#f4ecd8',4.4,.2,3,0,2.5,.1,k);
    mk('cyl','#c9d2e3',.12,3,.12,-2,4,1.2,k);mk('cyl','#c9d2e3',.12,3,.12,2,4,1.2,k);const aw=mk('box','#ff5fa8',4.8,.25,2.2,0,5.5,.6,k);aw.rotation.x=-.25;
    for(let i=0;i<5;i++)mk('box',i%2?'#ffffff':'#ff5fa8',.96,.27,2.22,-1.92+i*.96,5.52,.6,k).rotation.x=-.25;
    const sw=mk('sph','#000',.55,.55,.1,0,3.8,-1.32,k);sw.rotation.x=0;const ring=new THREE.Mesh(G.ring,new THREE.MeshBasicMaterial({color:'#ffd27a'}));ring.scale.setScalar(.85);ring.position.set(0,3.8,-1.35);k.add(ring);W.disp.push(ring.material);
    k.rotation.y=Math.PI;add(k,x,z,y);col(x,z,2.4);
    const lb=keep(label('🌀 Black Hole Tours',7));lb.position.set(x,y+7.6,z);W.ag.add(lb);
    if(isFound('pawking')){const pw=keep(pup3D(PUPS.pawking));add(pw,x+3.4,z-1.6);pw.rotation.y=Math.PI*.85;W.ticks.push(()=>{if(pw.parent)animPup(pw,W.t,false);else return true;});}
    W.things.push({bh:1,x,z:z-3,r:4.6,icon:'🌀',label:'Tours',act:booth});}
  {const [x,z]=DOCK,y=gy(x,z),pad=keep(grp());mk('cyl','#c9d2e3',5.2,.4,5.2,0,.2,0,pad);mk('cyl','#5b6378',4.6,.06,4.6,0,.42,0,pad);
    const rg=new THREE.Mesh(G.ring,new THREE.MeshBasicMaterial({color:'#c9b6ff'}));rg.scale.setScalar(4.8);rg.rotation.x=Math.PI/2;rg.position.y=.46;pad.add(rg);W.disp.push(rg.material);add(pad,x,z,y);
    W.ticks.push(()=>{if(!pad.parent)return true;rg.material.color.setHSL(.75+Math.sin(W.t*2)*.05,.8,.7);});
    const away=B.seenFall&&!B.done&&!BHQ.homing;
    if(!away){const sh=keep(stargazer3D({map:!!B.done}));sh.rotation.y=Math.PI;add(sh,x,z,y+.4);col(x,z,3.2);col(x,z-4,2);col(x,z+4,2);BHQ.dockShip=sh;const u=sh.userData;u.flame.visible=false;
      W.ticks.push(()=>{if(!sh.parent)return true;u.wm.color.set((W.t%1.7)<.3?'#ff3a3a':'#5a2020');});
      W.things.push({bh:1,x:x+3.6,z:z-2,r:3.8,icon:'🚀',label:'Stargazer',act:booth});}
    else{const s=keep(spr('🌠',3.2,x,y+4,z));W.ticks.push(()=>{if(!s.parent)return true;s.position.y=y+4+Math.sin(W.t*2)*.5;});W.things.push({bh:1,x,z,r:4.2,icon:'🌠',label:'Shooting star',act:booth});}}}
function rebuildBooth(){if(W.area&&W.area.id==='blackhole')buildBooth();}
function waitBooth(){W.ticks.push(()=>{if(!W.area||W.area.id!=='blackhole')return true;if(state.islDone.planet&&!ovOpen()&&!player.lock){buildBooth();bakeSweep();
  setTimeout(()=>say('Look! Black Hole Tours has opened, next to the hop pads. Take a tour in the Stargazer with Stephen Pawking!'),1500);return true;}});}
const bhA=AREAS.blackhole,_bb=bhA.build;
bhA.build=function(){const r=_bb.apply(this,arguments);clearZone(0,31,11);if(state.islDone.planet)buildBooth();else waitBooth();return r;};
function backToBooth(msg){show('world');enterArea('blackhole',[BOOTH[0]+2,BOOTH[1]-6,Math.PI],msg||null);}
function booth(){if(player.lock)return;const B=S(),pw=PUPS.pawking;sfx.chime();
  if(!isFound('pawking'))return say('Black Hole Tours! Oh no, the tour guide, Stephen Pawking, is missing. He is near the glowing crystals, next to a telescope. Can you find him?');
  const pa=`<div class="fitsvg" style="width:140px">${critterSVG(pw)}</div>`;
  if(!B.seenFall||(!B.landed&&!B.done)){card({art:pa,h:'Black Hole Tours',p:'Fly up close to the black hole in the Stargazer, with Stephen Pawking as your guide! Your pups can come too.',
      btns:[['🚀 Let\'s go!','green',()=>{player.lock=true;tourFall('first');}],['Not now','white',()=>{}]]});return;}
  if(!B.done){card({art:'<div style="font-size:110px;line-height:1">🌠</div>',h:`Back to ${pname()}?`,p:`Zuzu has sent a shooting star to fetch you! It can whoosh you back through the wormhole. Her puppies are waiting for you.`,
      btns:[['🌠 Whoosh!','green',()=>{player.lock=true;fadeTo(()=>enterArea('alien',null,null),['🌠',`The shooting star whooshes you through the wormhole to ${pname()}!`]);}],['Not now','white',()=>{}]]});return;}
  card({art:pa,h:'Black Hole Tours',p:`The Stargazer is fixed, and Zuzu's star map shows the way through the wormhole.`,
    btns:[[`🚀 Fly to ${pname()}`,'green',()=>{player.lock=true;fadeTo(()=>enterArea('alien',null,null),['🚀',`The Stargazer zooms through the wormhole to ${pname()}!`]);}],['🔭 Tour again','blue',()=>{player.lock=true;tourFall('again');}],['Not now','white',()=>{}]]});}
BHQ.booth=booth;BHQ.buildBooth=buildBooth;BHQ.DOCK=DOCK;BHQ.BOOTH=BOOTH;

/* ================= cards, badges and the certificate ================= */
TYPES.alien={name:'Alien',icon:'👽',col:'#a86fe0',power:'beams messages with glowing antennae'};
const aFound=()=>(BHQ.APUPS||[]).filter(p=>S().found[p.id]).length;BHQ.aFound=aFound;
let XSET=null;
window.XCARDS=[{isl:'alien',keys:()=>['x:alien'],
  set(){if(XSET)return XSET;const L=(BHQ.APUPS||[]).concat(BHQ.ZUZU?[BHQ.ZUZU]:[]),of=L.length;if(!of)return null;
    XSET={id:'3:alien',game:3,x:true,isl:'alien',get name(){return pname()==='the alien planet'?'The Alien Planet':pname();},get short(){return 'Alien';},icon:'👽',
      open:()=>!!(state&&state.islDone.planet),lockSay:()=>'Help Nebula on Planet Hop first. Then take the Black Hole Tour!',
      cards:L.map((p,i)=>{const c={cid:'3:'+p.id,game:3,set:'3:alien',n:i+1,of,src:{sci:true,alien:true},base:p.id,name:p.name,breed:p.breed,type:'alien',rar:'alien',fact:p.card,
        stats:Object.assign({},p.stats),zoom:p.zoom||80,moves:p.moves,col:TYPES.alien.col,bg:p.bg||'#efe2ff'};
        c.home=()=>p.mum?pname()==='the alien planet'?'The alien planet':pname():(p.where||'')+', '+(pname()==='the alien planet'?'the alien planet':pname());
        c.earned=()=>p.mum?!!(state.bh&&state.bh.done):!!(state.bh&&state.bh.found[p.id]);
        c.foundAt=()=>{const v=p.mum?state.bh&&state.bh.done:state.bh&&state.bh.found[p.id];return typeof v==='number'&&v>1e12?v:0;};
        c.art=an=>alienSVG(p,{anim:an});
        c.hint=()=>!(state.bh&&state.bh.seenFall)?'Take the Black Hole Tour on Planet Hop, and see where it takes you!':p.mum?'Find all ten puppies and fly home, to win Zuzu\'s card!':`Help Zuzu find ${p.name}. ${p.hint||''}`;
        return c;})};return XSET;},
  ids(){if(!state||!state.bh)return [];const ids=Object.keys(state.bh.found).map(id=>'3:'+id);if(state.bh.done&&BHQ.ZUZU)ids.push('3:'+BHQ.ZUZU.id);return ids;},
  key(cid){return cid.indexOf('3:al_')===0?'x:alien':undefined;},
  done(){return !!(state.bh&&state.bh.done);},
  info(k){return {k,isl:'alien',icon:'👽',name:pname()==='the alien planet'?'The Alien Planet':pname(),short:pname()==='the alien planet'?'Alien Planet':pname()};},
  say(k,c){return state.bh&&state.bh.done?'This card is in a pack that is ready to open. Tap the pack!':`${c.name}'s card is waiting in the ${pname()} pack. Help Zuzu find all her puppies and fly home to open it!`;}}];
MERITS.push(
  {id:'planetname',icon:'🪧',name:'Planet Namer',how:'Be the first explorer to land on a new planet, and give it a name.',ok:()=>!!(state.bh&&state.bh.name)},
  {id:'alienpups',icon:'👽',name:'Alien Puppy Finder',how:'Help Zuzu find all 10 of her alien puppies.',ok:()=>aFound()>=10},
  {id:'wormhole',icon:'🌀',name:'Wormhole Explorer',how:'Fall through the wormhole by the black hole, and fly home again.',ok:()=>!!(state.bh&&state.bh.done)});
CERTS.push({id:'blackhole',icon:'🌀',title:'Black Hole Explorer',why:'for being the first explorer to go through a black hole and come back',ok:()=>!!(state.bh&&state.bh.done)});

/* ----------------- styles ----------------- */
{const st=document.createElement('style');st.textContent=`
body.bhDark{background:#05030f}#bhcut{background:#05030f}#bhC{position:absolute;left:0;top:0;width:1024px;height:768px}
#bhCrew,#bhUI{position:absolute;left:0;top:0;width:1024px;height:768px;pointer-events:none}
#bhCrew .bhP{position:absolute;width:118px;height:124px;pointer-events:auto;transform:scale(var(--s,1));transform-origin:50% 100%;transition:transform 2.6s cubic-bezier(.25,.9,.4,1),opacity .8s}
#bhCrew .bhP .hel{position:absolute;left:-6px;top:-10px;width:130px;height:132px;border-radius:50%;background:radial-gradient(circle at 34% 28%,rgba(255,255,255,.5),rgba(190,230,255,.16) 38%,rgba(160,210,255,.1) 70%);border:4px solid rgba(220,240,255,.8);box-sizing:border-box;pointer-events:none;z-index:2}
#bhCrew .bhP .pic svg{width:118px;height:124px;display:block}
#bhCrew .bhP.drift{animation:bhWob 1.2s ease-in-out infinite alternate}#bhCrew .bhP.drift .hel{border-color:#ff7f7f}
@keyframes bhWob{from{margin-top:-6px}to{margin-top:8px}}
#bhCrew .bhP.spag{transform:scale(.42,2.1);transition:transform 1.4s ease-in}#bhCrew .bhP.gone{opacity:0}
#bhCrew .bhP.bye{transition:opacity 2.4s,transform 2.4s}
#bhCap{position:absolute;left:96px;right:96px;top:12px;min-height:76px;background:#fffdf5;border:5px solid #26232e;border-radius:26px;display:none;align-items:center;gap:12px;padding:8px 18px;font-size:25px;font-weight:900;line-height:1.25;color:#26232e;box-shadow:0 6px 0 rgba(0,0,0,.35);z-index:5}
#bhCap.on{display:flex}#bhWho{width:74px;height:76px;flex:none;display:none;margin:-4px 0}#bhWho svg{width:74px;height:78px}
#bhNext{position:absolute;right:10px;top:18px;display:none;z-index:6}#bhSkip{position:absolute;right:16px;bottom:16px;display:none;z-index:6}
#bhFlash{position:absolute;left:0;top:0;width:1024px;height:768px;background:#fff;opacity:0;pointer-events:none;z-index:8}
#bhBig{position:absolute;left:0;right:0;top:300px;text-align:center;font-size:76px;font-weight:900;color:#fff;-webkit-text-stroke:7px #26232e;paint-order:stroke;opacity:0;pointer-events:none;z-index:7}
#bhBig.on{animation:bhBig 2.6s ease-out forwards}#bhBig.spag{font-size:56px}#bhBig.spag.on{animation:bhSpag 3.2s ease-in-out forwards}#bhBig.ringhit.on{animation:bhBig .9s ease-out forwards;font-size:120px;-webkit-text-stroke:0}
@keyframes bhBig{0%{opacity:0;transform:scale(.4)}15%{opacity:1;transform:scale(1.15)}70%{opacity:1;transform:scale(1)}100%{opacity:0;transform:scale(1.05)}}
@keyframes bhSpag{0%{opacity:0;transform:scale(1,1)}20%{opacity:1;transform:scale(.6,2.2)}50%{transform:scale(1.4,.7)}80%{opacity:1;transform:scale(.7,1.8)}100%{opacity:0;transform:scale(.5,2.6)}}
.bhPrompt{position:absolute;pointer-events:auto;height:84px;border-radius:42px;border:5px solid #26232e;background:#ffd23f;font-size:32px;font-weight:900;color:#26232e;box-shadow:0 6px 0 rgba(0,0,0,.35);animation:bhPulse .8s ease-in-out infinite alternate;z-index:6}
@keyframes bhPulse{from{transform:scale(1)}to{transform:scale(1.12)}}
.bhHeart{position:absolute;font-size:44px;animation:bhUp 1.2s ease-out forwards;pointer-events:none;z-index:6}@keyframes bhUp{to{transform:translateY(-70px);opacity:0}}
#bhName{display:block;width:420px;margin:12px auto 8px;font-size:30px;font-weight:900;padding:10px 16px;border:4px solid #26232e;border-radius:18px;text-align:center;font-family:inherit;color:#26232e}
#celeCard .bhSug{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;margin-top:4px}#celeCard .bhSug .opt{font-size:20px}
.mc.r-alien{background:conic-gradient(#b58cff,#7fe0ff,#8fe39a,#ff9ee0,#b58cff)}.tc.r-alien .front{background:conic-gradient(#b58cff,#7fe0ff,#8fe39a,#ff9ee0,#b58cff)}`;document.head.appendChild(st);}
})();
