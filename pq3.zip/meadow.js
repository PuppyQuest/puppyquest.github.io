/* ================================================================
   Meadow Island: the starter island (Leaf pups)
   Windmill Hill (start) opens two paths: Sunflower Fields (gate opens
   after 2 pups) and Lily Pond (needs wellies). Both lead across a
   stream, by a Leaf pup's vine bridge, to Bluebell Wood (the boss).
   ================================================================ */
(function(){
const LEAFC=['#5fbf5a','#7fcf6a','#4fae4a','#6cc45e'];
const R=seed(2024);

/* ----- shared bits ----- */
function haybale(x,z,s){s=s||1;const y=gy(x,z);I('cyl','#f0cf6a',1.2*s,1.6*s,1.2*s,x,y+1.2*s,z,0,0,Math.PI/2);I('cyl','#e0b94f',1.25*s,.12,1.25*s,x+.8*s,y+1.2*s,z,0,0,Math.PI/2);col(x,z,1.3*s);}
function stream(z1,z2,key){const m=new THREE.Mesh(G.plane,new THREE.MeshLambertMaterial({color:'#6cc6ef'}));m.scale.set(200,1,z2-z1);m.position.set(0,.25,(z1+z2)/2);W.ag.add(m);W.disp.push(m.material);
  rect(-120,z1,-3.2,z2);rect(3.2,z1,120,z2);for(let x=-70;x<=70;x+=4.5){if(Math.abs(x)<5)continue;I('sph','#b7bcc9',.9,.5,.8,x+R()*2,.3,z2-.6);I('cyl','#5fae4a',.08,1.6,.08,x+1.5,.8,z2+.6);}
  /* the vine bridge, hidden until a Leaf pup grows it */
  const b=grp();for(let i=0;i<8;i++)mk('box',i%2?'#4fae4a':'#5fbf5a',4.6,.35,1.5,0,.55,-i*1.55,b);[-1,1].forEach(s=>{for(let i=0;i<8;i++){mk('sph','#3f9e46',.35,.35,.35,s*2.4,1.2,-i*1.55,b);mk('sph','#ff9ecb',.2,.2,.2,s*2.4,1.6,-i*1.55-.6,b);}mk('box','#3f9e46',.2,.2,12.4,s*2.4,1.3,-5.4,b);});
  b.position.set(0,0,z2+.5);b.scale.set(1,1,state.vines[key]?1:.001);b.visible=!!state.vines[key];W.ag.add(b);
  /* while the bridge is missing, the gap is blocked too */
  const gapR={x1:-3.2,z1:z1,x2:3.2,z2:z2};if(!state.vines[key])W.rects.push(gapR);
  W.things.push({x:0,z:z2+6.5,r:4.5,icon:'🍃',label:'Leaf power',show:()=>!state.vines[key],act:()=>growVines(key,b,gapR)});
  const s=label('🍃 Vine bridge',6);s.position.set(-4.5,4,z2+6);W.ag.add(s);}
function leafPup(){for(const id of teamIds()){const p=pupById(id);if(p&&p.type==='leaf')return p;}return null;}
function growVines(key,b,gapR){const A=W.area,n=foundIn(areaPups(A.id)),lp=leafPup();
  if(n<2){sfx.oops();say(`The stream is too wide to cross. Find 2 pups in ${A.name} first, then a Leaf pup can grow a bridge!`);return;}
  if(!lp){sfx.oops();say('You need a Leaf pup with you to grow a vine bridge. Choose a Leaf pup as your buddy in the Pup House!');return;}
  player.lock=true;hush();const f=followers.find(q=>q.id===lp.id);if(f)f.grp.userData.jump=.6;sfx.yip(lp.pitch);
  say(`Leaf power! ${lp.name} is growing a vine bridge!`);b.visible=true;let k=0;
  W.ticks.push(dt=>{k+=dt/2.2;b.scale.z=Math.max(.001,Math.min(1,k));if(R()<.3)floatS(pick(['🍃','🌿','🌸']),(R()-.5)*5,1.5,b.position.z-k*12,1.2,1);
    if(k>=1){state.vines[key]=true;state.stars+=5;save();hud();W.rects=W.rects.filter(r=>r!==gapR);sfx.jingle();player.lock=false;say(`Hooray! ${lp.name} grew a vine bridge. Walk across it to Bluebell Wood!`);return true;}});}
function jetty(z0){jettyDeck(z0,15);const boat=ferry3D();add(boat,4.8,z0+11,-1.1);boat.rotation.y=Math.PI/2;W.ticks.push(()=>{boat.position.y=-1.1+Math.sin(W.t*1.5)*.12;});
  sign(-10,z0-2.5,'⛴️ Home to the village',3,6);W.things.push({x:0,z:z0+7,r:5,icon:'⛴️',label:'Go home',act:goHome});}
function sunflower(x,z,h){const y=gy(x,z);I('cyl','#4f9e3a',.12,h,.12,x,y+h/2,z);I('sph','#5fae4a',.5,.12,.3,x+.4,y+h*.55,z,0,0,.5);I('cyl','#ffd23f',.9,.12,.9,x,y+h+.2,z+.15,Math.PI/2.4,0,0);I('cyl','#8a5a2a',.45,.16,.45,x,y+h+.22,z+.2,Math.PI/2.4,0,0);}

/* ----- the 13 Leaf pups (Seb chose Cali) ----- */
const PUPS12=[
 {id:'buttercup',name:'Buttercup',breed:'Labradoodle',area:'windmill',pitch:1.15,spot:{x:16,z:14,kind:'haybale'},hint:'Try near the hay bales.',
  fact:'Labradoodles have soft curly coats, and they love to splash in puddles!',rescue:{icon:'🌾',verb:'Dig',say:'Buttercup is stuck in the hay! Tap the button to dig her out!'},
  look:{fur:'#f3dcae',ear:'#e6c58f',ears:'floppy',fluffy:true,muzzle:'#fbeccf',belly:'#fbeccf',tail:'plume',collar:'#3fae5a',acc:['daisy']}},
 {id:'barley',name:'Barley',breed:'Border Terrier',area:'windmill',pitch:1.05,spot:{x:-34,z:18,kind:'bush'},tag:{x:-40,z:-14,kind:'stump'},hint:'Barley likes to play tag. Look near the old tree stump.',
  fact:'Border Terriers have heads shaped a bit like an otter, and they love to dig!',rescue:{icon:'🤲',verb:'Wiggle',say:'Barley\'s collar is caught on the old tree stump! Tap to wiggle it free!'},
  look:{fur:'#c9a06a',ear:'#8a6440',ears:'fold',muzzle:'#9a7448',muzzleBig:true,belly:'#e0c294',brows:'#a07a4a',tail:'stub',collar:'#e8423a',acc:['leaves']}},
 {id:'honey',name:'Honey',breed:'Cavalier King Charles Spaniel',area:'windmill',pitch:1.25,spot:{x:-20,z:-34,kind:'flowers'},hint:'Look near the beehives.',
  fact:'Cavaliers are gentle lap dogs. Long ago they sat on the laps of kings and queens!',rescue:{icon:'🍯',verb:'Wipe',say:'Honey has her nose stuck in a sticky honey pot! Tap to wipe her clean!'},
  look:{fur:'#ffffff',ear:'#c26a32',ears:'long',patch:{c:'#c26a32',side:1},muzzle:'#ffffff',belly:'#ffffff',eyeWhite:true,tail:'plume',collar:'#ffd23f',acc:['flower']}},
 {id:'cali',name:'Cali',breed:'Border Collie',area:'windmill',pitch:1.1,spot:{x:40,z:25,kind:'haybale'},tag:{x:10,z:-34,kind:'bush'},hint:'Cali plays tag. Look in the sheep field, then near the windmill.',
  fact:'Border Collies are super clever herding dogs. They can steer a whole flock of sheep with just a look! Seb chose Cali\'s name.',rescue:{icon:'🐑',verb:'Herd',taps:6,say:'Cali is busy rounding up the sheep! Tap to help her herd them back into the field!'},
  look:{fur:'#2f2b33',ears:'fold',blaze:'#ffffff',face:'#ffffff',faceLow:true,muzzle:'#ffffff',belly:'#ffffff',paw:'#ffffff',tailTip:'#ffffff',eyeWhite:true,tail:'plume',collar:'#3fae5a',acc:['daisy']}},
 {id:'bumble',name:'Bumble',breed:'British Bulldog',area:'sunflowers',pitch:.8,spot:{x:-22,z:40,kind:'haybale'},hint:'Look by the scarecrow.',
  fact:'Bulldogs love a good nap, and they snore like a little tractor!',rescue:{icon:'🧣',verb:'Untangle',say:'Bumble is tangled up in the scarecrow\'s scarf! Tap to untangle him!'},
  look:{fur:'#e2b47c',ears:'fold',ear:'#c99560',muzzle:'#fff4dc',muzzleBig:true,wrinkle:true,belly:'#fff4dc',hw:64,hh:50,bw:50,bh:34,tail:'stub',collar:'#ffd23f',acc:['flower'],tongue:true}},
 {id:'poppy',name:'Poppy',breed:'Papillon',area:'sunflowers',pitch:1.4,spot:{x:-30,z:-7,kind:'flowers'},tag:{x:38,z:-30,kind:'leafpile'},hint:'Poppy plays tag. Search the sunflower maze, then look for a pile of leaves.',
  fact:'Papillon means butterfly in French, because their big fluffy ears look like wings!',rescue:{icon:'🌻',verb:'Part',say:'Poppy is lost among the tall sunflowers! Tap to push the stalks apart!'},
  look:{fur:'#ffffff',headC:'#d0432f',blaze:'#ffffff',ear:'#d0432f',ears:'pointy',earBig:true,muzzle:'#ffffff',belly:'#ffffff',fluffy:true,tail:'plume',scale:.85,collar:'#3fae5a',acc:['daisy']}},
 {id:'hazel',name:'Hazel',breed:'Basset Hound',area:'sunflowers',pitch:.75,spot:{x:36,z:22,kind:'crate'},hint:'Look by the red tractor.',
  fact:'Basset Hounds have super sniffers. Their long ears help sweep smells up to their noses!',rescue:{icon:'⏰',verb:'Wake',say:'Hazel has fallen fast asleep in a crate! Tap to wake her up gently!'},
  look:{fur:'#ffffff',headC:'#b8743a',blaze:'#ffffff',ear:'#8a5428',ears:'long',long:true,patch:{c:'#3a3338',side:-1},muzzle:'#ffffff',belly:'#ffffff',tail:'thin',collar:'#e8423a',acc:['leaves']}},
 {id:'willow',name:'Willow',breed:'Weimaraner',area:'pond',pitch:1,spot:{x:22,z:-24,kind:'fern'},hint:'Look under the big willow tree.',
  fact:'Weimaraner puppies are born with stripes, and they often have bright blue eyes!',rescue:{icon:'💪',verb:'Pull',say:'Willow is stuck in squelchy mud! Tap to pull her out!'},
  look:{fur:'#a9a7a2',ear:'#99968f',ears:'floppy',muzzle:'#bab7b1',belly:'#bab7b1',iris:'#7fc8f0',tail:'thin',hw:52,hh:54,bw:38,bh:42,collar:'#3fae5a',acc:['leaves']}},
 {id:'lily',name:'Lily',breed:'Maltese',area:'pond',pitch:1.45,spot:{x:-26,z:-28,kind:'flowers'},tag:{x:32,z:28,kind:'log'},hint:'Lily plays tag. After that, look for a log by the water.',
  fact:'Maltese dogs are small and snowy white, and their silky hair keeps on growing, like ours!',rescue:{icon:'🦆',verb:'Shoo',say:'A friendly duck is sitting on Lily! Tap to ask it to move!'},
  look:{fur:'#ffffff',ears:'long',ear:'#f6f0ea',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',scale:.82,tail:'plume',collar:'#ff9ecb',acc:['bow','flower']}},
 {id:'dash',name:'Dash',breed:'Springer Spaniel',area:'pond',pitch:1.1,spot:{x:-19,z:33,kind:'crate'},hint:'Look by the boathouse.',
  fact:'Springer Spaniels love splashing in water, and they spring out of bushes when they play!',rescue:{icon:'🎣',verb:'Untangle',say:'Dash is tangled in a fishing net! Tap to untangle him!'},
  look:{fur:'#ffffff',ear:'#6b3a24',ears:'long',headC:'#6b3a24',blaze:'#ffffff',patch:{c:'#6b3a24',side:1},spots:true,spotC:'#6b3a24',muzzle:'#ffffff',belly:'#ffffff',tail:'wag',collar:'#5b8def',acc:['leaves']}},
 {id:'acorn',name:'Acorn',breed:'Miniature Schnauzer',area:'wood',pitch:1.1,spot:{x:-30,z:8,kind:'leafpile'},hint:'Look in a pile of leaves.',
  fact:'Schnauzers have bushy eyebrows and a big beard, like a little grandad!',rescue:{icon:'🍂',verb:'Sweep',say:'Acorn is buried in a big pile of leaves! Tap to sweep them away!'},
  look:{fur:'#8f9096',ears:'fold',ear:'#7a7b80',muzzle:'#e8e8ea',muzzleBig:true,brows:'#e8e8ea',belly:'#c9c9cc',tail:'stub',collar:'#e8a23a',acc:['leaves'],eyeWhite:true}},
 {id:'bluebell',name:'Bluebell',breed:'Australian Shepherd',area:'wood',pitch:1.05,spot:{x:30,z:-18,kind:'mushroom'},tag:{x:-26,z:-36,kind:'stump'},hint:'Bluebell plays tag. Look by the giant mushrooms, then by a tree stump.',
  fact:'Australian Shepherds are clever herding dogs, and some have one blue eye and one brown eye!',rescue:{icon:'👋',verb:'Wave',say:'Bluebell is feeling shy! Tap to wave hello!'},
  look:{fur:'#b9bfcc',spots:true,spotCs:['#4a4f5c','#2e323c','#6b7180'],ear:'#4a4f5c',ears:'fold',blaze:'#ffffff',muzzle:'#ffffff',belly:'#ffffff',iris:'#7fc8f0',tail:'stub',fluffy:true,collar:'#5b8def',acc:['flower']}},
 {id:'fern',name:'Fern',breed:'West Highland Terrier',area:'wood',pitch:1.3,spot:{x:22,z:24,kind:'fern'},hint:'Look among the ferns.',
  fact:'West Highland Terriers are little white dogs from the hills of Scotland, and they love to dig!',rescue:{icon:'✂️',verb:'Snip',say:'Fern is caught in a prickly bramble! Tap to snip her free!'},
  look:{fur:'#ffffff',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',fluffy:true,eyeWhite:true,tail:'thin',collar:'#3fae5a',acc:['leaves'],scale:.88}}];

const BLOSSOM={id:'blossom',name:'Blossom',breed:'Meadow Unicorn',uni:true,lv:1,pitch:1.2,fact:'Blossom makes the flowers grow wherever she trots.',
  look:{fur:'#fffaf2',ears:'side',earIn:'#ffc4dc',muzzle:'#ffffff',belly:'#ffffff',nose:'#c98aa6',iris:'#3fae5a',limbs:'hooves',hoofC:'#e8c9d8',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','flower'],scale:.96}};

/* ----- the four areas ----- */
const windmill={id:'windmill',name:'Windmill Hill',icon:'🌾',R:56,ground:'#8fd170',ground2:'#b3e08f',sky:'#a6dfff',fog:[70,200],start:[0,36,Math.PI],hedgeSkip:(x,z)=>z>44,
  hf:(x,z)=>7*Math.exp(-(x*x+(z+14)*(z+14))/520)+Math.sin(x*.1)*.4-4.5*sstep(44,52,z),
  hello:'Welcome to Meadow Island! This is Windmill Hill. Four pups are hiding here. Look for hiding spots that wobble!',how:'Take the ferry from the jetty in the village.',
  exits:[{x:-53,z:2,to:'sunflowers',arrive:[44,2,-Math.PI/2],name:'Sunflower Fields',icon:'🌻',open:()=>foundIn(areaPups('windmill'))>=2,
          lock:()=>{const n=foundIn(areaPups('windmill'));return `The gate to Sunflower Fields is shut. Find ${2-n} more ${2-n>1?'pups':'pup'} on Windmill Hill to open it!`;}},
         {x:53,z:2,to:'pond',arrive:[-44,2,Math.PI/2],name:'Lily Pond',icon:'🦆',open:()=>!!state.gear.wellies,
          lock:'The lane to Lily Pond is too squelchy and muddy! You need some wellies. Maybe the farmer\'s shed has some?'}],
  build(){
    /* the windmill on the hill, with turning sails */
    const hy=gy(0,-14);I('cyl','#fff8e6',3,11,3.6,0,hy+5.5,-14);I('cone','#e8423a',3.6,3.6,3.6,0,hy+12.8,-14);I('box','#5b4636',1.6,2.6,.3,0,hy+1.3,-10.5);I('box','#9bdcff',1.1,1.1,.2,0,hy+6,-10.75);col(0,-14,3.8);
    const sails=grp();for(let i=0;i<4;i++){const a=grp();a.rotation.z=i*Math.PI/2;mk('box','#c9905f',.3,7,.2,0,3.6,0,a);mk('box','#fff8e6',1.6,5.6,.12,.9,4,0,a);sails.add(a);}
    mk('sph','#c9905f',.6,.6,.6,0,0,0,sails);add(sails,0,-10.3,hy+10);W.ticks.push(dt=>{sails.rotation.z+=dt*.8;});
    const wl=label('🌾 Windmill Hill',7);wl.position.set(0,hy+17,-14);W.ag.add(wl);
    /* beehives and flowers */
    [[-28,-30],[-25,-33],[-30,-35]].forEach(b=>{const y=gy(b[0],b[1]);I('box','#ffd23f',1.6,1.8,1.6,b[0],y+.9,b[1]);I('box','#e0a82e',1.7,.25,1.7,b[0],y+1.3,b[1]);I('box','#e0a82e',1.7,.25,1.7,b[0],y+.5,b[1]);I('pyr','#fff8e6',1.4,.8,1.4,b[0],y+2.2,b[1],0,Math.PI/4,0);col(b[0],b[1],1.2);});
    const bees=[0,1,2,3].map(i=>spr('🐝',.9,-27,4,-32));W.ticks.push(()=>bees.forEach((b,i)=>{const a=W.t*(1.3+i*.2)+i*1.6;b.position.set(-27+Math.cos(a)*3,gy(-27,-32)+3+Math.sin(a*2)*.6,-32+Math.sin(a)*2.5);}));
    flowerPatch(-20,-30,40,9,['#ff9ecb','#fff27a','#ffffff','#c9b6ff'],R);flowerPatch(14,22,20,7,['#ffffff','#fff27a'],R);flowerPatch(-14,20,20,7,['#ff9ecb','#ff6b6b'],R);
    /* the farmer's shed, with the wellies */
    const sx=30,sz=-24,sy=gy(sx,sz);I('box','#d9363e',8,5,6,sx,sy+2.5,sz);I('pyr','#7a4f2a',6.4,3,5,sx,sy+6.4,sz,0,Math.PI/4,0);I('box','#fff8e6',2.6,3.6,.2,sx-2,sy+1.8,sz+3.05);I('box','#fff8e6',.25,3.6,.25,sx-2,sy+1.8,sz+3.12,0,0,.62);rect(sx-4,sz-3,sx+4,sz+3);camBlock(sx-4,sz-3,sx+4,sz+3);
    sign(sx+5.2,sz+4,'Farmer\'s shed',3,6);
    const boots=grp();[-.4,.4].forEach(s=>{mk('cyl','#3fae5a',.32,1.1,.38,s,.55,0,boots);mk('box','#3fae5a',.5,.35,.9,s,.18,.3,boots);});const bt=sprite('🥾',1.2);bt.position.y=2.2;boots.add(bt);add(boots,sx-2,sz+5.2);boots.visible=!state.gear.wellies;
    W.ticks.push(()=>{boots.rotation.y+=.02;});
    W.things.push({x:sx-2,z:sz+5.2,r:3.6,icon:'🥾',label:'Wellies',show:()=>!state.gear.wellies,act:()=>{state.gear.wellies=true;state.stars+=5;save();hud();boots.visible=false;sfx.jingle();confetti(30);
      card({art:'<div style="font-size:120px;line-height:1">🥾</div>',h:'You found the wellies!',p:'Now you can squelch through the mud on the lane to Lily Pond. It is on the other side of Windmill Hill, past the shed!'});}});
    /* the sheep field, where Cali loves to play */
    fence(30,14,44,14);fence(44,14,44,28);fence(30,28,44,28);sign(28,12,'🐑 Sheep field',3,6);haybale(40,25);
    W.things.push({x:26.5,z:21,r:4,icon:'🐑',label:'Herd sheep',act:()=>{if(!isFound('cali')){sfx.oops();say('The sheep keep wandering out of their field! They need a sheepdog to help. Have you found Cali yet?');return;}sfx.chime();startHerd('activity');}});
    const sheep=[0,1,2,3,4].map(i=>{const g=grp();mk('sph','#ffffff',.9,.75,1.1,0,1,0,g);mk('sph','#f4f4f0',.6,.55,.6,0,1.5,.4,g);mk('sph','#3a3338',.38,.42,.42,0,1.2,1.1,g);[-1,1].forEach(q=>[-1,1].forEach(w=>mk('cyl','#3a3338',.1,.7,.1,q*.4,.35,w*.5,g)));const o={g,x:32+i*2.2,z:17+(i%2)*3,tx:0,tz:0,w:0};add(g,o.x,o.z);return o;});
    W.ticks.push(dt=>sheep.forEach(o=>{o.w-=dt;if(o.w<0){o.tx=32+R()*9;o.tz=16+R()*6;o.w=3+R()*4;}const dx=o.tx-o.x,dz=o.tz-o.z,d=Math.hypot(dx,dz);if(d>.2){o.x+=dx/d*dt*.8;o.z+=dz/d*dt*.8;o.g.rotation.y=Math.atan2(dx,dz);}o.g.position.set(o.x,gy(o.x,o.z),o.z);}));
    /* hay, fences, trees */
    haybale(16,14);haybale(20,17,.9);haybale(12,18,.8);haybale(-8,30);
    fence(-46,-6,-30,-24);fence(10,-40,30,-40);fence(36,10,46,-10);
    const st=grp();mk('cyl','#9b6a43',1.3,1.4,1.3,0,.7,0,st);mk('cyl','#e0c294',1.15,.1,1.15,0,1.42,0,st);[[-1.2,.7],[1.1,-.9]].forEach(q=>{mk('sph','#ffffff',.3,.4,.3,q[0],.3,q[1],st);mk('sph','#e8423a',.5,.25,.5,q[0],.65,q[1],st);});
    tree(-46,26,1.2,'#5fbf5a');tree(-28,40,1,'#7fcf6a');tree(40,30,1.3,'#4fae4a');tree(28,40,1,'#5fbf5a');tree(-44,-30,1.1);bush(-34,22,1,'#5fbf5a','#ff5d6c');bush(40,-36,1.2);
    jetty(45);edgeTrees(56,[180,0,90],LEAFC,null,R);
  }};

function rowsSunflowers(){const rows=[-32,-22,-12,-2,8,18];rows.forEach((z,i)=>{const gap=i%2?-24:0;
    for(let x=-46;x<=12;x+=1.7){if(Math.abs(x-gap)<4)continue;sunflower(x+R()*.4,z+R()*.6-.3,3.2+R()*1.2);}
    rect(-46.5,z-.9,gap-4,z+.9);rect(gap+4,z-.9,12.5,z+.9);});}
const sunflowers={id:'sunflowers',name:'Sunflower Fields',icon:'🌻',R:58,ground:'#9bd16a',ground2:'#c9e07a',sky:'#b4e4ff',fog:[70,200],start:[44,2,-Math.PI/2],hedgeSkip:(x,z)=>z<-49,
  hf:(x,z)=>Math.sin(x*.07)*.5+Math.cos(z*.09)*.5,
  hello:'Sunflower Fields! The sunflowers are taller than you. Three pups are hiding here, and one is somewhere in the sunflower maze!',how:'The gate on Windmill Hill opens when you have found 2 pups there.',
  exits:[{x:56,z:2,to:'windmill',arrive:[-44,2,Math.PI/2],name:'Windmill Hill',icon:'🌾'},
         {x:0,z:-48.5,to:'wood',arrive:[-22,40,Math.PI],name:'Bluebell Wood',icon:'🌳',noArch:true,open:()=>!!state.vines.fields,lock:'The stream is too wide to cross! A Leaf pup could grow a vine bridge. Stand by the leafy sign and tap the button.'}],
  build(){rowsSunflowers();
    const sl=label('🌻 Sunflower maze',7);sl.position.set(-17,7,-36);W.ag.add(sl);
    /* scarecrow */
    const sc=grp();mk('cyl','#9b6a43',.12,4,.12,0,2,0,sc);mk('box','#9b6a43',3.4,.14,.14,0,3,0,sc);mk('box','#5b8def',1.2,1.4,.6,0,2.6,0,sc);mk('sph','#f0cf6a',.55,.55,.55,0,3.8,0,sc);mk('cone','#c9905f',.8,.8,.8,0,4.5,0,sc);mk('box','#e8423a',1.4,.3,.3,0,3.4,.3,sc);add(sc,-12,32);col(-12,32,.8);
    haybale(-22,40);haybale(-18,44,.8);haybale(-26,44,.9);
    /* the red tractor */
    const tr=grp();mk('box','#e8423a',4.4,2,2.6,0,1.8,0,tr);mk('box','#9bdcff',1.8,1.6,2.2,-.9,3.6,0,tr);mk('cyl','#5b4636',.8,.18,.8,1.8,4,0,tr);[[-1.2,1.4,1.3],[1.6,.9,.9]].forEach(w=>[-1,1].forEach(s=>{const m=mk('cyl','#3a3338',w[1],.6,w[1],w[0],w[1],s*w[2]+s*.2,tr);m.rotation.x=Math.PI/2;}));add(tr,34,14);tr.rotation.y=.4;col(34,14,2.8);
    I('box','#c9905f',1.6,1.2,1.6,36,gy(36,22)+.6,22.6);
    /* the maze race start */
    {const fx=18,fz=26,y=gy(fx,fz);I('cyl','#9b6a43',.15,4,.15,fx,y+2,fz);I('box','#e8423a',1.6,1,.08,fx+.8,y+3.5,fz);I('box','#ffffff',.8,.5,.09,fx+.4,y+3.75,fz);I('box','#ffffff',.8,.5,.09,fx+1.2,y+3.25,fz);
      sign(fx+4,fz+2,'🏁 Maze Race',3,6);W.things.push({x:fx,z:fz,r:4,icon:'🏁',label:'Maze race',show:()=>!W.act,act:startMaze});}
    stream(-62,-51,'fields');
    flowerPatch(30,40,30,10,['#ffd23f','#ffffff','#ff9ecb'],R);bush(44,-20,1.2);bush(-40,36,1);tree(46,34,1.2);tree(20,44,1);tree(-46,30,1.1);
    edgeTrees(58,[0,270],LEAFC,null,R);
  }};

const lilyPond={id:'pond',name:'Lily Pond',icon:'🦆',R:58,ground:'#8fd170',ground2:'#7cc49a',sky:'#aee6f5',fog:[70,200],start:[-44,2,Math.PI/2],hedgeSkip:(x,z)=>z<-49,
  hf:(x,z)=>{const d=Math.hypot(x,z+4);return Math.sin(x*.08)*.4-1.2*(1-sstep(16,24,d));},
  hello:'Lily Pond! Ducks are paddling on the water. Three pups are hiding round the pond. Watch out, one of them loves playing tag!',how:'You need wellies for the muddy lane. Look in the farmer\'s shed on Windmill Hill!',
  exits:[{x:-56,z:2,to:'windmill',arrive:[44,2,-Math.PI/2],name:'Windmill Hill',icon:'🌾'},
         {x:0,z:-48.5,to:'wood',arrive:[24,42,Math.PI],name:'Bluebell Wood',icon:'🌳',noArch:true,open:()=>!!state.vines.pond,lock:'The stream is too wide to cross! A Leaf pup could grow a vine bridge. Stand by the leafy sign and tap the button.'}],
  build(){const pz=-4;pond(0,pz,18,'#6cc6ef');
    for(let i=0;i<16;i++){const a=R()*6.28,r=4+R()*12;I('cyl','#4fae4a',.9,.06,.9,Math.cos(a)*r,gy(0,pz)+.14,pz+Math.sin(a)*r);if(i%3===0)I('sph','#ff9ecb',.25,.2,.25,Math.cos(a)*r,gy(0,pz)+.3,pz+Math.sin(a)*r);}
    for(let a=0;a<6.28;a+=.13){if(R()<.45)continue;const r=17.5+R()*1.5;I('cyl','#6a9e3a',.07,1.8+R(),.07,Math.cos(a)*r,gy(Math.cos(a)*r,pz+Math.sin(a)*r)+.9,pz+Math.sin(a)*r);}
    const ducks=[0,1,2,3].map(i=>{const d=grp();mk('sph','#fff27a',.6,.45,.8,0,.3,0,d);mk('sph','#fff27a',.35,.35,.35,0,.85,.45,d);mk('cone','#ff8a3c',.12,.3,.12,0,.8,.85,d).rotation.x=Math.PI/2;mk('sph','#3a3338',.06,.06,.04,.14,.95,.72,d,true);mk('sph','#3a3338',.06,.06,.04,-.14,.95,.72,d,true);add(d,0,pz,gy(0,pz)+.1);return d;});
    W.ticks.push(()=>ducks.forEach((d,i)=>{const a=W.t*.25*(i%2?1:-1)+i*1.6,r=6+i*2.5;d.position.x=Math.cos(a)*r;d.position.z=pz+Math.sin(a)*r;d.rotation.y=Math.atan2(-Math.sin(a),Math.cos(a))*(i%2?1:-1)+(i%2?0:Math.PI);d.position.y=gy(0,pz)+.1+Math.sin(W.t*3+i)*.05;}));
    /* the boathouse and a little rowing boat */
    const bx=-30,bz=26;I('box','#7fc8f0',10,5,8,bx,gy(bx,bz)+2.5,bz);I('pyr','#5b8def',8,3,6.2,bx,gy(bx,bz)+6.5,bz,0,Math.PI/4,0);I('box','#5b4636',2.4,3,.2,bx+5.05,gy(bx,bz)+1.5,bz,0,Math.PI/2,0);rect(bx-5,bz-4,bx+5,bz+4);camBlock(bx-5,bz-4,bx+5,bz+4);
    sign(bx+6,bz-5,'🚣 Boathouse',3,6);
    const boat=grp();mk('sph','#c9905f',1,.5,2.2,0,0,0,boat);mk('box','#9b6a43',1.6,.12,.4,0,.35,0,boat);add(boat,8,pz+10,gy(0,pz)+.2);
    tree(30,-28,1.5,'#7fcf6a','willow');tree(-36,-30,1.2,'#7fcf6a','willow');tree(40,20,1.2);tree(-44,10,1.1);tree(14,40,1.2);bush(-14,40,1,'#5fbf5a','#c9b6ff');bush(26,30,1.1);
    I('cyl','#9b6a43',.7,4,.7,32,gy(32,28)+.7,28,0,0,Math.PI/2);
    flowerPatch(-26,-24,26,8,['#ff9ecb','#ffffff','#c9b6ff'],R);flowerPatch(30,34,16,6,['#fff27a','#ffffff'],R);
    /* stepping stones across the south of the pond, and the start spot */
    for(let i=0;i<7;i++){const a=Math.PI*.62+i*.12,r=13.5;I('cyl','#b7bcc9',1.1,.5,1,Math.cos(a)*r,gy(0,pz)+.2,pz+Math.sin(a)*r);}
    sign(-6,17,'🪨 Stepping Stones',3,7);W.things.push({x:0,z:16.5,r:4,icon:'🪨',label:'Stepping stones',act:()=>{sfx.chime();startStones('activity');}});
    stream(-62,-51,'pond');edgeTrees(58,[180,270],LEAFC,null,R);
  }};

const wood={id:'wood',name:'Bluebell Wood',icon:'🌳',R:58,ground:'#6fae5a',ground2:'#8f9fd6',sky:'#c4e8d4',fog:[45,150],fogC:'#d4eadc',hedgeC:'#3f8a3f',start:[-24,42,Math.PI],
  hf:(x,z)=>Math.sin(x*.11)*.6+Math.cos(z*.1+x*.03)*.6,gmix:(x,z)=>(Math.sin(x*.3)+Math.sin(z*.27))*.25+.3,
  hello:'Bluebell Wood! Muddle the Magpie lives in the old oak tree in the middle. Three pups are hiding among the trees.',how:'Grow a vine bridge across the stream with a Leaf pup, from Sunflower Fields or Lily Pond.',
  exits:[{x:-30,z:48,to:'sunflowers',arrive:[0,-40,0],name:'Sunflower Fields',icon:'🌻'},{x:30,z:48,to:'pond',arrive:[0,-40,0],name:'Lily Pond',icon:'🦆'}],
  build(){
    /* the old oak */
    const oy=gy(0,-16);I('cyl','#8a5a3a',3,14,3.4,0,oy+7,-16);[[0,16,-16,8],[-6,14,-14,5],[6,15,-18,5.5],[0,19,-12,5],[-3,18,-20,5]].forEach(c=>I('sph',c===0?'#4fae4a':LEAFC[(c[0]+9)%4],c[3],c[3]*.8,c[3],c[0],oy+c[1],c[2]));
    I('cyl','#8a5a3a',.7,8,.7,5,oy+11,-14,0,0,-.9);I('cyl','#c9a36b',1.6,.6,1.6,8,oy+13.6,-13);for(let i=0;i<5;i++)I('sph','#ffe066',.2,.2,.2,8+Math.cos(i)*.8,oy+14.1,-13+Math.sin(i)*.8,0,0,0,true);
    col(0,-16,3.6);const ol=label('🌳 The old oak',6);ol.position.set(0,oy+26,-16);W.ag.add(ol);
    /* treehouse */
    I('cyl','#8a5a3a',.9,10,.9,34,gy(34,-34)+5,-34);I('box','#e0b06a',6,.4,6,34,gy(34,-34)+7,-34);I('box','#ffb3cf',4.4,3,4.4,34,gy(34,-34)+8.7,-34);I('pyr','#e8423a',3.8,2,3.8,34,gy(34,-34)+11.2,-34,0,Math.PI/4,0);I('sph','#5fbf5a',4,3,4,34,gy(34,-34)+13.4,-34);col(34,-34,1.2);
    for(let i=0;i<7;i++)I('box','#9b6a43',1.4,.15,.15,34,gy(34,-34)+i,-31.3);
    /* giant mushrooms */
    [[30,-14,1.4],[34,-20,1],[26,-22,.8],[-36,-6,1.1]].forEach(m=>{const y=gy(m[0],m[1]);I('cyl','#fff8e6',.4*m[2],2.4*m[2],.4*m[2],m[0],y+1.2*m[2],m[1]);I('hemi','#e8423a',1.6*m[2],1.1*m[2],1.6*m[2],m[0],y+2.3*m[2],m[1]);for(let i=0;i<4;i++)I('sph','#ffffff',.2*m[2],.1,.2*m[2],m[0]+Math.cos(i*1.6)*.9*m[2],y+3*m[2],m[1]+Math.sin(i*1.6)*.9*m[2]);col(m[0],m[1],.7*m[2]);});
    /* the wood: trees, ferns and a carpet of bluebells, kept off the paths */
    const busy=[[12,10,5],[0,4,7],[0,16,7],[0,28,6],[0,-16,10],[-30,8,4],[30,-18,5],[-26,-36,4],[22,24,4],[34,-34,4],[-36,-6,3],[0,-5,6]],onPath=(x,z)=>{for(const e of [[-30,48],[30,48]]){const t=Math.max(0,Math.min(1,((x-e[0])*(-e[0])+(z-e[1])*(-10-e[1]))/(e[0]*e[0]+(-10-e[1])*(-10-e[1])))),px=e[0]+(-e[0])*t,pz=e[1]+(-10-e[1])*t;if(Math.hypot(x-px,z-pz)<5)return true;}return false;};
    const free=(x,z,g)=>!busy.some(b=>Math.hypot(x-b[0],z-b[1])<b[2]+g)&&!onPath(x,z)&&Math.hypot(x,z)<52;
    let n=0;for(let k=0;k<400&&n<46;k++){const x=(R()*2-1)*52,z=(R()*2-1)*52;if(!free(x,z,2.5))continue;n++;tree(x,z,1+R()*.6,LEAFC[Math.floor(R()*4)],R()<.25?'pine':null);busy.push([x,z,3.5]);}
    for(let k=0;k<700;k++){const x=(R()*2-1)*54,z=(R()*2-1)*54;if(Math.hypot(x,z)>55||onPath(x,z)&&R()<.8)continue;I('sph',R()<.8?'#7b86e0':'#a9b1f0',.18,.14,.18,x,gy(x,z)+.25,z);if(k%3===0)I('cyl','#4f9e3a',.04,.4,.04,x,gy(x,z)+.15,z);}
    for(let k=0;k<30;k++){const x=(R()*2-1)*50,z=(R()*2-1)*50;if(!free(x,z,1))continue;const y=gy(x,z);for(let i=0;i<5;i++)I('cone','#4f9e3a',.25,1.6,.25,x+Math.cos(i*1.26)*.5,y+.6,z+Math.sin(i*1.26)*.5,Math.cos(i*1.26)*.6,0,Math.sin(i*1.26)*.6);}
    const ffl=[0,1,2,3,4,5].map(i=>spr('✨',.8,0,3,0));W.ticks.push(()=>ffl.forEach((f,i)=>{const a=W.t*.4+i;f.position.set(Math.cos(a*1.3+i)*20,gy(0,0)+2.5+Math.sin(a*2)*1,Math.sin(a+i*2)*20-6);}));
    /* the firefly jar on a stump */
    {const jx=12,jz=10,y=gy(jx,jz);I('cyl','#9b6a43',1,1.2,1,jx,y+.6,jz);I('cyl','#cfe8f5',.45,.9,.45,jx,y+1.65,jz);I('cyl','#c9905f',.48,.18,.48,jx,y+2.2,jz);spr('✨',1,jx,y+1.7,jz);col(jx,jz,1.1);
      sign(jx+3.5,jz+1,'✨ Firefly Catch',3,6);W.things.push({x:jx,z:jz,r:3.8,icon:'✨',label:'Fireflies',act:()=>{sfx.chime();startFlies('activity');}});}
    edgeTrees(58,[121,59],LEAFC,'pine',R);
  }};

regIsland({id:'meadow',name:'Meadow Island',icon:'🌼',type:'leaf',ride:'the ferry',from:'jetty in the village',rideIcon:'⛴️',rideSay:'All aboard the Daisy ferry!',
  badge:'Meadow Badge',cert:'Seb, Meadow Island Hero!',
  bossHint:'Blossom the Meadow Unicorn is waiting at the old oak tree in Bluebell Wood!',
  nextSay:'Hooray! Meadow Island is safe! Now the chairlift to Snowy Summit and the submarine to Coral Reef are open. You will find them in Pawprint Village!',
  map:{shape:'M120 380 Q50 250 140 140 Q230 20 430 30 Q640 20 730 140 Q820 250 740 380 Q600 455 430 445 Q260 455 120 380Z',
    nodes:{windmill:[430,300],sunflowers:[200,200],pond:[660,200],wood:[430,95]},links:[['windmill','sunflowers'],['windmill','pond'],['sunflowers','wood'],['pond','wood']]},
  boss:{area:'wood',x:0,z:-7,perch:0,uni:BLOSSOM,
    story:[['m','Muddle the Magpie hops down from the old oak. "I am sorry, Seb. I only wanted shiny things for my nest. I did not mean to make the pups run away!"'],
      ['u','Blossom the Meadow Unicorn smiles. "Muddle, sharing is better than borrowing. Give back the shiny things, and you can be our friend."'],
      ['b','Muddle gives back the shiny Meadow Star, and all 13 pups cheer! Muddle promises to help find the pups on the other islands.']],
    after:['Blossom says: thank you for finding every pup on Meadow Island!','Muddle says: I am being a good magpie now. Caw caw!','Blossom says: the bluebells look lovely today!']},
  pups:PUPS12,areas:[windmill,sunflowers,lilyPond,wood]});
})();
