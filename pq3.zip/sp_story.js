/* ================================================================
   Spring Blossom (26 Nov 2026; claude/spring-blossom-design.md sections 2, 4, 9, 10, 15): the story.
   Sightings during the search (Muddle with the buds, a mother duck searching), the full blossom branch
   at nine buds, Muddle at the Lily Pond (he moved an egg he thought was left behind), the Festival Garden
   (a 2D garden of nine beds: arrays, rows and sharing into rows), the Blossom Festival (the Festival Tree
   blossoms and the duckling finds its mum), 6 badges, the Spring Blossom Hero certificate, the goodbye and
   the Puppy Families teaser (three tiny puppies asleep in a basket in Seb's Den).
   ================================================================ */
(function(){
const SR=window.SPRING,SL=window.SPLOOK,PI=Math.PI,PINK='#ff9ac0';
const X=()=>SR.GS(),F=()=>SR.pal().name,big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`;
const ds=(w,o)=>`<div class="fitsvg" style="width:${w||160}px">${SR.duckSVG(o)}</div>`,mg=w=>`<div class="fitsvg" style="width:${w||150}px">${magpieSVG()}</div>`;
const br=(w,o)=>`<div class="fitsvg" style="width:${w||260}px">${SR.budBranch(null,o)}</div>`;
/* the duckling's mum, a mallard duck */
function mumSVG(o){o=o||{};const K=INK;return `<svg viewBox="0 0 220 200" xmlns="http://www.w3.org/2000/svg"><ellipse cx="108" cy="134" rx="74" ry="46" fill="#a8784a" stroke="${K}" stroke-width="4"/>`+
  [[80,120],[100,140],[124,118],[140,146],[70,148],[156,126]].map(q=>`<path d="M${q[0]} ${q[1]} q6 -6 12 0" stroke="#6a4a2a" stroke-width="3" fill="none"/>`).join('')+
  `<path d="M118 120 q34 -12 58 8 q-24 18 -58 6 Z" fill="#8a5a3a" stroke="${K}" stroke-width="3.4"/><path d="M140 124 q12 -2 22 6 q-12 6 -22 2 Z" fill="#3a6ae8" stroke="${K}" stroke-width="2"/>`+
  `<path d="M178 124 q22 -8 30 -2 q-10 10 -30 8 Z" fill="#a8784a" stroke="${K}" stroke-width="3.4"/>`+
  `<path d="M52 108 Q44 60 70 44" stroke="${K}" stroke-width="30" fill="none" stroke-linecap="round"/><path d="M52 108 Q44 60 70 44" stroke="#a8784a" stroke-width="22" fill="none" stroke-linecap="round"/>`+
  `<circle cx="72" cy="46" r="26" fill="#a8784a" stroke="${K}" stroke-width="4"/><path d="M50 42 q22 -4 44 2" stroke="#6a4a2a" stroke-width="4" fill="none"/>`+
  `<path d="M90 50 Q120 46 128 56 Q118 66 90 60 Z" fill="#ff9a2a" stroke="${K}" stroke-width="3.4" stroke-linejoin="round"/><ellipse cx="104" cy="54" rx="6" ry="3" fill="#6a4a2a"/>`+
  `<circle cx="76" cy="38" r="5" fill="${K}"/><circle cx="77.6" cy="36.4" r="1.6" fill="#fff"/>`+(o.tear?`<path d="M80 50 q3 8 0 12 q-3 -4 0 -12 Z" fill="#8ad0ff"/>`:'')+
  `<path d="M84 178 l-6 14 h18 Z M128 178 l-6 14 h18 Z" fill="#ff9a2a" stroke="${K}" stroke-width="3"/></svg>`;}
const mum=(w,o)=>`<div class="fitsvg" style="width:${w||170}px">${mumSVG(o)}</div>`;

/* ---------------- sightings during the search ---------------- */
const SEEN={4:()=>'A pup says: "I saw Muddle flying over the meadow with a beak full of pink buds and twigs! What is he building?"',
 12:()=>'Professor Hoot says: "A mother duck has been quacking by the Lily Pond all morning, looking under every leaf and in every clump of reeds."',
 24:()=>'A pup saw Muddle in Bluebell Wood, peering into an empty nest. "Where did it go?" he said. "It was right here!"',
 40:()=>`Somebody heard a mother duck calling by Skip-Count River: "Quack! Quack! Where are you?" ${F()} peeps: "Was that... my mum?"`};
const KS=[4,12,24,40];
function afterFind(p,n){const T=X();T.seen=T.seen||{};const k=KS.find(k=>n>=k&&!T.seen[k]);if(!k)return false;T.seen[k]=1;save();
  setTimeout(()=>{say(SEEN[k]());SR.PAL.jump=.5;if(k>=12)SR.snd.quack();},300);return true;}
/* ---------------- nine buds: the branch is full ---------------- */
function onBud(I,n){if(n<9)return;const T=X(),u=islandOf('meadow').boss.uni;setTimeout(()=>{player.lock=true;SR.snd.song(9,220);
  story([{art:br(270,{all:1}),t:`${F()} tucks in the last bud. The blossom branch is full: all nine of the Festival Tree's buds are home!`},
    {art:`<div class="fitsvg">${critterSVG(SL.sp(u))}</div>`,t:`${u.name} the unicorn trots up. "Well done, both of you! And I have some news. Muddle is sitting by the Lily Pond, beside an empty nest in the reeds. He looks very sad."`},
    {art:ds(170),t:`"An empty nest?" peeps ${F()}. "Let's go and see!"`}],
    ()=>{player.lock=false;T.call=Date.now();save();card({art:big('🦆🪺'),h:'To the Lily Pond!',p:'Shall we go to the Lily Pond on Meadow Island?',btns:[['🦆 Let\'s go!','green',()=>{player.lock=true;fadeTo(()=>enterArea('pond'),['🦆','The Lily Pond']);}],['Later','white',()=>say('The Lily Pond is on Meadow Island. Take the ferry from the village!')]]});});},900);}
/* ---------------- Muddle at the Lily Pond ---------------- */
let MC=null;
{const Ap=AREAS.pond,b=Ap.build;Ap.build=function(){b.apply(this,arguments);MC=null;if(!SR.on())return;const T=SR.G0();if(!T||!T.call||T.planted)return;const A=Ap,s=A.start||[0,0],nr=window.SPWORLD?SPWORLD.place:(a,x,z)=>[x,z];
  const fx=-Math.sin(s[2]||0),fz=-Math.cos(s[2]||0),c=nr(A,s[0]-fx*12,s[1]-fz*12,3),x=c[0],z=c[1],y=gy(x,z),r=Math.atan2(s[0]-x,s[1]-z);
  const N=SR.nest3D({reeds:1});add(N.g,x-2.4,z+.6);col(x-2.4,z+.6,1.2);const R=seed(41);for(let i=0;i<10;i++){const a=R()*PI*2,d=1.5+R()*4,px=x+Math.cos(a)*d,pz=z+Math.sin(a)*d;I('disc',i%2?PINK:'#ffd0e0',.16,1,.24,px,gy(px,pz)+.05,pz,0,R()*PI,0);}
  if(!T.met){const m=magpie3D();mk('sph',PINK,.14,.18,.14,0,1.55,.62,m);add(m,x,z);m.rotation.y=r;col(x,z,1.2);
    W.ticks.push(()=>{if(W.area!==A||!m.parent)return true;m.rotation.z=Math.sin(W.t*1.6)*.06;m.position.y=gy(x,z)+Math.abs(Math.sin(W.t*.9))*.08;});
    MC={m,x,z};W.things.push({x,z:z+2.4,r:4,icon:'🐦',label:'Muddle',act:muddle});
    setTimeout(()=>{if(W.area===A&&!player.lock)say(`Look, an empty nest in the reeds! And who is that sitting beside it? Go and say hello, Seb!`);},2200);}
  else{const m=magpie3D();add(m,x+2,z);W.things.push({x,z,r:4,icon:'🌷',label:'The Festival Garden',act:()=>garden()});}};}
function muddle(){if(player.lock)return;player.lock=true;hush();const T=X();MUSIC.over='spwad';
  story([{art:mg(160),t:'It\'s MUDDLE, sitting beside an empty nest in the reeds, holding one pink bud. "Oh. Hello, Seb," he sniffs.'},
    {art:mg(140)+big('🥚'),t:'"Yesterday I found an egg here, all on its own. I thought somebody had left it behind! So I carried it to my new nest in Bluebell Wood, to keep it safe."'},
    {art:mg(140)+big('🌸'),t:'"I made my nest pretty with the pink buds from the Festival Tree. Then I flew off to find more... and when I came back, the egg was gone! And a mother duck has been crying here ever since."'},
    {art:ds(170,{flap:1}),t:`"That was MY egg!" peeps ${F()}. "This is MY nest! So my real mum is a duck... and she's been looking for me!"`},
    {art:ds(130)+mg(120),t:`"Muddle," says ${F()} kindly, "if you find an egg or a baby animal on its own, leave it where it is and tell a grown-up. Its mum is probably close by, just getting a snack."`},
    {art:mg(150),t:'"I\'m so sorry," says Muddle. "And I spoiled the Festival Tree too." Seb holds up the blossom branch: all nine buds are safe! "Then let\'s plant the Festival Garden together," says Muddle, "so everything is ready. Everyone will come to the festival. Maybe your mum will too!"'}],
    ()=>{T.met=Date.now();save();MUSIC.over=null;if(MC&&MC.m){W.ag.remove(MC.m);const m=magpie3D();add(m,MC.x+2,MC.z);}player.lock=false;
      card({art:big('🌷🌱'),h:'The Festival Garden',p:'Muddle has the seeds and bulbs. Work out how many to plant in each bed, and the whole garden will bloom. Ready?',btns:[['🌱 Let\'s plant!','green',()=>garden()],['Later','white',()=>say('Come back to the Lily Pond when you are ready to plant the Festival Garden!')]]});});}
/* ---------------- the Festival Garden ---------------- */
const BEDS=[['meadow','daffodils','#ffd23f','count',2,5],['snowy','snowdrops','#ffffff','count',3,2],['reef','sea pinks','#ff9ac0','count',2,4],
 ['ninja','tulips','#ff6a8a','rows',4,3],['number','crocuses','#c8a8ff','rows',3,5],['gadget','bluebells','#8ab0ff','rows',5,2],
 ['rescue','primroses','#ffe680','share',3,4],['dino','daisies','#ffffff','share',2,5],['planet','hyacinths','#b088ff','share',4,5]];
let GD=null;
function bedsFor(){const L=BEDS.map(b=>b.slice());if(typeof tablesOn==='function'){const tb=(tablesOn()||[]).filter(v=>v>=2&&v<=10);if(tb.length)[3,4,5].forEach((k,i)=>{L[k][5]=tb[i%tb.length];});}return L;}
function gardenUI(){if($('#spgarden'))return;const d=el('div','screen',`<div id="spgSky"></div><div id="spgPlot"></div><div id="spgBed"></div><div id="spgPanel"></div><div id="spgAns"></div><button class="btn rnd white" id="spgBack">◀</button><div class="pill" id="spgPill"></div>`);d.id='spgarden';
  const q=document.querySelector('#quiz');q.parentNode.insertBefore(d,q);
  tap('#spgBack',()=>{sfx.boop();if(!GD)return;GD=null;MUSIC.over=null;show('world');player.lock=false;say('You can carry on planting the Festival Garden at the Lily Pond whenever you are ready.');});}
function plotSVG(){let s=`<svg viewBox="0 0 300 300" class="spplot"><rect width="300" height="300" rx="20" fill="#7ac85a"/><path d="M0 100 H300 M0 200 H300 M100 0 V300 M200 0 V300" stroke="#c8a070" stroke-width="12"/>`;
  GD.beds.forEach((b,k)=>{const x=50+(k%3)*100,y=50+Math.floor(k/3)*100,I=islandOf(b[0]),got=GD.got[k],cur=k===GD.i;s+=`<rect x="${x-40}" y="${y-40}" width="80" height="80" rx="10" fill="#8a5a3a" ${cur?'stroke="#ffd23f" stroke-width="6"':''}/>`;
    if(got)for(let i=0;i<4;i++)s+=SL.flower2D(x-18+(i%2)*36,y-14+Math.floor(i/2)*30,11,b[2],'#ffb020');else s+=`<text x="${x}" y="${y+10}" font-size="30" text-anchor="middle">${I.icon}</text>`;});
  return s+'</svg>';}
function bedSVG(b,o){o=o||{};const r=b[4],c=b[5],sh=b[3]==='share',W2=440,H2=300,cw=Math.min(70,380/c),rh=Math.min(56,(sh?190:220)/r),x0=W2/2-(c-1)*cw/2,y0=H2/2+(sh?34:10)-(r-1)*rh/2;
  let s=`<svg viewBox="0 0 ${W2} ${H2}" id="spgSvg"><rect x="10" y="40" width="${W2-20}" height="${H2-50}" rx="22" fill="#8a5a3a" stroke="#5b3e22" stroke-width="5"/>`;
  if(b[3]==='share'&&!o.done){const n=r*c;s+=`<text x="${W2/2}" y="30" font-size="22" font-weight="900" text-anchor="middle" fill="#3f6a2a" font-family="Arial">${n} bulbs</text>`;
    const sp=Math.min(36,392/n),k=Math.min(1,sp/26);for(let i=0;i<n;i++){const bx=W2/2-(n-1)*sp/2+i*sp,by=74;s+=`<g class="spbulb" transform="translate(${bx.toFixed(1)} ${by}) scale(${k.toFixed(2)})"><path d="M0 -12 q10 10 8 18 q-8 6 -16 0 q-2 -8 8 -18 Z" fill="#e8d0a8" stroke="#5b3e22" stroke-width="2"/><path d="M0 -12 v-6" stroke="#7ac85a" stroke-width="3"/></g>`;}}
  for(let i=0;i<r;i++){const y=y0+i*rh;let row='';
    for(let j=0;j<c;j++){const x=x0+j*cw;const show=b[3]==='count'||(b[3]==='rows'&&(i===0||o.holes));
      if(o.done)row+=`<path d="M${x} ${y+16} V${y}" stroke="#4a9a3a" stroke-width="3"/>`+SL.flower2D(x,y-4,Math.min(16,cw*.32),b[2],'#ffb020');
      else if(show&&b[3]!=='share')row+=`<ellipse cx="${x}" cy="${y+6}" rx="${Math.min(14,cw*.28)}" ry="7" fill="#4a2e1a"/>`;}
    if(b[3]==='rows'&&!o.done)row+=`<text x="26" y="${y+12}" font-size="22" font-weight="900" fill="#fff6d0" font-family="Arial">${i+1}</text>`+(i>0?`<path d="M${x0-cw/2} ${y+8} H${x0+(c-.5)*cw}" stroke="#c8a070" stroke-width="4" stroke-dasharray="10 8"/>`:'');
    if(b[3]==='share'&&!o.done&&o.rows!=null&&i<o.rows)row+=`<path d="M${x0-cw/2} ${y+8} H${x0+(c-.5)*cw}" stroke="#ffd23f" stroke-width="6" stroke-dasharray="10 8"/><text x="26" y="${y+14}" font-size="22" font-weight="900" fill="#ffe680" font-family="Arial">${i+1}</text>`;
    s+=`<g class="spgrow" data-r="${i}">${row}</g>`;}
  return s+'</svg>';}
const QS=b=>{const r=b[4],c=b[5],f=b[1];return b[3]==='count'?[`${r} rows of ${c} ${f}. How many ${f} is that?`,r*c]:b[3]==='rows'?[`${r} rows, with ${c} ${f} in each row. How many altogether?`,r*c]:[`Muddle has ${r*c} ${f} bulbs. Plant them in rows of ${c}. How many rows?`,r];};
function opts(b,ans){const r=b[4],c=b[5],L=b[3]==='share'?[r,r+1,Math.max(1,r-1)===r?r+2:r-1,c]:[ans,r+c,ans+c,Math.max(1,ans-c)];const o=[];L.forEach(v=>{if(v>0&&o.indexOf(v)<0&&o.length<3)o.push(v);});let k=1;while(o.length<3){if(o.indexOf(ans+k)<0)o.push(ans+k);k++;}return o.sort(()=>Math.random()-.5);}
function garden(){gardenUI();hush();player.lock=true;const T=X(),start=Math.min(BEDS.length,Math.max(0,T.plant||0));
  GD={i:start,got:BEDS.map((b,k)=>k<start),beds:bedsFor(),busy:false};
  $('#spgSky').innerHTML=`<svg viewBox="0 0 1024 768" preserveAspectRatio="xMidYMid slice"><rect width="1024" height="768" fill="#bfe4ff"/><circle cx="900" cy="90" r="56" fill="#ffe680"/><path d="M0 230 Q256 180 512 220 T1024 210 V768 H0 Z" fill="#9ad870"/></svg>`;
  show('spgarden');MUSIC.over='spwad';speak(`Let's plant the Festival Garden! ${F()} and Muddle are ready with the seeds and bulbs. Count the rows to work out how many!`);setTimeout(()=>nextBed(),900);}
function nextBed(){const R=GD;if(!R)return;X().plant=R.i;save();if(R.i>=R.beds.length){endGarden();return;}const b=R.beds[R.i],I=islandOf(b[0]),q=QS(b);R.q=q;R.tries=0;R.opts=opts(b,q[1]);
  $('#spgPill').textContent=`🌷 ${R.i+1} of 9`;$('#spgPlot').innerHTML=plotSVG();$('#spgBed').innerHTML=bedSVG(b);
  $('#spgPanel').innerHTML=`<div class="spgq">${I.icon} The ${I.name} bed: <b>${q[0]}</b></div>`;
  $('#spgAns').innerHTML=R.opts.map(v=>`<button class="btn white spga" data-v="${v}">${v}</button>`).join('');
  document.querySelectorAll('#spgAns .spga').forEach(e=>tap(e,()=>answer(+e.dataset.v,e)));speak(`The ${I.name} bed. ${q[0]}`+(R.i===6?' Now we share them into rows!':''));}
function countRows(b,n){const c=b[5];for(let i=0;i<n;i++)setTimeout(()=>{const g=document.querySelector(`#spgSvg .spgrow[data-r="${i}"]`);if(g)g.classList.add('lit');SR.snd.note(i);},300+i*480);}
function answer(v,e){const R=GD;if(!R||R.busy||e.classList.contains('nope'))return;const b=R.beds[R.i],I=islandOf(b[0]),r=b[4],c=b[5];
  if(v===R.q[1]){R.busy=true;e.classList.add('win');sfx.fanfare();confetti(30);$('#spgBed').innerHTML=bedSVG(b,{done:1});countRows(b,r);R.got[R.i]=true;
    const m=b[3]==='share'?`Yes! ${r*c} in rows of ${c}: ${SR.steps(c,r)}. That's ${r} rows of ${b[1]}!`:`Yes! ${SR.steps(c,r)}. ${r*c} ${b[1]}!`;
    $('#spgPanel').innerHTML=`<div class="spgq win">✅ ${m}</div>`;say(m);setTimeout(()=>{if(GD!==R)return;R.busy=false;R.i++;nextBed();},3000+r*300);return;}
  R.tries++;e.classList.add('nope');sfx.oops();
  if(b[3]==='share')$('#spgBed').innerHTML=bedSVG(b,{rows:r});else $('#spgBed').innerHTML=bedSVG(b,{holes:1});
  countRows(b,r);
  const m=b[3]==='share'?`Not quite! Put ${c} in each row: ${SR.steps(c,r)}. How many rows is that?`:`Not quite! Count in ${c}s, one row at a time: ${SR.steps(c,r)}.`;
  if(R.tries>=2){const k=document.querySelector(`#spgAns .spga[data-v="${R.q[1]}"]`);if(k)k.classList.add('hint');}
  $('#spgPanel').innerHTML=`<div class="spgq">${I.icon} ${m}${R.tries>=2?' Look, that answer is sparkling!':''}</div>`;speak(m);}
function endGarden(){const T=X(),first=!T.planted;GD=null;T.planted=Date.now();if(first)state.stars+=100;save();hud();MUSIC.over=null;
  fadeTo(()=>{show('world');enterArea('village',[0,15,PI]);setTimeout(()=>festival(),900);},['🌸','The Blossom Festival']);}
/* ---------------- the Blossom Festival ---------------- */
function festival(){const T=X();if(T.done)return;if(!W.area||W.area.id!=='village'){fadeTo(()=>{enterArea('village',[0,15,PI]);setTimeout(festival,900);},['🌸','The Blossom Festival']);return;}
  player.lock=true;hush();MUSIC.over='spvil';const zu=window.BHQ&&state.bh&&state.bh.done?' Zuzu and her puppies have come in flower crowns!':'';
  if(window.SPWORLD&&SPWORLD.bloom)setTimeout(()=>{try{SPWORLD.bloom();}catch(e){}},400);
  story([{art:big('🌸🌷🎉'),t:`The sun shines on Pawprint Village. The Festival Garden is full of flowers, and everyone has come to the Blossom Festival: every pup, Granny Paws, the guides and all nine unicorns!${zu}`},
    {art:br(260,{all:1})+big('🌳'),t:`Seb and ${F()} carry the nine buds to the Festival Tree. One by one, the unicorns tuck them back onto its branches... and the whole tree bursts into pink blossom!`},
    {art:mum(170),t:`Then, from the crowd, comes a "Quack!" A mother duck is waddling across the plaza, looking left and right. ${F()} hears her, and peeps as loud as a duckling can: "MUM!"`},
    {art:mum(130)+ds(110),t:`"My duckling!" quacks the mother duck, and she tucks ${F()} under her wing. "I looked everywhere for you!" They are together again at last.`},
    {art:mg(140)+mum(110),t:'Muddle flies down and says sorry to the mother duck. "I will never move an egg again. I will tell a grown-up instead." The mother duck gives him a little nod. "Thank you for keeping it warm."'},
    {art:`<div class="fitsvg" style="width:150px">${critterSVG(Object.assign({},state.buddy&&pupById(state.buddy)||PUPS.buttercup,{dressAs:'spduck'}),{anim:false})}</div>`,t:'Granny Paws has a duckling suit for every pup (dress any pup in it at the Pup Spa), and there is a blossom tree, a basket of painted eggs, a nest and a window box of daffodils waiting in your Den!'}],
    ()=>{T.done=Date.now();state.stars+=100;state.costumes=state.costumes||{};state.costumes.spduck=1;state.certs=state.certs||{};const c=CERTS.find(q=>q.id==='sphero');if(c&&!state.certs[c.id])state.certs[c.id]=Date.now();save();hud();
      SR.palCrown();
      if(c){confetti(70);sfx.fanfare();card(Object.assign(certHTML(c,state.certs[c.id]),{btns:[['🎉 Hooray! +100 ⭐','green',goodbye]]}));}else goodbye();});}
/* the teaser: three tiny puppies asleep in a basket in Seb's Den */
const BASKET='<svg viewBox="0 0 300 200" width="300" xmlns="http://www.w3.org/2000/svg"><rect width="300" height="200" rx="18" fill="#3a2a4a"/><rect x="200" y="20" width="70" height="60" rx="6" fill="#26203a" stroke="#8a7aa0" stroke-width="4"/><circle cx="246" cy="40" r="10" fill="#fff6c0"/>'+
  '<path d="M20 170 H280 V200 H20 Z" fill="#6a4a3a"/><path d="M30 34 q10 -12 22 0 M60 22 q8 -10 18 0" stroke="#ffd23f" stroke-width="3" fill="none"/>'+
  '<g class="spbask"><path d="M56 120 Q150 104 244 120 L232 172 Q150 184 68 172 Z" fill="#c8924a" stroke="#26232e" stroke-width="4"/><path d="M62 132 Q150 120 238 132 M66 150 Q150 140 234 150" stroke="#8a5a2a" stroke-width="4" fill="none"/>'+
  [[100,'#e8c08a','#b8864a'],[150,'#ffffff','#e8d8c0'],[200,'#5a4a4a','#3a2e2e']].map(q=>`<ellipse cx="${q[0]+6}" cy="116" rx="24" ry="15" fill="${q[1]}" stroke="#26232e" stroke-width="3"/><circle cx="${q[0]-12}" cy="106" r="15" fill="${q[1]}" stroke="#26232e" stroke-width="3"/>`+
    `<path d="M${q[0]-24} 96 q-10 4 -6 18 q6 0 8 -10 Z" fill="${q[2]}" stroke="#26232e" stroke-width="2.4"/><path d="M${q[0]-2} 95 q10 4 6 18 q-6 0 -8 -10 Z" fill="${q[2]}" stroke="#26232e" stroke-width="2.4"/>`+
    `<path d="M${q[0]-19} 105 q3 3 6 0 M${q[0]-10} 105 q3 3 6 0" stroke="#26232e" stroke-width="2" fill="none"/><ellipse cx="${q[0]-12}" cy="112" rx="3" ry="2" fill="#26232e"/><circle cx="${q[0]-21}" cy="110" r="2.4" fill="#ff9ec0" opacity=".7"/>`).join('')+
  '<path d="M56 120 Q150 136 244 120" stroke="#26232e" stroke-width="4" fill="none"/></g><text x="190" y="80" font-size="20" font-weight="900" fill="#c8c0ff" font-family="Arial" class="spzz">z z z</text></svg>';
function goodbye(){const T=X(),left=SR.all().length-SR.nFound();
  story([{art:ds(170,{crown:1}),t:`"Thank you, Seb, for helping me find my mum!" peeps ${F()}. "I live at the Lily Pond with her now. But whenever you play Spring Blossom, I'll waddle right behind you!"`+(left?` And there are still ${left} spring pups hiding on the islands!`:'')},
    {art:BASKET,t:'Back in Seb\'s Den, something in a basket by the fire wobbles... Seb peeks in. Three tiny puppies, fast asleep! Coming soon: Puppy Families!'}],
    ()=>{player.lock=false;T.bye=Date.now();save();MUSIC.over=null;say(`Happy spring, Seb! ${F()} will waddle along whenever Spring Blossom is on.`);});}
/* ---------------- the village checks where the story is up to ---------------- */
function village(){const T=SR.G0();if(!T||!T.intro)return false;
  if(T.call&&!T.met){say(`${F()} says: "Muddle is at the Lily Pond, by an empty nest. Let's go and see him!"`);return true;}
  if(T.met&&!T.planted){card({art:big('🌷🌱'),h:'The Festival Garden',p:'Muddle is waiting at the Lily Pond with the seeds and bulbs. Shall we plant the Festival Garden now?',btns:[['🌱 Let\'s plant!','green',()=>garden()],['Later','white']]});return true;}
  if(T.planted&&!T.done){festival();return true;}
  return false;}
/* ---------------- badges and the certificate ---------------- */
const ss=()=>(state&&state.sx&&state.sx.sp)||{};
MERITS.push(
 {id:'sppal',icon:'🐥',name:'Duckling Pal',how:'Meet the little duckling in Spring Blossom, and give it a name.',ok:()=>!!ss().pal},
 {id:'sphunt',icon:'🥚',name:'Egg Hunter',how:'Find all 8 painted eggs in the Great Egg Hunt in Spring Blossom.',ok:()=>!!(state.acts||{}).spegg},
 {id:'spnestb',icon:'🪺',name:'Nest Builder',how:'Collect everything the robin needs for its nest in Spring Blossom.',ok:()=>!!(state.acts||{}).spnest},
 {id:'sphatch',icon:'🦕',name:'Dino Hatcher',how:'Measure and hatch the dinosaur eggs at Long-neck\'s Nest in Spring Blossom.',ok:()=>!!(state.acts||{}).sphatch},
 {id:'spbuds',icon:'🌸',name:'Nine Blossom Buds',how:'Collect all nine blossom buds from the unicorns in Spring Blossom.',ok:()=>Object.keys(ss().bb||{}).length>=9},
 {id:'spall',icon:'🌷',name:'Every Pup in Bloom',how:'Find all 119 spring pups.',ok:()=>!!ss().found&&SR.nFound()>=SR.all().length});
CERTS.push({id:'sphero',icon:'🌸',title:'Spring Blossom Hero',get why(){return `for bringing back the Festival Tree's buds with ${ss().pal?ss().pal.name+', the little duckling':'the little duckling'}, planting the Festival Garden, and helping a duckling find its mum`;},ok:()=>!!ss().done});
const css=document.createElement('style');css.textContent=`#spgarden{background:#bfe4ff;overflow:hidden}#spgSky,#spgSky svg{position:absolute;left:0;top:0;width:100%;height:100%}#spgarden .btn.rnd{position:absolute;left:14px;top:10px;z-index:20}#spgarden .pill{position:absolute;right:14px;top:14px;z-index:20}
#spgPlot{position:absolute;left:24px;top:250px;width:250px;z-index:5}#spgPlot svg{width:100%;height:auto;display:block}
#spgBed{position:absolute;left:300px;top:232px;width:520px;z-index:5}#spgBed svg{width:100%;height:auto;display:block}
#spgAns{position:absolute;left:840px;top:262px;width:160px;display:flex;flex-direction:column;gap:16px;z-index:6}#spgAns .btn{min-height:84px;font-size:40px;font-weight:900}#spgAns .btn.nope{opacity:.4}#spgAns .btn.win{background:#8ae05a}#spgAns .btn.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
#spgPanel{position:absolute;left:50%;top:110px;transform:translateX(-50%);width:min(920px,92%);z-index:10}.spgq{background:#f6fff0;border:5px solid #6a9a3a;border-radius:24px;padding:10px 16px;font-size:25px;font-weight:800;text-align:center;box-shadow:0 6px 0 rgba(0,0,0,.2)}
.spgq b{color:#c83a7a}.spgq.win{background:#eaffd8}#spgSvg .spgrow{transition:filter .3s}#spgSvg .spgrow.lit{filter:drop-shadow(0 0 6px #ffd23f) brightness(1.2)}
.spbask{transform-origin:150px 170px;animation:spWob 1.4s ease-in-out infinite}@keyframes spWob{0%,60%,100%{transform:rotate(0)}70%{transform:rotate(-3deg)}80%{transform:rotate(3deg)}90%{transform:rotate(-2deg)}}.spzz{animation:spZz 2s ease-in-out infinite}@keyframes spZz{0%,100%{opacity:.3}50%{opacity:1}}`;
document.head.appendChild(css);
window.SPSTORY={afterFind,onBud,village,garden,festival,goodbye,muddle,mumSVG,_gd:()=>GD,_mc:()=>MC};
})();
