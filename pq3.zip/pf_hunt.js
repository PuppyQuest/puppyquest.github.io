/* ================================================================
   Puppy Families (26 Nov 2026, claude/puppy-families-design.md sections 7 and 11): the search.
   On the everyday islands (no season picked), once the Puppy Bus has arrived:
   - every found pup whose puppies are lost waits near its home spot with a 💭 thought bubble of three puppy
     outlines; tap it and it sniffs the air and trots off to where its puppies are hiding, waiting for Seb;
   - three tricks, each with three finds (one per puppy):
     peekaboo props (five island-themed hiding places, three puppies; Number Kingdom names 3-D shapes),
     counting trails (stepping stones in threes, then fours and eights; the grown-ups' table in Number Kingdom),
     puppy piles (puppies from two or three families in a heap, sorted to their parents by their markings,
     then "9 puppies in families of 3: how many families?");
   - a family photo for Granny's Pup Book; the family goes home to the Puppy Room as wobbly puppies;
   - 4 families home on an island: its unicorn and foal bring a Parade Rosette, with a lesson.
   ================================================================ */
(function(){
const PL=window.PFLOOK,PF=window.PF,PI=Math.PI,P=id=>PUPS[id],XM=window.XMAS;
const S=()=>PF.S(),S0=()=>PF.S0()||{};
const on=()=>PF.begun()&&!!S0().bus&&!state.season;
const isBonus=p=>ISLANDS.some(I=>(I.bonus||[]).indexOf(p)>=0);
const islOf=p=>islandOf(p.island||(AREAS[p.area]&&AREAS[p.area].island));
const areaF=a=>PL.all().filter(p=>p.area===a);
const lost=p=>isFound(p.id)&&!PF.home(p.id);
const baskId=()=>S0().basket&&S0().basket.pid;
const famIsl=I=>I.pups.concat(I.bonus||[]).filter(p=>PF.home(p.id)&&p.id!==baskId()).length;
const NEED=4;
const hsh=s=>{let h=7;for(let i=0;i<s.length;i++)h=(h*31+s.charCodeAt(i))%100003;return h;};
const r1=q=>[+q[0].toFixed(1),+q[1].toFixed(1)];
const big=e=>`<div style="font-size:90px;line-height:1">${e}</div>`;
/* ---------------- planning the hiding places (test/pf_plan_spots.py saves them in pf_spots.js) ---------------- */
function pileArea(I){let best=null,bn=0;I.areas.forEach(A=>{const n=areaF(A.id).filter(p=>!isBonus(p)).length;if(n>bn){bn=n;best=A.id;}});return bn>=2?best:null;}
function plan(A){const out={};const L=areaF(A.id);if(!L.length)return out;const Gd=XM.grid(A,1),R=seed(hsh(A.id)+91),chosen=[];
  const avoid=[];(W.exits||[]).forEach(e=>avoid.push([e.x,e.z,9]));W.things.forEach(t=>avoid.push([t.x,t.z,4]));if(A.start)avoid.push([A.start[0],A.start[1],8]);
  Object.values(PUPS).filter(p=>p.area===A.id).forEach(p=>{if(p.spot)avoid.push([p.spot.x,p.spot.z,4]);if(p.tag)avoid.push([p.tag.x,p.tag.z,4]);
    [window.XSPOTS,window.GSPOTS,window.HSPOTS,window.SBSPOTS,window.SPSPOTS].forEach(SS=>{const xs=SS&&SS[p.id];if(!xs)return;if(xs.x!=null)avoid.push([xs.x,xs.z,5]);['a','b','c'].forEach(k=>{if(xs[k])avoid.push([xs[k][0],xs[k][1],4]);});});});
  const okAt=(q,sep)=>!avoid.some(a=>Math.hypot(q[0]-a[0],q[1]-a[1])<a[2])&&!chosen.some(c=>Math.hypot(q[0]-c[0],q[1]-c[1])<sep);
  const st=A.start?Gd.snap(A.start[0],A.start[1],1):Gd.snap(0,0,1);if(st<0)return out;const B0=Gd.bfs(st);
  const I=islandOf(A.island),pa=I&&pileArea(I)===A.id,pileL=pa?L.filter(p=>!isBonus(p)).slice(-3):[];let pileH=-1;
  L.forEach(p=>{const sp=p.spot||{x:A.start?A.start[0]:0,z:A.start?A.start[1]:0};
    let a=-1,ab=-1e9;for(let k=0;k<Gd.N;k++){if(Gd.clr[k]<2||B0.D[k]>=1e9)continue;const q=Gd.xz(k),d=Math.hypot(q[0]-sp.x,q[1]-sp.z);if(d<2.6||d>9)continue;if(chosen.some(c=>Math.hypot(q[0]-c[0],q[1]-c[1])<3))continue;const s=-Math.abs(d-3.6)+R()*.6;if(s>ab){ab=s;a=k;}}
    if(a<0)a=Gd.snap(sp.x,sp.z,1);if(a<0)return;const aq=Gd.xz(a);chosen.push(aq);
    const k=pileL.indexOf(p)>=0?'pile':(p.tag||isBonus(p))?'trail':'peek',Ba=Gd.bfs(a);let h=-1;
    if(k==='pile'&&pileH>=0&&Ba.D[pileH]<1e9)h=pileH;
    else{const find=(lo,hi,mc,sep)=>{let hb=-1,hs2=-1e9;for(let q=0;q<Gd.N;q++){if(Gd.clr[q]<mc||Ba.D[q]>=1e9||B0.D[q]>=1e9)continue;const d=Ba.D[q];if(d<lo||d>hi)continue;const qq=Gd.xz(q);if(!okAt(qq,sep))continue;const s=-Math.abs(d-20)*.3+R()*5;if(s>hs2){hs2=s;hb=q;}}return hb;};
      h=find(12,32,3,9);if(h<0)h=find(7,40,2,6);if(h<0)h=find(4,60,1,4);if(h<0)return;if(k==='pile')pileH=h;}
    const hq=Gd.xz(h);chosen.push(hq);out[p.id]={k,a:r1(aq),h:r1(hq),p:Gd.path(Ba,h)};});
  return out;}
let PLAN=null;
function spotFor(p,A){const Q=(window.PFSPOTS||{})[p.id];if(Q)return Q;if(!PLAN||PLAN.area!==A.id){PLAN=plan(A);PLAN.area=A.id;}return PLAN[p.id]||null;}

/* ---------------- the worried parents and the hiding places ---------------- */
const PROPS={meadow:['👢','🪴','🧺','🌾','🪣'],snowy:['🥾','🛷','🧤','⛄','🎿'],reef:['🐚','🪣','🪸','🧰','⛱️'],ninja:['👒','🏮','🥁','📜','🎋'],number:['🧊','🥫','🍦','📦','🔺'],
  gadget:['🧰','📦','🚀','🤖','🔩'],rescue:['🥾','⛑️','🛟','🧯','🎒'],dino:['🥚','🌿','🪣','🪵','🦴'],planet:['🪨','👨‍🚀','🛸','📦','🛰️']};
const SHAPES=[['cube','a cube: six square faces, like a dice'],['cylinder','a cylinder: round at the top and bottom, like a tin of beans'],['cone','a cone: a round bottom and a point at the top'],['cuboid','a cuboid: a long box with rectangle faces'],['pyramid','a pyramid: a square bottom and pointy triangle sides']];
const SURP=[['🐸','A frog! Ribbit!'],['🦔','A sleepy hedgehog, curled up in a ball!'],['🐱','A cat! It gives a big yawn.'],['🦆','A rubber duck! Squeak!'],['⚽','A ball! It bounces out. Boing!'],['🐌','A snail, taking a nap!'],['🐞','A ladybird! It flies away.']];
let LIVE=[];
function famSpots(A){LIVE=[];const piles={};areaF(A.id).filter(lost).forEach(p=>{const Q=spotFor(p,A);if(!Q)return;try{
    if(Q.k==='pile'){const key=Q.h.join(',');if(!piles[key]){piles[key]={k:'pile',L:[],h:Q.h,A};}piles[key].L.push(p);}
    LIVE.push(place(p,Q,A,piles));}catch(e){console.warn('pf spot',p.id,e);}});
  Object.values(piles).forEach(G=>{try{pileProp(G);}catch(e){console.warn('pf pile',e);}});
  if(LIVE.length)W.ticks.push(tick);}
function bubble(p){const k=PF.nGot(p.id);return label(`💭 ${'🐶'.repeat(k)}${'⚪'.repeat(3-k)}`,4.4);}
function place(p,Q,A,piles){const o={p,Q,k:Q.k,A,led:false,done:false,props:[]};const a=Q.a,h=Q.h;
  const g=pup3D(p,p.shiny||bestFriend(p.id));g.rotation.y=Math.atan2(h[0]-a[0],h[1]-a[1]);add(g,a[0],a[1]);o.g=g;o.x=a[0];o.z=a[1];col(a[0],a[1],.9);
  const b=bubble(p);b.position.set(a[0],gy(a[0],a[1])+3.2,a[1]);W.ag.add(b);o.bub=b;
  const th={x:a[0],z:a[1],r:3.2,icon:'🐾',label:`Help ${p.name}`,act:()=>lead(o),show:()=>!o.led&&!o.done};W.things.push(th);o.things=[th];
  if(Q.k==='peek'){const em=PROPS[(islOf(p)||{}).id]||PROPS.meadow,R=seed(hsh(p.id));for(let i=0;i<5;i++){const an=-1.1+i*.55+(R()-.5)*.2,x=h[0]+Math.sin(an)*1.9,z=h[1]+Math.cos(an)*1.9;const s=spr(em[i],1.3,x,gy(x,z)+.75,z);o.props.push(s);}
    const t2={x:h[0],z:h[1],r:3.6,icon:'👀',label:'Peek!',act:()=>openPeek(o),show:()=>!o.done};W.things.push(t2);o.things.push(t2);}
  else if(Q.k==='trail'){const L=Q.p||[a,h],pts=[];for(let i=Math.max(0,L.length-4);i<L.length;i++)pts.push(L[i]);for(let i=1;i<pts.length;i++){const q0=pts[i-1],q1=pts[i];for(let t=0;t<1;t+=.34){const x=q0[0]+(q1[0]-q0[0])*t,z=q0[1]+(q1[1]-q0[1])*t;I('cyl','#c8c2b8',.55,.12,.55,x,gy(x,z)+.06,z);}}
    const s=spr('🪵',1.6,h[0],gy(h[0],h[1])+.8,h[1]);o.props.push(s);const t2={x:h[0],z:h[1],r:3.6,icon:'🔢',label:'Counting stones',act:()=>openTrail(o),show:()=>!o.done};W.things.push(t2);o.things.push(t2);}
  else{const key=Q.h.join(',');piles[key].o=piles[key].o||[];piles[key].o.push(o);}
  return o;}
function pileProp(G){const h=G.h;I('cyl','#c8925a',2.2,.9,2,h[0],gy(h[0],h[1])+.45,h[1]);I('cyl','#fff4dc',2,.15,1.8,h[0],gy(h[0],h[1])+.95,h[1]);col(h[0],h[1],2.2);
  const z=spr('💤',1,h[0],gy(h[0],h[1])+2.4,h[1]);G.o.forEach(o=>o.props.push(z));
  const t2={x:h[0],z:h[1],r:4,icon:'🧺',label:'Puppy pile',act:()=>openPile(G),show:()=>G.o.some(o=>!o.done)};W.things.push(t2);G.o.forEach(o=>o.things.push(t2));}
function tick(dt){LIVE.forEach(o=>{if(o.done)return;const g=o.g;if(o.walk){const w=o.walk,q=w.pts[w.i],dx=q[0]-o.x,dz=q[1]-o.z,d=Math.hypot(dx,dz),far=Math.hypot(player.x-o.x,player.z-o.z);let mv=false;
      if(far>7.5){if(!w.called){w.called=1;say(`${o.p.name} stops and looks back. "Come on, Seb! This way!"`);}g.rotation.y=lerpAng(g.rotation.y,Math.atan2(player.x-o.x,player.z-o.z),Math.min(1,dt*5));}
      else{w.called=0;if(d>.25){const sp=Math.min(d,4.4*dt);o.x+=dx/d*sp;o.z+=dz/d*sp;mv=true;g.rotation.y=lerpAng(g.rotation.y,Math.atan2(dx,dz),Math.min(1,dt*7));}else if(w.i<w.pts.length-1)w.i++;else{o.walk=null;arrive(o);}}
      g.position.set(o.x,gy(o.x,o.z),o.z);o.bub.position.set(o.x,gy(o.x,o.z)+3.2,o.z);animPup(g,W.t,mv);return;}
    animPup(g,W.t,false);o.bub.position.y=gy(o.x,o.z)+3.2+Math.sin(W.t*2+o.x)*.12;});}
function lead(o){if(o.led||o.done||player.lock)return;o.led=true;sfx.sniff();const h=o.Q.h,L=(o.Q.p||[o.Q.a,h]).slice(1),last=L[L.length-1],pen=L.length>1?L[L.length-2]:o.Q.a,dx=last[0]-pen[0],dz=last[1]-pen[1],d=Math.hypot(dx,dz)||1;
  L[L.length-1]=[last[0]-dx/d*2.2,last[1]-dz/d*2.2];o.walk={pts:L,i:0};
  say(`${o.p.name} sniffs the air... "I can smell my puppies! Follow me!" A dog's nose has about 40 times more smell sensors than yours.`);}
function arrive(o){const u=o.g.userData;u.act='sniff';u.at=2;sfx.sniff();o.g.rotation.y=Math.atan2(o.Q.h[0]-o.x,o.Q.h[1]-o.z);
  say(o.k==='peek'?`Sniff, sniff! "They're hiding here somewhere!" Tap 👀 to peek.`:o.k==='trail'?`"Look, stepping stones! Count along them, and they'll lead us to my puppies!"`:`"A puppy pile! My puppies are in there, all mixed up with another family's!"`);}
function bye(o){o.done=true;[o.g,o.bub].concat(o.props).forEach(m=>{if(m&&m.parent)m.parent.remove(m);});W.things=W.things.filter(t=>o.things.indexOf(t)<0);}

/* ---------------- a family is home ---------------- */
function famRec(id){const X=S();if(!X.fam[id])X.fam[id]={g:[0,0,0],st:1,c:0};const f=X.fam[id];if(!f.g)f.g=[0,0,0];return f;}
function gotPup(id,i,how){const f=famRec(id);if(f.g[i])return;f.g[i]=Date.now();f.how=how;state.stars+=1;state.stats.pfpups=(state.stats.pfpups||0)+1;save();hud();
  if(window.PFSTORY&&PFSTORY.onFind)try{PFSTORY.onFind(PF.nPuppies());}catch(e){}}
function home(ids,how,done){const t=Date.now();ids.forEach(id=>{const f=famRec(id);[0,1,2].forEach(i=>{if(!f.g[i])gotPup(id,i,how);});f.how=how;f.st=f.st||1;f.c=f.c||0;f.at=t;});save();
  LIVE.filter(o=>ids.indexOf(o.p.id)>=0).forEach(bye);hud();
  const step=k=>{if(k>=ids.length){const isls=[...new Set(ids.map(id=>islOf(P(id))).filter(Boolean))];return rosettes(isls,0,done);}
    const id=ids[k],p=P(id);sfx.fanfare();confetti(50);player.cheer=1.4;
    card({art:PF.photo(id,{w:300}),h:`${p.name}'s family is home!`,p:`Click! ${PF.list3(PF.names(id))} go into Granny's Pup Book, and off to the Puppy Room to grow up.`,btns:[['📖 +3 ⭐','green',()=>step(k+1)]]});};
  player.lock=true;step(0);}
function rosettes(isls,k,done){if(k>=isls.length){player.lock=false;if(done)done();after();return;}const I=isls[k];if(!I||S().ros&&S().ros[I.id]||famIsl(I)<NEED)return rosettes(isls,k+1,done);rosette(I,()=>rosettes(isls,k+1,done));}
function after(){if(window.PFSTORY&&PFSTORY.afterHome)try{PFSTORY.afterHome();}catch(e){}}
const LESSON={meadow:'Every family is different, and every family is special.',snowy:'Big brothers and sisters can help look after little ones.',reef:'Everyone needs a cuddle sometimes, whether you are little or big.',
  ninja:'Puppies fall over lots when they learn to walk. Keep practising, a little every day.',number:'Count everyone, every time. That\'s how you know nobody is missing.',gadget:'Little ones learn by watching you, so show them kind things.',
  rescue:'If you ever get lost, stay where you are and ask a helper, like a shop worker or a grown-up with children.',dino:'Everybody was little once, even a T. rex.',planet:'Families can be far apart and still love each other, like astronauts calling home from space.'};
function foal(u){const L=Object.assign({},u.look||{});L.hw=(L.hw||58)*1.18;L.hh=(L.hh||52)*1.14;L.bw=(L.bw||44)*.8;L.bh=(L.bh||40)*.74;L.scale=(L.scale||1)*.72;return Object.assign({},u,{id:u.id+'~f',look:L});}
const uniArt=(I,w)=>`<div class="pfuni"><div class="fitsvg" style="width:${w||150}px">${critterSVG(I.boss.uni,{anim:false})}</div><div class="fitsvg pffoal" style="width:${(w||150)*.7}px">${critterSVG(foal(I.boss.uni),{anim:false})}</div></div>`;
function rosette(I,next){const u=I.boss.uni,X=S();X.ros=X.ros||{};sfx.chime();snd3();
  story([{art:uniArt(I,150),t:`${u.name} the unicorn trots up, with a tiny foal wobbling along behind! "Thank you for bringing ${NEED} families home on ${I.name}," says ${u.name}.`},
    {art:uniArt(I,110)+big('🏵️'),t:`"${LESSON[I.id]}" ${u.name} gives you a Parade Rosette for the puppy float!`}],
    ()=>{X.ros[I.id]=Date.now();save();sfx.fanfare();confetti(40);const n=Object.keys(X.ros).length;
      if(n>=ISLANDS.length&&window.PFSTORY&&PFSTORY.call){setTimeout(()=>{try{PFSTORY.call();}catch(e){}if(next)next();},300);return;}
      say(`${n} of ${ISLANDS.length} Parade Rosettes! Bring ${NEED} families home on every island for the Puppy Parade.`);if(next)next();});}
function snd3(){try{const t=AC.currentTime;[784,988,1175].forEach((f,i)=>tone(f,t+i*.12,.25,'triangle',.18));}catch(e){}}

/* ---------------- trick 1: peekaboo props ---------------- */
function ui(id,html){if($('#'+id))return;const d=el('div','ov pfov2',`<div class="card pftrick">${html}<p class="pfmsg"></p><div class="btns"><button class="btn white pfback">Back</button></div></div>`);d.id=id;document.body.appendChild(d);
  tap(d.querySelector('.pfback'),()=>{sfx.boop();closeT(id);});}
let TR=null;
function closeT(id){const d=$('#'+id);if(d)d.classList.remove('on');player.lock=false;TR=null;hush();}
const tmsg=(id,t)=>{const m=$('#'+id+' .pfmsg');if(m)m.textContent=t;speak(t);};
function face(p,w){return `<div class="fitsvg pfface" style="width:${w||110}px">${critterSVG(p,{anim:false})}</div>`;}
function bubbleHTML(id){const k=PF.nGot(id);return `<span class="pfbub">💭 ${[0,1,2].map(i=>PF.got(id,i)?'🐶':'⚪').join('')}</span>`;}
function shapeSVG(k){const S2={cube:'<path d="M30 40 L70 40 L70 80 L30 80 Z M30 40 L46 26 L86 26 L70 40 M70 80 L86 66 L86 26" fill="#8fd0ff" stroke="#26232e" stroke-width="4" stroke-linejoin="round"/>',
  cylinder:'<ellipse cx="55" cy="28" rx="26" ry="10" fill="#ffd23f" stroke="#26232e" stroke-width="4"/><path d="M29 28 V76 A26 10 0 0 0 81 76 V28" fill="#ffd23f" stroke="#26232e" stroke-width="4"/>',
  cone:'<path d="M55 16 L28 76 A27 10 0 0 0 82 76 Z" fill="#ff9ecb" stroke="#26232e" stroke-width="4" stroke-linejoin="round"/>',
  cuboid:'<path d="M14 44 L76 44 L76 80 L14 80 Z M14 44 L28 32 L92 32 L76 44 M76 80 L92 68 L92 32" fill="#9ae07a" stroke="#26232e" stroke-width="4" stroke-linejoin="round"/>',
  pyramid:'<path d="M55 14 L22 70 L70 82 Z M55 14 L70 82 L92 66 Z" fill="#ffb347" stroke="#26232e" stroke-width="4" stroke-linejoin="round"/>'};return `<svg viewBox="0 0 110 96" class="pfshape">${S2[k]}</svg>`;}
function openPeek(o){if(player.lock||o.done)return;const p=o.p,id=p.id,I=islOf(p)||{},num=I.id==='number',em=PROPS[I.id]||PROPS.meadow,R=seed(hsh(id)+Date.now()%997);
  ui('pfpeek','<h2 class="pfth"></h2><div class="pfwho"></div><div class="pfprops"></div>');player.lock=true;hush();
  const left=[0,1,2].filter(i=>!PF.got(id,i)),slots=[0,1,2,3,4].sort(()=>R()-.5),hide={};left.forEach((i,k)=>{hide[slots[k]]=i;});const surp=SURP.slice().sort(()=>R()-.5);
  TR={o,hide,tried:{},wrong:0};const d=$('#pfpeek');d.querySelector('.pfth').textContent=`👀 Where are ${p.name}'s puppies?`;
  const order=()=>Object.keys(hide).filter(k=>!TR.tried[k]).map(Number);
  const clue=()=>{if(!num)return `"Sniff, sniff! ${left.length===3?'Three':left.length===2?'Two':'One'} of my puppies ${left.length>1?'are':'is'} hiding here!"`;const nx=order()[0];return nx==null?'':`"Sniff! The next puppy is in the <b>${SHAPES[nx][0]}</b>!"`;};
  const who=()=>{d.querySelector('.pfwho').innerHTML=`${face(p,96)}<div class="pfsay">${clue()}<br>${bubbleHTML(id)}</div>`;};who();
  d.querySelector('.pfprops').innerHTML=[0,1,2,3,4].map(k=>`<button class="pfprop" data-k="${k}"><span class="pfpi">${num?shapeSVG(SHAPES[k][0]):`<span class="pfem">${em[k]}</span>`}</span>${num?`<b>${SHAPES[k][0]}</b>`:''}<span class="pfout"></span></button>`).join('');
  d.classList.add('on');tmsg('pfpeek',num?clue().replace(/<[^>]+>/g,''):'Tap the hiding places to peek inside!');
  d.querySelectorAll('.pfprop').forEach(b=>tap(b,()=>{if(!TR||TR.busy)return;const k=+b.dataset.k;if(TR.tried[k])return;
    if(num){const nx=order()[0];if(nx!=null&&k!==nx){sfx.oops();b.classList.add('shake');setTimeout(()=>b.classList.remove('shake'),500);tmsg('pfpeek',`That's the ${SHAPES[k][0]}. Look for ${SHAPES[nx][1]}!`);TR.wrong++;if(TR.wrong>=2)d.querySelector(`.pfprop[data-k="${nx}"]`).classList.add('hint');return;}}
    TR.tried[k]=1;b.classList.add('wob');TR.busy=1;sfx.pop();
    setTimeout(()=>{TR.busy=0;if(hide[k]!=null){const i=hide[k];b.classList.add('got');b.querySelector('.pfout').innerHTML=`<span class="pfpop">${PL.svg(p,i,1,{anim:false})}</span>`;gotPup(id,i,'peek');sfx.yip(1.9);
        d.querySelectorAll('.pfprop.hint').forEach(e=>e.classList.remove('hint'));who();const n=PF.nGot(id);tmsg('pfpeek',`${PF.nm(id,i)}! ${n<3?`${3-n} more to find!`:'That\'s all three!'}`);
        if(n>=3)setTimeout(()=>{closeT('pfpeek');home([id],'peek');},1500);}
      else{const s=surp.pop()||SURP[0];b.classList.add('nope');b.querySelector('.pfout').innerHTML=`<span class="pfsurp">${s[0]}</span>`;sfx.giggle();TR.wrong++;tmsg('pfpeek',s[1]);
        if(!num&&TR.wrong>=1){const nx=order()[0];if(nx!=null)setTimeout(()=>{const e=d.querySelector(`.pfprop[data-k="${nx}"]`);if(e&&TR)e.classList.add('hint');tmsg('pfpeek',`${p.name} sniffs and wags at one of the hiding places!`);},1200);}}},450);}));}

/* ---------------- trick 2: counting trails ---------------- */
function trailSeq(p){const I=islOf(p)||{},R=seed(hsh(p.id)+3);let step=3,start=3,back=false;
  if(I.id==='ninja'||I.id==='gadget'||I.id==='rescue'){start=3*(3+Math.floor(R()*4));}
  else if(I.id==='dino'){step=4;start=4;}else if(I.id==='planet'){step=8;start=8;}
  else if(I.id==='number'){const tb=typeof tablesOn==='function'?(tablesOn()||[]).filter(v=>v>=2&&v<=12):[];if(tb.length){step=tb[Math.floor(R()*tb.length)];start=step;}else{step=3;start=30;back=true;}}
  const seq=[];for(let i=0;i<5;i++)seq.push(back?start-i*step:start+i*step);
  const dis=new Set();const all=seq.slice();seq.forEach(v=>[v+1,v-1,v+2].forEach(x=>{if(x>0&&all.indexOf(x)<0&&dis.size<4)dis.add(x);}));
  return {seq,dis:[...dis],step,back};}
function openTrail(o){if(player.lock||o.done)return;const p=o.p,id=p.id,Q=trailSeq(p),R=seed(hsh(id)+11);
  ui('pftrail','<h2 class="pfth"></h2><div class="pfwho"></div><div class="pfpond"><svg viewBox="0 0 900 330" class="pfwater"><rect x="0" y="0" width="900" height="330" rx="26" fill="#8fd0ff"/><path d="M0 60 Q120 40 260 70 T540 60 T900 70" stroke="#c8ecff" stroke-width="8" fill="none"/><path d="M0 250 Q160 230 300 260 T620 250 T900 262" stroke="#c8ecff" stroke-width="8" fill="none"/><rect x="796" y="0" width="104" height="330" rx="26" fill="#9ad870"/><rect x="0" y="0" width="96" height="330" rx="26" fill="#9ad870"/></svg><div class="pfstones"></div><div class="pfhop"></div><div class="pfend"></div></div>');
  player.lock=true;hush();const d=$('#pftrail');d.querySelector('.pfth').textContent=`🔢 Count ${Q.back?'back':'on'} in ${Q.step}s to find ${p.name}'s puppies!`;
  d.querySelector('.pfwho').innerHTML=`${face(p,80)}<div class="pfsay">"Hop on the stones in order: ${Q.seq[0]}, ${Q.seq[1]}, ... ${Q.back?'counting back':'counting on'} in ${Q.step}s!"<br>${bubbleHTML(id)}</div>`;
  const vals=Q.seq.map(v=>({v,ok:1})).concat(Q.dis.map(v=>({v,ok:0}))),cols=[150,280,410,540,670];
  const pos=[];Q.seq.forEach((v,i)=>pos.push([cols[i],70+R()*190]));Q.dis.forEach((v,i)=>{const c=cols[(i*2+1)%5]+(R()-.5)*40;let y=70+R()*190;const near=pos.find(q=>Math.abs(q[0]-c)<70&&Math.abs(q[1]-y)<80);if(near)y=near[1]>165?near[1]-110:near[1]+110;pos.push([c,Math.max(50,Math.min(280,y))]);});
  d.querySelector('.pfstones').innerHTML=vals.map((s,k)=>`<button class="pfstone" data-k="${k}" style="left:${pos[k][0]/9}%;top:${pos[k][1]/3.3}%"><b>${s.v}</b></button>`).join('');
  d.querySelector('.pfend').innerHTML=[0,1,2].map(i=>`<span>${PL.svg(p,i,1,{anim:false,sleep:true})}</span>`).join('');
  const hop=d.querySelector('.pfhop');hop.innerHTML=PL.svg(p,0,1,{anim:false});hop.style.left='2%';hop.style.top='40%';
  TR={o,i:0,wrong:0};d.classList.add('on');tmsg('pftrail',`Tap the stone with ${Q.seq[0]} on it!`);
  d.querySelectorAll('.pfstone').forEach(b=>tap(b,()=>{if(!TR||TR.busy)return;const k=+b.dataset.k,s=vals[k];if(b.classList.contains('on'))return;
    if(k===TR.i){b.classList.add('on');sfx.pop();hop.style.left=(pos[k][0]/9-3)+'%';hop.style.top=(pos[k][1]/3.3-22)+'%';TR.i++;d.querySelectorAll('.pfstone.hint').forEach(e=>e.classList.remove('hint'));TR.wrong=0;
      if(TR.i>=Q.seq.length){TR.busy=1;tmsg('pftrail',`${Q.seq.join(', ')}! You counted ${Q.back?'back':'on'} in ${Q.step}s!`);setTimeout(()=>{hop.style.left='86%';hop.style.top='30%';sfx.yip(1.9);d.querySelector('.pfend').classList.add('found');},700);
        setTimeout(()=>{closeT('pftrail');home([id],'trail');},2600);}else tmsg('pftrail',`${s.v}! Now ${Q.seq[TR.i]}...`);speak(String(s.v));return;}
    sfx.oops();b.classList.add('shake');setTimeout(()=>b.classList.remove('shake'),500);TR.wrong++;const want=Q.seq[TR.i];
    tmsg('pftrail',`That stone says ${s.v}. We need ${want}: ${TR.i?`${Q.seq[TR.i-1]} ${Q.back?'take away':'add'} ${Q.step}`:`the first one, ${want}`}.`);
    if(TR.wrong>=2)d.querySelector(`.pfstone[data-k="${TR.i}"]`).classList.add('hint');}));}

/* ---------------- trick 3: puppy piles ---------------- */
function openPile(G,opt){opt=opt||{};if(player.lock)return;const L=opt.practice?G.L.slice():G.L.filter(p=>lost(p));if(!L.length)return;const R=seed(Date.now()%9973),T0=Date.now();
  ui('pfpile','<h2 class="pfth"></h2><div class="pfwho"></div><div class="pfpilebox"><div class="pfheap"></div><div class="pfpars"></div></div>');player.lock=true;hush();
  const d=$('#pfpile'),U=[];L.forEach(p=>[0,1,2].forEach(i=>U.push({p,i})));U.sort(()=>R()-.5);
  d.querySelector('.pfth').textContent=L.length>1?`🧺 A puppy pile! ${U.length} puppies, all mixed up!`:'🧺 A puppy pile!';
  d.querySelector('.pfwho').innerHTML=`<div class="pfsay">Tap a puppy, then tap the grown-up pup it belongs to. Look at the coat, the ears and the tail!</div>`;
  d.querySelector('.pfheap').innerHTML=U.map((u,k)=>`<button class="pfhp" data-k="${k}">${PL.svg(u.p,u.i,1,{anim:false})}</button>`).join('');
  d.querySelector('.pfpars').innerHTML=L.map(p=>`<button class="pfpar" data-id="${p.id}">${face(p,120)}<b>${p.name}</b><span class="pfkids"></span></button>`).join('');
  TR={G,L,U,sel:null,n:0,wrong:{}};d.classList.add('on');tmsg('pfpile','Tap a puppy, then tap its mum or dad!');
  d.querySelectorAll('.pfhp').forEach(b=>tap(b,()=>{if(!TR||b.classList.contains('gone'))return;sfx.boop();d.querySelectorAll('.pfhp.sel').forEach(e=>e.classList.remove('sel'));b.classList.add('sel');TR.sel=+b.dataset.k;}));
  d.querySelectorAll('.pfpar').forEach(b=>tap(b,()=>{if(!TR||TR.sel==null||TR.ask)return;const u=TR.U[TR.sel],hb=d.querySelector(`.pfhp[data-k="${TR.sel}"]`);
    if(b.dataset.id===u.p.id){hb.classList.add('gone');hb.classList.remove('sel');b.querySelector('.pfkids').insertAdjacentHTML('beforeend',`<i>${PL.svg(u.p,u.i,1,{anim:false})}</i>`);if(!opt.practice)gotPup(u.p.id,u.i,'pile');sfx.yip(1.9);TR.n++;TR.sel=null;
      d.querySelectorAll('.pfpar.hint').forEach(e=>e.classList.remove('hint'));tmsg('pfpile',`${PF.nm(u.p.id,u.i)} snuggles up to ${u.p.name}!`);if(TR.n>=TR.U.length)setTimeout(ask,900);return;}
    sfx.oops();const k=TR.sel;TR.wrong[k]=(TR.wrong[k]||0)+1;b.classList.add('shake');setTimeout(()=>b.classList.remove('shake'),500);hb.classList.add('sneeze');setTimeout(()=>hb.classList.remove('sneeze'),700);
    tmsg('pfpile',`Achoo! That's not ${PF.nm(u.p.id,u.i)}'s family. Look at the coat colour and the ears!`);if(TR.wrong[k]>=2)d.querySelector(`.pfpar[data-id="${u.p.id}"]`).classList.add('hint');}));
  function ask(){const n=TR.U.length,f=TR.L.length;TR.ask=1;const opts=[...new Set([f,f+1,Math.max(1,f-1),f+2])].filter(v=>v!==0).slice(0,3).sort((a,b)=>a-b);
    d.querySelector('.pfwho').innerHTML=`<div class="pfsay pfaskq">${n} puppies, in families of 3. How many families?<div class="pfans">${opts.map(v=>`<button class="btn blue" data-v="${v}">${v}</button>`).join('')}</div></div>`;speak(`${n} puppies, in families of 3. How many families?`);let w=0;
    d.querySelectorAll('.pfaskq .btn').forEach(b=>tap(b,()=>{const v=+b.dataset.v;if(v===f){b.classList.add('win');sfx.chime();tmsg('pfpile',`Yes! ${n} shared into threes makes ${f} ${f>1?'families':'family'}.`);const ids=TR.L.map(p=>p.id);setTimeout(()=>{closeT('pfpile');if(opt.practice){if(opt.done)opt.done((Date.now()-T0)/1000);return;}home(ids,'pile');},1800);return;}
      w++;b.classList.add('nope');sfx.oops();tmsg('pfpile',`Count the families: each grown-up pup has 3 puppies.`);if(w>=2)d.querySelectorAll('.pfaskq .btn').forEach(q=>{if(+q.dataset.v===f)q.classList.add('hint');});}));}}

/* ---------------- hooks ---------------- */
const _bs=buildSpots;buildSpots=function(A){_bs(A);if(on()&&A.island)try{famSpots(A);}catch(e){console.warn('pf spots',e);}};
const _ac=areaCount;areaCount=function(a){const base=_ac(a);if(!on())return base;const L=areaF(a).filter(p=>isFound(p.id));if(!L.length)return base;const n=L.reduce((s,p)=>s+PF.nGot(p.id),0);return `${base?base+'  ':''}🐾 ${n}/${L.length*3}`;};
const css=document.createElement('style');css.textContent=`
.pfov2{z-index:60}.pftrick{max-width:980px;width:96%;background:#fff8ec;padding-top:10px}.pftrick h2{margin:0 0 4px}.pfmsg{min-height:34px;font-size:24px;font-weight:800;margin:6px 0}
.pfwho{display:flex;align-items:center;justify-content:center;gap:14px;margin:2px 0 6px}.pfface svg{width:100%;height:auto;display:block}.pfsay{font-size:24px;font-weight:800;background:#fff;border:4px solid #e8b877;border-radius:20px;padding:8px 16px;line-height:1.3}.pfsay b{color:#c83a7a}.pfbub{font-size:28px}
.pfprops{display:flex;gap:12px;justify-content:center;flex-wrap:wrap}.pfprop{position:relative;width:170px;height:200px;border:4px solid #e8c890;border-radius:24px;background:#fff6e0;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;padding-bottom:10px}
.pfprop .pfem{font-size:96px;line-height:1}.pfprop b{font-size:22px}.pfprop .pfshape{width:120px;height:auto}.pfprop.wob .pfpi{animation:pfwob .45s}.pfprop.nope{background:#f0ece4;border-color:#d8d0c0}.pfprop.got{background:#fff0c0;border-color:#ffd23f}.pfprop.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
.pfprop.shake,.pfpar.shake,.pfstone.shake{animation:pfshake .4s}@keyframes pfshake{0%,100%{transform:translateX(0)}25%{transform:translateX(-8px)}75%{transform:translateX(8px)}}@keyframes pfwob{0%,100%{transform:rotate(0)}30%{transform:rotate(-12deg)}70%{transform:rotate(12deg)}}
.pfout{position:absolute;left:0;right:0;top:-10px;display:flex;justify-content:center;pointer-events:none}.pfpop{width:130px;animation:xpop .5s}.pfpop svg{width:100%;height:auto}.pfsurp{font-size:70px;animation:xpop .5s}
.pfpond{position:relative;width:900px;max-width:100%;margin:0 auto}.pfwater{width:100%;height:auto;display:block}.pfstones{position:absolute;inset:0}
.pfstone{position:absolute;transform:translate(-50%,-50%);width:96px;height:72px;border-radius:50%;background:#c8c2b8;border:5px solid #8a8478;box-shadow:0 6px 0 #7a7468;cursor:pointer}.pfstone b{font-size:32px;font-weight:900}.pfstone.on{background:#ffe680;border-color:#e8b020}.pfstone.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
.pfhop{position:absolute;width:90px;transition:left .45s ease-out,top .45s ease-out;pointer-events:none;z-index:3}.pfhop svg{width:100%;height:auto}
.pfend{position:absolute;right:1%;top:55%;width:110px;display:flex;flex-wrap:wrap;opacity:.95}.pfend span{width:50%}.pfend span svg{width:100%;height:auto}.pfend.found{animation:xpop .5s}
.pfpilebox{display:flex;gap:16px;align-items:flex-start;justify-content:center}.pfheap{display:flex;flex-wrap:wrap;width:440px;background:#f8e2c0;border:5px solid #c8925a;border-radius:40px 40px 60px 60px;padding:10px;justify-content:center}
.pfhp{width:100px;background:none;border:4px solid transparent;border-radius:18px;padding:0;cursor:pointer}.pfhp svg{width:100%;height:auto}.pfhp.sel{border-color:#ff6fae;background:#fff0f6}.pfhp.gone{visibility:hidden}.pfhp.sneeze{animation:pfshake .4s}
.pfpars{display:flex;flex-direction:column;gap:8px}.pfpar{display:flex;align-items:center;gap:8px;background:#fff;border:4px solid #e8c890;border-radius:20px;padding:4px 10px;cursor:pointer;min-width:380px}.pfpar b{font-size:22px}.pfpar.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
.pfkids{display:flex}.pfkids i{width:64px}.pfkids i svg{width:100%;height:auto}.pfaskq .pfans{display:flex;gap:12px;justify-content:center;margin-top:8px}.pfaskq .btn{min-width:90px;min-height:70px;font-size:34px;font-weight:900}.pfaskq .btn.nope{opacity:.4}.pfaskq .btn.win{background:#8ae05a}.pfaskq .btn.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}
.pfuni{display:inline-flex;align-items:flex-end;gap:4px}.pfuni .fitsvg svg{width:100%;height:auto}`;
document.head.appendChild(css);
window.PFHUNT={_tr:()=>TR,on,plan,spotFor,famSpots,LIVE:()=>LIVE,lead,openPeek,openTrail,openPile,home,gotPup,famIsl,NEED,LESSON,uniArt,foal,rosette,islOf,trailSeq,pileArea,areaF};
})();
