/* ================================================================
   Seb's Puppy Quest 3: Release 7, eight more science pups.
   Gadget Island: Leonardo da Woofi, Marie Curly, Alexander Graham
   Bark and Orville Bright. Rescue Bay: Florence Night-in-tail,
   Alexander Flea-ming, Isambark Kingdom Brunel and Mary Seacollie.
   Facts are about the real people; the pups are characters inspired
   by them. Try-at-home cards are safe and need a grown-up where it
   matters.
   ================================================================ */
(function(){
const R=seed(7070),{sortExp,choiceRow,bigBtn,place,labBenchSVG}=SCIX;
const glow=c=>{const m=new THREE.MeshBasicMaterial({color:c});W.disp.push(m);return m;};
const svgEl=(w,h,inner,vb)=>`<svg viewBox="${vb||`0 0 ${w} ${h}`}" width="${w}" height="${h}">${inner}</svg>`;

/* ----------------- the 8 science pups ----------------- */
const S=[
 /* Gadget Island */
 {id:'dawoofi',name:'Leonardo da Woofi',who:'Leonardo da Vinci',breed:'Spinone Italiano',island:'gadget',area:'workshop',spot:{x:12,z:-36,kind:'crate'},prop:'🪂',exp:'chute',expName:'Parachute Drop',
  hint:'Look in a crate behind the Workshop, by the parachute model.',
  fact:'Leonardo da Woofi is named after the real Leonardo da Vinci, who lived in Italy over 500 years ago. He was a painter and an inventor. He drew ideas for flying machines, and a parachute shaped like a pyramid!',
  home:'Make a parachute from a paper napkin, with four pieces of thread tied to the corners and to a small toy. Stand on the floor, hold it up high and let go. Then try it without the napkin. Never drop things from a window or the stairs.',
  rescue:{icon:'🪂',verb:'Untangle',say:'Da Woofi is tangled in parachute strings! Tap to untangle them!'},
  look:{fur:'#f2ece2',ear:'#c8843a',ears:'floppy',fluffy:true,muzzle:'#f2ece2',muzzleBig:true,belly:'#ffffff',patch:'#c8843a',spots:true,spotC:'#d8a070',tail:'thin',acc:['grad']},
  deco(x,z){const ex=x-5,ez=z+1,y=gy(ex,ez);I('box','#9b6a43',.15,3.4,.15,ex-.8,y+1.6,ez+.2,-.15,0,0);I('box','#9b6a43',.15,3.4,.15,ex+.8,y+1.6,ez+.2,-.15,0,0);I('box','#9b6a43',.15,3.2,.15,ex,y+1.5,ez-.7,.35,0,0);
    I('box','#f2e6c0',2.4,1.8,.08,ex,y+2.5,ez+.45,-.15,0,0);spr('🪂',1,ex,y+2.6,ez+.6);col(ex,ez,1.2);
    const px=x+4.5,pz=z-1,py=gy(px,pz);[-1.8,1.8].forEach(s=>{I('cyl','#9b6a43',.12,5.6,.12,px+s,py+2.8,pz);col(px+s,pz,.4);});I('box','#9b6a43',3.9,.18,.18,px,py+5.6,pz);
    const ch=grp();mk('pyr','#f2e6c0',1.5,1.3,1.5,0,0,0,ch);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(q=>{const c=mk('cyl','#5b4636',.02,1.9,.02,q[0]*.4,-1.3,q[1]*.4,ch);c.rotation.z=-q[0]*.3;c.rotation.x=q[1]*.3;});
    const ted=sprite('🧸',.9);ted.position.y=-2.2;ch.add(ted);add(ch,px,pz,py+4.4);W.ticks.push(()=>{ch.position.y=py+4.2+Math.sin(W.t*1.1)*.3;ch.rotation.y+=.004;});
    sign(x-1,z+4.5,"🪂 Leonardo's parachute",2.6,6.4);}},
 {id:'curly',name:'Marie Curly',who:'Marie Curie',breed:'Polish Lowland Sheepdog',island:'gadget',area:'lightlab',spot:{x:-26,z:-24,kind:'books'},prop:'🩻',exp:'xray',expName:'X-ray Vision',
  hint:'Look by the books next to the X-ray van in the Light Lab.',
  fact:'Marie Curly is named after the real Marie Curie, a scientist from Poland who worked in France. She was the first person ever to win two Nobel Prizes. In the First World War she set up X-ray vans, so doctors could see broken bones and help injured soldiers.',
  home:'In a dark room, ask a grown-up to shine a torch behind your fingers. They glow red, because a little light passes through your skin! X-rays go right through skin, but bones stop them. Never shine a torch into anyone\'s eyes.',
  rescue:{icon:'🔦',verb:'Shine',say:'Marie Curly is in the dark! Tap to shine a light!'},
  look:{fur:'#d8d2c8',ears:'floppy',fluffy:true,wool:true,fringe:'#bdb5a8',muzzle:'#e8e2d8',belly:'#ece6dc',patch:'#8a8378',tail:'stub',acc:['grad']},
  deco(x,z){const bx=x+5,bz=z+1,y=gy(bx,bz);I('box','#3a3338',3.4,2.6,.3,bx,y+2.6,bz);const pn=new THREE.Mesh(G.box,glow('#d9f0ff'));pn.scale.set(3,2.2,.32);pn.position.set(bx,y+2.6,bz);W.ag.add(pn);spr('🩻',1.5,bx,y+2.6,bz+.35);
    [-1.2,1.2].forEach(s=>I('cyl','#8a8f99',.08,1.4,.08,bx+s,y+.7,bz));col(bx,bz,1.8);
    const vx=x-2,vz=z-6.5,vy=gy(vx,vz),g=grp();mk('box','#e6e0d0',2.4,2.2,4.2,0,1.5,0,g);mk('box','#e6e0d0',2.4,1.4,1.6,0,1.1,2.9,g);mk('box','#9bdcff',2.2,.6,.1,0,1.5,3.71,g);mk('box','#3d8fe0',2.42,.3,4.2,0,1.9,0,g);
    [[-1.2,-1.4],[1.2,-1.4],[-1.2,2.5],[1.2,2.5]].forEach(q=>mk('cyl','#26232e',.5,.3,.5,q[0],.5,q[1],g).rotation.z=Math.PI/2);add(g,vx,vz,vy);g.rotation.y=.6;spr('🩻',1.1,vx,vy+3.3,vz);col(vx,vz,2.1);col(vx+1.3,vz+1.9,1.3);col(vx-1,vz-1.4,1.3);
    sign(x+1.5,z+5,'🩻 X-ray van',2.6,5);}},
 {id:'grahambark',name:'Alexander Graham Bark',who:'Alexander Graham Bell',breed:'Scottish Deerhound',island:'gadget',area:'factory',spot:{x:38,z:10,kind:'crate'},prop:'☎️',exp:'phone',expName:'Tin-Can Phone',
  hint:'Look in a crate by the tin-can phone at the Factory.',
  fact:'Alexander Graham Bark is named after the real Alexander Graham Bell, who was born in Scotland. He taught deaf children, and in 1876 he got the first patent for a telephone. A telephone turns your voice into electricity, and back into sound at the other end!',
  home:'Make a phone from two paper cups and a long piece of string. Ask a grown-up to poke a small hole in the bottom of each cup, thread the string through and tie a knot. Pull the string tight, and talk into one cup while a friend listens!',
  rescue:{icon:'📞',verb:'Answer',say:'The phone is ringing and ringing! Tap to answer it for Graham Bark!'},
  look:{fur:'#8a8f99',ears:'fold',fluffy:true,muzzle:'#7a7f88',muzzleBig:true,belly:'#9a9fa8',tail:'thin',hw:56,hh:56,acc:['grad','scarf'],scarfC:'#3d6fb0'},
  deco(x,z){const a=[x-5,z-3.5],b=[x-5,z+4.5];[a,b].forEach((q,i)=>{const y=gy(q[0],q[1]);I('cyl','#9b6a43',.15,2.4,.15,q[0],y+1.2,q[1]);I('cyl','#c9c2b8',.35,.7,.35,q[0],y+2.6,q[1]+(i?-.35:.35),Math.PI/2,0,0);col(q[0],q[1],.4);});
    I('box','#f2e6c0',.05,.05,7.3,a[0],gy(a[0],z)+2.6,(a[1]+b[1])/2);spr('☎️',1.2,x-7,gy(x-7,z+.5)+1.4,z+.5);spr('〰️',.7,a[0],gy(a[0],z)+3.2,z);
    sign(x-1,z-6.5,'☎️ Tin-can phone',2.6,5.6);}},
 {id:'bright',name:'Orville Bright',who:'Orville and Wilbur Wright',breed:'Toy Fox Terrier',island:'gadget',area:'launch',spot:{x:32,z:-20,kind:'sandcastle'},prop:'✈️',exp:'planes',expName:'Paper Planes',
  hint:'Look by the sand dune and the old wooden aeroplane at the Launch Range.',
  fact:'Orville Bright is named after the real Orville Wright. He and his brother Wilbur built the first aeroplane with an engine that a pilot could fly and steer. On 17 December 1903, Orville flew it for 12 seconds at Kitty Hawk in America!',
  home:'Fold a paper aeroplane and throw it gently. Then bend up the back edges of both wings a little and throw again. What happens? Now bend up just one side! Always throw it away from people\'s faces.',
  rescue:{icon:'🪁',verb:'Catch',say:'Orville Bright is chasing a paper plane in the wind! Tap to catch it!'},
  look:{fur:'#ffffff',ear:'#26232e',ears:'pointy',earBig:true,patch:'#26232e',brows:'#c8843a',muzzle:'#ffffff',belly:'#ffffff',tail:'stub',scale:.78,acc:['grad','scarf'],scarfC:'#ffffff'},
  deco(x,z){const fx=x-5,fz=z+4,y=gy(fx,fz);const dune=new THREE.Mesh(G.hemi,M('#e8d9a8'));dune.scale.set(5,1.3,3.4);dune.position.set(x+4,gy(x+4,z-4)-.2,z-4);W.ag.add(dune);col(x+4,z-4,2.6);
    for(let i=0;i<9;i++)I('box','#9b6a43',.3,.14,1.1,fx-4+i,y+.08,fz);I('box','#5b4636',9,.1,.12,fx,y+.18,fz);
    const g=grp(),props=[];[0,1.1].forEach(h=>mk('box','#f2ecd8',5.6,.08,1.1,0,.9+h,0,g));for(let i=0;i<4;i++)[.45,-.45].forEach(q=>mk('cyl','#9b6a43',.035,1.1,.035,-2.4+i*1.6,1.45,q,g));
    mk('box','#f2ecd8',1.8,.06,.5,0,1.2,2,g);mk('box','#9b6a43',.08,.08,2,0,1.2,1,g);mk('box','#f2ecd8',.06,.9,.5,0,1.45,-2,g);mk('box','#9b6a43',.08,.08,1.6,0,1.45,-1.2,g);
    [-.9,.9].forEach(s=>{const pr=grp();mk('box','#9b6a43',.12,1.2,.1,0,0,0,pr);pr.position.set(s,1.45,-.75);g.add(pr);props.push(pr);});
    add(g,fx,fz,y);g.rotation.y=Math.PI/2;W.ticks.push(dt=>props.forEach(pr=>{pr.rotation.z+=dt*9;}));col(fx,fz,1.4);col(fx,fz-2.2,1.1);col(fx,fz+2.2,1.1);
    sign(x+1,z+8,'✈️ The 1903 Flyer',2.6,5.6);}},
 /* Rescue Bay */
 {id:'nightintail',name:'Florence Night-in-tail',who:'Florence Nightingale',breed:'Lancashire Heeler',island:'rescue',area:'bigrescue',spot:{x:30,z:-20,kind:'tent'},prop:'🧼',exp:'germs',expName:'Wash Away Germs',
  hint:'Look in a tent next to the hospital tent at the Big Rescue.',
  fact:'Florence Night-in-tail is named after the real Florence Nightingale, a nurse in the Crimean War in the 1850s. She made the army hospitals clean, with fresh air and washing, and far fewer soldiers died. She checked on them at night with a lamp, so people called her the Lady with the Lamp.',
  home:'With a grown-up, sprinkle some pepper on a bowl of water. Pretend the pepper is germs. Touch the middle with a clean finger, then put a drop of washing-up liquid on your finger and touch it again. Whoosh! Soap is great at getting dirt and germs off. Keep pepper away from your eyes, and wash your hands after.',
  rescue:{icon:'🫧',verb:'Scrub',say:'Night-in-tail has muddy paws! Tap to scrub them clean!'},
  look:{fur:'#26232e',ear:'#26232e',ears:'pointy',muzzle:'#c8843a',brows:'#c8843a',paw:'#c8843a',belly:'#3a3338',tail:'curl',scale:.82,acc:['grad','glow']},
  deco(x,z){const tx=x-7,tz=z+1,H=house(tx,tz,{w:6,d:5,h:2.6,wall:'#f4f2ea',roof:'#e6e0d0',trim:'#3fae5a',win:0,chimney:false,face:'e',label:'⛺ Hospital tent',lw:5.6}),y=H.y;
    I('box','#3fae5a',.06,1.2,.4,tx+3.04,y+1.7,tz-1.4);I('box','#3fae5a',.06,.4,1.2,tx+3.04,y+1.7,tz-1.4);
    {const lx=x-2,lz=z+5,ly=gy(lx,lz);I('cyl','#5b4636',.08,2,.08,lx,ly+1,lz);I('box','#c9a86a',.45,.55,.45,lx,ly+2.2,lz);const b=new THREE.Mesh(G.sph,glow('#fff27a'));b.scale.set(.18,.22,.18);b.position.set(lx,ly+2.2,lz);W.ag.add(b);col(lx,lz,.3);}
    {const wx=x+4,wz=z+4,wy=gy(wx,wz);I('box','#9b6a43',1.3,1,.9,wx,wy+.5,wz);I('cyl','#ffffff',.45,.16,.45,wx,wy+1.08,wz);spr('🧼',.6,wx+.4,wy+1.4,wz);col(wx,wz,.9);}}},
 {id:'fleaming',name:'Alexander Flea-ming',who:'Alexander Fleming',breed:'Skye Terrier',island:'rescue',area:'ranger',spot:{x:18,z:-34,kind:'log'},prop:'🧫',exp:'petri',expName:'Mould Watch',
  hint:'Look by a log near the mould lab at the Ranger Station.',
  fact:'Alexander Flea-ming is named after the real Alexander Fleming, a scientist from Scotland. In 1928 he saw mould growing in one of his dishes, and the germs near it had stopped growing. It led to penicillin, the first antibiotic medicine, which has saved millions of lives.',
  home:'Put a slice of bread in a clear food bag with a few drops of water, and seal it. Seal a dry slice in another bag and keep it in the fridge. Look at them through the bags each day, but never open them. After a week, a grown-up throws the bags away still sealed.',
  rescue:{icon:'🍄',verb:'Brush',say:'Flea-ming is covered in fluffy dandelion seeds! Tap to brush them off!'},
  look:{fur:'#9a9488',ear:'#7a7468',ears:'long',fluffy:true,fringe:'#8a8478',muzzle:'#8a8478',belly:'#a8a296',long:true,tail:'plume',scale:.85,acc:['grad']},
  deco(x,z){const tx=x-5.5,tz=z+1,y=gy(tx,tz);I('box','#e6e0d0',3.4,.2,1.8,tx,y+1.4,tz);[[-1.4,-.7],[1.4,-.7],[-1.4,.7],[1.4,.7]].forEach(q=>I('cyl','#8a8f99',.08,1.4,.08,tx+q[0],y+.7,tz+q[1]));
    for(let i=0;i<4;i++){const dx=tx-1.2+i*.75,dz=tz-.3+(i%2)*.5;I('cyl','#e8f6ff',.32,.08,.32,dx,y+1.55,dz,0,0,0,true);I('sphL','#6fbf5a',.14,.06,.14,dx+.05,y+1.62,dz);if(i%2)I('sphL','#ffd23f',.05,.03,.05,dx-.15,y+1.61,dz+.1);}
    spr('🔬',1.1,tx+1.2,y+2.2,tz);spr('🍞',.8,tx-1.3,y+2,tz+.4);col(tx,tz,1.9);
    sign(x+1,z+5,'🧫 Mould lab',2.6,5);}},
 {id:'brunel',name:'Isambark Kingdom Brunel',who:'Isambard Kingdom Brunel',breed:'Bullmastiff',island:'rescue',area:'firestation',spot:{x:-32,z:18,kind:'boulder'},prop:'🌉',exp:'bridge',expName:'Strong Bridges',
  hint:'Look behind a rock by the bridge model at the Fire Station.',
  fact:'Isambark Kingdom Brunel is named after the real Isambard Kingdom Brunel, an engineer who lived about 200 years ago. He built bridges, tunnels, railways and giant ships. His Royal Albert Bridge still carries trains between Devon and Cornwall!',
  home:'Lay a sheet of paper across a gap between two piles of books, and put a toy car on it. It sags! Now fold the paper into a zigzag, like a fan, and try again. How many toys can it hold now?',
  rescue:{icon:'🎩',verb:'Catch',say:'The wind blew off Brunel\'s tall hat! Tap to catch it!'},
  look:{fur:'#d8a860',ear:'#26232e',ears:'fold',muzzle:'#26232e',wrinkle:true,belly:'#e0b870',tail:'thin',hw:62,hh:58,acc:['grad']},
  deco(x,z){const bx=x+6,bz=z-4,y=gy(bx,bz);const stm=new THREE.Mesh(G.plane,glow('#7fd3f0'));stm.scale.set(3,1,12);stm.position.set(bx,y+.07,bz);W.ag.add(stm);rect(bx-1.5,bz-6,bx+1.5,bz+6);
    [-4,4].forEach(s=>{I('box','#c9b6a0',1,4,1.4,bx+s,y+2,bz);I('box','#b5a08a',1.2,.4,1.6,bx+s,y+4.1,bz);col(bx+s,bz,.9);});I('box','#9b6a43',10.4,.25,1.2,bx,y+1.2,bz);
    const P=[[-5.6,.3],[-4,4],[-2,2.4],[0,1.9],[2,2.4],[4,4],[5.6,.3]];[-.6,.6].forEach(dz=>{for(let i=0;i<P.length-1;i++){const a=P[i],b=P[i+1],L=Math.hypot(b[0]-a[0],b[1]-a[1]);I('box','#3a3338',L,.08,.08,bx+(a[0]+b[0])/2,y+(a[1]+b[1])/2,bz+dz,0,0,Math.atan2(b[1]-a[1],b[0]-a[0]));}
      [-3,-1,1,3].forEach(hx=>{const top=hx*hx*.13+1.9;I('box','#3a3338',.05,top-1.3,.05,bx+hx,y+1.3+(top-1.3)/2,bz+dz);});});
    {const hx=x-4,hz=z+3,hy=gy(hx,hz);I('cyl','#9b6a43',.1,1.6,.1,hx,hy+.8,hz);I('cyl','#26232e',.75,.06,.75,hx,hy+1.62,hz);I('cyl','#26232e',.45,1,.45,hx,hy+2.1,hz);col(hx,hz,.5);}
    sign(x+2,z+5,'🌉 Bridge models',2.6,5.6);}},
 {id:'seacollie',name:'Mary Seacollie',who:'Mary Seacole',breed:'Smooth Collie',island:'rescue',area:'harbour',spot:{x:38,z:18,kind:'crate'},prop:'🩹',exp:'firstaid',expName:'First Aid Kit',
  hint:'Look in a crate by the medicine chest at the Harbour.',
  fact:'Mary Seacollie is named after the real Mary Seacole, a nurse from Jamaica. In the 1850s she sailed all the way to the Crimean War, where she set up a place to look after soldiers, with food and medicine. There is a statue of her outside a big hospital in London.',
  home:'With a grown-up, look inside the first aid kit at home. Can you find the plasters and the bandages? Make sure you know where it is kept, and always get a grown-up if someone is hurt.',
  rescue:{icon:'🧳',verb:'Open',say:'Seacollie is stuck inside a travel trunk! Tap to open the lid!'},
  look:{fur:'#c8843a',ear:'#a8642a',ears:'fold',muzzle:'#ffffff',face:'#ffffff',faceLow:true,belly:'#ffffff',paw:'#ffffff',tail:'thin',acc:['grad','scarf'],scarfC:'#e8423a'},
  deco(x,z){const cx=x-5,cz=z-2.5,y=gy(cx,cz);I('box','#7a4f2a',2.4,1.4,1.4,cx,y+.7,cz);I('box','#c9a86a',2.5,.15,1.5,cx,y+1.1,cz);I('box','#c9a86a',2.5,.15,1.5,cx,y+.3,cz);I('box','#c9a86a',.2,.3,.1,cx,y+.9,cz+.72);col(cx,cz,1.4);
    const fx=x-5,fz=z+2.5,fy=gy(fx,fz);I('box','#3fae5a',1.4,1,1,fx,fy+.5,fz);I('box','#ffffff',.9,.22,.05,fx,fy+.55,fz+.51);I('box','#ffffff',.22,.7,.05,fx,fy+.55,fz+.51);col(fx,fz,.9);
    const tx=x+3.5,tz=z-4,ty=gy(tx,tz);I('cyl','#9b6a43',.9,.12,.9,tx,ty+1,tz);I('cyl','#9b6a43',.1,1,.1,tx,ty+.5,tz);spr('🫖',.8,tx-.2,ty+1.45,tz);spr('🍲',.6,tx+.4,ty+1.35,tz+.2);col(tx,tz,1);
    sign(x,z-6.5,'🩹 Medicine chest',2.6,5.6);}}];
regSci(S);

/* ----------------- experiments ----------------- */
const k=INK;
/* Leonardo da Woofi: which teddy lands most gently? */
XP.chute=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><defs><linearGradient id="chg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fd3f5"/><stop offset="1" stop-color="#e6f6ff"/></linearGradient></defs><rect width="1024" height="768" fill="url(#chg)"/>
  <rect y="560" width="1024" height="208" fill="#8fd170"/><rect x="290" y="140" width="640" height="22" rx="6" fill="#9b6a43" stroke="${k}" stroke-width="4"/><rect x="290" y="140" width="22" height="420" fill="#9b6a43" stroke="${k}" stroke-width="4"/><rect x="908" y="140" width="22" height="420" fill="#9b6a43" stroke="${k}" stroke-width="4"/>
  ${[0,1,2].map(i=>`<ellipse cx="${400+i*210}" cy="562" rx="70" ry="12" fill="#6fbf5a"/>`).join('')}<text x="140" y="540" font-size="90" text-anchor="middle">🌳</text></svg>`;
  const L=[['none','No parachute',0],['small','Small parachute',70],['big','Big parachute',150]];
  const can=w=>w?svgEl(160,110,`<path d="M${-w/2} 44 Q0 ${44-w*.62} ${w/2} 44 Z" fill="#ff9ecb" stroke="${k}" stroke-width="4"/><path d="M${-w/2} 44 L-10 104 M${w/2} 44 L10 104 M0 ${44-w*.3} L0 104" stroke="${k}" stroke-width="2" fill="none"/>`,'-80 -6 160 110'):'<div style="height:110px"></div>';
  const D=L.map((l,i)=>{const d=place(el('div','xobj',`${can(l[2])}<div style="font-size:64px;line-height:70px">🧸</div>`),400+i*210-80,30,160,190);st.appendChild(d);
    const t=place(el('div','xres',l[1]),400+i*210-90,578,180,0);t.style.fontSize='18px';st.appendChild(t);return d;});
  let guess=null;
  const row=place(el('div','xrow',''),0,620,1024);L.forEach(l=>row.appendChild(bigBtn(`${l[2]?'🪂':'🧸'}<small>${l[1]}</small>`,'white',()=>{guess=l[0];sfx.boop();row.remove();
    const go=place(el('div','xrow',''),0,620,1024);go.appendChild(bigBtn('⬇️<small>Drop them all!</small>','green',()=>{go.remove();drop();}));st.appendChild(go);say('Good guess! Now let us drop all three at the same time.');})));st.appendChild(row);
  const drop=()=>{const T=[700,1900,3400];D.forEach((d,i)=>{d.style.transition=`transform ${T[i]}ms ${i?'linear':'ease-in'}`;requestAnimationFrame(()=>{d.style.transform='translateY(350px)';});
      setTimeout(()=>{if(i===0){sfx.oops();anim(d,'t-shake',500);const b=place(el('div','xobj','💥'),400-40,450,80,80);b.style.fontSize='60px';st.appendChild(b);}else sfx.pop();},T[i]);});
    setTimeout(()=>{say((guess==='big'?'Yes! ':'Look! ')+'The big parachute floated down slowly and landed gently. The teddy with no parachute went bump!');
      setTimeout(()=>{say('Why does the big parachute fall so slowly?');choiceRow(st,[['air','💨 It catches lots of air'],['heavy','🏋️ It is heavier','It is not heavier. What is all around us, pushing back?'],['magic','✨ It is magic','Not magic, it is science! What does a parachute push against?']],'air',()=>{
        say('Yes! The big canopy catches lots of air, and the air pushes up and slows it down. This is called air resistance. In the year 2000, a skydiver tested a parachute made from Leonardo\'s drawing, and it worked!');setTimeout(()=>sciDone(p),8000);},640);},4200);},3700);};
  say('Leonardo da Vinci drew a parachute over 500 years ago. Let us test some! Which teddy do you think will land the most gently?');};

/* Marie Curly: X-ray a pup at the vet */
const boneSVG=()=>{const b='stroke="#f4f8ff" stroke-width="14" stroke-linecap="round" fill="none"',j=(x,y,r)=>`<circle cx="${x}" cy="${y}" r="${r||10}" fill="#f4f8ff"/>`;
  let s=`<path d="M150 175 Q290 150 430 160" ${b}/>`;for(let i=0;i<14;i++)s+=j(160+i*20,172-Math.sin(i/13*3.14)*12+(i>9?-(i-9)*2:0),7);
  for(let i=0;i<6;i++)s+=`<path d="M${300+i*18} 165 q${-14} 50 ${6} 92" stroke="#f4f8ff" stroke-width="8" fill="none" stroke-linecap="round"/>`;
  s+=`<path d="M430 160 Q450 140 470 125" ${b}/><ellipse cx="500" cy="115" rx="52" ry="36" fill="none" stroke="#f4f8ff" stroke-width="12"/><path d="M470 140 L560 150" ${b}/><circle cx="510" cy="105" r="10" fill="#13233f" stroke="#f4f8ff" stroke-width="5"/>`;
  s+=`<path d="M150 175 Q110 150 70 95" stroke="#f4f8ff" stroke-width="9" stroke-linecap="round" fill="none"/><ellipse cx="165" cy="190" rx="34" ry="22" fill="none" stroke="#f4f8ff" stroke-width="10"/>`;
  [[130,200,115,300,120,375],[185,205,180,300,195,375],[395,195,385,290,380,375],[425,195,430,290,440,375]].forEach(q=>{s+=`<path d="M${q[0]} ${q[1]} L${q[2]} ${q[3]} L${q[4]} ${q[5]}" ${b}/>`+j(q[2],q[3],9)+`<path d="M${q[4]-14} ${q[5]} h30" ${b}/>`;});
  s+=`<g transform="translate(285 245)"><circle r="30" fill="#ffd23f" opacity=".9" stroke="#fff" stroke-width="4"/><circle r="12" fill="#13233f"/><path d="M-6 -42 l6 -12 l6 12" fill="#fff"/></g>`;
  return `<svg viewBox="0 0 600 400" width="100%" height="100%" style="position:absolute;left:0;top:0">${s}</svg>`;};
XP.xray=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e6f4ff"/><rect y="600" width="1024" height="168" fill="#c9d6e6"/><text x="90" y="560" font-size="80" text-anchor="middle">🩺</text><text x="940" y="560" font-size="80" text-anchor="middle">🐶</text></svg>`;
  const box=place(el('div','',boneSVG()),212,130,600,400);box.style.cssText+=';border-radius:24px;overflow:hidden;border:8px solid #3a3338;background:#13233f;box-sizing:border-box';st.appendChild(box);
  const TL=['That is the tail!','Nothing up here. Keep looking!','Nothing up here. Keep looking!','That is the skull. It keeps the brain safe!','Those are the hips!',null,'Those are the ribs. They keep the heart and lungs safe!','That is the jaw, for chewing!','A back leg!','Another back leg!','The front legs!','No bones down here. Keep looking!'];
  let found=false,taps=0;const tiles=[];
  TL.forEach((t,i)=>{const b=el('button','xtap','🐾');b.style.cssText+=`;position:absolute;left:${(i%4)*146}px;top:${Math.floor(i/4)*128}px;width:146px;height:128px;background:#c8843a;border:2px solid #a8642a;font-size:44px;transition:opacity .5s`;
    tap(b,()=>{initAudio();if(b.dataset.done||found)return;b.dataset.done=1;b.style.opacity='0';taps++;
      if(t===null){found=true;sfx.chime();say('There it is! The squeaky toy is in his tummy. Now the vet knows just how to help him!');setTimeout(()=>{tiles.forEach(x=>x.style.opacity='0');},1400);
        setTimeout(()=>{say('What can an X-ray show us?');choiceRow(st,[['bones','🦴 Bones inside the body'],['dreams','💭 What you dream about','X-rays cannot see dreams! What was white in the picture?'],['colour','🎨 Your favourite colour','Not that! Look at the picture. What shows up white?']],'bones',()=>{
          say('Bones! X-rays go through skin, but bones stop them, so bones show up white. Marie Curie drove X-ray vans to help doctors in the First World War, and she trained lots of people to use them.');setTimeout(()=>sciDone(p),7600);},600);},4600);}
      else{sfx.pop();say(t+(taps>=5?' The toy must be near the middle of his tummy!':''));}});box.appendChild(b);tiles.push(b);});
  say('Oh no! A pup at the vet has swallowed his squeaky toy! Tap the X-ray screen to look inside and find it.');};

/* Alexander Graham Bark: does the tin-can phone work? */
XP.phone=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#cfeaff"/><rect y="470" width="1024" height="298" fill="#8fd170"/><circle cx="512" cy="96" r="44" fill="#ffd23f"/></svg>`;
  const pl=place(el('div','',pupBox(p,{anim:false})),0,300,190,190),pr=place(el('div','',pupBox(buddyPup(),{anim:false})),834,300,190,190);pr.style.transform='scaleX(-1)';st.append(pl,pr);
  const sv=place(el('div','',''),0,0,1024,768);sv.style.pointerEvents='none';st.appendChild(sv);
  const res=place(el('div','xres',''),212,470,600,0);st.appendChild(res);
  const M={loose:{d:'M190 300 Q512 470 834 300',stop:.18,n:'a loose, floppy string',ok:false,why:'The floppy string cannot carry the wobbles, so the sound fades away.'},
    tight:{d:'M190 300 L834 300',stop:1,n:'a tight string',ok:true,why:'The tight string carries the wobbles all the way to the other cup. Woof!'},
    pinch:{d:'M190 300 L834 300',stop:.5,n:'a tight string, pinched in the middle',ok:false,why:'The finger stops the wobbles, so the sound cannot get past.'}};
  const order=shuffle(['loose','tight','pinch']);let r=0;
  const draw=m=>{sv.innerHTML=svgEl(1024,768,`<rect x="165" y="270" width="44" height="60" rx="8" fill="#c9c2b8" stroke="${k}" stroke-width="4"/><rect x="815" y="270" width="44" height="60" rx="8" fill="#c9c2b8" stroke="${k}" stroke-width="4"/><path id="str" d="${m.d}" stroke="#9b6a43" stroke-width="5" fill="none"/>${m===M.pinch?'<text x="512" y="335" font-size="70" text-anchor="middle">✋</text>':''}<g id="pul"></g>`);};
  const ask=()=>{if(r>=order.length){res.innerHTML='';sv.innerHTML='';say('What travels along the string and carries the sound?');choiceRow(st,[['vib','〰️ Tiny wobbles called vibrations'],['water','💧 Water','There is no water in the string! What did the dots show?'],['light','💡 Light','Not light. Sound is made of tiny wobbles. What are they called?']],'vib',()=>{
      say('Vibrations! Sound is tiny wobbles. A real telephone turns those wobbles into electricity and back again. Alexander Graham Bell got the first patent for a telephone in 1876.');setTimeout(()=>sciDone(p),7000);},600);return;}
    const m=M[order[r]];draw(m);res.innerHTML='';say(`This phone has ${m.n}. Will the friend hear the woof?`);
    const row=place(el('div','xrow',''),0,620,1024);[[true,'👂<small>Yes, they will</small>'],[false,'🔇<small>No, they won\'t</small>']].forEach(o=>row.appendChild(bigBtn(o[1],'white',()=>{row.remove();sfx.boop();woof(m,o[0]===m.ok);})));st.appendChild(row);};
  const woof=(m,right)=>{say('Woof!');const path=sv.querySelector('#str'),g=sv.querySelector('#pul'),len=path.getTotalLength(),t0=performance.now();
    const step=now=>{const f=(now-t0)/1800;g.innerHTML='';for(let i=0;i<4;i++){const q=f-i*.12;if(q<0||q>m.stop)continue;const pt=path.getPointAtLength(len*q);g.insertAdjacentHTML('beforeend',`<circle cx="${pt.x}" cy="${pt.y}" r="${Math.max(3,12-(m.ok?0:q*30))}" fill="#ff6b6b" opacity="${m.ok?1:Math.max(.1,1-q/m.stop)}"/>`);}
      if(f<m.stop+.4)requestAnimationFrame(step);else{g.innerHTML=m.ok?'<text x="900" y="270" font-size="60">👂</text>':'<text x="512" y="250" font-size="60" text-anchor="middle">🔇</text>';
        if(m.ok)sfx.chime();else sfx.boop();res.innerHTML=`<b>${right?'✅ You were right!':'😮 Surprise!'}</b> ${m.why}`;say(m.why);r++;setTimeout(ask,4200);}};requestAnimationFrame(step);};
  say('Alexander Graham Bell worked out how to send voices along a wire. Let us test a tin-can phone!');setTimeout(ask,3200);};

/* Orville Bright: what flies furthest, and how do you steer? */
XP.planes=(st,p)=>{const side=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#bfe3ff"/><rect y="560" width="1024" height="208" fill="#e8d9a8"/><path d="M0 560 Q100 420 230 400 L230 560Z" fill="#d9c890" stroke="${k}" stroke-width="4"/>`;
    for(let i=1;i<8;i++)s+=`<line x1="${200+i*100}" y1="560" x2="${200+i*100}" y2="584" stroke="${k}" stroke-width="4"/><text x="${200+i*100}" y="612" font-size="24" font-weight="900" text-anchor="middle" fill="${k}">${i}</text>`;return s+'</svg>';};
  $('#sciBg').innerHTML=side();const pup=place(el('div','',pupBox(p,{anim:false})),110,250,150,150);st.appendChild(pup);
  const T=[['sheet','📄','Flat sheet',[[230,350],[290,430],[250,480],[320,520],[300,550]],2400],['ball','⚪','Paper ball',[[230,350],[330,300],[420,420],[470,550]],1500],['plane','✈️','Paper plane',[[230,350],[420,360],[650,420],[880,550]],2600]];
  let guess=null;const row=place(el('div','xrow',''),0,640,1024);
  T.forEach(t=>row.appendChild(bigBtn(`${t[1]}<small>${t[2]}</small>`,'white',()=>{guess=t[0];sfx.boop();row.remove();throwAll();})));st.appendChild(row);
  const throwAll=()=>{say('Throw!');let i=0;const one=()=>{if(i>=T.length){done1();return;}const t=T[i++],o=place(el('div','xobj',t[1]),0,0,70,70);o.style.fontSize='60px';st.appendChild(o);
      o.animate(t[3].map((q,j)=>({left:(q[0]-35)+'px',top:(q[1]-35)+'px',transform:`rotate(${t[0]==='sheet'?(j%2?30:-30):t[0]==='ball'?j*120:12}deg)`})),{duration:t[4],easing:'ease-in-out',fill:'forwards'});sfx.boop();setTimeout(()=>{sfx.pop();one();},t[4]+300);};one();};
  const done1=()=>{say((guess==='plane'?'Yes! ':'Look! ')+'The paper plane flew the furthest! Its wings let the air hold it up as it glides. The flat sheet just flutters, and the ball has no wings at all.');setTimeout(steer,6200);};
  const steer=()=>{[...st.querySelectorAll('.xobj')].forEach(o=>o.remove());pup.remove();
    $('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e8d9a8"/>${Array.from({length:30},(_,i)=>`<path d="M${(i*137)%1000} ${(i*71)%740} q10 -8 20 0" stroke="#c9b884" stroke-width="4" fill="none"/>`).join('')}
      <circle cx="800" cy="230" r="70" fill="#ff6b6b" stroke="${k}" stroke-width="5"/><circle cx="800" cy="230" r="44" fill="#fff"/><circle cx="800" cy="230" r="20" fill="#ff6b6b"/><text x="512" y="700" font-size="50" text-anchor="middle">🐶</text></svg>`;
    const ov=place(el('div','',svgEl(1024,768,'<path id="fp" d="" stroke="#5b4636" stroke-width="4" stroke-dasharray="10 10" fill="none"/><g id="pl"><path d="M0 -34 L22 26 L0 14 L-22 26 Z" fill="#ffffff" stroke="#5b4636" stroke-width="4"/><line x1="0" y1="-34" x2="0" y2="14" stroke="#5b4636" stroke-width="3"/></g>')),0,0,1024,768);ov.style.pointerEvents='none';st.appendChild(ov);
    const fp=ov.querySelector('#fp'),pl=ov.querySelector('#pl');pl.setAttribute('transform','translate(512 620)');let busy=false;
    const F={left:['M512 620 C512 420 420 300 230 240','It turned left! Bending up the left flap turns the plane to the left.'],right:['M512 620 C512 420 620 280 800 230','It landed on the target! Bending up the right flap turns the plane to the right.'],both:['M512 620 L512 420 C512 300 620 300 620 360 C620 430 512 430 512 360 L512 300','It swooped up and looped the loop! Bending up both flaps makes the nose go up.']};
    say('Now steer the plane to land on the target! Which flap should we bend up?');
    const row2=place(el('div','xrow',''),0,640,1024);[['left','⬅️<small>Left flap up</small>'],['right','➡️<small>Right flap up</small>'],['both','⬆️<small>Both flaps up</small>']].forEach(o=>row2.appendChild(bigBtn(o[1],'white',b=>{if(busy)return;busy=true;sfx.boop();fp.setAttribute('d',F[o[0]][0]);const len=fp.getTotalLength(),t0=performance.now();
      const step=now=>{const f=Math.min(1,(now-t0)/2200),pt=fp.getPointAtLength(len*f),p2=fp.getPointAtLength(Math.min(len,len*f+2)),a=Math.atan2(p2.y-pt.y,p2.x-pt.x)*180/Math.PI+90;pl.setAttribute('transform',`translate(${pt.x} ${pt.y}) rotate(${a})`);
        if(f<1){requestAnimationFrame(step);return;}busy=false;say(F[o[0]][1]);if(o[0]==='right'){sfx.chime();b.classList.add('right');row2.remove();
          setTimeout(()=>{say('The Wright brothers steered their plane by twisting the ends of its wings. They called it wing warping. Planes today still steer with flaps on their wings!');setTimeout(()=>sciDone(p),7000);},3200);}
        else{sfx.oops();b.disabled=true;setTimeout(()=>{if(!busy){pl.setAttribute('transform','translate(512 620)');fp.setAttribute('d','');}},2600);}};requestAnimationFrame(step);})));st.appendChild(row2);};
  say('The Wright brothers tested lots of designs. Which do you think will fly the furthest?');};

/* Florence Night-in-tail: wash away the germs */
XP.germs=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e6f4ff"/>${Array.from({length:8},(_,i)=>`<rect x="${i*128}" y="0" width="126" height="126" fill="#f4fbff" stroke="#c9e6f5" stroke-width="3"/>`).join('')}<rect y="560" width="1024" height="208" fill="#c9d6e6"/><ellipse cx="512" cy="600" rx="300" ry="40" fill="#ffffff" stroke="${k}" stroke-width="5"/></svg>`;
  const S2='#d9a27a';const hand=place(el('div','',svgEl(420,470,`<g stroke="${k}" stroke-width="6" fill="${S2}"><rect x="100" y="190" width="230" height="230" rx="70"/>${[0,1,2,3].map(i=>`<rect x="${108+i*56}" y="${40+Math.abs(i-1.5)*18}" width="50" height="200" rx="25"/>`).join('')}<rect x="20" y="230" width="150" height="54" rx="27" transform="rotate(-38 95 257)"/></g><rect x="150" y="400" width="130" height="70" fill="${S2}"/>`)),302,110,420,470);st.appendChild(hand);
  const G=[[131,70],[187,56],[243,56],[299,70],[180,250],[234,250],[205,330],[290,330],[60,190],[215,430]].map(q=>[q[0]+302-30,q[1]+110-30]);let soap=false,left=G.length,timeUp=false;
  const bar=place(el('div','',`<div style="font-size:22px;font-weight:900;text-align:center">⏱️ Scrub for 20 seconds</div><div style="height:26px;border:4px solid ${k};border-radius:14px;background:#fff;overflow:hidden"><div id="gbar" style="height:100%;width:0;background:#7fc8f0;transition:width 20s linear"></div></div>`),312,640,400,70);bar.style.visibility='hidden';st.appendChild(bar);
  const sb=place(bigBtn('🧴<small>Soap</small>','white',()=>{if(soap)return;soap=true;sfx.pop();sb.classList.add('right');hand.style.filter='drop-shadow(0 0 14px #fff)';bar.style.visibility='visible';requestAnimationFrame(()=>{bar.querySelector('#gbar').style.width='100%';});
      say('Bubbles! Now scrub every germ away. Fingers, thumbs, nails and in between. Keep going until the timer fills up!');setTimeout(()=>{timeUp=true;check();},20000);}),790,300);st.appendChild(sb);
  G.forEach(q=>{const b=place(el('button','xtap','🦠'),q[0],q[1],60,60);b.style.fontSize='46px';b.style.filter='drop-shadow(0 0 8px #7fff7f)';
    tap(b,()=>{initAudio();if(b.dataset.done)return;if(!soap){sfx.boop();say('Water on its own will not shift them. Tap the soap first!');return;}b.dataset.done=1;sfx.pop();b.textContent='🫧';setTimeout(()=>{b.style.transition='opacity .6s';b.style.opacity='0';},400);left--;
      if(left===0){if(!timeUp)say('All the germs are gone! Keep scrubbing while the timer fills up. You could hum Happy Birthday twice!');check();}});st.appendChild(b);});
  let rinsed=false;const check=()=>{if(left>0||!timeUp||rinsed)return;rinsed=true;bar.remove();sb.remove();say('Twenty seconds! Now rinse off the bubbles.');
    const row=place(el('div','xrow',''),0,620,1024);row.appendChild(bigBtn('💧<small>Rinse</small>','green',()=>{row.remove();sfx.chime();hand.style.filter='drop-shadow(0 0 18px #9fe8ff)';say('Sparkling clean! Now dry your hands.');
      const r2=place(el('div','xrow',''),0,620,1024);r2.appendChild(bigBtn('🧻<small>Dry</small>','green',()=>{r2.remove();sfx.chime();say('When should you wash your hands?');
        choiceRow(st,[['both','🍽️ Before eating and after the toilet'],['bday','🎂 Only on your birthday','Much more often than that! Think about mealtimes.'],['never','🙅 Never','Oh yes you should! Germs can make us poorly.']],'both',()=>{
          say('Yes! And after playing outside and stroking animals too. Florence Nightingale showed that keeping hospitals clean saved lots of lives.');setTimeout(()=>sciDone(p),6600);},620);}));st.appendChild(r2);}));st.appendChild(row);};
  say('Florence Nightingale knew that keeping clean stops germs spreading. We made these germs glow so we can see them. Tap the soap first!');};

/* Alexander Flea-ming: watch the mould */
XP.petri=(st,p)=>{$('#sciBg').innerHTML=labBenchSVG();const ov=place(el('div','',''),0,0,1024,768);ov.style.pointerEvents='none';st.appendChild(ov);
  const RR=seed(1928),dots=[];while(dots.length<40){const a=RR()*6.283,r=20+RR()*170,x=512+Math.cos(a)*r,y=320+Math.sin(a)*r*.8;if(Math.hypot(x-440,y-290)<40)continue;dots.push([x,y]);}
  let day=1,mr=18,clear=0;const dayL=place(el('div','xres','Day 1'),432,560,160,0);st.appendChild(dayL);
  const draw=()=>{ov.innerHTML=svgEl(1024,768,`<ellipse cx="512" cy="320" rx="230" ry="190" fill="#e8f6ff" stroke="${k}" stroke-width="6"/><ellipse cx="512" cy="320" rx="214" ry="176" fill="#fff6c9" opacity=".7"/>
    ${clear?`<circle cx="440" cy="290" r="${clear}" fill="#fffbe6" opacity=".9"/>`:''}${dots.filter(d=>Math.hypot(d[0]-440,d[1]-290)>clear).map(d=>`<circle cx="${d[0]}" cy="${d[1]}" r="9" fill="#ffd23f" stroke="#c9a400" stroke-width="2"/>`).join('')}
    <circle cx="440" cy="290" r="${mr}" fill="#6fbf5a" stroke="#3f8e4a" stroke-width="4"/>${Array.from({length:8},(_,i)=>`<circle cx="${440+Math.cos(i*.785)*mr*.6}" cy="${290+Math.sin(i*.785)*mr*.6}" r="${mr*.25}" fill="#8fd170"/>`).join('')}`);};draw();
  const row=place(el('div','xrow',''),0,620,1024);const nb=bigBtn('⏩<small>Next day</small>','green',()=>{if(day>=3)return;day++;sfx.pop();mr=[18,40,62][day-1];clear=[0,95,140][day-1];dayL.textContent='Day '+day;draw();
    if(day<3)say('The mould is growing. Look at the yellow germs near it!');else{row.remove();say('What happened to the germs near the mould?');choiceRow(st,[['gone','🚫 They went away'],['more','➕ There were more','Look closely near the green mould. Are the germs still there?'],['blue','🔵 They turned blue','Look again. What happened to the yellow dots?']],'gone',()=>{
      say('They went away! The mould made something that stops germs growing. Fleming called it penicillin. Now, where does mould grow best?');setTimeout(bread,6200);},620);}});row.appendChild(nb);st.appendChild(row);
  const MP=[[60,55],[35,40],[85,70],[45,85],[75,35],[95,50],[30,65],[60,95],[85,95],[50,30],[70,60],[40,105],[95,30],[25,90]];
  const bread=()=>{ov.innerHTML='';dayL.remove();const B=[['fridge','❄️','In the fridge',1],['dry','☀️','Warm and dry',2],['damp','💧','Warm and damp',14]];
    const pics=B.map((b,i)=>{const d=place(el('div','xobj',`<div style="font-size:120px;line-height:1">🍞</div><div style="font-size:40px">${b[1]}</div>`),182+i*240,230,180,200);d.style.position='absolute';st.appendChild(d);return d;});let guess=null;
    say('Three slices of bread in sealed bags. Which one will grow the most mould in a week?');const r2=place(el('div','xrow',''),0,620,1024);B.forEach((b,i)=>r2.appendChild(bigBtn(`${b[1]}<small>${b[2]}</small>`,'white',()=>{guess=b[0];r2.remove();sfx.boop();say('One week later...');
      setTimeout(()=>{B.forEach((bb,j)=>{const d=pics[j].firstChild;d.style.position='relative';for(let n=0;n<bb[3];n++){const q=MP[n],z=(bb[0]==='damp'?20:14)+(n%3)*5;d.insertAdjacentHTML('beforeend',`<span style="position:absolute;left:${30+q[0]-z/2}px;top:${q[1]-z/2}px;width:${z}px;height:${z}px;border-radius:50%;background:${n%3?'#6fbf5a':'#3f8e4a'};opacity:.92"></span>`);}});sfx.chime();
        say((guess==='damp'?'Yes! ':'Look! ')+'The warm, damp bread grew the most mould. Mould loves warm, wet places, and the fridge slows it down. That is why we keep food cool and dry.');setTimeout(()=>sciDone(p),7600);},1800);})));st.appendChild(r2);};
  say('Alexander Fleming grew germs in a dish, the yellow dots. He went on holiday, and when he came back, some green mould had landed in it! Tap next day to see what happens.');};

/* Isambark Kingdom Brunel: which paper bridge holds the fire engine? */
XP.bridge=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#bfe3ff"/><rect x="0" y="380" width="300" height="388" fill="#c9905f" stroke="${k}" stroke-width="5"/><rect x="724" y="380" width="300" height="388" fill="#c9905f" stroke="${k}" stroke-width="5"/>
    <rect x="300" y="620" width="424" height="148" fill="#5fc4f0"/>${[0,1,2,3].map(i=>`<path d="M${330+i*100} 660 q20 -12 40 0" stroke="#fff" stroke-width="5" fill="none"/>`).join('')}<rect x="0" y="372" width="300" height="12" fill="#8fd170"/><rect x="724" y="372" width="300" height="12" fill="#8fd170"/></svg>`;
  const ov=place(el('div','',''),0,0,1024,768);ov.style.pointerEvents='none';st.appendChild(ov);const eng=place(el('div','xobj','🚒'),120,300,90,80);eng.style.fontSize='72px';eng.style.transform='scaleX(-1)';st.appendChild(eng);
  const shape=(kind,sag)=>{const top=`M300 380 Q512 ${380+(sag||0)} 724 380`;let s=`<path d="${top}" stroke="#f2ecd8" stroke-width="12" fill="none"/><path d="${top}" stroke="${k}" stroke-width="2" fill="none" transform="translate(0 6)"/>`;
    if(kind==='zig'){let z='M300 384';for(let i=0;i<20;i++)z+=` L${310+i*21} ${i%2?384:404}`;s+=`<path d="${z} L724 384" stroke="#f2ecd8" stroke-width="5" fill="none"/><path d="${z} L724 384" stroke="${k}" stroke-width="1.5" fill="none"/>`;}
    if(kind==='arch')s+=`<path d="M300 520 Q512 300 724 520" stroke="#f2ecd8" stroke-width="10" fill="none"/><path d="M300 520 Q512 300 724 520" stroke="${k}" stroke-width="2" fill="none" transform="translate(0 6)"/>`;
    ov.innerHTML=svgEl(1024,768,s);};
  const done={};let busy=false,cur=null;const row=place(el('div','xrow',''),0,640,1024);
  const B=[['flat','📄','Flat paper','a flat paper bridge'],['zig','〰️','Zigzag folds','a bridge with zigzag folds'],['arch','🌈','Arch underneath','a bridge with an arch underneath']];
  B.forEach(b=>row.appendChild(bigBtn(`${b[1]}<small>${b[2]}</small>`,'white',btn=>{if(busy)return;busy=true;cur=b[0];sfx.boop();shape(cur,0);say(`Let us try ${b[3]}. Will it hold the fire engine?`);
    setTimeout(()=>{eng.style.transition='left 1.6s linear,top .5s';eng.style.left='470px';setTimeout(()=>{
      if(cur==='flat'){shape('flat',90);eng.style.top='370px';sfx.oops();say('Oh no, it sags! Flat paper is too floppy. Back up, fire engine!');setTimeout(()=>{shape('flat',0);eng.style.transition='left 1.2s linear,top .3s';eng.style.top='300px';eng.style.left='120px';setTimeout(()=>{busy=false;finish(btn,'flat');},1400);},2600);}
      else{eng.style.transition='left 1.6s linear';eng.style.left='830px';sfx.chime();say(cur==='zig'?'It holds! The zigzag folds make the paper stiff and strong.':'It holds! The arch pushes the weight out to the sides.');
        setTimeout(()=>{eng.style.transition='none';eng.style.left='120px';busy=false;finish(btn,cur);},3400);}},1700);},1400);})));st.appendChild(row);
  const finish=(btn,kd)=>{done[kd]=1;btn.disabled=true;if(kd!=='flat')btn.classList.add('right');if(Object.keys(done).length<3){say('Try another bridge!');return;}row.remove();ov.innerHTML='';
    say('Why does the zigzag paper hold more?');choiceRow(st,[['stiff','📐 The folds make it stiff'],['colour','🎨 It is a nicer colour','Colour does not make things stronger! What did the folds do?'],['glue','🧴 It has glue on it','There is no glue! What changed when we folded it?']],'stiff',()=>{
      say('Yes! Folds and arches make bridges strong. Isambard Kingdom Brunel used clever shapes like these to build bridges that still stand today.');setTimeout(()=>sciDone(p),6400);},640);};
  say('Brunel built strong bridges. Let us build paper bridges for a toy fire engine! Pick a bridge to test.');};

/* Mary Seacollie: pack the first aid kit */
XP.firstaid=(st,p)=>sortExp(st,{bg:()=>labBenchSVG().replace('</svg>','<text x="900" y="500" font-size="100" text-anchor="middle">🧰</text></svg>'),n:8,bins:[{k:'yes',icon:'🧰',label:'First aid kit'},{k:'no',icon:'🏠',label:'Leave it out'}],
  intro:'Mary Seacole carried medicines to help soldiers. Let us pack a first aid kit! Does each thing go in the kit, or stay out?',ask:it=>`The ${it.n}. In the first aid kit, or leave it out?`,end:'The first aid kit is ready! If someone is hurt, always get a grown-up to help.',
  items:[{e:'🩹',n:'plasters',k:'yes',why:'Plasters cover small cuts and grazes.',hint:'What goes on a little cut?'},{e:'🧤',n:'pair of gloves',k:'yes',why:'Gloves keep hands clean when you help someone.',hint:'Helpers keep their hands clean.'},
    {e:'✂️',n:'round-ended scissors',k:'yes',why:'Scissors cut bandages and tape to the right size.',hint:'How do you cut a bandage?'},{e:'🌡️',n:'thermometer',k:'yes',why:'A thermometer checks if someone has a temperature.',hint:'How do you check for a fever?'},
    {e:'🧊',n:'cold pack',k:'yes',why:'A cold pack helps a bump or a bruise.',hint:'What helps a bump?'},{e:'🧷',n:'safety pins',k:'yes',why:'Safety pins hold a bandage in place.',hint:'How do you keep a bandage on?'},
    {e:'🍰',n:'cake',k:'no',why:'Cake is yummy, but it does not help a hurt knee!',hint:'Would that help a cut?'},{e:'🧸',n:'teddy',k:'no',why:'Teddy gives great cuddles, but stays out of the kit.',hint:'Is that for first aid?'},
    {e:'🎮',n:'video game',k:'no',why:'A game does not help someone who is hurt.',hint:'Would that fix a graze?'},{e:'🍭',n:'lolly',k:'no',why:'A lolly is a treat, not first aid.',hint:'Is that medicine?'},
    {e:'☂️',n:'umbrella',k:'no',why:'An umbrella is far too big for the kit!',hint:'Would that fit in the box?'},{e:'🪀',n:'yo-yo',k:'no',why:'A yo-yo is a toy, not first aid.',hint:'Is that for helping people?'}]},p);

/* ----------------- badges and certificates ----------------- */
const S7=()=>S.filter(q=>isFound(q.id)).length;
MERITS.push({id:'sci7',icon:'🛠️',name:'Inventors and Helpers',how:'Find the 8 science pups on Gadget Island and Rescue Bay.',ok:()=>S7()>=8});
CERTS.push({id:'sci28',icon:'🔭',title:'Science Superstar',why:'for finding 28 science pups',ok:()=>sciFound().length>=28});
})();
