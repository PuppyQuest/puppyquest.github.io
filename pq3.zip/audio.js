/* Puppy Quest 3: sound, music and read-aloud voice (from Puppy Quest 2) */
/* ============ sound ============ */
let AC=null,sfxG=null,musG=null,musF=null,fxEnd=0;
function initAudio(){
  try{if(!AC){const C=window.AudioContext||window.webkitAudioContext;if(!C)return;
      /* play like a media app, so the iPad's silent setting does not mute the game while the voice still talks (24 Nov 2026) */
      try{if(navigator.audioSession)navigator.audioSession.type='playback';}catch(e){}
      AC=new C();let out=AC.destination;try{const L=AC.createDynamicsCompressor();L.threshold.value=-6;L.knee.value=6;L.ratio.value=12;L.attack.value=.003;L.release.value=.25;L.connect(AC.destination);out=L;}catch(e){}
      sfxG=AC.createGain();sfxG.gain.value=.75;sfxG.connect(out);musG=AC.createGain();musG.gain.value=musLevel();musG.connect(out);
      musF=AC.createGain();musF.gain.value=1;musF.connect(musG);}
    if(AC.state!=='running'&&AC.state!=='closed'&&!document.hidden){const p=AC.resume();if(p&&p.catch)p.catch(()=>{});}}catch(e){}
}
/* music volume (grown-ups panel): Medium is twice the old level; iPad speakers need it */
const MUSV={l:.09,m:.18,h:.28};
function musLevel(){return MUSV[state.set&&state.set.mvol]||MUSV.m;}
function setMusVol(){if(musG&&AC)try{musG.gain.setTargetAtTime(musLevel(),AC.currentTime,.05);}catch(e){}}
function musPreview(){if(!AC||!state.set.music)return;const t=AC.currentTime+.08;[523,659,784,1047].forEach((f,i)=>tone(f,t+i*.16,.4,'triangle',.5,musG));}
['touchend','pointerup','keydown'].forEach(ev=>document.addEventListener(ev,()=>initAudio(),{capture:true,passive:true}));
document.addEventListener('visibilitychange',()=>{if(!document.hidden&&AC)initAudio();});
setInterval(()=>{if(AC&&AC.state==='interrupted'&&!document.hidden)initAudio();},2000);
function tone(f,t,d,type,v,dest,to){
  if(!AC)return;try{const o=AC.createOscillator(),g=AC.createGain();o.type=type||'sine';o.frequency.setValueAtTime(f,t);if(to)o.frequency.exponentialRampToValueAtTime(to,t+d);
    g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v||.3,t+.02);g.gain.exponentialRampToValueAtTime(.0001,t+d);o.connect(g);g.connect(dest||sfxG);o.start(t);o.stop(t+d+.05);
    if(!dest||dest===sfxG)fxEnd=Math.max(fxEnd,t+d);}catch(e){}
}
/* a burst of filtered noise: hats, snares, roars, whooshes and sneezes (high sounds an iPad speaker can play) */
let NZB=null;
function nzHit(t,d,v,ft,fq,dest,q){if(!AC)return;try{if(!NZB){NZB=AC.createBuffer(1,Math.floor(AC.sampleRate*.6),AC.sampleRate);const a=NZB.getChannelData(0);for(let i=0;i<a.length;i++)a[i]=Math.random()*2-1;}
  const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=NZB;s.loop=d>.55;f.type=ft||'highpass';f.frequency.value=fq||3000;if(q)f.Q.value=q;
  g.gain.setValueAtTime(.0001,t);g.gain.exponentialRampToValueAtTime(v||.2,t+Math.min(.02,d/4));g.gain.exponentialRampToValueAtTime(.0001,t+d);s.connect(f);f.connect(g);g.connect(dest||sfxG);s.start(t);s.stop(t+d+.05);
  if(!dest||dest===sfxG)fxEnd=Math.max(fxEnd,t+d);}catch(e){}}
function fxOk(){return AC&&state.set.sfx&&AC.state==='running';}
const sfx={
  boop(){if(fxOk())tone(520,AC.currentTime,.09,'sine',.25,null,720);},
  yip(p){if(!fxOk())return;p=p||1;const t=AC.currentTime;tone(620*p,t,.09,'triangle',.3,null,950*p);tone(720*p,t+.12,.11,'triangle',.3,null,1150*p);},
  chime(){if(!fxOk())return;const t=AC.currentTime;[1319,1568,2093].forEach((f,i)=>tone(f,t+i*.07,.3,'sine',.18));},
  jingle(){if(!fxOk())return;const t=AC.currentTime;[523,659,784,1047,784,1047,1319].forEach((f,i)=>tone(f,t+i*.12,.26,'triangle',.3));},
  fanfare(){if(!fxOk())return;const t=AC.currentTime;[523,523,523,698,880,784,1047].forEach((f,i)=>tone(f,t+i*.15,.3,'triangle',.3));},
  giggle(){if(!fxOk())return;const t=AC.currentTime;[900,1100,950,1200].forEach((f,i)=>tone(f,t+i*.07,.06,'sine',.16));},
  pop(){if(fxOk())tone(300,AC.currentTime,.13,'sine',.3,null,900);},
  oops(){if(fxOk())tone(420,AC.currentTime,.2,'sine',.2,null,260);},
  sniff(){if(!fxOk())return;const t=AC.currentTime;tone(220,t,.07,'triangle',.2);tone(260,t+.14,.07,'triangle',.2);tone(220,t+.28,.07,'triangle',.2);}
};
/* each voice is a row of steps: a note (C5, F#4, Bb3), '-' holds the note before, '.' is a rest. Drums: k kick, s snare, h hat, o open hat, x kick+hat, y kick+snare, t tom, T taiko, '.' none */
const TUNES={
 village:{step:.3,mw:'triangle',
  mel:'C5 - E5 - G5 - E5 - D5 - C5 - A4 - C5 - D5 - F5 - A5 - G5 - E5 - D5 - C5 - - -',
  bas:'C3 - - . G3 - - . D3 - - . A2 - - . D3 - - . F3 - - . C3 - - . G3 - - .',
  drm:'......h.......h.'},
 meadow:{step:.27,mw:'sine',mv:.55,
  mel:'G5 - B5 - D6 - B5 - A5 - G5 - E5 - - - D5 - E5 - G5 - A5 - B5 - - - A5 - - - G5 - B5 - D6 - E6 - D6 - B5 - G5 - - - A5 - B5 - A5 - G5 - E5 - D5 - - - G5 -',
  bas:'G3 - - . D3 - - . C3 - - . D3 - - . G3 - - . E3 - - . C3 - - . D3 - - .',
  drm:'....h.......h...'},
 snowy:{step:.25,mw:'sine',mv:.5,
  mel:'D6 . A5 . F#5 . A5 . D6 . E6 . F#6 - - . E6 . D6 . B5 . A5 - - . B5 . D6 . A5 . F#5 . G5 . A5 - - . G5 . F#5 . E5 . D5 - - . . . E5 . F#5 . D5 - - - . . . .',
  bas:'D3 - - - A3 - - - B3 - - - F#3 - - - G3 - - - D3 - - - G3 - - - A3 - - -',
  drm:'h.h.h.h.h.h.h.ho'},
 reef:{step:.32,mw:'sine',mv:.5,hw:'sine',hv:.22,
  mel:'A5 - - - C6 - - - A5 - G5 - F5 - - - D5 - - - F5 - A5 - G5 - - - - - - - F5 - - - A5 - - - D6 - C6 - A5 - - - G5 - - - A5 - G5 - F5 - - - - - - -',
  har:'F4 A4 C5 A4 F4 A4 C5 A4 D4 F4 A4 F4 D4 F4 A4 F4 Bb3 D4 F4 D4 Bb3 D4 F4 D4 C4 E4 G4 E4 C4 E4 G4 E4',
  bas:'F3 - - - - - - - D3 - - - - - - - Bb2 - - - - - - - C3 - - - - - - -',
  drm:'........h.......'},
 ninja:{step:.24,mw:'triangle',
  mel:'A5 - E5 - F5 - E5 - D5 - - - E5 - A4 - Bb4 - D5 - E5 - - - F5 - E5 - D5 - Bb4 - A4 - - - - - - - A5 - - - F5 - E5 - D5 - E5 - F5 - A5 - Bb5 - A5 - E5 - - -',
  bas:'A3 - . A3 E3 - . . F3 - . F3 E3 - . .',
  drm:'T..tT.t.T..tT.tt'},
 number:{step:.22,mw:'square',mv:.3,
  mel:'C5 D5 E5 F5 G5 . G5 . A5 G5 F5 E5 D5 . D5 . E5 F5 G5 A5 B5 . B5 . C6 . G5 . E5 . C5 . C5 E5 G5 C6 B5 . G5 . A5 F5 D5 B4 C5 . . . D5 E5 F5 G5 A5 . F5 . G5 . E5 . C5 - - .',
  bas:'C3 . G3 . C3 . G3 . F3 . A3 . G3 . B3 .',
  drm:'k.h.s.h.k.h.s.hh'},
 gadget:{step:.135,mw:'square',mv:.28,hw:'square',hv:.12,
  mel:'E5 . G5 . B5 . E6 . D6 . B5 . G5 . A5 . . . A5 . C6 . E6 . D6 . B5 . . . G5 . B5 . D6 . G6 . F#6 . D6 . B5 . C6 . . . B5 . A5 . G5 . F#5 . E5 . . . . . . .',
  har:'E6 B5 G5 B5 E6 B5 G5 B5 C6 A5 E5 A5 C6 A5 E5 A5 D6 B5 G5 B5 D6 B5 G5 B5 D6 A5 F#5 A5 D6 A5 F#5 A5',
  bas:'E3 E3 . E3 . E3 E4 . C3 C3 . C3 . C3 C4 . G2 G2 . G2 . G2 G3 . D3 D3 . D3 . D3 D4 .',
  drm:'x.h.y.h.x.h.y.ho'},
 rescue:{step:.26,mw:'square',mv:.3,
  mel:'F5 - - F5 Bb5 - - - D6 - - C6 Bb5 - A5 - G5 - - G5 C6 - - - Eb6 - - D6 C6 - Bb5 - A5 - - A5 Bb5 - C6 - D6 - Bb5 - G5 - Eb6 - D6 - - - C6 - - - Bb5 - - - - - - -',
  bas:'Bb2 . F3 . Bb2 . F3 . Eb3 . Bb3 . Eb3 . Bb3 . F3 . C4 . F3 . C4 . Bb2 . F3 . Bb2 . F3 .',
  drm:'y.h.s.h.y.h.sss.'},
 dino:{step:.3,mw:'triangle',mv:.5,hw:'sawtooth',hv:.1,
  mel:'D5 - - - - - - - F5 - E5 - D5 - - - A4 - - - - - - - Bb4 - A4 - G4 - A4 - D5 - - - - - - - F5 - G5 - A5 - - - Bb5 - A5 - G5 - F5 - E5 - - - - - - -',
  har:'D4 . A4 . D4 . Bb4 . D4 . A4 . D4 . C5 .',
  bas:'D3 - - - - - - - Bb2 - - - - - - - G2 - - - - - - - A2 - - - - - - -',
  drm:'T.t.....T.t...t.'},
 planet:{step:.34,mw:'sine',mv:.45,hw:'sine',hv:.18,
  mel:'E6 - - - - - - - D6 - - - B5 - - - C6 - - - - - - - G5 - - - - - - - A5 - - - B5 - - - C6 - - - E6 - - - D6 - - - - - - - F#6 - - - - - - -',
  har:'C5 E5 G5 B5 D6 B5 G5 E5 A4 C5 E5 G5 B5 G5 E5 C5 F4 A4 C5 E5 G5 E5 C5 A4 G4 B4 D5 F#5 A5 F#5 D5 B4',
  bas:'C3 - - - - - - - A2 - - - - - - - F2 - - - - - - - G2 - - - - - - -',
  drm:'........o.......'},
 alien:{step:.22,mw:'square',mv:.28,
  mel:'G5 . A#5 . G5 . D5 . F5 - E5 . D#5 - D5 . C5 . . . G5 . A#5 . C6 . A#5 . G5 . F5 . G5 - - - C6 . A#5 . G5 . F5 . D#5 . F5 . G5 . . . F5 . D#5 . C5 . D5 . C5 - - -',
  bas:'C3 . . C3 G3 . . G3 F3 . . F3 G3 . A#3 .',
  drm:'k.hok.hok.hok.ho'},
 disco:{step:.125,mw:'square',mv:.3,hw:'triangle',hv:.22,
  mel:'A5 - . A5 C6 - A5 - G5 - E5 - . . . . C6 - . C6 D6 - C6 - B5 - G5 - . . . . D6 - . D6 E6 - D6 - C6 - A5 - G5 - A5 - E6 - - - D6 - - - C6 - B5 - A5 - - -',
  har:'. . E5 . . . E5 . . . G5 . . . G5 . . . A5 . . . A5 . . . B5 . . . G#5 .',
  bas:'A2 . A3 . A2 . A3 . C3 . C4 . C3 . C4 . D3 . D4 . D3 . D4 . E3 . E4 . E3 . E4 .',
  drm:'khohyhohkhohyhoh'}
};
const NOTE={C:0,D:2,E:4,F:5,G:7,A:9,B:11};
function noteF(n){const m=/^([A-G])(#|b)?(\d)$/.exec(n);if(!m)return 0;const k=NOTE[m[1]]+(m[2]==='#'?1:m[2]==='b'?-1:0)+(+m[3]+1)*12;return 440*Math.pow(2,(k-69)/12);}
function tuneRow(str){const tk=str.trim().split(/\s+/),out=tk.map(()=>null);let last=-1;tk.forEach((x,i)=>{if(x==='-'){if(last>=0)out[last].n++;}else if(x==='.')last=-1;else{out[i]={f:noteF(x),n:1};last=i;}});return out;}
Object.values(TUNES).forEach(T=>['mel','har','bas'].forEach(v=>{if(typeof T[v]==='string')T[v]=tuneRow(T[v]);}));
function drum(c,t,d){
  if(c==='k'||c==='x'||c==='y'){tone(150,t,.16,'sine',.7,d,55);tone(240,t,.09,'triangle',.35,d,120);nzHit(t,.015,.22,'highpass',1500,d);}
  if(c==='s'||c==='y'){nzHit(t,.13,.3,'bandpass',1900,d,.8);tone(330,t,.07,'triangle',.18,d,220);}
  if(c==='h'||c==='x')nzHit(t,.035,.12,'highpass',7000,d);
  if(c==='o')nzHit(t,.16,.09,'highpass',6000,d);
  if(c==='t'){tone(260,t,.22,'sine',.45,d,140);nzHit(t,.02,.1,'highpass',1200,d);}
  if(c==='T'){tone(190,t,.38,'sine',.6,d,95);tone(380,t,.18,'triangle',.25,d,190);nzHit(t,.05,.2,'bandpass',700,d,.7);}}
function playStep(T,i,t){const st=T.step,at=a=>a&&a[i%a.length],d=musF;
  const m=at(T.mel);if(m)tone(m.f,t,Math.max(.12,m.n*st*.92),T.mw||'triangle',T.mv||.45,d);
  const h=at(T.har);if(h)tone(h.f,t,Math.max(.1,h.n*st*.9),T.hw||'triangle',T.hv||.2,d);
  const b=at(T.bas);if(b){const du=Math.max(.15,b.n*st*.9);tone(b.f,t,du,'triangle',.42,d);tone(b.f*2,t,du*.8,'triangle',.26,d);}
  const c=T.drm&&T.drm[i%T.drm.length];if(c&&c!=='.')drum(c,t,d);}
/* which tune: the island's own, Zuzu's planet, the village, or one set by a scene (MUSIC.over, e.g. 'disco' for the conga) */
const MUSIC={key:null,over:null,pos:0,next:0,want:null,swAt:0};
function musKey(){if(MUSIC.over&&TUNES[MUSIC.over])return MUSIC.over;const A=typeof W!=='undefined'&&W&&W.area;if(!A)return 'village';if(A.id==='alien')return 'alien';return TUNES[A.island]?A.island:'village';}
function musFade(to,secs){if(!musF)return;try{const n=AC.currentTime;musF.gain.cancelScheduledValues(n);musF.gain.setValueAtTime(musF.gain.value,n);musF.gain.linearRampToValueAtTime(to,n+secs);}catch(e){}}
function musTick(){if(!AC||!musF||AC.state!=='running'||!state||!state.set.music||document.hidden||sleepOn||cur==='title'){MUSIC.next=0;return;}
  const now=AC.currentTime,k=musKey();if(!MUSIC.key)MUSIC.key=k;
  if(k!==MUSIC.key&&MUSIC.want!==k){MUSIC.want=k;MUSIC.swAt=now+.5;musFade(0,.45);}
  else if(k===MUSIC.key&&MUSIC.want){MUSIC.want=null;musFade(1,.3);}
  if(MUSIC.want&&now>=MUSIC.swAt){MUSIC.key=MUSIC.want;MUSIC.want=null;MUSIC.pos=0;MUSIC.next=now+.05;musFade(1,.3);}
  if(!MUSIC.next||MUSIC.next<now-.25)MUSIC.next=now+.05;
  const T=TUNES[MUSIC.key]||TUNES.village;while(MUSIC.next<now+.2){playStep(T,MUSIC.pos,MUSIC.next);MUSIC.pos++;MUSIC.next+=T.step;}}
setInterval(musTick,50);
let voice=null,voiceList=[];
const V_MALE=/\b(daniel|arthur|oliver|george|ryan|thomas|aaron|fred|alex|albert|bruce|gordon|lee|rishi|james|david|mark|malcolm|reed|rocko|eddy|grandpa|junior|ralph|nathan|evan|tom|guy|william|male)\b/i;
const V_FEM=/\b(martha|kate|serena|stephanie|sonia|libby|hazel|maisie|susan|samantha|karen|moira|tessa|fiona|ava|allison|victoria|zoe|joelle|nicky|catherine|aria|jenny|zira|emma|amy|flo|shelley|sandy|grandma|female|isha|veena|noelle)\b/i;
const V_ODD=/bells|bubbles|zarvox|trinoids|whisper|wobble|bad news|good news|boing|cellos|organ|jester|superstar|bahh|albert|hysterical|deranged|pipe|princess|kathy/i;
function voiceScore(v){const n=v.name||'',l=(v.lang||'').replace('_','-'),u=(v.voiceURI||'')+' '+n;if(!/^en/i.test(l))return -999;let s=/en-GB/i.test(l)?40:/en-(IE|AU|NZ|ZA)/i.test(l)?16:10;
  if(V_FEM.test(n))s+=50;if(V_MALE.test(n))s-=70;if(/premium/i.test(u))s+=16;else if(/enhanced|natural|neural|online|siri/i.test(u))s+=11;
  if(/eloquence/i.test(u)||/^(eddy|flo|grandma|grandpa|reed|rocko|sandy|shelley)\b/i.test(n))s-=45;if(/compact/i.test(u))s-=3;if(V_ODD.test(n))s-=200;return s;}
function pickVoice(){try{voiceList=speechSynthesis.getVoices().filter(v=>voiceScore(v)>-150).sort((a,b)=>voiceScore(b)-voiceScore(a));voice=voiceList.find(v=>v.name===state.set.voiceName)||voiceList[0]||null;}catch(e){}}
try{if('speechSynthesis' in window){pickVoice();speechSynthesis.onvoiceschanged=pickVoice;}}catch(e){}
const EMO=/[\u{1F000}-\u{1FFFF}\u{2600}-\u{27BF}\u{2190}-\u{21FF}\u{25A0}-\u{25FF}\u{2B00}-\u{2BFF}\u{FE0F}\u{200D}]/gu;
/* On the iPad the read-aloud voice turns every other game sound right down while it talks (and for about a second after),
   and nearly every sound effect comes with a spoken line, so they were lost. Now the voice waits for the sound effect to finish (up to 1.5 s). (25 Nov 2026) */
let spkTok=0;
function speak(t){if(!state.set.voice||!('speechSynthesis' in window))return;const tok=++spkTok;try{speechSynthesis.cancel();}catch(e){}
  setTimeout(()=>{if(tok!==spkTok)return;let w=0;try{if(AC&&AC.state==='running'&&state.set.sfx)w=Math.min(1.5,fxEnd-AC.currentTime);}catch(e){}
    if(w>.05)setTimeout(()=>{if(tok===spkTok)talk(t);},w*1000);else talk(t);},0);}
function talk(t){try{
  const txt=String(t).replace(/<[^>]+>/g,' ').replace(EMO,'').replace(/\s+/g,' ').trim(),raw=txt.match(/[^.!?]+[.!?]*["']?\s*/g)||[txt],parts=[];
  raw.forEach(r=>{if(parts.length&&(/^[a-z]/.test(r)||parts[parts.length-1].trim().length<7))parts[parts.length-1]+=r;else parts.push(r);});
  parts.forEach(pt=>{const s=pt.trim();if(!s)return;const u=new SpeechSynthesisUtterance(s);if(voice){u.voice=voice;u.lang=voice.lang;}else u.lang='en-GB';u.rate=.95;u.pitch=1.04;u.volume=1;speechSynthesis.speak(u);});}catch(e){}}
function quiet(){spkTok++;try{if('speechSynthesis' in window)speechSynthesis.cancel();}catch(e){}}
let lastSay='';
let sayT=null;
function say(t){lastSay=t;$('#btxt').textContent=t;$('#bubble').classList.add('on');speak(t);clearTimeout(sayT);if(cur==='world')sayT=setTimeout(()=>{if(cur==='world')hush();},7500);
  else if(cur==='book'||cur==='binder')sayT=setTimeout(hush,3000);}/* 25 Nov: menu screens hide the bubble after 3 s so it clears the top tabs; the voice carries on */
function hush(){$('#bubble').classList.remove('on');}


/* ============ fx ============ */
const COLS=['#ff8fb3','#ffd86b','#8fe39a','#9bdcff','#c9b6ff','#ffb347'];
function confetti(n){const c=$('#fx');for(let i=0;i<(n||40);i++){const d=el('i','conf');d.style.left=(Math.random()*1010)+'px';d.style.background=COLS[i%COLS.length];d.style.animationDuration=(1.8+Math.random()*1.6)+'s';d.style.animationDelay=(Math.random()*.5)+'s';c.appendChild(d);setTimeout(()=>d.remove(),4300);}}
function floaty(x,y,ch,n){const c=$('#fx');for(let i=0;i<(n||1);i++){const d=el('span','fl',ch);d.style.left=(x-22+(Math.random()-.5)*90)+'px';d.style.top=(y-30+(Math.random()-.5)*50)+'px';d.style.animationDelay=(i*.08)+'s';c.appendChild(d);setTimeout(()=>d.remove(),1500+i*80);}}
function anim(e,cls,ms){if(!e)return;e.classList.remove(cls);void e.offsetWidth;e.classList.add(cls);setTimeout(()=>e.classList.remove(cls),ms||900);}

