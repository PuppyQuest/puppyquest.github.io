/* Gadget Island look (22 Nov 2026): an industrial city. Concrete and
   tarmac with paving joints, a fence and a ring of warehouses and
   blocks with windows, tower blocks, chimneys and cranes beyond. The
   Light Lab is the bright white part of town, the Magnet Mine a quarry,
   and the Robot Yard a scrapyard. The Invention Vault is unchanged. */
(function(){
const flat=()=>0,slabs=(x,z)=>{const a=Math.floor((x+200)/8),b=Math.floor((z+200)/8);return ((a*7+b*13)%5)/6;};
const CITY={light:'city',sky:'#b6c4d4',fogC:'#c6d0dc',fog:[60,230],backdrop:{style:'city'},hedgeC:'#5b6378',noEdgeTrees:true};
restyle('workshop',Object.assign({},CITY,{hf:flat,ground:'#a3a8b0',ground2:'#959aa2',gmix:slabs,grid:{step:4,c:'#80858d'},edge:{style:'city'},biome:'city'}));
restyle('factory',Object.assign({},CITY,{hf:flat,ground:'#8f949c',ground2:'#848991',gmix:slabs,grid:{step:4,c:'#6f747c'},edge:{style:'city',pal:['#a0523a','#8a4a3a','#6b7078','#5b6378'],h:[9,22]},biome:'city'}));
restyle('lightlab',Object.assign({},CITY,{hf:flat,sky:'#c8e2f8',fogC:'#dceaf6',ground:'#e8ecf0',ground2:'#dde2e8',gmix:slabs,grid:{step:3,c:'#c4cad2'},
  edge:{style:'city',pal:['#eef2f6','#d4e4f2','#ffffff','#bcd2e6'],win:['#7fc8f0','#5fb0e8'],h:[8,22]},biome:'city'}));
restyle('mine',Object.assign({},CITY,{sky:'#a6b2c0',fogC:'#b2bcc8',ground:'#7f7870',ground2:'#90887e',edge:{style:'quarry'},biome:'quarry'}));
restyle('launch',Object.assign({},CITY,{hf:flat,sky:'#a8ccec',fogC:'#c4dcf0',ground:'#b6b6ae',ground2:'#aaaaa2',gmix:slabs,grid:{step:6,c:'#8f8f88',w:.1},
  edge:{style:'city',pal:['#8a8f99','#c9c2b8','#e6e0d0','#6b7078'],h:[5,10]},biome:'city'}),
  A=>{/* yellow and black hazard lines round the launch pads */[[-14,-20],[0,-26],[14,-20]].forEach(q=>{for(let i=0;i<16;i++){const a=i/16*6.283;I('box',i%2?'#ffd23f':'#26232e',1.2,.03,.3,q[0]+Math.cos(a)*4.4,.05,q[1]+Math.sin(a)*4.4,0,-a+Math.PI/2,0);}});});
restyle('robotyard',Object.assign({},CITY,{ground:'#8a8478',ground2:'#9a9488',edge:{style:'scrap'},biome:'scrap'}));
})();
