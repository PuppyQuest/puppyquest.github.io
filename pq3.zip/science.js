/* ================================================================
   Seb's Puppy Quest 3: Release 6, science pups from history.
   Four science pups per island, inspired by real scientists. They are
   extra finds (not needed to finish an island). Each found science pup
   moves into the Science Lab in Pawprint Village, where it has a short
   experiment and a safe try-at-home card. Facts are about the real
   people; the pups are characters inspired by them.
   ================================================================ */
const SCI=[];
function regSci(list){list.forEach(p=>{const IS=islandOf(p.island);p.lv=1;p.type=p.type||(IS&&IS.type)||'leaf';p.sci=true;PUPS[p.id]=p;SCI.push(p);
  const A=AREAS[p.area];if(A&&!A._sciWrap){A._sciWrap=true;const ob=A.build;A.build=function(){ob.apply(this,arguments);SCI.filter(q=>q.area===A.id&&q.deco).forEach(q=>{try{q.deco(q.spot.x,q.spot.z);}catch(e){console.warn('deco',q.id,e);}});};}});}
const sciOpen=p=>islOpen(p.island);
const sciFound=()=>SCI.filter(p=>isFound(p.id));

(function(){
const R=seed(6060);
const glowM=(c)=>{const m=new THREE.MeshBasicMaterial({color:c});W.disp.push(m);return m;};
/* ----------------- the 20 science pups ----------------- */
const S=[
 /* Meadow Island */
 {id:'woofton',name:'Sir Isaac Woofton',who:'Isaac Newton',breed:'English Setter',island:'meadow',area:'windmill',spot:{x:16,z:-6,kind:'leafpile'},prop:'🍎',exp:'drop',expName:'Feather and Ball',
  hint:'Look in the leaves under the apple tree on Windmill Hill.',
  fact:'Sir Isaac Woofton is named after the real Isaac Newton, who lived over 300 years ago in England. Newton worked out that gravity pulls everything down, from falling apples to the Moon going round the Earth!',
  home:'Hold a ball and a flat sheet of paper up high and let go at the same time. Which lands first? Now scrunch the paper into a ball and try again!',
  rescue:{icon:'🍎',verb:'Catch',say:'Apples are falling on Woofton! Tap to catch them!'},
  look:{fur:'#ffffff',ear:'#c8703a',ears:'long',muzzle:'#ffffff',belly:'#ffffff',spots:true,spotC:'#c8703a',tail:'plume',acc:['grad','leaves']},
  deco(x,z){const tx=x-4,tz=z;tree(tx,tz,1.15,'#4fae4a');const y=gy(tx,tz);for(let i=0;i<14;i++){const a=i*2.4,r=1.2+(i%3)*.7;I('sph','#e8423a',.25,.25,.25,tx+Math.cos(a)*r,y+4.6+(i%4)*.5,tz+Math.sin(a)*r);}
    for(let i=0;i<5;i++)I('sph','#e8423a',.25,.25,.25,tx+1.5+R()*2,y+.25,tz-1.5+R()*3);sign(tx-2,tz+4,'🍎 Gravity tree',2.6,5);}},
 {id:'carver',name:'George Woofington Carver',who:'George Washington Carver',breed:'Black and Tan Coonhound',island:'meadow',area:'pond',spot:{x:36,z:-14,kind:'grain'},prop:'🥜',exp:'soil',expName:'Healthy Soil',
  hint:'Look by the peanut field near Lily Pond.',
  fact:'George Woofington Carver is named after the real George Washington Carver, a plant scientist in America. He taught farmers to grow peanuts and sweet potatoes, which help make tired soil healthy again.',
  home:'Put a dried bean on damp kitchen roll in a clear jar and watch it sprout roots and a shoot over a few days.',
  rescue:{icon:'🥜',verb:'Shell',say:'Woofington is buried in peanut shells! Tap to clear them away!'},
  look:{fur:'#26232e',ear:'#26232e',ears:'long',earLen:1.3,muzzle:'#b8642a',brows:'#b8642a',paw:'#b8642a',belly:'#26232e',tail:'thin',acc:['grad','cap']},
  deco(x,z){const fx=x-6,fz=z;for(let r=0;r<4;r++){const m=new THREE.Mesh(G.plane,M('#8a5a3a'));m.scale.set(1.2,1,7);m.position.set(fx-r*1.8,gy(fx,fz)+.06,fz);W.ag.add(m);
    for(let k=0;k<6;k++)I('sphL','#5fae4a',.45,.35,.45,fx-r*1.8,gy(fx,fz)+.3,fz-3+k*1.2);}sign(fx-3,fz+5,'🥜 Peanut field',2.6,5);spr('🥜',.8,fx+1,gy(fx,fz)+.5,fz+2);}},
 {id:'mendoodle',name:'Gregor Mendoodle',who:'Gregor Mendel',breed:'Goldendoodle',island:'meadow',area:'sunflowers',spot:{x:24,z:-26,kind:'bush'},prop:'🫛',exp:'peas',expName:'Pea Flowers',
  hint:'Look in a bush by the pea plants in Sunflower Fields.',
  fact:'Gregor Mendoodle is named after the real Gregor Mendel, a monk who grew thousands of pea plants. He found out how things like flower colour pass from parent plants to their babies.',
  home:'Look at your family! Who has the same eye colour or hair colour as someone else?',
  rescue:{icon:'🫛',verb:'Untangle',say:'Mendoodle is tangled in pea vines! Tap to untangle them!'},
  look:{fur:'#e8c07a',ears:'floppy',fluffy:true,wool:true,muzzle:'#e8c07a',belly:'#f2d9a8',tail:'plume',acc:['grad','flower']},
  deco(x,z){const px=x-5,pz=z;for(let i=0;i<5;i++){const cx=px-(i%2)*1.6,cz=pz-3+i*1.4,y=gy(cx,cz);I('cylL','#c9a86a',.06,2.4,.06,cx,y+1.2,cz);for(let k=0;k<3;k++)I('sphL','#5fae4a',.4,.35,.4,cx,y+.6+k*.6,cz);
    I('sph',i%4===3?'#ffffff':'#9b59d0',.22,.22,.22,cx+.3,y+1.9,cz);I('sph',i%3===2?'#ffffff':'#9b59d0',.2,.2,.2,cx-.3,y+1.4,cz);}sign(px-3,pz+5,'🫛 Pea patch',2.6,5);}},
 {id:'barkwin',name:'Charles Barkwin',who:'Charles Darwin',breed:'Cocker Spaniel',island:'meadow',area:'wood',spot:{x:-24,z:20,kind:'log'},prop:'🔍',exp:'beaks',expName:'Beaks and Food',
  hint:'Look by the log with the beetles in Bluebell Wood.',
  fact:'Charles Barkwin is named after the real Charles Darwin, who sailed round the world on a ship called the Beagle. He studied birds called finches and saw that each kind had a beak that suited its food.',
  home:'Try picking up rice, raisins and water with tweezers, a spoon and a straw. Which beak works best for each food?',
  rescue:{icon:'🐞',verb:'Count',say:'Barkwin is busy counting beetles and will not move! Tap to help count them!'},
  look:{fur:'#8a5a3a',ear:'#6b4028',ears:'long',fluffy:true,muzzle:'#a0704a',belly:'#a0704a',tail:'wag',acc:['grad','scarf'],scarfC:'#3fae5a'}},
 /* Snowy Summit */
 {id:'galipup',name:'Galileo Galipup',who:'Galileo Galilei',breed:'Bracco Italiano',island:'snowy',area:'eagle',spot:{x:-2,z:6,kind:'drift'},prop:'🔭',exp:'moons',expName:"Jupiter's Moons",
  hint:'Look by the telescope on Eagle Peak.',
  fact:'Galileo Galipup is named after the real Galileo Galilei, who made his own telescope in Italy over 400 years ago. In 1610 he spotted four moons going round the planet Jupiter!',
  home:'On a clear night, look at the Moon with binoculars and spot its craters. Never look at the Sun!',
  rescue:{icon:'🔭',verb:'Polish',say:'Galipup cannot see through the frosty telescope! Tap to polish it!'},
  look:{fur:'#ffffff',ear:'#c8843a',ears:'long',earLen:1.2,muzzle:'#ffffff',belly:'#ffffff',patch:'#c8843a',spots:true,spotC:'#e0a070',tail:'thin',acc:['grad','scarf'],scarfC:'#3d8fe0'},
  deco(x,z){const tx=x-4,tz=z,y=gy(tx,tz),g=grp();[0,2.1,4.2].forEach(a=>{const l=mk('cyl','#5b4636',.06,2.4,.06,Math.cos(a)*.5,1.1,Math.sin(a)*.5,g);l.rotation.x=Math.sin(a)*.22;l.rotation.z=-Math.cos(a)*.22;});
    const t=mk('cyl','#c9a86a',.28,2.6,.28,0,2.6,0,g);t.rotation.z=-1;mk('cyl','#3a3338',.32,.3,.32,-1.15,3.3,0,g).rotation.z=-1;add(g,tx,tz,y);col(tx,tz,.8);sign(tx-2.5,tz+3,'🔭 Galileo\'s telescope',2.8,6);}},
 {id:'chillsius',name:'Anders Chillsius',who:'Anders Celsius',breed:'Swedish Lapphund',island:'snowy',area:'hut',spot:{x:26,z:-10,kind:'crate'},prop:'🌡️',exp:'thermo',expName:'Hot and Cold',
  hint:'Look by the giant thermometer at the Mountain Hut.',
  fact:'Anders Chillsius is named after the real Anders Celsius from Sweden. He made the temperature scale we use: water freezes at 0 degrees and boils at 100. Funny fact: he first had it upside down!',
  home:'Put ice cubes in two cups, one in the fridge and one on a sunny windowsill. Which melts first?',
  rescue:{icon:'🧣',verb:'Warm',say:'Chillsius is too chilly! Tap to wrap a warm scarf round Chillsius!'},
  look:{fur:'#3a2e2a',ear:'#3a2e2a',ears:'pointy',fluffy:true,muzzle:'#c8843a',brows:'#c8843a',belly:'#4a3a35',tail:'curl',acc:['grad','scarf','flake'],scarfC:'#ffd23f'},
  deco(x,z){const tx=x-4,tz=z,y=gy(tx,tz);I('box','#9b6a43',1.4,.4,1.4,tx,y+.2,tz);I('cyl','#ffffff',.35,5,.35,tx,y+2.9,tz);I('sph','#e8423a',.6,.6,.6,tx,y+.7,tz);I('cyl','#e8423a',.16,2.6,.16,tx,y+2,tz+.2);
    for(let i=0;i<6;i++)I('box','#26232e',.3,.04,.05,tx+.3,y+1.4+i*.6,tz+.3);const l=label('🌡️ 0° ice · 100° boil',4.4);l.position.set(tx,y+6,tz);W.ag.add(l);col(tx,tz,.8);}},
 {id:'howlard',name:'Luke Howl-ard',who:'Luke Howard',breed:'Old English Sheepdog',island:'snowy',area:'lift',spot:{x:26,z:-10,kind:'drift'},prop:'☁️',exp:'clouds',expName:'Name the Clouds',
  hint:'Look by the weather station at the Lift Station.',
  fact:'Luke Howl-ard is named after the real Luke Howard, who gave clouds their names over 200 years ago: cumulus means heap, stratus means layer, and cirrus means curl of hair.',
  home:'Look up at the sky. Can you spot cumulus, stratus or cirrus clouds today?',
  rescue:{icon:'💨',verb:'Blow',say:'Howl-ard is lost in a cloud! Tap to blow the cloud away!'},
  look:{fur:'#e6e6ee',ear:'#7d8496',ears:'floppy',fluffy:true,fringe:'#e6e6ee',muzzle:'#ffffff',belly:'#ffffff',bodyPatch:'#7d8496',tail:'stub',acc:['grad','mittens']},
  deco(x,z){const wx=x-4,wz=z,y=gy(wx,wz);[-.5,.5].forEach(a=>[-.4,.4].forEach(b=>I('cyl','#ffffff',.06,1.6,.06,wx+a,y+.8,wz+b)));I('box','#ffffff',1.4,1,1.1,wx,y+2,wz);for(let i=0;i<4;i++)I('box','#c9c2b8',1.3,.06,.04,wx,y+1.65+i*.22,wz+.57);
    I('cyl','#8a8f99',.06,2.4,.06,wx+1.6,y+1.2,wz);const cups=grp();for(let k=0;k<3;k++){const a=k*2.09;mk('cyl','#8a8f99',.03,.8,.03,Math.cos(a)*.4,0,Math.sin(a)*.4,cups).rotation.z=Math.PI/2;mk('hemi','#e8423a',.18,.18,.18,Math.cos(a)*.8,0,Math.sin(a)*.8,cups);}add(cups,wx+1.6,wz,y+2.5);W.ticks.push(dt=>{cups.rotation.y+=dt*3;});
    ['☁️','🌥️','☁️'].forEach((e,i)=>{const s=sprite(e,1.6);W.ag.add(s);W.ticks.push(()=>s.position.set(wx-1+i*1.4+Math.sin(W.t*.4+i)*.6,y+5+i*.4,wz));});col(wx,wz,1);}},
 {id:'bentpaw',name:'Snowflake Bentpaw',who:'Wilson Bentley',breed:'Siberian Husky',island:'snowy',area:'cave',spot:{x:20,z:10,kind:'crystal'},prop:'❄️',exp:'flake',expName:'Make a Snowflake',
  hint:'Look by the giant snowflakes in the Ice Cave.',
  fact:'Snowflake Bentpaw is named after the real Wilson Bentley, a farmer who took the first ever photo of a single snowflake, in 1885. He photographed over 5,000 snowflakes, and every one had six sides.',
  home:'Next time it snows, catch snowflakes on a dark glove and look closely. With a grown-up, cut a paper snowflake too.',
  rescue:{icon:'📷',verb:'Snap',say:'Bentpaw wants a photo before coming out! Tap to take the pictures!'},
  look:{fur:'#6b7686',ear:'#4a5260',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',face:'#ffffff',faceLow:true,iris:'#5aa9dc',tail:'plume',acc:['grad','flake']},
  deco(x,z){const fx=x-4.5,fz=z,y=gy(fx,fz);for(let k=0;k<2;k++){const g=grp();for(let i=0;i<6;i++){const a=i/6*6.283;const b=mk('box','#e8f6ff',.18,1.6,.18,Math.cos(a)*.8,Math.sin(a)*.8,0,g);b.rotation.z=a-Math.PI/2;mk('box','#ffffff',.5,.1,.1,Math.cos(a)*1.1,Math.sin(a)*1.1,0,g).rotation.z=a;}
    g.position.set(fx-k*2.4,y+2.4+k*.6,fz+k*1.2);g.scale.setScalar(1-k*.3);W.ag.add(g);W.ticks.push(dt=>{g.rotation.y+=dt*(.4+k*.2);});}
    const cam=grp();[0,2.1,4.2].forEach(a=>{const l=mk('cyl','#3a3338',.05,1.6,.05,Math.cos(a)*.35,.7,Math.sin(a)*.35,cam);l.rotation.x=Math.sin(a)*.2;l.rotation.z=-Math.cos(a)*.2;});mk('box','#5b4636',.8,.6,.6,0,1.7,0,cam);mk('cyl','#26232e',.22,.4,.22,0,1.7,.45,cam).rotation.x=Math.PI/2;add(cam,fx+1.2,fz+2.2,y);col(fx,fz,1.2);}},
 /* Coral Reef */
 {id:'arfchimedes',name:'Arf-chimedes',who:'Archimedes',breed:'Kokoni',island:'reef',area:'palace',spot:{x:-6,z:0,kind:'rockpool'},prop:'🛁',exp:'float',expName:'Float or Sink',
  hint:'Look by the marble bath in Pearl Palace.',
  fact:'Arf-chimedes is named after the real Archimedes, who lived in Ancient Greece over 2,000 years ago. The story goes that he saw the water rise when he got into his bath and shouted Eureka! He worked out why things float.',
  home:'Fill a bowl with water and test what floats: an apple, a coin, a toy, a cork. Do it with a grown-up nearby.',
  rescue:{icon:'🫧',verb:'Pop',say:'Arf-chimedes is lost in bath bubbles! Tap to pop them!'},
  look:{fur:'#f2e6d8',ear:'#c8a070',ears:'floppy',muzzle:'#f2e6d8',belly:'#ffffff',patch:'#c8a070',tail:'plume',scale:.85,acc:['grad','bubbles']},
  deco(x,z){const bx=x-4.5,bz=z,y=gy(bx,bz);I('box','#f4f0ea',3.2,1,1.8,bx,y+.5,bz);I('cyl','#f4f0ea',.9,1,.9,bx-1.6,y+.5,bz);I('cyl','#f4f0ea',.9,1,.9,bx+1.6,y+.5,bz);I('box','#7fd3f0',3,.1,1.5,bx,y+.98,bz,0,0,0,true);
    for(let i=0;i<4;i++)I('cyl','#ffd23f',.15,.3,.15,bx+(i<2?-1.4:1.4),y+.1,bz+(i%2?.7:-.7));let t=0;W.ticks.push(dt=>{t-=dt;if(t<0){t=.7;floatS('🫧',bx+(Math.random()-.5)*2.4,y+1.2,bz,.7,1.5);}});col(bx,bz,2);}},
 {id:'woofsteau',name:'Jacques Woofsteau',who:'Jacques Cousteau',breed:'Barbet',island:'reef',area:'ship',spot:{x:-36,z:-6,kind:'crate'},prop:'🤿',exp:'divekit',expName:'Pack the Dive Bag',
  hint:'Look by the old air tanks at the Shipwreck.',
  fact:'Jacques Woofsteau is named after the real Jacques Cousteau, a French ocean explorer. He helped invent the Aqua-Lung in 1943, so divers could carry air on their backs and explore under the sea.',
  home:'Push an upside-down cup straight down into a bowl of water. The air stays trapped inside, like a little diving bell!',
  rescue:{icon:'🤿',verb:'Fix',say:"Woofsteau's diving mask is wonky! Tap to fix it!"},
  look:{fur:'#3a2e2a',ears:'floppy',fluffy:true,wool:true,muzzle:'#3a2e2a',belly:'#4a3a35',tail:'plume',acc:['grad','shell']},
  deco(x,z){const dx=x-4.5,dz=z,y=gy(dx,dz);[-.5,.5].forEach(q=>{I('cyl','#ffd23f',.4,2,.4,dx+q,y+1,dz);I('hemi','#ffd23f',.4,.3,.4,dx+q,y+2,dz);});I('box','#26232e',1.6,.2,.3,dx,y+1.4,dz+.4);
    I('sph','#c9905f',.8,.8,.8,dx+2,y+.8,dz+.6);I('cyl','#9bdcff',.35,.1,.35,dx+2,y+.85,dz+1.35,Math.PI/2,0,0,true);col(dx,dz,1.2);}},
 {id:'barkson',name:'Rachel Barkson',who:'Rachel Carson',breed:'Chesapeake Bay Retriever',island:'reef',area:'coral',spot:{x:-38,z:20,kind:'bucket'},prop:'♻️',exp:'cleanup',expName:'Clean the Sea',
  hint:'Look by the recycling bin in the Coral Garden.',
  fact:'Rachel Barkson is named after the real Rachel Carson, a scientist who loved the sea. She wrote books that helped people understand nature, and why we must look after it.',
  home:'With a grown-up and some gloves, do a mini litter pick at the beach or the park.',
  rescue:{icon:'🛍️',verb:'Unwrap',say:'Barkson is tangled in an old plastic bag! Tap to unwrap it!'},
  look:{fur:'#8a6040',ear:'#6b4a30',ears:'floppy',muzzle:'#8a6040',belly:'#9b7050',tail:'thin',acc:['grad','shellneck']},
  deco(x,z){const bx=x-4,bz=z,y=gy(bx,bz);I('cyl','#3fae5a',.8,1.8,.8,bx,y+.9,bz);I('cyl','#2e8b47',.85,.15,.85,bx,y+1.85,bz);spr('♻️',.9,bx,y+2.6,bz);
    I('cyl','#9b6a43',.05,2.2,.05,bx+1.6,y+1.1,bz+.6,0,0,.3);I('tor','#c9c2b8',.5,.5,.5,bx+1.95,y+2.1,bz+.6,Math.PI/2,0,0);col(bx,bz,1);}},
 {id:'tharpup',name:'Marie Tharpup',who:'Marie Tharp',breed:'American Water Spaniel',island:'reef',area:'trench',spot:{x:24,z:-32,kind:'boulder'},prop:'🗺️',exp:'sonar',expName:'Map the Sea Floor',
  hint:'Look by the pinging sonar machine in the Deep Trench.',
  fact:'Marie Tharpup is named after the real Marie Tharp, who made the first maps of the ocean floor. She found a giant mountain range running down the middle of the Atlantic Ocean, with a valley in its middle!',
  home:'Hide some toys under a towel and find their shapes by gently pressing with a pencil, like a ship mapping the sea floor.',
  rescue:{icon:'🗺️',verb:'Unroll',say:'Tharpup is rolled up in a big map! Tap to unroll it!'},
  look:{fur:'#6b3a22',ear:'#5a301c',ears:'floppy',fluffy:true,wool:true,muzzle:'#6b3a22',belly:'#7a4628',tail:'thin',acc:['grad','bubbles']},
  deco(x,z){const sx=x-4.5,sz=z,y=gy(sx,sz);I('box','#ffd23f',1.4,1,1.4,sx,y+.5,sz);I('cyl','#8a8f99',.08,1,.08,sx,y+1.5,sz);I('hemi','#c9c2b8',.7,.3,.7,sx,y+2.1,sz,Math.PI,0,0);
    const ring=new THREE.Mesh(G.tor,glowM('#7fffe0'));ring.rotation.x=Math.PI/2;ring.position.set(sx,y+.2,sz);W.ag.add(ring);W.ticks.push(()=>{const k=(W.t*.8)%1;ring.scale.set(1+k*6,1+k*6,.4);ring.material.opacity=1-k;ring.material.transparent=true;});col(sx,sz,1);}},
 /* Ninja Mountains */
 {id:'furaday',name:'Michael Furaday',who:'Michael Faraday',breed:'Bull Terrier',island:'ninja',area:'dojo',spot:{x:26,z:0,kind:'crate'},prop:'🧲',exp:'magnet',expName:'Magnet Test',
  hint:'Look by the giant magnet near the tea house at the Dojo.',
  fact:'Michael Furaday is named after the real Michael Faraday, who discovered how magnets and electricity work together. He built the first electric motor in 1821.',
  home:'Use a fridge magnet to test what it sticks to around the house: a spoon, a door, a cupboard, a toy.',
  rescue:{icon:'📎',verb:'Pull',say:'Furaday is stuck to a giant magnet with paperclips! Tap to pull them off!'},
  look:{fur:'#ffffff',ear:'#ffffff',ears:'pointy',muzzle:'#ffffff',belly:'#ffffff',patch:'#c8843a',tail:'thin',acc:['grad','embers']},
  deco(x,z){const mx=x-4.5,mz=z,y=gy(mx,mz),g=grp();const h=mk('tor','#e8423a',1.1,1.1,1.6,0,2.6,0,g);h.rotation.z=0;[-1,1].forEach(q=>{mk('box','#e8423a',.5,1.6,.5,q*1.1,1.8,0,g);mk('box','#c9c2b8',.52,.4,.52,q*1.1,.9,0,g);});
    add(g,mx,mz,y);for(let i=0;i<4;i++){const s=sprite('📎',.6);W.ag.add(s);W.ticks.push(()=>s.position.set(mx+(i%2?1.1:-1.1)+Math.sin(W.t*2+i)*.15,y+.3+i%2*.2,mz+.4));}col(mx,mz,1.6);}},
 {id:'laboisier',name:'Antoine Lab-oisier',who:'Antoine Lavoisier',breed:'Brittany',island:'ninja',area:'firet',spot:{x:18,z:-22,kind:'crate'},prop:'⚗️',exp:'fizz',expName:'Fizzy Balloon',
  hint:'Look by the bubbling science table in the Fire Temple.',
  fact:'Antoine Lab-oisier is named after the real Antoine Lavoisier, a French chemist. He named the gases oxygen and hydrogen, and showed that when things change, nothing really vanishes.',
  home:'With a grown-up: pour vinegar into a bottle, put bicarbonate of soda in a balloon, stretch the balloon over the bottle top and tip it in. Watch the balloon blow up!',
  rescue:{icon:'🧪',verb:'Tidy',say:'Lab-oisier knocked over the test tubes! Tap to tidy them up!'},
  look:{fur:'#ffffff',ear:'#c8642a',ears:'floppy',muzzle:'#ffffff',belly:'#ffffff',patch:'#c8642a',spots:true,spotC:'#e08a50',tail:'stub',acc:['grad','embers']},
  deco(x,z){const lx=x-4.5,lz=z,y=gy(lx,lz);I('box','#9b6a43',3,.2,1.4,lx,y+1.4,lz);[-1.3,1.3].forEach(q=>[-.6,.6].forEach(r=>I('cyl','#5b4636',.08,1.4,.08,lx+q,y+.7,lz+r)));
    [['#9be8ff',-.9],['#ff9ecb',0],['#c9ff7f',.9]].forEach(f=>{I('cone','#e8f4ff',.35,.7,.35,lx+f[1],y+1.85,lz);I('sph',f[0],.25,.22,.25,lx+f[1],y+1.7,lz,0,0,0,true);});
    let t=0;W.ticks.push(dt=>{t-=dt;if(t<0){t=.5;floatS('🫧',lx+(Math.floor(Math.random()*3)-1)*.9,y+2.3,lz,.5,1);}});col(lx,lz,1.6);}},
 {id:'fetchla',name:'Nikola Fetchla',who:'Nikola Tesla',breed:'Croatian Sheepdog',island:'ninja',area:'thunder',spot:{x:24,z:-2,kind:'crate'},prop:'💡',exp:'circuit',expName:'Light the Bulb',
  hint:'Look by the crackling coil tower in the Thunder Temple.',
  fact:'Nikola Fetchla is named after the real Nikola Tesla, an inventor who worked out better ways to send electricity to people\'s homes and to make electric motors.',
  home:'With a grown-up, count how many things in your kitchen use electricity. Never touch plugs or sockets yourself.',
  rescue:{icon:'⚡',verb:'Calm',say:"Fetchla's fur is full of fizzy static! Tap to smooth it down!"},
  look:{fur:'#26232e',ears:'pointy',fluffy:true,wool:true,muzzle:'#26232e',belly:'#3a3338',tail:'plume',acc:['grad','embers']},
  deco(x,z){const cx=x-4.5,cz=z,y=gy(cx,cz);I('cyl','#5b6b80',.9,.6,.9,cx,y+.3,cz);I('cyl','#c97a3e',.5,4,.5,cx,y+2.6,cz);for(let i=0;i<10;i++)I('tor','#e0a070',.55,.55,.3,cx,y+1+i*.35,cz,Math.PI/2,0,0);I('tor','#c9c2b8',1.1,1.1,1.4,cx,y+5,cz,Math.PI/2,0,0);
    const zs=[0,1,2].map(()=>{const s=sprite('⚡',.9);W.ag.add(s);return s;});W.ticks.push(()=>zs.forEach((s,i)=>{const a=W.t*7+i*2.1;s.position.set(cx+Math.cos(a)*1.6,y+5+Math.sin(W.t*13+i)*.3,cz+Math.sin(a)*1.6);s.visible=Math.sin(W.t*9+i*3)>0;}));col(cx,cz,1.2);}},
 {id:'rumble',name:'Rumble',who:'Zhang Heng',breed:'Tibetan Mastiff',island:'ninja',area:'peak',spot:{x:-26,z:-8,kind:'boulder'},prop:'🐉',exp:'quake',expName:'Dragon Jar',
  hint:'Look by the bronze dragon jar on Dragon Peak.',
  fact:'Rumble is named in honour of the real Zhang Heng, a scientist in China nearly 2,000 years ago. He built the first earthquake detector: a bronze jar with eight dragons. When the ground shook, a ball dropped from one dragon\'s mouth into a toad below.',
  home:'Put a cup of water on the table and tap the table gently. Watch the ripples show the shake!',
  rescue:{icon:'🐸',verb:'Catch',say:'Bronze balls are bouncing everywhere! Tap to catch them for the toads!'},
  look:{fur:'#3a2e2a',ear:'#3a2e2a',ears:'floppy',fluffy:true,muzzle:'#c8843a',brows:'#c8843a',belly:'#4a3a35',tail:'plume',hw:62,hh:56,acc:['grad','embers']},
  deco(x,z){const jx=x-5,jz=z,y=gy(jx,jz);I('cyl','#a8743a',1.3,2.4,1.3,jx,y+1.4,jz);I('hemi','#a8743a',1.3,.9,1.3,jx,y+2.6,jz);I('sph','#c9905f',.25,.25,.25,jx,y+3.6,jz);
    for(let i=0;i<8;i++){const a=i/8*6.283,dx=Math.cos(a),dz=Math.sin(a);I('sph','#3f8e6a',.3,.25,.4,jx+dx*1.4,y+2.2,jz+dz*1.4,0,-a,0);I('sph','#ffd23f',.12,.12,.12,jx+dx*1.65,y+2.05,jz+dz*1.65);I('sph','#5a8a3a',.3,.22,.3,jx+dx*1.9,y+.25,jz+dz*1.9);}col(jx,jz,1.9);}},
 /* Number Kingdom */
 {id:'pawlace',name:'Ada Pawlace',who:'Ada Lovelace',breed:'Rough Collie',island:'number',area:'towers',spot:{x:32,z:4,kind:'books'},prop:'⚙️',exp:'code',expName:'Code a Robot Pup',
  hint:'Look by the big gear machine at Times Table Towers.',
  fact:'Ada Pawlace is named after the real Ada Lovelace, who wrote what many people call the first computer program, in 1843, for a machine called the Analytical Engine.',
  home:'Write step-by-step instructions for a grown-up to make a jam sandwich, and see if they can follow them exactly!',
  rescue:{icon:'⚙️',verb:'Turn',say:'Pawlace is stuck in the gears! Tap to turn them!'},
  look:{fur:'#c8843a',ear:'#a0682a',ears:'pointy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',face:'#ffffff',faceLow:true,tail:'plume',acc:['grad','bow']},
  deco(x,z){const gx=x-4.5,gz=z,y=gy(gx,gz);I('box','#9b6a43',3,.4,2,gx,y+.2,gz);[-1,0,1].forEach((q,i)=>{const col_=grp();for(let k=0;k<6;k++){mk('cyl','#c9a86a',.55,.12,.55,0,.6+k*.5,0,col_);mk('tor','#a8743a',.5,.5,.25,0,.6+k*.5,0,col_).rotation.x=Math.PI/2;}add(col_,gx+q*.9,gz,y);W.ticks.push(dt=>{col_.rotation.y+=dt*(i%2?1:-1);});});
    I('box','#fff2b8',.8,1,.05,gx+1.8,y+1.2,gz+.6);col(gx,gz,1.8);}},
 {id:'fidonacci',name:'Fido-nacci',who:'Fibonacci',breed:'Italian Greyhound',island:'number',area:'river',spot:{x:-6,z:36,kind:'flowers'},prop:'🌻',exp:'spiral',expName:'Number Spiral',
  hint:'Look by the spiral of sunflowers at Skip-Count River.',
  fact:'Fido-nacci is named after the real Fibonacci, an Italian mathematician who wrote about a number pattern: 1, 1, 2, 3, 5, 8, 13. You add the two numbers before to get the next one. It hides in sunflowers and pine cones!',
  home:'Look closely at a pine cone or a sunflower head. Can you see the spirals going round?',
  rescue:{icon:'🌻',verb:'Count',say:'Fido-nacci is counting sunflower seeds and lost count! Tap to help!'},
  look:{fur:'#8a8090',ear:'#6b6270',ears:'side',muzzle:'#9a90a0',belly:'#ffffff',tail:'thin',scale:.85,acc:['grad','flower']},
  deco(x,z){const cx=x-5,cz=z;for(let i=1;i<=21;i++){const a=i*2.39996,r=.45*Math.sqrt(i),fx=cx+Math.cos(a)*r,fz=cz+Math.sin(a)*r,y=gy(fx,fz),h=.8+R()*.6;I('cylL','#4fae4a',.05,h,.05,fx,y+h/2,fz);I('cyl','#ffd23f',.3,.06,.3,fx,y+h,fz,Math.PI/2.4,0,0);I('cyl','#6b4028',.14,.08,.14,fx,y+h+.02,fz,Math.PI/2.4,0,0);}
    sign(cx-1,cz+4,'🌻 1, 1, 2, 3, 5, 8...',3,6);col(cx,cz,1.5);}},
 {id:'pupthagoras',name:'Pupthagoras',who:'Pythagoras',breed:'Saluki',island:'number',area:'shapes',spot:{x:22,z:-34,kind:'bush'},prop:'📐',exp:'pyth',expName:'Triangle Squares',
  hint:'Look by the big triangle in the Shape Garden.',
  fact:'Pupthagoras is named after the real Pythagoras, who lived in Ancient Greece. He is famous for a rule about triangles with a square corner: the squares on the two short sides add up to the square on the long side.',
  home:'On squared paper, draw a triangle with sides of 3, 4 and 5 squares. Draw a square on each side and count the little squares inside.',
  rescue:{icon:'📐',verb:'Free',say:'Pupthagoras is stuck inside a triangle! Tap to lift it off!'},
  look:{fur:'#e8d0a8',ear:'#c8a070',ears:'long',earLen:1.3,fluffy:false,muzzle:'#f2e0c0',belly:'#f2e6d8',tail:'thin',acc:['grad','bow']},
  deco(x,z){const tx=x-5.5,tz=z,y=gy(tx,tz),g=grp();mk('box','#ff6b6b',3,.3,.3,0,.15,0,g);mk('box','#7fc8f0',.3,4,.3,-1.5,2,0,g);const h=mk('box','#8fe39a',.3,5,.3,0,2,0,g);h.rotation.z=Math.atan2(3,4);
    mk('box','#ffd23f',.6,.6,.32,-1.2,.45,0,g);g.rotation.y=.5;add(g,tx,tz,y);const l=label('3² + 4² = 5²',3.6);l.position.set(tx,y+5,tz);W.ag.add(l);col(tx,tz,1.8);}},
 {id:'pawstein',name:'Albert Pawstein',who:'Albert Einstein',breed:'German Shepherd',island:'number',area:'library',spot:{x:-14,z:4,kind:'books'},prop:'💡',exp:'light',expName:'Race the Light',
  hint:'Look by the chalkboard in the Secret Library.',
  fact:'Albert Pawstein is named after the real Albert Einstein, who worked out that nothing can travel faster than light. Light is so fast it could go round the Earth about seven times in one second! A famous photo shows the real Einstein, with his wild white hair, sticking his tongue out for fun on his 72nd birthday.',
  home:'Switch on a torch in a dark room. The light reaches the wall straight away. That is how fast light is!',
  rescue:{icon:'🌟',verb:'Wake',say:'Pawstein is lost in a big thought! Tap to say hello!'},
  look:{fur:'#c8843a',ear:'#26232e',ears:'pointy',earBig:true,muzzle:'#3a3338',bodyPatch:'#26232e',belly:'#d9a060',eyeWhite:true,tail:'plume',acc:['einstein','twinkle']},
  deco(x,z){const bx=x-4.5,bz=z,y=gy(bx,bz);I('box','#9b6a43',3.6,2.4,.3,bx,y+2.4,bz,0,Math.PI/2,0);I('box','#2f4f3a',3.2,2,.32,bx,y+2.4,bz,0,Math.PI/2,0);[-1.3,1.3].forEach(q=>I('cyl','#9b6a43',.08,2.4,.08,bx,y+1.2,bz+q));
    const l=label('E = mc²',3.4,'#2f4f3a','#ffffff');l.position.set(bx+.3,y+2.5,bz);W.ag.add(l);col(bx,bz,1.4);}}];
S.forEach(p=>{if(p.area==='wood'&&!p.deco)p.deco=(x,z)=>{const y=gy(x-4,z);I('cyl','#6b4028',.5,3,.5,x-4.5,y+.5,z,0,0,Math.PI/2);['🐞','🪲','🐛','🔍'].forEach((e,i)=>spr(e,i===3?1.2:.7,x-5.5+i*.8,y+1.1+(i===3?.8:0),z+(i%2?.6:-.4)));sign(x-6,z+3.5,'🔍 Beetle log',2.6,5);col(x-4.5,z,1.2);};});
regSci(S);

/* ----------------- found: off to the lab ----------------- */
window.sciFoundSay=p=>`${p.name} has gone to the Science Lab in Pawprint Village! Visit the lab to try an experiment together.`;

/* ----------------- the Science Lab screen ----------------- */
let labIsl='meadow';
const FIZZ={id:'fizz',name:'Professor Fizz',breed:'Labrador',lv:1,look:{fur:'#e8c07a',ear:'#d9a860',ears:'floppy',muzzle:'#f2d9a8',belly:'#f2d9a8',tail:'wag',acc:['grad','scarf'],scarfC:'#7fc8f0'}};
function openLab(isl){hush();QZ=null;labIsl=isl||labIsl;if(!islOpen(labIsl))labIsl='meadow';show('lab');$('#labStars').textContent='⭐ '+state.stars;$('#labBg').innerHTML=labSVG();$('#labHost').innerHTML=pupBox(FIZZ,{anim:true});
  const tabs=$('#labTabs');tabs.innerHTML='';ISLANDS.filter(I=>SCI.some(p=>p.island===I.id)).forEach(I=>{const L=SCI.filter(p=>p.island===I.id),open=islOpen(I.id);
    const b=el('button','tab'+(I.id===labIsl?' sel':'')+(open?'':' lock'),`${I.icon}<small>${open?foundIn(L)+'/'+L.length:'🔒'}</small>`);tap(b,()=>{if(!open){sfx.oops();say(islLockSay(I.id));return;}sfx.boop();openLab(I.id);});tabs.appendChild(b);});
  const gr=$('#labGrid');gr.innerHTML='';SCI.filter(p=>p.island===labIsl).forEach(p=>{const f=isFound(p.id),done=(state.lab||{})[p.id];
    const b=el('button','lcard'+(f?'':' miss'),f?`${pupBox(p,{anim:false})}<b>${p.name}</b><small>inspired by ${p.who}</small><span class="lexp">${p.prop} ${p.expName}${done?' ✅':''}</span>`:`<div class="q">?</div><b>${AREAS[p.area].icon} ${AREAS[p.area].name}</b><small>${p.hint}</small>`);
    tap(b,()=>{initAudio();sfx.boop();if(!f){say(`A science pup is hiding in ${AREAS[p.area].name}. ${p.hint}`);return;}labCard(p);});gr.appendChild(b);});
  const n=sciFound().length;say(n?`Hello, I am Professor Fizz! Tap a science pup to try an experiment.`:'Hello, I am Professor Fizz! Find the science pups on the islands, then come back for experiments.');}
function labCard(p){card({art:`<div style="position:relative;display:inline-block">${pupBox(p)}<div style="position:absolute;right:-20px;top:-10px;font-size:60px">${p.prop}</div></div>`,h:p.name,h3:`inspired by ${p.who}`,p:p.fact,say:p.fact,
  btns:[[`▶ ${p.expName}`,'green',()=>openExp(p)],['🏠 Try at home','white',()=>homeCard(p)],['Close','white']]});}
function homeCard(p){card({art:`<div style="font-size:100px;line-height:1">🏠${p.prop}</div>`,h:'Try it at home!',p:p.home,say:`Try it at home! ${p.home}`,btns:[['🔬 Back to the lab','green',()=>openLab()]]});}
function labSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e6f4ff"/>`;for(let i=0;i<16;i++)s+=`<rect x="${i*64}" y="0" width="62" height="768" fill="${i%2?'#dcefff':'#e6f4ff'}"/>`;
  s+=`<rect y="600" width="1024" height="168" fill="#c9d6e6"/><rect x="0" y="580" width="1024" height="30" fill="#9b6a43" stroke="${k}" stroke-width="4"/>`;
  [['#9be8ff',60],['#ff9ecb',110],['#c9ff7f',160],['#ffd23f',210]].forEach(f=>s+=`<path d="M${f[1]} 500 l-22 70 h44 Z" fill="${f[0]}" stroke="${k}" stroke-width="3"/><rect x="${f[1]-7}" y="470" width="14" height="32" fill="#e8f4ff" stroke="${k}" stroke-width="3"/>`);
  return s+`<text x="900" y="560" font-size="70">🔭</text><text x="800" y="560" font-size="56">🧲</text><text x="60" y="140" font-size="60">⚛️</text></svg>`;}

/* ----------------- experiments: shared bits ----------------- */
let EXP=null;
function openExp(p){hush();EXP={p,t0:performance.now()};show('sci');$('#sciTitle').textContent=`${p.prop} ${p.expName}`;$('#sciInfo').textContent=p.name;$('#sciBg').innerHTML='';const st=$('#sciStage');st.innerHTML='';st.onclick=null;
  const run=XP[p.exp];if(QUIZ['sci_'+p.exp]){startQuiz('lab','sci_'+p.exp);return;}if(run)run(st,p);}
function sciDone(p){const id=p.id;state.lab=state.lab||{};const first=!state.lab[id];state.lab[id]=(state.lab[id]||0)+1;if(first)state.stars+=15;state.stats.experiments=(state.stats.experiments||0)+1;save();EXP=null;
  sfx.fanfare();confetti(70);card({art:`<div style="font-size:110px;line-height:1">${p.prop}🎉</div>`,h:'Experiment complete!',h3:`${p.expName} with ${p.name}`,p:`${first?'+15 stars! ':''}Try it at home: ${p.home}`,say:`Brilliant science, Seb! ${first?'Plus 15 stars! ':''}Try it at home: ${p.home}`,
    btns:[['🔁 Again','white',()=>openExp(p)],['🔬 Lab','green',()=>openLab()]]});}
const XP={};
const bigBtn=(t,cls,cb)=>{const b=el('button','btn '+(cls||'white')+' xbtn',t);tap(b,()=>{initAudio();cb(b);});return b;};
const place=(e,x,y,w,h)=>{e.style.cssText+=`;position:absolute;left:${x}px;top:${y}px;${w?'width:'+w+'px;':''}${h?'height:'+h+'px;':''}`;return e;};
function choiceRow(st,opts,ans,onRight,y){const row=place(el('div','xrow',''),0,y||600,1024);opts.forEach(o=>{const b=bigBtn(o[1],'white',()=>{if(o[0]===ans){sfx.chime();b.classList.add('right');row.remove();onRight();}else{sfx.oops();anim(b,'t-shake',500);b.disabled=true;say(o[2]||'Not quite. Have another go!');}});row.appendChild(b);});st.appendChild(row);return row;}

/* ---- sort engine: float or sink, pack the bag, magnets ---- */
function sortExp(st,cfg,p){let i=0,score=0;const items=shuffle(cfg.items.slice()).slice(0,cfg.n||8);
  $('#sciBg').innerHTML=cfg.bg();const show=el('div','xitem','');place(show,312,150,400,260);st.appendChild(show);const res=place(el('div','xres',''),262,420,500,90);st.appendChild(res);
  const row=place(el('div','xrow',''),0,600,1024);cfg.bins.forEach(bn=>{const b=bigBtn(`${bn.icon}<small>${bn.label}</small>`,'white',()=>pickBin(bn.k,b));row.appendChild(b);});st.appendChild(row);
  const next=()=>{if(i>=items.length){say(cfg.end);setTimeout(()=>sciDone(p),1600);return;}const it=items[i];show.innerHTML=`<div class="xe">${it.e}</div><div class="xn">${it.n}</div>`;res.innerHTML='';[...row.children].forEach(b=>{b.disabled=false;b.classList.remove('right');});say(cfg.ask(it));};
  const pickBin=(k,b)=>{const it=items[i];if(!it||show.dataset.busy)return;const ok=it.k===k;
    if(cfg.test){show.dataset.busy=1;[...row.children].forEach(x=>x.disabled=true);if(cfg.anim)cfg.anim(show,it);sfx[ok?'chime':'boop']();if(ok)score++;res.innerHTML=`<b>${ok?'✅ Yes!':'😮 Surprise!'}</b> ${it.why}`;say(`${ok?'Yes! ':'Surprise! '}${it.why}`);
      setTimeout(()=>{delete show.dataset.busy;i++;next();},2600);}
    else if(ok){sfx.chime();b.classList.add('right');show.dataset.busy=1;res.innerHTML=`<b>✅</b> ${it.why}`;say(it.why);setTimeout(()=>{delete show.dataset.busy;i++;next();},1500);}
    else{sfx.oops();anim(b,'t-shake',500);say(`Hmm, think again. ${it.hint||''}`);}};
  say(cfg.intro);setTimeout(next,cfg.introMs||3200);}
XP.float=(st,p)=>sortExp(st,{bg:()=>tankSVG(),test:true,n:8,bins:[{k:'float',icon:'🛟',label:'Floats'},{k:'sink',icon:'⚓',label:'Sinks'}],
  intro:'Float or sink? Guess first, then we drop it in the bath and see!',ask:it=>`Will the ${it.n} float or sink?`,end:'Eureka! Things float when the water can push them up hard enough. Heavy, small things like coins sink.',
  anim:(show,it)=>{show.querySelector('.xe').style.transform=it.k==='float'?'translateY(80px)':'translateY(190px)';},
  items:[{e:'🦆',n:'rubber duck',k:'float',why:'The rubber duck floats! It is full of air.'},{e:'🪙',n:'coin',k:'sink',why:'The coin sinks! It is small and heavy for its size.'},{e:'🍎',n:'apple',k:'float',why:'The apple floats! It has lots of air inside.'},{e:'🪨',n:'pebble',k:'sink',why:'The pebble sinks straight to the bottom.'},
    {e:'🔑',n:'key',k:'sink',why:'The metal key sinks.'},{e:'🧽',n:'sponge',k:'float',why:'The sponge floats! It is full of tiny air holes.'},{e:'🪵',n:'piece of wood',k:'float',why:'Wood floats! That is why boats used to be made of wood.'},{e:'🥄',n:'metal spoon',k:'sink',why:'The metal spoon sinks.'},{e:'🏐',n:'beach ball',k:'float',why:'The beach ball floats high. It is full of air.'},{e:'🍇',n:'grape',k:'sink',why:'Most grapes sink! Surprise!'}]},p);
XP.divekit=(st,p)=>sortExp(st,{bg:()=>seaSVG(),n:8,bins:[{k:'yes',icon:'🎒',label:'Dive bag'},{k:'no',icon:'🏠',label:'Leave at home'}],
  intro:'Pack the dive bag for an adventure under the sea! Does each thing go in the bag, or stay at home?',ask:it=>`The ${it.n}. Dive bag, or leave it at home?`,end:'The dive bag is packed! With an air tank on his back, Jacques Cousteau could explore under the sea for a long time.',
  items:[{e:'🤿',n:'diving mask',k:'yes',why:'A mask lets you see clearly under water.',hint:'Divers need to see!'},{e:'🧪',n:'air tank',k:'yes',why:'The air tank holds air to breathe. That is the Aqua-Lung idea!',hint:'Divers need air to breathe.'},{e:'🦶',n:'pair of flippers',k:'yes',why:'Flippers help you swim fast.',hint:'How do divers swim fast?'},
    {e:'🩱',n:'wetsuit',k:'yes',why:'A wetsuit keeps you warm in cold water.',hint:'The sea can be cold!'},{e:'☂️',n:'umbrella',k:'no',why:'You do not need an umbrella under the sea!',hint:'Would that help under water?'},{e:'👢',n:'pair of wellies',k:'no',why:'Wellies would fill up with water!',hint:'Would those help you swim?'},
    {e:'🧸',n:'teddy',k:'no',why:'Teddy can wait at home, nice and dry.',hint:'Teddy would get soggy!'},{e:'🔦',n:'waterproof torch',k:'yes',why:'A torch lights up the dark deep sea.',hint:'It is dark deep down.'},{e:'📚',n:'pile of books',k:'no',why:'Books would get soggy under the sea!',hint:'Paper and water do not mix.'}]},p);
XP.magnet=(st,p)=>sortExp(st,{bg:()=>labBenchSVG().replace('</svg>','<text x="512" y="200" font-size="110" text-anchor="middle">🧲</text></svg>'),test:true,n:8,bins:[{k:'yes',icon:'🧲',label:'Sticks'},{k:'no',icon:'🚫',label:'Does not stick'}],
  intro:'Magnet test! Guess first: will the magnet pick it up? Then we test it!',ask:it=>`Will the magnet pick up the ${it.n}?`,end:'Magnets pull things made of iron and steel. Michael Faraday found that magnets and electricity can work together to make motors spin!',
  anim:(show,it)=>{show.querySelector('.xe').style.transform=it.k==='yes'?'translateY(-60px) scale(.8)':'translateY(30px)';},
  items:[{e:'📎',n:'paperclip',k:'yes',why:'The paperclip jumps to the magnet! It is made of steel.'},{e:'🔩',n:'steel bolt',k:'yes',why:'The steel bolt sticks to the magnet.'},{e:'🪵',n:'wooden block',k:'no',why:'Wood does not stick to a magnet.'},{e:'🦆',n:'plastic duck',k:'no',why:'Plastic does not stick to a magnet.'},
    {e:'📄',n:'piece of paper',k:'no',why:'Paper does not stick to a magnet.'},{e:'🪡',n:'sewing needle',k:'yes',why:'The steel needle sticks to the magnet.'},{e:'🍌',n:'banana',k:'no',why:'Bananas are not magnetic!'},{e:'🧸',n:'teddy',k:'no',why:'Teddy is not magnetic.'},{e:'🥫',n:'tin of beans',k:'yes',why:'The tin sticks! Most food tins are made of steel.'}]},p);

/* ---- tap engine: moons, clean-up, soil ---- */
function tapExp(st,cfg,p){$('#sciBg').innerHTML=cfg.bg();let hit=0;const need=cfg.targets.filter(t=>t.ok).length;const info=$('#sciInfo');info.textContent=`${p.name} · 0/${need}`;
  cfg.targets.forEach((t,i)=>{const b=place(el('button','xtap'+(t.cls?' '+t.cls:''),t.h||t.e),t.x,t.y,t.s||80,t.s||80);b.style.fontSize=((t.s||80)*.75)+'px';if(t.drift)b.style.animation=`xdrift ${4+i%3}s ease-in-out ${i*.3}s infinite alternate`;
    tap(b,()=>{initAudio();if(b.dataset.done)return;if(!t.ok){sfx.boop();say(t.msg||cfg.wrong);return;}b.dataset.done=1;hit++;info.textContent=`${p.name} · ${hit}/${need}`;sfx.pop();if(cfg.onHit)cfg.onHit(b,t,hit);else{b.style.transition='all .5s';b.style.opacity='0';b.style.transform='scale(.2)';}
      if(t.say)say(t.say);if(hit>=need){setTimeout(()=>{say(cfg.end);setTimeout(()=>sciDone(p),2400);},900);}});st.appendChild(b);});say(cfg.intro);}
XP.moons=(st,p)=>{const moons=[['Io',300],['Europa',400],['Ganymede',640],['Callisto',760]],stars=[[120,140],[880,120],[200,520],[840,500],[520,120],[90,330]];
  tapExp(st,{bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#0b1030"/>${Array.from({length:60},(_,i)=>`<circle cx="${(i*173)%1010}" cy="${(i*97)%740}" r="${1+i%3}" fill="#fff" opacity=".6"/>`).join('')}<circle cx="512" cy="360" r="300" fill="none" stroke="#3a4a7a" stroke-width="14"/>
    <circle cx="512" cy="370" r="62" fill="#e8c79a"/><rect x="452" y="345" width="120" height="12" fill="#c8843a" opacity=".7"/><rect x="455" y="372" width="114" height="10" fill="#b5703a" opacity=".6"/><circle cx="530" cy="392" r="8" fill="#c8642a"/></svg>`,
    intro:'Look through Galileo\'s telescope! That big planet is Jupiter. Galileo spotted four little moons next to it. Tap all four moons!',wrong:'That is a star, very far away. Look for the little moons in a line next to Jupiter!',end:'You found all four! Io, Europa, Ganymede and Callisto. Galileo saw them in 1610, and they are still called the Galilean moons.',
    targets:moons.map(m=>({e:'⚪',x:m[1]-20,y:350,s:40,ok:true,say:m[0]+'!',cls:'moon'})).concat(stars.map(s=>({e:'✦',x:s[0],y:s[1],s:46,ok:false,cls:'star'}))),
    onHit:(b,t)=>{b.style.background='#ffd23f';b.innerHTML=`<span class="xlab">${t.say.replace('!','')}</span>`;}},p);};
XP.cleanup=(st,p)=>{const junk=['🥤','🧴','🛍️','🥫','🧃','🧴','🥤','🛍️'],life=['🐟','🐢','🐠','🦀','🐙','🐡'];const T=[];
  junk.forEach((e,i)=>T.push({e,x:120+(i%4)*210+R()*60,y:150+Math.floor(i/4)*230+R()*60,s:84,ok:true,drift:true}));life.forEach((e,i)=>T.push({e,x:80+i*150+R()*40,y:300+(i%2)*200,s:84,ok:false,drift:true,msg:`That is a ${({'🐟':'fish','🐢':'turtle','🐠':'fish','🦀':'crab','🐙':'octopus','🐡':'pufferfish'})[e]}! Leave it to swim, and tap the rubbish instead.`}));
  tapExp(st,{bg:()=>seaSVG(),intro:'Clean the sea with Rachel Barkson! Tap all the rubbish to put it in the net, but leave the sea creatures alone.',wrong:'Leave the sea creatures, and tap the rubbish!',end:'The sea is clean! Rachel Carson helped people understand why we must look after nature.',targets:T},p);};
XP.soil=(st,p)=>{const T=[];for(let i=0;i<12;i++){const tired=[0,2,3,6,9,11].indexOf(i)>=0;T.push({h:tired?'<span class="soil tired">😴</span>':'<span class="soil">🌱</span>',x:170+(i%4)*180,y:150+Math.floor(i/4)*150,s:140,ok:tired,msg:'That soil is already happy. Find the tired, sleepy soil!'});}
  tapExp(st,{bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#b5e2ff"/><rect y="110" width="1024" height="658" fill="#8fd170"/></svg>`,intro:'Years of growing cotton made some of this soil tired. Tap the tired soil to plant peanuts and make it healthy again!',end:'All the soil is healthy! George Washington Carver taught farmers that peanuts help tired soil get its goodness back.',
    targets:T,onHit:(b)=>{b.innerHTML='<span class="soil">🥜</span>';b.classList.add('happy');}},p);};
XP.sonar=(st,p)=>{const D=[420,400,380,330,270,210,250,210,270,330,380,410];const T=D.map((d,i)=>({h:'<span class="ping">📡</span>',x:40+i*80,y:130,s:70,ok:true}));
  tapExp(st,{bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#0e3a6a"/><rect width="1024" height="120" fill="#b5e2ff"/><rect y="110" width="1024" height="20" fill="#5fc4f0"/><text x="900" y="105" font-size="70">🚢</text><g id="sea"></g></svg>`,
    intro:'Help Marie Tharpup map the sea floor! Tap each sonar dish to send a ping down and measure how deep the water is.',end:'Look! A giant mountain range under the sea, with a valley in the middle. Marie Tharp drew the first maps of it!',targets:T,
    onHit:(b,t,n)=>{const i=T.indexOf(t),d=D[i],g=document.querySelector('#sciBg #sea');if(g)g.insertAdjacentHTML('beforeend',`<rect x="${40+i*80}" y="${130+d}" width="80" height="${640-d}" fill="#c9905f" stroke="#5b4636" stroke-width="3"/><circle cx="${75+i*80}" cy="${130+d}" r="8" fill="#ffd23f"/>`);b.style.opacity='.35';}},p);};

/* ---- custom experiments ---- */
XP.drop=(st,p)=>{const scene=(moon)=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="${moon?'#0b1030':'#b5e2ff'}"/>${moon?'<circle cx="840" cy="140" r="60" fill="#5fa8e0"/><path d="M800 120 q30 -20 60 10 q-10 30 -40 30z" fill="#5fbf5a"/>':''}<rect y="640" width="1024" height="128" fill="${moon?'#b7bcc9':'#8fd170'}"/><rect x="300" y="160" width="420" height="30" fill="#9b6a43"/></svg>`;
  const ball=place(el('div','xobj','⚽'),380,90,90,90),fea=place(el('div','xobj','🪶'),560,90,90,90);st.append(ball,fea);
  const go=(moon,cb)=>{[ball,fea].forEach(o=>{o.style.transition='none';o.style.transform='translateY(0)';});void ball.offsetWidth;
    ball.style.transition=moon?'transform 2.2s ease-in':'transform .9s ease-in';fea.style.transition=moon?'transform 2.2s ease-in':'transform 3.6s cubic-bezier(.3,.1,.6,1)';ball.style.transform=fea.style.transform='translateY(470px)';if(!moon)fea.animate([{marginLeft:'0px'},{marginLeft:'60px'},{marginLeft:'-40px'},{marginLeft:'40px'},{marginLeft:'0px'}],{duration:3600});setTimeout(cb,moon?2500:3900);};
  const ask=(moon)=>{$('#sciBg').innerHTML=scene(moon);[ball,fea].forEach(o=>{o.style.transition='none';o.style.transform='translateY(0)';});say(moon?'Now we are on the Moon, where there is no air! Which lands first now?':'Seb drops a ball and a feather at the same time. Which do you think lands first?');
    const row=place(el('div','xrow',''),0,620,1024);[['ball','⚽ The ball'],['feather','🪶 The feather'],['same','🤝 Both together']].forEach(o=>{const b=bigBtn(o[1],'white',()=>{row.remove();sfx.boop();go(moon,()=>{
      if(!moon){say((o[0]==='ball'?'Yes! ':'Watch! ')+'The ball lands first. The air pushes on the light feather and slows it down. Gravity pulls them both, but the air gets in the way!');setTimeout(()=>ask(true),5200);}
      else{say((o[0]==='same'?'Yes! ':'Look! ')+'They land together! With no air, the feather falls just like the ball. An astronaut really tried this on the Moon in 1971, with a hammer and a feather!');setTimeout(()=>sciDone(p),6000);}});});row.appendChild(b);});st.appendChild(row);};
  ask(false);};
XP.flake=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#3d6fb0"/>${Array.from({length:40},(_,i)=>`<circle cx="${(i*151)%1010}" cy="${(i*83)%740}" r="${2+i%4}" fill="#fff" opacity=".5"/>`).join('')}</svg>`;
  const svgNS='http://www.w3.org/2000/svg';const box=place(el('div','',`<svg viewBox="-200 -200 400 400" width="460" height="460"><g id="flk" stroke="#ffffff" stroke-width="10" stroke-linecap="round" fill="#ffffff"></g></svg>`),282,60);st.appendChild(box);const g=box.querySelector('#flk');
  const arm=(f)=>{for(let k=0;k<6;k++){const r=document.createElementNS(svgNS,'g');r.setAttribute('transform',`rotate(${k*60})`);r.innerHTML=f;g.appendChild(r);}};arm('<line x1="0" y1="0" x2="0" y2="-170"/>');let n=0;
  const parts=[['💎',d=>`<path d="M0 ${-d-18} l14 18 l-14 18 l-14 -18z"/>`],['🔵',d=>`<circle cx="0" cy="${-d}" r="14"/>`],['🌿',d=>`<line x1="0" y1="${-d}" x2="-34" y2="${-d-34}"/><line x1="0" y1="${-d}" x2="34" y2="${-d-34}"/>`],['⭕',d=>`<circle cx="0" cy="${-d}" r="18" fill="none"/>`],['🔺',d=>`<path d="M0 ${-d-20} l18 30 h-36z"/>`]];
  const row=place(el('div','xrow',''),0,560,1024);parts.forEach(q=>{row.appendChild(bigBtn(q[0],'white',()=>{if(n>=5)return;arm(q[1](40+n*26));n++;sfx.pop();say(n<5?`Lovely! It copies onto all six arms. Add ${5-n} more.`:'Your snowflake is finished! How many arms does it have?');if(n>=5){row.remove();
    choiceRow(st,[[4,'4'],[5,'5'],[6,'6'],[8,'8']],6,()=>{say('Six! Every snowflake has six arms or sides. Wilson Bentley photographed over 5,000 snowflakes, and no two looked the same!');setTimeout(()=>sciDone(p),5200);},600);}}));});st.appendChild(row);
  say('Make your own snowflake! Tap a shape to add it, and watch it copy onto every arm.');};
XP.circuit=(st,p)=>{$('#sciBg').innerHTML=labBenchSVG();const box=place(el('div','',`<svg viewBox="0 0 600 360" width="560" height="336"><rect x="60" y="60" width="480" height="240" rx="20" fill="none" stroke="#c97a3e" stroke-width="12" stroke-dasharray="none"/>
    <rect x="30" y="140" width="60" height="90" rx="8" fill="#3a3338"/><rect x="45" y="128" width="30" height="14" fill="#c9c2b8"/><text x="60" y="200" font-size="34" text-anchor="middle" fill="#ffd23f">+</text>
    <circle id="bulb" cx="300" cy="40" r="38" fill="#f2f0ea" stroke="#5b4636" stroke-width="5"/><rect x="285" y="72" width="30" height="20" fill="#8a8f99"/>
    ${[[150,300],[450,300],[540,180]].map((q,i)=>`<rect id="gap${i}" x="${q[0]-36}" y="${q[1]-22}" width="72" height="44" rx="10" fill="#e6f4ff" stroke="#e8423a" stroke-width="5" stroke-dasharray="8 6"/>`).join('')}</svg>`),232,170);st.appendChild(box);
  const items=[['📎','metal paperclip',true],['〰️','copper wire',true],['🥄','metal spoon',true],['🥤','plastic straw',false],['🪵','wooden stick',false],['➰','rubber band',false]];let n=0;
  const row=place(el('div','xrow',''),0,560,1024);items.forEach(it=>{const b=bigBtn(`${it[0]}<small>${it[1]}</small>`,'white',()=>{if(n>=3)return;if(!it[2]){sfx.oops();anim(b,'t-shake',500);say(`The ${it[1]} does not let electricity through. Try something made of metal!`);return;}
    const gp=box.querySelector('#gap'+n);gp.setAttribute('fill','#ffd23f');gp.setAttribute('stroke','#c97a3e');gp.setAttribute('stroke-dasharray','none');box.querySelector('svg').insertAdjacentHTML('beforeend',`<text x="${+gp.getAttribute('x')+36}" y="${+gp.getAttribute('y')+34}" font-size="30" text-anchor="middle">${it[0]}</text>`);n++;sfx.pop();b.disabled=true;
    if(n<3)say(`Yes! Metal lets electricity flow. ${3-n} more ${3-n>1?'gaps':'gap'} to fill.`);else{row.remove();const bl=box.querySelector('#bulb');bl.setAttribute('fill','#fff27a');bl.style.filter='drop-shadow(0 0 30px #ffd23f)';sfx.jingle();
      say('The bulb lights up! Electricity flows all the way round a loop of metal, called a circuit. Nikola Tesla worked on new ways to bring electricity to our homes.');setTimeout(()=>sciDone(p),5600);}});row.appendChild(b);});st.appendChild(row);
  say('Light the bulb! Fill the three gaps in the circuit. Which things let electricity flow through?');};
XP.quake=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#efe3c4"/><circle cx="512" cy="410" r="120" fill="#a8743a" stroke="#5b4636" stroke-width="6"/><circle cx="512" cy="410" r="70" fill="#c9905f"/>
    ${['N','E','S','W'].map((d,i)=>`<text x="${512+[0,300,0,-300][i]}" y="${410+[-262,10,282,10][i]}" font-size="44" font-weight="900" text-anchor="middle" fill="#5b4636">${d}</text>`).join('')}</svg>`;
  const dirs=[['north','N',0],['north-east','NE',45],['east','E',90],['south-east','SE',135],['south','S',180],['south-west','SW',225],['west','W',270],['north-west','NW',315]];const btn={};
  dirs.forEach(d=>{const a=d[2]*Math.PI/180,x=512+Math.sin(a)*175-40,y=410-Math.cos(a)*175-40;const b=place(el('button','xtap drag','🐉'),x,y,80,80);b.style.fontSize='56px';tap(b,()=>dpick(d,b));btn[d[0]]=b;st.appendChild(b);
    const t=place(el('div','xtoad','🐸'),512+Math.sin(a)*250-24,410-Math.cos(a)*250-24,48,48);t.style.fontSize='40px';st.appendChild(t);});
  const order=shuffle(dirs.slice(0,8).filter((d,i)=>i%2===0)).concat(shuffle(dirs.filter((d,i)=>i%2===1)).slice(0,2));let r=0;
  const ask=()=>{if(r>=order.length){say('Well done! Zhang Heng\'s dragon jar told people which way an earthquake came from, nearly 2,000 years ago!');setTimeout(()=>sciDone(p),4600);return;}say(`Rumble! The ground shakes from the ${order[r][0]}! Tap the dragon that drops its ball.`);};
  function dpick(d,b){initAudio();if(r>=order.length)return;if(d===order[r]){sfx.pop();const a=d[2]*Math.PI/180;const ball=place(el('div','xball','🟡'),512+Math.sin(a)*175-14,410-Math.cos(a)*175-14,28,28);st.appendChild(ball);
      requestAnimationFrame(()=>{ball.style.transition='all .7s ease-in';ball.style.left=(512+Math.sin(a)*250-14)+'px';ball.style.top=(410-Math.cos(a)*250-14)+'px';});setTimeout(()=>{sfx.chime();ball.remove();},800);r++;setTimeout(ask,1300);}
    else{sfx.oops();anim(b,'t-shake',500);say(`Not that one! Look for ${order[r][1]} on the compass, for ${order[r][0]}.`);}}
  ask();};
XP.fizz=(st,p)=>{$('#sciBg').innerHTML=labBenchSVG();const box=place(el('div','',`<svg viewBox="0 0 300 460" width="260" height="400"><ellipse id="bal" cx="150" cy="120" rx="40" ry="30" fill="#ff6b6b" stroke="#5b4636" stroke-width="5"/><rect x="132" y="140" width="36" height="40" fill="#ff6b6b" stroke="#5b4636" stroke-width="5"/>
    <path d="M110 180 h80 v40 q50 30 50 90 v120 q0 20 -20 20 h-140 q-20 0 -20 -20 v-120 q0 -60 50 -90z" fill="#e8f4ff" stroke="#5b4636" stroke-width="5" opacity=".9"/><rect x="72" y="330" width="156" height="118" rx="14" fill="#fff6c9"/><g id="bub"></g></svg>`),382,180);st.appendChild(box);let n=0;
  const row=place(el('div','xrow',''),0,600,1024);const add=bigBtn('🥄<small>Add bicarbonate of soda</small>','green',()=>{if(n>=4)return;n++;sfx.pop();const b=box.querySelector('#bal');b.setAttribute('rx',40+n*22);b.setAttribute('ry',30+n*20);b.setAttribute('cy',120-n*14);
    const g=box.querySelector('#bub');for(let i=0;i<8;i++)g.insertAdjacentHTML('beforeend',`<circle cx="${90+Math.random()*120}" cy="${340+Math.random()*90}" r="${3+Math.random()*6}" fill="#fff" stroke="#9fd8f0"/>`);
    if(n<4)say(['Fizz! Bubbles!','More fizz! The balloon is growing!','Look how big it is getting!'][n-1]);else{row.remove();say('Wow! What blew up the balloon?');choiceRow(st,[['gas','💨 A gas'],['water','💧 Water','Water stayed in the bottle. Look at the bubbles!'],['sand','🏖️ Sand','There is no sand in there! What was in the bubbles?']],'gas',()=>{
      say('A gas! Vinegar and bicarbonate of soda make a gas called carbon dioxide, and it filled the balloon. Antoine Lavoisier showed that when things change, nothing really vanishes. It just turns into something else!');setTimeout(()=>sciDone(p),7000);},600);}});
  row.appendChild(add);st.appendChild(row);say('The bottle has vinegar in it. Tap the spoon to add bicarbonate of soda, and watch what happens to the balloon!');};
XP.light=(st,p)=>{$('#sciBg').innerHTML=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#0b1030"/>${Array.from({length:50},(_,i)=>`<circle cx="${(i*173)%1010}" cy="${(i*97)%740}" r="${1+i%3}" fill="#fff" opacity=".5"/>`).join('')}
    <circle cx="512" cy="330" r="120" fill="#3d8fe0"/><path d="M450 260 q40 -30 80 0 q20 40 -20 60 q-40 10 -60 -20z M540 350 q40 -10 50 30 q-20 40 -60 20z" fill="#5fbf5a"/><circle cx="512" cy="330" r="190" fill="none" stroke="#5b6378" stroke-width="3" stroke-dasharray="10 10"/></svg>`;
  const runner=place(el('div','xobj',''),0,0,70,70);runner.style.fontSize='56px';st.appendChild(runner);const tag=place(el('div','xres',''),212,560,600,60);st.appendChild(tag);const tried={};let busy=false;
  const R5=[['snail','🐌','A snail would take nearly 100 years to go round the Earth!',3200,.15],['car','🚗','A car would take about 17 days, driving day and night without stopping!',3000,1],['plane','✈️','A plane would take about 2 days!',2400,1],['rocket','🛰️','The space station goes round the Earth in about an hour and a half!',1600,1],['light','💡','Light goes round the Earth about seven times in ONE second!',1000,7]];
  const row=place(el('div','xrow',''),0,640,1024);R5.forEach(q=>{row.appendChild(bigBtn(q[1],'white',()=>{if(busy)return;busy=true;tried[q[0]]=1;runner.textContent=q[1];sfx.boop();const t0=performance.now(),dur=q[3],laps=q[4];
    const step=now=>{const k=Math.min(1,(now-t0)/dur),a=-Math.PI/2+k*laps*Math.PI*2;runner.style.left=(512+Math.cos(a)*190-35)+'px';runner.style.top=(330+Math.sin(a)*190-35)+'px';if(k<1)requestAnimationFrame(step);else{busy=false;tag.textContent=q[2];say(q[2]);
      if(tried.light&&Object.keys(tried).length>=3&&!row.dataset.q){row.dataset.q=1;setTimeout(()=>{row.remove();tag.textContent='';say('Which is the fastest thing of all?');choiceRow(st,[['rocket','🛰️ The space station'],['light','💡 Light'],['plane','✈️ The plane']],'light',()=>{say('Light! Albert Einstein worked out that nothing can go faster than light.');setTimeout(()=>sciDone(p),4400);},630);},3600);}
      else if(!tried.light)setTimeout(()=>say('Try another racer! Have you tried the light?'),2600);}};requestAnimationFrame(step);}));});st.appendChild(row);
  say('Race round the Earth! Pick a racer and see how long it takes. Try at least three, including the light!');};
XP.code=(st,p)=>{const LV=[{s:[0,4],g:[3,4],rocks:[]},{s:[0,4],g:[2,1],rocks:[[1,4],[1,3]]},{s:[0,0],g:[4,4],rocks:[[1,1],[2,2],[3,3],[1,3]]},{s:[2,4],g:[2,0],rocks:[[2,2],[1,2],[3,2]]}];let lv=0,prog=[],busy=false;
  $('#sciBg').innerHTML=towerBgSVG();const grid=place(el('div','xgrid',''),337,130,350,350);st.appendChild(grid);const strip=place(el('div','xstrip',''),162,500,700,70);st.appendChild(strip);
  const draw=(pos)=>{const L=LV[lv];let h='';for(let y=0;y<5;y++)for(let x=0;x<5;x++){const r=L.rocks.some(q=>q[0]===x&&q[1]===y),g=L.g[0]===x&&L.g[1]===y,me=pos[0]===x&&pos[1]===y;h+=`<div class="xcell">${me?'🤖':g?'🦴':r?'🪨':''}</div>`;}grid.innerHTML=h;strip.innerHTML=prog.map(d=>`<span>${d}</span>`).join('')||'<em>Tap the arrows to write your code</em>';};
  const DIR={'⬆️':[0,-1],'⬇️':[0,1],'⬅️':[-1,0],'➡️':[1,0]};const row=place(el('div','xrow',''),0,610,1024);
  Object.keys(DIR).forEach(d=>row.appendChild(bigBtn(d,'white',()=>{if(busy||prog.length>=10)return;prog.push(d);sfx.boop();draw(LV[lv].s);})));
  row.appendChild(bigBtn('⌫','white',()=>{if(busy)return;prog.pop();draw(LV[lv].s);}));row.appendChild(bigBtn('▶ Go','green',()=>{if(busy||!prog.length)return;busy=true;let pos=LV[lv].s.slice(),i=0;
    const step=()=>{if(i>=prog.length){busy=false;const g=LV[lv].g;if(pos[0]===g[0]&&pos[1]===g[1])win();else{sfx.oops();say('The robot stopped before the bone. Add some more steps and try again!');prog=[];draw(LV[lv].s);}return;}
      const d=DIR[prog[i]],nx=pos[0]+d[0],ny=pos[1]+d[1];if(nx<0||ny<0||nx>4||ny>4||LV[lv].rocks.some(q=>q[0]===nx&&q[1]===ny)){sfx.oops();busy=false;say('Bump! Something is in the way. Change your code and try again!');prog=[];setTimeout(()=>draw(LV[lv].s),700);return;}
      pos=[nx,ny];i++;sfx.pop();draw(pos);setTimeout(step,420);};step();}));st.appendChild(row);
  const win=()=>{sfx.chime();lv++;prog=[];if(lv>=LV.length){say('You are a coder! Ada Lovelace wrote step-by-step instructions for a machine, just like you did for the robot pup.');setTimeout(()=>sciDone(p),4600);return;}say(`The robot pup found the bone! Level ${lv+1}. Watch out for the rocks!`);draw(LV[lv].s);};
  draw(LV[0].s);say('Code a robot pup! Tap the arrows to tell the robot where to go, then press Go. Help it reach the bone!');};

/* ---- quiz-based experiments (they use the quiz screen) ---- */
const birdSVG=(b)=>{const k=INK,beak={nut:'<path d="M150 95 l55 -10 l-55 40z" fill="#5b4636"/>',insect:'<path d="M150 100 l70 4 l-70 8z" fill="#5b4636"/>',nectar:'<path d="M150 100 q60 10 90 50 q-50 -30 -90 -38z" fill="#5b4636"/>',tool:'<path d="M150 98 l45 4 l-45 14z" fill="#5b4636"/><rect x="190" y="96" width="70" height="6" fill="#9b6a43" transform="rotate(15 190 99)"/>'}[b];
  return `<svg viewBox="0 0 280 200" width="280" height="200"><ellipse cx="100" cy="130" rx="70" ry="50" fill="#9b7a5a" stroke="${k}" stroke-width="4"/><circle cx="130" cy="95" r="35" fill="#9b7a5a" stroke="${k}" stroke-width="4"/><circle cx="138" cy="88" r="6" fill="${k}"/>${beak}<path d="M40 140 l-30 30 l40 -5z" fill="#7a5a3a"/></svg>`;};
const BEAK=[['nut','big, strong beak','🌰 Seeds and nuts','crack open hard seeds'],['insect','thin, pointy beak','🐛 Little insects','pick tiny insects from leaves'],['nectar','long, curved beak','🌺 Flower nectar','reach deep into flowers'],['tool','short beak, holding a cactus spine','🪱 Grubs in wood','poke grubs out of holes with a tool']];
QUIZ.sci_beaks={k:'sci_beaks',name:'Beaks and Food',icon:'🐦',n:6,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#c9f2b0"/></svg>`,intro:'Charles Darwin noticed that birds have beaks that suit their food. Look at each beak. What does the bird eat?',
  make:i=>{const b=BEAK[[0,1,2,3,0,2][i]];return {q:`This bird has a <b>${b[1]}</b>. What does it eat?`,say:`This bird has a ${b[1]}. What does it eat?`,pic:birdSVG(b[0]),ans:b[2],opts:shuffle([b[2]].concat(shuffle(BEAK.filter(x=>x!==b).map(x=>x[2])).slice(0,2))),hintSay:`This beak is good to ${b[3]}.`};},
  block:()=>'🐦',onDone:()=>sciDone(PUPS.barkwin)};
const flowers=(pu,wh)=>`<div style="font-size:54px;letter-spacing:6px">${shuffle(Array(pu).fill('🟣').concat(Array(wh).fill('⚪'))).join('')}</div>`;
QUIZ.sci_peas={k:'sci_peas',name:'Pea Flowers',icon:'🫛',n:6,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#d9f5c2"/></svg>`,intro:'Gregor Mendel grew pea plants with purple flowers and white flowers. Let us see what he found!',
  make:i=>{const Q=[{q:'Mendel mixed a <b>purple</b> pea plant with a <b>white</b> one. All the baby plants were...',say:'Mendel mixed a purple pea plant with a white one. What colour were all the baby plants?',pic:'<div style="font-size:70px">🟣 + ⚪ = ?</div>',ans:'purple',opts:['purple','white','pink'],hintSay:'Purple was the strong colour that showed up in all the babies!'},
    {q:'Then the baby plants had babies. <b>How many purple?</b>',say:'Then those plants had babies. How many purple flowers can you count?',pic:flowers(3,1),ans:3,opts:[2,3,4]},{q:'<b>How many white?</b>',say:'How many white flowers can you count?',pic:flowers(3,1),ans:1,opts:[0,1,2]},
    {q:'A bigger patch! <b>How many purple?</b>',say:'A bigger patch! How many purple flowers?',pic:flowers(6,2),ans:6,opts:[4,6,8]},{q:'<b>How many white?</b>',say:'And how many white?',pic:flowers(6,2),ans:2,opts:[1,2,3]},
    {q:'For every <b>4</b> plants, Mendel found 3 purple. <b>How many white?</b>',say:'For every 4 plants, Mendel found 3 purple. How many white?',pic:flowers(3,1),ans:1,opts:[1,2,3],hintSay:'4 take away 3 is...'}][i];Q.opts=shuffle(Q.opts.slice());if(!Q.hintSay)Q.hintSay='Count them one at a time.';return Q;},
  block:()=>'🫛',onDone:()=>sciDone(PUPS.mendoodle)};
const thermo=(t)=>`<svg viewBox="0 0 120 300" width="120" height="300"><rect x="45" y="20" width="30" height="220" rx="15" fill="#fff" stroke="${INK}" stroke-width="5"/><circle cx="60" cy="255" r="32" fill="#e8423a" stroke="${INK}" stroke-width="5"/><rect x="52" y="${240-t*2}" width="16" height="${t*2+10}" fill="#e8423a"/><text x="90" y="245" font-size="20">0</text><text x="90" y="45" font-size="20">100</text></svg>`;
QUIZ.sci_thermo={k:'sci_thermo',name:'Hot and Cold',icon:'🌡️',n:6,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e6f4ff"/></svg>`,intro:'Anders Celsius made the temperature scale we use. Let us read the thermometer!',
  make:i=>{const Q=[{q:'Water freezes into ice at how many <b>degrees</b>?',say:'Water freezes into ice at how many degrees Celsius?',pic:thermo(0),ans:0,opts:[0,10,50],hintSay:'It is the smallest number on this thermometer!'},
    {q:'Water boils at how many <b>degrees</b>?',say:'Water boils at how many degrees Celsius?',pic:thermo(100),ans:100,opts:[20,50,100],hintSay:'It is the biggest number on this thermometer!'},
    {q:'Which is the <b>coldest</b>?',say:'Which is the coldest?',ans:'🍦',opts:['🍦','🛁','☕'],show:v=>`<span style="font-size:60px">${v}</span>`,hintSay:'Which one comes from the freezer?'},
    {q:'Which is the <b>hottest</b>?',say:'Which is the hottest?',ans:'🫖',opts:['🫖','🧃','⛄'],show:v=>`<span style="font-size:60px">${v}</span>`,hintSay:'Which one has boiling water in it?'},
    {q:'Your body is about how many <b>degrees</b>?',say:'Your body is about how many degrees Celsius?',pic:thermo(37),ans:37,opts:[0,37,100],hintSay:'Look where the red line stops!'},
    {q:'The thermometer says <b>25 degrees</b>. What is the weather like?',say:'The thermometer says 25 degrees. What is the weather like?',pic:thermo(25),ans:'☀️ Warm and sunny',opts:['☀️ Warm and sunny','❄️ Freezing','🔥 Boiling hot'],hintSay:'25 is quite low on this thermometer, but well above freezing.'}][i];Q.opts=shuffle(Q.opts.slice());return Q;},
  block:()=>'🌡️',onDone:()=>sciDone(PUPS.chillsius)};
const cloudSVG=(k)=>({cumulus:'<svg viewBox="0 0 300 180" width="300" height="180"><rect width="300" height="180" fill="#b5e2ff"/><g fill="#fff" stroke="#c9d6e6" stroke-width="3"><circle cx="100" cy="110" r="45"/><circle cx="160" cy="85" r="55"/><circle cx="215" cy="115" r="40"/><rect x="70" y="110" width="170" height="40" rx="20"/></g></svg>',
  stratus:'<svg viewBox="0 0 300 180" width="300" height="180"><rect width="300" height="180" fill="#c9d6e6"/><rect x="0" y="40" width="300" height="60" fill="#9aa6b8"/><rect x="0" y="90" width="300" height="20" fill="#aab6c4"/></svg>',
  cirrus:'<svg viewBox="0 0 300 180" width="300" height="180"><rect width="300" height="180" fill="#8fc8f0"/><g stroke="#fff" stroke-width="5" fill="none" stroke-linecap="round"><path d="M30 60 q60 -40 120 -10 q20 10 40 -10"/><path d="M90 110 q50 -30 110 -5"/><path d="M160 40 q40 -20 90 0"/></g></svg>',
  storm:'<svg viewBox="0 0 300 180" width="300" height="180"><rect width="300" height="180" fill="#8a9ac0"/><path d="M60 170 v-80 q0 -60 70 -70 q90 -5 100 60 v90z" fill="#5b6378"/><path d="M40 30 h220 v20 h-220z" fill="#5b6378"/><path d="M150 130 l-20 40 h20 l-10 30" stroke="#ffd23f" stroke-width="6" fill="none"/></svg>'})[k];
const CL=[['cumulus','Cumulus','big fluffy heaps, like cotton wool'],['stratus','Stratus','a flat grey blanket, like a layer'],['cirrus','Cirrus','thin wispy curls, very high up'],['storm','Cumulonimbus','a giant tower that brings thunderstorms']];
QUIZ.sci_clouds={k:'sci_clouds',name:'Name the Clouds',icon:'☁️',n:6,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#cfe9ff"/></svg>`,intro:'Luke Howard gave the clouds their names. Can you name them?',
  make:i=>{const c=CL[[0,1,2,3,0,2][i]];const o=shuffle(CL.map(x=>x[1])).filter(x=>x!==c[1]).slice(0,2).concat([c[1]]);return {q:`What is this cloud called?`,say:`What is this cloud called? It looks like ${c[2]}.`,pic:cloudSVG(c[0]),ans:c[1],opts:shuffle(o),hintSay:`${c[1]} clouds look like ${c[2]}.`};},
  block:()=>'☁️',onDone:()=>sciDone(PUPS.howlard)};
const pythSVG=(hl)=>{const k=INK,u=26;let s=`<svg viewBox="30 -30 330 340" width="300" height="300"><g transform="translate(150,190)">`;const sq=(x,y,n,c,on)=>{let r='';for(let i=0;i<n;i++)for(let j=0;j<n;j++)r+=`<rect x="${x+i*u}" y="${y+j*u}" width="${u}" height="${u}" fill="${c}" stroke="${k}" stroke-width="1.5" opacity="${on?1:.35}"/>`;return r;};
  s+=sq(0,0,4,'#7fc8f0',hl==='b'||hl==='all')+sq(-3*u,-3*u,3,'#8fe39a',hl==='a'||hl==='all');s+=`<path d="M0 0 L${4*u} 0 L0 ${-3*u} Z" fill="#fff6c9" stroke="${k}" stroke-width="4"/>`;
  s+=`<g transform="translate(0,${-3*u}) rotate(${Math.atan2(3,4)*180/Math.PI})">${sq(0,-5*u,5,'#ff9ecb',hl==='c'||hl==='all')}</g>`;return s+'</g></svg>';};
QUIZ.sci_pyth={k:'sci_pyth',name:'Triangle Squares',icon:'📐',n:6,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#fff6e0"/></svg>`,intro:'Pythagoras found something magic about triangles with a square corner. Let us count the squares!',
  make:i=>[{q:'How many little squares in the <b>green</b> square?',say:'How many little squares are in the green square?',pic:pythSVG('a'),ans:9,opts:[6,9,12],hintSay:'It is 3 rows of 3. 3, 6, 9.'},
    {q:'How many little squares in the <b>blue</b> square?',say:'How many little squares are in the blue square?',pic:pythSVG('b'),ans:16,opts:[12,16,20],hintSay:'It is 4 rows of 4. 4, 8, 12, 16.'},
    {q:'<b>9 + 16 = ?</b>',say:'What is 9 add 16?',pic:pythSVG('all'),ans:25,opts:[23,25,27],hintSay:'Start at 16 and count on 9.'},
    {q:'How many little squares in the big <b>pink</b> square?',say:'How many little squares are in the big pink square? It is 5 rows of 5.',pic:pythSVG('c'),ans:25,opts:[20,25,30],hintSay:'5, 10, 15, 20, 25.'},
    {q:'So green + blue = pink! How many <b>sides</b> does a triangle have?',say:'Green add blue makes pink! That is the Pythagoras rule. How many sides does a triangle have?',pic:pythSVG('all'),ans:3,opts:[3,4,5],hintSay:'Tri means three!'},
    {q:'How many <b>square corners</b> does this triangle have?',say:'How many square corners does this triangle have?',pic:pythSVG('all'),ans:1,opts:[0,1,2],hintSay:'Look for the corner that is like the corner of a book.'}][i],
  block:Q=>String(Q.ans),onDone:()=>sciDone(PUPS.pupthagoras)};
const spiralSVG=()=>{const k=INK,F=[[0,0,1],[1,0,1],[0,-2,2],[-3,-2,3],[-3,1,5],[2,-2,8]];return `<svg viewBox="-42 -30 168 108" width="420" height="270">${F.map((f,i)=>`<rect x="${f[0]*12}" y="${f[1]*12}" width="${f[2]*12}" height="${f[2]*12}" fill="${['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff'][i]}" stroke="${k}" stroke-width="2"/><text x="${f[0]*12+f[2]*6}" y="${f[1]*12+f[2]*6+5}" font-size="${8+f[2]*2}" text-anchor="middle" font-weight="900">${f[2]}</text>`).join('')}</svg>`;};
QUIZ.sci_spiral={k:'sci_spiral',name:'Number Spiral',icon:'🌻',n:6,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#fff6c9"/></svg>`,intro:'Fibonacci\'s numbers grow by adding the two numbers before. 1 and 1 make 2. 1 and 2 make 3. Can you find the next ones?',
  make:i=>{const Q=[[[1,1,2,3],5],[[1,2,3,5],8],[[2,3,5,8],13],[[3,5,8,13],21],[[5,8,13,21],34]];if(i===5)return {q:'How do you get the next number?',say:'How do you get the next Fibonacci number?',pic:spiralSVG(),ans:'➕ Add the two before',opts:shuffle(['➕ Add the two before','✖️ Double it','1️⃣ Add one']),hintSay:'5 and 8 make 13. What did we do?'};
    const q=Q[i],a=q[1],l=q[0];return {q:`<b>${l.join(', ')}, ?</b>`,say:`${l.join(', ')}. What comes next?`,pic:spiralSVG(),ans:a,opts:opts(a,[a+1,a-1,a+2,l[3]*2],3),hintSay:`Add the last two: ${l[2]} and ${l[3]}.`};},
  block:Q=>String(Q.ans),onDone:()=>sciDone(PUPS.fidonacci)};

/* ----------------- backgrounds ----------------- */
function tankSVG(){const k=INK;return `<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#f2ece2"/><rect x="262" y="120" width="500" height="420" rx="30" fill="#bfeaff" stroke="${k}" stroke-width="8"/><rect x="262" y="200" width="500" height="340" fill="#7fd3f0" opacity=".7"/><path d="M262 200 q60 -14 125 0 t125 0 t125 0 t125 0" fill="none" stroke="#fff" stroke-width="6"/></svg>`;}
function seaSVG(){let s='<svg viewBox="0 0 1024 768"><defs><linearGradient id="sg5" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#5fc4f0"/><stop offset="1" stop-color="#1a5a9a"/></linearGradient></defs><rect width="1024" height="768" fill="url(#sg5)"/>';for(let i=0;i<20;i++)s+=`<circle cx="${(i*151)%1000+10}" cy="${(i*97)%700+30}" r="${4+i%6}" fill="#fff" opacity=".3"/>`;return s+'<path d="M0 700 q120 -40 240 0 t240 0 t240 0 t300 0 V768 H0Z" fill="#e8d9a8"/></svg>';}
function labBenchSVG(){const k=INK;return `<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e6f4ff"/><rect y="520" width="1024" height="248" fill="#c9905f" stroke="${k}" stroke-width="5"/><rect y="520" width="1024" height="24" fill="#9b6a43"/></svg>`;}
function towerBgSVG(){return `<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#fff2d9"/>${Array.from({length:8},(_,i)=>`<text x="${40+i*130}" y="${80+(i%2)*640}" font-size="40" opacity=".3">⚙️</text>`).join('')}</svg>`;}

/* ----------------- quiz engine hooks for the lab ----------------- */
(function(){const base=quizTap;quizTap=function(k){const Z=QZ;if(Z&&Z.sk.onDone&&Z.Q&&Z.Q.opts[k]===Z.Q.ans&&Z.i+1>=Z.sk.n&&!Z.busy){Z.busy=true;const b=$('#qzOpts').children[k];b.classList.add('right');sfx.chime();state.stats.sums=(state.stats.sums||0)+1;Z.i++;
    say(pick(['Yes!','Correct!','Brilliant!']));setTimeout(()=>{if(QZ!==Z)return;QZ=null;Z.sk.onDone();},900);return;}base(k);};})();

/* ----------------- badges and certificates ----------------- */
MERITS.push(
  {id:'sci1',icon:'🔬',name:'Lab Assistant',how:'Find a science pup.',ok:()=>sciFound().length>=1},
  {id:'sci5',icon:'🧪',name:'Bright Spark',how:'Find 5 science pups.',ok:()=>sciFound().length>=5},
  {id:'sci10',icon:'⚛️',name:'Science Squad',how:'Find 10 science pups.',ok:()=>sciFound().length>=10},
  {id:'exp1',icon:'🥼',name:'First Experiment',how:'Do an experiment in the Science Lab.',ok:()=>Object.keys(state.lab||{}).length>=1},
  {id:'exp10',icon:'🧫',name:'Busy Scientist',how:'Do 10 different experiments.',ok:()=>Object.keys(state.lab||{}).length>=10});
CERTS.push(
  {id:'sci20',icon:'🏛️',title:'Science Hall of Fame',why:'for finding 20 science pups',ok:()=>sciFound().length>=20},
  {id:'exp20',icon:'🥼',title:'Super Scientist',why:'for doing 20 different experiments',ok:()=>Object.keys(state.lab||{}).length>=20});
Object.assign(window,{openLab,openExp,sciDone,XP,labCard});
window.SCIX={sortExp,tapExp,choiceRow,bigBtn,place,labBenchSVG,seaSVG,tankSVG};
})();
