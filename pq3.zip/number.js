/* ================================================================
   Number Kingdom: Region 4 (Spark pups), reached by the number train.
   Number Town (start) opens two paths: Times Table Towers (a number
   lock) and Skip-Count River (after 2 pups). Towers lead to the Pizza
   Bakery (a Spark pup lights the dark tunnel), the River to the Shape
   Garden (a number lock). Both lead to Number Castle (boss).
   Bonus: the Secret Library off the Towers, its lanterns lit by a Fire
   pup from Ninja Mountains, with a sparkly pup and treasure.
   The grown-ups choose which times tables Seb practises.
   ================================================================ */
(function(){
const R=seed(4242),inw=(x,z,f)=>[x*(f||.68),z*(f||.68),Math.atan2(-x,-z)];
const KG={ground:'#93d873',ground2:'#aee38d',sky:'#b5e2ff',fog:[80,240],fogC:'#dff1ff',hedgeC:'#3fae5a',biome:'kingdom'};
const NUM=['0️⃣','1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
const WORD={1:'ones',2:'twos',3:'threes',4:'fours',5:'fives',6:'sixes',7:'sevens',8:'eights',9:'nines',10:'tens',11:'elevens',12:'twelves'};
const BRIGHT=['#ff6b6b','#ffb347','#ffd23f','#8fe39a','#7fc8f0','#c9b6ff','#ff9ecb'];
function numTag(n,x,y,z,s){const l=label(String(n),s||2.4,'#ffffff');l.position.set(x,y,z);W.ag.add(l);return l;}
function pathTo(x1,z1,x2,z2,w,c){const d=Math.hypot(x2-x1,z2-z1),m=new THREE.Mesh(G.plane,M(c||'#f2e2c4'));m.scale.set(w||4,1,d);m.rotation.y=Math.atan2(x2-x1,z2-z1);m.position.set((x1+x2)/2,gy((x1+x2)/2,(z1+z2)/2)+.07,(z1+z2)/2);W.ag.add(m);
  for(let t=.06;t<1;t+=.1){const x=x1+(x2-x1)*t,z=z1+(z2-z1)*t;I('box',BRIGHT[Math.floor(t*10)%7],.7,.05,.7,x+(R()-.5)*(w||4)*.5,gy(x,z)+.1,z+(R()-.5),0,R()*3,0);}}
function blockStack(x,z,table,n){const y=gy(x,z);for(let i=0;i<n;i++){I('box',BRIGHT[i%7],1.8,1.4,1.8,x,y+.7+i*1.42,z,0,i*.15,0);numTag(table*(i+1),x,y+.75+i*1.42,z+1.05,1.6);}col(x,z,1.3);const l=label(`${table}×`,3,'#fff2b8');l.position.set(x,y+n*1.42+1.2,z);W.ag.add(l);}
function abacus(x,z,rot){const y=gy(x,z),g=grp();[-2.4,2.4].forEach(q=>mk('box','#9b6a43',.3,4.2,.3,q,2.1,0,g));mk('box','#9b6a43',5.2,.3,.3,0,4.2,0,g);mk('box','#9b6a43',5.2,.3,.3,0,.2,0,g);
  for(let r=0;r<5;r++){mk('cyl','#c9c2b8',.04,4.8,.04,0,.9+r*.75,0,g).rotation.z=Math.PI/2;for(let b=0;b<6;b++)mk('sph',BRIGHT[r],.3,.3,.3,-2+b*.4+(b>r?1.4:0),.9+r*.75,0,g);}g.rotation.y=rot||0;add(g,x,z);col(x,z,1.6);}
function clockTower(x,z){const y=gy(x,z);I('box','#fff2b8',4,14,4,x,y+7,z);I('box','#e8423a',4.6,.6,4.6,x,y+14.2,z);I('pyr','#5b8def',3.6,4,3.6,x,y+16.6,z,0,Math.PI/4,0);I('cyl','#ffffff',1.7,.2,1.7,x,y+11,z+2.05,Math.PI/2,0,0);
  for(let i=1;i<=12;i++){const a=i/12*6.283-Math.PI/2,s=label(String(i),.9,'#ffffff');s.position.set(x+Math.cos(a)*1.35,y+11-Math.sin(a)*1.35,z+2.25);W.ag.add(s);}
  const hand1=grp(),hand2=grp();mk('box','#26232e',.12,1.2,.08,0,.6,0,hand1);mk('box','#26232e',.16,.8,.08,0,.4,0,hand2);[hand1,hand2].forEach(h=>{h.position.set(x,y+11,z+2.3);W.ag.add(h);});W.ticks.push(()=>{hand1.rotation.z=-W.t*.5;hand2.rotation.z=-W.t*.04;});
  rect(x-2.2,z-2.2,x+2.2,z+2.2);camBlock(x-2,z-2,x+2,z+2);}
function boat(x,z,c){const g=grp();mk('box',c||'#e8423a',1.6,.6,3.2,0,.3,0,g);mk('cyl','#9b6a43',.06,2.6,.06,0,1.6,0,g);mk('box','#ffffff',.05,1.8,1.4,0,1.8,.5,g);const n=sprite(pick(NUM.slice(1)),.8);n.position.set(0,3.2,0);g.add(n);add(g,x,z,gy(x,z)+.1);W.ticks.push(()=>{g.rotation.z=Math.sin(W.t*1.5+x)*.06;g.position.y=gy(x,z)+.1+Math.sin(W.t*2+z)*.05;});return g;}
function owl3D(){const g=grp();mk('sph','#9b6a43',.8,1,.7,0,1.2,0,g);mk('sph','#e8c79a',.55,.7,.4,0,1.1,.4,g);mk('sph','#9b6a43',.7,.6,.6,0,2.2,0,g);[-1,1].forEach(q=>{mk('sph','#ffffff',.26,.26,.15,q*.26,2.3,.5,g);mk('sph','#26232e',.12,.12,.1,q*.26,2.3,.62,g);mk('cone','#9b6a43',.15,.35,.15,q*.38,2.75,0,g);mk('cyl','#3a3338',.3,.04,.3,q*.26,2.3,.6,g).rotation.x=Math.PI/2;});
  mk('cone','#ffb347',.1,.25,.1,0,2.1,.6,g).rotation.x=Math.PI;mk('box','#26232e',.9,.08,.9,0,2.85,0,g);mk('box','#26232e',.5,.3,.5,0,3,0,g);return g;}
function pizzaTable(x,z){const y=gy(x,z);I('cyl','#ffffff',1.4,.12,1.4,x,y+1.2,z);for(let i=0;i<8;i++)I('box',i%2?'#e8423a':'#ffffff',.6,.13,2.6,x-1.05+i*.3,y+1.21,z);I('cyl','#9b6a43',.12,1.2,.12,x,y+.6,z);I('cyl','#ffd23f',.7,.08,.7,x,y+1.32,z);for(let k=0;k<4;k++)I('cyl','#e8423a',.12,.04,.12,x+Math.cos(k*1.6)*.35,y+1.38,z+Math.sin(k*1.6)*.35);
  [-1,1].forEach(q=>{I('box','#9b6a43',.7,.7,.7,x+q*2,y+.35,z);});col(x,z,1.5);}
function sackPile(x,z){const y=gy(x,z);for(let i=0;i<4;i++)I('sph','#f2e6d8',.6,.75,.5,x+(i%2)*.9,y+.6+(i>1?.8:0),z+(i>1?.3:0));col(x,z,1);}
function stationPad(x,z){const y=gy(x,z);I('box','#c9c2b8',14,.6,4,x,y+.3,z);I('box','#ffd23f',14,.08,.4,x,y+.62,z+1.8);for(let i=0;i<4;i++)I('cyl','#5b8def',.15,3,.15,x-6+i*4,y+2,z+1.6);I('box','#e8423a',15,.4,4.4,x,y+3.6,z);
  for(let i=-30;i<=30;i+=2)I('box','#9b6a43',.4,.15,2.6,x+i,gy(x+i,z+4.5)+.08,z+4.5);[-1,1].forEach(q=>I('box','#8a8f99',62,.12,.12,x,gy(x,z+4.5)+.2,z+4.5+q*.8));
  const t=train3D();t.rotation.y=Math.PI/2;add(t,x+4,z+4.5,gy(x,z+4.5)+.1);rect(x-32,z+3,x+32,z+6);const l=label('🚂 Number train home',7);l.position.set(x,y+6,z);W.ag.add(l);rect(x-7,z-2,x+7,z+2);
  W.things.push({x,z:z-4,r:4.5,icon:'🚂',label:'Go home',act:goHome});}

/* ----------------- the 12 Spark pups ----------------- */
const P=[
 {id:'digit',name:'Digit',breed:'Dalmatian',area:'ntown',pitch:1.1,spot:{x:-22,z:14,kind:'toybox'},hint:'Look in the toy box near the houses in Number Town.',
  fact:'Dalmatians are born pure white, and their spots appear when they are a few weeks old. Can you count Digit\'s spots?',rescue:{icon:'🧸',verb:'Lift',say:'Digit is stuck under a pile of toys! Tap to lift them off!'},
  look:{fur:'#ffffff',ear:'#26232e',ears:'floppy',muzzle:'#ffffff',belly:'#ffffff',spots:true,spotC:'#26232e',tail:'thin',acc:['cap']}},
 {id:'dot',name:'Dot',breed:'Bichon Frise',area:'ntown',pitch:1.45,spot:{x:22,z:18,kind:'flowers'},tag:{x:-30,z:-16,kind:'bush'},hint:'Dot plays tag. Look in the flowers by the clock tower, then in a bush.',
  fact:'Bichon Frises have soft curly coats like a cloud, and they love to make people laugh.',rescue:{icon:'🎈',verb:'Pop',say:'Dot is tangled in balloon strings! Tap to free Dot!'},
  look:{fur:'#ffffff',ears:'floppy',fluffy:true,wool:true,muzzle:'#ffffff',belly:'#ffffff',tail:'pom',scale:.82,acc:['bow']}},
 {id:'doodle',name:'Doodle',breed:'Standard Poodle',area:'towers',pitch:1.05,spot:{x:-18,z:10,kind:'books'},hint:'Look behind the pile of books near the towers.',
  fact:'Poodles are one of the cleverest dogs in the world. They are brilliant at learning tricks!',rescue:{icon:'📚',verb:'Stack',say:'Doodle knocked over the books! Tap to stack them back up!'},
  look:{fur:'#c9a0e0',ears:'long',fluffy:true,wool:true,muzzle:'#c9a0e0',belly:'#dcc0ee',tail:'pom',acc:['flower']}},
 {id:'zero',name:'Zero',breed:'Great Dane',area:'towers',pitch:.7,spot:{x:20,z:-6,kind:'crate'},tag:{x:-24,z:-24,kind:'schoolbag'},hint:'Zero plays tag. Look in a crate by the abacus, then by a school bag.',
  fact:'Great Danes are some of the tallest dogs in the world, but they are gentle giants who love a cuddle.',rescue:{icon:'🧮',verb:'Slide',say:'Zero is stuck behind the giant abacus! Tap to slide the beads out of the way!'},
  look:{fur:'#8a96a6',ear:'#6b7686',ears:'floppy',muzzle:'#5b6676',belly:'#9aa6b6',tail:'thin',hw:56,hh:58,bw:46,acc:['scarf'],scarfC:'#ffd23f'}},
 {id:'ruler',name:'Ruler',breed:'Dachshund',area:'river',pitch:1,spot:{x:-20,z:12,kind:'log'},hint:'Look by a log near the river.',
  fact:'Dachshunds are long and low, like a sausage! Their long bodies helped them squeeze into burrows.',rescue:{icon:'📏',verb:'Measure',say:'Ruler is stuck in a log! Tap to wiggle Ruler out, one centimetre at a time!'},
  look:{fur:'#a0582a',ear:'#7a3e1a',ears:'long',muzzle:'#a0582a',belly:'#b8703e',long:true,tail:'thin',acc:['cap']}},
 {id:'paddle',name:'Paddle',breed:'Golden Retriever',area:'river',pitch:.95,spot:{x:22,z:4,kind:'bucket'},tag:{x:-12,z:-30,kind:'rockpool'},hint:'Paddle plays tag. Look by a bucket on the riverbank, then in a rock pool.',
  fact:'Golden Retrievers love swimming, and they have soft mouths so they can carry things without biting!',rescue:{icon:'🦆',verb:'Shoo',say:'A duck is sitting on Paddle\'s head! Tap to ask the duck to move!'},
  look:{fur:'#e8b45a',ear:'#d9a046',ears:'floppy',fluffy:true,muzzle:'#f2cc80',belly:'#f2cc80',tail:'plume',acc:['scarf'],scarfC:'#3d8fe0'}},
 {id:'cube',name:'Cube',breed:'Bernese Mountain Dog',area:'shapes',pitch:.8,spot:{x:-22,z:-8,kind:'bush'},hint:'Look in a bush in the Shape Garden.',
  fact:'Bernese Mountain Dogs have three colours: black, white and rusty brown. They used to pull little carts!',rescue:{icon:'🔷',verb:'Turn',say:'Cube is stuck in a hedge shaped like a box! Tap to turn the hedge round!'},
  look:{fur:'#26232e',ear:'#26232e',ears:'floppy',muzzle:'#ffffff',belly:'#ffffff',face:'#ffffff',blaze:'#ffffff',brows:'#c8642a',paw:'#c8642a',fluffy:true,tail:'plume',hw:58,hh:54,acc:['flower']}},
 {id:'prism',name:'Prism',breed:'Whippet',area:'shapes',pitch:1.15,spot:{x:18,z:16,kind:'flowers'},tag:{x:-26,z:22,kind:'toybox'},hint:'Prism plays tag. Look in the flowers by the big shapes, then in a toy box.',
  fact:'Whippets are super fast runners, and they love to curl up in a cosy bed afterwards.',rescue:{icon:'🌈',verb:'Catch',say:'Prism is chasing rainbows and is all dizzy! Tap to catch Prism!'},
  look:{fur:'#e0d0c0',ear:'#c0a890',ears:'side',muzzle:'#f2e6d8',belly:'#ffffff',tail:'thin',acc:['scarf'],scarfC:'#c9b6ff'}},
 {id:'pretzel',name:'Pretzel',breed:'Beagle',area:'bakery',pitch:1.05,spot:{x:-18,z:12,kind:'grain'},hint:'Look among the flour sacks by the bakery.',
  fact:'Beagles have one of the best noses of any dog. They can sniff out a pizza from far away!',rescue:{icon:'🍕',verb:'Wipe',say:'Pretzel has tomato sauce all over his nose! Tap to wipe it off!'},
  look:{fur:'#c8843a',ear:'#8a5a2a',ears:'floppy',muzzle:'#ffffff',belly:'#ffffff',blaze:'#ffffff',bodyPatch:'#26232e',tail:'thin',tailTip:'#ffffff',acc:['cap']}},
 {id:'pie',name:'Pie',breed:'Pembroke Welsh Corgi',area:'bakery',pitch:1.2,spot:{x:20,z:-10,kind:'crate'},tag:{x:-22,z:-22,kind:'grain'},hint:'Pie plays tag. Look in a crate by the pizza oven, then by the flour sacks.',
  fact:'Corgis have short legs and a fluffy bottom. Long ago they helped farmers move cows!',rescue:{icon:'🥧',verb:'Clean',say:'Pie is covered in flour! Tap to brush it off!'},
  look:{fur:'#e0903a',ear:'#c0702a',ears:'pointy',earBig:true,muzzle:'#ffffff',belly:'#ffffff',face:'#ffffff',faceLow:true,long:true,tail:'stub',acc:['bow']}},
 {id:'plus',name:'Plus',breed:'Pug',area:'castle',pitch:1.25,spot:{x:-22,z:4,kind:'crate'},hint:'Look in a crate in the castle courtyard.',
  fact:'Pugs have curly tails and squishy faces. A group of pugs is called a grumble!',rescue:{icon:'👑',verb:'Lift',say:'Plus is wearing a crown that is too big! Tap to lift it off!'},
  look:{fur:'#e8d0a0',ear:'#3a2a25',ears:'side',muzzle:'#3a2a25',wrinkle:true,belly:'#f2e0c0',tail:'curl',scale:.85,acc:['cap']}},
 {id:'seven',name:'Seven',breed:'Jack Russell Terrier',area:'castle',pitch:1.3,spot:{x:22,z:10,kind:'bush'},tag:{x:-16,z:26,kind:'flowers'},hint:'Seven plays tag. Look in a bush by the castle wall, then in the flowers by the moat.',
  fact:'Jack Russells are small but full of energy. They can jump five times as high as they are tall!',rescue:{icon:'🏰',verb:'Climb',say:'Seven climbed up the castle steps and is stuck! Tap to help Seven down!'},
  look:{fur:'#ffffff',ear:'#c8843a',ears:'side',muzzle:'#ffffff',belly:'#ffffff',patch:'#c8843a',tail:'stub',acc:['scarf'],scarfC:'#e8423a'}}];
const INFINITY={id:'infinity',name:'Infinity',breed:'Bedlington Terrier',area:'library',pitch:1.2,spot:{x:-10,z:-8,kind:'books'},hint:'A sparkly pup is hiding in the Secret Library.',
  fact:'Infinity is a sparkly pup! Bedlington Terriers look like little lambs but they are super speedy. You found a secret pup!',rescue:{icon:'📖',verb:'Turn',say:'Infinity is reading a book and does not want to stop! Tap to turn the pages to the end!'},
  look:{fur:'#e6e6f2',ears:'long',wool:true,fluffy:true,muzzle:'#e6e6f2',belly:'#ffffff',tail:'thin',acc:['twinkle','flower']}};
const TALLY={id:'tally',name:'Tally',breed:'Number Unicorn',uni:true,lv:1,pitch:1.2,fact:'Tally the Number Unicorn can count all the stars in the sky.',
  look:{fur:'#f4f0ff',ears:'side',earIn:'#d9c9ff',muzzle:'#ffffff',belly:'#ffffff',nose:'#a090c0',iris:'#8a6ae0',limbs:'hooves',hoofC:'#ffd23f',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','twinkle'],scale:.96}};
const OWL_SAY=['Professor Hoot says: a number lock asks three sums. Take your time!','Professor Hoot says: times tables are just counting in jumps. 3, 6, 9, 12!','Professor Hoot says: a Spark pup lights up dark tunnels. Bring one with you!','Professor Hoot says: the grown-ups can choose which times tables you practise.','Professor Hoot says: there is a Secret Library near the Times Table Towers. Its lanterns need a Fire pup from Ninja Mountains!','Professor Hoot says: Tally the Number Unicorn lives in Number Castle.'];

/* ----------------- areas ----------------- */
const KA=o=>Object.assign({},KG,o);
const ntown=KA({id:'ntown',name:'Number Town',icon:'🔢',R:52,start:[0,32,Math.PI],
  hf:(x,z)=>Math.sin(x*.06)*.4+Math.cos(z*.05)*.4,
  hello:'Welcome to Number Kingdom! This is Number Town, where every house has a number. Two pups are hiding here. Say hello to Professor Hoot!',how:'Take the number train from the station in the village.',
  exits:[{x:-38,z:-34,to:'towers',arrive:inw(36,36),name:'Times Table Towers',icon:'🏰',nlock:{key:'nl_towers',kind:['times','times','missing'],n:3,done:'Click! The number lock opens. Times Table Towers is this way!'}},
         {x:38,z:-34,to:'river',arrive:inw(-36,36),name:'Skip-Count River',icon:'🌊',open:()=>foundIn(areaPups('ntown'))>=2,lock:()=>{const n=foundIn(areaPups('ntown'));return `The bridge to Skip-Count River is up. Find ${2-n} more ${2-n>1?'pups':'pup'} in Number Town to lower it!`;}}],
  build(){stationPad(0,44);
    const pl=new THREE.Mesh(G.disc,M('#f2e2c4'));pl.scale.set(14,1,14);pl.position.set(0,gy(0,4)+.06,4);W.ag.add(pl);
    pathTo(0,40,0,17,4.5);pathTo(-6,-6,-34,-30,4);pathTo(6,-6,34,-30,4);
    clockTower(0,-6);{const fx=0,fz=10,y=gy(fx,fz);I('cyl','#c9c2b8',2.6,.8,2.6,fx,y+.4,fz);I('cyl','#7fd3f0',2.2,.1,2.2,fx,y+.82,fz,0,0,0,true);I('box','#ffd23f',1,1,1,fx,y+1.8,fz,0,.6,0);spr('🔢',1,fx,y+2.9,fz);col(fx,fz,2.7);}
    {const hx=-10,hz=20;for(let i=0;i<10;i++){const r=Math.floor(i/2),c=i%2,x=hx+c*1.8,z=hz-r*1.8;const m=new THREE.Mesh(G.plane,M(BRIGHT[i%7]));m.scale.set(1.6,1,1.6);m.position.set(x,gy(x,z)+.09,z);W.ag.add(m);numTag(i+1,x,gy(x,z)+.5,z,1.1);}
      sign(hx-4,hz+2,'🔢 Hopscotch',3,6);W.things.push({x:hx-3,z:hz-1,r:4,icon:'🔢',label:'Hopscotch',act:()=>{sfx.chime();startStones('activity','hopscotch');}});}
    [[-30,6,'e',1],[-34,-12,'e',2],[30,4,'w',3],[34,-14,'w',4],[-20,30,'s',5],[24,30,'s',6]].forEach((h,i)=>{const H=house(h[0],h[1],{w:7,d:6,wall:BRIGHT[(i*2)%7],roof:BRIGHT[(i*2+3)%7],face:h[2]});spr(NUM[h[3]],1.6,H.front[0],gy(h[0],h[1])+6.4,H.front[1]);});
    stall(14,16,'#5b8def',['🍎','🍐','🍊'],'w');signpost(8,-14,[['🏰 Towers ↖','#fff2b8'],['🌊 River ↗','#c9f0ff']]);[[-8,22],[8,22],[-12,-2],[12,-2]].forEach(p=>lampPost(p[0],p[1]));bunting(-12,-2,12,-2,4.5);
    {const g=owl3D();add(g,6,2);col(6,2,.9);I('cyl','#9b6a43',.25,1.4,.25,6,gy(6,2)+.7,2);g.position.y+=1.4;const l=label('🦉 Professor Hoot',4.6);l.position.set(6,gy(6,2)+5.6,2);W.ag.add(l);let k=0;
      W.ticks.push(()=>{g.rotation.y=Math.atan2(player.x-6,player.z-2);g.position.y=gy(6,2)+1.4+Math.abs(Math.sin(W.t*2))*.1;});W.things.push({x:6,z:2,r:4,icon:'💬',label:'Professor',act:()=>{sfx.chime();say(OWL_SAY[(k++)%OWL_SAY.length]);}});}
    edgeTrees(52,[angOf(-38,-34),angOf(38,-34),90],['#5fbf5a','#7fcf6a','#ffb347'],null,R);}});

const towers=KA({id:'towers',name:'Times Table Towers',icon:'🏰',R:52,start:inw(36,36),
  hf:(x,z)=>Math.sin(x*.07)*.5+Math.cos(z*.06)*.5,
  hello:'Times Table Towers! Every tower is built from a times table. Two pups are hiding here. Can you build the tallest tower?',how:'Answer the number lock in Number Town.',
  exits:[{x:36,z:36,to:'ntown',arrive:inw(-38,-34),name:'Number Town',icon:'🔢'},
         {x:0,z:-52,to:'bakery',arrive:inw(0,48),name:'Pizza Bakery',icon:'🍕',gate:{type:'spark',key:'tunnel_bakery',look:'dark',verb:'lights up the dark tunnel',done:'The tunnel lights up! The Pizza Bakery is through here. Can you smell the pizza?'},lock:'The tunnel to the Pizza Bakery is too dark. A Spark pup could light it up!'},
         {x:-52,z:0,to:'library',arrive:inw(30,0,.7),name:'Secret Library',icon:'📚',gate:{type:'fire',key:'library',look:'lanterns',need:0,verb:'lights the library lanterns',done:'The lanterns glow and the secret door swings open!'},lock:'The Secret Library door only opens when its lanterns are lit. A Fire pup from Ninja Mountains could light them!'}],
  build(){pathTo(30,30,0,0,4);pathTo(0,0,0,-44,4);pathTo(0,0,-44,0,4);
    castleTower(0,-24,4,16,'#fff2b8','#e8423a','#ffd23f');{const l=label('🏰 Times Table Tower',7);l.position.set(0,gy(0,-24)+26,-24);W.ag.add(l);}
    [[-14,-10,2,6],[14,-12,5,6],[-20,10,3,5],[22,12,10,5],[-10,26,4,4],[12,28,9,4]].forEach(b=>blockStack(b[0],b[1],b[2],b[3]));abacus(22,-2,-.6);
    {const bx=-18,bz=20;for(let i=0;i<5;i++)I('box',BRIGHT[i],1.6,.4,1.1,bx,gy(bx,bz)+.2+i*.4,bz,0,i*.2,0);}
    sign(6,4,'🏰 Times Tower',3,6);W.things.push({x:6,z:1,r:4,icon:'✖️',label:'Times Tower',act:()=>{sfx.chime();startQuiz('activity','times');}});
    bunting(-14,-10,14,-12,7);for(let i=0;i<5;i++)lampPost(-6+((i%2)?12:0),18-i*8);
    edgeTrees(52,[angOf(36,36),270,180],['#5fbf5a','#7fcf6a'],null,R);}});

const river=KA({id:'river',name:'Skip-Count River',icon:'🌊',R:52,start:inw(-36,36),
  hf:(x,z)=>Math.sin(x*.07)*.5+Math.cos(z*.06)*.4,
  hello:'Skip-Count River! The stepping stones have numbers on them. Two pups are hiding by the water.',how:'Find 2 pups in Number Town to lower the bridge.',
  exits:[{x:-36,z:36,to:'ntown',arrive:inw(38,-34),name:'Number Town',icon:'🔢'},
         {x:0,z:-52,to:'shapes',arrive:inw(0,48),name:'Shape Garden',icon:'🔷',nlock:{key:'nl_shapes',kind:['share','half','double'],n:3,done:'Click! The number lock opens. The Shape Garden is this way!'}}],
  build(){const W1=[[-56,-6],[-30,-12],[-8,-4],[14,-14],[34,-6],[58,-12]];
    for(let i=0;i<W1.length-1;i++){const a=W1[i],b=W1[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#5fc4f0'}));m.scale.set(8,1,d+2);m.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);m.position.set((a[0]+b[0])/2,gy((a[0]+b[0])/2,(a[1]+b[1])/2)+.09,(a[1]+b[1])/2);W.ag.add(m);W.disp.push(m.material);
      for(let t=0;t<1;t+=.25){const x=a[0]+(b[0]-a[0])*t,z=a[1]+(b[1]-a[1])*t;if(Math.abs(x)>6)col(x,z,3.6);I('box','#ffffff',1,.02,.12,x+(R()-.5)*4,gy(x,z)+.12,z+(R()-.5)*3,0,R()*3,0,true);}}
    for(let i=0;i<5;i++){const x=-4+i*2,z=-8+(i%2)*1.2-i*.6;I('cyl','#b7bcc9',1,.4,1,x,gy(x,z)+.2,z);numTag((i+1)*3,x,gy(x,z)+1,z,1.2);}
    {const bx=0,bz=-6;for(let i=0;i<12;i++)I('box','#c9905f',4,.25,.9,bx,gy(bx,bz)+.45,bz-5+i*.9);[-2,2].forEach(q=>{for(let i=0;i<12;i++)I('cyl','#9b6a43',.08,1,.08,bx+q,gy(bx,bz)+.9,bz-5+i*.9);I('box','#9b6a43',.12,.12,11,bx+q,gy(bx,bz)+1.4,bz);});}
    boat(-24,-11,'#e8423a');boat(22,-12,'#3d8fe0');boat(40,-8,'#ffd23f');
    const ducks=[0,1,2].map(()=>{const s=sprite('🦆',.9);W.ag.add(s);return s;});W.ticks.push(()=>ducks.forEach((s,i)=>{const t=W.t*.15+i*.3,x=-40+((t*30)%80),z=-8+Math.sin(t*4)*2;s.position.set(x,gy(x,z)+.4,z);}));
    for(let i=0;i<30;i++){const x=-50+R()*100,z=(R()<.5?-17:1)+R()*3;if(Math.abs(x)<5)continue;I('cylL','#6aae3a',.08,1.6,.08,x,gy(x,z)+.8,z);I('cylL','#8a5a2a',.14,.5,.14,x,gy(x,z)+1.7,z);}
    sign(10,8,'🌊 Skip-Count Steps',3,7);W.things.push({x:10,z:5,r:4,icon:'🌊',label:'Skip-Count',act:()=>{sfx.chime();startStones('activity','skipriver');}});
    [[-26,20],[26,22],[-30,-30],[28,-32]].forEach(p=>tree(p[0],p[1],1.1,'#5fbf5a'));picnic(-14,22);bench(18,18,'n');
    edgeTrees(52,[angOf(-36,36),270],['#5fbf5a','#7fcf6a'],null,R);}});

const shapes=KA({id:'shapes',name:'Shape Garden',icon:'🔷',R:50,start:inw(0,48),
  hf:(x,z)=>Math.sin(x*.08)*.4+Math.cos(z*.07)*.4,
  hello:'The Shape Garden! The hedges are cut into shapes. Can you name them all? Two pups are hiding here.',how:'Answer the number lock at Skip-Count River.',
  exits:[{x:0,z:50,to:'river',arrive:inw(0,-52),name:'Skip-Count River',icon:'🌊'},
         {x:-36,z:-34,to:'castle',arrive:inw(38,30),name:'Number Castle',icon:'👑',nlock:{key:'nl_castle',kind:['missing','times','add'],n:3,done:'Click! The castle gate opens. Number Castle is this way!'}}],
  build(){pathTo(0,46,0,0,4,'#e8dcc8');pathTo(0,0,-30,-28,4,'#e8dcc8');
    [['box','Cube',-14,-14,'#ff6b6b'],['sph','Sphere',0,-20,'#ffd23f'],['cone','Cone',14,-14,'#7fc8f0'],['pyr','Pyramid',20,2,'#8fe39a'],['cyl','Cylinder',-20,2,'#c9b6ff'],['tor','Torus',14,22,'#ff9ecb']].forEach(q=>{const y=gy(q[2],q[3]);
      I('box','#c9c2b8',3.4,.8,3.4,q[2],y+.4,q[3]);const s=q[0]==='tor'?1.3:2.2;I(q[0],q[4],s,q[0]==='cone'||q[0]==='pyr'?3.4:q[0]==='cyl'?3:s,s,q[2],y+(q[0]==='tor'?2.6:q[0]==='cone'||q[0]==='pyr'?2.5:q[0]==='cyl'?2.3:2.6),q[3],q[0]==='tor'?Math.PI/2:0,q[0]==='pyr'?Math.PI/4:0,0);
      const l=label(q[1],3,'#ffffff');l.position.set(q[2],y+5.4,q[3]);W.ag.add(l);col(q[2],q[3],1.9);});
    [[-30,18],[30,-20],[-34,-4],[34,10]].forEach((p,i)=>{const y=gy(p[0],p[1]);if(i%2){I('box','#3f9e46',2.4,2.4,2.4,p[0],y+1.2,p[1]);I('sph','#4fae4a',1.3,1.3,1.3,p[0],y+3.4,p[1]);}else{I('cone','#3f9e46',1.8,4,1.8,p[0],y+2,p[1]);}col(p[0],p[1],1.6);});
    [[3,-6,-2],[4,6,-4],[5,-8,12],[6,8,10],[8,-26,-14]].forEach(q=>{const sides=q[0],cx=q[1],cz=q[2],r=2.2;for(let i=0;i<sides;i++){const a1=i/sides*6.283,a2=(i+1)/sides*6.283,x1=cx+Math.cos(a1)*r,z1=cz+Math.sin(a1)*r,x2=cx+Math.cos(a2)*r,z2=cz+Math.sin(a2)*r,d=Math.hypot(x2-x1,z2-z1);I('box','#3f9e46',d,.6,.4,(x1+x2)/2,gy(cx,cz)+.3,(z1+z2)/2,0,-Math.atan2(z2-z1,x2-x1),0);}
      flowerPatch(cx,cz,8,r*.7,[BRIGHT[sides%7]],R);col(cx,cz,r);});
    sign(6,30,'🔷 Shape Quiz',3,6);W.things.push({x:6,z:27,r:4,icon:'🔷',label:'Shape Quiz',act:()=>{sfx.chime();startQuiz('activity','shapes');}});
    edgeTrees(52,[90,angOf(-36,-34)],['#5fbf5a','#7fcf6a','#ff9ecb'],null,R);}});

const bakery=KA({id:'bakery',name:'Pizza Bakery',icon:'🍕',R:50,start:inw(0,48),
  hf:(x,z)=>Math.sin(x*.08)*.4+Math.cos(z*.07)*.4,
  hello:'The Pizza Bakery! Mmm, it smells of pizza. Chef Crust cuts pizzas into halves and quarters. Two pups are hiding here.',how:'A Spark pup lights up the dark tunnel at Times Table Towers.',
  exits:[{x:0,z:50,to:'towers',arrive:inw(0,-52),name:'Times Table Towers',icon:'🏰'},
         {x:36,z:-34,to:'castle',arrive:inw(-38,30),name:'Number Castle',icon:'👑',open:()=>foundIn(areaPups('bakery'))>=2,lock:()=>{const n=foundIn(areaPups('bakery'));return `The castle gate is shut. Find ${2-n} more ${2-n>1?'pups':'pup'} in the Pizza Bakery and the guards will open it!`;}}],
  build(){pathTo(0,46,0,0,4,'#e8dcc8');pathTo(0,0,30,-28,4,'#e8dcc8');
    {const H=house(0,-18,{w:14,d:9,h:5,wall:'#fff2b8',roof:'#e8423a',trim:'#ffffff',win:3,label:'🍕 Pizza Bakery',lw:7});for(let i=0;i<9;i++)I('box',i%2?'#ffffff':'#3fae5a',1.5,.12,2,-6+i*1.5,H.y+4.2,-13.1,-.45,0,0);
      let st=0;W.ticks.push(dt=>{st-=dt;if(st<0){st=.8;floatS('💨',4.5,H.y+10,-20,1.6,2.2);}});}
    {const ox=-14,oz=-6,y=gy(ox,oz);I('hemi','#c26a32',2.6,2.4,2.6,ox,y+1,oz);I('box','#c9c2b8',5.6,1,5.6,ox,y+.5,oz);I('box','#26232e',1.4,1,.2,ox,y+1.8,oz+2.5);I('sph','#ff8a3c',.7,.5,.4,ox,y+1.7,oz+2.4,0,0,0,true);I('cyl','#8a8f99',.4,2,.4,ox,y+4,oz-1);col(ox,oz,3);spr('🔥',.9,ox,y+1.9,oz+2.6);}
    [[-8,12],[8,12],[0,22],[14,4]].forEach(p=>pizzaTable(p[0],p[1]));[[-18,12],[-22,-22],[22,-8]].forEach(p=>sackPile(p[0]+3,p[1]+3));stall(16,-6,'#e8423a',['🍕','🥖','🧁'],'w');
    {const g=pup3D({id:'crust',name:'Chef Crust',look:{fur:'#ffffff',ear:'#c8843a',ears:'floppy',muzzle:'#ffffff',belly:'#ffffff',patch:'#c8843a',tail:'wag'},dressAs:'chef'},false);add(g,4,-6);g.rotation.y=.3;col(4,-6,1);const l=label('👨‍🍳 Chef Crust',4.5);l.position.set(4,gy(4,-6)+4,-6);W.ag.add(l);
      sign(-4,-4,'🍕 Pizza Maths',3,6);W.things.push({x:2,z:-3,r:4,icon:'🍕',label:'Pizza Maths',act:()=>{sfx.chime();startQuiz('activity','pizza');}});}
    edgeTrees(50,[90,angOf(36,-34)],['#5fbf5a','#7fcf6a'],null,R);}});

const castle=KA({id:'castle',name:'Number Castle',icon:'👑',R:52,start:inw(-38,30),
  hf:(x,z)=>Math.sin(x*.06)*.4+Math.cos(z*.06)*.4,
  hello:'Number Castle! Tally the Number Unicorn lives here. Two pups are hiding in the courtyard, and the crown jewels are scattered everywhere!',how:'Find 2 pups in the Pizza Bakery, or answer the number lock in the Shape Garden.',
  exits:[{x:-38,z:30,to:'bakery',arrive:inw(36,-34),name:'Pizza Bakery',icon:'🍕'},{x:38,z:30,to:'shapes',arrive:inw(-36,-34),name:'Shape Garden',icon:'🔷'}],
  build(){const cz=-32,wc='#e6dccf';
    I('box',wc,40,9,3,0,gy(0,cz)+4.5,cz-6);for(let i=0;i<14;i++)I('box',wc,1.4,1.2,3,-19+i*2.9,gy(0,cz)+9.6,cz-6);rect(-21,cz-8,21,cz-4);camBlock(-21,cz-8,21,cz-4);
    [[-20,cz-6],[20,cz-6],[-20,cz+8],[20,cz+8]].forEach(p=>castleTower(p[0],p[1],3,12,wc,'#5b8def','#e8423a'));
    [-1,1].forEach(q=>{I('box',wc,3,8,14,q*20,gy(q*20,cz)+4,cz+1);rect(q*20-1.6,cz-6,q*20+1.6,cz+8);});
    castleTower(0,cz-2,5,18,'#f2ece2','#e8423a','#ffd23f');I('box','#5b4636',3.4,4.6,.4,0,gy(0,cz)+2.3,cz+3);I('cyl','#5b4636',1.7,.4,1.7,0,gy(0,cz)+4.6,cz+3,Math.PI/2,0,0);
    {const l=label('👑 Number Castle',8);l.position.set(0,gy(0,cz)+30,cz);W.ag.add(l);}
    [-10,10].forEach(x=>{for(let i=0;i<5;i++){const y=gy(x,cz+8);I('cyl','#9b6a43',.1,3,.1,x-2+i,y+1.5,cz+10);}});
    bunting(-20,cz+8,20,cz+8,7);[[-12,8],[12,8],[-12,20],[12,20]].forEach(p=>lampPost(p[0],p[1]));
    {const mz=cz+12,m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#5fc4f0'}));m.scale.set(40,1,3.4);m.position.set(0,gy(0,mz)+.1,mz);W.ag.add(m);W.disp.push(m.material);rect(-20,mz-1.7,-2.6,mz+1.7);rect(2.6,mz-1.7,20,mz+1.7);
      for(let i=0;i<8;i++)I('box','#9b6a43',5,.3,.5,0,gy(0,mz)+.35,mz-1.9+i*.55);[-2.5,2.5].forEach(q=>{I('cyl','#5b4636',.15,2,.15,q,gy(q,mz)+1,mz-2);I('cyl','#26232e',.04,4,.04,q,gy(q,mz)+3,mz-4.5,.6,0,0);});for(let i=0;i<10;i++)I('box','#ffffff',.6,.02,.1,-18+i*4,gy(0,mz)+.14,mz+(i%2?.6:-.6),0,0,0,true);}
    [[-8,4],[8,4]].forEach(p=>{const y=gy(p[0],p[1]);I('box','#ffd23f',1.6,1,1.6,p[0],y+.5,p[1]);I('sph','#ffffff',.9,1,.9,p[0],y+1.8,p[1]);I('cone','#ffd23f',.2,1,.2,p[0],y+2.9,p[1]);col(p[0],p[1],1);});
    sign(-6,24,'💎 Crown Jewels',3,6);W.things.push({x:-6,z:21,r:4,icon:'💎',label:'Crown Jewels',act:()=>{sfx.chime();startCollect('jewels');}});
    edgeTrees(52,[angOf(-38,30),angOf(38,30)],['#5fbf5a','#7fcf6a'],null,R);}});

const library={id:'library',name:'Secret Library',icon:'📚',R:32,ground:'#c9905f',ground2:'#b8804f',sky:'#3a2a20',fog:[30,110],fogC:'#5b4030',hedgeC:'#7a4f2a',noEnrich:true,start:inw(30,0,.7),
  hf:()=>0,hello:'The Secret Library! Books about numbers, from the floor to the ceiling. A secret sparkly pup and a treasure chest are hidden here!',how:'A Fire pup lights the lanterns at Times Table Towers.',
  exits:[{x:32,z:0,to:'towers',arrive:inw(-52,0,.85),name:'Times Table Towers',icon:'🏰'}],
  build(){const dome=new THREE.Mesh(G.hemi,new THREE.MeshLambertMaterial({color:'#7a5a40',side:THREE.BackSide}));dome.scale.set(36,18,36);W.ag.add(dome);W.disp.push(dome.material);
    for(let i=0;i<14;i++){const a=i/14*6.283+.2;if(Math.abs(Math.cos(a)-1)<.15)continue;const x=Math.cos(a)*28,z=Math.sin(a)*28;I('box','#7a4f2a',6,8,1.4,x,4,z,0,-a+Math.PI/2,0);
      for(let r=0;r<4;r++)for(let b=0;b<8;b++)I('box',BRIGHT[(b+r+i)%7],.5,1.3,.9,x+Math.cos(a+Math.PI/2)*(-2.6+b*.7),1+r*1.9,z+Math.sin(a+Math.PI/2)*(-2.6+b*.7),0,-a+Math.PI/2,0);col(x,z,3.2);}
    const rug=new THREE.Mesh(G.disc,M('#c9342a'));rug.scale.set(9,1,9);rug.position.y=.05;W.ag.add(rug);
    {I('cyl','#9b6a43',.3,1.2,.3,6,.6,8);I('sph','#5fc4f0',1,1,1,6,2,8);I('sph','#8fe39a',.5,.5,.5,6.3,2.3,8.6);col(6,8,1);}
    [[-6,10],[10,-8]].forEach(p=>{I('box','#c9342a',2,1,2,p[0],.5,p[1]);I('box','#c9342a',2,1.6,.5,p[0],1.3,p[1]-.8);col(p[0],p[1],1.3);I('cyl','#ffd23f',.1,3,.1,p[0]+1.6,1.5,p[1]);I('cone','#fff6c9',.6,.6,.6,p[0]+1.6,3.2,p[1],0,0,0,true);});
    for(let i=0;i<16;i++){const s=label(String(rint(1,99)),1.4,'#fff6c9');s.position.set(-14+R()*28,4+R()*8,-14+R()*28);W.ag.add(s);const o=s.position.y,ph=R()*6;W.ticks.push(()=>{s.position.y=o+Math.sin(W.t+ph)*.4;});}
    treasureChest(-4,-16,'library');}};

/* ----------------- activities ----------------- */
const towerSVG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#b5e2ff"/><rect y="600" width="1024" height="168" fill="#93d873"/>`;for(let i=0;i<6;i++)s+=`<rect x="${40+i*170}" y="${300-((i*37)%120)}" width="70" height="${300+((i*37)%120)}" fill="${BRIGHT[i]}" opacity=".35"/>`;return s+'</svg>';};
const gardenSVG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#c9f2b0"/>`;for(let i=0;i<16;i++)s+=`<g opacity=".25">${shapeSVG([3,4,5,6,8,0][i%6],BRIGHT[i%7],90).replace('<svg ',`<svg x="${(i*233)%960}" y="${(i*157)%700}" `)}</g>`;return s+'</svg>';};
const bakerySVG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#fff2d9"/>`;for(let i=0;i<16;i++)for(let j=0;j<12;j++)if((i+j)%2)s+=`<rect x="${i*64}" y="${j*64}" width="64" height="64" fill="#ffe0e0" opacity=".6"/>`;return s+'</svg>';};
const riverSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#5fc4f0"/><rect width="1024" height="150" fill="#93d873"/>`;for(let i=0;i<24;i++)s+=`<path d="M${(i*157)%980} ${200+(i*73)%540} q20 -10 40 0" stroke="#fff" stroke-width="4" fill="none" opacity=".6"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#93d873" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#93d873" stroke="${k}" stroke-width="5"/>`;return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🦄</text></svg>`;};
const townSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#f2e2c4"/><rect width="1024" height="150" fill="#b5e2ff"/>`;for(let i=0;i<8;i++)s+=`<rect x="${i*130}" y="40" width="110" height="110" fill="${BRIGHT[i%7]}" stroke="${k}" stroke-width="4"/><text x="${i*130+55}" y="120" font-size="60" font-weight="900" text-anchor="middle" fill="#fff">${i+1}</text>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#e0cfae" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#e0cfae" stroke="${k}" stroke-width="5"/>`;return s+`<text x="964" y="140" font-size="40" text-anchor="middle">🏁</text></svg>`;};
COUNTS.hopscotch={k:'hopscotch',icon:'🔢',get rounds(){const T=tablesOn(),r=T.slice(0,3).map(t=>({step:t,word:WORD[t]||t+'s'}));[2,5,10].forEach(t=>{if(r.length<3&&!r.some(q=>q.step===t))r.push({step:t,word:WORD[t]});});return r;},
  bg:townSVG,cls:'stone',intro:'Times table hopscotch! Hop along the squares, counting in your times tables.',title:'Hopscotch champion!'};
COUNTS.skipriver={k:'skipriver',icon:'🌊',rounds:[{step:3,word:'threes'},{start:20,step:-2,word:'twos, going backwards'},{step:11,word:'elevens'}],bg:riverSVG,cls:'stone',intro:'Help your pup hop across Skip-Count River on the numbered stones!',title:'You skip-counted across the river!'};
QUIZ.times={k:'times',name:'Times Table Towers',icon:'🏰',n:10,bg:towerSVG,introMs:3200,get intro(){const T=tablesOn();return `Build a times table tower! Every right answer adds a block. Today's tables: ${T.join(', ')}.`;},
  make:i=>{const q=makeQ(i%4===3?'missing':'times',4);return Object.assign(q,{q:`<b>${q.q}</b>`});},block:(Q)=>String(Q.ans),title:'Your times table tower reaches the clouds!'};
QUIZ.shapes={k:'shapes',name:'Shape Quiz',icon:'🔷',n:8,bg:gardenSVG,intro:'Shape Quiz! How well do you know your shapes?',
  make:i=>{const S=pick(SHAPES.filter(s=>s.s>0)),col=pick(BRIGHT);
    if(i%2===0){const ans=S.s;return {q:`How many sides does a <b>${S.n}</b> have?`,say:`How many sides does a ${S.n} have?`,pic:shapeSVG(S.s,col,180),ans,opts:opts(ans,[3,4,5,6,8,0],4),hint:shapeSVG(S.s,col,180),hintSay:'Count the straight sides, one at a time, going round the shape.'};}
    const ans=S.s;return {q:`Which shape has <b>${S.s} sides</b>?`,say:`Which shape has ${S.s} sides? It is called a ${S.n}.`,ans,opts:opts(ans,[3,4,5,6,8,0],4),show:v=>shapeSVG(v,col,90),hintSay:`Count the sides on each shape. You need ${S.s}.`};},
  block:Q=>'🔷',title:'You are a shape expert!'};
QUIZ.pizza={k:'pizza',name:'Pizza Maths',icon:'🍕',n:8,bg:bakerySVG,intro:'Pizza Maths with Chef Crust! Help share out the pizzas fairly.',
  make:i=>{const k=i%3;
    if(k===0){const sl=pick([4,6,8,10,12]),ans=sl/2;return {q:`This pizza has <b>${sl} slices</b>. How many slices is <b>half</b>?`,say:`This pizza has ${sl} slices. How many slices is half?`,pic:pizzaSVG(sl,0),after:pizzaSVG(sl,ans),ans,opts:opts(ans,[ans+1,ans-1,sl,ans+2],3),hintSay:`Half means two equal parts. Split ${sl} into two.`};}
    if(k===1){const sl=pick([4,8,12]),ans=sl/4;return {q:`This pizza has <b>${sl} slices</b>. How many slices is <b>a quarter</b>?`,say:`This pizza has ${sl} slices. How many slices is a quarter?`,pic:pizzaSVG(sl,0),after:pizzaSVG(sl,ans),ans,opts:opts(ans,[ans+1,ans-1,sl/2,ans+2],3),hintSay:`A quarter means four equal parts. Split ${sl} into four.`};}
    const pups=pick([2,3,4]),each=rint(1,3),sl=pups*each;return {q:`<b>${pups} pups</b> share a pizza with <b>${sl} slices</b>. How many each?`,say:`${pups} pups share a pizza with ${sl} slices. How many slices does each pup get?`,pic:pizzaSVG(sl,0)+'<div style="font-size:40px">'+'🐶'.repeat(pups)+'</div>',ans:each,opts:opts(each,[each+1,each-1,each+2,pups],3),hintSay:`Give each pup one slice at a time until all ${sl} are gone.`};},
  block:()=>'🍕',title:'Every pup got a fair share of pizza!'};
COLLECT.jewels={k:'jewels',area:'castle',icon:'💎',size:2,items:[[-24,-4],[24,-6],[-14,14],[16,18],[0,30],[-30,14]],start:[-6,22,Math.PI],thing:'crown jewel',art:'💎',
  intro:'Crown Jewels! Muddle dropped 6 of the crown jewels round the castle. Collect them all!',title:'You found all the crown jewels!'};
regAct('hopscotch',{name:'Times Table Hopscotch',icon:'🔢',island:'number',area:'ntown',where:'Number Town',play:()=>startStones('arcade','hopscotch')});
regAct('times',{name:'Times Tower',icon:'✖️',island:'number',area:'towers',where:'Times Table Towers',play:()=>startQuiz('arcade','times')});
regAct('skipriver',{name:'Skip-Count Steps',icon:'🌊',island:'number',area:'river',where:'Skip-Count River',play:()=>startStones('arcade','skipriver')});
regAct('shapes',{name:'Shape Quiz',icon:'🔷',island:'number',area:'shapes',where:'the Shape Garden',play:()=>startQuiz('arcade','shapes')});
regAct('pizza',{name:'Pizza Maths',icon:'🍕',island:'number',area:'bakery',where:'the Pizza Bakery',play:()=>startQuiz('arcade','pizza')});
regAct('jewels',{name:'Crown Jewels',icon:'💎',island:'number',area:'castle',where:'Number Castle',play:()=>arcadeTravel('castle',COLLECT.jewels.start,()=>startCollect('jewels'),'Crown Jewels is about to start!')});

regIsland({id:'number',name:'Number Kingdom',icon:'🔢',type:'spark',req:['snowy','reef'],rideName:'The number train',ride:'the number train',from:'train station in the village',rideIcon:'🚂',rideSay:'All aboard the number train! Choo choo!',
  homeSay:'The number train chugs back to the village!',homePos:[36,-24,Math.PI/2],
  badge:'Number Badge',cert:'Seb, Number Kingdom Hero!',bossHint:'Tally the Number Unicorn is waiting at Number Castle!',
  nextSay:'Hooray! Number Kingdom is safe! Have you been to Ninja Mountains too?',
  map:{shape:'M90 420 L120 160 L240 120 L300 60 L560 60 L620 120 L740 160 L770 420 Q600 470 430 460 Q260 470 90 420Z',
    nodes:{ntown:[430,350],towers:[230,260],river:[630,260],bakery:[200,120],shapes:[660,120],castle:[430,80],library:[95,345]},
    links:[['ntown','towers'],['ntown','river'],['towers','bakery'],['river','shapes'],['bakery','castle'],['shapes','castle'],['towers','library']]},
  boss:{area:'castle',x:0,z:-12,perch:0,uni:TALLY,
    story:[['m','Muddle the Magpie hops out from behind a tower. "Sorry, Seb! I took the shiny Number Star because it had the shiniest 7 on it. Then I mixed up all the numbers on the signs, and I scared all the pups!"'],
      ['u','Tally the Number Unicorn laughs. "Oh, Muddle! Numbers are for sharing, not hiding. Let us put every number back in order. Now give back the shiny Number Star."'],
      ['b','Muddle gives back the Number Star, and all 12 Spark pups count to 100 and cheer! Professor Hoot hoots, and Tally gives Seb the Number Badge.']],
    after:['Tally says: thank you for finding every pup in Number Kingdom!','Muddle says: 1, 2, 3, 4, 5, 6, 7! Seven is still my favourite.','Tally says: did you know 7 times 7 is 49?']},
  pups:P,bonus:[INFINITY],areas:[ntown,towers,river,shapes,bakery,castle,library]});
})();
/* ----- Release 5 badges and certificates ----- */
MERITS.push(
  {id:'ninja',icon:'🥷',name:'Ninja Hero',how:'Find all 12 pups in Ninja Mountains.',ok:()=>!!state.islDone.ninja},
  {id:'number',icon:'🔢',name:'Number Hero',how:'Find all 12 pups in Number Kingdom.',ok:()=>!!state.islDone.number},
  {id:'rope',icon:'🪢',name:'Ninja Rope',how:'Find the ninja rope at the Dojo.',ok:()=>!!state.gear.rope},
  {id:'firepower',icon:'🔥',name:'Fire Power',how:'Use a Fire pup to light lanterns or melt ice.',ok:()=>!!(state.vines.lanterns_fire||state.vines.icewall||state.vines.library)},
  {id:'sparkpower',icon:'⚡',name:'Spark Power',how:'Use a Spark pup to light up a dark place.',ok:()=>!!(state.vines.tunnel_bakery||state.vines.glowcave)},
  {id:'numlock',icon:'🔢',name:'Lock Cracker',how:'Open a number lock.',ok:()=>!!(state.vines.nl_towers||state.vines.nl_shapes||state.vines.nl_castle)},
  {id:'sums50',icon:'🧮',name:'Super Sums',how:'Answer 50 sums correctly.',ok:()=>(state.stats.sums||0)>=50},
  {id:'tower',icon:'🏰',name:'Tower Builder',how:'Build a times table tower.',ok:()=>!!(state.acts||{}).times},
  {id:'dragon',icon:'🐉',name:'Dragon Rider',how:'Climb to Dragon Peak.',ok:()=>!!state.seen.peak},
  {id:'glimmer',icon:'🍄',name:'Glow Finder',how:'Find the sparkly pup in the Glow Cave.',ok:()=>isFound('glimmer')},
  {id:'infinity',icon:'♾️',name:'To Infinity',how:'Find the sparkly pup in the Secret Library.',ok:()=>isFound('infinity')});
CERTS.push(
  {id:'ninja',icon:'🥷',title:'Ninja Mountains Hero',why:'for finding all 12 pups in Ninja Mountains',ok:()=>!!state.islDone.ninja},
  {id:'number',icon:'🔢',title:'Number Kingdom Hero',why:'for finding all 12 pups in Number Kingdom',ok:()=>!!state.islDone.number},
  {id:'tablestar',icon:'✖️',title:'Times Table Star',why:'for building 3 times table towers',ok:()=>((state.acts||{}).times||0)>=3});
