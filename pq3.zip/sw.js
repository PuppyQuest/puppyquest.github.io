/* Seb's Puppy Quest website: offline copy of Puppy Quest 3.
   Made by the site build; the version and file list change with every build, which is how the iPad notices an update.
   A new version downloads in the background and takes over once this part of the site is not open (it never mixes files of two versions). */
const V='pq3-ee8546015a72';
const FILES=["alien.js", "art.js", "audio.js", "awards.js", "base.css", "battle.js", "bhquest.js", "cardlook.js", "cards.css", "cards.js", "conga.js", "decor.js", "dino.js", "edges2.js", "engine5.js", "engine7.js", "gadget.js", "gadget2.js", "game.js", "games.js", "glow.js", "glow_cards.js", "glow_look.js", "glow_spots.js", "glow_story.js", "glow_world.js", "ground.js", "hw.js", "hw_cards.js", "hw_look.js", "hw_spots.js", "hw_story.js", "hw_world.js", "index.html", "look_gadget.js", "look_ninja.js", "look_number.js", "look_rescue.js", "looks.js", "meadow.js", "models.js", "ninja.js", "number.js", "number2.js", "planet.js", "planethop.js", "pq2cards.js", "pq2friends.js", "pq3.css", "pupstyle.js", "reef.js", "rescue.js", "sb.js", "sb_cards.js", "sb_look.js", "sb_spots.js", "sb_story.js", "sb_world.js", "science.js", "science7.js", "science8.js", "season.js", "showdown.js", "skyline.js", "snowy.js", "sp.js", "sp_cards.js", "sp_look.js", "sp_spots.js", "sp_story.js", "sp_world.js", "start.js", "three.min.js", "version.json", "village.js", "world2.js", "xmas_cards.js", "xmas_look.js", "xmas_spots.js", "xmas_story.js", "xmas_world.js"];
const ROOT=false;
const BASE=new URL('./',self.location).pathname;

self.addEventListener('install',e=>{
  e.waitUntil(caches.open(V).then(c=>Promise.all(FILES.map(f=>
    fetch(new Request(f+'?v='+V,{cache:'reload'})).then(r=>{if(!r.ok)throw new Error('Could not fetch '+f);return c.put(f,r);})))));
});

self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('pq3-')&&k!==V).map(k=>caches.delete(k))))
    .then(()=>self.clients.claim()));
});

self.addEventListener('fetch',e=>{
  const q=e.request;if(q.method!=='GET')return;
  const u=new URL(q.url);if(u.origin!==self.location.origin||!u.pathname.startsWith(BASE))return;
  let rel=decodeURIComponent(u.pathname.slice(BASE.length));if(rel===''||rel.endsWith('/'))rel+='index.html';
  if(FILES.includes(rel)){
    e.respondWith(caches.open(V).then(c=>c.match(rel)).then(r=>r||fetch(q)));
  }else if(ROOT){
    /* the front page: anything else (such as a game's version note) from the internet, or from a game's offline copy */
    e.respondWith(fetch(q).catch(()=>caches.match(u.pathname+(u.pathname.endsWith('/')?'index.html':''),{ignoreSearch:true})
      .then(r=>r||new Response('',{status:504}))));
  }
});
