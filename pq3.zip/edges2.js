/* ================================================================
   Edge check (24 Nov 2026): everywhere Seb is stopped now has
   something you can see stopping him. A gate across the end of each
   jetty, a lattice under the kite hill platform, fences by the train
   tracks, a fence round the Lily Pond, reeds and pebbles along the
   meadow stream, rims round the ice lake, the glow pool and the swamp
   ponds, rocks along the lava, a rocky rim on both sides of the
   Volcano Ridge gorge, museum ropes along the Skip-Count River, a
   kerb by the castle moat, and fences across the open views at the
   Fern Forest river and the Fossil Cliffs beach.
   ================================================================ */
(function(){
const after=(id,fn)=>{const A=AREAS[id];if(!A)return;const b=A.build;A.build=function(){const r=b.apply(this,arguments);try{fn(A);}catch(e){console.warn('edges2',id,e);}return r;};};
const inA=(x,z,m)=>Math.hypot(x,z)<W.area.R+(m||0);
/* a run of fence along a line, posts every step, rails between */
function fenceLine(x1,z1,x2,z2,o){o=o||{};const d=Math.hypot(x2-x1,z2-z1),n=Math.max(1,Math.round(d/(o.step||2))),ry=Math.atan2(x2-x1,z2-z1)+Math.PI/2,pc=o.post||'#ffffff',rc=o.rail||pc,h=o.h||1.1,y0=o.y;
  for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;if(o.keep&&!o.keep(x,z))continue;const y=y0!=null?y0:gy(x,z);
    if(o.kind==='stanchion'){I('cyl','#c9a86a',.32,.08,.32,x,y+.04,z);I('cyl','#c9a86a',.07,h,.07,x,y+h/2,z);I('sph','#c9a86a',.14,.14,.14,x,y+h+.05,z);}
    else if(o.kind==='rock'){I('sph',o.rock||'#5a4a44',.9+((i*37)%10)/14,.7+((i*53)%10)/16,.9,x,y+.25,z,0,i,0);if(o.glow&&i%3===0)I('sph',o.glow,.25,.18,.25,x+.5,y+.75,z,0,0,0,true);continue;}
    else I('box',pc,.18,h,.18,x,y+h/2,z);
    if(i===n)continue;const xn=x1+(x2-x1)*(i+1)/n,zn=z1+(z2-z1)*(i+1)/n;if(o.keep&&!o.keep(xn,zn))continue;const mx=(x+xn)/2,mz=(z+zn)/2,my=y0!=null?y0:gy(mx,mz),L=d/n;
    if(o.kind==='stanchion'){I('cyl','#c8323a',.06,L,.06,mx,my+h-.1,mz,0,ry,Math.PI/2);continue;}
    (o.rails||[.45,.85]).forEach(k=>I('box',rc,L+.1,.1,.08,mx,my+h*k,mz,0,ry,0));}}
/* a ring round a pond or pool */
function rimRing(cx,cz,r,o){const n=Math.ceil(2*Math.PI*r/(o.step||1.3)),y=o.y!=null?o.y:gy(cx,cz);
  for(let i=0;i<n;i++){const a=i/n*Math.PI*2+(o.a0||0),x=cx+Math.cos(a)*r,z=cz+Math.sin(a)*r,yy=o.y!=null?o.y:gy(x,z);
    if(o.kind==='fence'){const an=(i+1)/n*Math.PI*2+(o.a0||0),xn=cx+Math.cos(an)*r,zn=cz+Math.sin(an)*r;fenceLine(x,z,xn,zn,{post:o.post||'#9b6a43',rail:o.rail||'#b5844f',h:1,step:9,y:o.y});continue;}
    const c=o.cols[i%o.cols.length],s=o.s||1;I('sph',c,(.8+((i*37)%10)/25)*s,(.55+((i*17)%10)/30)*s,(.75)*s,x,yy+.12*s,z,0,i*1.7,0);
    if(o.extra)o.extra(x,z,yy,i,a);}}
const reed=(x,z,y,h)=>{I('cylL','#5f9a3a',.07,h,.07,x,y+h/2,z);I('cylL','#7a4f2a',.13,.45,.13,x,y+h-.1,z);};

/* ----- Pawprint Village: jetty gate, kite hill lattice, track fences ----- */
function jettyGate(zg,z0){const y=gy(0,z0)+.2+.05;[-2.5,2.5].forEach(s=>I('box','#ffffff',.22,1.4,.22,s,y+.7,zg));[.45,1.05].forEach(h=>I('box','#ffffff',5,.14,.12,0,y+h,zg));
  for(let i=-2;i<=2;i++)I('box','#ffffff',.1,.9,.08,i*.95,y+.75,zg);I('tor','#e8423a',.55,.55,.55,1.2,y+.95,zg+.12);I('box','#ffffff',.6,.18,.2,1.2,y+1.45,zg+.12);}
after('village',()=>{jettyGate(55.7,44);
  {const kx=-44,kz=-8,y=gy(kx,kz);[[0,-2.05,0],[0,2.05,0],[-2.05,0,1],[2.05,0,1]].forEach(s=>{const x=kx+s[0],z=kz+s[1],ry=s[2]?Math.PI/2:0;
    [.6,1.7,2.8].forEach(h=>I('box','#9b6a43',4.1,.22,.1,x,y+h,z,0,ry,0));[1,-1].forEach(k=>I('box','#b5844f',5.2,.16,.08,x,y+2.1,z,0,ry,k*.62));});}
  {const rz=-30,keep=(x,z)=>inA(x,z,-.5);fenceLine(30,rz-2.2,47,rz-2.2,{keep,step:2.2});fenceLine(30,rz+2.2,38.6,rz+2.2,{keep,step:2.2});fenceLine(28.6,rz-2.2,28.6,rz+2.2,{step:2.2});}});
/* ----- Meadow Island ----- */
after('windmill',()=>jettyGate(55.7,45));
function streamBank(){const z=-50.4;for(let x=-36;x<=36;x+=1.1){if(Math.abs(x)<3.8||!inA(x,z,2))continue;const k=Math.round(x/1.1),y=gy(x,z);
    if(k%2)I('sph',k%3?'#b7bcc9':'#c9cdd6',.7,.42,.6,x,y+.12,z+(k%3?.2:-.2),0,k,0);else{reed(x,z+.3,y,1.4+(k%3)*.3);reed(x+.35,z-.1,y,1.2);}}
  [-1,1].forEach(s=>{for(let i=0;i<3;i++){const x=s*(27+i*2.4),zz=-48.6-i*.9;I('sph','#5fbf5a',1.6,1.3,1.5,x,gy(x,zz)+.9,zz);}});}
after('sunflowers',streamBank);
after('pond',()=>{streamBank();rimRing(0,-4,18.9,{kind:'fence'});});
/* ----- Snowy Summit: snowbank round the ice lake ----- */
after('cave',()=>rimRing(0,6,9.7,{cols:['#ffffff','#eef6ff','#dff0ff'],step:1.2,s:1.2,extra:(x,z,y,i)=>{if(i%4===0)I('box','#cfeeff',.7,.9,.6,x,y+.45,z,.2,i,.1);}}));
/* ----- Ninja Mountains: crystals round the glow pool; rocks along the lava ----- */
after('glow',()=>rimRing(-4,8,6.5,{cols:['#4a4a66','#5a5a7a'],step:1.1,extra:(x,z,y,i)=>{if(i%3===0)I('cone',i%2?'#9bdcff':'#c9a0ff',.28,1.1,.28,x,y+.6,z,0,0,(i%5-2)*.12,true);}}));
after('firet',()=>{const rim=(x1,z1,x2,z2)=>{const k=(x,z)=>inA(x,z,-1),o={kind:'rock',step:1.5,rock:'#3a2e2c',glow:'#ff8a2a',keep:k};
    fenceLine(x1-.6,z1-.6,x2+.6,z1-.6,o);fenceLine(x2+.6,z1-.6,x2+.6,z2+.6,o);fenceLine(x2+.6,z2+.6,x1-.6,z2+.6,o);fenceLine(x1-.6,z2+.6,x1-.6,z1-.6,o);};
  rim(-30,-19,-22,11);rim(17,12.5,39,19.5);});
/* ----- Number Kingdom: museum ropes by the river and the train, a kerb by the moat ----- */
after('ntown',()=>{const z=46.3,keep=(x,z)=>inA(x,z,-1);fenceLine(-32,z,-7.6,z,{kind:'stanchion',keep,step:2.6});fenceLine(7.6,z,32,z,{kind:'stanchion',keep,step:2.6});});
after('river',()=>{const W1=[[-56,-6],[-30,-12],[-8,-4],[14,-14],[34,-6],[58,-12]];
  for(let i=0;i<W1.length-1;i++){const a=W1[i],b=W1[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),nx=-(b[1]-a[1])/d,nz=(b[0]-a[0])/d;
    [-1,1].forEach(s=>{const o=4.7*s;fenceLine(a[0]+nx*o,a[1]+nz*o,b[0]+nx*o,b[1]+nz*o,{kind:'stanchion',step:2.6,keep:(x,z)=>Math.abs(x)>4.6&&inA(x,z,-1.2)});});}});
after('castle',()=>{const mz=-20,y=gy(0,mz);[[-20.4,-3],[3,20.4]].forEach(r=>{for(let x=r[0];x<=r[1]+.01;x+=1.9){I('box','#cfc6b8',1.8,.55,.7,x,gy(x,mz+2.1)+.27,mz+2.1);I('box','#b8ae9e',1.82,.12,.72,x,gy(x,mz+2.1)+.58,mz+2.1);}});
  [-20.6,20.6].forEach(x=>{for(let z=-21.6;z<=-18.4;z+=1.6)I('box','#cfc6b8',.7,.55,1.5,x,gy(x,z)+.27,z);});});
/* ----- Dino Valley ----- */
after('ridge',()=>{[-8.1,-19.9].forEach(z=>[[-50,-3.4],[3.4,50]].forEach(r=>fenceLine(r[0],z,r[1],z,{kind:'rock',step:1.7,rock:'#3f3432',glow:'#ff7a2a',keep:(x,zz)=>inA(x,zz,-1)})));});
after('swamp',()=>{[[14,-12,10],[-20,-14,6],[-8,26,5]].forEach(p=>rimRing(p[0],p[1],p[2]+.55,{cols:['#6a7a5a','#7a8a66','#5a6a4a'],step:1.25,extra:(x,z,y,i)=>{if(i%2)reed(x,z,y,1.3+(i%3)*.4);}}));});
after('nest',()=>{const x=0,z=-26,y=gy(x,z);I('tor','#8a6a3a',2.3,2.3,2.4,x,y+.45,z,Math.PI/2,0,0);I('cyl','#a8865a',2.2,.3,2.2,x,y+.2,z);
  for(let i=0;i<6;i++){const a=i/6*6.283+.3,r=i?1.05:0,ex=x+Math.cos(a)*r,ez=z+Math.sin(a)*r;I('sph',i%2?'#f4ead0':'#e8dcb8',.55,.72,.55,ex,y+.85,ez,(i%3-1)*.15,0,(i%2-.5)*.2);if(i%2)I('sph','#c9a86a',.15,.15,.1,ex+.3,y+1,ez+.4);}
  for(let i=0;i<10;i++){const a=i/10*6.283,r=2.55;I('box','#9b7a4a',1.4,.12,.14,x+Math.cos(a)*r,y+.75+(i%2)*.18,z+Math.sin(a)*r,0,-a+.6,.3);}});
function gapFence(A,o){const R=A.R,r=R-.35,n=Math.ceil(2*Math.PI*r/1.8),pts=[];
  for(let i=0;i<=n;i++){const a=i/n*Math.PI*2,x=Math.cos(a)*r,z=Math.sin(a)*r,g=(A.edgeGaps||[]).some(q=>Math.hypot(x-q[0],z-q[1])<(q[2]||4.6)+1.5)&&!W.exits.some(e=>Math.hypot(x-e.x,z-e.z)<6);pts.push(g?[x,z]:null);}
  for(let i=0;i<pts.length-1;i++)if(pts[i]&&pts[i+1])fenceLine(pts[i][0],pts[i][1],pts[i+1][0],pts[i+1][1],o);}
after('fernforest',A=>gapFence(A,{post:'#6b4a32',rail:'#8a6440',h:1.2,step:1.8,rails:[.4,.8]}));
after('cliffs',A=>gapFence(A,{post:'#9b7a5a',rail:'#d8c8a0',h:1.1,step:1.8,rails:[.85]}));
})();
