/* ================================================================
   Island looks (22 Nov 2026). Gives Ninja Mountains, Number Kingdom,
   Gadget Island and Rescue Bay their own look: light and time of day
   per area, a night sky with a moon and stars, themed edges (cliffs,
   city blocks, dunes, cottages, museum walls), skylines, paving joints,
   the sea round the coast, and new scenery sets. Areas opt in with:
     A.light    'canyon' | 'sunset' | 'storm' | 'night' | 'city' | 'sunny' | 'museum' (or an object)
     A.edge     {style, ...}   replaces the hedge ring
     A.backdrop {style, ...}   skyline beyond the edge
     A.grid     {step,c}       paving or tile joints (flat areas)
     A.sea      {y,c}          sea all round, beyond the edge
     A.skyObj   {sun|moon|stars}
     A.noEdgeTrees, A.indoor (camera stays inside the walls)
   The island files stay as they were; look_*.js files restyle them.
   ================================================================ */
(function(){
const D2=Math.PI/180;
/* ----- light presets ----- */
const LIGHTS={
  day:{sky:'#ffffff',gr:'#a8b898',hi:.66,dir:'#ffffff',di:.45,pos:[60,90,-40]},
  canyon:{sky:'#fff1dc',gr:'#b07a5e',hi:.7,dir:'#fff0d4',di:.5,pos:[60,80,-40]},
  sunset:{sky:'#ffd6b8',gr:'#80506a',hi:.62,dir:'#ff9c60',di:.62,pos:[-90,26,-70]},
  storm:{sky:'#cdb8e6',gr:'#4a3a5c',hi:.6,dir:'#ffa07a',di:.42,pos:[-90,30,-70]},
  night:{sky:'#8090d8',gr:'#1c1c36',hi:.46,dir:'#aebcff',di:.26,pos:[-60,70,-90],lantern:1.6},
  city:{sky:'#eef3fa',gr:'#80868f',hi:.7,dir:'#ffffff',di:.42,pos:[50,90,-30]},
  sunny:{sky:'#ffffff',gr:'#dccb98',hi:.74,dir:'#fff3d6',di:.58,pos:[60,95,50]},
  museum:{sky:'#fffaf0',gr:'#ddd3c2',hi:.82,dir:'#ffffff',di:.3,pos:[20,90,10]}};
let dl=null,lamp=null;
function lights(A){if(!W.hemi)return;const L=typeof A.light==='object'?A.light:(LIGHTS[A.light]||LIGHTS.day);
  if(!dl)dl=scene.children.find(o=>o.isDirectionalLight);
  if(!lamp){lamp=new THREE.PointLight('#ffd89a',0,20,1.4);lamp.position.set(0,3.4,.8);player.grp.add(lamp);}
  W.hemi.color.set(L.sky);W.hemi.groundColor.set(L.gr);W.hemi.intensity=L.hi;
  if(dl){dl.color.set(L.dir);dl.intensity=L.di;dl.position.set(L.pos[0],L.pos[1],L.pos[2]);}
  lamp.intensity=L.lantern||0;}
/* ----- sky things: sun, moon, stars ----- */
const TEX={};
function glowTex(k,inner,outer){if(TEX[k])return TEX[k];const cv=document.createElement('canvas');cv.width=cv.height=128;const g=cv.getContext('2d'),gr=g.createRadialGradient(64,64,6,64,64,64);
  gr.addColorStop(0,inner);gr.addColorStop(.5,inner);gr.addColorStop(.62,outer);gr.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=gr;g.fillRect(0,0,128,128);return TEX[k]=new THREE.CanvasTexture(cv);}
let STARS=null;
function skyThings(A){const S=A.skyObj;if(!S)return;
  const disc=(tex,size,az,el,dist)=>{const m=new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false,fog:false}),s=new THREE.Sprite(m);s.scale.set(size,size,1);
    s.position.set(Math.cos(az*D2)*Math.cos(el*D2)*dist,Math.sin(el*D2)*dist,Math.sin(az*D2)*Math.cos(el*D2)*dist);W.ag.add(s);W.disp.push(m);return s;};
  if(S.sun)disc(glowTex('sun','#fff3b0','rgba(255,170,90,.5)'),S.sun.size||70,S.sun.az,S.sun.el,320);
  if(S.moon){disc(glowTex('moon','#f6f0d0','rgba(200,210,255,.35)'),S.moon.size||46,S.moon.az,S.moon.el,300);}
  if(S.stars){if(!STARS){const n=420,p=new Float32Array(n*3),R2=seed(4242);for(let i=0;i<n;i++){const az=R2()*6.283,el=.06+R2()*1.4,d=420;p[i*3]=Math.cos(az)*Math.cos(el)*d;p[i*3+1]=Math.sin(el)*d;p[i*3+2]=Math.sin(az)*Math.cos(el)*d;}
      const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));STARS=new THREE.Points(g,new THREE.PointsMaterial({color:'#ffffff',size:2.2,sizeAttenuation:false,fog:false}));}
    W.ag.add(STARS);}
  if(S.flies){const n=S.flies,p=new Float32Array(n*3),base=[],R2=seed(77);for(let i=0;i<n;i++){const a=R2()*6.283,r=6+R2()*(A.R-12);base.push([Math.cos(a)*r,Math.sin(a)*r,R2()*6.28]);}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));const m=new THREE.PointsMaterial({color:'#fff27a',size:.35,transparent:true,opacity:.9}),pts=new THREE.Points(g,m);W.ag.add(pts);W.disp.push(g,m);
    W.ticks.push(()=>{const t=W.t;base.forEach((b,i)=>{const x=b[0]+Math.sin(t*.4+b[2])*1.5,z=b[1]+Math.cos(t*.3+b[2])*1.5;p[i*3]=x;p[i*3+1]=gy(x,z)+1+Math.sin(t*1.3+b[2])*.6;p[i*3+2]=z;});g.attributes.position.needsUpdate=true;});}}
/* ----- small lanterns by every hiding spot in night areas ----- */
function spotLamps(A){const L=typeof A.light==='object'?A.light:LIGHTS[A.light];if(!L||!L.lantern)return;
  W.spots.forEach(s=>{const d=Math.hypot(s.x,s.z)||1,x=s.x-s.x/d*1.6+s.z/d*1.2,z=s.z-s.z/d*1.6-s.x/d*1.2,y=gy(x,z);I('cyl','#3a3338',.07,1.4,.07,x,y+.7,z);I('box','#3a3338',.42,.06,.42,x,y+1.45,z);I('box','#ffd27a',.34,.4,.34,x,y+1.68,z,0,0,0,true);I('pyr','#3a3338',.32,.24,.32,x,y+2,z,0,Math.PI/4,0);});}

/* ----- scattering helper (same rules as enrich) ----- */
function scatter(A){const B=areaBox(A),Rn=seed((A.id.charCodeAt(0)*131+A.id.length*29)|0);
  const keep=[];W.spots.forEach(s=>keep.push([s.x,s.z,3.2]));W.things.forEach(t=>keep.push([t.x,t.z,4]));W.exits.forEach(e=>keep.push([e.x,e.z,6]));if(A.start)keep.push([A.start[0],A.start[1],5]);
  const inside=(x,z,m)=>A.rect?(x>B.x1+m&&x<B.x2-m&&z>B.z1+m&&z<B.z2-m):Math.hypot(x,z)<A.R-m;
  const blocked=(x,z,r)=>{for(const c of W.cols)if(Math.hypot(x-c.x,z-c.z)<c.r+r)return true;for(const q of W.rects)if(x>q.x1-r&&x<q.x2+r&&z>q.z1-r&&z<q.z2+r)return true;for(const k of keep)if(Math.hypot(x-k[0],z-k[1])<k[2]+r)return true;if(A.keepOut&&A.keepOut(x,z))return true;return false;};
  const spot=(r,m,tries)=>{for(let t=0;t<(tries||30);t++){const x=B.x1+Rn()*(B.x2-B.x1),z=B.z1+Rn()*(B.z2-B.z1);if(inside(x,z,m||3)&&!blocked(x,z,r))return [x,z];}return null;};
  const k=Math.min(2.4,(B.x2-B.x1)*(B.z2-B.z1)/9000);return {Rn,spot,n:c=>Math.round(c*k),pk:a=>a[Math.floor(Rn()*a.length)]};}

/* ----- ring of edge points, with gaps at arches and at A.edgeGaps ----- */
function ring(A,r,step,gap){const out=[],n=Math.ceil(2*Math.PI*r/step);for(let i=0;i<n;i++){const a=i/n*Math.PI*2,x=Math.cos(a)*r,z=Math.sin(a)*r;
  if(A.hedgeSkip&&A.hedgeSkip(x,z))continue;if(W.exits.some(e=>!e.noArch&&Math.hypot(x-e.x,z-e.z)<gap))continue;if((A.edgeGaps||[]).some(g=>Math.hypot(x-g[0],z-g[1])<(g[2]||gap)))continue;out.push([x,z,a,i]);}return out;}
/* ----- edge styles ----- */
const EDGES={
  /* rock walls: two rings of slabs with strata bands */
  cliff(A,o){const C=o.c||['#b5564a','#a04a3e','#c9805a'],band=o.band||'#e0a070',h0=o.h||[6,11],R=A.R,Rn=seed(R*13+A.id.length);
    ring(A,R+2.2,2.3,4.6).forEach(p=>{const h=h0[0]+Rn()*(h0[1]-h0[0]),w=2.6+Rn()*1.4,y=gy(p[0],p[1])-.5,ry=-p[2]+Rn()*.5,c=C[p[3]%C.length],tx=(Rn()-.5)*.16,tz=(Rn()-.5)*.16;
      I('box',c,w,h,2.6,p[0],y+h/2,p[1],tx,ry,tz);I('box',band,w*1.02,.5,2.62,p[0],y+h*.62,p[1],tx,ry,tz);I('pyr',o.cap||c,w*.75,1.2+Rn()*2.4,1.9,p[0]+(Rn()-.5),y+h+.4,p[1],0,ry+Math.PI/4,0);
      if(p[3]%3===0){const x=p[0]-Math.cos(p[2])*1.8,z=p[1]-Math.sin(p[2])*1.8;I('sphL',C[(p[3]+1)%C.length],1.2+Rn()*.6,.8,1.1,x,gy(x,z)+.3,z,0,Rn()*3,0);}});
    ring(A,R+5.4,3.2,6).forEach(p=>{const h=h0[1]+2+Rn()*6,w=3.4+Rn()*1.6,y=gy(p[0],p[1])-.5,ry=-p[2]+Rn()*.4,c=C[(p[3]+2)%C.length],tx=(Rn()-.5)*.2;
      if(p[3]%3===1){I('pyr',c,w*.9,h*1.35,w*.9,p[0],y+h*.6,p[1],0,ry,0);I('pyr',band,w*.92,h*.1,w*.92,p[0],y+h*.45,p[1],0,ry,0);if(o.cap)I('pyr',o.cap,w*.3,h*.2,w*.3,p[0],y+h*1.2,p[1],0,ry,0);return;}
      I('box',c,w,h,3,p[0],y+h/2,p[1],tx,ry,0);I('box',band,w*1.02,.6,3.02,p[0],y+h*.45,p[1],tx,ry,0);I('pyr',o.cap||shade(c,.08),w*.7,1.5+Rn()*3,2.2,p[0]+(Rn()-.5),y+h+.6,p[1],0,ry+Math.PI/4,0);});},
  /* city: kerb and fence, then a ring of warehouses and blocks with windows */
  fence(A){const R=A.R;
    ring(A,R+.7,2.4,3.4).forEach(p=>{const y=gy(p[0],p[1]),ry=-p[2];I('box','#b8bcc4',2.5,.35,.5,p[0],y+.17,p[1],0,ry+Math.PI/2,0);I('cyl','#6b7078',.07,2.2,.07,p[0],y+1.1,p[1]);
      [1.2,2.1].forEach(hh=>I('box','#8a8f99',2.4,.06,.06,p[0],y+hh,p[1],0,ry+Math.PI/2,0));for(let k=-1;k<=1;k++)I('box','#a8adb5',.03,1.9,.03,p[0]-Math.sin(p[2])*k*.7,y+1.15,p[1]+Math.cos(p[2])*k*.7,0,0,0);});},
  city(A,o){const R=A.R,Rn=seed(R*17+A.id.length),PAL=o.pal||['#a0523a','#b5654a','#8a8f99','#9aa0a8','#5b6378','#c9b6a0'],H=o.h||[7,20],WIN=o.win||['#9bdcff','#ffe9a8'];EDGES.fence(A);
    ring(A,R+6.5,6.6,8).forEach(p=>{const h=H[0]+Rn()*(H[1]-H[0]),w=5.2+Rn()*1.2,d=5,c=PAL[Math.floor(Rn()*PAL.length)],y=gy(p[0],p[1])-.2,ry=-p[2]+Math.PI/2,nx=-Math.cos(p[2]),nz=-Math.sin(p[2]),tx=-Math.sin(p[2]),tz=Math.cos(p[2]);
      I('box',c,w,h,d,p[0],y+h/2,p[1],0,ry,0);I('box',shade(c,-.25),w+.2,.4,d+.2,p[0],y+h+.2,p[1],0,ry,0);
      const wc=WIN[Math.floor(Rn()*WIN.length)];for(let fy=2.4;fy<h-1;fy+=2.6)for(let k=-1;k<=1;k++){const x=p[0]+nx*(d/2+.04)+tx*k*1.6,z=p[1]+nz*(d/2+.04)+tz*k*1.6;I('box',wc,1,1.1,.08,x,y+fy,z,0,ry,0,true);}
      if(Rn()<.35){const x=p[0]+tx*1.2,z=p[1]+tz*1.2;I('cyl','#8a8f99',.8,1.6,.8,x,y+h+1.2,z);I('cone','#6b7078',.9,.6,.9,x,y+h+2.3,z);}
      if(Rn()<.3){const x=p[0]+nx*(d/2+.05),z=p[1]+nz*(d/2+.05);I('box',pick(['#3d6fb0','#e8423a','#3fae5a']),2.6,2.6,.1,x,y+1.3,z,0,ry,0);}});},
  /* quarry: grey rock walls */
  quarry(A,o){EDGES.cliff(A,{c:['#8a8378','#7a746a','#9a9488'],band:'#b0a898',h:[5,10]});},
  /* scrapyard: fence and stacks of squashed cars and tyres */
  scrap(A,o){EDGES.fence(A);const R=A.R,Rn=seed(R*19);
    ring(A,R+4.2,3.4,6).forEach(p=>{const y=gy(p[0],p[1]),ry=-p[2]+Rn()*.6;for(let k=0;k<2+Math.floor(Rn()*3);k++)I('box',pick(['#c97a3e','#7a9ab0','#a8504a','#8a8f99','#d8c070','#6b8f78']),2.4,.9,1.6,p[0]+(Rn()-.5)*.4,y+.45+k*.92,p[1]+(Rn()-.5)*.4,0,ry+(Rn()-.5)*.4,0);
      if(p[3]%2)for(let k=0;k<3;k++)I('tor','#26232e',.7,.7,.9,p[0]-Math.cos(p[2])*2.2,y+.4+k*.55,p[1]-Math.sin(p[2])*2.2,Math.PI/2,0,0);});},
  /* beach: rope fence along the top of the sand; the sand runs down to the sea */
  dunes(A,o){const R=A.R,Rn=seed(R*23);ring(A,R-.35,2.2,3.6).forEach(p=>{const y=gy(p[0],p[1]),ry=-p[2]+Math.PI/2;I('cyl','#9b7a5a',.1,1.3,.1,p[0],y+.6,p[1]);I('box','#d8c8a0',2.2,.05,.05,p[0]-Math.sin(p[2])*1.1,y+1,p[1]+Math.cos(p[2])*1.1,0,ry,.0);
      if(p[3]%2)for(let k=0;k<4;k++){const x=p[0]+Math.cos(p[2])*(1.2+Rn()*2),z=p[1]+Math.sin(p[2])*(1.2+Rn()*2);I('coneL',pick(['#b8c880','#a8b870','#c8d890']),.12,1+Rn()*.6,.12,x,gy(x,z)+.5,z,(Rn()-.5)*.5,0,(Rn()-.5)*.5);}});
    W.exits.forEach(e=>{if(e.noArch)return;const d=Math.hypot(e.x,e.z)||1,ux=e.x/d,uz=e.z/d;for(let s=1;s<14;s+=1.1){const x=e.x+ux*s,z=e.z+uz*s;I('box','#c9905f',4,.2,1,x,Math.max(gy(x,z),-.2)+.15,z,0,Math.atan2(ux,uz),0);}});},
  /* sea cliffs: rocky rim, the land drops away to the sea */
  seacliff(A,o){const R=A.R,Rn=seed(R*29);ring(A,R+1.6,2.2,4.4).forEach(p=>{const y=gy(p[0],p[1]),ry=-p[2]+Rn()*.6,h=7+Rn()*2;I('box',pick(['#8a8378','#9a9488','#7a7468']),2.6,h,2.4,p[0],y-h/2+1.2,p[1],0,ry,0);I('box','#6fa86a',2.7,.35,2.5,p[0],y+1.3,p[1],0,ry,0);});
    ring(A,R-.4,2.4,3.6).forEach(p=>{const y=gy(p[0],p[1]);I('cyl','#ffffff',.09,1.1,.09,p[0],y+.55,p[1]);I('box','#ffffff',2.4,.08,.08,p[0]-Math.sin(p[2])*1.2,y+1,p[1]+Math.cos(p[2])*1.2,0,-p[2]+Math.PI/2,0);});},
  /* seaside cottages: painted terraces with slate roofs, and a white picket fence */
  cottages(A,o){const R=A.R,Rn=seed(R*31+A.id.length),PAL=['#ff9ecb','#ffd23f','#7fc8f0','#9fe3b0','#c9b6ff','#ffffff','#ff8a6b','#f6e0a8'];
    ring(A,R-.3,1.6,3.6).forEach(p=>{const y=gy(p[0],p[1]),ry=-p[2]+Math.PI/2;I('box','#ffffff',.12,.9,.12,p[0],y+.45,p[1]);I('box','#ffffff',1.6,.1,.06,p[0]-Math.sin(p[2])*.8,y+.7,p[1]+Math.cos(p[2])*.8,0,ry,0);});
    ring(A,R+4.4,5.6,7).forEach(p=>{const w=5.3,d=5,h=4.4+Rn()*1.6,c=PAL[p[3]%PAL.length],y=gy(p[0],p[1])-.1,ry=-p[2]+Math.PI/2,nx=-Math.cos(p[2]),nz=-Math.sin(p[2]),tx=-Math.sin(p[2]),tz=Math.cos(p[2]);
      I('box',c,w,h,d,p[0],y+h/2,p[1],0,ry,0);I('pyr','#5b6378',w*.78,2.4,d*.78,p[0],y+h+1.2,p[1],0,ry+Math.PI/4,0);
      const fx=p[0]+nx*(d/2+.04),fz=p[1]+nz*(d/2+.04);I('box',pick(['#3d6fb0','#e8423a','#2f7a4a','#26232e']),1,2,.08,fx,y+1,fz,0,ry,0);
      [-1.6,1.6].forEach(k=>{const x=fx+tx*k,z=fz+tz*k;I('box','#ffffff',1.1,1.1,.07,x,y+2.6,z,0,ry,0);I('box','#9bdcff',.85,.85,.09,x,y+2.6,z,0,ry,0);if(h>5){I('box','#ffffff',1,1,.07,x,y+h-1.1,z,0,ry,0);I('box','#9bdcff',.75,.75,.09,x,y+h-1.1,z,0,ry,0);}
        I('box','#9b6a43',1.1,.3,.3,x+nx*.2,y+1.9,z+nz*.2,0,ry,0);I('sphL',pick(['#ff6b6b','#ffd23f','#ff9ecb']),.45,.2,.15,x+nx*.3,y+2.1,z+nz*.3);});
      if(p[3]%2)I('box','#b35a3a',.7,1.4,.7,p[0]+tx*1.5,y+h+1.8,p[1]+tz*1.5,0,ry,0);});},
  /* museum: a round hall of tall walls with pilasters, rails and doorways */
  museum(A,o){const R=A.R+1.2,H=o.h||22,wc=o.wall||'#efe6d2',pc=shade(wc,-.1),tc=o.trim||'#c9a86a',sk=o.skirt||'#7a4f2a';
    ring(A,R,1.8,4.2).forEach(p=>{const ry=-p[2]+Math.PI/2;I('box',wc,1.9,H,.6,p[0],H/2,p[1],0,ry,0);I('box',sk,1.92,1.1,.7,p[0],.55,p[1],0,ry,0);I('box',tc,1.92,.22,.68,p[0],3.6,p[1],0,ry,0);I('box',tc,1.92,.5,.8,p[0],H-.8,p[1],0,ry,0);
      if(p[3]%5===0){const x=p[0]-Math.cos(p[2])*.45,z=p[1]-Math.sin(p[2])*.45;I('box',pc,1.1,H,.5,x,H/2,z,0,ry,0);I('box',tc,1.3,.6,.7,x,1.2,z,0,ry,0);I('box',tc,1.3,.8,.7,x,H-1.6,z,0,ry,0);}});
    W.exits.forEach(e=>{if(e.noArch)return;const a=Math.atan2(e.z,e.x),x=Math.cos(a)*R,z=Math.sin(a)*R,ry=-a+Math.PI/2,tx=-Math.sin(a),tz=Math.cos(a);
      I('box',wc,8.6,H-9.5,.62,x,9.5+(H-9.5)/2,z,0,ry,0);I('box',tc,8.8,.7,.9,x,9.4,z,0,ry,0);[-1,1].forEach(k=>{I('box',tc,.9,9.4,.9,x+tx*4.2*k,4.7,z+tz*4.2*k,0,ry,0);});});
    const cl=new THREE.Mesh(new THREE.CircleGeometry(R+1,40),new THREE.MeshBasicMaterial({color:o.ceil||'#f6f1e6',side:THREE.DoubleSide}));cl.rotation.x=Math.PI/2;cl.position.y=H;W.ag.add(cl);W.disp.push(cl.geometry,cl.material);
    for(let x=-R;x<=R;x+=8)for(let z=-R;z<=R;z+=8){if(Math.hypot(x,z)>R-4)continue;I('box','#ffffff',5.4,.1,5.4,x,H-.12,z,0,0,0,true);I('box',tc,6.2,.4,.3,x,H-.3,z-3,0,0,0);I('box',tc,.3,.4,6.2,x-3,H-.3,z,0,0,0);}}};
/* ----- skylines beyond the edge ----- */
const BACKS={
  mesas(A,o){const C=o.c||['#c0654a','#a8503e','#d8885a'],band=o.band||'#f0c090',Rn=seed(91+A.id.length),R=A.R;
    for(let i=0;i<30;i++){const a=i/30*6.283+Rn()*.15,r=R+22+Rn()*55,x=Math.cos(a)*r,z=Math.sin(a)*r,w=10+Rn()*16,h=14+Rn()*30,c=C[i%C.length];
      I('box',c,w,h,w*.8,x,h/2-2,z,0,Rn()*3,0);I('box',band,w*1.02,1.4,w*.82,x,h*.55,z,0,Rn()*3*0,0);I('box',shade(c,-.15),w*.7,h*.25,w*.56,x,h+h*.12-2,z,0,Rn()*3,0);
      if(i%3===0)I('pyr',c,w*.25,h*.6,w*.25,x+w*.3,h+h*.3,z,0,Rn()*3,0);}},
  city(A,o){const Rn=seed(73+A.id.length),R=A.R,T=o.c||['#7a8494','#8a94a4','#6b7586','#9aa4b4'];
    for(let i=0;i<44;i++){const a=i/44*6.283+Rn()*.1,r=R+26+Rn()*60,x=Math.cos(a)*r,z=Math.sin(a)*r,w=6+Rn()*8,h=18+Rn()*40,c=T[i%T.length];I('box',c,w,h,w,x,h/2-2,z,0,-a,0);
      for(let fy=4;fy<h-3;fy+=4)I('box','#c9e4ff',w*.85,.5,w*1.01,x,fy,z,0,-a,0,true);if(Rn()<.3)I('cyl','#8a8f99',.25,6,.25,x,h+1,z);}
    [[.6,1],[2.4,.9],[4.1,1.1]].forEach((q,i)=>{const r=R+30+i*8,x=Math.cos(q[0])*r,z=Math.sin(q[0])*r;I('cyl','#a0523a',2*q[1],30*q[1],2*q[1],x,15*q[1]-2,z);[.3,.6].forEach(k=>I('cyl','#ffffff',2.05*q[1],1.4,2.05*q[1],x,30*q[1]*k,z));
      W.ticks.push(()=>{if(Math.random()<.04)floatS('💨',x+(Math.random()-.5)*2,30*q[1]+1,z,6,4);});});
    [[1.4],[3.3],[5.3]].forEach((q,i)=>{const r=R+18+i*5;crane(Math.cos(q[0])*r,Math.sin(q[0])*r,q[0]);});},
  mountains(A,o){const Rn=seed(57+A.id.length),R=A.R,arc=o.arc||[0,360],C=o.c||['#6fa86a','#7f9a78','#8a9aa8','#5f8a6a'];
    for(let i=0;i<16;i++){const ang=(arc[0]+(arc[1]-arc[0])*(i+.5)/16)*D2,r=R+55+Rn()*70,x=Math.cos(ang)*r,z=Math.sin(ang)*r,s=26+Rn()*26,c=C[i%C.length];
      I('cone',c,s,s*1.4,s,x,s*.7-4,z,0,Rn()*3,0);if(s>36||o.snow)I('cone','#ffffff',s*.32,s*.45,s*.32,x,s*1.4-4-s*.2,z,0,Rn()*3,0);}
    for(let i=0;i<14;i++){const ang=(arc[0]+(arc[1]-arc[0])*(i+.5)/14)*D2,r=R+24+Rn()*16,x=Math.cos(ang)*r,z=Math.sin(ang)*r,s=12+Rn()*8;I('sphL',pick(['#5f9a5a','#6fae5f','#4f8a4f']),s,s*.55,s,x,-2,z);}}};
/* ----- new scenery sets ----- */
const SETS={
  canyon(A,S,night){const P=A.pal||{},G=P.grass||['#c9a86a','#b8945a','#d8b878'],RK=P.rock||['#b5564a','#9a4a3e','#c9805a','#8a8378'],TR=P.tree||['#d9362e','#ff8a3c','#e8603a'],HD=P.hoodoo||['#c0654a','#e0a070','#a04a3a'],{spot,n,Rn,pk}=S;
    for(let i=0;i<n(160);i++){const p=spot(.2,2,6);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('coneL',pk(G),.07,.4+Rn()*.35,.07,p[0]+j*.14,y+.2,p[1]+(j%2)*.12,(j-1)*.35,0,(j-1)*.25);}
    for(let i=0;i<n(18);i++){const p=spot(.8,3);if(p){const y=gy(p[0],p[1]),s=.5+Rn()*.9;I('sphL',pk(RK),s*1.2,s*.75,s,p[0],y+s*.25,p[1],0,Rn()*3,0);if(s>.9)col(p[0],p[1],s);}}
    for(let i=0;i<n(22);i++){const p=spot(.4,3);if(!p)continue;for(let j=0;j<4;j++){const x=p[0]+(Rn()-.5)*1.4,z=p[1]+(Rn()-.5)*1.4;I('sphL',pk(RK),.18,.11,.16,x,gy(x,z)+.05,z);}}
    for(let i=0;i<n(16);i++){const p=spot(.6,3,8);if(!p)continue;let x=p[0],z=p[1],a=Rn()*6;for(let j=0;j<3;j++){const L=.8+Rn()*.8;I('box',P.crack||'#6a3a30',L,.02,.08,x,gy(x,z)+.05,z,0,a,0);x+=Math.cos(a)*L*.5;z-=Math.sin(a)*L*.5;a+=(Rn()-.5)*1.2;}}
    for(let i=0;i<n(5);i++){const p=spot(1.4,5);if(!p)continue;const y=gy(p[0],p[1]);let h=0;[[1.6,1.6],[1.3,1.4],[1,1.3],[1.4,.5]].forEach((q,j)=>{I('box',HD[j%HD.length],q[0],q[1],q[0],p[0],y+h+q[1]/2,p[1],0,Rn()*.6,0);h+=q[1];});col(p[0],p[1],1);}
    for(let i=0;i<n(4);i++){const p=spot(.7,4);if(p){const y=gy(p[0],p[1]);I('box','#a9a399',.9,.3,.9,p[0],y+.15,p[1]);I('box','#a9a399',.35,1.2,.35,p[0],y+.9,p[1]);I('box','#fff27a',.6,.55,.6,p[0],y+1.75,p[1],0,0,0,true);I('pyr','#8a8378',.75,.5,.75,p[0],y+2.3,p[1],0,Math.PI/4,0);col(p[0],p[1],.6);}}
    for(let i=0;i<n(night?2:4);i++){const p=spot(1.8,5);if(p)tree(p[0],p[1],.75+Rn()*.4,pk(TR));}
    for(let i=0;i<n(3);i++){const p=spot(1.8,5);if(p)tree(p[0],p[1],.8+Rn()*.3,P.pine||'#3f6e4a','pine');}
    for(let i=0;i<n(8);i++){const p=spot(1.2,4);if(p)bush(p[0],p[1],.5+Rn()*.3,pk(P.bush||['#8a8a4a','#7a7a3a','#9a8a4a']));}
    if(!night)birds(2,24,A.R||40);},
  city(A,S){const {spot,n,Rn,pk}=S;
    for(let i=0;i<n(14);i++){const p=spot(.4,3);if(p){const y=gy(p[0],p[1]);I('cyl','#3a3f48',.2,.9,.2,p[0],y+.45,p[1]);I('cyl','#ffd23f',.21,.15,.21,p[0],y+.75,p[1]);col(p[0],p[1],.25);}}
    for(let i=0;i<n(10);i++){const p=spot(.4,3);if(p){const y=gy(p[0],p[1]);I('box','#ff8a3c',.6,.06,.6,p[0],y+.03,p[1]);I('cone','#ff8a3c',.26,.8,.26,p[0],y+.45,p[1]);I('cyl','#ffffff',.17,.12,.17,p[0],y+.55,p[1]);}}
    for(let i=0;i<n(6);i++){const p=spot(.7,3);if(p){const y=gy(p[0],p[1]),c=pk(['#2f7a4a','#3a3f48','#3d6fb0']);I('box',c,.8,1.1,.8,p[0],y+.55,p[1],0,Rn()*3,0);I('box',shade(c,-.2),.85,.1,.9,p[0],y+1.12,p[1],0,Rn()*3,0);col(p[0],p[1],.6);}}
    for(let i=0;i<n(14);i++){const p=spot(.6,3,8);if(p)I('cyl','#4a4f57',.5,.03,.5,p[0],gy(p[0],p[1])+.04,p[1]);}
    for(let i=0;i<n(10);i++){const p=spot(1.4,3,8);if(p){const r=.9+Rn()*.8;I('cyl','#8aa4ba',r,.02,r*.6,p[0],gy(p[0],p[1])+.045,p[1],0,Rn()*3,0);}}
    for(let i=0;i<n(5);i++){const p=spot(.8,4);if(p){lampPost(p[0],p[1]);col(p[0],p[1],.3);}}
    for(let i=0;i<n(4);i++){const p=spot(1.4,4);if(p){const y=gy(p[0],p[1]);I('box','#8a8f99',1.6,.6,1.6,p[0],y+.3,p[1]);tree(p[0],p[1],.55,pk(['#5fbf5a','#4fae4a']));col(p[0],p[1],1);}}
    for(let i=0;i<n(6);i++){const p=spot(.9,3);if(p){const y=gy(p[0],p[1]),a=Rn()*3;I('box','#9b6a43',1.3,.18,1.1,p[0],y+.1,p[1],0,a,0);for(let k=0;k<1+Math.floor(Rn()*3);k++)I('box','#c9905f',1,.8,.9,p[0],y+.6+k*.82,p[1],0,a+(Rn()-.5)*.3,0);col(p[0],p[1],.8);}}
    for(let i=0;i<n(6);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('cyl',pk(['#3d6fb0','#e8423a','#3fae5a','#ffd23f']),.42,1.1,.42,p[0],y+.55,p[1]);I('cyl','#26232e',.43,.06,.43,p[0],y+.8,p[1]);col(p[0],p[1],.45);}}
    birds(3,18,A.R||40);},
  quarry(A,S){const {spot,n,Rn,pk}=S;
    for(let i=0;i<n(24);i++){const p=spot(.8,3);if(p){const y=gy(p[0],p[1]),s=.5+Rn()*1;I('sphL',pk(['#8a8378','#9a9488','#7a746a']),s*1.2,s*.7,s,p[0],y+s*.2,p[1],0,Rn()*3,0);if(s>1)col(p[0],p[1],s);}}
    for(let i=0;i<n(14);i++){const p=spot(1,3,8);if(p){const r=1+Rn()*1.2;I('cyl','#a8a298',r,.03,r,p[0],gy(p[0],p[1])+.04,p[1]);}}
    for(let i=0;i<n(8);i++){const p=spot(1.2,3,8);if(p){const r=.8+Rn()*.8;I('cyl','#7f9ab0',r,.02,r*.6,p[0],gy(p[0],p[1])+.05,p[1],0,Rn()*3,0);}}
    for(let i=0;i<n(8);i++){const p=spot(.4,3);if(p){const y=gy(p[0],p[1]);I('cone','#ff8a3c',.26,.8,.26,p[0],y+.4,p[1]);I('cyl','#ffffff',.17,.12,.17,p[0],y+.5,p[1]);}}
    for(let i=0;i<n(6);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('cyl',pk(['#e8423a','#ffd23f']),.42,1.1,.42,p[0],y+.55,p[1]);col(p[0],p[1],.45);}}},
  scrap(A,S){const {spot,n,Rn,pk}=S;
    for(let i=0;i<n(16);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('tor','#26232e',.6,.6,.8,p[0],y+.2,p[1],Math.PI/2,0,0);if(Rn()<.5)I('tor','#26232e',.6,.6,.8,p[0]+.2,y+.5,p[1],Math.PI/2,0,0);}}
    for(let i=0;i<n(30);i++){const p=spot(.3,3);if(p){const y=gy(p[0],p[1]);I(pk(['box','cyl']),pk(['#c97a3e','#8a8f99','#a8504a','#6b7078']),.3+Rn()*.5,.15+Rn()*.3,.3+Rn()*.5,p[0],y+.12,p[1],Rn(),Rn()*3,Rn());}}
    for(let i=0;i<n(14);i++){const p=spot(1,3,8);if(p){const r=1+Rn();I('cyl','#9a9488',r,.03,r,p[0],gy(p[0],p[1])+.04,p[1]);}}
    for(let i=0;i<n(8);i++){const p=spot(1.2,3,8);if(p){const r=.8+Rn()*.8;I('cyl','#5a6a7a',r,.02,r*.6,p[0],gy(p[0],p[1])+.05,p[1],0,Rn()*3,0);}}
    for(let i=0;i<n(6);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('cyl',pk(['#3d6fb0','#e8423a','#c97a3e']),.42,1.1,.42,p[0],y+.55,p[1]);col(p[0],p[1],.45);}}
    birds(2,18,A.R||40);},
  beach(A,S){const {spot,n,Rn,pk}=S;
    for(let i=0;i<n(70);i++){const p=spot(.4,2,6);if(p){const a=Rn()*.4;for(let j=0;j<3;j++)I('box','#f8e6a8',1.6+Rn(),.02,.08,p[0],gy(p[0],p[1])+.04,p[1]+j*.3,0,a,0);}}
    for(let i=0;i<n(36);i++){const p=spot(.2,2);if(p){const y=gy(p[0],p[1]);I(Rn()<.5?'sph':'cone',pk(['#ffc9d9','#ffffff','#ffe0b0','#f4a6b8']),.14,.12,.14,p[0],y+.08,p[1],Rn(),0,Rn());}}
    for(let i=0;i<n(6);i++){const p=spot(.4,3);if(p){const y=gy(p[0],p[1]),c=pk(['#ff8a3c','#ff6b8a','#ffd23f']);for(let k=0;k<5;k++)I('box',c,.12,.05,.42,p[0]+Math.sin(k*1.257)*.2,y+.05,p[1]+Math.cos(k*1.257)*.2,0,k*1.257,0);}}
    for(let i=0;i<n(40);i++){const p=spot(.4,2);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<4;j++)I('coneL',pk(['#b8c880','#a8b870','#c8d890']),.1,.8+Rn()*.6,.1,p[0]+(Rn()-.5)*.6,y+.4,p[1]+(Rn()-.5)*.6,(Rn()-.5)*.5,0,(Rn()-.5)*.5);}
    for(let i=0;i<n(4);i++){const p=spot(1.4,4);if(p){const y=gy(p[0],p[1]);I('cyl','#a8987a',.2,3+Rn()*2,.2,p[0],y+.2,p[1],0,Rn()*3,Math.PI/2);}}
    for(let i=0;i<n(3);i++){const p=spot(2,4);if(p){const y=gy(p[0],p[1]);I('cyl','#5fc4f0',1.4,.04,1,p[0],y+.05,p[1],0,0,0,true);for(let k=0;k<7;k++){const a=k/7*6.28;I('sphL',pk(['#8a8378','#9a9488']),.45,.3,.4,p[0]+Math.cos(a)*1.6,y+.12,p[1]+Math.sin(a)*1.2);}I('sphL','#2f7a4a',.3,.08,.3,p[0]+.3,y+.06,p[1]);col(p[0],p[1],1.6);}}
    for(let i=0;i<n(4);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]),c=pk(['#e8423a','#3d8fe0','#ffd23f','#3fae5a']);I('cyl',c,.3,.45,.24,p[0],y+.22,p[1]);I('box',pk(['#ffd23f','#ff9ecb']),.12,.7,.05,p[0]+.4,y+.35,p[1],0,0,.4);}}
    for(let i=0;i<n(3);i++){const p=spot(1.6,4);if(p){const y=gy(p[0],p[1]),c=pk(['#e8423a','#3d8fe0','#ffd23f','#ff9ecb']);I('cyl','#ffffff',.06,2.6,.06,p[0],y+1.3,p[1]);I('cone',c,1.5,.6,1.5,p[0],y+2.7,p[1]);I('cone','#ffffff',.8,.35,.8,p[0],y+2.82,p[1]);
      const a=Rn()*6;I('box',c,.8,.08,1.6,p[0]+Math.cos(a)*1.2,y+.45,p[1]+Math.sin(a)*1.2,-.5,a,0);col(p[0],p[1],.4);}}
    for(let i=0;i<n(3);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('sph',pk(['#ff6b6b','#ffd23f','#7fc8f0']),.45,.45,.45,p[0],y+.45,p[1]);I('sph','#ffffff',.46,.12,.46,p[0],y+.45,p[1]);}}
    birds(4,14,A.R||40);},
  seatown(A,S){const {spot,n,Rn,pk}=S;
    for(let i=0;i<n(6);i++){const p=spot(1,3);if(p){planter(p[0],p[1]);col(p[0],p[1],.9);}}
    for(let i=0;i<n(5);i++){const p=spot(.8,4);if(p){lampPost(p[0],p[1]);col(p[0],p[1],.3);}}
    for(let i=0;i<n(8);i++){const p=spot(.4,3);if(p){const y=gy(p[0],p[1]);I('cyl','#26232e',.2,.9,.2,p[0],y+.45,p[1]);I('sph','#26232e',.22,.18,.22,p[0],y+.9,p[1]);col(p[0],p[1],.25);}}
    for(let i=0;i<n(5);i++){const p=spot(.8,3);if(p){const y=gy(p[0],p[1]);I('cyl','#c9905f',.5,.7,.5,p[0],y+.35,p[1]);I('cylL','#6b4028',.1,1.6,.1,p[0],y+1.4,p[1]);for(let k=0;k<7;k++)I('coneL','#4fae4a',.1,1.2,.1,p[0],y+2.3,p[1],Math.cos(k)*.9,0,Math.sin(k)*.9);col(p[0],p[1],.5);}}
    for(let i=0;i<n(4);i++){const p=spot(.8,3);if(p){const y=gy(p[0],p[1]);I('box','#9bdcff',1,.5,.7,p[0],y+.25,p[1],0,Rn()*3,0);for(let k=0;k<4;k++)I('sph','#c9d6e6',.16,.08,.3,p[0]-.3+k*.2,y+.55,p[1]);col(p[0],p[1],.6);}}
    for(let i=0;i<n(3);i++){const p=spot(.8,3);if(p){lobsterPot(p[0],p[1]);col(p[0],p[1],.7);}}
    for(let i=0;i<n(16);i++){const p=spot(.6,2);if(p)flowerPatch(p[0],p[1],4,.7,[pk(['#ff6b6b','#ffd23f','#ff9ecb','#ffffff'])],Rn);}
    birds(4,16,A.R||40);},
  pinewood(A,S){const {spot,n,Rn,pk}=S;
    for(let i=0;i<n(30);i++){const p=spot(.8,3,8);if(p){const r=1+Rn()*1.4;I('cyl','#8a6a4a',r,.02,r,p[0],gy(p[0],p[1])+.04,p[1]);}}
    for(let i=0;i<n(36);i++){const p=spot(.5,2);if(!p)continue;const y=gy(p[0],p[1]);for(let k=0;k<6;k++)I('coneL',pk(['#3f8e4a','#4f9e5a','#2f7a3a']),.14,1,.14,p[0],y+.4,p[1],Math.cos(k*1.05)*.8,0,Math.sin(k*1.05)*.8);}
    for(let i=0;i<n(12);i++){const p=spot(.3,2);if(p){const y=gy(p[0],p[1]);I('cyl','#fff6e6',.07,.3,.07,p[0],y+.15,p[1]);I('hemi',pk(['#e8423a','#c97a3e']),.22,.18,.22,p[0],y+.28,p[1]);}}
    for(let i=0;i<n(5);i++){const p=spot(1.4,4);if(p){const y=gy(p[0],p[1]);I('cyl','#7a5236',.35,3,.35,p[0],y+.35,p[1],0,Rn()*3,Math.PI/2);col(p[0],p[1],1.2);}}
    for(let i=0;i<n(12);i++){const p=spot(.8,3);if(p){const y=gy(p[0],p[1]),s=.6+Rn()*.7;I('sphL','#8a8378',s*1.2,s*.7,s,p[0],y+s*.2,p[1]);I('sphL','#4f8e3a',s*.9,s*.25,s*.8,p[0],y+s*.6,p[1]);if(s>.9)col(p[0],p[1],s);}}
    for(let i=0;i<n(10);i++){const p=spot(1.8,5);if(p)tree(p[0],p[1],.9+Rn()*.5,pk(['#2f6e3a','#3f7e4a']),'pine');}
    birds(3,20,A.R||40);},
  museum(A,S){const {spot,n,Rn,pk}=S,DG=['#ff6b6b','#ffd23f','#7fc8f0','#8fe39a','#c9b6ff','#ff9ecb'];
    for(let i=0;i<n(7);i++){const p=spot(1.2,5);if(!p)continue;const y=gy(p[0],p[1]);I('box','#ffffff',1.6,1.2,1.6,p[0],y+.6,p[1]);I('box','#c9a86a',1.7,.1,1.7,p[0],y+1.22,p[1]);
      const k=pk(['box','sph','cone','pyr','cyl']);I(k,pk(DG),.5,k==='cone'||k==='pyr'?.9:.5,.5,p[0],y+1.65,p[1]);I('box','#e8f6ff',1.3,1.3,1.3,p[0],y+1.9,p[1],0,0,0,true);col(p[0],p[1],1.1);}
    for(let i=0;i<n(4);i++){const p=spot(1.2,5);if(!p)continue;const y=gy(p[0],p[1]),a=Rn()*3;I('box','#5b4636',2.6,.45,.8,p[0],y+.5,p[1],0,a,0);I('box','#a8504a',2.6,.12,.8,p[0],y+.78,p[1],0,a,0);col(p[0],p[1],1.2);}
    for(let i=0;i<n(6);i++){const p=spot(.9,4);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#c9905f',.55,.8,.55,p[0],y+.4,p[1]);for(let k=0;k<7;k++)I('coneL',pk(['#3f8e4a','#4fae4a']),.12,1.4,.12,p[0],y+1.3,p[1],Math.cos(k)*.8,0,Math.sin(k)*.8);col(p[0],p[1],.6);}
    for(let i=0;i<n(5);i++){const p=spot(.6,4);if(!p)continue;const y=gy(p[0],p[1]),a=Rn()*3;I('cyl','#3a3338',.06,1.3,.06,p[0],y+.65,p[1]);I('box','#2f4f3a',1,.7,.06,p[0],y+1.5,p[1],-.4,a,0);I('box','#ffffff',.8,.08,.07,p[0],y+1.6,p[1],-.4,a,0,true);col(p[0],p[1],.3);}}};
/* ----- hooks into the engine ----- */
const _hedge=edgeHedge;edgeHedge=function(R,skip,c){const A=W.area,E=A&&A.edge;if(E&&EDGES[E.style]){EDGES[E.style](A,E);return;}_hedge(R,skip,c);};
const _et=edgeTrees;edgeTrees=function(){if(W.area&&W.area.noEdgeTrees)return;return _et.apply(this,arguments);};
const _mf=mountainsFar;mountainsFar=function(cols){const A=W.area;if(A&&A.backdrop)return;return _mf(A&&A.mtnCols||cols);};
const _cp=cloudPuffs;cloudPuffs=function(n,y,r,c){const A=W.area;return _cp(n,y,r,A&&A.cloudC||c);};
const _en=enrich;enrich=function(A){const s=A.biome&&SETS[A.biome];if(s&&!A.noEnrich){s(A,scatter(A),A.light==='night');}else _en(A);
  if(A.backdrop&&BACKS[A.backdrop.style])BACKS[A.backdrop.style](A,A.backdrop);
  if(A.grid){const g=A.grid,R=A.R-.3;for(let v=-R+g.step/2;v<R;v+=g.step){const L=2*Math.sqrt(Math.max(0,R*R-v*v));if(L<1)continue;I('box',g.c,L,.02,g.w||.08,0,(g.y||0)+.035,v);I('box',g.c,g.w||.08,.02,L,v,(g.y||0)+.035,0);}}
  if(A.sea){const s=A.sea,m=new THREE.Mesh(new THREE.RingGeometry(A.R-6,700,64,1),new THREE.MeshBasicMaterial({color:s.c||'#3fc4d8'}));m.rotation.x=-Math.PI/2;m.position.y=s.y;W.ag.add(m);W.disp.push(m.geometry,m.material);
    const f=new THREE.Mesh(new THREE.RingGeometry(A.R+(s.foam||1.6),A.R+(s.foam||1.6)+.9,64,1),new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.75}));f.rotation.x=-Math.PI/2;f.position.y=s.y+.03;W.ag.add(f);W.disp.push(f.geometry,f.material);
    W.ticks.push(()=>{const k=1+Math.sin(W.t*1.2)*.008;f.scale.set(k,k,1);});}
  spotLamps(A);skyThings(A);};
const _sp=snowPine;snowPine=function(x,z){const A=W.area;if(A&&A._clear&&A.keepOut(x,z))return;return _sp.apply(this,arguments);};
const _tr=tree;tree=function(x,z){const A=W.area;if(A&&A._clear&&A.keepOut(x,z))return;return _tr.apply(this,arguments);};
const _cr=camRoom;camRoom=function(fx,fz,D){D=_cr(fx,fz,D);const A=W.area;if(A&&A.indoor&&!player.ski){const lim=A.R+.2;for(let s=D;s>1.6;s-=.3){if(Math.hypot(player.x-fx*s,player.z-fz*s)<=lim)return s;}return 1.6;}return D;};
const _ea=enterArea;enterArea=function(id,pos,msg){_ea(id,pos,msg);if(W.area&&W.ready)lights(W.area);};
/* restyle an area: change its settings and add to its build */
window.restyle=function(id,props,extra){const A=AREAS[id];if(!A)return;Object.assign(A,props);
  /* keep scenery off the strip between each arch and its arrival point, where the camera looks */
  if(!A.keepOut&&!A.rect){const segs=(A.exits||[]).map(e=>[e.x,e.z,e.x*.6,e.z*.6]);if(A.start)segs.push([A.start[0]*1.4,A.start[1]*1.4,A.start[0],A.start[1]]);
    A.keepOut=(x,z)=>segs.some(q=>{const dx=q[2]-q[0],dz=q[3]-q[1],L=dx*dx+dz*dz||1,t=Math.max(0,Math.min(1,((x-q[0])*dx+(z-q[1])*dz)/L));return Math.hypot(x-q[0]-dx*t,z-q[1]-dz*t)<5;});A._clear=true;}if(extra){const b=A.build;A.build=function(){b.call(this);extra.call(this,this);};}};
/* the land slopes down into the sea beyond the edge */
window.shoreHF=function(A,drop,from,to){const h0=A.hf||(()=>0),R=A.R;A.hf=(x,z)=>{const r=Math.hypot(x,z),t=Math.max(0,Math.min(1,(r-(R+(from||-.5)))/(to||5)));return h0(x,z)*(1-t)+drop*t;};};
window.LOOKS={LIGHTS,EDGES,BACKS,SETS};
})();
