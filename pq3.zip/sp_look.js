/* ================================================================
   Spring Blossom (Pup Seasons 5, 26 Nov 2026; claude/spring-blossom-design.md): how the pups look.
   - Primrose (Bearded Collie) and Tulip (Welsh Springer Spaniel), the two secret season pups;
   - a spring fact for each of the 119 spring pups (stable science, written 26 Nov 2026);
   - spring kits per island (flower crowns, bunny ears, wellies, baskets of eggs...),
     one full costume per island, the duckling suit for the Spa;
   - new pieces: a flower crown and bunny ears (2D and 3D);
   - window.SEASONSPEC is wrapped: in Spring Blossom every pup in 3D wears its spring outfit,
     and in 2D any copy made with SPLOOK.sp(p).
   ================================================================ */
(function(){
const PS=window.PSTYLE,K=INK,PI=Math.PI;
const ol=w=>`stroke="${K}" stroke-width="${w||2.6}" stroke-linejoin="round" stroke-linecap="round"`;
const st=(c,w,o)=>`fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${o==null?1:o}"`;
const PINK='#ff9ac0',LEAF='#6abf4a',SKY='#bfe4ff',YEL='#ffe066';
const FLC=['#ff9ac0','#ffe066','#ffffff','#c8a8ff','#ff8a8a','#8ad0ff'];

/* ---------------- the two secret season pups ---------------- */
const SPUPS={
 primrose:{id:'primrose',name:'Primrose',breed:'Bearded Collie',area:'windmill',island:'meadow',type:'leaf',pitch:1.12,season:'sp',
   look:{fur:'#8a8f98',ear:'#6a6f78',ears:'floppy',fluffy:true,muzzle:'#f2f0ea',belly:'#f2f0ea',paw:'#f2f0ea',blaze:'#f2f0ea',tail:'plume',collar:'#ffe066',acc:[]},
   fact:'The Bearded Collie is a shaggy herding dog from Scotland, where shepherds have worked with it for hundreds of years. The long hair on its cheeks and chin makes a beard.',
   hint:'Primrose is hiding among the lambs at Windmill Hill.'},
 tulip:{id:'tulip',name:'Tulip',breed:'Welsh Springer Spaniel',area:'village',island:'village',type:'fire',pitch:1.2,season:'sp',
   look:{fur:'#ffffff',ear:'#b8472a',ears:'floppy',patch:'#b8472a',spots:true,muzzle:'#ffffff',belly:'#ffffff',tail:'wag',collar:'#ff6a8a',acc:[]},
   fact:'The Welsh Springer Spaniel comes from Wales, and its coat is always red and white. Springer spaniels got their name because they spring birds out of bushes and long grass.',
   hint:'Tulip is waiting near the Blossom Festival in the village.'}};
if(window.CARDS&&CARDS.BREEDS){if(!CARDS.BREEDS['Bearded Collie'])CARDS.BREEDS['Bearded Collie']={sz:'m',spd:8,brn:9,cud:8,brv:7,g:'herd'};if(!CARDS.BREEDS['Welsh Springer Spaniel'])CARDS.BREEDS['Welsh Springer Spaniel']={sz:'m',spd:8,brn:8,cud:9,brv:7,g:'fetch'};}
if(PS&&PS.COAT){PS.COAT['Bearded Collie']='silky';PS.COAT['Welsh Springer Spaniel']='feather';}

/* ---------------- spring facts, one per pup, in island order (I.pups then the sparkly pup) ---------------- */
const SF={
 meadow:['Buttercup petals are so shiny that they reflect yellow light. Hold one under your chin and see!',
  'Farmers sow seeds in spring. A seed needs water, air and warmth to start growing.',
  'Honeybees visit spring blossom to collect nectar, which they turn into honey.',
  'Lambs are born in spring, when fresh new grass grows for their mums to eat.',
  'Bumblebee queens sleep all winter, then wake up in spring and start a new nest.',
  'Poppy seeds can wait in the soil for years, then grow when the ground is dug.',
  'Hazel trees have dangly yellow catkins in early spring, and the wind carries their pollen.',
  'Pussy willow buds are soft and furry, like a kitten\'s paw, and come out in early spring.',
  'Frogs lay their eggs in ponds in spring. A clump of frog eggs is called frogspawn.',
  'In spring, hares can be seen standing up and boxing with their front paws!',
  'An acorn is a seed. Plant it, and one day it can grow into a mighty oak tree.',
  'Bluebells flower in the woods in spring, before the trees\' new leaves shade the ground.',
  'Young fern leaves come up curled like a snail shell, then slowly unroll.'],
 snowy:['In spring the snow starts to melt, and the water runs down the mountains into the rivers.',
  'Bears wake up from their long winter sleep in spring, very hungry!',
  'Mountain hares swap their white winter coat for a brown summer coat in spring.',
  'Marmots wake up in spring after sleeping through the winter for about six months.',
  'Some mountain flowers start growing under the snow and pop up as soon as it melts.',
  'Snow melts faster on sunny slopes than on shady ones.',
  'Snowdrops are some of the first flowers of the year, and they can push up through thin snow.',
  'In spring, melting snow makes waterfalls rush down the steep sides of the fjords.',
  'Around 20 March, day and night are about the same length all over the world. It is called the spring equinox.',
  'Pine cones open up in warm, dry weather to let their seeds fly out.',
  'Snow keeps the ground underneath it warmer, like a blanket, so little plants survive the winter.',
  'Birds that fly away for the winter come back in spring. This long journey is called migration.',
  'Icicles drip and melt in the spring sunshine, and the drips can freeze again at night.'],
 reef:['In spring the sea fills with tiny floating plants called plankton, which feed lots of sea creatures.',
  'Baby sea turtles hatch from eggs buried in the sand, then scurry down the beach to the sea.',
  'Kelp is a giant seaweed. It holds onto the rocks with a grip like roots, called a holdfast.',
  'Many fish lay thousands of tiny eggs at once.',
  'Seahorse dads carry the eggs in a pouch on their tummy until the babies hatch.',
  'If a starfish loses an arm, it can grow a new one.',
  'On the Great Barrier Reef, the corals all let go of their eggs on the same few nights, after a full moon.',
  'Baby barnacles swim about in the sea before they glue themselves to a rock for good.',
  'Grey whales swim thousands of kilometres north in spring, to their summer feeding grounds.',
  'An octopus mum guards her eggs and keeps them clean until they hatch.',
  'Salmon swim from the sea back up the river where they hatched, to lay their own eggs.',
  'Puffins come back to the same burrow on the cliffs every spring to lay one egg.',
  'Sea turtle eggs are soft and leathery, a bit like ping-pong balls.'],
 ninja:['In Japan, people have picnics under the cherry blossom in spring. It is called hanami, which means flower watching.',
  'At cherry blossom time in Japan, people eat pink, white and green sweet dumplings called hanami dango.',
  'In spring, bamboo shoots are dug up and cooked in Japan. They are called takenoko.',
  'On Children\'s Day in Japan, on 5 May, streamers shaped like carp fish fly from poles. They are called koinobori.',
  'Cherry blossom trees are in bloom for only a week or two.',
  'Each spring in Japan, people follow the cherry blossom front as the flowers open from the warm south to the cool north.',
  'The Japanese school year starts in April, at cherry blossom time.',
  'In spring, the fresh new leaves of tea bushes are picked to make green tea.',
  'Spring storms can happen when warm air and cold air bump into each other.',
  'Swallows swoop fast and low in spring to catch insects in the air.',
  'Japanese cranes dance in pairs, leaping and flapping their wings.',
  'Wisteria flowers hang down in long purple bunches, like grapes, in late spring.',
  'Fireflies in Japan start to glow in late spring and early summer.'],
 number:['Spring in Britain is March, April and May: 31 add 30 add 31 makes 92 days.',
  'Ladybirds can have 2, 7, 10 or even 22 spots, depending on their kind.',
  'A dozen eggs is 12 eggs, like 2 rows of 6 in an egg box.',
  'A hen\'s egg takes about 21 days to hatch.',
  'A duck\'s egg takes about 28 days to hatch. That is 4 weeks.',
  'Ducks have webbed feet, with 3 front toes joined by skin, for paddling.',
  'Many flowers have 3, 5 or 8 petals.',
  'In Britain, the clocks go forward 1 hour in spring, on the last Sunday in March.',
  'Count the spirals on a pine cone or a sunflower: the numbers are often 8, 13, 21 or 34.',
  'In the Fibonacci numbers, each number is the two before it added together: 1, 1, 2, 3, 5, 8, 13.',
  'A spider has 8 legs and an insect has 6, so a spider and a bee have 14 legs altogether.',
  'A seven-spot ladybird has 3 spots on each wing case and 1 in the middle: 3 add 3 add 1 makes 7.',
  'Leonardo Fibonacci wrote a puzzle about rabbits to explain his famous number pattern, about 800 years ago.'],
 gadget:['A greenhouse traps the Sun\'s warmth, so seeds can grow inside even when it is chilly outside.',
  'An incubator keeps eggs warm so they can hatch, just like a mother bird sitting on her nest.',
  'Plants make their own food from sunlight, air and water. This is called photosynthesis.',
  'A rainbow appears when sunlight shines through raindrops and splits into its colours.',
  'A weather vane turns to show which way the wind is blowing.',
  'A rain gauge measures how much rain has fallen.',
  'Lightning is a giant spark of electricity in the sky.',
  'Seed banks keep seeds safe for many years, ready to be planted one day.',
  'Some farms use robots to pick fruit and to milk the cows.',
  'Plants drink water up through their roots, all the way to their leaves.',
  'Some tractors can steer themselves, using signals from satellites.',
  'Jethro Tull improved the seed drill, a machine that plants seeds in neat rows, more than 300 years ago.',
  'Plants grow towards the light. Put one on a windowsill and watch it lean!'],
 rescue:['In the countryside, leave gates as you find them, so the farm animals stay safe.',
  'Keep dogs on a lead near sheep and lambs, so they don\'t frighten them.',
  'If you find a baby bird on the ground, leave it where it is. Its parents are usually close by.',
  'Wild birds\' nests and eggs are protected by law in Britain, so always leave them alone.',
  'Hedgehogs wake up in spring, hungry and thirsty. A shallow dish of water helps them.',
  'Always wash your hands after touching farm animals.',
  'If you hear thunder in a spring storm, go indoors.',
  'Seabirds nest on the cliffs in spring, so keep well back from the edge.',
  'Take your litter home, so it can\'t hurt animals and birds.',
  'Rangers look after the countryside and help people enjoy it safely.',
  'Dry spring grass can catch fire easily, so never leave a campfire or barbecue burning.',
  'Mountain rescue teams in Britain are volunteers, ready to help day or night.',
  'Lifeboat crews practise often, so they are ready for any emergency.'],
 dino:['All dinosaurs hatched from eggs.',
  'Some dinosaur eggs were about as big as a football.',
  'Maiasaura means good mother lizard. It looked after its babies in nests.',
  'Baby tyrannosaurs, the T. rex family, were only about as big as a Border Collie when they hatched.',
  'Birds are living dinosaurs, so a hen\'s egg is a kind of dinosaur egg!',
  'Some dinosaurs sat on their nests to keep their eggs warm, just like birds do.',
  'Long-necked dinosaurs laid lots of round eggs in big nesting grounds.',
  'Crocodiles bury their eggs in warm nests of leaves and mud.',
  'Fossil footprints show that some baby dinosaurs walked with their parents in groups.',
  'Mammoths were not dinosaurs. They lived long after the dinosaurs had gone.',
  'Ash from volcanoes makes rich soil, so plants grow well near old volcanoes.',
  'Ferns were growing on Earth long before the first flowers appeared.',
  'The first flowers appeared on Earth while dinosaurs were still alive.'],
 planet:['Tree seeds flew round the Moon on Apollo 14 in 1971, then came home and grew into Moon trees.',
  'Spring comes because the Earth is tilted, and our half of the world starts to lean towards the Sun.',
  'Astronauts have grown lettuce and flowers on the space station.',
  'The Moon has no weather, so it never rains and no flowers grow there.',
  'The first flower grown on the space station, a zinnia, bloomed in 2016.',
  'Mars has seasons too, but each one lasts about twice as long as ours.',
  'Each season on Saturn lasts about 7 years.',
  'On the spring equinox, the Sun rises in the east and sets in the west, almost exactly.',
  'In spring the Sun climbs higher in the sky each day, so the days get longer.',
  'Moonlight is really sunlight bouncing off the Moon.',
  'The Earth goes round the Sun once a year, so spring comes back every year.',
  'Rockets are often launched towards the east, to get a push from the spinning Earth.',
  'A meteor shower called the Lyrids lights up the night sky every April.']};
const FACT={primrose:SPUPS.primrose.fact,tulip:SPUPS.tulip.fact};
ISLANDS.forEach(I=>{const L=SF[I.id];if(!L)return;I.pups.concat(I.bonus||[]).forEach((p,i)=>{if(L[i])FACT[p.id]=L[i];});});

/* ---------------- new pieces (2D) ---------------- */
const flower2D=(x,y,r,col,mid)=>{let s='';for(let i=0;i<5;i++){const a=-PI/2+i*PI*2/5;s+=`<circle cx="${(x+Math.cos(a)*r*.62).toFixed(1)}" cy="${(y+Math.sin(a)*r*.62).toFixed(1)}" r="${(r*.5).toFixed(1)}" fill="${col||PINK}" ${ol(1.4)}/>`;}
  return s+`<circle cx="${x}" cy="${y}" r="${(r*.36).toFixed(1)}" fill="${mid||YEL}" ${ol(1.2)}/>`;};
const egg2D=(x,y,s,col,pat)=>{s=s||1;col=col||'#8ad0ff';let p=`<path d="M${x} ${y-12*s} C${x+8*s} ${y-12*s} ${x+10*s} ${y+2*s} ${x+9*s} ${y+5*s} C${x+8*s} ${y+11*s} ${x-8*s} ${y+11*s} ${x-9*s} ${y+5*s} C${x-10*s} ${y+2*s} ${x-8*s} ${y-12*s} ${x} ${y-12*s} Z" fill="${col}" ${ol(1.6)}/>`;
  if(pat===1)p+=`<path d="M${x-9*s} ${y} q${4.5*s} ${-4*s} ${9*s} 0 t${9*s} 0" ${st('#ffffff',2*s,.9)}/>`;else if(pat===2)p+=[[-3,-4],[3,-1],[-2,4],[4,5]].map(q=>`<circle cx="${x+q[0]*s}" cy="${y+q[1]*s}" r="${1.6*s}" fill="#ffffff" opacity=".9"/>`).join('');else p+=`<path d="M${x-9.5*s} ${y+2*s} H${x+9.5*s}" ${st('#ffffff',2.4*s,.9)}/>`;return p;};
if(PS){
 Object.assign(PS.HAT,{
  flowercrown(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;let s='',d='';
   for(let i=0;i<=12;i++){const a=PI*(1.1+i*.8/12),x=cx+Math.cos(a)*hw*.92,y=cy-hh*.25+Math.sin(a)*hh*.95;d+=(i?'L':'M')+x.toFixed(1)+' '+y.toFixed(1);}
   s+=`<path d="${d}" ${st(K,9,1)}/><path d="${d}" ${st(LEAF,5,1)}/>`;
   for(let i=0;i<6;i++){const a=PI*(1.16+i*.136),x=cx+Math.cos(a)*hw*.92,y=cy-hh*.25+Math.sin(a)*hh*.95;s+=flower2D(+x.toFixed(1),+y.toFixed(1),12,i%2?(col||PINK):FLC[(i+1)%FLC.length]);}
   return s;},
  bunnyears(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||'#ffffff';let s='';
   for(const g of[-1,1]){const bx=cx+g*hw*.36,by=cy-hh*.82,tx=cx+g*hw*.6,ty=cy-hh*1.95;
    s+=`<path d="M${bx-g*10} ${by} Q${tx-g*22} ${(by+ty)/2} ${tx} ${ty} Q${tx+g*20} ${(by+ty)/2} ${bx+g*12} ${by} Z" fill="${col}" ${ol(3)}/>`+
     `<path d="M${bx-g*4} ${by-4} Q${tx-g*10} ${(by+ty)/2} ${tx} ${ty+14} Q${tx+g*10} ${(by+ty)/2} ${bx+g*6} ${by-4} Z" fill="#ffb0c8"/>`;}
   return s+`<path d="M${cx-hw*.8} ${cy-hh*.62} Q${cx} ${cy-hh*1.06} ${cx+hw*.8} ${cy-hh*.62}" ${st(K,9,1)}/><path d="M${cx-hw*.8} ${cy-hh*.62} Q${cx} ${cy-hh*1.06} ${cx+hw*.8} ${cy-hh*.62}" ${st(PINK,5,1)}/>`;}});
}
/* ---------------- new pieces (3D) ---------------- */
if(PS){
 Object.assign(PS.H3,{
  flowercrown(h,col){const r=mk('tor',LEAF,.55,.5,.25,0,.32,0,h);r.rotation.x=PI/2;for(let i=0;i<8;i++){const a=i*PI/4;mk('sph',i%2?(col||PINK):FLC[(i>>1)%FLC.length],.11,.08,.11,Math.cos(a)*.55,.36,Math.sin(a)*.5,h);}},
  bunnyears(h,col){col=col||'#ffffff';[-1,1].forEach(s=>{const e=mk('sph',col,.11,.42,.07,s*.2,.78,0,h);e.rotation.z=-s*.18;const i=mk('sph','#ffb0c8',.06,.3,.03,s*.21,.78,.06,h);i.rotation.z=-s*.18;});}});
}

/* ---------------- full costumes ---------------- */
const SC={
 splamb:{n:'Lamb',body:'#ffffff',belly:'#f4f0ea',paw:'#3a3640',line:'NAME is a woolly little lamb. Baa!'},
 spbunny:{n:'Bunny',body:'#f4ece4',belly:'#ffffff',paw:'#e8dcd0',line:'NAME is a fluffy spring bunny. Hop, hop!'},
 spturtle:{n:'Baby Turtle',body:'#6abf6a',belly:'#e8e0a0',paw:'#4a9a5a',line:'NAME is a baby sea turtle, off to the sea!'},
 spblossom:{n:'Cherry Blossom',body:'#ffb8d0',belly:'#ffffff',paw:'#e87aa0',line:'NAME is a cherry blossom, pretty in pink!'},
 spduck:{n:'Duckling',body:'#ffd23f',belly:'#fff0a0',paw:'#ff9a2a',line:'NAME is a fluffy little duckling. Peep, peep!'},
 spegg:{n:'Dino Egg',body:'#f4ecd8',belly:'#ffffff',paw:'#c8b08a',line:'NAME is hatching out of a dinosaur egg. Crack!'}};
const SKEYS=Object.keys(SC),isS=k=>SKEYS.indexOf(k)>=0;
for(const k in SC){SC[k].sp=true;COS[k]=SC[k];}
if(typeof COS_ICON!=='undefined')Object.assign(COS_ICON,{splamb:'🐑',spbunny:'🐰',spturtle:'🐢',spblossom:'🌸',spduck:'🐥',spegg:'🥚'});
const _c2=cos2D;cos2D=function(w,c){let s=_c2(w,c);const L=c.L,Kc=L.cos;if(!isS(Kc))return s;
  const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,yb=cy-hh*.42;
  const dome=(col,lo)=>`<path d="M${cx-hw*.94} ${lo} Q${cx-hw*.94} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.94} ${cy-hh*1.2} ${cx+hw*.94} ${lo} Z" fill="${col}" ${S}/>`;
  if(w==='behind'){
    if(Kc==='spblossom')for(let i=0;i<6;i++){const a=-PI/2+i*PI/3,x=cx+Math.cos(a)*hw*1.12,y=cy-hh*.3+Math.sin(a)*hh*1.12;s+=`<ellipse cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" rx="${(hw*.5).toFixed(1)}" ry="${(hh*.36).toFixed(1)}" transform="rotate(${(a*180/PI+90).toFixed(0)} ${x.toFixed(1)} ${y.toFixed(1)})" fill="#ffd0e0" ${ol(3)}/>`;}
    if(Kc==='spduck')for(const g of[-1,1]){const x=100+g*(bw+6),y=by-bh*.1;s+=`<ellipse cx="${x}" cy="${y}" rx="16" ry="26" transform="rotate(${g*28} ${x} ${y})" fill="#ffd23f" ${ol(3)}/>`;}
    if(Kc==='spbunny')for(const g of[-1,1])s+=`<circle cx="${100+g*(bw+4)}" cy="${by+bh*.6}" r="12" fill="#ffffff" ${ol(2.6)}/>`;}
  if(w==='bodyClip'){
    if(Kc==='splamb')for(let q=-3;q<=3;q++)for(let r=-3;r<=3;r++)s+=`<circle cx="${100+q*15+(r%2?7:0)}" cy="${by+r*13}" r="9" fill="#ffffff" stroke="#d8d2c8" stroke-width="2"/>`;
    if(Kc==='spturtle'){s+=`<ellipse cx="100" cy="${by}" rx="${bw*.86}" ry="${bh*.86}" fill="#3f8f5a"/>`;[[0,0],[-.45,-.3],[.45,-.3],[-.45,.35],[.45,.35]].forEach(q=>{const x=100+q[0]*bw,y=by+q[1]*bh,r=Math.min(bw,bh)*.24;let d='';for(let i=0;i<6;i++){const a=i*PI/3;d+=(i?'L':'M')+(x+Math.cos(a)*r).toFixed(1)+' '+(y+Math.sin(a)*r).toFixed(1);}s+=`<path d="${d}Z" fill="#5aaf6a" stroke="#2f6a3e" stroke-width="2.4"/>`;});}
    if(Kc==='spblossom')[[-.5,-.35],[.4,-.45],[.55,.3],[-.3,.45],[.05,0]].forEach((q,i)=>{s+=flower2D(100+q[0]*bw,by+q[1]*bh,9,i%2?'#ffffff':'#ff9ac0');});
    if(Kc==='spduck')for(const t of[-.5,0,.5])s+=`<path d="M${100+t*bw-10} ${by+bh*.2} q10 10 20 0" ${st('#f0b820',3,1)}/>`;
    if(Kc==='spegg'){[[-.55,-.4],[.3,-.55],[.6,.1],[-.2,.35],[.1,-.1],[-.6,.5],[.45,.55]].forEach(q=>{s+=`<ellipse cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" rx="4" ry="3" fill="#b89a6a"/>`;});
      s+=`<path d="M${100-bw} ${by-bh*.05} ${Array.from({length:8},(v,i)=>`l${(bw/4).toFixed(1)} ${i%2?-9:9}`).join(' ')}" ${st('#8a6a4a',4,1)}/>`;}}
  if(w==='top'){
    if(Kc==='splamb')s+=dome('#ffffff',yb)+[[-.55,-.95],[-.2,-1.12],[.2,-1.12],[.55,-.95],[0,-.98],[-.38,-.82],[.38,-.82]].map(q=>`<circle cx="${cx+q[0]*hw}" cy="${cy+q[1]*hh}" r="${(hw*.2).toFixed(1)}" fill="#ffffff" stroke="#d8d2c8" stroke-width="2.4"/>`).join('')+
      [-1,1].map(g=>`<ellipse cx="${cx+g*hw*1.02}" cy="${cy-hh*.5}" rx="16" ry="8" transform="rotate(${g*24} ${cx+g*hw*1.02} ${cy-hh*.5})" fill="#3a3640" ${ol(2.4)}/>`).join('');
    if(Kc==='spbunny')s+=[-1,1].map(g=>{const bx=cx+g*hw*.4,b2=cy-hh*.9,tx=cx+g*hw*.62,ty=cy-hh*2;return `<path d="M${bx-g*12} ${b2} Q${tx-g*24} ${(b2+ty)/2} ${tx} ${ty} Q${tx+g*22} ${(b2+ty)/2} ${bx+g*14} ${b2} Z" fill="#f4ece4" ${S}/><path d="M${bx-g*5} ${b2-4} Q${tx-g*11} ${(b2+ty)/2} ${tx} ${ty+16} Q${tx+g*11} ${(b2+ty)/2} ${bx+g*7} ${b2-4} Z" fill="#ffb0c8"/>`;}).join('')+dome('#f4ece4',yb);
    if(Kc==='spturtle')s+=dome('#6abf6a',yb)+[[-.45,-.95],[0,-1.08],[.45,-.95]].map(q=>`<circle cx="${cx+q[0]*hw}" cy="${cy+q[1]*hh}" r="${(hw*.12).toFixed(1)}" fill="#4a9a5a"/>`).join('');
    if(Kc==='spblossom')s+=dome('#ffb8d0',yb)+flower2D(cx,cy-hh*1.18,18,'#ffffff','#ff7aa8');
    if(Kc==='spduck')s+=dome('#ffd23f',yb)+[-1,1].map(g=>`<circle cx="${cx+g*hw*.32}" cy="${cy-hh*.9}" r="9" fill="#ffffff" ${ol(2.4)}/><circle cx="${cx+g*hw*.32+1}" cy="${cy-hh*.9+1}" r="4.4" fill="${K}"/>`).join('')+
      `<path d="M${cx-hw*.42} ${yb-6} Q${cx} ${yb+16} ${cx+hw*.42} ${yb-6} Q${cx} ${yb+2} ${cx-hw*.42} ${yb-6} Z" fill="#ff9a2a" ${ol(2.6)}/><path d="M${cx-4} ${cy-hh*1.2} q-4 -16 8 -20 q-2 8 4 12" fill="#ffd23f" ${ol(2.4)}/>`;
    if(Kc==='spegg'){const n=9;let d=`M${cx-hw*.98} ${yb}`;for(let i=1;i<=n;i++)d+=` L${(cx-hw*.98+i*hw*1.96/n).toFixed(1)} ${yb+(i%2?-12:2)}`;
      s+=`<path d="${d} L${cx+hw*.98} ${yb} Q${cx+hw*.98} ${cy-hh*1.22} ${cx} ${cy-hh*1.26} Q${cx-hw*.98} ${cy-hh*1.22} ${cx-hw*.98} ${yb} Z" fill="#f4ecd8" ${S}/>`+[[-.5,-.9],[.1,-1.1],[.55,-.85],[-.15,-.75]].map(q=>`<ellipse cx="${cx+q[0]*hw}" cy="${cy+q[1]*hh}" rx="4.5" ry="3.4" fill="#b89a6a"/>`).join('');}}
  return s;};
const _c3=cos3D;cos3D=function(L,b,h,c){const Kc=L.cos;if(!isS(Kc))return _c3(L,b,h,c);
  const bw=c.bw,lg=c.lg,helm=col=>{const hm=mk('hemi',col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;return hm;};
  switch(Kc){
   case'splamb':helm('#ffffff');[-1,1].forEach(s=>mk('sph','#3a3640',.22,.08,.12,s*.62,.22,0,h));for(let i=0;i<6;i++){const a=i/6*PI*2;mk('sph','#ffffff',.2,.18,.2,Math.cos(a)*.42*bw,1.0,Math.sin(a)*.5*lg,b);}break;
   case'spbunny':helm('#f4ece4');[-1,1].forEach(s=>{const e=mk('sph','#f4ece4',.12,.44,.08,s*.22,.8,0,h);e.rotation.z=-s*.2;const i=mk('sph','#ffb0c8',.06,.32,.03,s*.23,.8,.07,h);i.rotation.z=-s*.2;});mk('sph','#ffffff',.2,.2,.2,0,.8,-.62*lg,b);break;
   case'spturtle':helm('#6abf6a');mk('sph','#3f8f5a',.66*bw,.34,.78*lg,0,.98,0,b);break;
   case'spblossom':helm('#ffb8d0');for(let i=0;i<5;i++){const a=i/5*PI*2+PI/2;mk('sph','#ffd0e0',.3,.3,.06,Math.cos(a)*.64,.12+Math.sin(a)*.58,-.12,h);}mk('sph','#ffffff',.14,.1,.14,0,.62,0,h);break;
   case'spduck':helm('#ffd23f');mk('box','#ff9a2a',.38,.06,.26,0,.4,.42,h);[-1,1].forEach(s=>{mk('sph','#ffffff',.09,.09,.05,s*.17,.56,.4,h);mk('sph','#ffd23f',.13,.26,.42,s*(.55*bw+.1),.78,0,b);});break;
   case'spegg':helm('#f4ecd8');for(let i=0;i<8;i++){const a=i/8*PI*2,cn=mk('cone','#f4ecd8',.08,.16,.08,Math.cos(a)*.6,.02,Math.sin(a)*.58,h);cn.rotation.x=PI;}mk('sph','#f4ecd8',.72*bw,.42,.84*lg,0,.5,0,b);break;}};

/* ---------------- who wears what in spring ---------------- */
const NUMS={digit:'1',dot:'2',doodle:'10',zero:'0',ruler:'12',paddle:'5',cube:'8',prism:'3',pie:'π',seven:'7',infinity:'∞',plus:'+',pretzel:'6'};
const KIT={
 meadow:(i,p)=>{const k=i%3;return {h:k===0?['flowercrown',FLC[i%6]]:k===1?['strawhat',FLC[(i+2)%6]]:['flowercrown',FLC[(i+4)%6]],n:k===1?[['neckerchief',['#e8423a','#3d8fe0','#3fae5a'][i%3]]]:null,f:i%2?['wellies',['#ffd23f','#3fae5a','#e8423a'][i%3]]:null,p:[['basket','egg','butterfly','duck'][i%4]],drop:['scarf','bow','flower']};},
 snowy:(i,p)=>({h:i%2?['bunnyears',i%4===1?'#ffffff':'#f4ece4']:['flowercrown',FLC[i%6]],p:i%3===0?['egg']:null,drop:['mittens']}),
 reef:(i,p)=>({g:i%3===2?['snorkel']:null,n:i%3===2?null:[['lei']],p:i%2?['shell']:null,keep:['bubbles'],drop:['shellneck']}),
 ninja:(i,p)=>({h:['headband',['#ff9ac0','#ffffff','#ffb8d0','#8ae05a'][i%4]],p:[i%2?'kite':'fan'],drop:['scarf','bow']}),
 number:(i,p)=>({h:i%2?['bunnyears']:null,n:[['num',YEL,{num:NUMS[p.id]||String(i+1)}]],p:i%2?null:['basket'],drop:['scarf','flower','bow']}),
 gadget:(i,p)=>({h:i%2?['propeller']:['flowercrown',FLC[i%6]],g:i%3===0?['pixel']:null,p:i%2?['peapod']:null,drop:['scarf','bow']}),
 rescue:(i,p)=>({h:['souwester'],f:['wellies',['#ffd23f','#e8423a','#3fae5a'][i%3]],n:i%2?[['binocs']]:null,drop:['scarf','glow']}),
 dino:(i,p)=>({h:i%2?['explorer']:['pith'],p:['egg']}),
 planet:(i,p)=>({space:{trim:PINK},p:i%2?['egg']:null})};
const COSTUME={meadow:'splamb',snowy:'spbunny',reef:'spturtle',ninja:'spblossom',number:'bee',gadget:'robot',rescue:'spduck',dino:'spegg',planet:'ladybird'};
const SPOUT={primrose:{h:['flowercrown','#ffe066'],f:['wellies','#5ab8ff']},tulip:{h:['flowercrown','#ff6a8a'],p:['basket']}};
const CWHO={};
ISLANDS.forEach(I=>{const f=KIT[I.id];if(!f)return;const cp=I.pups.find((p,i)=>i>=4&&!(p.look&&p.look.ninja));I.pups.concat(I.bonus||[]).forEach((p,i)=>{const cs=p===cp&&COSTUME[I.id];if(cs)CWHO[p.id]=cs;SPOUT[p.id]=cs?{cos:cs}:f(i,p);const S=SPOUT[p.id];for(const k in S)if(S[k]==null)delete S[k];});});
/* the unicorns in spring: a flower crown */
const UNI={h:['flowercrown',PINK]};
const isPup=p=>!!(p&&p.id&&(PUPS[p.id]||SPUPS[p.id]));
const sOn=()=>!!(typeof state!=='undefined'&&state&&state.season==='sp');
const s0=window.SEASONSPEC;
window.SEASONSPEC=function(p,is2D){const prev=()=>s0?s0(p,is2D):null;if(!p||!p.id||p.guest)return prev();
  if(p.sp){if(p.uni)return UNI;if(!isPup(p))return null;const R=PUPS[p.id]||SPUPS[p.id];if(R.breed!==p.breed)return null;return SPOUT[p.id]||null;}
  if(!is2D&&sOn()&&!p.xmas&&!p.glow&&!p.hw&&!p.sb){if(p.uni||!isPup(p))return null;const R=PUPS[p.id]||SPUPS[p.id];if(R.breed!==p.breed)return null;return SPOUT[p.id]||null;}
  return prev();};

/* a spring copy of a pup, for 2D pictures and cards */
const sp=p=>p?Object.assign({},p,{sp:true}):p;
window.SPLOOK={SPUPS,FACT,SPOUT,sp,UNI,COSTUME,CWHO,PINK,LEAF,SKY,YEL,FLC,flower2D,egg2D};
})();
