/* ================================================================
   Seb's Puppy Quest 3: tiny planets (Release 8, Planet Hop).
   A planet area is a square map that wraps round at the edges (walk
   off one side and you come back on the other, so there are no edges),
   drawn bent round a little ball under Seb: the ground curves away on
   every side and things sink below the horizon as Seb walks away.
   The bend happens in the shaders (every built-in material gets it,
   switched on by a shared uniform), sprites are bent on the CPU just
   before drawing. Game logic stays flat: x and z as usual.
   An area opts in with  A.planet={L,Rs,lowG}  (L map size, Rs radius).
   Also: space skies (stars, planets, the Sun, a black hole, nebulas),
   hop pads between planets, low gravity bounces and pup bubbles.
   ================================================================ */
(function(){
const PV=new Float32Array([0,0,96,0]),PQ=new Float32Array([38,0,0,0]);
/* ---------- shaders: bend and wrap every vertex round the planet ---------- */
THREE.ShaderChunk.common+='\nuniform vec4 planetP;\nuniform vec4 planetQ;\n';
THREE.ShaderChunk.project_vertex=`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_INSTANCING
mvPosition = instanceMatrix * mvPosition;
#endif
vec3 plK = vec3( 0.0 ); float plS = 0.0; float plC = 1.0;
#ifndef NO_PLANET
if ( planetP.w > 0.5 ) {
  vec4 plW = modelMatrix * mvPosition; vec2 plD = plW.xz - planetP.xy;
  if ( abs( plD.x ) < planetP.z * 3.0 && abs( plD.y ) < planetP.z * 3.0 ) {
    plD = mod( plD + planetP.z * 0.5, planetP.z ) - planetP.z * 0.5;
    float plR = length( plD ); float plT = plR / planetQ.x; vec2 plDir = plR > 0.0001 ? plD / plR : vec2( 0.0, 1.0 );
    plS = sin( plT ); plC = cos( plT ); float plH = planetQ.x + plW.y;
    plW.xyz = vec3( planetP.x + plH * plS * plDir.x, - planetQ.x + plH * plC, planetP.y + plH * plS * plDir.y );
    plK = normalize( mat3( viewMatrix ) * vec3( plDir.y, 0.0, - plDir.x ) );
  }
  mvPosition = viewMatrix * plW;
} else { mvPosition = modelViewMatrix * mvPosition; }
#else
mvPosition = modelViewMatrix * mvPosition;
#endif
gl_Position = projectionMatrix * mvPosition;`;
THREE.ShaderChunk.planet_normal=`#ifndef NO_PLANET
if ( plS != 0.0 ) { transformedNormal = transformedNormal * plC + cross( plK, transformedNormal ) * plS + plK * dot( plK, transformedNormal ) * ( 1.0 - plC ); }
#endif`;
['lambert','phong','standard','physical','toon','normal'].forEach(k=>{const S=THREE.ShaderLib[k];if(S&&S.vertexShader.indexOf('#include <project_vertex>')>=0&&S.vertexShader.indexOf('defaultnormal_vertex')>=0)S.vertexShader=S.vertexShader.replace('#include <project_vertex>','#include <project_vertex>\n#include <planet_normal>');});
Object.keys(THREE.ShaderLib).forEach(k=>{const S=THREE.ShaderLib[k];if(S&&S.uniforms){S.uniforms.planetP={value:PV};S.uniforms.planetQ={value:PQ};}});

/* ---------- maths ---------- */
const wrapD=(d,L)=>d-L*Math.floor((d+L/2)/L);
const V=new THREE.Vector3();
function bend(x,y,z,o){const L=PV[2],Rs=PQ[0];let dx=x-PV[0],dz=z-PV[1];
  if(Math.abs(dx)>L*3||Math.abs(dz)>L*3){o.set(x,y,z);return o;}
  dx=wrapD(dx,L);dz=wrapD(dz,L);const r=Math.hypot(dx,dz),t=r/Rs,h=Rs+y,s=Math.sin(t),c=Math.cos(t),ux=r>1e-4?dx/r:0,uz=r>1e-4?dz/r:1;
  return o.set(PV[0]+h*s*ux,-Rs+h*c,PV[1]+h*s*uz);}
const on=()=>PV[3]>.5;
window.PLANET={PV,PQ,bend,wrapD,on};

/* ---------- sprites are bent on the CPU just before drawing, then put back ---------- */
const moved=[];
function preRender(){if(!on())return;moved.length=0;
  const doSp=sp=>{if(!sp.isSprite||!sp.visible)return;moved.push(sp,sp.position.x,sp.position.y,sp.position.z);bend(sp.position.x,sp.position.y,sp.position.z,V);sp.position.copy(V);};
  W.ag.children.forEach(doSp);W.fl.forEach(f=>doSp(f.sp));}
function postRender(){for(let i=0;i<moved.length;i+=4)moved[i].position.set(moved[i+1],moved[i+2],moved[i+3]);moved.length=0;}
function hookRender(){if(!R3||R3._planet)return;const r=R3.render.bind(R3);R3.render=function(s,c){preRender();try{r(s,c);}finally{postRender();}};R3._planet=true;}

/* ---------- the ground: exactly one map square, so it wraps without a seam ---------- */
const _bg=buildGround;buildGround=function(A){if(!A.planet)return _bg(A);
  const L=A.planet.L,n=Math.round(L/1.2),geo=new THREE.PlaneGeometry(L,L,n,n);geo.rotateX(-Math.PI/2);
  const p=geo.attributes.position,colA=new Float32Array(p.count*3),c1=new THREE.Color(A.ground),c2=new THREE.Color(A.ground2||A.ground),t=new THREE.Color();
  for(let i=0;i<p.count;i++){const x=p.getX(i),z=p.getZ(i);p.setY(i,A.hf?A.hf(x,z):0);const k=A.gmix?A.gmix(x,z):(Math.sin(x*.2)+Math.sin(z*.17+x*.05)+2)*.25;t.copy(c1).lerp(c2,Math.max(0,Math.min(1,k)));colA[i*3]=t.r;colA[i*3+1]=t.g;colA[i*3+2]=t.b;}
  geo.setAttribute('color',new THREE.BufferAttribute(colA,3));geo.computeVertexNormals();
  W.gm={x0:-L/2,z0:-L/2,sx:L/n,sz:L/n,nx:n,nz:n,Y:p.array};
  const m=new THREE.Mesh(geo,new THREE.MeshLambertMaterial({vertexColors:true}));W.ag.add(m);W.disp.push(geo,m.material);};
/* bumps that repeat with the map, so the wrap has no seam */
window.planetHF=function(L,bumps,craters){return (x,z)=>{let h=0;const k=6.2832/L;(bumps||[]).forEach(b=>{h+=b[0]*Math.sin(k*b[1]*x+(b[3]||0))*Math.cos(k*b[2]*z+(b[4]||0));});
  (craters||[]).forEach(c=>{const dx=wrapD(x-c[0],L),dz=wrapD(z-c[1],L),r=Math.hypot(dx,dz)/c[2];if(r<1.35){h+=r<1?-c[3]*(1-r*r):c[3]*.6*Math.sin((r-1)/.35*Math.PI);}});return h;};};

/* ---------- moving about: no edges, things collide across the wrap ---------- */
const _res=resolve;resolve=function(x,z){const A=W.area;if(!A||!A.planet)return _res(x,z);const L=A.planet.L;
  for(const c of W.cols){const dx=wrapD(x-c.x,L),dz=wrapD(z-c.z,L),d=Math.hypot(dx,dz),m=c.r+.55;if(d<m){if(d<1e-4){x+=m;continue;}x+=dx/d*m-dx;z+=dz/d*m-dz;}}
  return [x,z];};

/* ---------- space skies ---------- */
const SKYT={};
function cv(k,w,h,draw){if(SKYT[k])return SKYT[k];const c=document.createElement('canvas');c.width=w;c.height=h||w;draw(c.getContext('2d'),w,h||w);const t=new THREE.CanvasTexture(c);return SKYT[k]=t;}
const ball=(g,cx,cy,r,col,shadow)=>{const gr=g.createRadialGradient(cx-r*.35,cy-r*.35,r*.1,cx,cy,r);gr.addColorStop(0,col[0]);gr.addColorStop(.7,col[1]);gr.addColorStop(1,shadow||'#000000');g.fillStyle=gr;g.beginPath();g.arc(cx,cy,r,0,6.2832);g.fill();};
const glow=(g,cx,cy,r0,r1,c,a)=>{const gr=g.createRadialGradient(cx,cy,r0,cx,cy,r1);gr.addColorStop(0,c);gr.addColorStop(1,'rgba(0,0,0,0)');g.globalAlpha=a==null?1:a;g.fillStyle=gr;g.beginPath();g.arc(cx,cy,r1,0,6.2832);g.fill();g.globalAlpha=1;};
const SKY={
  earth:()=>cv('earth',256,0,(g,w)=>{glow(g,128,128,100,128,'rgba(120,190,255,.7)');ball(g,128,128,100,['#7fc4ff','#2f6fd0'],'#0c2050');g.save();g.beginPath();g.arc(128,128,100,0,6.2832);g.clip();
    g.fillStyle='#5fbf5a';[[90,100,34,22],[150,80,26,18],[160,150,30,40],[80,165,20,14],[118,120,14,10]].forEach(q=>{g.beginPath();g.ellipse(q[0],q[1],q[2],q[3],q[0]*.03,0,6.2832);g.fill();});
    g.fillStyle='rgba(255,255,255,.75)';[[70,70,40,7],[140,115,46,6],[100,190,52,7],[175,60,22,5],[60,135,30,5]].forEach(q=>{g.beginPath();g.ellipse(q[0],q[1],q[2],q[3],-.3,0,6.2832);g.fill();});
    const sh=g.createLinearGradient(40,40,230,230);sh.addColorStop(0,'rgba(0,0,0,0)');sh.addColorStop(.55,'rgba(0,0,0,0)');sh.addColorStop(1,'rgba(0,0,20,.75)');g.fillStyle=sh;g.fillRect(0,0,256,256);g.restore();}),
  jupiter:()=>cv('jupiter',512,0,(g)=>{g.save();g.beginPath();g.arc(256,256,240,0,6.2832);g.clip();const cols=['#f3e2c6','#d9a46a','#efd2a8','#b97a4a','#f7e6cc','#c98a5a','#ead0a8','#a8683a','#f0dcc0','#d9a46a'];
    for(let i=0;i<cols.length;i++){g.fillStyle=cols[i];g.fillRect(0,16+i*48,512,52);}for(let i=0;i<40;i++){g.fillStyle='rgba(255,255,255,.12)';g.beginPath();g.ellipse((i*97)%512,30+(i*61)%460,40,5,0,0,6.2832);g.fill();}
    g.fillStyle='#c9502a';g.beginPath();g.ellipse(330,320,54,30,0,0,6.2832);g.fill();g.fillStyle='#e8805a';g.beginPath();g.ellipse(330,320,36,18,0,0,6.2832);g.fill();
    const sh=g.createRadialGradient(200,200,60,256,256,250);sh.addColorStop(0,'rgba(0,0,0,0)');sh.addColorStop(.8,'rgba(0,0,0,.05)');sh.addColorStop(1,'rgba(0,0,0,.55)');g.fillStyle=sh;g.fillRect(0,0,512,512);g.restore();}),
  saturn:()=>cv('saturn',512,256,(g)=>{const ring=(front)=>{g.save();g.translate(256,128);g.rotate(-.18);g.scale(1,.28);for(let r=0;r<6;r++){g.strokeStyle=['#e8d6a8','#c9b088','#f2e6c6','#bfa070','#e0cc9a','#a88a5a'][r];g.lineWidth=13;g.beginPath();g.arc(0,0,170+r*12,front?0:Math.PI,front?Math.PI:6.2832);g.stroke();}g.restore();};
    ring(false);ball(g,256,128,100,['#f7e3a8','#e0b860'],'#5a4020');g.save();g.beginPath();g.arc(256,128,100,0,6.2832);g.clip();for(let i=0;i<6;i++){g.fillStyle=`rgba(${i%2?'190,140,60':'255,240,200'},.25)`;g.fillRect(140,50+i*26,240,12);}g.restore();ring(true);}),
  sun:()=>cv('sun',512,0,(g)=>{glow(g,256,256,60,256,'rgba(255,190,80,.9)');glow(g,256,256,100,200,'rgba(255,230,120,.8)');ball(g,256,256,130,['#fffbe0','#ffd23f'],'#ff9a3c');
    g.strokeStyle='rgba(255,140,60,.7)';g.lineWidth=10;[[0.4,1],[2.2,.8],[4,1.1]].forEach(q=>{g.beginPath();g.arc(256+Math.cos(q[0])*140,256+Math.sin(q[0])*140,40*q[1],q[0]+2.2,q[0]+5.4);g.stroke();});}),
  hole:()=>cv('hole',512,256,(g)=>{g.save();g.translate(256,128);g.scale(1,.42);for(let r=230;r>70;r-=6){const t=(r-70)/160;g.strokeStyle=`rgba(${Math.round(255-60*t)},${Math.round(120+80*(1-t))},${Math.round(200*t+40)},${.18+.5*(1-t)})`;g.lineWidth=7;g.beginPath();g.arc(0,0,r,0,6.2832);g.stroke();}g.restore();
    glow(g,256,128,40,90,'rgba(255,210,120,.9)');g.fillStyle='#000';g.beginPath();g.arc(256,128,58,0,6.2832);g.fill();g.strokeStyle='#ffd27a';g.lineWidth=5;g.beginPath();g.arc(256,128,60,0,6.2832);g.stroke();
    g.save();g.translate(256,128);g.scale(1,.42);g.strokeStyle='rgba(255,190,90,.85)';g.lineWidth=14;g.beginPath();g.arc(0,0,120,0,Math.PI);g.stroke();g.restore();}),
  neb:(c1,c2,k)=>cv('neb'+k,256,0,(g)=>{for(let i=0;i<14;i++){const x=40+((i*67)%180),y=40+((i*41)%180),r=40+(i%4)*14;glow(g,x,y,0,r,i%2?c1:c2,.35);}}),
  moonlet:(k,c)=>cv('ml'+k,128,0,(g)=>{g.fillStyle=c||'#9a8f84';g.beginPath();g.ellipse(64,64,50,36,.4,0,6.2832);g.fill();g.fillStyle='rgba(0,0,0,.2)';[[50,58,8],[78,72,10],[66,46,5]].forEach(q=>{g.beginPath();g.arc(q[0],q[1],q[2],0,6.2832);g.fill();});}),
  dot:(k,c)=>cv('dot'+k,128,0,(g)=>{glow(g,64,64,0,64,c,.6);ball(g,64,64,22,[c,c],'#20202a');}),
  band:()=>cv('band',512,128,(g)=>{for(let i=0;i<260;i++){const x=(i*53)%512,y=64+Math.sin(i*1.7)*26*Math.random();g.fillStyle=`rgba(255,255,255,${.15+.4*Math.random()})`;g.fillRect(x,y,1.5,1.5);}glow(g,256,64,0,250,'rgba(200,190,255,.35)',.8);})};
let skyG=null;
function buildSky(A){if(skyG){scene.remove(skyG);skyG=null;}const S=A.space;if(!S)return;skyG=new THREE.Group();scene.add(skyG);
  const stars=(n,d,size,col)=>{const p=new Float32Array(n*3),R2=seed(n*7+3);for(let i=0;i<n;i++){const u=R2()*2-1,a=R2()*6.2832,s=Math.sqrt(1-u*u);p[i*3]=Math.cos(a)*s*d;p[i*3+1]=u*d;p[i*3+2]=Math.sin(a)*s*d;}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(p,3));const m=new THREE.PointsMaterial({color:col,size,sizeAttenuation:false,fog:false,transparent:true,opacity:.95,depthWrite:false});m.defines={NO_PLANET:''};skyG.add(new THREE.Points(g,m));};
  if(S.stars!==false){stars(900,640,1.6,'#ffffff');stars(220,640,2.8,'#fff6d8');stars(120,640,2.2,S.starTint||'#cfe0ff');}
  const put=(tex,az,el,w,h,op)=>{const m=new THREE.SpriteMaterial({map:tex,transparent:true,depthWrite:false,fog:false,opacity:op==null?1:op}),s=new THREE.Sprite(m);const D=Math.PI/180,d=560;
    s.position.set(Math.cos(az*D)*Math.cos(el*D)*d,Math.sin(el*D)*d,Math.sin(az*D)*Math.cos(el*D)*d);s.scale.set(w,h||w,1);skyG.add(s);return s;};
  if(S.band)put(SKY.band(),S.band,4,900,180,.8);
  (S.items||[]).forEach(o=>{const t=o.k==='neb'?SKY.neb(o.c1,o.c2,o.key||o.c1):o.k==='moonlet'?SKY.moonlet(o.key||'a',o.c):o.k==='dot'?SKY.dot(o.key||o.c,o.c):SKY[o.k]();const s=put(t,o.az,o.el,o.size,o.h||(o.k==='saturn'||o.k==='hole'?o.size/2:o.size),o.op);s.userData.spin=o.spin||0;});}
function skyTick(){if(!skyG)return;skyG.position.copy(cam.position);}

/* ---------- hop pads (planet exits) ---------- */
function hopper3D(c){const g=grp();mk('cyl','#f4f6fb',.55,2.2,.55,0,1.9,0,g);mk('cone',c||'#e8423a',.55,1,.55,0,3.5,0,g);mk('cyl','#9bdcff',.3,.12,.3,0,2.4,.48,g).rotation.x=Math.PI/2;
  [0,2.09,4.19].forEach(a=>{const f=mk('box',c||'#e8423a',.08,.9,.7,Math.sin(a)*.55,1.1,Math.cos(a)*.55,g);f.rotation.y=a;});mk('cyl','#5b6378',.4,.4,.4,0,.65,0,g);return g;}
function hopPad(e){const y=gy(e.x,e.z),pad=grp();mk('cyl','#c9d2e3',2.6,.35,2.6,0,.18,0,pad);mk('cyl','#5b6378',2.2,.06,2.2,0,.38,0,pad);
  const ring=new THREE.Mesh(G.ring,new THREE.MeshBasicMaterial({color:e.col||'#7fe0ff'}));ring.scale.set(2.35,2.35,2.35);ring.rotation.x=Math.PI/2;ring.position.y=.42;pad.add(ring);W.disp.push(ring.material);
  const h=hopper3D(e.col2);h.position.set(1.4,.35,-1.2);h.scale.setScalar(.8);pad.add(h);add(pad,e.x,e.z,y);{const lb=label((e.icon||'')+' '+e.name,6);lb.position.set(e.x,y+6.4,e.z);W.ag.add(lb);}
  W.ticks.push(()=>{ring.material.color.setHSL(.5+Math.sin(W.t*2)*.05,.8,.6+Math.sin(W.t*4)*.1);h.position.y=.35+Math.abs(Math.sin(W.t*1.5))*.15;});}

/* ---------- each frame on a planet ---------- */
let bubbles=[];
function clearBubbles(){bubbles.forEach(b=>scene.remove(b.m));bubbles=[];}
function planetTick(dt){const A=W.area;if(!A||!A.planet)return;const P=player,L=A.planet.L,h=L/2;
  /* walk off one side, come back on the other */
  let sx=0,sz=0;if(P.x>h)sx=-L;else if(P.x<-h)sx=L;if(P.z>h)sz=-L;else if(P.z<-h)sz=L;
  if(sx||sz){P.x+=sx;P.z+=sz;cam.position.x+=sx;cam.position.z+=sz;followers.forEach(f=>{f.x+=sx;f.z+=sz;});}
  followers.forEach(f=>{f.x=P.x+wrapD(f.x-P.x,L);f.z=P.z+wrapD(f.z-P.z,L);f.grp.position.x=f.x;f.grp.position.z=f.z;});
  P.grp.position.x=P.x;P.grp.position.z=P.z;
  PV[0]=P.x;PV[1]=P.z;
  /* low gravity: slow floaty bounces */
  if(A.planet.lowG){const k=P.moving?1:0;P.bounce=(P.bounce||0)+(k-(P.bounce||0))*Math.min(1,dt*4);P.grp.position.y+=Math.abs(Math.sin(P.wt*4.2))*1.1*P.bounce+Math.sin(W.t*1.3)*.05;
    followers.forEach((f,i)=>{f.grp.position.y+=f.moving?Math.abs(Math.sin(W.t*4.5+i*1.3))*.9:Math.sin(W.t*1.4+i)*.12;});
    if(P.moving&&Math.random()<dt*1.6)floatS('💨',P.x-Math.sin(P.h)*.6,gy(P.x,P.z)+.4,P.z-Math.cos(P.h)*.6,1,.8);}
  /* bubble helmets for the pups */
  if(bubbles.length!==followers.length||bubbles.some((b,i)=>b.f!==followers[i])){clearBubbles();followers.forEach(f=>{const m=new THREE.Mesh(G.sph,new THREE.MeshLambertMaterial({color:'#dff4ff',transparent:true,opacity:.22,depthWrite:false}));m.scale.setScalar(1.25);scene.add(m);bubbles.push({f,m});});}
  bubbles.forEach(b=>{b.m.position.set(b.f.grp.position.x,b.f.grp.position.y+1.15,b.f.grp.position.z);b.m.visible=b.f.grp.visible;});
  if((W.cullT=(W.cullT||0)-dt)<0){W.cullT=.5;W.ag.children.forEach(c=>{if(c.frustumCulled!==false)c.traverse(o=>{o.frustumCulled=false;});});}
  skyTick();}

/* ---------- switching planets on and off as areas change ---------- */
function enterPlanet(A){hookRender();const P=A.planet;PV[2]=P.L;PQ[0]=P.Rs;PV[0]=player.x;PV[1]=player.z;PV[3]=1;
  buildSky(A);(player.grp.userData.helmet||[]).forEach(m=>m.visible=true);
  /* nothing may be culled by its flat position: the bend moves things */
  W.ag.traverse(o=>{o.frustumCulled=false;});player.grp.traverse(o=>{o.frustumCulled=false;});followers.forEach(f=>f.grp.traverse(o=>{o.frustumCulled=false;}));
  /* sprites inside groups come out to the top level, so they can be bent; they still follow their group's visibility */
  const nested=[];W.ag.children.forEach(c=>{if(c.isSprite)return;c.traverse(o=>{if(o.isSprite&&o.parent!==W.ag)nested.push(o);});});
  nested.forEach(s=>{const par=s.parent;s.userData.v0=s.visible;W.ag.attach(s);s.userData.par=par;});
  if(nested.length)W.ticks.push(()=>{nested.forEach(s=>{let v=s.userData.v0,o=s.userData.par;while(o&&o!==W.ag){if(!o.visible){v=false;break;}o=o.parent;}s.visible=v;});});
  W.ticks.unshift(dt=>{planetTick(dt);});}
function leavePlanet(){PV[3]=0;if(skyG){scene.remove(skyG);skyG=null;}clearBubbles();player.bounce=0;}
const _ea=enterArea;enterArea=function(id,pos,msg){_ea(id,pos,msg);const A=W.area;if(!W.ready||!A)return;if(A.planet)enterPlanet(A);else leavePlanet();};
/* hop pads are built after the exits, before scenery */
const _en=enrich;enrich=function(A){if(A&&A.planet&&W.exits)W.exits.forEach(e=>{if(e.hop){hopPad(e);if(e.gate)buildTypeGate(e);if(e.nlock)buildNumLock(e);}});return _en.apply(this,arguments);};

/* ---------- Release 8 Pup Types and their gate looks ---------- */
TYPES.stone={name:'Stone',icon:'🪨',col:'#9a7350',power:'digs through rockfalls'};
TYPES.comet={name:'Comet',icon:'☄️',col:'#5b6fe0',power:'switches off gravity, so heavy things float'};
GATE_LOOKS.rockfall=function(blk,grow){[[0,1.4,0,2.2],[-2.2,1.1,.3,1.7],[2.2,1.2,-.2,1.8],[-1,3.1,0,1.5],[1.2,3,.2,1.4],[0,4.3,0,1.1],[-3,.6,.6,1],[3,.7,.5,1.1]].forEach((q,i)=>{const r=mk('sph',['#8a7a6a','#a08a72','#6b5e52'][i%3],q[3],q[3]*.85,q[3]*.9,q[0],q[1],q[2],blk);r.rotation.set(i,i*2,0);});
  [-3.4,3.4].forEach(x=>{mk('sph','#8a7a6a',1.6,1.2,1.4,x,.6,0,grow);mk('sph','#a08a72',1,.8,1,x*.8,1.6,.2,grow);});for(let i=0;i<5;i++)mk('sph','#6b5e52',.4,.3,.4,-2+i,.15,1.6-(i%2),grow);};
GATE_LOOKS.floatrock=function(blk,grow){const r=mk('sph','#7a6e66',2.7,2.3,2.5,0,2.3,0,blk);mk('sph','#5b524c',1.2,1,1.2,1.6,3.4,.8,blk);mk('box','#4a423e',.12,2.4,.1,-.6,2.6,2.3,blk);
  const g=grp();mk('sph','#7a6e66',2,1.7,1.9,0,0,0,g);g.position.y=7.5;grow.add(g);for(let i=0;i<6;i++)mk('sph','#c9d6ff',.18,.18,.18,Math.cos(i)*2.6,7.5+Math.sin(i*2),Math.sin(i)*2.6,grow);};

/* ---------- riding: Seb rides Boulder or the Mars rover in some activities ---------- */
const RIDES={};let ride=null;
window.regRide=(k,fn,h)=>{RIDES[k]={fn,h:h||1.4};};
function rideStop(){if(!ride)return;scene.remove(ride.g);ride=null;const u=player.grp.userData;if(u.legs)u.legs.forEach(l=>{l.rotation.z=0;});}
function rideStart(k){rideStop();const R=RIDES[k];if(!R)return;const g=R.fn();scene.add(g);g.traverse(o=>{o.frustumCulled=false;});ride={k,g,h:R.h};
  W.ticks.push(dt=>{if(!ride||!W.act){rideStop();return true;}const P=player,u=P.grp.userData;g.position.set(P.x,walkY(P.x,P.z),P.z);g.rotation.y=P.h;P.grp.position.y+=ride.h;
    if(u.legs)for(let i=0;i<2;i++){u.legs[i].rotation.x=-1.25;u.legs[i].rotation.z=(i?-1:1)*.5;u.knees[i].rotation.x=1.45;u.arms[i].rotation.x=-1;}
    if(g.userData.tick)g.userData.tick(W.t,P.moving);});}
const _sc=startCollect;startCollect=function(k){_sc.apply(this,arguments);const C=COLLECT[k];if(C&&C.ride&&W.act&&W.act.k===k)rideStart(C.ride);};
window.RIDE={start:rideStart,stop:rideStop};
const _ea2=enterArea;enterArea=function(){rideStop();return _ea2.apply(this,arguments);};
window.PLANET.hopper3D=hopper3D;window.PLANET.SKY=SKY;window.PLANET.cv=cv;window.PLANET.glow=glow;window.PLANET.ball=ball;
})();
