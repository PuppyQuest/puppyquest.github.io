/* ================================================================
   Puppy Families (26 Nov 2026, claude/puppy-families-design.md sections 10 and 14): Granny's Pup Book and the Family cards.
   - the Pup Book: a first page for the basket family, a page per island (an empty photo corner shows a faint
     outline of the parent), a page per family (names, small differences, stage, care stickers, renaming),
     and a last page that is stuck shut until the Puppy Parade;
   - a Family card for every family (117): the parent with its three puppies, the parent's stats (the saga's
     fixed scale), the everyday move "Puppy Pile-On"; a 👪 Families tab on the Seasons shelf, packs per area.
   Hooks: window.XCARDS, window.SEALOOK['f:'], window.SEAPACK.f_, CLOOK.EDGE.pf, a hidden SEASONS.pf entry
   (not enumerable, so the Season Globe never lists it; the binder and card games read its icon and name).
   ================================================================ */
(function(){
const PL=window.PFLOOK,PF=window.PF,P=id=>PUPS[id];
const X0=()=>PF.S0()||{};
const dstr=d=>d&&d>1e12?new Date(d).toLocaleDateString('en-GB',{day:'numeric',month:'long',year:'numeric'}):'';
const HOW={basket:'🧺 Born in the basket in Seb\'s Den',peek:'👢 Found peeking out of hiding places',trail:'🪨 Found at the end of a counting trail',pile:'🧺 Found in a puppy pile'};
const STK={blanket:'🧣',quiet:'🤫',weigh:'⚖️',mash:'🥣',toys:'⚽',doctor:'🩺',school:'🎓',walk:'🦮',bath:'🫧'};
const islFams=I=>I.pups.concat(I.bonus||[]).map(p=>p.id);
/* ---------------- the Pup Book ---------------- */
let PG=0,FAM=null;
function ui(){if($('#pfbook'))return;const d=el('div','ov','<div class="card" id="pfbCard"><button class="btn white rnd" id="pfbX">✕</button><div id="pfbTabs"></div><div id="pfbPage"></div><div class="pfbNav"><button class="btn white" id="pfbPrev">◀</button><span id="pfbN"></span><button class="btn white" id="pfbNext">▶</button></div></div>');d.id='pfbook';document.body.appendChild(d);
  tap('#pfbX',()=>{sfx.boop();close();});tap('#pfbPrev',()=>{sfx.boop();FAM=null;PG=Math.max(0,PG-1);draw();});tap('#pfbNext',()=>{sfx.boop();FAM=null;PG=Math.min(nPages()-1,PG+1);draw();});}
const nPages=()=>ISLANDS.length+2;
function open(pg,fam){if(!PF.begun()){say('Granny\'s Pup Book will be ready when Puppy Families begins!');return;}ui();hush();player.lock=true;PG=pg!=null?pg:0;FAM=fam||null;$('#pfbook').classList.add('on');sfx.chime();draw(true);}
function close(){$('#pfbook').classList.remove('on');player.lock=false;FAM=null;hush();}
function draw(talk){$('#pfbCard').classList.toggle('gold',PF.homes().length>=PF.famIds().length);const t=$('#pfbTabs');t.innerHTML=['📖'].concat(ISLANDS.map(I=>I.icon)).concat(['🔒']).map((ic,i)=>`<button class="tab${i===PG&&!FAM?' sel':''}" data-i="${i}">${i===nPages()-1&&X0().done?'📷':ic}</button>`).join('');
  t.querySelectorAll('.tab').forEach(b=>tap(b,()=>{sfx.boop();FAM=null;PG=+b.dataset.i;draw(true);}));
  $('#pfbN').textContent=FAM?'':`${PG+1} / ${nPages()}`;$('#pfbPrev').style.visibility=FAM||PG<=0?'hidden':'visible';$('#pfbNext').style.visibility=FAM||PG>=nPages()-1?'hidden':'visible';
  const pg=$('#pfbPage');if(FAM)return famPage(FAM,talk);
  if(PG===0){const b=X0().basket,n=PF.nPuppies(),h=PF.homes().length;pg.innerHTML=`<h2 class="pfbH">🐾 Granny's Pup Book</h2><div class="pfbFirst">${b?`<button class="pfslot big" data-f="${b.pid}">${PF.photo(b.pid,{w:300})}</button>`:''}<div class="pfbSum"><p>🐶 <b>${n}</b> puppies home</p><p>👪 <b>${h}</b> of ${PF.famIds().length} families</p><p class="pfbTip">Every new puppy in Pawprint Village gets a photo in this book. Tap a photo to see the family!</p></div></div>`;
    if(talk)speak(`Granny's Pup Book. ${n} puppies are home.`);}
  else if(PG<=ISLANDS.length){const I=ISLANDS[PG-1],L=islFams(I),done=L.filter(PF.home).length;
    pg.innerHTML=`<h2 class="pfbH">${I.icon} ${I.name} <small>${done} of ${L.length} families</small></h2><div class="pfbGrid">${L.map(id=>{const k=PF.nGot(id),h=k>=3,f=PF.famOf(id);
      return `<button class="pfslot${h?'':' empty'}" data-f="${h?id:''}">${PF.photo(id,{faint:!h,cap:h?P(id).name+'\'s family':`${P(id).name}: ${'🐾'.repeat(k)}${'·'.repeat(3-k)}`,st:h?PF.stg(id):1})}</button>`;}).join('')}</div>`;
    if(talk)speak(`${I.name}. ${done} of ${L.length} families are home.`);}
  else{const D=X0().done;pg.innerHTML=D&&window.PFSTORY&&PFSTORY.oldPhoto?`<h2 class="pfbH">📷 The very last page</h2><div class="pfbOld">${PFSTORY.oldPhoto()}</div>`:`<h2 class="pfbH">🔒 The last page</h2><div class="pfbStuck"><div class="pfbStuckPg">This page is stuck!</div><p>The last page of Granny's Pup Book won't open. Maybe it will come free one day...</p></div>`;if(talk)speak(D?'The very last page.':'This page is stuck!');}
  pg.querySelectorAll('.pfslot').forEach(b=>tap(b,()=>{const id=b.dataset.f;if(!id){sfx.oops();say('This family is still lost on the islands. Help its pup find the puppies!');return;}sfx.pop();FAM=id;draw(true);}));}
function famPage(id,talk){const p=P(id),f=PF.famOf(id),st=f.st||0,inRoom=window.PFROOM&&PFROOM.roomIds().indexOf(id)>=0,cl=f.cl||{};
  const pz=[0,1,2].map(i=>`<div class="pfbPup"><div class="fitsvg">${PL.svg(p,i,st,{anim:false,bd:f.bd,sleep:st===0})}</div><b>${PF.nm(id,i)} ${PF.girl(id,i)?'👧':'👦'}</b><small>${PL.diffText(p,i)}</small><button class="btn white pfren" data-i="${i}">✏️ Rename</button></div>`).join('');
  const stk=Object.keys(STK).filter(k=>cl[k]).map(k=>`<span title="${k}">${STK[k]}</span>`).join('')||'<i>No care stickers yet</i>';
  const tr=window.PFR3&&PFR3.tricks?PFR3.tricks(id):'';const fact=PL.FACT[st][PL.hs(id)%PL.FACT[st].length];
  $('#pfbPage').innerHTML=`<h2 class="pfbH">${p.name}'s family <small>${PL.STAGE[st].i} ${PL.STAGE[st].n}s</small></h2><div class="pfbFam"><div class="pfbFamL">${PF.photo(id,{w:280})}<p class="pfbHow">${HOW[f.how]||''}${f.at?'<br>📅 '+dstr(f.at):''}</p></div><div class="pfbFamR"><div class="pfbPups">${pz}</div>
    <p class="pfbStk">Care stickers: ${stk}</p>${tr}<p class="pfbFact">💡 ${fact}</p><div class="btns">${inRoom?'<span class="pfbIn">🐶 Playing in the Puppy Room</span>':'<button class="btn green" id="pfbRoom">🐶 To the Puppy Room</button>'}${window.PFR3&&PFR3.tagBtn?PFR3.tagBtn(id):''}<button class="btn white" id="pfbBack">◀ Back</button></div></div></div>`;
  if(talk)speak(`${p.name}'s family: ${PF.list3(PF.names(id))}.`);
  tap('#pfbBack',()=>{sfx.boop();FAM=null;draw();});
  if(!inRoom)tap('#pfbRoom',()=>{sfx.chime();const L=PFROOM.roomIds().filter(q=>q!==id);PF.S().room=[id].concat(L).slice(0,4);save();close();say(`${p.name}'s family is going to the Puppy Room!`);if(W.area&&W.area.id==='pfroom')enterArea('pfroom',[player.x,player.z,player.h],'');});
  if(window.PFR3&&PFR3.tagHook)PFR3.tagHook(id);
  document.querySelectorAll('#pfbPage .pfren').forEach(b=>tap(b,()=>rename(id,+b.dataset.i)));}
function rename(id,i){const p=P(id),f=PF.famOf(id),cur=PF.nm(id,i);sfx.chime();
  const d=el('div','pfren2',`<div class="pfrenBox"><h3>✏️ A new name for ${cur}?</h3><input id="pfRen" maxlength="18" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" value="${cur}"><div class="btns"><button class="btn green" id="pfRenOk">✓ OK</button><button class="btn white" id="pfRenNo">Cancel</button></div></div>`);
  $('#pfbCard').appendChild(d);const inp=$('#pfRen');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));inp.focus();inp.select();
  tap('#pfRenNo',()=>{sfx.boop();d.remove();});tap('#pfRenOk',()=>{const n=PF.cleanName(inp.value);if(n){f.n=f.n||[];f.n[i]=n;save();sfx.yip(1.8);speak(n);}d.remove();draw();});}

/* ---------------- the Family cards ---------------- */
const C=window.CARDS;if(C&&C.RAR){C.RAR.family=['Family','👪'];C.RAR.firstfam=['First Family','🧺'];}
const SZ={t:[50,10,30],s:[60,10,40],m:[70,20,50],l:[80,20,60],g:[90,30,70]};
const TM={leaf:'Vine Bridge',snow:'Snowdrift Sweep',water:'Stepping Stones',fire:'Lantern Glow',sky:'Float Bridge',spark:'Light Up',star:'Fog Shine',stone:'Rockfall Dig',comet:'Gravity Pull',dino:'Dino Stomp',planet:'Rocket Boost'};
const hs=PL.hs,cp=(v,a,b)=>Math.max(a,Math.min(b,v));
function fcard(p,set,n,of,isl){const B=C.breedOf(p.breed),T=C.TY(p.type),z=SZ[B.sz]||SZ.m,sh=p.shiny?10:0,st={spd:B.spd,brn:B.brn,cud:B.cud,brv:B.brv};
  st[C.STATS[hs(p.id)%4][0]]+=1;for(const k in st)st[k]=cp(st[k],1,10);
  const c={stats:st,zoom:cp(z[0]+sh,30,120),moves:[['Puppy Pile-On',1,z[1]],[TM[p.type]||'Pup Power',2,z[2]+sh]],col:T.col,bg:shade(T.col,.72)};
  Object.assign(c,{cid:'3:pf_'+p.id,game:3,set,n,of,src:p,base:p.id,name:`${p.name}'s family`,breed:p.breed,type:p.type,pf:true,fisl:isl});
  Object.defineProperty(c,'rar',{get(){return X0().basket&&X0().basket.pid===p.id?'firstfam':'family';},enumerable:true});
  Object.defineProperty(c,'fact',{get(){return `${PF.list3(PF.names(p.id))}: ${PL.FACT.g[hs(p.id)%PL.FACT.g.length]}`;},enumerable:true});
  c.home=()=>{const A=AREAS[p.area],I=islandOf(p.island);return (A?A.name:'')+(I?', '+I.name:'');};
  c.earned=()=>PF.home(p.id);c.foundAt=()=>(PF.famOf(p.id)||{}).at||0;
  c.art=an=>PL.famSVG(p,PF.stg(p.id),{bd:(PF.famOf(p.id)||{}).bd});
  c.hint=()=>PF.opened()?`${p.name}'s puppies are lost on the islands. Find ${p.name}, and help sniff them out!`:'Puppy Families opens after Spring Blossom is finished!';
  c.back=()=>{const d=c.foundAt(),f=PF.famOf(p.id)||{};return [`👪 ${PF.list3(PF.names(p.id))}`,`📍 ${c.home()}`,HOW[f.how]||'👪 A Puppy Family',`${PL.STAGE[f.st||0].i} ${PL.STAGE[f.st||0].n}s${d?' · '+dstr(d):''}`];};
  return c;}
const SETS={};
function mkSet(key){if(SETS[key])return SETS[key];const I=islandOf(key),L=I.pups.concat(I.bonus||[]),lock=()=>'Puppy Families opens after Spring Blossom is finished!';
  const S={id:'3:f_'+key,game:3,season:'pf',isl:'f_'+key,name:`${I.name} families`,short:I.name.split(' ')[0],icon:I.icon,open:()=>PF.opened(),lockSay:lock,cards:[]};
  S.cards=L.map((p,i)=>fcard(p,S.id,i+1,L.length,key));return (SETS[key]=S);}
function entry(key){const I=islandOf(key),pups=I.pups.concat(I.bonus||[]),areas=[...new Set(pups.map(p=>p.area))];
  const mine=cid=>cid.indexOf('3:pf_')===0&&pups.some(p=>cid==='3:pf_'+p.id),inA=a=>pups.filter(p=>p.area===a);
  return {isl:'f_'+key,season:'pf',keys:()=>areas.map(a=>'x:pf:'+a),set:()=>mkSet(key),
    ids(){if(!state)return [];return pups.filter(p=>PF.home(p.id)).map(p=>'3:pf_'+p.id);},
    key(cid){if(!mine(cid))return undefined;const p=PUPS[cid.slice(5)];return p?'x:pf:'+p.area:null;},
    done(k){return inA(k.slice(5)).every(p=>PF.home(p.id));},
    info(k){const a=k.slice(5),A=AREAS[a];return {k,isl:'f_'+key,icon:(A&&A.icon)||'👪',name:`${A?A.name:''} families`,short:A?A.name:'Families',pf:true};},
    say(k,c){const a=k.slice(5),A=AREAS[a],left=inA(a).filter(p=>!PF.home(p.id)).length;return `${c.name}'s card is waiting in the ${A?A.name:''} puppy carrier. Bring ${left} more ${left>1?'families':'family'} home from there to open it!`;}};}
window.XCARDS=(window.XCARDS||[]).concat(ISLANDS.map(I=>entry(I.id)));
/* a hidden entry in the seasons list: the binder and the card games read its icon and name; the Season Globe never lists it */
if(window.SEASONS&&!Object.prototype.hasOwnProperty.call(window.SEASONS,'pf'))Object.defineProperty(window.SEASONS,'pf',{enumerable:false,value:{id:'pf',icon:'👪',name:'Puppy Families',short:'Families',card:['👪','Puppy Families'],opened:()=>PF.opened(),named:()=>PF.begun(),order:99}});
/* the look: a nursery frame of paw prints and little bones */
const paw=(x,y,s,o,c)=>`<g opacity="${o}" fill="${c||'#ffb8d0'}"><ellipse cx="${x}" cy="${y}" rx="${5*s}" ry="${4.2*s}"/><circle cx="${x-5*s}" cy="${y-6*s}" r="${1.9*s}"/><circle cx="${x-1.7*s}" cy="${y-8*s}" r="${1.9*s}"/><circle cx="${x+1.7*s}" cy="${y-8*s}" r="${1.9*s}"/><circle cx="${x+5*s}" cy="${y-6*s}" r="${1.9*s}"/></g>`;
const bone=(x,y,s,o,c,r)=>`<g opacity="${o}" fill="${c||'#ffffff'}" transform="rotate(${r||0} ${x} ${y})"><rect x="${x-7*s}" y="${y-1.6*s}" width="${14*s}" height="${3.2*s}" rx="${1.4*s}"/><circle cx="${x-7*s}" cy="${y-2*s}" r="${2.2*s}"/><circle cx="${x-7*s}" cy="${y+2*s}" r="${2.2*s}"/><circle cx="${x+7*s}" cy="${y-2*s}" r="${2.2*s}"/><circle cx="${x+7*s}" cy="${y+2*s}" r="${2.2*s}"/></g>`;
const PATH=`<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">${paw(16,18,1,.5)}${bone(46,46,1,.6,'#ffffff',30)}${paw(46,16,.8,.45,'#a8dcff')}${bone(16,46,.8,.5,'#ffe066',-20)}</svg>`;
function over(i){const R=seed(i.length*37+5);let s=`<rect width="200" height="190" fill="#fff0f6" opacity=".35"/><path d="M0 150 Q60 136 120 148 T200 142 V190 H0 Z" fill="#ffd9a8" opacity=".55"/>`;
  for(let k=0;k<5;k++)s+=paw(20+R()*160,30+R()*100,1.2,.45,k%2?'#ffb8d0':'#a8dcff');for(let k=0;k<3;k++)s+=bone(30+R()*140,160+R()*20,1,.9,'#ffffff',R()*60-30);return s;}
const EDGE=()=>{let s=`<path d="M0 0 H400 V14 Q300 24 200 14 T0 16 Z" fill="#ffd0e0" opacity=".9"/>`;let k=0;for(let x=22;x<390;x+=40){s+=paw(x,10,1,1,k%2?'#ff9ac0':'#8fd0ff');k++;}
  for(let y=50;y<540;y+=42){[8,392].forEach(x=>{s+=`<g class="twk" style="animation-delay:${(k%5)*.35}s">${k%2?bone(x,y,.9,1,'#ffffff',90):paw(x,y,.9,1,'#ffb8d0')}</g>`;k++;});}
  s+=`<path d="M0 550 Q100 540 200 550 T400 550 V564 H0 Z" fill="#ffd9a8"/>`;return s;};
if(window.CLOOK&&CLOOK.EDGE)CLOOK.EDGE.pf=EDGE;
function packSVG(s){const n=s.n!=null?s.n:(s.cards||[]).length;return `<svg viewBox="0 0 200 270" xmlns="http://www.w3.org/2000/svg"><rect x="22" y="40" width="156" height="214" rx="14" fill="#d8a868" stroke="#7a4f2a" stroke-width="5"/><path d="M22 40 L100 16 L178 40" fill="#e8bc80" stroke="#7a4f2a" stroke-width="5" stroke-linejoin="round"/>`+
  `<g class="pfhandle"><path d="M70 30 Q100 -4 130 30" stroke="#7a4f2a" stroke-width="8" fill="none" stroke-linecap="round"/></g>`+[60,84,108,132].map(x=>`<rect x="${x}" y="64" width="10" height="44" rx="5" fill="#7a4f2a"/>`).join('')+
  `<circle cx="100" cy="158" r="36" fill="#fff" stroke="#7a4f2a" stroke-width="4"/><text x="100" y="174" text-anchor="middle" font-size="40">${s.icon||'👪'}</text>${paw(52,214,1.4,.7,'#7a4f2a')}${paw(148,214,1.4,.7,'#7a4f2a')}`+
  `<rect x="44" y="222" width="112" height="28" rx="10" fill="#fff" stroke="#7a4f2a" stroke-width="3"/><text x="100" y="242" text-anchor="middle" font-size="18" font-weight="900" fill="#7a4f2a" font-family="Arial">${n} card${n===1?'':'s'}</text></svg>`;}
function openPack(P2,pk2){sfx.yip(1.8);setTimeout(()=>{sfx.yip(2.1);const h=pk2&&pk2.querySelector('.pfhandle');if(h)h.classList.add('pop');},350);}
window.SEALOOK=Object.assign(window.SEALOOK||{},{'f:':{pat:()=>PATH,over,edge:'pf',badge:'👪'}});
window.SEAPACK=Object.assign(window.SEAPACK||{},{f_:{packSVG,open:openPack}});
const PTL=(()=>{const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="300" height="300">${[[40,50],[205,25],[150,150],[265,205],[70,250],[115,80],[250,110],[30,175],[185,265],[95,205]].map((q,i)=>i%2?bone(q[0],q[1],1.4,.35,'#ffffff',i*30):paw(q[0],q[1],1.4,.3,['#ffb8d0','#a8dcff','#ffe066'][i%3])).join('')}</svg>`;return 'url("data:image/svg+xml,'+encodeURIComponent(svg)+'")';})();
const css=document.createElement('style');css.textContent=`
#pfbook{z-index:58}#pfbCard{max-width:1000px;width:97%;background:#f6e6c8;border:8px solid #8a5a3a;border-radius:26px;padding:10px 14px 8px;position:relative;font-family:inherit}
#pfbX{position:absolute;right:10px;top:8px;z-index:3}#pfbCard.gold{border-color:#e8b020;background:linear-gradient(#fff2b0,#f6e6c8);box-shadow:0 0 0 6px #ffe680}#pfbTabs{display:flex;gap:4px;justify-content:center;flex-wrap:wrap;margin:0 50px 4px}#pfbTabs .tab{min-width:54px;height:46px;font-size:26px;border-radius:12px 12px 0 0;border:3px solid #c8a070;background:#fff6e6}#pfbTabs .tab.sel{background:#ffd9a8}
#pfbPage{background:#fffaf0;border-radius:16px;min-height:470px;max-height:560px;overflow:auto;padding:6px 10px}.pfbH{margin:4px 0 6px;color:#6a4228}.pfbH small{font-size:20px;color:#a07850;margin-left:8px}
.pfbNav{display:flex;align-items:center;justify-content:center;gap:20px;margin-top:6px}#pfbN{font-size:20px;font-weight:900;color:#6a4228}
.pfbGrid{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}.pfslot{background:none;border:none;padding:0;cursor:pointer;width:170px}.pfslot .pfphoto{width:100%;padding:5px 5px 2px}.pfslot .pfcap{font-size:15px}
.pfslot.empty .pfphoto{background:#f4efe4;border-style:dashed}.pfslot.big{width:320px}.pfslot:nth-child(2n) .pfphoto{transform:rotate(1.5deg)}
.pffam.faint{opacity:1}.pfbFirst{display:flex;gap:24px;align-items:center;justify-content:center;flex-wrap:wrap}.pfbSum p{font-size:28px;margin:8px 0;color:#6a4228}.pfbSum .pfbTip{font-size:20px;max-width:360px}
.pfbStuck{text-align:center;padding:30px}.pfbStuckPg{display:inline-block;width:300px;height:220px;line-height:220px;background:repeating-linear-gradient(45deg,#efe0c4,#efe0c4 12px,#e8d4b0 12px,#e8d4b0 24px);border:4px solid #c8a070;border-radius:12px;font-size:28px;font-weight:900;color:#8a5a3a;transform:rotate(-2deg)}
.pfbFam{display:flex;gap:16px;align-items:flex-start;flex-wrap:wrap;justify-content:center}.pfbFamL{width:290px}.pfbFamR{flex:1;min-width:420px}.pfbHow{font-size:18px;color:#6a4228}
.pfbPups{display:flex;gap:8px;justify-content:center}.pfbPup{width:170px;text-align:center;background:#fff;border:3px solid #ffd0dc;border-radius:16px;padding:4px}.pfbPup .fitsvg svg{width:100%;height:auto}.pfbPup b{display:block;font-size:22px}.pfbPup small{display:block;font-size:15px;min-height:36px}
.pfren{min-height:40px;font-size:17px;padding:0 10px}.pfbStk{font-size:22px;margin:8px 0}.pfbStk span{font-size:30px;margin:0 2px}.pfbFact{font-size:19px;background:#fff6c8;border-radius:12px;padding:6px 10px}.pfbIn{font-size:20px;font-weight:800;color:#3fae5a;align-self:center}
.pfren2{position:absolute;left:0;right:0;top:0;bottom:0;background:rgba(0,0,0,.35);display:flex;align-items:center;justify-content:center;border-radius:18px;z-index:5}.pfrenBox{background:#fff;border-radius:22px;padding:14px 24px;border:5px solid #ffb8d0}.pfrenBox input{font-size:30px;padding:8px 14px;border-radius:14px;border:4px solid #8fd0ff;text-align:center;font-family:inherit}
.pq2pack .pfhandle{transform-origin:100px 30px;transition:transform .4s}.pq2pack .pfhandle.pop{transform:translateY(-14px) rotate(-12deg)}
#book[data-sea=pf],#binder[data-sea=pf]{isolation:isolate}#book[data-sea=pf]{background:linear-gradient(#fff6f8,#eef8ff)}#binder[data-sea=pf]{background:#c8926a}
#book[data-sea=pf]::before,#binder[data-sea=pf]::before{content:'';position:absolute;left:0;right:0;top:0;bottom:0;z-index:-1;background-image:${PTL};background-size:300px 300px;pointer-events:none}
#binder[data-sea=pf] #bdTabs .tab.sel{background:#ffd9a8}`;
document.head.appendChild(css);
window.PFBOOK={open,close,draw,fcard,mkSet};
})();
