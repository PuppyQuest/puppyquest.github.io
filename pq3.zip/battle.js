/* ================================================================
   Zoomies Battle (24 Nov 2026): the pup trading card battle game.
   Design agreed: claude/card-battle-design.md (he chose
   every recommendation). Teams of 3, 5 or 9 pups; a Treat Bowl that
   fills by 1 a turn; the moves cost what is printed on the cards;
   Save up; a move uses up the other pup's Zoomies (sums in tens);
   Super! doubles a move when its type beats the other pup's type
   (CARDS.BEATS, every type beats 2 and is beaten by 2, aliens are
   neutral); a pup with no Zoomies naps; the side with no pups awake
   loses. Swapping uses the turn. Pup Skills from each pup's strongest
   stat. Maths Power Ups before big moves. Against Granny Paws, Sensei
   Mochi, Professor Hoot, Chief Woofles and Muddle (Showdown's
   characters), a Battle Ladder with the Unicorn Champions, or two
   players on one iPad with a draft. Saves after every turn.
   Save: state.cards.bt = {opp, p2, size, sets, coin, first, opts, lv,
   streak, team, rec, stat, ladder:{done}, match}.
   ================================================================ */
(function(){
const C=window.CARDS,SHW=window.SHOWDOWN;if(!C||!SHW)return;
const SEB='#3fae5a',P2COLS=['#3d8fe0','#ff8a3c','#9a6fe0','#e8423a'],NAMES=['Dad','Mum','Granny','Grandad'];
const BEATS=C.BEATS,sup=(a,b)=>!!(BEATS[a]&&BEATS[a].indexOf(b)>=0);
const LENS=[{n:3,name:'Quick Battle',short:'Quick',t:'3 min',stars:10},{n:5,name:'Team Battle',short:'Team',t:'6 min',stars:15},{n:9,name:'Full Tin Battle',short:'Full Tin',t:'12 min',stars:25}];
const LEN=n=>LENS.find(l=>l.n===n)||LENS[0];
const E=s=>C.esc(s),art_=w=>/^[aeiou]/i.test(w)?'an':'a';
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
const rnd=a=>a[Math.floor(Math.random()*a.length)];
const ISLE={fire:'Ninja Mountains',water:'Coral Reef',leaf:'Meadow Island',snow:'Snowy Summit',spark:'Number Kingdom',stone:'Dino Valley',sky:'Gadget Island',star:'Rescue Bay',comet:'Planet Hop'};
const ORDER=['fire','water','leaf','snow','spark','stone','sky','star','comet'];
const WHY={'fire>leaf':'fire burns leaves','fire>comet':'comets are made of ice, and fire melts ice','water>fire':'water puts out fire','water>stone':'waves wear rocks smooth',
  'leaf>water':'plants drink up water','leaf>stone':'roots crack rocks','snow>sky':'snowstorms keep flyers on the ground','snow>spark':'batteries go flat in the cold',
  'spark>water':'electricity zaps through water','spark>star':'bright city lights hide the stars','stone>fire':'sand and rocks smother fire','stone>spark':'rock does not let electricity through',
  'sky>star':'clouds hide the stars','sky>leaf':'the wind blows leaves away','star>snow':'the Sun is a star, and sunshine melts snow','star>comet':"the Sun melts a comet's ice into its tail",
  'comet>sky':'comets fly far above the sky','comet>snow':'a comet is a giant snowball, bigger than any snow pup'};
const FX={fire:'🔥',water:'💧',leaf:'🍃',snow:'❄️',spark:'⚡',stone:'🪨',sky:'💨',star:'⭐',comet:'☄️',alien:'👽'};
const SKL={spd:['💨','Quick Start','When it comes in from the bench, it does its everyday move straight away, free!'],
  brn:['💡','Bright Idea','It brings 1 extra treat when it comes into play.'],
  cud:['💖','Cuddle Up','Once a battle it can cuddle up to get 30 Zoomies back.'],
  brv:['🛡️','Hang On','From full Zoomies it cannot nap in one move. It hangs on with 10!']};

/* ---------- cards ---------- */
let MAP={},PCT={};
function buildMap(){MAP={};C.allSets().forEach(s=>s.cards.forEach(c=>{MAP[c.cid]=c;}));PCT={};const all=Object.values(MAP);
  ['spd','brn','cud','brv'].forEach(k=>{PCT[k]=all.map(c=>c.stats[k]).sort((a,b)=>a-b);});}
const cardOf=id=>MAP[id];
function pct(k,v){const A=PCT[k]||[];if(!A.length)return .5;let lo=0,eq=0;for(const x of A){if(x<v)lo++;else if(x===v)eq++;}return (lo+eq/2)/A.length;}
const skillOf=c=>['spd','brn','cud','brv'].reduce((b,k)=>pct(k,c.stats[k])>pct(b,c.stats[b])?k:b,'spd');
const TY=t=>C.TY(t);
const isUni=id=>{const c=cardOf(id);return !!(c&&(c.uni||c.rar==='unicorn'));};

/* ---------- save ---------- */
function SV(){const c=C.CS();if(!c.bt)c.bt={};const s=c.bt;s.opp=s.opp||'granny';s.p2=s.p2||{name:'Dad',col:P2COLS[0]};s.size=s.size||3;s.sets=s.sets||'all';
  s.opts=Object.assign({hint:[1,0],pw:['tt','off'],swap:1,skills:1,uni:1,head:[0,0],catchup:1,diff:'normal'},s.opts||{});
  s.lv=s.lv||1;s.streak=s.streak||0;s.team=s.team||[];s.rec=s.rec||{};s.stat=s.stat||{};s.ladder=s.ladder||{};s.ladder.done=s.ladder.done||{};if(s.first==null)s.first=0;return s;}

/* ---------- opponents ---------- */
const CH=id=>SHW.CHARS.find(c=>c.id===id);
const BST={
  granny:{style:'simple',str:.9,theme:c=>c.type==='leaf'||c.stats.cud>=10,about:'Granny Paws plays gently. A good one to start with!',win:'Ooh, lucky me!',lose:'Well done, dear! What lovely pups.'},
  mochi:{style:'good',str:1,theme:c=>c.type==='fire',about:'Sensei Mochi saves his treats for big ninja moves.',win:'A true ninja is patient.',lose:'Well played, young ninja!'},
  hoot:{style:'clever',str:1,theme:c=>c.type==='spark',about:'Professor Hoot knows the type chart. Watch out for Super!',win:'Hoo hoo! Super science!',lose:'Hoo! A clever battle, Seb!'},
  chief:{style:'careful',str:1,theme:c=>c.type==='star',about:'Chief Woofles is careful. His pups cuddle up and hang on!',win:'Woof! Ready for anything!',lose:'Great teamwork, Seb!'},
  muddle:{style:'good',str:1.05,theme:c=>c.rar!=='common',about:'Muddle loves shiny cards, and he might pinch a treat!',win:'Ha ha! Shiny!',lose:'Oh, bother my feathers!'}};
function OPP(id){if(!id||id==='p2'||id==='ladder')return null;
  if(id.slice(0,4)==='uni:'){const u=cardOf(id.slice(4));if(!u)return null;const S=C.setById(u.set);
    return {id,uni:u,name:u.name+' the Unicorn',short:u.name,she:'their',col:'#b26fe0',art:()=>u.art(false),style:'clever',str:1.1,theme:c=>c.set===u.set,
      about:`${u.name} the Unicorn leads the ${S?S.name:'island'} team. A Champion battle!`,win:'Rainbows and sparkles!',lose:'You are a true Champion, Seb!'};}
  const ch=CH(id),b=BST[id];if(!ch||!b)return null;return Object.assign({},b,{id,name:ch.name,short:ch.short,she:ch.she,col:ch.col,art:ch.art,open:ch.open});}
const styleOf=m=>{const o=OPP(m.opp);return !o?'good':m.opts.diff==='easy'?'simple':o.style;};
const isHuman=(m,i)=>i===0||m.opp==='p2';
const nm=(m,i)=>i===0?'Seb':m.opp==='p2'?m.p2.name:(OPP(m.opp)||{short:'?'}).short;
const colOf=(m,i)=>i===0?SEB:m.opp==='p2'?m.p2.col:(OPP(m.opp)||{col:'#888'}).col;
const safe=f=>{try{return f();}catch(e){return '<div style="font-size:44px;line-height:56px;text-align:center">🐾</div>';}};
function avatar(m,i){if(i===0)return `<div class="fitsvg">${safe(()=>sebSVG())}</div>`;
  if(m.opp!=='p2'){const o=OPP(m.opp);return `<div class="fitsvg">${o?safe(o.art):''}</div>`;}
  return `<div class="sdIni" style="background:${m.p2.col}">${E((m.p2.name||'?')[0].toUpperCase())}</div>`;}

/* ---------- the Battle Ladder ---------- */
function ladderSteps(){const L=['granny','mochi','hoot','chief'],got={};C.earnedIds().forEach(id=>{got[id]=1;});
  C.allSets().filter(s=>s.game===3).forEach(s=>s.cards.forEach(c=>{if((c.uni||c.rar==='unicorn')&&got[c.cid])L.push('uni:'+c.cid);}));L.push('muddle');return L;}
const stepOpen=id=>{if(id.slice(0,4)==='uni:')return true;const ch=CH(id);return !ch||ch.open();};
function ladderNext(){const sv=SV();return ladderSteps().find(id=>!sv.ladder.done[id])||null;}
function lockSay(id){const isl={mochi:'ninja',hoot:'number',chief:'rescue'}[id],I=isl&&typeof islandOf==='function'?islandOf(isl):null,o=OPP(id);
  return `Open ${I?I.name:'the next island'} to battle ${o?o.name:'them'}!`;}

/* ---------- screen ---------- */
let M=null,from='binder',busy=0,timers=[],PICK=null,DRAFT=null;
const later=(f,ms)=>{const t=setTimeout(()=>{timers=timers.filter(x=>x!==t);f();},ms);timers.push(t);return t;};
const clearLater=()=>{timers.forEach(clearTimeout);timers=[];};
function afterSpeech(f,min,max){const t0=Date.now();const go=()=>{const el_=Date.now()-t0;let sp=false;try{sp=!!(state.set.voice&&window.speechSynthesis&&speechSynthesis.speaking);}catch(e){}
  if(el_>=(max||9000)||(el_>=min&&!sp))f();else later(go,200);};later(go,Math.min(min,200));}
function build(){if($('#battle'))return;const S=el('div','screen','');S.id='battle';
  S.innerHTML=`<button class="btn rnd white" id="btBack" style="left:14px;top:10px">◀</button><h2 id="btH">⚔️ Zoomies Battle</h2><div class="pill" id="btTag"></div><div id="btBody"></div><div id="btPanel"></div><div id="btFx"></div>`;
  $('#stage').insertBefore(S,$('#bubble'));tap('#btBack',back);}
function open(src){build();from=src||from;clearLater();busy=0;closeOv('menu');
  const go=()=>{buildMap();show('battle');const sv=SV();if(sv.match&&restore(sv.match))resumeView();else setupView(true);};
  if(C.CS().pq2&&!window.PQ2ART)C.loadArt(go,true);else go();}
function leave(){clearLater();hush();busy=0;closeChart();if(from==='binder'){C.openBinder();return;}
  if(W.area){show('world');if(typeof syncFollowers==='function')syncFollowers(true);hud();player.lock=false;}else showTitle();}
function back(){sfx.boop();const S=$('#battle');
  if(M&&!M.over&&S.classList.contains('game')){card({art:'<div style="font-size:90px;line-height:1">⚔️</div>',h:'Stop for now?',
    p:`Your battle is saved. ${nm(M,0)} has ${awake(M,0).length} ${awake(M,0).length===1?'pup':'pups'} awake, ${nm(M,1)} has ${awake(M,1).length}. You can carry on later.`,
    btns:[['▶ Keep playing','green'],['Stop for now','white',leave]]});return;}
  if(S.classList.contains('pick')){setupView();return;}leave();}
function chip(label,sel,data,cls){return `<button class="sdChip${sel?' sel':''}${cls?' '+cls:''}" ${data}>${label}</button>`;}
function setMode(mode){const S=$('#battle');['game','pick','setup'].forEach(k=>S.classList.toggle(k,k===mode));$('#btPanel').classList.remove('on');}

/* ---------- setup ---------- */
function setupView(first){const sv=SV(),S=$('#battle');setMode('setup');M=null;PICK=null;DRAFT=null;$('#btTag').style.display='none';$('#btH').textContent='⚔️ Zoomies Battle';
  if(sv.opp!=='p2'&&sv.opp!=='ladder'&&!(CH(sv.opp)&&CH(sv.opp).open()))sv.opp='granny';
  const two=sv.opp==='p2',lad=sv.opp==='ladder',o=OPP(sv.opp),P2=two?sv.p2.name:o?o.short:'',pq2=!!C.CS().pq2,cnt=sel=>SHW.poolFor(sel).length,pool=SHW.poolFor(sv.sets);
  const opp=[chip('<span class="big">👫</span>2 players',two,'data-opp="p2"')].concat(SHW.CHARS.filter(c=>c.open()).map(c=>chip(`<span class="av">${c.art()}</span>${c.short}`,sv.opp===c.id,`data-opp="${c.id}"`)))
    .concat([chip('<span class="big">🪜</span>Ladder',lad,'data-opp="ladder"')]).join('');
  let row2;
  if(two)row2=NAMES.map(n=>chip(n,sv.p2.name===n,`data-nm="${n}"`)).join('')+`<input id="btName" class="sdIn" maxlength="12" placeholder="✏️ Name" autocomplete="off" autocorrect="off" spellcheck="false" value="${NAMES.indexOf(sv.p2.name)<0?E(sv.p2.name):''}">`+
      `<span class="sdCols">${P2COLS.map(c=>`<button class="sdDot${sv.p2.col===c?' sel':''}" data-col="${c}" style="background:${c}"></button>`).join('')}</span>`;
  else if(lad){const L=ladderSteps(),nx=ladderNext();row2=`<div class="btLad">${L.map(id=>{const q=OPP(id),done=!!sv.ladder.done[id],lk=!stepOpen(id);
      return `<span class="st${done?' done':''}${id===nx?' nx':''}${lk?' lk':''}"><span class="fitsvg">${q?safe(q.art):''}</span>${done?'<b>✓</b>':lk?'<b>🔒</b>':''}</span>`;}).join('<i>›</i>')}</div>`;}
  else row2=`<span class="sdAbout">${E(o.about)}</span>`;
  const sets=[['all','All my cards'],['pq3','Puppy Quest 3']].concat(pq2?[['pq2','Puppy Quest 2']]:[]).map(q=>chip(`${q[1]} <small>${cnt(q[0])}</small>`,sv.sets===q[0],`data-sets="${q[0]}"`)).join('')+
    chip(Array.isArray(sv.sets)?`Chosen sets <small>${pool.length}</small>`:'Pick sets…',Array.isArray(sv.sets),'data-pick="1"');
  const recKey=two?sv.p2.name:o?o.name:null,rec=recKey&&sv.rec[recKey],next=sv.first?(two?sv.p2.name:lad?(OPP(ladderNext()||'muddle')||{short:'They'}).short:P2):'Seb';
  $('#btBody').innerHTML=`<div class="sdSetup btSetup">
    <div class="sdRow"><label>Play with</label><div>${opp}</div></div>
    <div class="sdRow"><label>${two?'Player 2':lad?'Ladder':'About'}</label><div>${row2}</div></div>
    <div class="sdRow"><label>Battle</label><div>${LENS.map(l=>chip(`${l.short}<small>${l.n} pups · about ${l.t}</small>`,sv.size===l.n,`data-sz="${l.n}"`,'tg')).join('')}</div></div>
    <div class="sdRow"><label>Cards</label><div>${sets}</div></div>
    <div class="sdRow"><label>Who starts</label><div>${chip(`Take turns <small>${E(next)} next</small>`,!sv.coin,'data-coin="0"')}${chip('🪙 Paw coin <small>toss for it</small>',!!sv.coin,'data-coin="1"')}</div></div>
    <div class="sdFoot"><span class="sdRec">${chip('⚙️ More','','data-more="1"')}${chip('🌈 Types','','data-types="1"')} ${rec?`⚔️ Seb ${rec[0]}, ${E(two?sv.p2.name:o.short)} ${rec[1]}`:''}</span><button class="btn green" id="btStart">▶ Pick teams</button></div></div>`;
  const B=$('#btBody');
  B.querySelectorAll('[data-opp]').forEach(b=>tap(b,()=>{sfx.pop();sv.opp=b.dataset.opp;save();setupView();
    if(sv.opp==='ladder'){const nx=ladderNext();say(nx?`The Battle Ladder! Next: ${OPP(nx).name}.${stepOpen(nx)?'':' '+lockSay(nx)}`:'You finished the Battle Ladder! You are the Champion!');}
    else if(sv.opp!=='p2')say(OPP(sv.opp).about);else say('Two players! Take turns to pick your teams.');}));
  B.querySelectorAll('[data-nm]').forEach(b=>tap(b,()=>{sfx.pop();sv.p2.name=b.dataset.nm;save();setupView();}));
  const inp=$('#btName');if(inp){inp.addEventListener('input',()=>{const v=inp.value.replace(/[<>]/g,'').trim();if(v){sv.p2.name=v;save();B.querySelectorAll('[data-nm]').forEach(b=>b.classList.remove('sel'));}});
    inp.addEventListener('change',()=>setupView());}
  B.querySelectorAll('[data-col]').forEach(b=>tap(b,()=>{sfx.pop();sv.p2.col=b.dataset.col;save();setupView();}));
  B.querySelectorAll('[data-sz]').forEach(b=>tap(b,()=>{sfx.pop();sv.size=+b.dataset.sz;save();setupView();const l=LEN(sv.size);say(`${l.name}: ${l.n} pups each.`);}));
  B.querySelectorAll('[data-sets]').forEach(b=>tap(b,()=>{sfx.pop();sv.sets=b.dataset.sets;save();setupView();}));
  B.querySelectorAll('[data-coin]').forEach(b=>tap(b,()=>{sfx.pop();sv.coin=b.dataset.coin==='1';save();setupView();}));
  tap(B.querySelector('[data-pick]'),()=>{sfx.pop();pickSets();});tap(B.querySelector('[data-more]'),()=>{sfx.pop();morePanel();});tap(B.querySelector('[data-types]'),()=>{sfx.pop();openChart();});
  tap('#btStart',startFlow);
  if(first)say(C.earnedIds().length<3?'Zoomies Battle needs 3 cards. Find more pups, then come back!':'Zoomies Battle! Use up the other team\'s Zoomies until all their pups nap. Who are you playing?');}
function panel(html,done){const P=$('#btPanel');P.innerHTML=`<div class="sdPan">${html}<button class="btn green sdDone">✓ Done</button></div>`;P.classList.add('on');
  tap(P.querySelector('.sdDone'),()=>{sfx.boop();P.classList.remove('on');if(done)done();});return P;}
function pickSets(){const sv=SV(),chosen=Array.isArray(sv.sets)?sv.sets.slice():[],got={};C.earnedIds().forEach(id=>{got[id]=1;});
  const L0=C.allSets().map(s=>({s,n:s.cards.filter(c=>got[c.cid]).length})).filter(q=>q.n>0),XL=L0.filter(q=>q.s.season),XI=XL.map(q=>q.s.id),SK=[...new Set(XL.map(q=>q.s.season))],SI=k=>XL.filter(q=>q.s.season===k).map(q=>q.s.id),L=L0.filter(q=>!q.s.season).concat(SK.map(k=>{const S=(window.SEASONS||{})[k],cd=S&&S.card||['✨',k];return {s:{id:'*'+k,icon:cd[0],short:cd[1]},n:XL.filter(q=>q.s.season===k).reduce((a,q)=>a+q.n,0)};})),sel=id=>id[0]==='*'?SI(id.slice(1)).every(x=>chosen.indexOf(x)>=0):chosen.indexOf(id)>=0;
  const P=panel(`<h3>Pick the sets to play with</h3><div class="sdSets">${L.map(q=>chip(`<span>${q.s.icon}</span>${E(q.s.short||q.s.name)} <small>${q.n}</small>`,sel(q.s.id),`data-set="${q.s.id}"`)).join('')}</div>`,
    ()=>{sv.sets=chosen.length?chosen:'all';save();setupView();});
  P.querySelectorAll('[data-set]').forEach(b=>tap(b,()=>{sfx.pop();const id=b.dataset.set;if(id[0]==='*'){const on=sel(id);SI(id.slice(1)).forEach(x=>{const i=chosen.indexOf(x);if(on&&i>=0)chosen.splice(i,1);if(!on&&i<0)chosen.push(x);});b.classList.toggle('sel',!on);return;}const i=chosen.indexOf(id);if(i<0)chosen.push(id);else chosen.splice(i,1);b.classList.toggle('sel',i<0);}));}
function morePanel(){const sv=SV(),o=sv.opts,two=sv.opp==='p2',P2=two?sv.p2.name:'';
  const row=(lab,key,opts,cur)=>`<div class="sdOpt"><label>${lab}</label>${opts.map(q=>chip(q[1],cur===q[0],`data-k="${key}" data-v="${q[0]}"`)).join('')}</div>`,OF=[[1,'On'],[0,'Off']];
  const draw=()=>{const P=panel(`<h3>⚙️ More</h3>`+
      row('⭐ Hints for Seb','hint0',OF,o.hint[0]?1:0)+(two?row(`⭐ Hints for ${E(P2)}`,'hint1',OF,o.hint[1]?1:0):'')+
      row('🧮 Power Ups for Seb','pw0',[['tt','Times tables'],['zs','Zoomies sums'],['mix','Mix'],['off','Off']],o.pw[0])+
      (o.pw[0]==='tt'||o.pw[0]==='mix'?row('✖️ Times tables','lv',[[1,'2, 5, 10'],[2,'Up to 10 × 10'],[3,'Up to 12 × 12']],sv.lv):'')+
      (two?row(`🧮 Power Ups for ${E(P2)}`,'pw1',[['off','Off'],['same','Same as Seb'],['hard','Harder']],o.pw[1]):'')+
      row('🔄 Swapping','swap',OF,o.swap?1:0)+row('🌟 Pup Skills','skills',OF,o.skills?1:0)+
      row('🦄 Unicorns','uni',[[1,'One per team'],[0,'None'],[2,'Any']],o.uni)+row('🍖 Catch-up treat','catchup',OF,o.catchup?1:0)+
      (two?row('🏁 Head start for Seb','head0',[[0,'None'],[1,'2 treats'],[2,'Extra pup']],o.head[0])+row(`🏁 Head start for ${E(P2)}`,'head1',[[0,'None'],[1,'2 treats'],[2,'Extra pup']],o.head[1])
        :row('🎚️ Characters','diff',[['easy','Easy'],['normal','Normal'],['hard','Hard']],o.diff))+
      `<p class="sdNote">Hints show Super! on the moves and glow on a good move. Power Ups ask a quick sum before a big move: right adds 10. Whoever has 2 more pups napping gets an extra treat each turn.</p>`,()=>setupView());
    P.querySelectorAll('[data-k]').forEach(b=>tap(b,()=>{sfx.pop();const k=b.dataset.k,raw=b.dataset.v,v=isNaN(+raw)?raw:+raw;
      if(k==='hint0')o.hint[0]=v;else if(k==='hint1')o.hint[1]=v;else if(k==='pw0')o.pw[0]=v;else if(k==='pw1')o.pw[1]=v;else if(k==='lv'){sv.lv=v;sv.streak=0;}
      else if(k==='head0')o.head[0]=v;else if(k==='head1')o.head[1]=v;else o[k]=v;save();const sc=$('#btPanel .sdPan').scrollTop;draw();$('#btPanel .sdPan').scrollTop=sc;}));};
  draw();}

/* ---------- teams ---------- */
const uniCap=m=>m.opts.uni===0?0:m.opts.uni===2?99:1;
const sizeFor=(sv,i)=>sv.size+(sv.opp==='p2'&&sv.opts.head[i]===2?1:0);
function startFlow(){const sv=SV();buildMap();clearLater();
  let opp=sv.opp,step=null;
  if(opp==='ladder'){const nx=ladderNext();step=nx||'muddle';if(!stepOpen(step)){sfx.oops();say(lockSay(step));return;}opp=step;}
  const pool=SHW.poolFor(sv.sets).filter(id=>cardOf(id)&&(sv.opts.uni!==0||!isUni(id))),N=sv.size;
  if(opp==='p2'){const need=sizeFor(sv,0)+sizeFor(sv,1);if(pool.length<need){sfx.oops();say(`A ${LEN(N).name} for two players needs ${need} cards, and these sets have ${pool.length}. Try a shorter battle or more sets!`);return;}
    sfx.pop();draftView(pool);return;}
  if(pool.length<N){sfx.oops();say(`A ${LEN(N).name} needs ${N} cards, and these sets have ${pool.length}. Try a shorter battle or more sets!`);return;}
  sfx.pop();PICK={opp,step,pool,team:(sv.team||[]).filter(id=>pool.indexOf(id)>=0).slice(0,N),filt:null};
  if(PICK.team.length>N)PICK.team.length=N;fixUni(PICK.team,sv);pickView(true);}
function fixUni(team,sv){const cap=sv.opts.uni===0?0:sv.opts.uni===2?99:1;let n=0;for(let i=0;i<team.length;i++){if(isUni(team[i])){n++;if(n>cap){team.splice(i,1);i--;}}}}
function teamZ(ids){return ids.reduce((a,id)=>a+(cardOf(id)?cardOf(id).zoom:0),0);}
function mini(id,cls,scale){const c=cardOf(id);return `<div class="btMn ${cls||''}" data-id="${id}"><div class="sc" style="transform:scale(${scale||.6})">${C.miniHTML(c,{force:true})}</div></div>`;}
function pickView(first){const sv=SV(),P=PICK,N=sv.size,o=OPP(P.opp);setMode('pick');$('#btTag').style.display='';$('#btTag').textContent=LEN(N).name;
  $('#btH').textContent=o&&o.uni?'🦄 Champion battle':'⚔️ Your team';
  const tin=C.CS().tin.filter(id=>P.pool.indexOf(id)>=0),got={};P.pool.forEach(id=>{got[id]=1;});
  const sets=C.allSets().map(s=>({s,n:s.cards.filter(c=>got[c.cid]).length})).filter(q=>q.n>0);
  if(!P.filt)P.filt=tin.length?'tin':sets.length?sets[0].s.id:'tin';
  const ids=P.filt==='tin'?tin:P.pool.filter(id=>cardOf(id).set===P.filt);
  $('#btBody').innerHTML=`<div class="btPick">
    <div class="btVs"><div class="av">${avatar({opp:P.opp,p2:sv.p2},1)}</div><div><b>Seb vs ${E(o?o.name:'')}</b><small>Pick ${N} pups for your team!</small></div></div>
    <div class="btSlots n${N}">${Array.from({length:N},(_,j)=>P.team[j]?mini(P.team[j],'in',N>5?.44:.6):'<div class="btMn empty"><span>?</span></div>').join('')}</div>
    <div class="btTZ">Team Zoomies<b>${teamZ(P.team)}</b></div>
    <div class="btFilt">${(tin.length?[chip(`💖 Tin <small>${tin.length}</small>`,P.filt==='tin','data-f="tin"')]:[]).concat(sets.map(q=>chip(`${q.s.icon} <small>${q.n}</small>`,P.filt===q.s.id,`data-f="${q.s.id}"`))).join('')}</div>
    <div class="btGrid">${ids.map(id=>mini(id,P.team.indexOf(id)>=0?'chosen':'')).join('')}</div>
    <div class="btPF"><button class="btn white" id="btTin">💖 My Tin</button><button class="btn white" id="btDip">🎲 Lucky Dip</button><button class="btn white" id="btClr">✖ Clear</button>
      <button class="btn green${P.team.length===N?'':' off'}" id="btGo">⚔️ Battle!</button></div></div>`;
  const B=$('#btBody');
  B.querySelectorAll('.btFilt [data-f]').forEach(b=>tap(b,()=>{sfx.pop();P.filt=b.dataset.f;pickView();}));
  B.querySelectorAll('.btGrid .btMn').forEach(b=>tap(b,()=>toggleTeam(b.dataset.id)));
  B.querySelectorAll('.btSlots .btMn.in').forEach(b=>tap(b,()=>toggleTeam(b.dataset.id)));
  tap('#btTin',()=>{if(!tin.length){sfx.oops();say('Your Special Tin is empty. Put favourite cards in it from the binder!');return;}sfx.pop();P.team=tin.slice(0,N);fixUni(P.team,sv);pickView();
    say(P.team.length<N?`Your tin has ${P.team.length}. Pick ${N-P.team.length} more!`:'Your Special Tin team!');});
  tap('#btDip',()=>{sfx.giggle();P.team=luckyDip(P.pool,N,sv);pickView();say(`Lucky Dip! Team Zoomies ${teamZ(P.team)}.`);});
  tap('#btClr',()=>{sfx.boop();P.team=[];pickView();});
  tap('#btGo',()=>{if(P.team.length<N){sfx.oops();say(`Pick ${N-P.team.length} more ${N-P.team.length===1?'pup':'pups'} first!`);return;}sfx.chime();sv.team=P.team.slice();save();beginVsChar();});
  if(first)say(`Pick ${N} pups for your team, or tap Lucky Dip!${o&&o.uni?' '+o.about:''}`);}
function toggleTeam(id){const sv=SV(),P=PICK,N=sv.size,i=P.team.indexOf(id),c=cardOf(id);
  if(i>=0){sfx.boop();P.team.splice(i,1);pickView();return;}
  if(P.team.length>=N){sfx.oops();say(`Your team is full! Tap a pup in your team to take it out.`);return;}
  if(isUni(id)&&P.team.filter(isUni).length>=(sv.opts.uni===2?99:1)){sfx.oops();say('Only one unicorn in a team!');return;}
  sfx.pop();P.team.push(id);pickView();speak(`${c.name}, ${c.zoom} Zoomies.`);}
function luckyDip(pool,N,sv){for(let t=0;t<50;t++){const T=shuffle(pool.slice()).slice(0,N);const u=T.filter(isUni).length;if(u<=(sv.opts.uni===2?99:sv.opts.uni===0?0:1))return T;}
  return shuffle(pool.filter(id=>!isUni(id))).slice(0,N);}
/* a character's team: themed from Seb's own cards (as many themed pups as still match), matched to Seb's Team Zoomies */
function charTeam(o,N,target,pool,cap){
  if(o.uni){const S=C.setById(o.uni.set),isl=S?S.cards.map(c=>c.cid).filter(id=>id!==o.uni.cid&&!isUni(id)):[],ot=pool.filter(id=>!isUni(id)&&isl.indexOf(id)<0);
    const T=fit(isl,ot,N-1,target-o.uni.zoom,0,Math.min(isl.length,N-1));return [o.uni.cid].concat(T||shuffle(isl.concat(ot)).slice(0,N-1));}
  const cands=pool.filter(id=>cap>0||!isUni(id)),th=cands.filter(id=>o.theme(cardOf(id))),ot=cands.filter(id=>th.indexOf(id)<0);
  return fit(th,ot,N,target,cap,Math.min(th.length,N))||shuffle(cands.slice()).slice(0,N);}
function fit(th,ot,N,target,cap,maxTh){let B=null,bd=1e9;
  for(let nTh=maxTh;nTh>=0;nTh--){const T=fit2(th,ot,nTh,N,target,cap);if(!T)continue;const d=Math.abs(teamZ(T)-target);if(d<=target*.08)return T;if(d<bd){bd=d;B=T;}}
  return B;}
function fit2(th,ot,nTh,N,target,cap){if(ot.length<N-nTh||th.length<nTh)return null;let B=null,bd=1e9;
  for(let t=0;t<160;t++){const T=shuffle(th.slice()).slice(0,nTh).concat(shuffle(ot.slice()).slice(0,N-nTh));if(T.filter(isUni).length>cap)continue;
    const d=Math.abs(teamZ(T)-target);if(d<bd){bd=d;B=T;}if(d===0)break;}return B;}
function beginVsChar(){const sv=SV(),P=PICK,o=OPP(P.opp),N=sv.size,adj=sv.opts.diff==='easy'?-.1:sv.opts.diff==='hard'?.1:0;
  const tgt=Math.round(teamZ(P.team)*(o.str+adj)/10)*10,T=charTeam(o,N,tgt,P.pool,o.uni?0:(sv.opts.uni===0?0:sv.opts.uni===2?99:1));
  startMatch(P.opp,[P.team.slice(),T],P.step,false);}

/* ---------- the draft (two players) ---------- */
function draftView(pool){const sv=SV(),first=sv.coin?(Math.random()<.5?0:1):sv.first,sz=[sizeFor(sv,0),sizeFor(sv,1)];
  const n=Math.min(pool.length,sz[0]+sz[1]+4);
  DRAFT={first,coin:!!sv.coin,sz,pile:pickPile(pool,n,sv),teams:[[],[]],turn:1-first};drawDraft(true);}
function pickPile(pool,n,sv){const cap=sv.opts.uni===2?99:sv.opts.uni===0?0:2;for(let t=0;t<40;t++){const T=shuffle(pool.slice()).slice(0,n);if(T.filter(isUni).length<=cap)return T;}
  return shuffle(pool.filter(id=>!isUni(id))).slice(0,n);}
function drawDraft(first){const sv=SV(),D=DRAFT,m={opp:'p2',p2:sv.p2},i=D.turn;setMode('pick');$('#btTag').style.display='';$('#btTag').textContent=LEN(sv.size).name;$('#btH').textContent='⚔️ Pick teams';
  const side=p=>`<div class="btDS p${p}"><div class="sdPlate p${p}${p===i?' turn':''}" style="--pc:${colOf(m,p)}"><div class="av">${avatar(m,p)}</div><div class="nm">${E(nm(m,p))}<em>${p===i?'Your pick!':''}</em></div><div class="sc">${D.teams[p].length}/${D.sz[p]}</div></div>
    <div class="btDT">${Array.from({length:D.sz[p]},(_,j)=>D.teams[p][j]?mini(D.teams[p][j],'',.42):'<div class="btMn empty sm"><span>?</span></div>').join('')}</div><div class="btTZ sm">Team Zoomies<b>${teamZ(D.teams[p])}</b></div></div>`;
  $('#btBody').innerHTML=`<div class="btDraft">${side(0)}${side(1)}<div class="btDP">${D.pile.map(id=>mini(id,'',.55)).join('')}</div></div>`;
  $('#btBody').querySelectorAll('.btDP .btMn').forEach(b=>tap(b,()=>draftPick(b.dataset.id)));
  if(first)say(`${D.coin?`The paw coin says ${nm(m,D.first)} starts the battle, so `:''}${nm(m,i)} picks first. Take turns to pick your pups!`);
  else say(`${nm(m,i)}'s pick!`);}
function draftPick(id){const sv=SV(),D=DRAFT,i=D.turn,c=cardOf(id);if(!D||D.pile.indexOf(id)<0)return;
  if(isUni(id)&&D.teams[i].filter(isUni).length>=(sv.opts.uni===2?99:1)){sfx.oops();say('Only one unicorn in a team!');return;}
  sfx.pop();D.pile.splice(D.pile.indexOf(id),1);D.teams[i].push(id);speak(`${c.name}!`);
  const full=p=>D.teams[p].length>=D.sz[p];
  if(full(0)&&full(1)){later(()=>{sfx.chime();startMatch('p2',[D.teams[0],D.teams[1]],null,true,D.first);},700);D.turn=-1;drawDraftDone();return;}
  D.turn=full(1-i)?i:1-i;drawDraft();}
function drawDraftDone(){const B=$('#btBody .btDP');if(B)B.innerHTML='<div class="btReady">⚔️ Teams ready!</div>';$('#btBody').querySelectorAll('.sdPlate').forEach(p=>p.classList.remove('turn'));}

/* ---------- a match ---------- */
function startMatch(opp,teams,step,draft,firstIn){const sv=SV();let first=firstIn!=null?firstIn:sv.first;const coin=!!sv.coin&&firstIn==null;if(coin)first=Math.random()<.5?0:1;
  const two=opp==='p2',head=two?sv.opts.head:[0,0];
  M={v:1,opp,p2:{name:sv.p2.name,col:sv.p2.col},size:sv.size,sets:sv.sets,opts:JSON.parse(JSON.stringify(sv.opts)),step,draft:!!draft,
    teams:teams.map(T=>T.map(id=>({id,hp:cardOf(id).zoom,mx:cardOf(id).zoom,cu:0}))),act:[-1,-1],bowl:[head[0]===1?2:0,head[1]===1?2:0],
    first,turn:first,phase:'lead',lead:first,need:-1,sel:null,naps:{},sup:0,pu:0,pinched:0,swapT:[-9,-9],turnN:0,seen:{},over:false,win:-1,coinSaid:coin};
  if(!two)M.opts.hint[1]=0;persist();gameView(false);}
function restore(m){if(!m||m.v!==1||!m.teams)return false;if(m.opp!=='p2'&&!OPP(m.opp))return false;
  if(m.teams.some(T=>T.some(P=>!cardOf(P.id))))return false;M=m;return true;}
function persist(){const sv=SV();sv.match=M?JSON.parse(JSON.stringify(M)):null;save();}
const act=(m,i)=>m.act[i]>=0?m.teams[i][m.act[i]]:null;
const awake=(m,i)=>m.teams[i].map((P,k)=>k).filter(k=>m.teams[i][k].hp>0);
const napped=(m,i)=>m.teams[i].filter(P=>P.hp<=0).length;
const benchAwake=(m,i)=>awake(m,i).filter(k=>k!==m.act[i]);
const canCud=(m,i)=>{const P=act(m,i);return !!(P&&m.opts.skills&&skillOf(cardOf(P.id))==='cud'&&!P.cu&&P.hp>0&&P.hp<P.mx);};

/* ---------- resume ---------- */
function resumeView(){const m=M;setMode('setup');$('#btTag').style.display='none';$('#btH').textContent='⚔️ Zoomies Battle';
  $('#btBody').innerHTML=`<div class="sdResume"><div class="sdRA">${avatar(m,0)}<b>${awake(m,0).length}</b></div><div class="sdRm"><h3>Your battle is saved!</h3><p>${E(nm(m,0))}: ${awake(m,0).length} awake<br>${E(nm(m,1))}: ${awake(m,1).length} awake<br><small>${LEN(m.size).name}</small></p>
    <button class="btn green" id="btCarry">▶ Carry on</button><button class="btn white" id="btNew">New battle</button></div><div class="sdRA">${avatar(m,1)}<b>${awake(m,1).length}</b></div></div>`;
  tap('#btCarry',()=>{sfx.pop();gameView(true);});tap('#btNew',()=>{sfx.boop();M=null;SV().match=null;save();setupView(false);});
  say(`Your battle is saved. ${nm(m,0)} has ${awake(m,0).length} pups awake, ${nm(m,1)} has ${awake(m,1).length}. Carry on?`);}

/* ---------- drawing the battle ---------- */
function gameView(resumed){const m=M;setMode('game');busy=0;const t=$('#btTag');t.style.display='';t.textContent=LEN(m.size).name;
  const o=OPP(m.opp);$('#btH').textContent=o&&o.uni?'🦄 Champion battle':'⚔️ Zoomies Battle';
  $('#btBody').innerHTML=[0,1].map(i=>`<div class="sdPlate btPl p${i}" style="--pc:${colOf(m,i)}"><div class="av">${avatar(m,i)}</div><div class="nm">${E(nm(m,i))}<em></em></div><div class="bowl"></div><div class="aw"></div></div>
    <div class="btSlot p${i}"><div class="btScale"></div><div class="btEmpty"></div></div><div class="btCol p${i}"></div><div class="btBench p${i}"><div class="lbl"></div><div class="row"></div></div>`).join('')+
    `<div class="btMatch"></div><button class="btn white" id="btTypes">🌈 Types</button>`;
  [0,1].forEach(i=>tap($('#battle .btSlot.p'+i),()=>slotTap(i)));tap('#btTypes',()=>{sfx.pop();openChart();});tap($('#battle .btMatch'),matchSay);
  drawB();resumePhase(resumed);}
function resumePhase(resumed){const m=M;
  if(m.over){later(finish,600);return;}
  if(m.phase==='lead'){leadPrompt(resumed);return;}
  if(m.phase==='next'){nextPrompt(resumed);return;}
  if(m.phase==='turn'){const i=m.turn;if(isHuman(m,i))say(`${resumed?'Welcome back! ':''}${nm(m,i)}'s turn! ${m.bowl[i]} ${m.bowl[i]===1?'treat':'treats'}.`);else{say(`${resumed?'Welcome back! ':''}${nm(m,i)}'s turn…`);later(charAct,1700);}}}
function bones(n){return Array.from({length:5},(_,j)=>`<i class="${j<n?'on':''}">🦴</i>`).join('');}
function blocks(P){const n=P.mx/10,f=Math.max(0,P.hp)/10;return Array.from({length:n},(_,j)=>`<i class="${j<f?'on':''}"></i>`).join('');}
function hintFor(m,i){if(!m.opts.hint[i]||m.phase!=='turn'||m.turn!==i||!isHuman(m,i))return null;return plan(m,i,'careful').a;}
function moveBtn(m,i,w,on,hint){const P=act(m,i),c=cardOf(P.id),D=act(m,1-i),mv=c.moves[w-1],s=D&&sup(c.type,cardOf(D.id).type),can=m.bowl[i]>=mv[1];
  return `<button class="btMv${on&&can?'':' off'}${hint==='m'+w?' hint':''}${w===2?' big':''}" data-a="m${w}"><span class="cost">${'🦴'.repeat(mv[1])}</span><b>${E(mv[0])}</b><span class="pw">${mv[2]}</span>${s&&m.opts.hint[i]?`<em>Super! ${mv[2]*2}</em>`:''}</button>`;}
function colHTML(m,i){const P=act(m,i);if(!P)return `<div class="btWait">${m.phase==='lead'&&m.lead===i?(isHuman(m,i)?'👇 Pick your first pup!':'Picking…'):m.phase==='next'&&m.need===i?(isHuman(m,i)?'👇 Pick your next pup!':'Picking…'):''}</div>`;
  const c=cardOf(P.id),on=m.phase==='turn'&&m.turn===i&&isHuman(m,i)&&!busy,hint=hintFor(m,i),sk=m.opts.skills?SKL[skillOf(c)]:null;
  const cud=m.opts.skills&&skillOf(c)==='cud'&&!P.cu,swapOk=m.opts.swap&&benchAwake(m,i).length>0;
  return `<div class="btZ${P.hp<=0?' nap':''}"><span>⚡ Zoomies <b>${Math.max(0,P.hp)}</b><small>/ ${P.mx}</small></span><div class="blk">${blocks(P)}</div></div>`+
    (sk?`<div class="btSk" data-sk="1">${sk[0]} ${sk[1]}</div>`:'<div class="btSk none"></div>')+
    moveBtn(m,i,1,on,hint)+moveBtn(m,i,2,on,hint)+
    `<div class="btAux"><button class="btA${on?'':' off'}${hint==='save'?' hint':''}" data-a="save">🦴 Save up</button>`+
    (m.opts.swap?`<button class="btA${on&&swapOk?'':' off'}${m.sel==='swap'&&m.turn===i?' sel':''}" data-a="swap">🔄 Swap</button>`:'')+
    (cud?`<button class="btA${on&&P.hp<P.mx?'':' off'}${hint==='cud'?' hint':''}" data-a="cud">💖 +30</button>`:'')+`</div>`;}
function benchHTML(m,i){const T=m.teams[i],hideOpp=!isHuman(m,i)&&!m.draft,sel=(m.phase==='lead'&&m.lead===i)||(m.phase==='next'&&m.need===i)||(m.phase==='turn'&&m.sel==='swap'&&m.turn===i);
  const n=T.length-(m.act[i]>=0?1:0),sc=n>8?.38:n>6?.42:n>4?.48:.55;
  return T.map((P,k)=>{if(k===m.act[i])return '';const c=cardOf(P.id),nap=P.hp<=0,can=sel&&!nap&&isHuman(m,i);
    const inner=hideOpp&&!m.seen[P.id]?`<div class="btClue" style="background:${TY(c.type).col}"><span>${TY(c.type).icon}</span><b>?</b></div>`:C.miniHTML(c,{force:true});
    return `<div class="btMn bn${nap?' nap':''}${can?' can':''}" data-k="${k}" style="--s:${sc}"><div class="sc" style="transform:scale(${sc})">${inner}</div>${nap?'<i class="zz">💤</i>':''}${!nap&&P.hp<P.mx?`<i class="hp">${P.hp}</i>`:''}</div>`;}).join('');}
function drawB(){const m=M,S=$('#battle');if(!m||!S||!S.classList.contains('game'))return;
  [0,1].forEach(i=>{const P=act(m,i),pl=S.querySelector('.btPl.p'+i);
    const myTurn=(m.phase==='turn'&&m.turn===i)||(m.phase==='lead'&&m.lead===i)||(m.phase==='next'&&m.need===i);
    pl.classList.toggle('turn',myTurn&&!m.over);pl.querySelector('.nm em').textContent=m.over?(m.win===i?'Winner!':''):myTurn?(m.phase==='turn'?(isHuman(m,i)?'Your turn!':'Thinking…'):'Picking a pup'):'';
    pl.querySelector('.bowl').innerHTML=bones(m.bowl[i]);pl.querySelector('.aw').innerHTML=`🐶 <b>${awake(m,i).length}</b>/${m.teams[i].length}`;
    const sl=S.querySelector('.btSlot.p'+i),sc=sl.querySelector('.btScale');
    if(P){if(sc.dataset.id!==P.id){sc.innerHTML=C.bigHTML(cardOf(P.id));sc.dataset.id=P.id;}sl.classList.toggle('nap',P.hp<=0);sl.querySelector('.btEmpty').innerHTML='';}
    else{sc.innerHTML='';sc.dataset.id='';sl.classList.remove('nap');sl.querySelector('.btEmpty').innerHTML='<span>🐾</span>';}
    const col=S.querySelector('.btCol.p'+i);col.innerHTML=colHTML(m,i);
    col.querySelectorAll('[data-a]').forEach(b=>tap(b,()=>humanAct(i,b.dataset.a)));const sk=col.querySelector('[data-sk]');if(sk)tap(sk,()=>{const c=cardOf(act(m,i).id),q=SKL[skillOf(c)];speak(`${q[1]}! ${q[2]}`);sfx.pop();});
    const bn=S.querySelector('.btBench.p'+i);bn.querySelector('.lbl').textContent=`${nm(m,i)}'s bench`;bn.querySelector('.row').innerHTML=benchHTML(m,i);
    bn.querySelectorAll('.btMn').forEach(b=>tap(b,()=>benchTap(i,+b.dataset.k)));});
  const A=act(m,0),B=act(m,1),mt=S.querySelector('.btMatch');
  if(A&&B&&A.hp>0&&B.hp>0){const a=cardOf(A.id).type,b=cardOf(B.id).type,ta=TY(a),tb=TY(b);
    mt.innerHTML=sup(a,b)?`${ta.icon} ${ta.name} beats ${tb.icon} ${tb.name}: <b>Super! for ${E(nm(m,0))}</b>`:sup(b,a)?`${tb.icon} ${tb.name} beats ${ta.icon} ${ta.name}: <b>Super! for ${E(nm(m,1))}</b>`:`${ta.icon} ${ta.name} and ${tb.icon} ${tb.name}: no Super! either way`;mt.style.display='';}
  else mt.style.display='none';}
function matchSay(){const m=M;if(!m)return;const A=act(m,0),B=act(m,1);if(!A||!B)return;const a=cardOf(A.id).type,b=cardOf(B.id).type;sfx.pop();
  if(sup(a,b))speak(`${TY(a).name} beats ${TY(b).name}, because ${WHY[a+'>'+b]}.`);else if(sup(b,a))speak(`${TY(b).name} beats ${TY(a).name}, because ${WHY[b+'>'+a]}.`);
  else speak(`${TY(a).name} and ${TY(b).name}: neither one is Super against the other.`);}

/* ---------- choosing pups ---------- */
function leadPrompt(resumed){const m=M,i=m.lead;drawB();
  const lead=resumed?'Welcome back! ':m.coinSaid&&i===m.first&&m.act[1-i]<0?`The paw coin says ${nm(m,m.first)} goes first! `:'';
  if(isHuman(m,i)){const o=act(m,1-i);say(`${lead}${nm(m,i)}, pick your first pup!${o?` ${nm(m,1-i)} has ${cardOf(o.id).name}, ${art_(TY(cardOf(o.id).type).name)} ${TY(cardOf(o.id).type).name} pup.`:''}`);}
  else{say(`${lead}${nm(m,i)} is picking a first pup…`);later(()=>{if(M!==m||m.phase!=='lead')return;comeIn(i,charChoose(m,i,true),true);},1600);}}
function nextPrompt(resumed){const m=M,i=m.need;drawB();
  if(isHuman(m,i))say(`${resumed?'Welcome back! ':''}${nm(m,i)}, pick your next pup!`);
  else{say(`${nm(m,i)} is picking the next pup…`);later(()=>{if(M!==m||m.phase!=='next')return;comeIn(i,charChoose(m,i,false),false);},1500);}}
function benchTap(i,k){const m=M;if(!m||busy)return;const P=m.teams[i][k];if(!P)return;
  if(!isHuman(m,i)){if(m.seen[P.id]||m.draft){const c=cardOf(P.id);speak(`${c.name}, ${P.hp>0?P.hp+' Zoomies':'napping'}.`);}else{const c=cardOf(P.id);speak(`${art_(TY(c.type).name)} ${TY(c.type).name} pup. It's a surprise!`);}return;}
  if(m.phase==='lead'&&m.lead===i){comeIn(i,k,true);return;}
  if(m.phase==='next'&&m.need===i){if(P.hp<=0){sfx.oops();say(`${cardOf(P.id).name} is napping. Pick a pup that is awake!`);return;}comeIn(i,k,false);return;}
  if(m.phase==='turn'&&m.turn===i&&m.sel==='swap'){if(P.hp<=0){sfx.oops();say(`${cardOf(P.id).name} is napping!`);return;}m.sel=null;doSwap(i,k);return;}
  const c=cardOf(P.id);sfx.pop();speak(`${c.name}, ${P.hp>0?P.hp+' Zoomies':'napping'}. ${TY(c.type).name} type.`);}
function slotTap(i){const m=M;if(!m)return;const P=act(m,i);if(!P)return;const c=cardOf(P.id);sfx.pop();
  speak(`${c.name}: ${Math.max(0,P.hp)} Zoomies out of ${P.mx}. ${c.moves[0][0]}, power ${c.moves[0][2]}. ${c.moves[1][0]}, power ${c.moves[1][2]}.`);}
function comeIn(p,k,opening){const m=M;if(!m||busy)return;const P=m.teams[p][k];if(!P||P.hp<=0)return;
  m.act[p]=k;m.seen[P.id]=1;m.need=-1;m.sel=null;const c=cardOf(P.id);let t=opening?`${nm(m,p)} picks ${c.name}!`:`${nm(m,p)} sends in ${c.name}!`;
  const sk=m.opts.skills?skillOf(c):null;if(sk==='brn'){m.bowl[p]=Math.min(5,m.bowl[p]+1);t+=' Bright Idea: +1 treat!';}
  sfx.pop();const sl=$(`#battle .btSlot.p${p}`);if(sl){sl.classList.remove('deal');void sl.offsetWidth;sl.classList.add('deal');}
  if(opening){const o=1-p;if(m.act[o]<0){m.lead=o;m.phase='lead';persist();drawB();say(t);later(()=>leadPrompt(false),1400);return;}
    m.phase='turn';m.turn=m.first;persist();drawB();say(t);busy=1;later(()=>{busy=0;startTurn(m.first,true);},1600);return;}
  m.phase='turn';persist();drawB();
  if(sk==='spd'&&act(m,1-p)&&act(m,1-p).hp>0){say(t+' Quick Start!');busy=1;later(()=>{busy=0;doMove(p,1,{free:true});},1500);return;}
  say(t);busy=1;afterSpeech(()=>{busy=0;endTurn();},1500,4000);}

/* ---------- turns ---------- */
function startTurn(i,firstTurn){const m=M;if(!m||m.over)return;m.turn=i;m.turnN++;m.sel=null;m.phase='turn';
  const behind=m.opts.catchup&&napped(m,i)-napped(m,1-i)>=2;m.bowl[i]=Math.min(5,m.bowl[i]+1+(behind?1:0));let extra=behind?` Catch-up treat!`:'';
  if(i===1&&m.opp==='muddle'&&!m.pinched&&m.bowl[0]>=1&&m.turnN>=3&&Math.random()<.5){m.pinched=1;m.bowl[0]--;m.bowl[1]=Math.min(5,m.bowl[1]+1);extra+=' Ooh, shiny! Muddle pinches one of Seb\'s treats!';sfx.giggle();}
  persist();drawB();const n=m.bowl[i];
  if(isHuman(m,i))say(`${nm(m,i)}'s turn! ${n} ${n===1?'treat':'treats'}.${extra}${firstTurn&&n<2?' Save up for a big move, or use your everyday move.':''}`);
  else{say(`${nm(m,i)}'s turn…${extra}`);later(charAct,1700+(extra?1500:0));}}
function endTurn(){const m=M;if(!m||m.over)return;startTurn(1-m.turn);}
function humanAct(i,a){const m=M;if(!m||busy||m.over||m.phase!=='turn'||m.turn!==i||!isHuman(m,i))return;const P=act(m,i);if(!P)return;const c=cardOf(P.id);
  if(a==='m1'||a==='m2'){const w=a==='m1'?1:2,mv=c.moves[w-1];if(m.bowl[i]<mv[1]){sfx.oops();say(`${mv[0]} needs ${mv[1]} treats. Save up, or use ${c.moves[0][0]}!`);return;}
    m.sel=null;if(w===2&&pwKind(m,i)){askQ(i,()=>doMove(i,2,{bonus:10}),()=>doMove(i,2,{}));return;}doMove(i,w,{});return;}
  if(a==='save'){m.sel=null;saveUp(i);return;}
  if(a==='swap'){if(!m.opts.swap)return;if(!benchAwake(m,i).length){sfx.oops();say('No pups awake on your bench to swap in!');return;}
    sfx.pop();m.sel=m.sel==='swap'?null:'swap';drawB();if(m.sel)say('Tap a pup on your bench to swap in. Swapping uses your turn.');return;}
  if(a==='cud'){if(!canCud(m,i)){sfx.oops();say(P.cu?'Cuddle Up is used up for this pup.':`${c.name} has all its Zoomies!`);return;}m.sel=null;cuddle(i);}}
function saveUp(i){const m=M;busy=1;sfx.sniff();fxSniff(i);const n=m.bowl[i];persist();drawB();
  say(`${nm(m,i)} saves up. ${n} ${n===1?'treat':'treats'} in the bowl!`);afterSpeech(()=>{busy=0;endTurn();},1500,4000);}
function cuddle(i){const m=M,P=act(m,i),c=cardOf(P.id),b=P.hp;busy=1;P.hp=Math.min(P.mx,P.hp+30);P.cu=1;persist();drawB();fxHearts(i);sfx.chime();
  say(`Cuddle Up! ${c.name} had ${b}. ${b} add ${P.hp-b} makes ${P.hp}.`);afterSpeech(()=>{busy=0;endTurn();},1800,5000);}
function doSwap(i,k){const m=M;m.swapT[i]=m.turnN;const P=act(m,i);const out=P?cardOf(P.id).name:'';sfx.boop();
  say(`${nm(m,i)} swaps ${out} for ${cardOf(m.teams[i][k].id).name}!`);busy=1;later(()=>{busy=0;comeIn(i,k,false);},900);}
function doMove(i,w,o){const m=M;if(!m||m.over)return;const A=act(m,i),D=act(m,1-i);if(!A||!D||A.hp<=0||D.hp<=0){endTurn();return;}
  const c=cardOf(A.id),d=cardOf(D.id),mv=c.moves[w-1];if(!o.free){if(m.bowl[i]<mv[1])return;m.bowl[i]-=mv[1];}
  busy=1;const s=sup(c.type,d.type),bonus=o.bonus||0,dmg=(s?mv[2]*2:mv[2])+bonus,before=D.hp;let hang=false;
  if(m.opts.skills&&skillOf(d)==='brv'&&D.hp===D.mx&&dmg>=D.hp){D.hp=10;hang=true;}else D.hp=Math.max(0,D.hp-dmg);
  if(s&&i===0){m.sup++;const st=SV().stat;st.supers=(st.supers||0)+1;}
  let t=`${c.name}: ${mv[0]}, power ${mv[2]}!`;if(s)t+=` Super! Doubled is ${mv[2]*2}.`;if(bonus)t+=` Power Up makes ${dmg}.`;
  if(hang)t+=` ${d.name} hangs on with 10 Zoomies!`;else if(dmg>before)t+=` ${dmg} is more than ${before}, so no Zoomies left!`;else t+=` ${before} take away ${dmg} leaves ${before-dmg}.`;
  persist();drawB();fxAttack(i,c.type,w===2,s);
  later(()=>{drawB();fxDamage(1-i,dmg,s,hang);if(s)sfx.chime();else sfx.boop();say(t);
    if(D.hp<=0){const key=i+':'+m.act[i];m.naps[key]=(m.naps[key]||0)+1;afterSpeech(()=>napFlow(1-i),2200,7000);}
    else afterSpeech(()=>{busy=0;endTurn();},2000,7000);},650);}
function napFlow(o){const m=M;if(!m)return;const P=act(m,o),c=cardOf(P.id),w=1-o;const sl=$(`#battle .btSlot.p${o}`);if(sl)sl.classList.add('nap');fxZz(o);sfx.boop();
  if(!awake(m,o).length){m.over=true;m.win=w;m.phase='over';persist();drawB();busy=0;sfx.fanfare();confetti(w===0||m.opp==='p2'?90:30);
    say(`${c.name} takes a nap! All of ${nm(m,o)}'s pups are napping. ${nm(m,w)} wins the battle!`);later(finish,3400);return;}
  m.phase='next';m.need=o;persist();busy=0;drawB();
  say(`${c.name} is all tired out and takes a nap! 💤 ${isHuman(m,o)?`${nm(m,o)}, pick your next pup.`:''}`);
  if(!isHuman(m,o))later(()=>{if(M!==m||m.phase!=='next')return;comeIn(o,charChoose(m,o,false),false);},2200);}

/* ---------- characters ---------- */
function plan(m,i,style){const A=act(m,i),D=act(m,1-i);if(!A||!D)return {a:'save'};const c=cardOf(A.id),d=cardOf(D.id),s=sup(c.type,d.type);
  const [n1,c1,p1]=c.moves[0],[n2,c2,p2]=c.moves[1],e1=s?p1*2:p1,e2=s?p2*2:p2,b=m.bowl[i];
  if(style==='simple'){const o=[];if(b>=c1)o.push('m1');if(b>=c2)o.push('m2');return {a:o.length?rnd(o):'save'};}
  if(style==='clever'&&m.opts.swap&&m.swapT[i]<m.turnN-2&&sup(d.type,c.type)){const k=bestBench(m,i,d,true);if(k>=0)return {a:'swap',k};}
  if((style==='careful'||style==='clever')&&canCud(m,i)&&A.hp<=30&&!(b>=c1&&e1>=D.hp))return {a:'cud'};
  if(b>=c1&&e1>=D.hp)return {a:'m1'};if(b>=c2)return {a:'m2'};if(b+1>=c2&&e2>=2*e1)return {a:'save'};if(b>=c1)return {a:'m1'};return {a:'save'};}
function bestBench(m,i,d,needBeat){const L=benchAwake(m,i).map(k=>({k,P:m.teams[i][k],t:cardOf(m.teams[i][k].id).type}));
  let C2=L.filter(q=>sup(q.t,d.type)&&!sup(d.type,q.t)&&q.P.hp>=q.P.mx/2);if(!C2.length&&!needBeat)C2=L.filter(q=>!sup(d.type,q.t));if(!C2.length)return -1;
  return C2.sort((a,b)=>b.P.hp-a.P.hp)[0].k;}
function charChoose(m,i,opening){const st=styleOf(m),L=(opening?m.teams[i].map((P,k)=>k):benchAwake(m,i)),o=act(m,1-i);
  if(st==='simple')return rnd(L);
  if(o&&o.hp>0&&st==='clever'){const k=bestBench(m,i,cardOf(o.id),false);if(k>=0&&L.indexOf(k)>=0)return k;}
  if(opening&&!o)return rnd(L);
  return L.slice().sort((a,b)=>m.teams[i][b].hp-m.teams[i][a].hp)[0];}
function charAct(){const m=M;if(!m||m.over||m.phase!=='turn'||isHuman(m,m.turn)||cur!=='battle'||busy)return;const i=m.turn,p=plan(m,i,styleOf(m));
  if(p.a==='m1'||p.a==='m2'){doMove(i,p.a==='m1'?1:2,{});return;}if(p.a==='swap'){doSwap(i,p.k);return;}if(p.a==='cud'){cuddle(i);return;}saveUp(i);}

/* ---------- maths Power Ups ---------- */
function pwKind(m,i){if(!isHuman(m,i))return null;const k0=m.opts.pw[0];if(i===0)return k0==='off'?null:k0==='mix'?rnd(['tt','zs']):k0;
  const k1=m.opts.pw[1];if(k1==='off')return null;if(k1==='hard')return 'tt3';return k0==='off'||k0==='mix'?'tt':k0;}
function makeQ(m,i){const k=pwKind(m,i),sv=SV();if(!k)return null;
  if(k==='zs'){const A=act(m,i),D=act(m,1-i),c=cardOf(A.id),d=cardOf(D.id),mv=c.moves[1],dm=sup(c.type,d.type)?mv[2]*2:mv[2],ans=Math.max(0,D.hp-dm);
    const dis=shuffle([ans+10,ans+20,ans-10,ans+30].filter(x=>x>=0&&x!==ans)).slice(0,2);
    return {q:`${d.name} has ${D.hp}. ${mv[0]} does ${dm}. How many left?`,show:`${D.hp} − ${dm} = ?`,ans,opts:shuffle([ans].concat(dis))};}
  const lv=k==='tt3'?3:sv.lv;let a,b;if(lv===1){a=rnd([2,5,10]);b=1+Math.floor(Math.random()*10);}else if(lv===2){a=2+Math.floor(Math.random()*9);b=2+Math.floor(Math.random()*9);}
  else{a=2+Math.floor(Math.random()*11);b=2+Math.floor(Math.random()*11);}if(Math.random()<.5)[a,b]=[b,a];const ans=a*b;
  const dis=shuffle([a*(b+1),a*(b-1),(a+1)*b,(a-1)*b,ans+10,ans-1].filter(x=>x>0&&x!==ans)).filter((x,j,A)=>A.indexOf(x)===j).slice(0,2);
  return {q:`Power Up! What is ${a} times ${b}?`,show:`${a} × ${b} = ?`,ans,opts:shuffle([ans].concat(dis)),tt:true};}
function askQ(i,right,wrong){const m=M,Q=makeQ(m,i);if(!Q){wrong();return;}busy=1;const P=$('#btPanel');
  P.innerHTML=`<div class="btQ"><h3>⚡ Power Up!</h3><div class="who">${E(nm(m,i))}, answer for +10 power!</div><div class="q">${Q.show}</div><div class="ans">${Q.opts.map(v=>`<button class="btn white" data-v="${v}">${v}</button>`).join('')}</div></div>`;
  P.classList.add('on');say(Q.q);
  P.querySelectorAll('[data-v]').forEach(b=>tap(b,()=>{if(P.dataset.done)return;P.dataset.done='1';const v=+b.dataset.v,ok=v===Q.ans,sv=SV();
    b.classList.add(ok?'right':'wrong');if(!ok)P.querySelector(`[data-v="${Q.ans}"]`).classList.add('right');
    if(ok){sfx.jingle();if(i===0){m.pu++;sv.stat.pu=(sv.stat.pu||0)+1;if(Q.tt&&pwKind(m,0)!=='tt3'){sv.streak++;if(sv.streak>=5&&sv.lv<3){sv.lv++;sv.streak=0;}}}save();
      say(`Yes! ${Q.ans}! Power Up, plus 10!`);}else{sfx.oops();if(i===0){sv.streak=0;save();}say(`Good try! The answer is ${Q.ans}.`);}
    later(()=>{P.classList.remove('on');delete P.dataset.done;busy=0;(ok?right:wrong)();},ok?1600:2400);}));}

/* ---------- effects ---------- */
const CEN=[[122,350],[902,350]];
function fxAttack(i,type,big,s){const F=$('#btFx');if(!F)return;const sl=$(`#battle .btSlot.p${i}`);if(sl){sl.classList.remove('lunge');void sl.offsetWidth;sl.classList.add('lunge');}
  const [x0,y0]=CEN[i],[x1,y1]=CEN[1-i],n=big?14:7;
  for(let j=0;j<n;j++){const p=el('span','btP',FX[type]||'✨');p.style.left=x0+'px';p.style.top=(y0-20+Math.random()*40)+'px';p.style.fontSize=(big?46:34)+'px';F.appendChild(p);
    setTimeout(()=>{p.style.transform=`translate(${x1-x0+(Math.random()*120-60)}px,${y1-y0+(Math.random()*160-80)}px) rotate(${Math.random()*360}deg) scale(${big?1.3:1})`;p.style.opacity='0';},40+j*40);setTimeout(()=>p.remove(),1100+j*40);}}
function fxDamage(o,dmg,s,hang){const F=$('#btFx');if(!F)return;const [x,y]=CEN[o];const sl=$(`#battle .btSlot.p${o}`);if(sl){sl.classList.remove('shake');void sl.offsetWidth;sl.classList.add('shake');}
  const d=el('div','btDmg',hang?'🛡️ 10!':'−'+dmg);d.style.left=(x-80)+'px';d.style.top=(y-60)+'px';F.appendChild(d);setTimeout(()=>d.remove(),1600);
  if(s){const b=el('div','btSuper','Super!');F.appendChild(b);setTimeout(()=>b.remove(),1500);}}
function fxZz(o){const F=$('#btFx');if(!F)return;const [x,y]=CEN[o];for(let j=0;j<3;j++){const z=el('span','btZz','💤');z.style.left=(x+20*j-20)+'px';z.style.top=(y-40)+'px';z.style.animationDelay=(j*.3)+'s';F.appendChild(z);setTimeout(()=>z.remove(),2600);}}
function fxHearts(i){const F=$('#btFx');if(!F)return;const [x,y]=CEN[i];for(let j=0;j<6;j++){const z=el('span','btZz','💖');z.style.left=(x-60+Math.random()*120)+'px';z.style.top=(y+20)+'px';z.style.animationDelay=(j*.15)+'s';F.appendChild(z);setTimeout(()=>z.remove(),2600);}}
function fxSniff(i){const F=$('#btFx');if(!F)return;const [x,y]=CEN[i];const z=el('span','btZz','🦴');z.style.left=(x-20)+'px';z.style.top=(y+40)+'px';F.appendChild(z);setTimeout(()=>z.remove(),2600);}

/* ---------- the end ---------- */
function finish(){const m=M;if(!m)return;const sv=SV(),w=m.win<0?0:m.win,L=LEN(m.size),o=OPP(m.opp),oppKey=m.opp==='p2'?m.p2.name:o?o.name:'?';
  let stars=L.stars,newStep=false;if(m.step&&w===0&&!sv.ladder.done[m.step]){sv.ladder.done[m.step]=1;stars+=10;newStep=true;}
  state.stars+=stars;sv.rec[oppKey]=sv.rec[oppKey]||[0,0];sv.rec[oppKey][w]++;const rec=sv.rec[oppKey],st=sv.stat;
  st.games=(st.games||0)+1;if(m.opp==='p2'){st.pals=(st.pals||0)+1;if(w===0)st.champ=(st.champ||0)+1;}else{st.cpu=(st.cpu||0)+1;if(w===0)st.cpuWin=(st.cpuWin||0)+1;}
  if(m.size>=9)st.full=(st.full||0)+1;
  const ladderDone=!!m.step&&newStep&&!ladderNext()&&!st.ladder;if(ladderDone)st.ladder=1;
  if(!sv.coin)sv.first=1-m.first;sv.match=null;
  let top=null;Object.keys(m.naps).forEach(k=>{const [side,ix]=k.split(':').map(Number);if(side!==w)return;if(!top||m.naps[k]>top.n)top={n:m.naps[k],id:m.teams[side][ix].id};});
  const done=m;M=null;save();setMode('setup');$('#btBody').innerHTML='';
  const bc=top&&cardOf(top.id),n0=nm(done,0),n1=nm(done,1);
  const head=w===0?(o&&o.uni?'Seb beats the Champion!':'Seb wins the battle!'):`${n1} wins this time!`;
  const line=w===0?(done.opp==='p2'?`Well played, ${n1}!`:`${o.short}: "${o.lose}"`):(done.opp==='p2'?'Well played, Seb!':`${o.short}: "${o.win}" Try again!`);
  const again=()=>{if(done.opp==='p2'){startFlow();return;}if(done.step&&SV().opp==='ladder'){startFlow();return;}PICK={opp:done.opp,step:null,pool:SHW.poolFor(SV().sets).filter(id=>cardOf(id)),team:SV().team.slice(),filt:null};pickView(true);};
  const after=()=>{if(ladderDone){confetti(120);sfx.fanfare();card({cls:'sdEnd',art:'<div style="font-size:110px;line-height:1">👑</div>',h:'Battle Champion!',
      p:'Seb beat every step of the Battle Ladder: Granny Paws, Sensei Mochi, Professor Hoot, Chief Woofles, the Unicorn Champions and Muddle! You are a true Zoomies Battle Champion!',btns:[['🎉 Hooray!','green',()=>setupView()]]});}
    else setupView();};
  confetti(w===0?90:30);sfx.fanfare();
  card({cls:'sdEnd',art:`<div class="sdEndA"><div class="av">${avatar(done,w)}</div>${bc?`<div class="bp">${C.miniHTML(bc,{force:true})}<small>⭐ Star pup</small></div>`:''}</div>`,h:head,
    p:`${line}${bc?`<br>Star pup of the battle: <b>${E(bc.name)}</b>, who sent ${top.n} ${top.n===1?'pup':'pups'} to sleep!`:''}${newStep?'<br>🪜 A new step on the Battle Ladder! +10 ⭐':''}${done.opp==='p2'&&done.opts.pw[0]!=='off'&&done.pu?`<br>🧮 ${done.pu} Power Ups right!`:''}<br>+${L.stars} ⭐ for playing! Seb ${rec[0]}, ${E(done.opp==='p2'?done.p2.name:o.short)} ${rec[1]}.`,
    btns:[['▶ Play again','green',again],['Done','white',after]]});}

/* ---------- the type chart ---------- */
function openChart(){let O=$('#btChart');if(!O){O=el('div','','');O.id='btChart';$('#stage').insertBefore(O,$('#bubble'));}
  const row=t=>{const T=TY(t),b=BEATS[t];return `<button class="btCR" data-t="${t}"><span class="ty" style="background:${T.col}">${T.icon}</span><span class="nm">${T.name}<small>${ISLE[t]}</small></span><span class="bt">beats</span>${b.map(x=>`<span class="vs" style="background:${TY(x).col}">${TY(x).icon} ${TY(x).name}</span>`).join('')}</button>`;};
  O.innerHTML=`<div class="btCP"><h3>🌈 Type Chart: who is Super against who?</h3><div class="btCG">${ORDER.map(row).join('')}</div>
    <p class="al">👽 Alien pups are a mystery: no type beats them, and they beat nobody.</p><p class="tip">Tap a type to hear why. Super! doubles the power of a move.</p><button class="btn green" id="btChartX">✓ Done</button></div>`;
  O.classList.add('on');tap('#btChartX',()=>{sfx.boop();closeChart();});
  O.querySelectorAll('[data-t]').forEach(b=>tap(b,()=>{sfx.pop();const t=b.dataset.t,T=TY(t),B=BEATS[t];speak(`${T.name} beats ${TY(B[0]).name}, because ${WHY[t+'>'+B[0]]}. And ${TY(B[1]).name}, because ${WHY[t+'>'+B[1]]}.`);}));
  speak('The type chart. Every type beats two types. Tap one to hear why!');}
function closeChart(){const O=$('#btChart');if(O)O.classList.remove('on');}

/* ---------- ways in ---------- */
function addBinderBtns(){const B=$('#binder');if(!B)return false;if($('#bdBT'))return true;
  const b=el('button','bdMark','<span class="i">⚔️</span><small>Battle</small>');b.id='bdBT';B.appendChild(b);tap(b,()=>{sfx.pop();open('binder');});
  const t=el('button','bdMark','<span class="i">🌈</span><small>Types</small>');t.id='bdTY';B.appendChild(t);tap(t,()=>{sfx.pop();openChart();});return true;}
{const t=setInterval(()=>{if(addBinderBtns())clearInterval(t);},400);}
if(typeof showTitle==='function'){}
if(typeof openGames==='function'){const _og=openGames;openGames=function(tab){_og.apply(this,arguments);try{if(arcTab!=='games')return;const g=$('#menuCard .gcols');if(!g||g.querySelector('[data-g="battle"]'))return;
    const sv=SV(),r=sv.stat.games?`${sv.stat.games} played`:'New!';const b=el('button','grow',`<span class="gi">⚔️</span><span class="gn">Zoomies Battle</span><span class="gb">${r}</span>`);b.dataset.g='battle';g.appendChild(b);}catch(e){}};}
if(typeof startGame==='function'){const _sg=startGame;startGame=function(k){if(k==='battle'){open('arcade');return;}return _sg.apply(this,arguments);};}
setInterval(()=>{if(cur==='battle'&&state&&!sleepOn&&!ovOpen())playClock(1);},1000);
/* the chart closes if the binder or another screen takes over */
setInterval(()=>{const O=$('#btChart');if(O&&O.classList.contains('on')&&cur!=='battle'&&cur!=='binder')O.classList.remove('on');},500);
const bst=()=>(state.cards&&state.cards.bt&&state.cards.bt.stat)||{};
MERITS.push(
  {id:'btpals',icon:'👫',name:'Battle Pals',how:'Finish a Zoomies Battle with a friend on the same iPad.',ok:()=>!!bst().pals},
  {id:'btchamp',icon:'⚔️',name:'Battle Champ',how:'Win a two-player Zoomies Battle.',ok:()=>!!bst().champ},
  {id:'btsuper',icon:'💥',name:'Super Pup',how:'Land 25 Super! moves in Zoomies Battle.',ok:()=>(bst().supers||0)>=25},
  {id:'btpower',icon:'🧠',name:'Power Up Pro',how:'Get 20 Power Up sums right in Zoomies Battle.',ok:()=>(bst().pu||0)>=20},
  {id:'btfull',icon:'🏟️',name:'Full Tin',how:'Finish a Full Tin Battle, 9 pups each.',ok:()=>!!bst().full},
  {id:'btladder',icon:'👑',name:'Battle Champion',how:'Finish the Battle Ladder, all the way to Muddle.',ok:()=>!!bst().ladder});

/* ---------- styles ---------- */
{const st=document.createElement('style');st.textContent=`
#battle{background:radial-gradient(circle at 50% 42%,#e86a5a,#7e2f45 78%);color:#5b4636}
#battle.on~#bubble{left:104px;width:690px}
#btH{position:absolute;left:104px;top:22px;margin:0;font-size:34px;color:#fff;white-space:nowrap;text-shadow:3px 3px 0 #5b4636,-2px 2px 0 #5b4636,2px -2px 0 #5b4636,-2px -2px 0 #5b4636}
#btTag{right:14px;top:18px}
#bdBT{top:290px;background:#ffb4a8}#bdTY{top:522px;background:#e6dcff}
.btSetup .sdChip{min-width:0;padding:0 11px}.btSetup .sdChip.tg{min-width:150px}
.sdIn{width:130px;height:58px;border:4px solid #5b4636;border-radius:18px;font:inherit;font-size:22px;font-weight:900;padding:0 10px;color:#5b4636;margin-right:12px}
.btLad{display:flex;align-items:center;flex-wrap:nowrap;gap:1px}.btLad i{font-style:normal;color:#fff;font-size:16px;font-weight:900;margin:0 1px}
.btLad .st{position:relative;width:42px;height:42px;flex:none;border-radius:50%;background:#fff;border:3px solid #5b4636;overflow:hidden;opacity:.75}
.btLad .st .fitsvg,.btLad .st svg{width:38px;height:38px;display:block}.btLad .st.done{background:#8fe39a;opacity:1}.btLad .st.nx{opacity:1;box-shadow:0 0 0 4px #fff27a;transform:scale(1.12)}
.btLad .st.lk{filter:grayscale(1)}.btLad .st b{position:absolute;right:-1px;bottom:-3px;font-size:17px;text-shadow:1px 1px 0 #fff}
#btPanel{position:absolute;inset:0;background:rgba(40,20,40,.55);display:none;z-index:30}#btPanel.on{display:block}#btPanel .sdPan{padding-bottom:96px}#btPanel .sdOpt label{width:290px}
#btFx{position:absolute;inset:0;pointer-events:none;z-index:28}
.btPick{position:absolute;left:20px;right:20px;top:136px;bottom:10px}
.btVs{position:absolute;left:0;top:0;width:250px;height:118px;display:flex;align-items:center;gap:8px;color:#fff;text-shadow:2px 2px 0 #5b4636}
.btVs .av{width:76px;height:76px;flex:none;background:#fffaf0;border:4px solid #5b4636;border-radius:50%;overflow:hidden}.btVs .av .fitsvg,.btVs .av svg{width:70px;height:70px}
.btVs b{display:block;font-size:22px;line-height:1.1}.btVs small{display:block;font-size:17px;font-weight:800;margin-top:4px}
.btSlots{position:absolute;left:256px;top:0;right:150px;height:118px;display:flex;gap:6px;align-items:flex-start}
.btMn{position:relative;width:76px;height:106px;flex:none;border:0;padding:0;background:none}.btMn .sc{position:absolute;left:0;top:0;transform-origin:0 0}
.btSlots.n9 .btMn{width:56px;height:78px}
.btMn.empty{border:4px dashed rgba(255,255,255,.7);border-radius:12px;box-sizing:border-box;display:flex;align-items:center;justify-content:center;color:#fff;font-size:34px;font-weight:900}
.btMn.empty.sm{width:53px;height:74px;font-size:24px}
.btTZ{position:absolute;right:0;top:4px;width:140px;text-align:center;color:#fff;font-size:17px;font-weight:900;text-shadow:2px 2px 0 #5b4636}.btTZ b{display:block;font-size:40px}
.btTZ.sm{position:static;width:auto;font-size:15px;margin-top:4px}.btTZ.sm b{display:inline;font-size:22px;margin-left:6px}
.btFilt{position:absolute;left:0;right:0;top:126px;height:66px;display:flex;gap:6px;overflow-x:auto;overflow-y:hidden;white-space:nowrap}
.btFilt .sdChip{height:58px;min-width:0;padding:0 10px;font-size:24px;flex:none;margin:0}
.btGrid{position:absolute;left:0;right:0;top:198px;bottom:84px;overflow-y:auto;display:flex;flex-wrap:wrap;gap:10px 8px;align-content:flex-start;padding:4px;background:rgba(255,255,255,.12);border-radius:20px}
.btGrid .btMn.chosen{opacity:.35}.btGrid .btMn.chosen::after{content:'✓';position:absolute;left:24px;top:28px;font-size:40px;color:#fff;font-weight:900;text-shadow:2px 2px 0 #5b4636}
.btPF{position:absolute;left:0;right:0;bottom:0;height:76px;display:flex;gap:12px;align-items:center}
.btPF .btn{height:70px;min-height:0;font-size:24px}#btGo{margin-left:auto;min-width:230px;font-size:32px}#btGo.off{opacity:.5}
.btDraft{position:absolute;left:0;right:0;top:136px;bottom:0}
.btDS{position:absolute;top:0;width:250px}.btDS.p0{left:12px}.btDS.p1{right:12px}
.btDS .sdPlate{position:relative;left:0;top:0;width:250px}.btDS .sdPlate .nm{width:110px;font-size:22px}.btDS .sdPlate .sc{font-size:26px;width:70px}
.btDT{display:grid;grid-template-columns:repeat(4,53px);gap:8px 7px;margin-top:10px;justify-content:center}.btDT .btMn{width:53px;height:74px}
.btDS .btTZ.sm{text-align:center}
.btDP{position:absolute;left:276px;right:276px;top:0;bottom:12px;display:flex;flex-wrap:wrap;gap:8px 6px;align-content:flex-start;justify-content:center;overflow-y:auto;background:rgba(255,255,255,.12);border-radius:20px;padding:8px 4px}
.btDP .btMn{width:70px;height:97px}
.btReady{margin-top:200px;font-size:44px;font-weight:900;color:#fff;text-shadow:3px 3px 0 #5b4636}
.btPl{top:140px;height:58px}.btPl .nm{width:120px}.btPl .bowl{display:flex;gap:1px;margin-left:4px}.btPl .bowl i{font-style:normal;font-size:22px;opacity:.2;filter:grayscale(1)}.btPl .bowl i.on{opacity:1;filter:none}
.btPl .aw{margin-left:auto;font-size:20px;font-weight:900;white-space:nowrap}.btPl .aw b{font-size:28px}
.btSlot{position:absolute;top:206px;width:205px;height:287px;transition:filter .4s}.btSlot.p0{left:20px}.btSlot.p1{left:799px}
.btScale{width:410px;height:574px;transform:scale(.5);transform-origin:0 0;pointer-events:none}
.btEmpty{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-size:70px;opacity:.5}.btEmpty:empty{display:none}
.btEmpty span{width:180px;height:260px;border:5px dashed rgba(255,255,255,.7);border-radius:24px;display:flex;align-items:center;justify-content:center}
.btSlot.nap{filter:grayscale(1) brightness(.85);transform:rotate(-4deg)}
.btSlot.deal{animation:sdDeal .45s ease-out}.btSlot.lunge.p0{animation:btL0 .5s ease-out}.btSlot.lunge.p1{animation:btL1 .5s ease-out}
@keyframes btL0{40%{transform:translateX(60px) rotate(4deg)}}@keyframes btL1{40%{transform:translateX(-60px) rotate(-4deg)}}
.btSlot.shake{animation:btSh .5s ease-out}@keyframes btSh{20%{transform:translateX(-10px)}40%{transform:translateX(10px)}60%{transform:translateX(-6px)}80%{transform:translateX(6px)}}
.btCol{position:absolute;top:206px;width:262px;height:290px}.btCol.p0{left:234px}.btCol.p1{left:528px}
.btZ{background:#fffaf0;border:4px solid #5b4636;border-radius:16px;padding:4px 8px 6px;box-sizing:border-box;height:62px}
.btZ span{display:block;font-size:18px;font-weight:900;line-height:1.1}.btZ span b{font-size:24px;margin-left:4px}.btZ span small{font-size:15px;margin-left:4px}
.btZ .blk{display:flex;gap:2px;margin-top:3px}.btZ .blk i{flex:1;max-width:19px;height:16px;border-radius:4px;background:#e4dccd;border:2px solid #5b4636;box-sizing:border-box}.btZ .blk i.on{background:#3fae5a}
.btZ.nap .blk i{background:#ccc}
.btSk{height:28px;margin:5px 0 4px;font-size:17px;font-weight:900;color:#fff;text-shadow:2px 2px 0 #5b4636;line-height:28px;pointer-events:auto}.btSk.none{visibility:hidden}
.btMv{position:relative;display:flex;align-items:center;width:262px;height:56px;margin:0 0 6px;padding:0 8px;border:4px solid #5b4636;border-radius:16px;background:#fff;font:inherit;color:#5b4636;font-weight:900;box-sizing:border-box}
.btMv.big{background:#fff2b8}.btMv .cost{font-size:16px;width:52px;text-align:left;letter-spacing:-3px}.btMv b{flex:1;text-align:left;font-size:18px;line-height:1.05;overflow:hidden}
.btMv .pw{font-size:28px;min-width:44px;text-align:right;padding-left:6px}.btMv em{position:absolute;right:-6px;top:-12px;background:#ff4f6d;color:#fff;font-style:normal;font-size:14px;padding:1px 7px;border-radius:10px;border:2px solid #fff;transform:rotate(6deg)}
.btMv.off,.btA.off{opacity:.45}.btMv.hint,.btA.hint{box-shadow:0 0 0 4px #fff27a,0 0 16px 6px #ffd23f}
.btAux{display:flex;gap:6px}.btA{flex:1;height:52px;border:4px solid #5b4636;border-radius:14px;background:#fff;font:inherit;font-weight:900;font-size:16px;color:#5b4636;padding:0 4px;white-space:nowrap}
.btA.sel{background:#ffd86b}
.btWait{margin-top:110px;text-align:center;color:#fff;font-size:24px;font-weight:900;text-shadow:2px 2px 0 #5b4636}
.btBench{position:absolute;top:504px;width:480px;height:132px}.btBench.p0{left:20px}.btBench.p1{left:524px}
.btBench .lbl{font-size:17px;font-weight:900;color:#fff;text-shadow:2px 2px 0 #5b4636;height:22px}.btBench.p1 .lbl{text-align:right}
.btBench .row{display:flex;gap:5px;flex-wrap:nowrap}.btBench.p1 .row{justify-content:flex-end}
.btMn.bn{width:calc(127px*var(--s));height:calc(177px*var(--s))}.btMn.bn.nap .sc{filter:grayscale(1);opacity:.55}
.btMn.bn .zz{position:absolute;right:-4px;top:-8px;font-style:normal;font-size:22px}.btMn.bn .hp{position:absolute;left:-4px;top:-8px;font-style:normal;font-size:13px;font-weight:900;background:#fff;border:2px solid #5b4636;border-radius:9px;padding:0 4px}
.btMn.bn.can{animation:sdPulse2 1s ease-in-out infinite}.btMn.bn.can .sc{box-shadow:0 0 0 4px #fff27a,0 0 14px 6px #ffd23f;border-radius:12px}
.btClue{width:127px;height:177px;border-radius:12px;border:4px solid #5b4636;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-shadow:2px 2px 0 #5b4636}
.btClue span{font-size:54px;line-height:1}.btClue b{font-size:60px;line-height:1}
.btMatch{position:absolute;left:150px;right:150px;top:648px;height:40px;line-height:36px;text-align:center;background:rgba(255,255,255,.92);border:4px solid #5b4636;border-radius:20px;font-size:19px;font-weight:800;white-space:nowrap;overflow:hidden}
.btMatch b{color:#d0304a}
#btTypes{position:absolute;left:432px;top:698px;width:160px;height:60px;min-height:0;font-size:22px}
.btP{position:absolute;transition:transform .7s cubic-bezier(.3,.6,.4,1),opacity .7s ease-in;margin:-20px 0 0 -20px}
.btDmg{position:absolute;width:160px;text-align:center;font-size:58px;font-weight:900;color:#fff;text-shadow:3px 3px 0 #d0304a,-2px 2px 0 #5b4636,2px -2px 0 #5b4636;animation:btUp 1.6s ease-out forwards}
@keyframes btUp{from{transform:translateY(20px) scale(.6);opacity:0}25%{transform:none;opacity:1}to{transform:translateY(-60px);opacity:0}}
.btSuper{position:absolute;left:362px;top:300px;width:300px;text-align:center;font-size:76px;font-weight:900;color:#fff27a;text-shadow:4px 4px 0 #d0304a,-3px 3px 0 #5b4636,3px -3px 0 #5b4636;animation:btSup 1.5s ease-out forwards}
@keyframes btSup{from{transform:scale(.3) rotate(-10deg);opacity:0}30%{transform:scale(1.15) rotate(4deg);opacity:1}70%{transform:scale(1);opacity:1}to{opacity:0}}
.btZz{position:absolute;font-size:40px;animation:btZz 2.4s ease-out forwards;opacity:0}@keyframes btZz{10%{opacity:1}to{transform:translate(30px,-110px) scale(1.4);opacity:0}}
.btQ{position:absolute;left:212px;right:212px;top:190px;background:#fffaf0;border:6px solid #5b4636;border-radius:30px;padding:16px 20px 24px;text-align:center}
.btQ h3{margin:0;font-size:36px}.btQ .who{font-size:20px;font-weight:800}.btQ .q{font-size:76px;font-weight:900;margin:8px 0 14px}
.btQ .ans{display:flex;gap:18px;justify-content:center}.btQ .ans .btn{min-width:150px;height:96px;font-size:48px}
.btQ .ans .btn.right{background:#8fe39a}.btQ .ans .btn.wrong{background:#ffb0b0}
#btChart{position:absolute;inset:0;z-index:46;background:rgba(30,20,50,.55);display:none}#btChart.on{display:block}
.btCP{position:absolute;left:60px;right:60px;top:136px;bottom:14px;background:#fffaf0;border:5px solid #5b4636;border-radius:28px;padding:10px 20px}
.btCP h3{margin:2px 0 10px;font-size:28px}.btCG{display:grid;grid-template-columns:1fr 1fr;gap:10px 12px}
.btCR{display:flex;align-items:center;gap:6px;height:62px;border:3px solid #5b4636;border-radius:16px;background:#fff;font:inherit;color:#5b4636;font-weight:900;padding:0 8px;text-align:left}
.btCR .ty{width:42px;height:42px;border-radius:50%;border:3px solid #5b4636;font-size:24px;line-height:36px;text-align:center;flex:none}
.btCR .nm{width:108px;font-size:20px;line-height:1}.btCR .nm small{display:block;font-size:12px;font-weight:800;opacity:.75;margin-top:2px}
.btCR .bt{font-size:15px;opacity:.7}.btCR .vs{border-radius:12px;color:#fff;font-size:15px;padding:4px 7px;text-shadow:1px 1px 0 #5b4636;white-space:nowrap}
.btCP .al{font-size:18px;font-weight:800;margin:8px 0 2px}.btCP .tip{font-size:16px;font-weight:700;margin:0;opacity:.8}
#btChartX{position:absolute;right:20px;bottom:14px}
`;document.head.appendChild(st);}
window.BATTLE={open,SV,get M(){return M;},set M(v){M=v;},buildMap,OPP,ladderSteps,ladderNext,startFlow,startMatch,charTeam,teamZ,plan,skillOf,sup,doMove,humanAct,benchTap,comeIn,startTurn,
  finish:()=>finish(),openChart,closeChart,makeQ,pwKind,get PICK(){return PICK;},get DRAFT(){return DRAFT;},draftPick,toggleTeam,beginVsChar,cardOf,awake,act};
})();
