/* ================================================================
   Seb's Puppy Quest 3: Release 4, village growth.
   A richer Pawprint Village, plus three new places:
   - the Shop (spend stars on den things, costumes and treats)
   - the Pup Spa (feed, bath, brush, walk and dress pups; each care
     earns friendship hearts, and 10 hearts makes a sparkly best friend)
   - Seb's Den (a 3D room he decorates; favourite pups nap there)
   ================================================================ */
const bestFriend=id=>((state.friend||{})[id]||0)>=10;
(function(){
const V=AREAS.village,PATHS=[[0,12,0,44,5],[-8,-6,-20,-10,4],[8,-6,21,-12,4],[-6,8,-22,16,4],[6,8,36,20,4],[-6,8,-33,28,4],[0,-12,0,-31,4],[-8,-10,-26,-29,4],[9,-10,25,-25,4],[12,-2,33,-5,4],[-34,-8,-24,-10,3],[10,-10,38,-24,4],[-6,-12,-14,-39,4],[-8,11,-12,29,3.5],[16,11,31,31,4]];
const segD=(x,z,p)=>{const dx=p[2]-p[0],dz=p[3]-p[1],L=dx*dx+dz*dz,t=Math.max(0,Math.min(1,((x-p[0])*dx+(z-p[1])*dz)/L));return Math.hypot(x-p[0]-dx*t,z-p[1]-dz*t);};
V.biome='village';V.keepOut=(x,z)=>Math.hypot(x,z)<15||PATHS.some(p=>segD(x,z,p)<p[4]/2+1.2)||z>40;
V.hello='Welcome to Pawprint Village! This is your home. Take the ferry from the jetty to Meadow Island!';
V.build=function(){const R=seed(11);
  /* ----- the plaza: cobbles, map tower, fountain, lamps, bunting, benches ----- */
  const ring=new THREE.Mesh(G.disc,M('#cbb89a'));ring.scale.set(14.2,1,14.2);ring.position.y=.04;W.ag.add(ring);
  const pl=new THREE.Mesh(G.disc,M('#ead9bd'));pl.scale.set(13,1,13);pl.position.y=.05;W.ag.add(pl);
  for(let i=0;i<70;i++){const a=R()*6.28,r=3+R()*9.5;I('cyl',pick(['#d9c6a6','#e0cfb0','#cdb894']),.5+R()*.3,.04,.5+R()*.3,Math.cos(a)*r,.08,Math.sin(a)*r);}
  PATHS.forEach(p=>{const d=Math.hypot(p[2]-p[0],p[3]-p[1]),m=new THREE.Mesh(G.plane,M('#ead9bd'));m.scale.set(p[4],1,d);m.position.set((p[0]+p[2])/2,gy((p[0]+p[2])/2,(p[1]+p[3])/2)+.06,(p[1]+p[3])/2);m.rotation.y=Math.atan2(p[2]-p[0],p[3]-p[1]);W.ag.add(m);
    for(let t=.15;t<1;t+=.18){const x=p[0]+(p[2]-p[0])*t,z=p[1]+(p[3]-p[1])*t;I('cyl','#d9c6a6',.35,.03,.35,x+(R()-.5)*p[4]*.6,gy(x,z)+.09,z+(R()-.5)*1.5);}});
  I('cyl','#c9c2b8',2.2,12,2.2,0,6,-4);I('cyl','#b0a89c',2.6,.8,2.6,0,12.2,-4);I('cone','#e8423a',3,4,3,0,14.6,-4);I('cyl','#9b6a43',.1,3,.1,0,17.5,-4);I('box','#3fae5a',1.8,1,.08,.9,18.4,-4);
  I('box','#5b4636',1.4,2.2,.2,0,1.1,-1.75);for(let i=0;i<3;i++){I('box','#9bdcff',.8,.8,.2,0,4+i*3,-1.76);I('box','#ffffff',1,1,.12,0,4+i*3,-1.7);}for(let i=0;i<8;i++){const a=i*.785;I('box','#b0a89c',.7,.9,.7,Math.cos(a)*2.4,12.9,-4+Math.sin(a)*2.4);}
  I('cyl','#ffffff',2.25,.3,2.25,0,9,-4);col(0,-4,2.6);const tl=label('🗺️ Map Tower',7);tl.position.set(0,20.5,-4);W.ag.add(tl);
  W.things.push({x:0,z:-1,r:4,icon:'🗺️',label:'Map',act:()=>{sfx.chime();worldMap();}});
  I('cyl','#c9c2b8',2.6,.8,2.6,0,.4,5);I('cyl','#7fd3f0',2.2,.1,2.2,0,.82,5,0,0,0,true);I('cyl','#c9c2b8',.4,2.2,.4,0,1.7,5);I('cyl','#c9c2b8',1.1,.25,1.1,0,2.8,5);I('sph','#7fd3f0',.6,.4,.6,0,3.2,5,0,0,0,true);col(0,5,2.7);
  let dropT=0;W.ticks.push(dt=>{dropT-=dt;if(dropT<0){dropT=.35;floatS('💧',(Math.random()-.5)*1.6,3.3,5+(Math.random()-.5)*1.6,.5,.7);}});
  const LP=[25,108,180,-68].map(a=>[Math.cos(a*D2R)*11.5,Math.sin(a*D2R)*11.5]);LP.forEach(p=>lampPost(p[0],p[1]));for(let i=0;i<4;i++){const a=LP[i],b=LP[(i+1)%4];bunting(a[0],a[1],b[0],b[1],4.4);}
  bench(8,1,'w');bench(-7.6,3.2,'e');bench(-3,-8.2,'s');planter(-12,-4);planter(13,3,'#ff9ecb');planter(-7,12.5,'#fff27a');planter(8,12.5,'#c9b6ff');bin(4.5,12.5);
  signpost(4,-14,[['🛍️ Shop ↑','#fff2b8'],['🎮 Arcade ↖','#e6d9ff'],['🛁 Pup Spa ↗','#c9f0ff'],["🏠 Seb's Den →",'#d9f5c2']]);signpost(-13,-2,[['🪁 Kite hill ←','#ffd9c9']]);signpost(-4,-22,[['🔬 Science Lab ↙','#c9f0ff']]);signpost(14,-12,[['🚂 Station →','#e6d9ff']]);
  /* ----- lamps along the paths ----- */
  [[3.5,22],[-3.5,32],[-12,-11],[13,-11],[-12,18],[17,16],[-20,21],[25,19],[3,-22],[-16,-21],[16,-19],[24,-6]].forEach(p=>lampPost(p[0],p[1]));
  /* ----- the Pup House ----- */
  {const hx=-20,hz=-12;I('box','#ffb3cf',10,6,8,hx,3,hz);I('box','#e68ab0',10.2,.5,8.2,hx,.25,hz);I('pyr','#e8423a',8.2,4.2,6.2,hx,8.1,hz,0,Math.PI/4,0);I('box','#ffffff',10.6,.3,8.6,hx,6.05,hz);
    I('box','#5b4636',2.6,3.6,.3,hx+2.6,1.8,hz+4.05);I('cyl','#5b4636',1.3,.3,1.3,hx+2.6,3.6,hz+4.05,Math.PI/2,0,0);I('box','#c9c2b8',3.4,.25,1,hx+2.6,.12,hz+4.6);
    I('box','#9bdcff',1.6,1.6,.2,hx-2.4,3.4,hz+4.05);I('box','#ffffff',1.9,1.9,.1,hx-2.4,3.4,hz+4.02);I('box','#9b6a43',1.8,.3,.4,hx-2.4,2.4,hz+4.3);for(let k=0;k<4;k++)I('sph',['#ff6b6b','#fff27a','#ff9ecb','#c9b6ff'][k],.16,.14,.16,hx-3+k*.4,2.65,hz+4.3);
    I('cyl','#ffffff',.25,1.6,.25,hx,8.6,hz+3.2,0,0,Math.PI/2);[-1,1].forEach(s=>{I('sph','#ffffff',.35,.35,.35,hx+s*.9,8.8,hz+3.2);I('sph','#ffffff',.35,.35,.35,hx+s*.9,8.4,hz+3.2);});
    [[hx+4.5,hz+5.2],[hx+5.2,hz+4.6]].forEach((q,i)=>{I('cyl',i?'#3d8fe0':'#e8423a',.45,.25,.45,q[0],.13,q[1]);I('cyl','#c9905f',.35,.05,.35,q[0],.27,q[1]);});
    for(let i=0;i<6;i++)spr('🐾',.7,hx+2.6+(i%2?.5:-.5),.06,hz+6+i*1.4);rect(hx-5,hz-4,hx+5,hz+4);camBlock(hx-5,hz-4,hx+5,hz+4);
    hedgeRow(hx-5,hz+5,hx+.6,hz+5,'#5fbf5a');const hl=label('🏠 Pup House',7);hl.position.set(hx,12,hz);W.ag.add(hl);
    W.things.push({x:hx+2.6,z:hz+6,r:4,icon:'📖',label:'Pup House',act:()=>showBook()});}
  /* ----- Granny's cottage and garden ----- */
  {const gx=22,gz=-14,H=house(gx,gz,{w:8,d:7,wall:'#fff2b8',roof:'#9b6a43',trim:'#ffffff',label:"🧶 Granny's Cottage",lw:7});
    fence(gx-5,gz+5.5,gx-1.2,gz+5.5,'#ffffff');fence(gx+1.2,gz+5.5,gx+5,gz+5.5,'#ffffff');fence(gx+5,gz+5.5,gx+5,gz-4,'#ffffff');
    flowerPatch(gx+3,gz+4.6,12,1.4,['#ff9ecb','#ffffff','#c9b6ff'],R);flowerPatch(gx-3,gz+4.6,12,1.4,['#fff27a','#ff6b6b'],R);wheelbarrow(gx+7,gz+2);
    [[gx+6.5,gz-6],[gx+9.5,gz-6]].forEach(p=>I('cyl','#9b6a43',.08,2.4,.08,p[0],gy(p[0],p[1])+1.2,p[1]));I('cyl','#ffffff',.02,3,.02,gx+8,gy(gx+8,gz-6)+2.3,gz-6,0,0,Math.PI/2);['#ff9ecb','#7fc8f0','#fff27a'].forEach((c,i)=>I('box',c,.7,.9,.05,gx+7+i*.9,gy(gx+8,gz-6)+1.85,gz-6));
    spr('🐈',1.6,gx-1,gy(gx,gz)+7,gz+.5);mailbox(gx+2,gz+6.6);
    const gr=granny3D();add(gr,gx-4,gz+7);col(gx-4,gz+7,1);W.ticks.push(()=>{gr.rotation.y=Math.atan2(player.x-gr.position.x,player.z-gr.position.z);});
    W.things.push({x:gx-4,z:gz+7,r:4.2,icon:'💬',label:'Granny',act:grannyHint});}
  /* ----- the Games Arcade ----- */
  {const ax=-28,az=-34,y=gy(ax,az);I('box','#b58cff',10,5.5,7,ax,y+2.75,az);I('box','#ffd23f',10.4,.6,7.4,ax,y+5.8,az);for(let i=0;i<5;i++)I('box',['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0','#ff9ecb'][i],1.6,.5,.2,ax-4+i*2,y+5,az+3.6);
    I('box','#5b4636',2.6,3.4,.3,ax,y+1.7,az+3.55);[-3.2,3.2].forEach(s=>{I('box','#9bdcff',1.6,1.6,.2,ax+s,y+2.8,az+3.55);I('box','#ffd23f',1.9,1.9,.1,ax+s,y+2.8,az+3.52);});rect(ax-5,az-3.5,ax+5,az+3.5);camBlock(ax-5,az-3.5,ax+5,az+3.5);
    for(let i=0;i<12;i++)I('sph',['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0'][i%4],.15,.15,.15,ax-5+i*.9,y+6.3,az+3.75,0,0,0,true);
    I('box','#ff6b6b',1.6,2.4,1.4,ax+6.6,y+1.2,az+2);I('box','#ffd23f',1.8,.3,1.6,ax+6.6,y+2.5,az+2);spr('🎟️',1,ax+6.6,y+3.2,az+2);col(ax+6.6,az+2,1);
    const al=label('🎮 Games Arcade',7);al.position.set(ax,y+9,az);W.ag.add(al);spr('🕹️',2.2,ax,y+6.9,az+3.8);
    W.things.push({x:ax,z:az+6,r:4,icon:'🎮',label:'Games',act:()=>{if(arcadeOpen()){sfx.chime();openGames();}else{sfx.oops();const n=3-Object.keys(state.found).filter(id=>PUPS[id]).length;say(`The Games Arcade opens when you have found 3 pups. ${n} more to go!`);}}});}
  /* ----- the Shop ----- */
  {const sx=0,sz=-38,H=house(sx,sz,{w:12,d:8,h:5,wall:'#ffe1c9',roof:'#5b8def',trim:'#ffffff',win:3,chimney:false,label:'🛍️ The Shop',lw:7}),y=H.y;
    for(let i=0;i<8;i++)I('box',i%2?'#ffffff':'#e8423a',1.5,.12,2,sx-5.25+i*1.5,y+4.2,sz+4.9,-.45,0,0);
    ['🧸','🎈','🦴','🛏️','🎭'].forEach((e,i)=>spr(e,1,sx-4+i*2,y+2.5,sz+4.35));stall(sx+8.5,sz+3,'#3fae5a',['🍎','🥕','🍞'],'s');
    const op=label('OPEN',2.6,'#8fe39a');op.position.set(sx-1.8,y+3.4,sz+4.2);W.ag.add(op);planter(sx-4.6,sz+5.8,'#ff6b6b');planter(sx+4.6,sz+5.8,'#fff27a');
    W.things.push({x:sx,z:sz+6.8,r:4.2,icon:'🛍️',label:'Shop',act:()=>{sfx.chime();openShop();}});}
  /* ----- the Pup Spa ----- */
  {const px=26,pz=-32,H=house(px,pz,{w:11,d:8,h:4.6,wall:'#c9f0ff',roof:'#7fc8f0',trim:'#ffffff',label:'🛁 Pup Spa',lw:6.5}),y=H.y;
    const tx=px-8,tz=pz+6;I('cyl','#ffffff',1.8,1,1.2,tx,gy(tx,tz)+.6,tz);I('cyl','#bfeaff',1.6,.1,1,tx,gy(tx,tz)+1.12,tz,0,0,0,true);for(let k=0;k<4;k++)I('cyl','#c9c2b8',.12,.5,.12,tx+(k%2?1.3:-1.3),gy(tx,tz)+.2,tz+(k<2?.7:-.7));col(tx,tz,2);
    let bt=0;W.ticks.push(dt=>{bt-=dt;if(bt<0){bt=.6;floatS('🫧',tx+(Math.random()-.5)*2.4,gy(tx,tz)+1.6,tz,.9,1.8);}});spr('🦆',.8,tx+.6,gy(tx,tz)+1.35,tz);
    [[px+6.5,pz+5],[px+10,pz+5]].forEach(p=>I('cyl','#9b6a43',.08,2.4,.08,p[0],gy(p[0],p[1])+1.2,p[1]));I('cyl','#ffffff',.02,3.5,.02,px+8.25,gy(px+8,pz+5)+2.3,pz+5,0,0,Math.PI/2);['#ff9ecb','#7fc8f0','#8fe39a','#fff27a'].forEach((c,i)=>I('box',c,.6,.9,.05,px+7+i*.8,gy(px+8,pz+5)+1.85,pz+5));
    planter(px-4,pz+5.8,'#c9b6ff');planter(px+4,pz+5.8,'#7fc8f0');
    W.things.push({x:px,z:pz+6.6,r:4.2,icon:'🛁',label:'Pup Spa',act:()=>{sfx.chime();openSpa();}});}
  /* ----- Seb's Den ----- */
  {const dx=40,dz=-6,H=house(dx,dz,{w:9,d:8,h:4.6,wall:'#8fe39a',roof:'#3fae5a',trim:'#fff8e6',face:'w',label:"🏠 Seb's Den",lw:6.5}),y=H.y;
    I('cyl','#9b6a43',.08,3.4,.08,dx+1,y+8.2,dz);I('box','#ffd23f',1.4,.9,.05,dx+1,y+9.4,dz+.7);spr('⭐',.7,dx+1,y+9.4,dz+.75);
    spr('⚽',1,dx-7,gy(dx-7,dz-4)+.5,dz-4);spr('🚲',1.6,dx-6,gy(dx-6,dz+5)+.8,dz+5);spr('🚀',1.4,dx-6.5,gy(dx-6,dz-6)+.9,dz-6.5);
    hedgeRow(dx-6,dz-8,dx-6,dz-3.2,'#4fae4a');hedgeRow(dx-6,dz+3.2,dx-6,dz+8,'#4fae4a');mailbox(dx-6.3,dz+2.2);
    W.things.push({x:H.front[0],z:H.front[1],r:4,icon:'🏠',label:'My den',act:()=>{player.lock=true;sfx.chime();fadeTo(()=>enterArea('den'),['🏠',"Seb's Den"]);}});}
  /* ----- more houses, a well, a market stall and the sports field plot ----- */
  /* ----- kite hill: the dragon kite to Ninja Mountains ----- */
  {const kx=-44,kz=-8,y=gy(kx,kz);const mound=new THREE.Mesh(G.hemi,M('#8fd170'));mound.scale.set(7,1.6,7);mound.position.set(kx,y-.2,kz);W.ag.add(mound);
    [[-2,-2],[2,-2],[-2,2],[2,2]].forEach(q=>I('cyl','#9b6a43',.25,5,.25,kx+q[0],y+2.5,kz+q[1]));I('box','#c9905f',5,.4,5,kx,y+5,kz);for(let i=0;i<4;i++)I('box','#9b6a43',5.2,.15,.15,kx,y+5.8,kz+(i<2?-2.5:2.5));
    for(let i=0;i<6;i++)I('box','#9b6a43',1.6,.15,.4,kx+3,y+.6+i*.8,kz+2.5-i*.3);rect(kx-2.6,kz-2.6,kx+2.6,kz+2.6);camBlock(kx-2.6,kz-2.6,kx+2.6,kz+2.6);
    const open=islOpen('ninja')&&islandOf('ninja');const D=dragonFlyer(t=>[kx-6+Math.cos(t*.45)*6,y+12+Math.sin(t*.9)*2,kz+Math.sin(t*.45)*8],{c:'#e8423a',c2:'#ffd23f',wing:'#ffb347',n:10,s:.9});
    const str=new THREE.Mesh(G.cyl,M('#ffffff'));str.userData.th=.04;W.ag.add(str);const a=new THREE.Vector3(kx,y+5.4,kz);W.ticks.push(()=>stickBetween(str,a,D.segs[D.segs.length-1].position));
    for(let i=0;i<3;i++)I('box',['#ff6b6b','#ffd23f','#7fc8f0'][i],1.4,.9,.08,kx+6,y+1.4+i*.9,kz-3+i*.2,0,.4,0);
    const lb=label(open?'🪁 Dragon kite to Ninja Mountains':'🪁 Ninja Mountains 🔒',8);lb.position.set(kx,y+9,kz);W.ag.add(lb);
    W.things.push({x:kx+7,z:kz,r:4.6,icon:'🪁',label:'Dragon kite',act:()=>rideTo('ninja')});}
  house(-38,-27,{w:7,d:6,wall:'#ffe1c9',roof:'#e8423a',face:'e'});mailbox(-33.6,-24);
  /* ----- the station: the number train to Number Kingdom ----- */
  {const sx=46,sz=-26,y=gy(sx,sz),rz=sz-4;I('box','#c9c2b8',14,.7,4,sx,y+.35,sz);I('box','#ffd23f',14,.08,.4,sx,y+.72,sz-1.8);for(let i=0;i<4;i++)I('cyl','#5b8def',.15,3,.15,sx-6+i*4,y+2.1,sz+1.6);I('box','#e8423a',15,.4,4.6,sx,y+3.7,sz);
    for(let x=30;x<=72;x+=1.6)I('box','#9b6a43',.4,.15,2.6,x,gy(x,rz)+.08,rz);[-1,1].forEach(q=>I('box','#8a8f99',44,.12,.12,51,gy(51,rz)+.2,rz+q*.8));I('box','#e8423a',.5,1.2,2.4,30,gy(30,rz)+.6,rz);
    const tr=train3D();tr.rotation.y=Math.PI/2;add(tr,54,rz,gy(54,rz)+.1);W.ticks.push(()=>{tr.position.y=gy(54,rz)+.1+Math.abs(Math.sin(W.t*3))*.03;});let st=0;W.ticks.push(dt=>{st-=dt;if(st<0){st=.9;floatS('💨',57.4,gy(57,rz)+4.2,rz,1.4,1.8);}});
    rect(sx-7,sz-2,sx+7,sz+2);rect(29,rz-1.6,72,rz+1.6);camBlock(sx-7,sz-2,sx+7,sz+2);
    const open=islOpen('number')&&islandOf('number');const lb=label(open?'🚂 Number train to Number Kingdom':'🚂 Number Kingdom 🔒',8);lb.position.set(sx,y+7,sz);W.ag.add(lb);
    W.things.push({x:sx-9,z:sz+2,r:4.6,icon:'🚂',label:'Number train',act:()=>rideTo('number')});}
  house(16,-47,{w:7,d:5.5,wall:'#fff2b8',roof:'#3fae5a',face:'s'});
  well(12,28);stall(-15,1,'#ff9ecb',['🍓','🧁','🍪'],'e');
  /* ----- the Science Lab (Release 6) ----- */
  {const lx=-14,lz=-46,H=house(lx,lz,{w:12,d:8,h:5,wall:'#e6f4ff',roof:'#5b8def',trim:'#ffffff',win:3,chimney:false,label:'🔬 Science Lab',lw:7}),y=H.y;
    I('hemi','#c9d6e6',3,2.6,3,lx+3,y+6.6,lz-1);I('box','#26232e',1,2.4,.2,lx+3,y+7.6,lz+1.3,-.3,0,0);I('cyl','#8a8f99',.45,3.2,.45,lx+3.6,y+8.4,lz+.6,-.9,0,-.4);
    [[lx-8,lz+5,'#9be8ff'],[lx-9.6,lz+3.4,'#ff9ecb'],[lx+8,lz+5,'#c9ff7f']].forEach(q=>{const yy=gy(q[0],q[1]);I('cyl','#e8f4ff',.45,2,.45,q[0],yy+1,q[1]);I('cyl',q[2],.38,1.2,.38,q[0],yy+.65,q[1],0,0,0,true);I('sph','#e8f4ff',.5,.5,.5,q[0],yy+2,q[1]);col(q[0],q[1],.6);});
    {const rx=lx+9,rz=lz+1,yy=gy(rx,rz);I('cyl','#ffffff',.7,4,.7,rx,yy+2.4,rz);I('cone','#e8423a',.7,1.4,.7,rx,yy+5.1,rz);[0,2.1,4.2].forEach(a=>I('box','#3d8fe0',.12,1.2,1,rx+Math.cos(a)*.7,yy+.9,rz+Math.sin(a)*.7,0,-a,0));I('cyl','#9bdcff',.3,.1,.3,rx,yy+3.2,rz+.7,Math.PI/2,0,0,true);col(rx,rz,1);}
    {const sx=lx-9,sz=lz-2,yy=gy(sx,sz);I('box','#2a3a5a',2.6,.1,1.6,sx,yy+1.6,sz,-.5,0,0);I('cyl','#8a8f99',.08,1.6,.08,sx,yy+.8,sz);col(sx,sz,.8);}
    const fz=sprite('⚛️',1.4);W.ag.add(fz);W.ticks.push(()=>{fz.position.set(lx,y+9.8+Math.sin(W.t*2)*.3,lz);});
    W.things.push({x:lx,z:lz+6.6,r:4.2,icon:'🔬',label:'Science Lab',act:()=>{sfx.chime();openLab();}});}
  /* ----- Pup Park with a playground ----- */
  {const pk=new THREE.Mesh(G.disc,M('#b6e89a'));pk.scale.set(13,1,13);pk.position.set(-24,gy(-24,16)+.07,16);W.ag.add(pk);
    tree(-33,10,1.2,'#5fbf5a');tree(-31,4,1.1,'#7fcf6a');tree(-31,33,1,'#5fbf5a');tree(-36,20,1,'#4fae4a');
    slide(-30,15);swing(-20,23);seesaw(-29,23);picnic(-17,15);bench(-24,6,'s');bin(-21,6);sign(-14,11,'🐶 Pup Park',3,6);
    flowerPatch(-24,16,18,10,['#ff9ecb','#fff27a','#ffffff'],R);spr('⚽',.9,-24,gy(-24,18)+.45,18);}
  /* ----- the jetty and the ferry to Meadow Island ----- */
  jettyDeck(44,18);{const boat=ferry3D();add(boat,4.8,58,-1.1);boat.rotation.y=Math.PI/2;W.ticks.push(()=>{boat.position.y=-1.1+Math.sin(W.t*1.5)*.12;boat.rotation.z=Math.sin(W.t*1.1)*.03;});}
  sign(-10,41.5,'⛴️ To Meadow Island',3,6);I('tor','#ff6b6b',.6,.6,.6,-2.9,gy(0,46)+1.2,46.5,0,Math.PI/2,0);[[2.9,48],[2.9,49.2]].forEach(p=>I('box','#9b6a43',1,1,1,p[0]-.3,gy(0,44)+.75,p[1]));
  W.things.push({x:0,z:52,r:5,icon:'⛴️',label:'Ferry',act:()=>{const IS=islandOf('meadow');player.lock=true;sfx.chime();fadeTo(()=>enterArea(IS.areas[0].id,IS.areas[0].start),[IS.rideIcon,IS.rideSay]);}});
  I('sph','#8fd170',60,14,40,0,-6,200);I('cyl','#fff8e6',2,12,2,-8,10,186);I('cone','#e8423a',2.6,4,2.6,-8,18,186);
  const gulls=[0,1,2].map(()=>{const s=sprite('🕊️',1.4);W.ag.add(s);return s;});W.ticks.push(()=>gulls.forEach((s,i)=>{const a=W.t*.25+i*2;s.position.set(Math.cos(a)*18,12+i,58+Math.sin(a)*8);}));
  /* ----- the chairlift to Snowy Summit ----- */
  {const cx=40,cz=20,y0=gy(cx,cz),MX=168,MZ=24,MR=78,MH=74,mtn=(x,z)=>-6+(MH+6)*Math.max(0,1-Math.hypot(x-MX,z-MZ)/MR),mx=126,my=mtn(mx,cz)+.6,ytop=x=>y0+6.2+(x-cx)*(my+4-y0-6.2)/(mx-cx);
    I('box','#c9c2b8',9,1,7,cx,y0+.5,cz);[[-4,-3],[4,-3],[-4,3],[4,3]].forEach(q=>I('cyl','#8a8f99',.25,6,.25,cx+q[0],y0+3.5,cz+q[1]));I('box','#e8423a',10,.5,8,cx,y0+6.6,cz);I('pyr','#e8423a',7,1.6,5.6,cx,y0+7.6,cz,0,Math.PI/4,0);
    I('tor','#3a3338',2.4,2.4,2.4,cx+2,y0+6,cz,Math.PI/2,0,0);I('box','#fff2b8',2.6,3,2.6,cx-2.8,y0+2.5,cz-4.2);I('box','#9bdcff',1.4,1,.2,cx-2.8,y0+3,cz-2.85);rect(cx-4.5,cz-5.5,cx+4.5,cz+3.5);camBlock(cx-4.5,cz-5.5,cx+4.5,cz+3.5);
    const towers=[cx+14,cx+30,cx+48,cx+64,cx+76];towers.forEach(x=>{const top=ytop(x),base=Math.max(-1.6,x<92?gy(x,cz):mtn(x,cz));I('cyl','#8a8f99',.4,top-base+1,.4,x,(top+base)/2,cz);I('box','#8a8f99',.3,.3,3.4,x,top,cz);if(x<cx+16)col(x,cz,.7);});
    const pts=[[cx+2,y0+6]].concat(towers.map(x=>[x,ytop(x)])).concat([[mx,my+4]]);
    [-1.4,1.4].forEach(dz=>{for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],L=Math.hypot(b[0]-a[0],b[1]-a[1]);I('box','#3a3338',L,.08,.08,(a[0]+b[0])/2,(a[1]+b[1])/2,cz+dz,0,0,Math.atan2(b[1]-a[1],b[0]-a[0]));}});
    const chairs=[];for(let i=0;i<14;i++){const c=grp();mk('cyl','#3a3338',.05,1.8,.05,0,-.9,0,c);mk('box','#3d8fe0',1.4,.18,.9,0,-1.8,0,c);mk('box','#3d8fe0',1.4,.9,.16,0,-1.4,-.4,c);W.ag.add(c);chairs.push({c,k:i/14});}
    W.ticks.push(dt=>chairs.forEach(o=>{o.k=(o.k+dt*.012)%1;const up=o.k<.5,f=up?o.k*2:(1-o.k)*2,x=cx+2+(mx-cx-2)*f;o.c.position.set(x,ytop(x)-.1,cz+(up?-1.4:1.4));o.c.rotation.y=Math.PI/2;}));
    /* Snowy Summit's own island: the lift's top station sits on its slope (24 Nov: the old peaks floated) */
    const peak=(px,pz,r,h,c,cap)=>{I('cone',c,r,h+6,r,px,(h-6)/2,pz);const ch=cap*(h+6),cr=r*cap;I('cone','#ffffff',cr*1.04,ch*1.02,cr*1.04,px,h-ch/2+.3,pz);};
    peak(MX,MZ,MR,MH,'#c9d6e6',.34);peak(198,-36,58,58,'#d9e4ef',.36);peak(200,64,46,40,'#c9d6e6',.38);I('cone','#9aa8b8',MR*1.12,14,MR*1.12,MX,0,MZ);
    for(let i=0;i<30;i++){const a=i/30*6.283,d=MR*(.78+(i%3)*.06),px=MX+Math.cos(a)*d,pz=MZ+Math.sin(a)*d,py=mtn(px,pz);if(py<-1)continue;I('coneL','#2f6a4a',2.4,6.5,2.4,px,py+2.8,pz);I('coneL','#2f6a4a',1.8,5,1.8,px+2.2,mtn(px+2.2,pz+1)+2.2,pz+1);}
    I('cyl','#c9d6e6',7,3,7,mx+2,my-.6,cz);
    I('box','#8a8f99',8,5,6,mx+2,my+2,cz);I('box','#e8423a',9,.6,7,mx+2,my+4.8,cz);snowman(cx-5,cz+6,.6);
    const lb=label(islOpen('snowy')&&islandOf('snowy')?'🚡 Chairlift to Snowy Summit':'🚡 Snowy Summit 🔒',8);lb.position.set(cx,y0+10.5,cz);W.ag.add(lb);
    W.things.push({x:cx-6.5,z:cz,r:4.6,icon:'🚡',label:'Chairlift',act:()=>rideTo('snowy')});}
  /* ----- the harbour with the yellow submarine to Coral Reef ----- */
  {const hx=-42,hz=32;pond(hx,hz,4.6,'#4fb0e0');for(let a=0;a<6.28;a+=.35)I('sph','#b7bcc9',.7,.45,.6,hx+Math.cos(a)*4.8,gy(hx+Math.cos(a)*4.8,hz+Math.sin(a)*4.8)+.15,hz+Math.sin(a)*4.8,0,a,0);
    for(let i=0;i<3;i++)I('box','#c9905f',1.1,.25,2.2,hx+5.2+i*1.1,gy(hx+6,hz-1)+.35,hz-1.5);I('tor','#ff6b6b',.5,.5,.5,hx+5,gy(hx+5,hz-3.5)+1.2,hz-3.5,0,Math.PI/2,0);I('cyl','#9b6a43',.1,1.6,.1,hx+5,gy(hx+5,hz-3.5)+.8,hz-3.6);
    [[hx+3,hz-6],[hx+4.2,hz-6.4]].forEach(p=>I('box','#c9905f',1,1,1,p[0],gy(p[0],p[1])+.5,p[1]));
    const sb=sub3D();sb.scale.setScalar(.75);add(sb,hx,hz,gy(hx,hz)+.6);sb.rotation.y=.6;W.ticks.push(()=>{sb.position.y=gy(hx,hz)+.6+Math.sin(W.t*1.4)*.15;sb.rotation.z=Math.sin(W.t)*.04;});
    const lb=label(islOpen('reef')&&islandOf('reef')?'🚢 Submarine to Coral Reef':'🚢 Coral Reef 🔒',8);lb.position.set(hx,gy(hx,hz)+6.5,hz);W.ag.add(lb);
    W.things.push({x:hx+7.5,z:hz-2.5,r:4.6,icon:'🚢',label:'Submarine',act:()=>rideTo('reef')});}
  /* ----- Release 7: Seb's flying machine to Gadget Island ----- */
  {const fx=-17,fz=35,y=gy(fx,fz);I('cyl','#c9905f',5,.5,5,fx,y+.25,fz);I('cyl','#3fae5a',4.4,.06,4.4,fx,y+.52,fz);for(let i=0;i<8;i++){const a=i/8*6.283;I('sph','#ffd23f',.2,.2,.2,fx+Math.cos(a)*4.6,y+.6,fz+Math.sin(a)*4.6,0,0,0,true);}
    for(let i=0;i<6;i++)I('box','#9b6a43',3,.25,1.2,fx+3.2+i*.2,y+.5+i*.35,fz-4.6-i*1.1,-.3,0,0);
    const fm=flyMachine3D();add(fm,fx,fz,y+.5);fm.rotation.y=Math.PI*.85;W.ticks.push(()=>{fm.userData.tick(W.t*.5);fm.position.y=y+.5+Math.abs(Math.sin(W.t*1.6))*.08;});col(fx,fz,2.2);
    {const wx=fx-5,wz=fz-3,yy=gy(wx,wz);I('cyl','#8a8f99',.1,4.4,.1,wx,yy+2.2,wz);const ws=grp();for(let i=0;i<4;i++)mk('cone',i%2?'#ffffff':'#ff8a3c',.4-i*.07,.9,.4-i*.07,0,0,.8+i*.8,ws).rotation.x=Math.PI/2;add(ws,wx,wz,yy+4.4);W.ticks.push(()=>{ws.rotation.y=Math.sin(W.t*.4)*.5+.8;});col(wx,wz,.3);}
    I('box','#9b6a43',2.6,1.4,1.4,fx+4.6,y+.7,fz+2.4);['🔧','🔩','⚙️'].forEach((e,i)=>spr(e,.7,fx+3.8+i*.8,y+1.8,fz+2.4));col(fx+4.6,fz+2.4,1.3);
    const open=islOpen('gadget')&&islandOf('gadget');const lb=label(open?"✈️ Seb's flying machine to Gadget Island":'✈️ Gadget Island 🔒',9);lb.position.set(fx,y+8,fz);W.ag.add(lb);
    W.things.push({x:fx+4.4,z:fz-2.4,r:4.6,icon:'✈️',label:'Flying machine',act:()=>rideTo('gadget')});}
  /* ----- Release 7: the fire station and the fire engine over the bridge to Rescue Bay ----- */
  {const fx=23,fz=37,H=house(fx,fz,{w:8,d:6,h:4.4,wall:'#e8423a',roof:'#8a3a2a',trim:'#ffffff',win:0,chimney:false,face:'e',label:'🚒 Fire Station',lw:6.5}),y=H.y;
    for(let k=0;k<4;k++)I('box','#c9c2b8',.22,.6,3.6,fx+4.06,y+.8+k*.9,fz);I('cyl','#ffd23f',.5,.3,.5,fx+4.1,y+4,fz-2.2,0,0,Math.PI/2);
    const ex=34,ez=34,fe=fireEngine3D();add(fe,ex,ez,gy(ex,ez));fe.rotation.y=Math.PI/4;col(ex,ez,2.2);col(ex-1.6,ez-1.6,1.6);col(ex+1.6,ez+1.6,1.6);
    let lt=0;const beacon=spr('🚨',.8,ex-.7,gy(ex,ez)+3.9,ez-.7);W.ticks.push(dt=>{lt+=dt;beacon.visible=(lt%1)<.6;});
    for(let i=0;i<9;i++){const t=40+i*1.6,yy=gy(t,t);I('box','#9b6a43',6,.3,1.2,t,yy+.35,t,0,Math.PI/4,0);}
    [-1,1].forEach(s=>{for(let i=0;i<6;i++){const t=40+i*2.6;I('cyl','#5b4636',.14,1.6,.14,t+s*2.1,gy(t,t)+1,t-s*2.1);}I('box','#9b6a43',.15,.15,15,47+s*2.1,gy(47,47)+1.7,47-s*2.1,0,Math.PI/4,0);});
    {const m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#5fc4f0'}));m.scale.set(60,1,8);m.rotation.y=-Math.PI/4;m.position.set(47,gy(47,47)-.3,47);W.ag.add(m);W.disp.push(m.material);}
    {const bx=39,bz=39,yy=gy(bx,bz);[-1,1].forEach(s=>I('box','#ffffff',.4,1.4,.4,bx+s*2.2,yy+.7,bz-s*2.2));I('box','#ffffff',6.2,.35,.25,bx,yy+1.2,bz,0,Math.PI/4,0);for(let i=0;i<3;i++)I('box','#e8423a',.9,.37,.27,bx-1.4+i*1.4,yy+1.2,bz+1.4-i*1.4,0,Math.PI/4,0);col(bx,bz,1.2);col(bx-1.8,bz+1.8,1);col(bx+1.8,bz-1.8,1);}
    [[fx-2,fz-4],[fx+2,fz-4]].forEach(p=>{const yy=gy(p[0],p[1]);I('cyl','#e8423a',.32,.9,.32,p[0],yy+.45,p[1]);I('sph','#e8423a',.32,.28,.32,p[0],yy+.95,p[1]);col(p[0],p[1],.4);});
    const open=islOpen('rescue')&&islandOf('rescue');const lb=label(open?'🚒 Fire engine to Rescue Bay':'🚒 Rescue Bay 🔒',8);lb.position.set(ex,gy(ex,ez)+7,ez);W.ag.add(lb);
    W.things.push({x:ex-4.2,z:ez-1,r:4.6,icon:'🚒',label:'Fire engine',act:()=>rideTo('rescue')});}
  /* ----- trees round the village ----- */
  [[-46,-18],[-48,2],[-30,-44],[30,-44],[48,-12],[-50,18],[48,30],[-28,40],[12,44],[-6,-50],[36,-40],[-44,-36]].forEach(p=>tree(p[0],p[1],1+R()*.4,pick(['#5fbf5a','#7fcf6a','#4fae4a']),R()<.25?'pine':null));
  edgeTrees(56,[90,angOf(56,-30),45],['#5fbf5a','#7fcf6a','#4fae4a'],null,R);};

/* ================= Seb's Den ================= */
const DEN_SLOTS=[['paint','🎨','Wall colour'],['rug','🟠','Rug'],['bed','🛏️','Bed'],['pupbeds','🐶','Pup beds'],['seat','🛋️','Seat'],['lamp','💡','Lamp'],['shelf','📚','Shelf'],['picture','🖼️','Picture'],['plant','🪴','Plant'],['toy','🧸','Toy'],['scope','🔭','Telescope']];
const DEN_ITEMS=[
  {id:'paint_green',slot:'paint',name:'Green walls',icon:'🟩',price:0,c:'#bfe8b0'},{id:'paint_blue',slot:'paint',name:'Sky blue walls',icon:'🟦',price:20,c:'#bfe0f7'},
  {id:'paint_pink',slot:'paint',name:'Pink walls',icon:'🩷',price:20,c:'#ffd6e6'},{id:'paint_yellow',slot:'paint',name:'Sunny walls',icon:'🟨',price:20,c:'#fff0b0'},{id:'paint_space',slot:'paint',name:'Space walls',icon:'🌌',price:40,c:'#2b3a6e',stars:true},
  {id:'rug_round',slot:'rug',name:'Round rug',icon:'🟠',price:25},{id:'rug_paw',slot:'rug',name:'Paw print rug',icon:'🐾',price:30},{id:'rug_rainbow',slot:'rug',name:'Rainbow rug',icon:'🌈',price:40},
  {id:'bed_wood',slot:'bed',name:'Cosy bed',icon:'🛏️',price:40},{id:'bed_car',slot:'bed',name:'Racing car bed',icon:'🏎️',price:100},{id:'bed_rocket',slot:'bed',name:'Rocket bed',icon:'🚀',price:120},
  {id:'pb_basket',slot:'pupbeds',name:'Pup baskets',icon:'🧺',price:40},{id:'pb_cushion',slot:'pupbeds',name:'Pup cushions',icon:'🛋️',price:50},{id:'pb_kennel',slot:'pupbeds',name:'Pup kennels',icon:'🏠',price:70},
  {id:'beanbag',slot:'seat',name:'Beanbag',icon:'🫘',price:30},{id:'sofa',slot:'seat',name:'Comfy sofa',icon:'🛋️',price:50},{id:'hammock',slot:'seat',name:'Hammock',icon:'🌴',price:60},
  {id:'lamp_lava',slot:'lamp',name:'Lava lamp',icon:'🌋',price:25},{id:'lamp_moon',slot:'lamp',name:'Moon lamp',icon:'🌙',price:30},{id:'lamp_fairy',slot:'lamp',name:'Fairy lights',icon:'✨',price:35},
  {id:'shelf_books',slot:'shelf',name:'Bookshelf',icon:'📚',price:35},{id:'shelf_toys',slot:'shelf',name:'Toy shelf',icon:'🧸',price:40},{id:'shelf_trophy',slot:'shelf',name:'Trophy shelf',icon:'🏆',price:45},
  {id:'pic_planets',slot:'picture',name:'Planets poster',icon:'🪐',price:20},{id:'pic_ninja',slot:'picture',name:'Ninja poster',icon:'🥷',price:20},{id:'pic_dino',slot:'picture',name:'Dinosaur poster',icon:'🦕',price:20},{id:'pic_map',slot:'picture',name:'Island map',icon:'🗺️',price:25},
  {id:'plant_fern',slot:'plant',name:'Fern',icon:'🌿',price:15},{id:'plant_cactus',slot:'plant',name:'Cactus',icon:'🌵',price:15},{id:'plant_sun',slot:'plant',name:'Sunflower',icon:'🌻',price:20},
  {id:'toy_blocks',slot:'toy',name:'Building blocks',icon:'🧱',price:40},{id:'toy_rocket',slot:'toy',name:'Toy rocket',icon:'🚀',price:50},{id:'toy_train',slot:'toy',name:'Train set',icon:'🚂',price:60},{id:'toy_ballpit',slot:'toy',name:'Ball pit',icon:'🔴',price:70},
  {id:'scope',slot:'scope',name:'Telescope',icon:'🔭',price:80}];
const itemOf=id=>DEN_ITEMS.find(i=>i.id===id);
const ownsItem=id=>id==='paint_green'||!!(state.owned||{})[id];
function denBuild(){const den=state.den||{},it=s=>itemOf(den[s]||(s==='paint'?'paint_green':null));
  const P=it('paint')||itemOf('paint_green'),wc=P.c;
  /* floor planks, skirting, walls, window and door mat */
  for(let i=0;i<14;i++)I('box',i%2?'#c9965a':'#d9a86a',28,.05,1.55,0,.03,-10.2+i*1.57);
  I('box',wc,28,7,.4,0,3.5,-11.2);I('box',wc,.4,7,22.4,-14.2,3.5,0);I('box',wc,.4,7,22.4,14.2,3.5,0);I('box','#fff8e6',28.4,.5,.5,0,.25,-11);I('box','#fff8e6',.5,.5,22.4,-14,.25,0);I('box','#fff8e6',.5,.5,22.4,14,.25,0);
  I('box','#fff8e6',28.6,.4,.6,0,7,-11.2);if(P.stars)for(let i=0;i<40;i++)I('sph','#fff6c9',.08,.08,.04,-13+(i*7.3)%26,1+(i*3.7)%5.5,-10.95,0,0,0,true);
  I('box','#9bdcff',4,3,.1,8,4,-10.95,0,0,0,true);I('box','#ffffff',4.4,3.4,.08,8,4,-11);I('box','#ffffff',.12,3,.15,8,4,-10.9);I('box','#ff9ecb',1.2,3.6,.1,5.6,4.1,-10.85);I('box','#ff9ecb',1.2,3.6,.1,10.4,4.1,-10.85);
  I('box','#e8423a',3,.05,1.6,0,.06,9.4);rect(-14.5,-11.5,14.5,-10.8);rect(-14.5,-11.5,-13.8,11.5);rect(13.8,-11.5,14.5,11.5);
  const b=s=>den[s]||null,put=(id,fn)=>{if(id)fn(id);};
  put(b('rug'),id=>{if(id==='rug_rainbow'){['#ff6b6b','#ffb347','#fff27a','#8fe39a','#7fc8f0','#c9b6ff'].forEach((c,i)=>I('cyl',c,5-i*.7,.05+i*.01,4-i*.55,0,.06+i*.01,1));}
    else if(id==='rug_paw'){I('cyl','#c9b6ff',4.6,.05,3.6,0,.06,1);I('cyl','#ffffff',1,.06,1,0,.08,1.4);[[-1.1,-.3],[-.4,-.9],[.4,-.9],[1.1,-.3]].forEach(q=>I('cyl','#ffffff',.45,.06,.45,q[0],.08,1+q[1]));}
    else{I('cyl','#ffb347',4.4,.05,3.4,0,.06,1);I('cyl','#ff8a3c',3.2,.06,2.4,0,.07,1);}});
  put(b('bed'),id=>{const x=-9,z=-7.5;if(id==='bed_rocket'){I('cyl','#ffffff',1.6,5,1.6,x,1.6,z,Math.PI/2,0,0);I('cone','#e8423a',1.6,2,1.6,x,1.6,z+3.4,Math.PI/2,0,0);I('box','#3d8fe0',2.4,.8,4,x,1.4,z);[-1,1].forEach(s=>I('pyr','#e8423a',1,1.4,.2,x+s*1.7,.9,z-2.2,0,0,0));I('cyl','#9bdcff',.5,.1,.5,x,2.4,z+1.8,Math.PI/2,0,0);}
    else if(id==='bed_car'){I('box','#e8423a',3.2,1.2,5.4,x,.7,z);I('box','#3d8fe0',2.6,.5,3.4,x,1.4,z+.3);[[-1.6,-1.8],[1.6,-1.8],[-1.6,1.8],[1.6,1.8]].forEach(q=>I('cyl','#26232e',.6,.4,.6,x+q[0],.6,z+q[1],0,0,Math.PI/2));I('box','#ffd23f',.6,.3,.2,x-.9,.9,z+2.75);I('box','#ffd23f',.6,.3,.2,x+.9,.9,z+2.75);}
    else{I('box','#9b6a43',3.2,.8,5.4,x,.5,z);I('box','#ffffff',2.9,.4,5,x,1.1,z);I('box','#3fae5a',3,.3,3.4,x,1.35,z+.7);I('box','#ffffff',1.6,.5,.9,x,1.45,z-1.9);I('box','#9b6a43',3.2,2,.3,x,1.3,z-2.75);}
    rect(x-1.8,z-2.9,x+1.8,z+2.9);});
  put(b('pupbeds'),id=>{[[5,-8],[8,-8],[11,-8]].forEach((q,i)=>{if(id==='pb_kennel'){I('box',['#ff9ecb','#7fc8f0','#ffd23f'][i],2.2,1.6,2,q[0],.8,q[1]);I('pyr','#e8423a',1.8,1,1.6,q[0],2.1,q[1],0,Math.PI/4,0);I('box','#5b4636',.9,1,.1,q[0],.5,q[1]+1.01);}
    else if(id==='pb_cushion'){I('cyl',['#ff9ecb','#7fc8f0','#c9b6ff'][i],1.2,.4,1.2,q[0],.2,q[1]);}else{I('cyl','#c9905f',1.2,.5,1.2,q[0],.25,q[1]);I('cyl','#fff4dc',1,.1,1,q[0],.45,q[1]);}});});
  put(b('seat'),id=>{const x=-11.5,z=3;if(id==='sofa'){I('box','#3d8fe0',2.2,1,5,x,.6,z);I('box','#3d8fe0',.8,1.6,5,x-.8,1.2,z);[-1,1].forEach(s=>I('box','#2f73b8',2.2,1.3,.5,x,.9,z+s*2.5));I('box','#ffd23f',.8,.8,.3,x-.2,1.4,z-1);rect(x-1.2,z-2.7,x+1.2,z+2.7);}
    else if(id==='hammock'){[-2.6,2.6].forEach(s=>I('cyl','#9b6a43',.12,4,.12,x+.4,2,z+s));I('box','#ffb347',1.4,.15,4.4,x+.4,1.3,z,0,0,.1);rect(x-.4,z-2.8,x+1.2,z+2.8);}
    else{I('sph','#ff6b6b',1.4,.8,1.4,x+.5,.6,z);rect(x-.9,z-1.4,x+1.9,z+1.4);}});
  put(b('lamp'),id=>{const x=-4,z=-9.5;if(id==='lamp_fairy'){for(let i=0;i<24;i++)I('sph',['#fff27a','#ff9ecb','#7fc8f0','#8fe39a'][i%4],.12,.12,.12,-13+i*1.1,6.2+Math.sin(i*.6)*.3,-10.9,0,0,0,true);}
    else if(id==='lamp_moon'){I('cyl','#c9c2b8',.3,.2,.3,x,.1,z);I('sph','#fff6c9',.9,.9,.9,x,1.2,z,0,0,0,true);}
    else{I('cyl','#c9c2b8',.4,.4,.4,x,.2,z);I('cyl','#ff8a3c',.3,1.3,.3,x,1,z,0,0,0,true);for(let k=0;k<3;k++)I('sph','#ffd23f',.15,.2,.15,x,.7+k*.35,z,0,0,0,true);I('cone','#c9c2b8',.35,.4,.35,x,1.85,z);}});
  put(b('shelf'),id=>{const x=1.5,z=-10.4;I('box','#9b6a43',4.4,4.4,.9,x,2.2,z);for(let k=0;k<3;k++)I('box','#7a4f2a',4.2,.12,.8,x,1+k*1.3,z+.05);
    const items=id==='shelf_trophy'?['🏆','🏅','🥇','🏆','🏅','🥇']:id==='shelf_toys'?['🧸','🚗','🦖','🎲','🪀','🤖']:['📕','📗','📘','📙','📒','📓'];
    items.forEach((e,i)=>spr(e,.7,x-1.4+(i%3)*1.4,1.4+Math.floor(i/3)*1.3,z+.5));rect(x-2.2,z-.5,x+2.2,z+.5);});
  put(b('picture'),id=>{const x=-6,e={pic_planets:'🪐',pic_ninja:'🥷',pic_dino:'🦕',pic_map:'🗺️'}[id];I('box','#9b6a43',3.4,2.6,.1,x,4.4,-10.95);I('box','#ffffff',3,2.2,.1,x,4.4,-10.9);spr(e,1.8,x,4.4,-10.7);});
  put(b('plant'),id=>{const x=12.4,z=-9.4,e={plant_fern:'🌿',plant_cactus:'🌵',plant_sun:'🌻'}[id];I('cyl','#c26a32',.6,.9,.5,x,.45,z);spr(e,1.8,x,1.8,z);col(x,z,.7);});
  put(b('toy'),id=>{const x=8,z=4;if(id==='toy_ballpit'){I('cyl','#7fc8f0',2,.9,2,x,.45,z);for(let k=0;k<26;k++)I('sph',['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0'][k%4],.25,.25,.25,x+Math.cos(k*2.4)*(k%5)*.35,.95,z+Math.sin(k*2.4)*(k%5)*.35);col(x,z,2.1);}
    else if(id==='toy_train'){for(let a=0;a<6.28;a+=.25)I('box','#9b6a43',.12,.05,.6,x+Math.cos(a)*2,.05,z+Math.sin(a)*2,0,-a,0);const tr=grp();mk('box','#e8423a',.6,.5,1,0,.35,0,tr);mk('cyl','#26232e',.15,.4,.15,0,.8,.3,tr);add(tr,x+2,z,0);W.ticks.push(dt=>{const a=W.t*.8;tr.position.set(x+Math.cos(a)*2,0,z+Math.sin(a)*2);tr.rotation.y=-a;});}
    else if(id==='toy_rocket'){I('cyl','#ffffff',.5,2.4,.5,x,1.4,z);I('cone','#e8423a',.5,.9,.5,x,3,z);[0,2.1,4.2].forEach(a=>I('box','#3d8fe0',.1,.8,.6,x+Math.cos(a)*.5,.5,z+Math.sin(a)*.5,0,-a,0));col(x,z,.7);}
    else{for(let k=0;k<12;k++)I('box',['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0'][k%4],.7,.7,.7,x+(k%3)*.75-.75,.35+Math.floor(k/6)*.7,z+(Math.floor(k/3)%2)*.75);col(x,z,1.3);}});
  put(b('scope'),()=>{const x=11.5,z=-3;[0,2.1,4.2].forEach(a=>I('cyl','#3a3338',.06,2.2,.06,x+Math.cos(a)*.5,1,z+Math.sin(a)*.5,Math.sin(a)*.25,0,-Math.cos(a)*.25));I('cyl','#3d8fe0',.3,2.2,.3,x,2.4,z,0,0,-.8);col(x,z,.7);});
  /* pups napping */
  const pups=(state.denPups||[]).filter(id=>isFound(id)&&PUPS[id]).slice(0,5),spots=[[5,-7],[8,-7],[11,-7],[-2,2],[2,2.5]];
  pups.forEach((id,i)=>{const p=PUPS[id],g=pup3D(p,p.shiny||bestFriend(id)),q=spots[i];g.rotation.y=Math.PI*(.9+i*.1);g.scale.multiplyScalar(.85);g.userData.nap=true;W.ticks.push(()=>{animPup(g,W.t,false);});add(g,q[0],q[1],den.pupbeds&&i<3?.45:.1);const z=sprite('💤',.9);z.position.set(q[0],2.4,q[1]);W.ag.add(z);
    W.ticks.push(()=>{z.position.y=2.2+Math.sin(W.t*1.5+i)*.25;g.userData.body.scale.y=1+Math.sin(W.t*1.8+i)*.03;});});}
AREAS.den={id:'den',name:"Seb's Den",icon:'🏠',R:14,rect:{x1:-14,z1:-11,x2:14,z2:11},noHedge:true,noEnrich:true,ground:'#d9a86a',sky:'#f6ead8',fogC:'#f6ead8',fog:[80,300],camD:9,camH:4.6,start:[0,7,Math.PI],hf:()=>0,
  hello:"This is your den, Seb! Tap the paint pot to decorate it. You can buy more things in the Shop.",
  exits:[{x:-14,z:7,to:'village',arrive:[29,-5,Math.PI/2],name:'Out to the village',icon:'🚪',noArch:true,noLabel:true}],
  build(){denBuild();W.things.push({x:5,z:5,r:3.4,icon:'🎨',label:'Decorate',act:openDecorate});I('box','#ffffff',.25,4.8,3.2,-13.9,2.4,7);I('box','#c9905f',.3,4.3,2.6,-13.85,2.15,7);I('box','#a87545',.32,1.6,2,-13.85,3,7);I('sph','#ffd23f',.25,.25,.25,-13.65,2.1,7.9);I('box','#e8423a',1.4,.05,2.6,-13,.06,7);{const dl=label('🚪 Out',3.2);dl.position.set(-13.4,5.4,7);W.ag.add(dl);}const pot=grp();mk('cyl','#c9c2b8',.5,.7,.5,0,.35,0,pot);mk('cyl','#3fae5a',.45,.05,.45,0,.72,0,pot);mk('box','#9b6a43',.08,1.4,.08,.3,1,0,pot).rotation.z=.4;add(pot,5,5);
    const l=label('🎨 Decorate',3.6);l.position.set(5,2.3,5);W.ag.add(l);}};
function openDecorate(){hush();const c=$('#menuCard');c.className='card wide';state.den=state.den||{};const den=state.den;
  c.innerHTML=`<h2>🎨 Decorate your den</h2><div class="decgrid">${DEN_SLOTS.map(s=>{const it=itemOf(den[s[0]]||(s[0]==='paint'?'paint_green':''));return `<button class="decslot" data-s="${s[0]}"><span class="di">${it?it.icon:s[1]}</span><b>${s[2]}</b><small>${it?it.name:'Empty'}</small></button>`;}).join('')}
    <button class="decslot" data-s="pups"><span class="di">🐶</span><b>Napping pups</b><small>${(state.denPups||[]).length} of 5</small></button></div><div class="mapnote">Buy more things in the Shop in the village!</div><div class="btns"><button class="btn green" data-s="">✓ Done</button></div>`;
  $('#menu').classList.add('on');speak('Decorate your den! Tap a spot to choose what goes there.');
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();const s=b.dataset.s;sfx.boop();if(!s){closeOv('menu');c.onclick=null;return;}if(s==='pups')return pickDenPups();pickSlot(s);};}
function pickSlot(slot){const c=$('#menuCard'),S=DEN_SLOTS.find(q=>q[0]===slot),own=DEN_ITEMS.filter(i=>i.slot===slot&&ownsItem(i.id)),cur=(state.den||{})[slot];
  c.innerHTML=`<h2>${S[1]} ${S[2]}</h2><div class="decgrid">${own.map(i=>`<button class="decslot${cur===i.id?' on':''}" data-i="${i.id}"><span class="di">${i.icon}</span><b>${i.name}</b></button>`).join('')}${slot!=='paint'?`<button class="decslot" data-i="none"><span class="di">🚫</span><b>Nothing</b></button>`:''}</div>
    ${own.length?'':'<p>You have not bought anything for this spot yet. Visit the Shop!</p>'}<div class="btns"><button class="btn white" data-i="back">◀ Back</button></div>`;
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.i;sfx.boop();if(id==='back')return openDecorate();state.den=state.den||{};if(id==='none')delete state.den[slot];else state.den[slot]=id;save();closeOv('menu');c.onclick=null;
    sfx.chime();enterArea('den',[player.x,player.z,player.h],id==='none'?'Tidied away!':`${itemOf(id).name}! Your den looks great!`);};}
function pickDenPups(){const c=$('#menuCard'),found=Object.keys(state.found).filter(id=>PUPS[id]);let sel=(state.denPups||[]).slice();
  const draw=()=>{c.innerHTML=`<h2>🐶 Napping pups</h2><p>Choose up to 5 pups to nap in your den.</p><div class="pupgrid">${found.map(id=>`<button class="pupsel${sel.indexOf(id)>=0?' on':''}" data-p="${id}">${pupBox(PUPS[id],{anim:false})}<b>${PUPS[id].name}</b></button>`).join('')}</div><div class="btns"><button class="btn green" data-p="">✓ Done</button></div>`;};draw();
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.p;sfx.boop();if(!id){state.denPups=sel;save();closeOv('menu');c.onclick=null;enterArea('den',[player.x,player.z,player.h],sel.length?'Sweet dreams, pups!':'');return;}
    const i=sel.indexOf(id);if(i>=0)sel.splice(i,1);else{if(sel.length>=5){say('Only 5 pups fit in the den. Tap a pup again to take it out.');return;}sel.push(id);}draw();};}

/* ================= the Shop ================= */
const COS_ICON={pirate:'🏴‍☠️',fire:'🚒',dino:'🦖',hero:'🦸',knight:'🛡️',wizard:'🧙',chef:'👨‍🍳',bee:'🐝',ladybird:'🐞',ginger:'🍪',axolotl:'🦎',snowman:'⛄',robot:'🤖'};
const COS_FREE3=['pirate','wizard','robot'],COS_COST=40;
const TREATS=[{id:'treat5',name:'Bag of 5 treats',icon:'🦴',price:10,n:5},{id:'treat12',name:'Big bag of 12 treats',icon:'🍖',price:20,n:12}];
const ownsCos=k=>COS_FREE3.indexOf(k)>=0||!!(state.costumes||{})[k];
let shopTab='den',shopPage=0;
function openShop(tab){hush();shopTab=tab||shopTab;show('shop');$('#shopStars').textContent='⭐ '+state.stars;
  $('#shopBg').innerHTML=shopSVG();$('#shopKeeper').innerHTML=pupBox({id:'crumbs',name:'Mr Crumbs',lv:1,look:{fur:'#c9905f',ear:'#8a5a3a',ears:'long',muzzle:'#f3dcae',belly:'#f3dcae',tail:'wag',acc:['cap','bow']}},{anim:true});
  const tabs=[['den','🛋️ Den things'],['cos','🎭 Costumes'],['treat','🦴 Treats']];$('#shopTabs').innerHTML=tabs.map(t=>`<button class="tab${t[0]===shopTab?' sel':''}" data-t="${t[0]}">${t[1]}</button>`).join('');
  $('#shopTabs').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx.boop();shopPage=0;openShop(b.dataset.t);};
  const list=shopTab==='den'?DEN_ITEMS.filter(i=>i.price>0).map(i=>({id:i.id,name:i.name,icon:`<span class="si">${i.icon}</span>`,price:i.price,got:ownsItem(i.id)}))
    :shopTab==='cos'?Object.keys(COS).filter(k=>!COS[k].xmas&&!COS[k].glow&&!COS[k].hw&&!COS[k].sb&&!COS[k].sp).map(k=>({id:'cos_'+k,k,name:COS[k].n,icon:pupBox(Object.assign({},buddyPup(),{dressAs:k}),{anim:false}),price:COS_FREE3.indexOf(k)>=0?0:COS_COST,got:ownsCos(k)}))
    :TREATS.map(t=>({id:t.id,name:t.name,icon:`<span class="si">${t.icon}</span>`,price:t.price,got:false}));
  const per=8,pages=Math.ceil(list.length/per);shopPage=Math.min(shopPage,pages-1);
  $('#shopGrid').innerHTML=list.slice(shopPage*per,shopPage*per+per).map(o=>`<button class="scard${o.got?' got':''}" data-id="${o.id}">${o.icon}<b>${o.name}</b><small>${o.got?'✅ Got it':o.price?'⭐ '+o.price:'Free'}</small></button>`).join('');
  $('#shopPager').innerHTML=pages>1?`<button class="opt" data-pg="-1">◀</button><span>${shopPage+1} / ${pages}</span><button class="opt" data-pg="1">▶</button>`:'';
  $('#shopPager').onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx.boop();shopPage=Math.max(0,Math.min(pages-1,shopPage+ +b.dataset.pg));openShop();};
  $('#shopGrid').onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();buy(list.find(o=>o.id===b.dataset.id));};
  if(tab)say(shopTab==='den'?'Things for your den! Tap one to buy it.':shopTab==='cos'?'Costumes to dress up your pups!':'Treats for your pups! Feed them at the Pup Spa.');
  else say(`Welcome to the Shop! I am Mr Crumbs. You have ${state.stars} stars to spend.`);}
function buy(o){if(!o)return;if(o.got){sfx.boop();say(shopTab==='cos'?`You already have the ${o.name} costume. Dress a pup up at the Pup Spa!`:`You already have the ${o.name}. Put it in your den!`);return;}
  if(o.price>state.stars){sfx.oops();say(`The ${o.name} costs ${o.price} stars. You need ${o.price-state.stars} more stars. Find pups and play games to earn more!`);return;}
  const tab=shopTab;let did=false;
  card({art:o.icon,h:o.name,p:o.price?`Buy it for ⭐ ${o.price}?`:'It is free!',say:`${o.name}. ${o.price?'That costs '+o.price+' stars.':'It is free!'}`,btns:[['✓ Buy it','green',()=>{
    if(did||o.price>state.stars)return;did=true;state.stars-=o.price;state.stats.bought=(state.stats.bought||0)+1;
    if(tab==='den'){state.owned=state.owned||{};state.owned[o.id]=1;const it=itemOf(o.id);state.den=state.den||{};if(!state.den[it.slot]||it.slot==='paint')state.den[it.slot]=o.id;}
    else if(tab==='cos'){state.costumes=state.costumes||{};state.costumes[o.k]=1;}
    else{state.treats=(state.treats||0)+TREATS.find(t=>t.id===o.id).n;}
    save();sfx.jingle();confetti(30);openShop();say(tab==='den'?`You bought the ${o.name}! It is in your den now.`:tab==='cos'?`You bought the ${o.name} costume! Dress up a pup at the Pup Spa.`:`Yum! You have ${state.treats} treats now.`);}],['Not now','white']]});}
function shopSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#ffe9d4"/><rect y="560" width="1024" height="208" fill="#d9a86a"/>`;
  for(let i=0;i<12;i++)s+=`<rect x="${i*90}" y="560" width="88" height="208" fill="${i%2?'#d0995c':'#d9a86a'}"/>`;
  for(let r=0;r<3;r++){s+=`<rect x="20" y="${150+r*130}" width="260" height="14" fill="#9b6a43" stroke="${k}" stroke-width="3"/>`;for(let i=0;i<5;i++)s+=`<rect x="${32+i*50}" y="${100+r*130}" width="40" height="50" rx="6" fill="${['#ff9ecb','#7fc8f0','#8fe39a','#ffd23f','#c9b6ff'][(i+r)%5]}" stroke="${k}" stroke-width="3"/>`;}
  s+=`<rect x="0" y="0" width="1024" height="40" fill="#e8423a"/>`;for(let i=0;i<20;i++)s+=`<path d="M${i*54} 40 h54 l-27 26Z" fill="${i%2?'#ffffff':'#e8423a'}"/>`;
  return s+`<rect x="40" y="520" width="240" height="60" rx="8" fill="#9b6a43" stroke="${k}" stroke-width="4"/></svg>`;}

/* ================= the Pup Spa: care and friendship ================= */
let SPA=null,spaPage=0;
function openSpa(){hush();show('spa');$('#spaBg').innerHTML=spaSVG();$('#spaStars').textContent='⭐ '+state.stars;$('#spaCare').style.display='none';$('#spaPick').style.display='';
  const found=Object.keys(state.found).filter(id=>PUPS[id]);const per=12,pages=Math.max(1,Math.ceil(found.length/per));spaPage=Math.min(spaPage,pages-1);
  $('#spaPick').innerHTML=`<h2>🛁 Pup Spa</h2><p>Which pup would like a pamper?</p><div class="pupgrid">${found.slice(spaPage*per,spaPage*per+per).map(id=>{const f=(state.friend||{})[id]||0;return `<button class="pupsel" data-p="${id}">${pupBox(PUPS[id],{anim:false})}<b>${PUPS[id].name}</b><small>💖 ${f}/10</small></button>`;}).join('')}</div>
    ${pages>1?`<div class="spapager"><button class="opt" data-pg="-1">◀</button><span>${spaPage+1} / ${pages}</span><button class="opt" data-pg="1">▶</button></div>`:''}`;
  $('#spaPick').onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();sfx.boop();if(b.dataset.pg){spaPage=Math.max(0,Math.min(pages-1,spaPage+ +b.dataset.pg));openSpa();return;}careFor(b.dataset.p);};
  say(found.length?'Welcome to the Pup Spa! Which pup would like a pamper?':'Find some pups first, then bring them to the Pup Spa!');}
function careFor(id){const p=PUPS[id];SPA={id,done:{},mode:null,dist:0};$('#spaPick').style.display='none';$('#spaCare').style.display='';drawCare();
  say(`${p.name} is here for a pamper! Choose what to do. Every kind thing makes you better friends.`);}
function drawCare(){const S=SPA,p=PUPS[S.id],f=(state.friend||{})[S.id]||0;
  $('#spaPup').innerHTML=`<div class="jmp">${pupBox(p)}</div>`;$('#spaHearts').innerHTML=Array.from({length:10},(_,i)=>`<span class="${i<f?'full':''}">💖</span>`).join('')+(f>=10?'<b>Best friends!</b>':'');
  $('#spaName').textContent=`${p.name} the ${p.breed}`;
  const acts=[['feed','🦴','Feed'],['bath','🫧','Bath'],['brush','🪮','Brush'],['dress','🎀','Dress up'],['walk','🐾','Walk']];
  $('#spaBtns').innerHTML=acts.map(a=>`<button class="btn ${S.done[a[0]]?'off':'green'}" data-a="${a[0]}">${a[1]}<small>${a[2]}</small></button>`).join('')+`<button class="btn white" data-a="pick">🔁<small>Other pup</small></button>`;
  $('#spaBtns').onclick=e=>{const b=e.target.closest('button');if(!b)return;initAudio();careAct(b.dataset.a);};
  $('#spaTreats').textContent=`🦴 ${state.treats||0} treats`;$('#spaRub').style.display='none';$('#spaMeter').style.display='none';}
function addFriend(n,why){const S=SPA;state.friend=state.friend||{};const before=state.friend[S.id]||0;state.friend[S.id]=Math.min(10,before+n);save();sfx.yip(PUPS[S.id].pitch);anim($('#spaPup .jmp'),'t-jump',650);floaty(512,330,'💖',3);drawCare();
  if(before<10&&state.friend[S.id]>=10){confetti(80);sfx.fanfare();state.stars+=25;save();const p=PUPS[S.id];
    setTimeout(()=>card({art:pupBox(p,{sparkly:true}),h:'Best friends!',h3:`${p.name} 💖 Seb`,p:`${p.name} loves you so much that ${p.name} sparkles now! Plus 25 stars!`,say:`Best friends! ${p.name} loves you so much that ${p.name} sparkles now!`}),700);}
  else if(why)say(why);}
function careAct(a){const S=SPA,p=PUPS[S.id];if(a==='pick'){SPA=null;openSpa();return;}
  if(a==='dress')return dressUp();
  if(S.done[a]){sfx.boop();say(`${p.name} has had that already today. Try something else!`);return;}
  if(a==='feed'){S.done.feed=1;const treat=(state.treats||0)>0;if(treat)state.treats--;state.stats.fed=(state.stats.fed||0)+1;if(treat)state.stats.treatFed=1;floaty(512,420,treat?'🦴':'🍪',3);sfx.pop();setTimeout(()=>{sfx.giggle();addFriend(treat?2:1,treat?`Crunch crunch! ${p.name} loves the treat!`:`${p.name} munches a biscuit! Buy treats in the Shop for even happier pups.`);},500);}
  else if(a==='walk'){S.done.walk=1;addFriend(1);state.pack=(state.pack||[]).filter(q=>q!==S.id);if(state.buddy!==S.id){state.pack.unshift(S.id);state.pack=state.pack.slice(0,2);}save();
    setTimeout(()=>{show('world');syncFollowers(true);hud();say(`${p.name} is coming for a walk with you!`);},900);}
  else{S.mode=a;S.dist=0;$('#spaRub').style.display='';$('#spaMeter').style.display='';$('#spaMeter b').style.width='0';say(a==='bath'?`Bath time! Rub ${p.name} with your finger to make lots of bubbles!`:`Brush ${p.name}'s fur! Swipe your finger across ${p.name}.`);}}
(function(){const pad=$('#spaRub');let down=false,last=null,gl=0;
  pad.addEventListener('pointerdown',e=>{initAudio();if(!SPA||!SPA.mode)return;down=true;last=[e.clientX,e.clientY];});
  pad.addEventListener('pointermove',e=>{if(!down||!SPA||!SPA.mode)return;const d=Math.hypot(e.clientX-last[0],e.clientY-last[1])/scale;last=[e.clientX,e.clientY];if(d<1)return;SPA.dist+=d;const need=SPA.mode==='bath'?2200:1400;
    const now=Date.now();if(now-gl>200){gl=now;if(SPA.mode==='bath'){floaty(400+Math.random()*220,300+Math.random()*200,'🫧',2);sfx.pop();}else{floaty(400+Math.random()*220,300+Math.random()*200,'✨',1);sfx.giggle();}}
    $('#spaMeter b').style.width=Math.min(100,SPA.dist/need*100)+'%';
    if(SPA.dist>=need){const m=SPA.mode;SPA.mode=null;down=false;SPA.done[m]=1;if(m==='bath'){state.stats.baths=(state.stats.baths||0)+1;for(let i=0;i<8;i++)setTimeout(()=>floaty(380+Math.random()*260,250,'💧',1),i*80);}else state.stats.brushes=(state.stats.brushes||0)+1;
      addFriend(m==='bath'?2:1,m==='bath'?`Splash! ${PUPS[SPA.id].name} is squeaky clean!`:`${PUPS[SPA.id].name}'s fur is so soft and shiny!`);}});
  ['pointerup','pointercancel','pointerleave'].forEach(n=>pad.addEventListener(n,()=>{down=false;}));})();
function dressUp(){const S=SPA,p=PUPS[S.id],c=$('#menuCard');c.className='card wide';const keys=Object.keys(COS).filter(ownsCos),cur=state.dress[S.id+'@1']||'none';
  c.innerHTML=`<h2>🎀 Dress up ${p.name}</h2><div class="pupgrid">${['none'].concat(keys).map(k=>`<button class="pupsel${cur===k?' on':''}" data-k="${k}">${pupBox(Object.assign({},p,{dressAs:k==='none'?'none':k}),{anim:false})}<b>${k==='none'?'No costume':COS[k].n}</b></button>`).join('')}</div>
    <div class="mapnote">Buy more costumes in the Shop!</div><div class="btns"><button class="btn white" data-k="">◀ Back</button></div>`;
  $('#menu').classList.add('on');speak(`Choose a costume for ${p.name}!`);
  c.onclick=e=>{const b=e.target.closest('button');if(!b)return;sfx.boop();const k=b.dataset.k;closeOv('menu');c.onclick=null;if(!k)return;
    if(k==='none')delete state.dress[S.id+'@1'];else{state.dress[S.id+'@1']=k;state.stats.dressed=(state.stats.dressed||0)+1;}save();drawCare();sfx.chime();syncFollowers();
    say(k==='none'?`${p.name} is back to normal!`:`${p.name} looks amazing as a ${COS[k].n.toLowerCase()}!`);};}
function spaSVG(){const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#e6f7ff"/>`;
  for(let y=0;y<560;y+=64)for(let x=0;x<1024;x+=64)s+=`<rect x="${x+2}" y="${y+2}" width="60" height="60" rx="6" fill="${(x/64+y/64)%2?'#d6f0ff':'#ffffff'}"/>`;
  s+=`<rect y="560" width="1024" height="208" fill="#bfe3f5"/><ellipse cx="512" cy="600" rx="280" ry="70" fill="#ffffff" stroke="${k}" stroke-width="5"/><ellipse cx="512" cy="585" rx="250" ry="48" fill="#9be8ff"/>`;
  for(let i=0;i<14;i++)s+=`<circle cx="${290+i*34}" cy="${560+(i%3)*8}" r="${16+(i%3)*6}" fill="#ffffff" stroke="#9fd8f0" stroke-width="2"/>`;
  [['#ff9ecb',90],['#7fc8f0',150],['#fff27a',210]].forEach(t=>s+=`<rect x="${t[1]}" y="120" width="44" height="90" rx="8" fill="${t[0]}" stroke="${k}" stroke-width="3"/>`);
  return s+`<path d="M60 112 H280" stroke="${k}" stroke-width="5"/><text x="900" y="160" font-size="80">🧴</text><text x="820" y="540" font-size="60">🦆</text></svg>`;}

/* ================= new badges and certificates ================= */
MERITS.push(
  {id:'shopper',icon:'🛍️',name:'Shopper',how:'Buy something in the Shop.',ok:()=>(state.stats.bought||0)>0},
  {id:'decorator',icon:'🎨',name:'Decorator',how:'Put 5 things in your den.',ok:()=>Object.keys(state.den||{}).filter(s=>s!=='paint').length>=5},
  {id:'bath',icon:'🫧',name:'Bubble Bath',how:'Give a pup a bath at the Pup Spa.',ok:()=>(state.stats.baths||0)>0},
  {id:'treat',icon:'🦴',name:'Treat Time',how:'Feed a pup a treat.',ok:()=>!!state.stats.treatFed},
  {id:'dressup',icon:'🎭',name:'Dress Up',how:'Dress a pup in a costume.',ok:()=>(state.stats.dressed||0)>0},
  {id:'costumes',icon:'👗',name:'Costume Box',how:'Collect 6 costumes.',ok:()=>Object.keys(COS).filter(ownsCos).length>=6},
  {id:'bestfriend',icon:'💖',name:'Best Friends',how:'Fill a pup\'s friendship hearts at the Pup Spa.',ok:()=>Object.keys(state.friend||{}).some(bestFriend)},
  {id:'denpups',icon:'💤',name:'Sleepover',how:'Have pups napping in your den.',ok:()=>(state.denPups||[]).length>0});
CERTS.push(
  {id:'den',icon:'🏠',title:'Super Den Designer',why:'for filling every spot in the den',ok:()=>DEN_SLOTS.every(s=>s[0]==='paint'||(state.den||{})[s[0]])},
  {id:'bff',icon:'💖',title:'Best Friends Forever',why:'for becoming best friends with 5 pups',ok:()=>Object.keys(state.friend||{}).filter(bestFriend).length>=5});
Object.assign(window,{openShop,openSpa,openDecorate,careFor,careAct,DEN_ITEMS,spaClose:()=>{SPA=null;}});
})();
