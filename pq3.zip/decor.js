/* ================================================================
   Seb's Puppy Quest 3: detail helpers and the scenery filler.
   house() builds a detailed house (door with frame and step,
   framed windows with flower boxes, roof trim, chimney with smoke).
   Small props: lamp posts, benches, bins, planters, mailboxes,
   bunting, signposts with arrows, wells, market stalls, playground.
   enrich() scatters lots of small scenery over an area, keeping
   clear of paths, hiding spots, buttons, exits and colliders.
   ================================================================ */
const FACE={s:0,e:Math.PI/2,n:Math.PI,w:-Math.PI/2};
/* local (lx,lz) to world, where local +z is the front of the building */
function faceAt(x,z,face){const a=FACE[face||'s'],c=Math.cos(a),s=Math.sin(a);return {a,t:(lx,lz)=>[x+lx*c+lz*s,z-lx*s+lz*c]};}
function house(x,z,o){o=Object.assign({w:7,d:6,h:4.2,wall:'#fff2b8',roof:'#e8423a',face:'s',door:'#5b4636',trim:'#ffffff',chimney:true,boxes:true,win:2},o||{});
  const F=faceAt(x,z,o.face),y=gy(x,z),a=F.a,P=(lx,lz)=>F.t(lx,lz),w=o.w,d=o.d,h=o.h;
  I('box',o.wall,w,h,d,x,y+h/2,z,0,a,0);I('box',shade(o.wall,-.18),w+.2,.5,d+.2,x,y+.25,z,0,a,0);
  I('pyr',o.roof,w*.78,h*.62,d*.78,x,y+h+h*.31,z,0,a+Math.PI/4,0);I('box',o.trim,w+.5,.25,d+.5,x,y+h+.05,z,0,a,0);
  /* door, frame, step and porch light */
  let p=P(0,d/2+.06);I('box',o.door,1.5,2.5,.12,p[0],y+1.25,p[1],0,a,0);p=P(0,d/2+.03);I('box',o.trim,1.9,2.8,.08,p[0],y+1.4,p[1],0,a,0);
  p=P(.5,d/2+.14);I('sph','#ffd23f',.09,.09,.09,p[0],y+1.3,p[1],0,0,0,true);p=P(0,d/2+.5);I('box','#c9c2b8',2.2,.25,.9,p[0],y+.12,p[1],0,a,0);
  p=P(1.25,d/2+.15);I('sph','#ffe27a',.18,.18,.18,p[0],y+2.7,p[1],0,0,0,true);
  /* windows with frames, cross bars and flower boxes */
  const wins=o.win===1?[-w/4]:o.win===3?[-w/3,w/3,0]:[-w/3.2,w/3.2];
  wins.forEach(lx=>{if(Math.abs(lx)<1.3)return;let q=P(lx,d/2+.06);I('box','#9bdcff',1.3,1.2,.1,q[0],y+2.4,q[1],0,a,0);q=P(lx,d/2+.04);I('box',o.trim,1.6,1.5,.06,q[0],y+2.4,q[1],0,a,0);
    q=P(lx,d/2+.1);I('box',o.trim,.08,1.2,.08,q[0],y+2.4,q[1],0,a,0);I('box',o.trim,1.3,.08,.08,q[0],y+2.4,q[1],0,a,0);
    if(o.boxes){q=P(lx,d/2+.3);I('box','#9b6a43',1.5,.3,.4,q[0],y+1.65,q[1],0,a,0);for(let k=0;k<4;k++){const r=P(lx-.55+k*.37,d/2+.32);I('sph',['#ff6b6b','#fff27a','#ff9ecb','#c9b6ff'][k],.16,.14,.16,r[0],y+1.92,r[1]);}}});
  [-1,1].forEach(sd=>{const q=P(sd*(w/2+.06),0);I('box','#9bdcff',.1,1.1,1.2,q[0],y+2.4,q[1],0,a,0);});
  if(o.chimney){const q=P(w*.25,-d*.1);I('box','#b0645a',.8,2.2,.8,q[0],y+h+1.6,q[1],0,a,0);I('box','#8a4a40',1,.25,1,q[0],y+h+2.75,q[1],0,a,0);
    let st=Math.random()*3;W.ticks.push(dt=>{st-=dt;if(st<0){st=2.4+Math.random()*2;floatS('💨',q[0],y+h+3.4,q[1],1.2,2.2);}});}
  const hw=(a===0||Math.abs(a)===Math.PI)?w/2:d/2,hd=(a===0||Math.abs(a)===Math.PI)?d/2:w/2;rect(x-hw,z-hd,x+hw,z+hd);camBlock(x-hw,z-hd,x+hw,z+hd);
  if(o.label){const l=label(o.label,o.lw||7);l.position.set(x,y+h*1.75+1.2,z);W.ag.add(l);}
  return {y,P,front:P(0,d/2+2.6)};}
function lampPost(x,z,c){const y=gy(x,z);I('cyl','#3a3338',.12,4,.12,x,y+2,z);I('cyl','#3a3338',.25,.3,.25,x,y+.15,z);I('box','#3a3338',.7,.12,.12,x+.3,y+4,z);I('sph',c||'#ffe9a0',.35,.4,.35,x+.6,y+3.7,z,0,0,0,true);I('cone','#3a3338',.45,.3,.45,x+.6,y+4.1,z);col(x,z,.3);}
function bench(x,z,face){const F=faceAt(x,z,face),y=gy(x,z),a=F.a;I('box','#c9905f',2.6,.18,.8,x,y+.75,z,0,a,0);let p=F.t(0,-.38);I('box','#c9905f',2.6,.7,.14,p[0],y+1.15,p[1],0,a,0);
  [-1.1,1.1].forEach(lx=>{const q=F.t(lx,0);I('box','#3a3338',.14,.75,.7,q[0],y+.38,q[1],0,a,0);});col(x,z,1.2);}
function bin(x,z){const y=gy(x,z);I('cyl','#3fae5a',.4,1,.4,x,y+.5,z);I('cyl','#2e8b47',.45,.12,.45,x,y+1.02,z);col(x,z,.45);}
function planter(x,z,c){const y=gy(x,z);I('box','#9b6a43',1.6,.7,1.6,x,y+.35,z);I('sph','#5fbf5a',.8,.5,.8,x,y+.9,z);for(let k=0;k<5;k++)I('sph',c||pick(['#ff6b6b','#fff27a','#ff9ecb','#c9b6ff']),.17,.15,.17,x+Math.cos(k*1.3)*.5,y+1.25,z+Math.sin(k*1.3)*.5);col(x,z,.9);}
function mailbox(x,z){const y=gy(x,z);I('cyl','#9b6a43',.08,1.1,.08,x,y+.55,z);I('box','#e8423a',.5,.45,.7,x,y+1.25,z);I('box','#ffd23f',.05,.3,.1,x+.27,y+1.4,z);}
function bunting(x1,z1,x2,z2,h){const n=Math.max(4,Math.round(Math.hypot(x2-x1,z2-z1)/1.1)),ang=Math.atan2(x2-x1,z2-z1),cs=['#ff6b6b','#ffd23f','#8fe39a','#7fc8f0','#ff9ecb','#c9b6ff'];
  for(let i=0;i<n;i++){const t=(i+.5)/n,x=x1+(x2-x1)*t,z=z1+(z2-z1)*t,sag=Math.sin(t*Math.PI)*.8,y=Math.max(gy(x1,z1),gy(x2,z2))+h-sag;I('cone',cs[i%cs.length],.3,.6,.08,x,y-.3,z,Math.PI,ang,0);}}
function signpost(x,z,arrows){const y=gy(x,z),n=arrows.length;I('cyl','#9b6a43',.18,1.8,.18,x,y+.9,z);I('box','#9b6a43',.9,.12,.9,x,y+1.78,z);arrows.forEach((a,i)=>{const l=label(a[0],4.2,a[1]||'#fff8e6');l.position.set(x,y+2.4+(n-1-i)*1.08,z);W.ag.add(l);});col(x,z,.3);}
function well(x,z){const y=gy(x,z);I('cyl','#b7bcc9',1.3,1.2,1.3,x,y+.6,z);I('cyl','#4fb0e0',1,.1,1,x,y+1.15,z,0,0,0,true);[-1,1].forEach(s=>I('box','#9b6a43',.2,2.2,.2,x+s*1.1,y+2.1,z));I('pyr','#e8423a',1.8,1,1.8,x,y+3.6,z,0,Math.PI/4,0);I('cyl','#9b6a43',.12,2.2,.12,x,y+2.6,z,0,0,Math.PI/2);col(x,z,1.4);}
function stall(x,z,c,items,face){const F=faceAt(x,z,face),y=gy(x,z),a=F.a;I('box','#c9905f',3.4,1,1.6,x,y+.5,z,0,a,0);[-1.5,1.5].forEach(lx=>{const p=F.t(lx,-.6);I('cyl','#9b6a43',.1,2.8,.1,p[0],y+1.4,p[1]);});
  for(let i=0;i<5;i++){const p=F.t(-1.4+i*.7,-.2);I('box',i%2?c:'#ffffff',.7,.15,2.2,p[0],y+2.8,p[1],-.2,a,0);}
  (items||[]).forEach((e,i)=>{const p=F.t(-1+i*1,.2);spr(e,.9,p[0],y+1.4,p[1]);});col(x,z,1.7);}
function wheelbarrow(x,z){const y=gy(x,z);I('box','#3fae5a',1.4,.5,.9,x,y+.7,z,0,.4,0);I('cyl','#3a3338',.35,.12,.35,x+.8,y+.35,z+.3,Math.PI/2,.4,0);I('cyl','#9b6a43',.05,1.4,.05,x-.9,y+.7,z-.4,0,.4,Math.PI/2.4);for(let k=0;k<3;k++)I('sph','#ff8a3c',.22,.22,.22,x-.2+k*.25,y+1.05,z+k*.1);}
function hedgeRow(x1,z1,x2,z2,c){const d=Math.hypot(x2-x1,z2-z1),n=Math.ceil(d/1);for(let i=0;i<=n;i++){const x=x1+(x2-x1)*i/n,z=z1+(z2-z1)*i/n;I('sph',c||'#4f9e46',.75,.85,.75,x,gy(x,z)+.6,z);}colLine(x1,z1,x2,z2,.6);}
function slide(x,z){const y=gy(x,z);I('box','#e8423a',.15,3,.15,x-1,y+1.5,z-1);I('box','#e8423a',.15,3,.15,x+1,y+1.5,z-1);for(let i=0;i<5;i++)I('box','#ffd23f',2,.12,.3,x,y+.6+i*.6,z-1.2);I('box','#7fc8f0',1.6,.2,4.6,x,y+1.6,z+1.2,-.55,0,0);I('box','#ffd23f',2.2,.2,1.2,x,y+3,z-.9);col(x,z-1,1.2);}
function swing(x,z){const y=gy(x,z);[-1.8,1.8].forEach(s=>{I('box','#3d8fe0',.15,3.6,.15,x+s,y+1.8,z-.6,.2,0,0);I('box','#3d8fe0',.15,3.6,.15,x+s,y+1.8,z+.6,-.2,0,0);});I('cyl','#3d8fe0',.1,3.8,.1,x,y+3.5,z,0,0,Math.PI/2);
  const sw=grp();mk('cyl','#3a3338',.03,2.4,.03,-.4,-1.2,0,sw);mk('cyl','#3a3338',.03,2.4,.03,.4,-1.2,0,sw);mk('box','#e8423a',1,.12,.5,0,-2.4,0,sw);add(sw,x,z,y+3.5);W.ticks.push(()=>{sw.rotation.x=Math.sin(W.t*1.6)*.35;});col(x,z,1.6);}
function seesaw(x,z){const y=gy(x,z);I('box','#9b6a43',.6,.7,.6,x,y+.35,z);const s=grp();mk('box','#ff9ecb',4,.18,.5,0,0,0,s);mk('box','#ffd23f',.15,.5,.5,-1.8,.3,0,s);mk('box','#ffd23f',.15,.5,.5,1.8,.3,0,s);add(s,x,z,y+.8);W.ticks.push(()=>{s.rotation.z=Math.sin(W.t*1.2)*.25;});col(x,z,1);}
function picnic(x,z){const y=gy(x,z);I('box','#ff6b6b',3,.04,3,x,y+.06,z);for(let i=0;i<3;i++)I('box','#ffffff',3,.05,.35,x,y+.08,z-1+i);I('box','#c9905f',.9,.5,.6,x+.6,y+.3,z+.4);spr('🧺',1,x-.6,y+.7,z-.4);}
function butterflies(n,cx,cz,r,em){const L=[];for(let i=0;i<n;i++){const s=sprite(em||pick(['🦋','🦋','🐝']),.9);W.ag.add(s);L.push({s,a:Math.random()*6,b:Math.random()*6,r:r*(.4+Math.random()*.6)});}
  W.ticks.push(dt=>L.forEach(o=>{o.a+=dt*.5;const x=cx+Math.cos(o.a)*o.r,z=cz+Math.sin(o.a*1.3+o.b)*o.r;o.s.position.set(x,gy(x,z)+1.5+Math.sin(W.t*3+o.b)*.5,z);}));}
function birds(n,h,r){const L=[];for(let i=0;i<n;i++){const s=sprite(pick(['🐦','🕊️']),1.4);W.ag.add(s);L.push({s,a:i/n*6.28,r:r*(.6+i*.1)});}W.ticks.push(dt=>L.forEach(o=>{o.a+=dt*.18;o.s.position.set(Math.cos(o.a)*o.r,h+Math.sin(o.a*3)*1.5,Math.sin(o.a)*o.r);}));}

/* ================= enrich: lots of small scenery for every area ================= */
function enrich(A){if(A.noEnrich)return;const B=areaBox(A),Rn=seed((A.id.charCodeAt(0)*131+A.id.length*17)|0),biome=A.biome||(A.swim?'reef':A.island==='snowy'?(A.id==='cave'?'ice':'snow'):'meadow');
  const keep=[];W.spots.forEach(s=>keep.push([s.x,s.z,3.2]));W.things.forEach(t=>keep.push([t.x,t.z,4]));W.exits.forEach(e=>keep.push([e.x,e.z,6]));if(A.start)keep.push([A.start[0],A.start[1],5]);
  (A.exits||[]).forEach(e=>{if(e.arrive){}});
  const inside=(x,z,m)=>A.rect?(x>B.x1+m&&x<B.x2-m&&z>B.z1+m&&z<B.z2-m):Math.hypot(x,z)<A.R-m;
  const blocked=(x,z,r)=>{for(const c of W.cols)if(Math.hypot(x-c.x,z-c.z)<c.r+r)return true;for(const q of W.rects)if(x>q.x1-r&&x<q.x2+r&&z>q.z1-r&&z<q.z2+r)return true;for(const k of keep)if(Math.hypot(x-k[0],z-k[1])<k[2]+r)return true;
    if(A.ski&&Math.abs(x)<B.x2-12)return true;if(A.keepOut&&A.keepOut(x,z))return true;return false;};
  const spot=(r,m,tries)=>{for(let t=0;t<(tries||30);t++){const x=B.x1+Rn()*(B.x2-B.x1),z=B.z1+Rn()*(B.z2-B.z1);if(inside(x,z,m||3)&&!blocked(x,z,r))return [x,z];}return null;};
  const area=(B.x2-B.x1)*(B.z2-B.z1),k=Math.min(2.4,area/9000);const n=c=>Math.round(c*k);
  if(biome==='meadow'||biome==='village'){
    for(let i=0;i<n(260);i++){const p=spot(.2,2,6);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('coneL',pick(['#5fae4a','#4f9e3a','#6fbf5a']),.08,.5+Rn()*.4,.08,p[0]+j*.15,y+.25,p[1]+(j%2)*.12,(j-1)*.3,0,(j-1)*.2);}
    for(let i=0;i<n(30);i++){const p=spot(1,3);if(p)flowerPatch(p[0],p[1],6+Math.round(Rn()*6),1.6,[pick(['#ff9ecb','#fff27a','#ffffff','#c9b6ff','#ff6b6b','#ffb347'])],Rn);}
    for(let i=0;i<n(12);i++){const p=spot(1.4,4);if(p)bush(p[0],p[1],.7+Rn()*.5,pick(['#5fbf5a','#4fae4a','#6cc45e']),Rn()<.4?pick(['#ff5d6c','#7b86e0']):null);}
    for(let i=0;i<n(14);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('sph','#b7bcc9',.5+Rn()*.4,.3,.45,p[0],y+.12,p[1],0,Rn()*3,0);}}
    for(let i=0;i<n(10);i++){const p=spot(.5,3);if(p){const y=gy(p[0],p[1]),c=pick(['#e8423a','#ffb347','#fff8e6']);I('cyl','#fff8e6',.12,.45,.12,p[0],y+.22,p[1]);I('hemi',c,.35,.25,.35,p[0],y+.42,p[1]);}}
    for(let i=0;i<n(6);i++){const p=spot(1.8,5);if(p)tree(p[0],p[1],.8+Rn()*.5,pick(['#5fbf5a','#7fcf6a','#4fae4a']),Rn()<.2?'pine':null);}
    butterflies(Math.max(3,n(8)),0,0,(A.R||40)*.6);if(biome==='meadow')birds(3,22,A.R||40);}
  else if(biome==='ninja'){
    for(let i=0;i<n(220);i++){const p=spot(.2,2,6);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('coneL',pick(['#5fae4a','#4f9e3a','#7fbf5a']),.08,.5+Rn()*.4,.08,p[0]+j*.15,y+.25,p[1]+(j%2)*.12,(j-1)*.3,0,(j-1)*.2);}
    for(let i=0;i<n(14);i++){const p=spot(1.2,4);if(!p)continue;const y=gy(p[0],p[1]),k=3+Math.floor(Rn()*3);for(let j=0;j<k;j++){const x=p[0]+(Rn()-.5)*1.6,z=p[1]+(Rn()-.5)*1.6,h=4+Rn()*4;I('cylL',pick(['#7fbf4a','#6aae3a','#8fcf5a']),.16,h,.16,x,y+h/2,z);for(let q=1;q<h;q+=1.2)I('cylL','#4f8e2a',.19,.12,.19,x,y+q,z);I('sphL','#6cc45e',.9,.5,.9,x,y+h,z);}col(p[0],p[1],1);}
    for(let i=0;i<n(22);i++){const p=spot(1,3);if(p)flowerPatch(p[0],p[1],6+Math.round(Rn()*5),1.5,[pick(['#ffb7d5','#ffffff','#ff9ecb','#e8423a','#ffd23f'])],Rn);}
    for(let i=0;i<n(9);i++){const p=spot(1.4,4);if(p)bush(p[0],p[1],.7+Rn()*.4,pick(['#e8603a','#ffb347','#d9362e','#5fbf5a']));}
    for(let i=0;i<n(12);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('sphL',pick(['#9a9488','#b7bcc9','#8a8378']),.5+Rn()*.5,.35,.45,p[0],y+.12,p[1],0,Rn()*3,0);I('sphL','#5fae4a',.3,.1,.3,p[0],y+.42,p[1]);}}
    for(let i=0;i<n(5);i++){const p=spot(.7,4);if(p){const y=gy(p[0],p[1]);I('box','#a9a399',.9,.3,.9,p[0],y+.15,p[1]);I('box','#a9a399',.35,1.2,.35,p[0],y+.9,p[1]);I('box','#fff27a',.6,.55,.6,p[0],y+1.75,p[1],0,0,0,true);I('pyr','#8a8378',.75,.5,.75,p[0],y+2.3,p[1],0,Math.PI/4,0);col(p[0],p[1],.6);}}
    for(let i=0;i<n(4);i++){const p=spot(1.8,5);if(p)tree(p[0],p[1],.8+Rn()*.4,pick(['#ffb7d5','#ff9ecb','#ffc9e0']));}
    butterflies(Math.max(3,n(6)),0,0,(A.R||40)*.6);birds(3,24,A.R||40);}
  else if(biome==='fire'){
    for(let i=0;i<n(150);i++){const p=spot(.2,2,6);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('coneL',pick(['#a8864a','#8a6a3a','#c9a05a']),.07,.4+Rn()*.3,.07,p[0]+j*.15,y+.2,p[1]+(j%2)*.12,(j-1)*.3,0,(j-1)*.2);}
    for(let i=0;i<n(24);i++){const p=spot(.8,3);if(!p)continue;const y=gy(p[0],p[1]),s=.5+Rn()*.8;I('pyr',pick(['#2e2630','#3a3338','#4a3a40']),.8*s,1.6*s,.8*s,p[0],y+.6*s,p[1],0,Rn()*3,(Rn()-.5)*.4);I('pyr','#5a2a6a',.4*s,1*s,.4*s,p[0]+.5*s,y+.4*s,p[1]+.2,0,Rn()*3,.3);col(p[0],p[1],.8*s);}
    for(let i=0;i<n(30);i++){const p=spot(.5,3,8);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('box','#ff8a3c',1.4+Rn(),.03,.12,p[0]+(Rn()-.5),y+.07,p[1]+(Rn()-.5),0,Rn()*3,0,true);}
    for(let i=0;i<n(16);i++){const p=spot(1,3);if(p)flowerPatch(p[0],p[1],5+Math.round(Rn()*4),1.4,[pick(['#ff6b2a','#ffd23f','#e8423a','#ffb347'])],Rn);}
    for(let i=0;i<n(5);i++){const p=spot(2,5);if(!p)continue;const y=gy(p[0],p[1]),r=1.2+Rn()*1.2;I('cyl','#ff7a2a',r,.05,r,p[0],y+.07,p[1],0,0,0,true);I('cyl','#ffd23f',r*.5,.06,r*.5,p[0],y+.08,p[1],0,0,0,true);for(let k=0;k<6;k++){const a=k/6*6.28;I('sphL','#3a3338',.5,.35,.5,p[0]+Math.cos(a)*r,y+.15,p[1]+Math.sin(a)*r);}col(p[0],p[1],r+.4);}
    for(let i=0;i<n(6);i++){const p=spot(.6,4);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#4a3a30',.25,2.4,.25,p[0],y+1.2,p[1]);I('cyl','#4a3a30',.1,1.2,.1,p[0]+.4,y+2,p[1],0,0,-.8);I('cyl','#4a3a30',.1,1,.1,p[0]-.35,y+1.7,p[1],0,0,.9);col(p[0],p[1],.4);}
    birds(2,24,A.R||40);}
  else if(biome==='kingdom'){
    for(let i=0;i<n(200);i++){const p=spot(.2,2,6);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('coneL',pick(['#5fae4a','#4f9e3a','#6fbf5a']),.08,.5+Rn()*.4,.08,p[0]+j*.15,y+.25,p[1]+(j%2)*.12,(j-1)*.3,0,(j-1)*.2);}
    for(let i=0;i<n(30);i++){const p=spot(1,3);if(p)flowerPatch(p[0],p[1],6+Math.round(Rn()*6),1.6,[pick(['#ff6b6b','#ffd23f','#7fc8f0','#c9b6ff','#ff9ecb','#ffffff'])],Rn);}
    for(let i=0;i<n(9);i++){const p=spot(1,4);if(!p)continue;const y=gy(p[0],p[1]);I('cyl','#c26a32',.6,.7,.6,p[0],y+.35,p[1]);const k=pick(['sph','box','cone','pyr']);I(k,'#4fae4a',.9,k==='cone'||k==='pyr'?1.8:.9,.9,p[0],y+(k==='cone'||k==='pyr'?1.6:1.6),p[1]);col(p[0],p[1],.8);}
    for(let i=0;i<n(10);i++){const p=spot(.8,4);if(!p)continue;const y=gy(p[0],p[1]),d=1+Math.floor(Rn()*9);I('box',pick(['#ff6b6b','#ffd23f','#7fc8f0','#8fe39a','#c9b6ff']),1.1,1.1,1.1,p[0],y+.55,p[1],0,Rn()*3,0);spr(d+'️⃣',.9,p[0],y+1.6,p[1]);col(p[0],p[1],.8);}
    for(let i=0;i<n(6);i++){const p=spot(1,4);if(!p)continue;const y=gy(p[0],p[1]);I('cylL','#ffffff',.12,2.6,.12,p[0],y+1.3,p[1]);I('sph',pick(['#ff6b6b','#ff9ecb','#ffd23f','#c9b6ff']),.9,.9,.4,p[0],y+3,p[1],0,Rn()*3,0);col(p[0],p[1],.4);}
    for(let i=0;i<n(8);i++){const p=spot(1.4,4);if(p)bush(p[0],p[1],.7+Rn()*.4,pick(['#5fbf5a','#4fae4a','#6cc45e']),Rn()<.5?pick(['#ff5d6c','#ffd23f']):null);}
    for(let i=0;i<n(4);i++){const p=spot(1.8,5);if(p)tree(p[0],p[1],.8+Rn()*.4,pick(['#5fbf5a','#7fcf6a','#ffb347']));}
    butterflies(Math.max(3,n(8)),0,0,(A.R||40)*.6);birds(2,24,A.R||40);}
  else if(biome==='snow'){
    for(let i=0;i<n(70);i++){const p=spot(.6,3,8);if(!p)continue;const y=gy(p[0],p[1]);I('sphL','#ffffff',.9+Rn()*1.2,.35+Rn()*.3,.8+Rn(),p[0],y+.05,p[1],0,Rn()*3,0);}
    for(let i=0;i<n(16);i++){const p=spot(1.4,4);if(p)snowPine(p[0],p[1],.7+Rn()*.6);}
    for(let i=0;i<n(10);i++){const p=spot(1.2,4);if(p)snowRock(p[0],p[1],.6+Rn()*.5);}
    for(let i=0;i<n(5);i++){const p=spot(.8,4);if(p){const y=gy(p[0],p[1]);for(let j=0;j<4;j++)I('sph','#ffffff',.3,.3,.3,p[0]+(j%2)*.4,y+.3+(j>1?.35:0),p[1]+(j>1?.2:0));}}
    for(let i=0;i<n(6);i++){const p=spot(.4,4);if(p){const y=gy(p[0],p[1]),c=pick(['#e8423a','#3d8fe0','#ffd23f']);I('cyl','#9b6a43',.07,1.8,.07,p[0],y+.9,p[1]);I('box',c,.6,.4,.05,p[0]+.3,y+1.6,p[1]);}}
    for(let i=0;i<n(3);i++){const p=spot(1,5);if(p)snowman(p[0],p[1],.7+Rn()*.3);}
    for(let i=0;i<n(5);i++){const p=spot(1,4);if(p){const y=gy(p[0],p[1]);I('box','#9b6a43',1.6,.3,.6,p[0],y+.6,p[1],0,Rn()*3,0);for(let j=0;j<2;j++)I('box','#c9905f',.3,.6,.3,p[0]+(j?.6:-.6),y+.3,p[1],0,0,0);}}
    birds(2,26,A.R||40);}
  else if(biome==='ice'){
    for(let i=0;i<n(30);i++){const p=spot(.6,3);if(!p)continue;const y=gy(p[0],p[1]),c=pick(['#9be8ff','#c9b6ff','#ff9ecb','#e8f6ff']);for(let j=0;j<3;j++)I('cone',c,.25,1+Rn()*1.4,.25,p[0]+(j-1)*.35,y+.6,p[1],0,0,(j-1)*.35,true);}
    for(let i=0;i<n(30);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]);I('sph','#e8f6ff',.7+Rn()*.6,.3,.6,p[0],y+.1,p[1]);}}}
  else if(biome==='reef'){
    for(let i=0;i<n(40);i++){const p=spot(.8,3,10);if(!p)continue;const y=gy(p[0],p[1]);for(let j=0;j<3;j++)I('box',pick(['#5fae4a','#3f9e46','#6fbf5a']),.12,1+Rn()*1.2,.05,p[0]+j*.25,y+.6,p[1],0,Rn()*3,(j-1)*.25);}
    for(let i=0;i<n(16);i++){const p=spot(1,4);if(p)coral(p[0],p[1],.6+Rn()*.6,pick(['#ff7f9e','#ffb347','#c78cff','#ff6b6b','#7fd3f0','#ffd23f']),pick(['branch','fan','brain']));}
    for(let i=0;i<n(40);i++){const p=spot(.3,2,6);if(p)shellAt(p[0],p[1],pick(['#ffd9e6','#fff4dc','#ffe0b8','#ffc4dc']));}
    for(let i=0;i<n(10);i++){const p=spot(.5,3);if(p){const y=gy(p[0],p[1]);I('sph','#3a2a40',.35,.3,.35,p[0],y+.2,p[1]);for(let j=0;j<6;j++)I('cylL','#3a2a40',.03,.6,.03,p[0],y+.35,p[1],Math.cos(j)*.9,0,Math.sin(j)*.9);}}
    for(let i=0;i<n(10);i++){const p=spot(.6,3);if(p){const y=gy(p[0],p[1]),c=pick(['#ff7fd0','#7fffe0','#ffb347']);for(let j=0;j<7;j++)I('cylL',c,.06,.6,.06,p[0]+Math.cos(j)*.2,y+.3,p[1]+Math.sin(j)*.2,Math.cos(j)*.4,0,Math.sin(j)*.4);}}
    for(let i=0;i<n(8);i++){const p=spot(.4,3);if(p)spr('⭐',.8,p[0],gy(p[0],p[1])+.25,p[1]);}
    fishSchool(0,4+Rn()*4,0,(A.R||40)*.45,6,'🐟',.4);}}
