/* ================================================================
   Halloween (Pup Seasons 3, 25 Nov 2026; claude/halloween-design.md): the engine.
   A storybook dusk (purple sky, harvest moon, falling leaves, friendly bats), Seb's little pup
   in a bedsheet costume (named by Seb; a real puppy in a costume, never a ghost), the three hiding
   tricks (the wiggling pumpkin, trick-or-treat doors, pumpkin carving), finding a Halloween pup,
   the nine Brave Paws from the unicorns, the opening, the invitation and the grown-ups switch.
   Shares window.SEASONS, the Season Globe and the spot planner grid with season.js.
   Save: state.sx.hw = {pal:{name,girl,at}, found:{id:time}, how:{id:kind}, tagged:{id:1},
   bp:{island:time}, inv, intro, ...}; created only once Halloween is opened and started.
   ================================================================ */
(function(){
const PI=Math.PI,HL=window.HLOOK,HP=HL.HPUPS,hp=HL.hp,FACT=HL.FACT,XM=window.XMAS,ORANGE='#ff8a1a',CANDY='#ffd23f';
const G0=()=>(state&&state.sx&&state.sx.hw)||null;
const GS=()=>{if(!state.sx)state.sx={};const s=state.sx;if(!s.hw)s.hw={found:{},how:{},tagged:{},bp:{}};if(!s.hw.bp)s.hw.bp={};return s.hw;};
const on=()=>!!(state&&state.season==='hw');
const glowDone=()=>!!(state&&state.sx&&state.sx.glow&&state.sx.glow.done);
const opened=()=>glowDone()||!!(state&&state.set&&state.set.hwOpen);
const named=()=>!!(G0()&&G0().pal);
let ALL=null;
const all=()=>ALL||(ALL=ISLANDS.reduce((a,I)=>a.concat(I.pups,I.bonus||[]),[]).concat([HP.marmalade,HP.conker]));
const gpup=id=>PUPS[id]||HP[id];
const xFound=id=>!!(G0()&&G0().found[id]);
const nFound=()=>G0()?all().filter(p=>xFound(p.id)).length:0;
const islX=I=>I.pups.concat(I.bonus||[]);
const islN=I=>islX(I).filter(p=>xFound(p.id)).length;
const areaX=a=>all().filter(p=>p.area===a);
const nBp=()=>Object.keys((G0()||{}).bp||{}).length;
const pal=()=>(G0()&&G0().pal)||{name:'the little pup',girl:false};
const he=()=>pal().girl?'she':'he',his=()=>pal().girl?'her':'his',him=()=>pal().girl?'her':'him',He=()=>pal().girl?'She':'He';
const kindOf=p=>p.season==='hw'||p.bonus?'carve':p.tag?'door':'look';
const NEED=6;
const hsh=s=>{let h=7;for(const ch of String(s))h=(h*31+ch.charCodeAt(0))%100003;return h;};

/* ---------------- sounds ---------------- */
const BRAVE=[523,587,659,698,784,880,988,1047,1175];/* a rising scale, one note per Brave Paw */
const snd={
 knock(){if(!fxOk())return;const t=AC.currentTime;[0,.16,.32].forEach(d=>{nzHit(t+d,.07,.22,'lowpass',420);tone(140,t+d,.06,'sine',.12);});},
 squeak(){if(!fxOk())return;const t=AC.currentTime;tone(2600,t,.06,'sine',.06,null,3400);tone(2900,t+.08,.06,'sine',.05,null,3600);},
 purr(){if(!fxOk())return;const t=AC.currentTime;for(let i=0;i<10;i++)nzHit(t+i*.06,.05,.05,'lowpass',260);},
 pop(){if(!fxOk())return;const t=AC.currentTime;tone(520,t,.08,'square',.06,null,1000);nzHit(t,.05,.08,'highpass',2600);},
 rustle(){if(!fxOk())return;const t=AC.currentTime;nzHit(t,.25,.06,'highpass',3200);nzHit(t+.12,.2,.05,'highpass',3800);},
 boo(){if(!fxOk())return;const t=AC.currentTime;tone(660,t,.35,'sine',.08,null,520);},
 twinkle(){if(!fxOk())return;const t=AC.currentTime;[1319,1568,2093,2637].forEach((f,i)=>tone(f,t+i*.08,.22,'sine',.09));},
 note(i){if(!fxOk())return;const t=AC.currentTime,f=BRAVE[i%9];tone(f,t,.4,'triangle',.13);tone(f*2,t,.2,'sine',.03);},
 song(n,gap){for(let i=0;i<n;i++)setTimeout(()=>snd.note(i),i*(gap||260));}};

/* ================= the dusk look ================= */
const NOHW=new Set(['den','cave','glow','vault','ambercave','library','alien']);
const DUSK={sky:'#e6c0ff',gr:'#5a3a4a',hi:.68,dir:'#ffb070',di:.52,pos:[-90,30,-80],lantern:1.1};
const MUSEUM={sky:'#e0d0f6',gr:'#6a5a7a',hi:.56,dir:'#ffc890',di:.34,pos:[20,90,10],lantern:.9};
const mixC=(a,b,k)=>{const c=new THREE.Color(a||'#888888');c.lerp(new THREE.Color(b),k);return '#'+c.getHexString();};
const dusk=A=>!!(A&&!NOHW.has(A.id)&&!A.indoor);
const museum=A=>!!(A&&A.indoor&&A.island==='number');
function lookFor(A){if(museum(A))return {light:Object.assign({},MUSEUM)};if(!dusk(A))return null;
  const space=(A.island||A.id)==='planet',o={light:Object.assign({},DUSK),skyObj:Object.assign({},A.skyObj||{},{stars:true,sun:null})};
  if(!space){o.sky=A.swim?'#3a3a86':'#4b3a7a';o.fogC=o.sky;o.fog=[60,215];o.ground=mixC(A.ground,'#8a5a2a',.22);o.ground2=mixC(A.ground2||A.ground,'#8a5a2a',.22);}
  if(A.swim){o.light.hi=.76;o.light.sky='#b8c0ff';}return o;}
let MOONT=null,GLT=null,LEAFT=null,BATT=null;
const canvasTex=(w,h,f)=>{const c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'));return new THREE.CanvasTexture(c);};
function moonTex(){return MOONT||(MOONT=canvasTex(128,128,x=>{const g=x.createRadialGradient(56,56,8,64,64,52);g.addColorStop(0,'#ffe2a8');g.addColorStop(1,'#ff9a3a');x.fillStyle=g;x.beginPath();x.arc(64,64,50,0,PI*2);x.fill();
  [[48,50,8],[78,72,10],[70,42,5],[52,82,6]].forEach(q=>{x.fillStyle='rgba(200,110,40,.35)';x.beginPath();x.arc(q[0],q[1],q[2],0,PI*2);x.fill();});}));}
function glowTex(){return GLT||(GLT=canvasTex(64,64,x=>{const g=x.createRadialGradient(32,32,0,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.3,'rgba(255,255,255,.7)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);}));}
function leafTex(){return LEAFT||(LEAFT=canvasTex(64,64,x=>{x.fillStyle='#ffffff';x.beginPath();x.moveTo(32,4);x.quadraticCurveTo(58,20,46,46);x.quadraticCurveTo(36,58,32,60);x.quadraticCurveTo(28,58,18,46);x.quadraticCurveTo(6,20,32,4);x.fill();
  x.strokeStyle='rgba(120,60,20,.6)';x.lineWidth=2;x.beginPath();x.moveTo(32,8);x.lineTo(32,60);x.stroke();}));}
function batTex(){return BATT||(BATT=canvasTex(64,64,x=>{x.fillStyle='#3a2a50';x.beginPath();x.moveTo(32,24);x.lineTo(20,16);x.lineTo(4,22);x.lineTo(10,30);x.lineTo(4,38);x.lineTo(16,36);x.lineTo(22,44);x.lineTo(32,36);
  x.lineTo(42,44);x.lineTo(48,36);x.lineTo(60,38);x.lineTo(54,30);x.lineTo(60,22);x.lineTo(44,16);x.closePath();x.fill();x.beginPath();x.arc(32,30,7,0,PI*2);x.fill();
  x.beginPath();x.moveTo(26,24);x.lineTo(28,16);x.lineTo(31,24);x.moveTo(33,24);x.lineTo(36,16);x.lineTo(38,24);x.fill();x.fillStyle='#ffd23f';[[29,29],[35,29]].forEach(q=>{x.beginPath();x.arc(q[0],q[1],1.8,0,PI*2);x.fill();});}));}
function glowMat(col,op){return new THREE.SpriteMaterial({map:glowTex(),color:col||ORANGE,transparent:true,opacity:op==null?.9:op,depthWrite:false,blending:THREE.AdditiveBlending,fog:false});}
function moonSky(A){if((A.island||A.id)==='planet')return;const m=new THREE.Sprite(new THREE.SpriteMaterial({map:moonTex(),transparent:true,depthWrite:false,fog:false}));m.scale.set(64,64,1);m.position.set(-170,42,-240);W.ag.add(m);W.disp.push(m.material);
  const h=new THREE.Sprite(glowMat('#ffb070',.32));h.scale.set(150,150,1);h.position.copy(m.position);W.ag.add(h);W.disp.push(h.material);}
/* autumn leaves drifting down round Seb: one points cloud with a colour per leaf */
function leafFall(A,n){const P=new Float32Array(n*3),C=new Float32Array(n*3),B=[],R=seed(hsh(A.id)+9),cols=['#ff8a1a','#e8423a','#ffc21a','#c8641a','#a8501a'].map(c=>new THREE.Color(c));
  for(let i=0;i<n;i++){B.push([(R()-.5)*70,R()*22,(R()-.5)*70,R()*6,.6+R()*.9]);const c=cols[i%cols.length];C[i*3]=c.r;C[i*3+1]=c.g;C[i*3+2]=c.b;}
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('color',new THREE.BufferAttribute(C,3));
  const m=new THREE.PointsMaterial({size:.55,map:leafTex(),vertexColors:true,transparent:true,alphaTest:.3,depthWrite:false});const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);
  const tick=dt=>{if(W.area!==A||!pts.parent)return true;const px=player.x,pz=player.z,by=walkY(px,pz),t=W.t;for(let i=0;i<n;i++){const b=B[i];b[1]-=dt*b[4];if(b[1]<0)b[1]+=22;
      let x=b[0]+Math.sin(t*.9+b[3])*1.2,z=b[2]+Math.cos(t*.7+b[3])*1.2;x=((x-px+35)%70+70)%70-35+px;z=((z-pz+35)%70+70)%70-35+pz;P[i*3]=x;P[i*3+1]=by+b[1];P[i*3+2]=z;}
    g.attributes.position.needsUpdate=true;};W.ticks.push(tick);tick(0);return pts;}
/* friendly bats, circling high up */
function batsPts(A,n){const P=new Float32Array(n*3),B=[],R=seed(hsh(A.id)+4);for(let i=0;i<n;i++)B.push([R()*PI*2,14+R()*22,16+R()*10,.25+R()*.35,R()*6]);
  const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));const m=new THREE.PointsMaterial({size:2.2,map:batTex(),transparent:true,alphaTest:.3,depthWrite:false,fog:false});
  const pts=new THREE.Points(g,m);pts.frustumCulled=false;W.ag.add(pts);W.disp.push(g,m);const cx=0,cz=0;
  const tick=()=>{if(W.area!==A||!pts.parent)return true;const t=W.t;for(let i=0;i<n;i++){const b=B[i],a=b[0]+t*b[3];P[i*3]=cx+Math.cos(a)*b[1];P[i*3+1]=b[2]+Math.sin(t*2+b[4])*1.2;P[i*3+2]=cz+Math.sin(a)*b[1];}
    m.size=2.0+Math.abs(Math.sin(t*9))*.6;g.attributes.position.needsUpdate=true;};W.ticks.push(tick);tick();return pts;}

/* ================= entering an area in Halloween ================= */
const _ea=enterArea;
enterArea=function(id,pos,msg){const A=AREAS[id];
  if(!A||!on())return _ea.apply(this,arguments);
  const o=lookFor(A),keep={};if(o)for(const k in o){keep[k]=[k in A,A[k]];A[k]=o[k];}
  if(!msg&&named()&&G0().intro){const L=areaX(id),left=L.filter(p=>!xFound(p.id)).length;if(L.length)msg=`${A.icon} ${A.name} at Halloween! `+(left?`${left===1?'One pup':left+' pups'} in costume ${left===1?'is':'are'} hiding here. Watch ${pal().name}'s tail!`:'Every pup in costume here is found!');}
  try{_ea.call(this,id,pos,msg);}finally{for(const k in keep){if(keep[k][0])A[k]=keep[k][1];else delete A[k];}}
  if(W.area!==A)return;
  if(dusk(A)){moonSky(A);if(!A.swim)leafFall(A,A.id==='village'?110:90);batsPts(A,A.swim?0:9);}
  if(window.HWORLD&&HWORLD.after)try{HWORLD.after(A);}catch(e){console.warn('hw after',e);}
  palEnter(A);hud();
  const I=A.island&&islandOf(A.island);if(I&&named()&&G0().intro&&islN(I)>=NEED&&!G0().bp[I.id])setTimeout(()=>{if(W.area===A&&!player.lock&&!ovOpen())brave(I);},1800);
  if(id==='village')setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||!W.area||W.area.id!=='village')return;if(window.HSTORY&&HSTORY.village)HSTORY.village();},900);};
Object.values(AREAS).forEach(A=>{const b=A.build;if(typeof b!=='function')return;A.build=function(){b.apply(this,arguments);if(on()&&window.HWORLD&&HWORLD.build)try{HWORLD.build(A);}catch(e){console.warn('hw build',e);}};});

/* ================= hiding spots ================= */
const _bs=buildSpots;buildSpots=function(A){if(!on())return _bs(A);if(HW.noSpots)return;hSpots(A);};
const _bb=buildBoss;buildBoss=function(IS){if(!on())return _bb(IS);uniHome(IS);};
const _ac=areaCount;areaCount=function(a){if(!on())return _ac(a);const L=areaX(a);return L.length?`🎃 ${L.filter(p=>xFound(p.id)).length}/${L.length}`:'';};
let PLAN=null,LIVE=[];
function spotFor(p,A){const S=(window.HSPOTS||{})[p.id];if(S)return S;if(!PLAN||PLAN.area!==A.id){PLAN=plan(A);PLAN.area=A.id;}return PLAN.spots[p.id]||null;}
function hSpots(A){LIVE=[];areaX(A.id).forEach(p=>{const S=spotFor(p,A);if(!S)return;const k=S.k||kindOf(p);try{
    if(k==='look')LIVE.push(patch(p,S,A));else if(k==='carve')LIVE.push(carveSpot(p,S,A));else if(k==='door')LIVE.push(door(p,S,A));}catch(e){console.warn('hw spot',p.id,e);}});
  W.ticks.push(spotTick);}
/* pumpkins, coloured for each island */
const PCOL={meadow:'#ff8a1a',snowy:'#f2efe6',reef:'#8aa0a8',ninja:'#d8402a',number:'#ff8a1a',gadget:'#b8c0cc',rescue:'#ff8a1a',dino:'#6aa84a',planet:'#9a5ad8',village:'#ff8a1a'};
const pcol=A=>PCOL[A.island||'village']||ORANGE;
function pumpkin3D(par,col,s,face){const g=grp();g.scale.setScalar(s||1);par.add(g);const dk=mixC(col,'#3a2010',.25);
  mk('sph',col,.62,.46,.62,0,.42,0,g);for(let i=0;i<4;i++){const a=i*PI/2+PI/4;mk('sph',dk,.3,.43,.3,Math.cos(a)*.34,.42,Math.sin(a)*.34,g);}
  mk('cyl','#4a7a2a',.05,.22,.05,0,.92,0,g);
  if(face){mk('box','#ffd23f',.13,.13,.04,-.2,.52,.6,g,true);mk('box','#ffd23f',.13,.13,.04,.2,.52,.6,g,true);mk('box','#ffd23f',.36,.09,.04,0,.3,.6,g,true);}
  return g;}
/* 1. spot the costume: a patch of pumpkins, and one of them wiggles */
function patch(p,S,A){const isl=A.island||'village',R=seed(hsh(p.id)+7),n=5,G0=grp(),ps=[],right=hsh(p.id+'r')%n,num=isl==='number',found=xFound(p.id),pc=pcol(A);let wig=null;
  for(let i=0;i<n;i++){const a=i/n*PI*2+R()*.5,r=i?1.7+R()*.4:.2,s=.85+R()*.35;if(i===right){wig=grp();pumpkin3D(wig,pc,s);wig.position.set(S.x+Math.cos(a)*r,0,S.z+Math.sin(a)*r);wig.rotation.y=R()*PI;}
    else{const g=pumpkin3D(G0,pc,s);g.position.set(Math.cos(a)*r,0,Math.sin(a)*r);g.rotation.y=R()*PI;}ps.push({s});}
  add(G0,S.x,S.z);bakeModel(G0,'hpatch|'+isl+'|'+p.id);add(wig,wig.position.x,wig.position.z);bakeModel(wig,'hwig|'+isl+'|'+p.id);if(!A.ski)col(S.x,S.z,1.3);
  const R2=seed(hsh(p.id)+3),used={},cnt=ps.map(()=>{let v;do{v=2+Math.floor(R2()*9);}while(used[v]);used[v]=1;return v;});
  const o={p,k:'look',x:S.x,z:S.z,g:G0,wig,ps,right,n,cnt,num,tries:0,col:pc};
  if(!found){o.easy=spr('🎃',1.6,S.x,gy(S.x,S.z)+4,S.z);}else markFound(o);
  W.things.push({x:S.x,z:S.z,r:4.4,icon:'🎃',label:'Pumpkins!',show:()=>!xFound(p.id),act:()=>openPatch(o)});return o;}
/* 3. pumpkin carving: a giant pumpkin on a ring of candle light */
function carveSpot(p,S,A){const found=xFound(p.id),y=gy(S.x,S.z),g=grp();pumpkin3D(g,pcol(A),2.1,found);add(g,S.x,S.z);bakeModel(g,'hcarve|'+(A.island||'v')+(found?1:0));
  const m=new THREE.MeshBasicMaterial({color:'#ffb040',transparent:true,opacity:.7,depthWrite:false}),ring=new THREE.Mesh(G.tor||G.sph,m);ring.scale.set(2.3,2.3,.35);ring.rotation.x=PI/2;ring.position.set(S.x,y+.12,S.z);W.ag.add(ring);W.disp.push(m);
  const o={p,k:'carve',x:S.x,z:S.z,ring,m,g};if(!A.ski)col(S.x,S.z,1.4);
  if(found)markFound(o);else o.glow=spr('🕯️',1.6,S.x,y+3.6,S.z);
  W.things.push({x:S.x,z:S.z,r:4.4,icon:'🎃',label:'Carve the pumpkin',show:()=>!xFound(p.id),act:()=>openCarve(o)});return o;}
function markFound(o){if(o.easy){W.ag.remove(o.easy);o.easy=null;}if(o.glow){W.ag.remove(o.glow);o.glow=null;}if(o.ring)o.m.opacity=.25;if(o.wig)o.wig.rotation.z=0;
  if(!o.mark)o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+3.4,o.z);}
/* 2. trick-or-treat doors, at the end of a trail of sweets */
let candyT=null;
function candyTex(){return candyT||(candyT=canvasTex(64,64,x=>{const cols=['#ff5a8a','#ffd23f','#5ab8ff','#8ae05a','#ff8a1a'];x.save();x.translate(32,32);x.rotate(-.4);
  x.fillStyle='#ffffff';x.beginPath();x.moveTo(-28,-10);x.lineTo(-14,0);x.lineTo(-28,10);x.fill();x.beginPath();x.moveTo(28,-10);x.lineTo(14,0);x.lineTo(28,10);x.fill();
  x.beginPath();x.ellipse(0,0,15,11,0,0,PI*2);x.fill();x.fillStyle='rgba(0,0,0,.12)';x.fillRect(-6,-11,4,22);x.fillRect(4,-11,4,22);x.restore();}));}
function sweets(pts){const step=1.5,out=[];for(let i=0;i<pts.length-1;i++){const a=pts[i],b=pts[i+1],d=Math.hypot(b[0]-a[0],b[1]-a[1]),n=Math.max(1,Math.floor(d/step));
    for(let k=0;k<n;k++){const t=k/n;out.push([a[0]+(b[0]-a[0])*t,a[1]+(b[1]-a[1])*t,hsh(i*31+k)%6]);}}
  const cols=['#ff5a8a','#ffd23f','#5ab8ff','#8ae05a','#ff8a1a','#b88aff'],m=new THREE.MeshBasicMaterial({map:candyTex(),transparent:true,alphaTest:.4,depthWrite:false}),
    im=new THREE.InstancedMesh(G.plane,m,Math.max(1,out.length)),M4=new THREE.Matrix4(),q=new THREE.Quaternion(),s=new THREE.Vector3(.7,1,.7),v=new THREE.Vector3(),e=new THREE.Euler(),c=new THREE.Color();
  out.forEach((p,i)=>{e.set(0,p[2],0);q.setFromEuler(e);v.set(p[0],walkY(p[0],p[1])+.07,p[1]);M4.compose(v,q,s);im.setMatrixAt(i,M4);im.setColorAt(i,c.set(cols[p[2]]));});
  im.count=out.length;im.frustumCulled=false;if(im.instanceColor)im.instanceColor.needsUpdate=true;W.ag.add(im);W.disp.push(m);return {im,m,n:out.length};}
function door3D(A,key){const g=grp(),R=seed(hsh(key)),dc=['#8a4a2a','#5a2a8a','#2a6a5a','#a8302a'][hsh(key)%4];
  mk('box','#6a5a4a',1.5,2.0,.3,0,1.0,-.05,g);mk('box',dc,1.15,1.6,.12,0,.86,.12,g);mk('cyl',dc,.58,.12,.58,0,1.66,.12,g).rotation.x=PI/2;mk('cyl','#6a5a4a',.75,.3,.75,0,1.78,-.05,g).rotation.x=PI/2;
  mk('sph','#ffd23f',.07,.07,.07,.38,.9,.22,g,true);const pk=pumpkin3D(g,ORANGE,.55,true);pk.position.set(1.05,0,.25);R();g.scale.setScalar(DS);return g;}
const DS=1.7;
function trailSpot(p,S,A){const tagged=!!(G0()&&G0().tagged[p.id]),found=xFound(p.id),to=tagged?S.c:S.b,path=tagged?S.bc:S.ab;
  const o={p,k:'door',S,x:to[0],z:to[1],tagged};o.g=door3D(A,p.id+(tagged?'c':'b'));add(o.g,o.x,o.z);o.g.rotation.y=hsh(p.id+(tagged?'c':'b'))%6;bakeModel(o.g,'hdoor|'+hsh(p.id+(tagged?'c':'b'))%4);col(o.x,o.z,1.6);
  if(found){o.mark=spr('✅',1.5,o.x,gy(o.x,o.z)+4.4,o.z);return o;}
  o.pr=sweets(path||[[tagged?S.b[0]:S.a[0],tagged?S.b[1]:S.a[1]],to]);o.easy=spr('🚪',1.6,o.x,gy(o.x,o.z)+4.8,o.z);
  o.th={x:o.x,z:o.z,r:3.9,icon:'✊',label:'Knock knock!',show:()=>!xFound(p.id)&&!o.busy,act:()=>knock(o)};W.things.push(o.th);return o;}
const door=trailSpot;
function spotTick(dt){const t=W.t,P=player;let near=null,nd=1e9;
  LIVE.forEach(o=>{if(o.easy){o.easy.visible=state.set.hsEasy;o.easy.position.y=gy(o.x,o.z)+(o.k==='door'?5:4)+Math.sin(t*3)*.3;}if(o.glow)o.glow.position.y=gy(o.x,o.z)+3.6+Math.sin(t*2.5)*.2;
    if(o.ring&&!xFound(o.p.id)){o.m.opacity=.5+.3*Math.sin(t*2.6);o.ring.rotation.z=t*.3;}
    if(o.wig&&!xFound(o.p.id)){const ph=(t+hsh(o.p.id)%5)%3.4;o.wig.rotation.z=ph<.7?Math.sin(ph*28)*.18*(1-ph/.7):0;}
    if(xFound(o.p.id))return;const d=Math.hypot(P.x-o.x,P.z-o.z);if(d<nd){nd=d;near=o;}});
  if(near&&nd<9&&t-(HW.jT||0)>2.8&&!P.lock&&!ovOpen()){HW.jT=t;if(near.k==='look')snd.rustle();else if(near.k==='carve')snd.twinkle();else{sfx.yip((near.p.pitch||1)*1.1);floatS('🍬',near.x,gy(near.x,near.z)+2.6,near.z,1.2);}}
  if(near&&!P.lock&&t-W.findT>75&&t-W.hintT>75){W.hintT=t;sparkTrail(near);}}
function sparkTrail(o){W.trail.forEach(s=>W.ag.remove(s));W.trail=[];const P=player,dx=o.x-P.x,dz=o.z-P.z,d=Math.hypot(dx,dz),n=Math.min(10,Math.floor((d-3)/2.5));
  for(let i=1;i<=n;i++){const x=P.x+dx*i/(n+1.2),z=P.z+dz*i/(n+1.2);W.trail.push(spr('🍬',1.1,x,gy(x,z)+.6,z));}
  PAL.jump=.7;snd.twinkle();say(`${pal().name} is wagging like mad! Follow the sweets, Seb!`);}

/* ----- the pumpkin picker ----- */
const SURP=[['🦇','Eek! A little bat, hanging upside down.'],['🐈‍⬛','Purr! Just a black cat having a snooze.'],['🐸','Ribbit! A toad hops out.'],['🐭','A mouse, nibbling a sweet!'],['🦉','A sleepy owl. Hoo!'],['🕷️','A tiny spider waves from its thread. Hello!'],['🍬','Just a pile of sweets!']];
function numClue(n){const R=Math.random(),a=1+Math.floor(Math.random()*(n-1));if(n%2===0&&R<.3)return `double ${n/2}`;if(R<.65)return `${a} add ${n-a}`;const b=1+Math.floor(Math.random()*4);return `${n+b} take away ${b}`;}
function pickSVG(col,num,tail){return `<svg viewBox="0 0 120 120" width="120" height="120">${tail?'<path class="htail" d="M86 92 q22 -2 24 -24" stroke="#26232e" stroke-width="10" fill="none" stroke-linecap="round"/><path class="htail" d="M86 92 q22 -2 24 -24" stroke="#f3dcae" stroke-width="6" fill="none" stroke-linecap="round"/>':''}${HL.pumpkinSVG(60,72,40,col,false)}`+
  (num!=null?`<circle cx="60" cy="74" r="17" fill="#fff" stroke="#26232e" stroke-width="3"/><text x="60" y="83" font-size="24" font-weight="900" text-anchor="middle" font-family="Arial" fill="#26232e">${num}</text>`:'')+`</svg>`;}
let PK=null;
function pickUI(){if($('#hpick'))return;const d=el('div','ov','<div class="card" id="hpCard"><h2 id="hpH"></h2><div id="hpRow"></div><p id="hpMsg"></p><div class="btns"><button class="btn white" id="hpBack">Back</button></div></div>');d.id='hpick';document.body.appendChild(d);
  tap('#hpBack',()=>{sfx.boop();closePick();});}
function closePick(){$('#hpick').classList.remove('on');player.lock=false;PK=null;hush();}
function openPatch(o){if(player.lock||xFound(o.p.id))return;pickUI();player.lock=true;hush();snd.rustle();PK=o;o.tries=0;o.opened={};
  const F=pal().name,row=$('#hpRow');row.innerHTML='';$('#hpMsg').textContent='';const N=o.cnt[o.right];
  const order=o.ps.map((q,i)=>i);order.sort((a,b)=>hsh(o.p.id+a)%7-hsh(o.p.id+b)%7);
  order.forEach(i=>{const b=el('button','hpr'+(i===o.right&&!o.num?' wig':''),pickSVG(o.col,o.num?o.cnt[i]:null,i===o.right&&!o.num));b.dataset.i=i;tap(b,()=>tapPumpkin(o,i,b));row.appendChild(b);});
  if(o.num){o.clue=numClue(N);$('#hpH').textContent=`🔢 Which pumpkin makes ${o.clue}?`;speak(`${F} says: the puppy is hiding in the pumpkin that makes ${o.clue}. Which one is it?`);}
  else{$('#hpH').textContent='🎃 Which pumpkin is a pup in costume?';speak(`${F} says: one of these pumpkins is really a pup in a costume! Watch for the one that wiggles, and look for a tail!`);}
  $('#hpick').classList.add('on');}
function tapPumpkin(o,i,b){if(o.opened[i]||PK!==o)return;o.opened[i]=1;b.classList.remove('hint','wig');b.classList.add('open');
  if(i===o.right){snd.pop();sfx.yip(o.p.pitch);b.innerHTML=`<div class="hpup">${critterSVG(hp(o.p),{anim:false})}</div>`;$('#hpMsg').textContent=`Boo! It's ${o.p.name} in a costume!`;
    setTimeout(()=>{closePick();markFound(o);found(o.p,'look',o);},1100);return;}
  o.tries++;const S=SURP[(hsh(o.p.id)+o.tries*3+i)%SURP.length];if(S[0]==='🦇')snd.squeak();else if(S[0]==='🐈‍⬛')snd.purr();else sfx.boop();sfx.oops();
  b.innerHTML=`<div class="hsur"><span>${S[0]}</span>${o.num?`<small>${o.cnt[i]}</small>`:''}</div>`;
  let m=S[1]+(o.num?` Remember: the pumpkin that makes ${o.clue}.`:' Watch for the wiggle!');
  if(o.tries>=2){$('#hpRow').querySelectorAll('.hpr').forEach(e=>{if(+e.dataset.i===o.right)e.classList.add('hint');});m+=' Look, one of them is glowing!';}
  $('#hpMsg').textContent=m;speak(m);}
/* tag pups: the first knock makes them giggle and run to another door along a fresh trail of sweets */
function knock(o){if(player.lock||xFound(o.p.id))return;player.lock=true;o.busy=true;hush();snd.knock();say('Knock knock! Trick or treat!');o.g.scale.set(DS*1.05,DS*.95,DS*1.05);
  setTimeout(()=>{o.g.scale.setScalar(DS);if(!o.tagged){runOff(o);return;}o.busy=false;player.lock=false;found(o.p,'door',o);},1100);}
function runOff(o){const p=o.p,S=o.S,g=pup3D(p,p.shiny),A=W.area;add(g,o.x,o.z);sfx.giggle();say(`Hee hee! ${p.name} giggles and runs off to another door! Follow the new trail of sweets!`);
  GS().tagged[p.id]=1;save();const path=(S.bc||[S.b,S.c]).slice();let seg=0,k=0;
  if(o.pr){W.ag.remove(o.pr.im);o.pr=null;}if(o.easy){W.ag.remove(o.easy);o.easy=null;}
  W.ticks.push(function run(dt){if(W.area!==A)return true;const a=path[seg],b=path[seg+1];if(!b){W.ag.remove(g);W.ag.remove(o.g);const n=trailSpot(p,S,A);LIVE=LIVE.filter(q=>q!==o);LIVE.push(n);W.things=W.things.filter(t=>t!==o.th);flushTo(W.ag);player.lock=false;return true;}
    const d=Math.hypot(b[0]-a[0],b[1]-a[1])||.01;k+=dt*14/d;const e=Math.min(1,k),x=a[0]+(b[0]-a[0])*e,z=a[1]+(b[1]-a[1])*e;g.position.set(x,walkY(x,z)+Math.abs(Math.sin(W.t*16))*.35,z);g.rotation.y=Math.atan2(b[0]-a[0],b[1]-a[1]);animPup(g,W.t,true);
    if(e>=1){seg++;k=0;}});}

/* ================= pumpkin carving (also used by the finale) ================= */
/* faces to carve, in a 100 x 75 box, inside the pumpkin */
const SHAPES={
 head:[[50,68],[34,60],[27,46],[18,14],[34,27],[50,23],[66,27],[82,14],[73,46],[66,60]],
 cat:[[50,66],[33,60],[25,45],[23,15],[38,28],[50,26],[62,28],[77,15],[75,45],[67,60]],
 bat:[[50,28],[45,20],[40,30],[30,24],[18,26],[10,38],[20,36],[26,46],[34,40],[42,50],[50,60],[58,50],[66,40],[74,46],[80,36],[90,38],[82,26],[70,24],[60,30],[55,20]],
 grin:[[16,38],[24,46],[31,40],[39,50],[50,42],[61,50],[69,40],[76,46],[84,38],[78,56],[50,64],[22,56]]};
const STEP={meadow:1,snowy:1,reef:2,ninja:2,number:3,gadget:5,rescue:5,dino:10,planet:10,village:2};
let SP=null;
function carveUI(){if($('#hcarve'))return;const d=el('div','ov','<div class="card" id="hcCard"><h2 id="hcH"></h2><div id="hcBox"></div><p id="hcMsg"></p><div class="btns"><button class="btn white" id="hcBack">Back</button></div></div>');d.id='hcarve';document.body.appendChild(d);
  tap('#hcBack',()=>{sfx.boop();closeCarve();});}
function closeCarve(){$('#hcarve').classList.remove('on');if(SP&&SP.lock!==false)player.lock=false;const cb=SP&&SP.cancel;SP=null;hush();if(cb)cb();}
function carvePuzzle(o){carveUI();const pts=o.pts,step=o.step||1,start=o.start!=null?o.start:step,lab=i=>start+i*step,n=pts.length;SP={o,i:0,lock:o.lock,cancel:o.cancel};$('#hcBack').style.display=o.noBack?'none':'';
  const col=o.col||ORANGE,dk=mixC(col,'#3a2010',.3);
  $('#hcBox').innerHTML=`<svg viewBox="0 0 100 75" id="hcSvg"><rect width="100" height="75" rx="4" fill="#2a1f4a"/><ellipse cx="50" cy="42" rx="47" ry="32" fill="${col}"/>`+
    `<path d="M28 12 Q16 42 28 72 M50 10 V74 M72 12 Q84 42 72 72" stroke="${dk}" stroke-width=".9" fill="none" opacity=".7"/><path d="M49 11 q-1 -6 4 -9" stroke="#4a7a2a" stroke-width="2.4" fill="none" stroke-linecap="round"/>`+
    `<g id="hcLines"></g><g id="hcPic" opacity="0">${o.pic||''}</g>`+
    pts.map((p,i)=>`<g class="hcd" data-i="${i}"><circle cx="${p[0]}" cy="${p[1]}" r="5.4" fill="transparent"/><circle class="hcg" cx="${p[0]}" cy="${p[1]}" r="2.1" fill="#fff6c2" opacity=".35"/><circle cx="${p[0]}" cy="${p[1]}" r="1.25" fill="#fff6c2" stroke="#5a2a10" stroke-width=".35"/><text x="${p[0]+(p[0]>88?-3.4:2.2)}" y="${p[1]+(p[1]<8?4.8:-2)}" font-size="3.4" font-weight="900" fill="#ffffff" stroke="#3a1a08" stroke-width=".5" paint-order="stroke" font-family="Arial" text-anchor="${p[0]>88?'end':'start'}">${lab(i)}</text></g>`).join('')+`</svg>`;
  $('#hcH').textContent=o.title||'🎃 Carve the pumpkin!';const intro=o.say||`Tap the dots in order: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;$('#hcMsg').textContent=step===1?'Start at 1 and keep going!':`Count in ${step}s: ${lab(0)}, ${lab(1)}, ${lab(2)}...`;speak(intro);
  const mark=()=>document.querySelectorAll('#hcSvg .hcd').forEach(g=>g.classList.toggle('next',+g.dataset.i===SP.i));mark();
  document.querySelectorAll('#hcSvg .hcd').forEach(g=>tap(g,()=>{if(!SP||SP.o!==o)return;const i=+g.dataset.i;
    if(i!==SP.i){if(i<SP.i)return;sfx.oops();const m=`Look for ${lab(SP.i)}.`;$('#hcMsg').textContent=m;speak(m);g.classList.remove('nope');void g.getBBox();g.classList.add('nope');return;}
    snd.note(i);g.classList.add('done');if(i>0){const a=pts[i-1],b=pts[i];$('#hcLines').insertAdjacentHTML('beforeend',`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#5a2a10" stroke-width="1.1" stroke-linecap="round"/>`);}
    SP.i++;if(SP.i<n){mark();$('#hcMsg').textContent=`${lab(i)}! Next: ${lab(SP.i)}`;return;}
    if(o.loop!==false){const a=pts[n-1],b=pts[0];$('#hcLines').insertAdjacentHTML('beforeend',`<line x1="${a[0]}" y1="${a[1]}" x2="${b[0]}" y2="${b[1]}" stroke="#5a2a10" stroke-width="1.1" stroke-linecap="round"/>`);
      $('#hcLines').insertAdjacentHTML('afterbegin',`<polygon class="hclit" points="${pts.map(p=>p.join(',')).join(' ')}" fill="#ffd23f"/>`);}
    mark();$('#hcSvg').classList.add('win');$('#hcPic').setAttribute('opacity','1');snd.twinkle();confetti(24);const m=o.win||'You carved the pumpkin!';$('#hcMsg').textContent=m;speak(m);
    const done=o.done;SP.cancel=null;setTimeout(()=>{if(!$('#hcarve').classList.contains('on'))return;$('#hcarve').classList.remove('on');if(o.lock!==false)player.lock=false;SP=null;if(done)done();},o.hold||1900);}));
  $('#hcarve').classList.add('on');}
function openCarve(o){if(player.lock||xFound(o.p.id))return;player.lock=true;hush();snd.twinkle();const isl=o.p.island,sh=o.p.id==='marmalade'?'cat':o.p.id==='conker'?'bat':['head','grin','cat'][hsh(o.p.id)%3];
  let step=STEP[isl]||1;if(isl==='number'&&typeof tablesOn==='function'){const tb=tablesOn();if(tb&&tb.length)step=pick(tb);}
  carvePuzzle({pts:SHAPES[sh],step,col:pcol(W.area),title:'🎃 Join the dots to carve the pumpkin!',
    say:`A giant pumpkin! Join the dots in order to carve a face.${step>1?` Count in ${step}s!`:''}`,win:'The pumpkin lights up! Something is wriggling inside...',
    done:()=>{snd.pop();confetti(30);setTimeout(()=>{markFound(o);found(o.p,'carve',o);},700);}});}

/* ================= finding a Halloween pup ================= */
function found(p,how,o){const X=GS();if(X.found[p.id])return;X.found[p.id]=Date.now();X.how[p.id]=how;state.stars+=10;W.findT=W.t;W.trail.forEach(t=>W.ag.remove(t));W.trail=[];save();hud();
  const P=player,dx=P.x-o.x,dz=P.z-o.z,d=Math.hypot(dx,dz)||1,g=pup3D(p,p.shiny);add(g,o.x+dx/d*1.9,o.z+dz/d*1.9);g.rotation.y=Math.atan2(-dx,-dz)+PI;g.userData.jump=.8;
  player.cheer=1.3;player.wave=2.4;sfx.jingle();confetti(36);W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});
  const n=nFound(),where={look:'hiding among the pumpkins',door:'behind a trick-or-treat door',carve:'inside a carved pumpkin'}[how]||'';
  card({art:pupBox(hp(p)),h:`You found ${p.name}!`,h3:`🎃 Halloween · ${p.breed} ${typeBadge(p.type)}`,p:FACT[p.id]||p.fact,say:`You found ${p.name}, ${where}! ${FACT[p.id]||''}`,
    btns:[['🍬 Happy Halloween!','green',()=>{W.ag.remove(g);PAL.jump=.8;setTimeout(()=>after(p,n),500);}]]});
  if(window.HSTORY&&HSTORY.onFind)try{HSTORY.onFind(p);}catch(e){}}
function after(p,n){const I=islandOf(p.island);
  if(I&&islN(I)>=NEED&&!GS().bp[I.id]){setTimeout(()=>brave(I),400);return;}
  if(window.HSTORY&&HSTORY.afterFind&&HSTORY.afterFind(p,n))return;
  if(n===all().length){say(`Every single Halloween pup is found! All ${n} of them! Spooktacular, Seb!`);return;}
  const A=W.area,L=areaX(A.id),left=L.filter(q=>!xFound(q.id)).length;
  say(`${n} of ${all().length} Halloween pups found! `+(left?`${left} more ${left>1?'pups':'pup'} hiding in ${A.name}.`:`Every Halloween pup in ${A.name} is found!`)+(I&&!GS().bp[I.id]?` Find ${NEED-islN(I)} more on ${I.name} for a Brave Paw!`:''));}

/* ================= the nine Brave Paws ================= */
const LESSON={blossom:'It is fine to feel scared. Being scared just means you care.',flurry:'Holding a friend\'s paw makes any path less scary.',pearl:'A costume changes how you look, but your kindness still shows through.',
 emberuni:'Take one small step, then another. That is how brave things get done.',tally:'Count your friends when you feel scared, and you will never feel alone.',gizmouni:'Most scary things are just things we do not understand yet, so find out how they work.',
 beaconuni:'If someone looks scared, be the friend who helps.',amberuni:'Things that look scary can turn out to be friendly, like old bones.',nebulauni:'Laughing together is the best way to chase a scary feeling away.'};
function brave(I){const u=I.boss.uni,P=player,X=GS();player.lock=true;hush();
  const a=P.h+.7,x=P.x+Math.sin(a)*4.5,z=P.z+Math.cos(a)*4.5,g=pup3D(u,true);add(g,x,z);g.rotation.y=Math.atan2(P.x-x,P.z-z);g.userData.jump=.9;snd.twinkle();confetti(30);floatS('🐾',x,gy(x,z)+4,z,3);
  W.ticks.push(()=>{if(!g.parent)return true;animPup(g,W.t,false);});const n=nBp()+1,F=pal().name;
  story([{art:`<div class="fitsvg">${critterSVG(hp(u))}</div>`,t:`${u.name} trots up in a witch hat and an orange cape! "You found ${NEED} pups in costume on ${I.name}, and ${F} followed you all the way, even in the dark."`},
    {art:`<div class="fitsvg">${critterSVG(hp(u))}</div><div style="font-size:64px;line-height:1">🐾</div>`,t:`"Here is something to remember, ${F}: ${LESSON[u.id]||'Every friend makes you braver.'}"`},
    {art:`<div class="fitsvg" style="width:170px">${palSVG({bp:n})}</div>`,t:`${u.name} stitches a golden Brave Paw onto ${F}'s sheet. ${n} of 9 Brave Paws!`+(n===9?` ${F} stands up tall: "I'm brave enough now!"`:` ${F} stands a little taller.`)}],
    ()=>{X.bp[I.id]=Date.now();save();W.ag.remove(g);player.lock=false;PAL.jump=1;palRefresh();sfx.fanfare();snd.song(n);confetti(40);hud();
      if(window.HSTORY&&HSTORY.onBrave)try{HSTORY.onBrave(I,n);}catch(e){}
      if(n<9)say(`${n} of 9 Brave Paws! Find ${NEED} Halloween pups on each island to collect them all.`);});}
function uniHome(IS){const B=IS.boss;if(!B||!B.uni||!(G0()&&G0().bp[IS.id]))return;if(W.bossUp===IS.id)return;W.bossUp=IS.id;const u=pup3D(B.uni,true);u.rotation.y=Math.atan2(-B.x,-B.z)+PI;add(u,B.x,B.z);col(B.x,B.z,1.4);
  W.ticks.push(()=>{animPup(u,W.t,false);});W.things.push({x:B.x,z:B.z,r:4,icon:'🦄',label:B.uni.name,act:()=>{sfx.chime();say(`${B.uni.name} says: "${LESSON[B.uni.id]} Happy Halloween, Seb!"`);}});}

/* ================= Seb's little pup in the bedsheet ================= */
const PAL={g:null,x:0,z:0,h:0,jump:0,tail:null,paws:null,step:0};
function pal3D(){const g=grp(),b=grp();g.add(b);const W1='#fafafa';
  mk('sph',W1,.46,.6,.5,0,.66,0,b);const sk=mk('cone',W1,.6,.56,.64,0,.3,-.02,b);sk.rotation.x=0;mk('sph','#f0f0f0',.32,.07,.5,0,.05,-.5,b);
  [-1,1].forEach(s=>{mk('sph','#26232e',.075,.105,.03,s*.15,.82,.45,b);mk('sph','#ff9ec0',.06,.04,.02,s*.27,.66,.42,b);});mk('box','#26232e',.16,.025,.02,0,.62,.48,b);
  [[-.22,.28],[.22,.28],[-.2,-.22],[.2,-.22]].forEach(q=>mk('sph','#f3dcae',.11,.07,.13,q[0],.04,q[1],b));
  const bk=grp();bk.position.set(.52,.42,.12);b.add(bk);pumpkin3D(bk,ORANGE,.32,true);mk('tor','#3a3640',.16,.16,.5,0,.4,0,bk);
  bakeModel(g,'hwpal');
  const tl=grp();tl.position.set(0,.18,-.5);b.add(tl);const tm=new THREE.MeshLambertMaterial({color:'#f3dcae'}),t1=new THREE.Mesh(G.cyl,tm);t1.scale.set(.06,.32,.06);t1.position.set(0,.14,-.05);t1.rotation.x=-.6;tl.add(t1);
  const paws=grp();b.add(paws);g.scale.setScalar(1.05);Object.assign(g.userData,{body:b,tail:tl,paws});g.traverse(o=>{o.frustumCulled=false;});return g;}
let PAWM=null;function palRefresh(){if(!PAL.g)return;const P=PAL.g.userData.paws,n=nBp();while(P.children.length)P.remove(P.children[0]);
  const m=PAWM||(PAWM=new THREE.MeshBasicMaterial({color:'#ffd23f'}));for(let i=0;i<n;i++){const a=-.9+(i%5)*.45,y=.42+Math.floor(i/5)*.18,s=new THREE.Mesh(G.sph,m);s.scale.set(.06,.06,.03);s.position.set(Math.sin(a)*.47,y,Math.cos(a)*.5);P.add(s);}}
function usePal(g){PAL.g=g;PAL.tail=g.userData.tail;if(!g.parent)scene.add(g);palRefresh();}
function palEnter(A){if(!named()){if(PAL.g)PAL.g.visible=false;return;}
  if(!PAL.g)usePal(pal3D());PAL.g.visible=true;const P=player,a=P.h+PI/2;PAL.x=P.x+Math.sin(a)*1.6;PAL.z=P.z+Math.cos(a)*1.6;PAL.h=P.h;palRefresh();
  W.things.push({x:PAL.x,z:PAL.z,r:3.2,icon:'💬',label:pal().name,hpal:1,show:()=>!followers.some(f=>Math.hypot(f.x-player.x,f.z-player.z)<2.3),act:palTalk});
  W.ticks.push(palTick);}
function palHide(){if(PAL.g)PAL.g.visible=false;}
function nearest(){let best=null,bd=1e9;LIVE.forEach(o=>{if(xFound(o.p.id))return;const d=Math.hypot(player.x-o.x,player.z-o.z);if(d<bd){bd=d;best=o;}});return best?{o:best,d:bd}:null;}
function palTick(dt){if(!PAL.g||!on())return true;if(!PAL.g.visible||PAL.script)return;const P=player,t=W.t,u=PAL.g.userData;
  const fx=Math.sin(P.h),fz=Math.cos(P.h),tx=P.x+fz*1.5-fx*.9,tz=P.z-fx*1.5-fz*.9,dx=tx-PAL.x,dz=tz-PAL.z,d=Math.hypot(dx,dz),mv=d>.2;
  if(d>.05){PAL.x+=dx*Math.min(1,dt*3.4);PAL.z+=dz*Math.min(1,dt*3.4);}if(d>26){PAL.x=tx;PAL.z=tz;}
  PAL.h=lerpAng(PAL.h,mv?Math.atan2(dx,dz):P.h,Math.min(1,dt*6));if(PAL.jump>0)PAL.jump-=dt;PAL.step+=mv?dt*10:0;
  const shy=Math.max(0,1-nBp()/4),shiver=shy*Math.sin(t*40)*.03,hop=PAL.jump>0?Math.sin(PAL.jump*PI*1.6)*.7:0;
  PAL.g.position.set(PAL.x+shiver,walkY(PAL.x,PAL.z)+Math.abs(Math.sin(PAL.step))*(mv?.12:0)+hop+(W.area&&W.area.swim?1:0),PAL.z);PAL.g.rotation.y=PAL.h;u.body.rotation.z=mv?Math.sin(PAL.step)*.08:Math.sin(t*1.5)*.03;
  const th=W.things.find(q=>q.hpal);if(th){th.x=PAL.x;th.z=PAL.z;}
  /* warmer and colder: the tail wags faster near a hiding pup */
  const n=nearest(),k=n?Math.max(0,Math.min(1,1-n.d/45)):0;u.tail.rotation.y=Math.sin(t*(4+18*k))*.7;
  if(n&&n.d<10&&t-(PAL.dingT||0)>3.4&&!P.lock&&!ovOpen()){PAL.dingT=t;sfx.yip(1.5);}
  if(t-(PAL.factT||0)>140&&!P.lock&&!ovOpen()&&t-W.msgT>20){PAL.factT=t;say(`${pal().name} says: "${pick(PFACT)}"`);}}
const PFACT=['Did you know? Pumpkins are fruit, because they have seeds inside!','Did you know? Bats find their food in the dark by listening to echoes.','Did you know? Spiders have eight legs, so they are not insects.',
 'Being scared is your body trying to keep you safe. Then you can be brave anyway!','Did you know? Owls fly so quietly because their feathers have soft, fringed edges.','Did you know? Hedgehogs sleep right through the winter. That is called hibernating.'];
function dir(o){const P=player,a=Math.atan2(o.x-P.x,o.z-P.z),r=angDiff(a,W.camYaw),d=Math.hypot(o.x-P.x,o.z-P.z);
  const w=Math.abs(r)<.6?'straight ahead':Math.abs(r)>2.4?'behind you':r>0?'over to your left':'over to your right';return `${w}, ${d<12?'really close':d<30?'not far away':'a long way off'}`;}
function palTalk(){if(player.lock)return;snd.boo();PAL.jump=.6;const F=pal().name,n=nearest(),A=W.area;
  if(n){const o=n.o,w=dir(o);say(o.k==='look'?`${F} says: "I saw a pumpkin wiggle, ${w}!"`:o.k==='carve'?`${F} says: "There's a giant pumpkin with candles, ${w}!"`:`${F} says: "A trail of sweets! It goes ${w}. Let's follow it!"`);return;}
  const I=A.island&&islandOf(A.island),more=I?I.areas.filter(a=>areaX(a.id).some(p=>!xFound(p.id))):[];
  if(more.length)say(`${F} says: "Every pup here is found! Shall we try ${more[0].name}?"`);
  else if(I)say(`${F} says: "Every Halloween pup on ${I.name} is found! Let's try another island."`);
  else{const left=ISLANDS.find(I2=>islX(I2).some(p=>!xFound(p.id)));say(left?`${F} says: "Let's look for pups in costume on ${left.name}!"`:`${F} says: "Happy Halloween, Seb!"`);}}
/* a picture of the little pup in the bedsheet, for cards and story scenes */
function palSVG(o){o=o||{};const K=INK,n=Math.min(9,o.bp==null?nBp():o.bp);let paws='';
  for(let i=0;i<n;i++){const r=Math.floor(i/5),x=(r?80:68)+(i%5)*16,y=134+r*18;paws+=HL.paw(x,y,'#ffd23f',1).replace(/fill="#ffd23f"/g,`fill="#ffd23f" stroke="${K}" stroke-width="1.2"`);}
  return `<svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">${o.scared?'<path d="M30 70 q-8 6 0 12 M24 90 q-8 6 0 12 M170 70 q8 6 0 12 M176 90 q8 6 0 12" stroke="#8a8fa8" stroke-width="3" fill="none" stroke-linecap="round"/>':''}`+
   `<path d="M150 168 q30 -4 30 -34" stroke="${K}" stroke-width="12" fill="none" stroke-linecap="round"/><path d="M150 168 q30 -4 30 -34" stroke="#f3dcae" stroke-width="7" fill="none" stroke-linecap="round"/>`+
   [62,86,112,136].map(x=>`<ellipse cx="${x}" cy="178" rx="11" ry="8" fill="#f3dcae" stroke="${K}" stroke-width="3"/>`).join('')+
   `<path d="M52 172 Q40 120 54 76 Q66 28 100 26 Q134 28 146 76 Q160 120 150 172 Q138 162 126 174 Q114 162 100 174 Q86 162 74 174 Q62 162 52 172 Z" fill="#fafafa" stroke="${K}" stroke-width="4"/>`+
   `<path d="M66 92 Q72 120 70 150" stroke="#e4e6ee" stroke-width="3" fill="none"/><path d="M134 92 Q128 120 130 150" stroke="#e4e6ee" stroke-width="3" fill="none"/>`+
   `<ellipse cx="84" cy="72" rx="11" ry="15" fill="#26232e"/><ellipse cx="116" cy="72" rx="11" ry="15" fill="#26232e"/><circle cx="87" cy="68" r="3.5" fill="#fff"/><circle cx="119" cy="68" r="3.5" fill="#fff"/>`+
   `<path d="M88 100 Q100 ${o.scared?96:110} 112 100" stroke="#26232e" stroke-width="3.5" fill="none" stroke-linecap="round"/><circle cx="70" cy="94" r="6" fill="#ff9ec0" opacity=".7"/><circle cx="130" cy="94" r="6" fill="#ff9ec0" opacity=".7"/>`+
   paws+`<g transform="translate(20 120)">${HL.pumpkinSVG(14,30,18,ORANGE,true)}<path d="M-2 22 Q14 2 30 22" stroke="#3a3640" stroke-width="3" fill="none"/></g></svg>`;}

/* ================= the opening ================= */
const SUG=['Wisp','Button','Peanut','Mallow','Socks','Squeak'];
const cleanName=s=>{s=String(s||'').replace(/[^A-Za-z0-9 '\-!]/g,'').replace(/\s+/g,' ').trim().slice(0,18);return s?s.charAt(0).toUpperCase()+s.slice(1):'';};
const big=e=>`<div style="font-size:100px;line-height:1">${e}</div>`,psv=(w,o)=>`<div class="fitsvg" style="width:${w||170}px">${palSVG(o)}</div>`;
function intro(){const X=GS();X.inv=1;save();player.lock=true;hush();
  story([{art:big('🎃🏡'),t:'Dusk falls on Pawprint Village, and Granny Paws lights the pumpkins. Tonight is the Pumpkin Parade!'},
    {art:`<div class="fitsvg" style="width:150px">${grannySVG()}</div>`,t:'"Every pup on the islands has made a costume," says Granny Paws. "And before the parade they are playing the Big Costume Hide-and-Seek! They are hiding all over the islands, and they want you to find them."'},
    {art:big('🎃'),t:'Then, from behind the biggest pumpkin by the fountain, comes a tiny voice: "boo?"'}],
    ()=>{state.season='hw';save();XM.rebuildPack();Object.values(window.SEASONS).forEach(S=>{if(S.id!=='hw'&&S.hide)try{S.hide();}catch(e){}});fadeTo(()=>{enterArea('village',[-5,17,PI]);arrive();},['🎃','Halloween']);});}
function arrive(){const P=player,x=1.5,z=9;player.lock=true;W.camYaw=Math.atan2(x-P.x,z-P.z);P.h=W.camYaw;const D=pal3D();usePal(D);D.visible=true;PAL.script=true;PAL.x=x;PAL.z=z;
  D.position.set(x,walkY(x,z),z);D.rotation.y=Math.atan2(P.x-x,P.z-z);D.scale.setScalar(.01);let t=0;snd.boo();
  W.ticks.push(dt=>{t+=dt;const k=Math.min(1,t/1.2);D.scale.setScalar(1.05*(.01+.99*k));D.position.x=x+Math.sin(t*30)*.03*(1-Math.min(1,t/3));if(t>2.4){meet();return true;}});}
function meet(){story([{art:psv(190,{bp:0,scared:1}),t:'It\'s a little puppy in a bedsheet costume, much too big, with two eye holes and four paws poking out at the bottom!'},
    {art:psv(190,{bp:0,scared:1}),t:'"On my way to the parade, a big furry MONSTER jumped out and shouted BOO!" the little pup whispers. "I ran and hid. And now it\'s getting dark, and I\'m a bit scared."'}],()=>nameCard(()=>scatter()));}
function nameCard(done){sfx.chime();
  card({art:psv(160,{bp:0}),h:'Name the little pup!',p:`The little pup in the bedsheet doesn't have a name yet. What would you like to call it?<input id="hName" maxlength="18" autocomplete="off" placeholder="Type a name..."><span class="xSug">${SUG.map(s=>`<button class="opt">${s}</button>`).join('')}</span><span class="xSex"><button class="opt on" data-g="0">👦 Boy</button><button class="opt" data-g="1">👧 Girl</button></span>`,
    say:'The little pup in the bedsheet does not have a name yet. Type a name, or pick one. Is your pup a boy or a girl?',
    btns:[['✓ That\'s the name!','green',()=>{const n=cleanName($('#hName').value)||pick(SUG),g=!!+(document.querySelector('#celeCard .xSex .on')||{dataset:{g:0}}).dataset.g;
      GS().pal={name:n,girl:g,at:Date.now()};save();sfx.fanfare();confetti(50);player.cheer=1.6;if(done)done();}]]});
  const inp=$('#hName');['keydown','keyup','keypress'].forEach(ev=>inp.addEventListener(ev,e=>e.stopPropagation()));
  document.querySelectorAll('#celeCard .xSug .opt').forEach(b=>tap(b,()=>{inp.value=b.textContent;sfx.boop();speak(b.textContent);}));
  document.querySelectorAll('#celeCard .xSex .opt').forEach(b=>tap(b,()=>{document.querySelectorAll('#celeCard .xSex .opt').forEach(q=>q.classList.toggle('on',q===b));sfx.boop();}));}
function scatter(){const F=pal().name;
  story([{art:psv(170,{bp:0}),t:`"I'm ${F}!" ${F} holds ${his()} pumpkin bucket tight. Seb promises to find the pups, and to keep ${him()} company in the dark. ${F}'s tail wags faster under the sheet when a hidden pup is near!`},
    {art:big('🎃🚪🍬'),t:'The pups are hiding among the pumpkins (watch for one that wiggles!), behind little trick-or-treat doors at the end of a trail of sweets, and inside giant pumpkins that you can carve.'},
    {art:psv(150,{bp:0})+big('🦄'),t:`Find 6 pups on an island, and its unicorn will give ${F} a Brave Paw. Collect all nine, and ${F} will be brave enough to find that monster!`}],
    ()=>{const X=GS();X.intro=Date.now();save();player.lock=false;PAL.script=false;palEnter(W.area);hud();say(`Let's find the pups in costume! Take the ferry to Meadow Island, or any island you like. ${F} will come too!`);
      if(window.HSTORY&&HSTORY.onIntro)try{HSTORY.onIntro();}catch(e){}});}
/* the invitation, once Halloween is open (earlier seasons' invitations go first) */
const _ea3=enterArea;enterArea=function(id,pos,msg){_ea3.apply(this,arguments);if(state.season||id!=='village'||!opened()||!state.intro)return;
  if(Object.values(window.SEASONS).some(S=>S.order<3&&S.opened()&&!(state.sx&&state.sx[S.id]&&state.sx[S.id].inv)))return;const X=G0();if(X&&(X.inv||X.pal))return;
  setTimeout(()=>{if(cur!=='world'||ovOpen()||player.lock||state.season||!W.area||W.area.id!=='village')return;GS().inv=1;save();invite();},1900);};
function invite(){player.lock=true;sfx.chime();
  card({art:big('🎃✨'),h:'🎃 Halloween is here!',p:'Dusk is falling on Pawprint Village, the pumpkins are glowing, and every pup is in costume for the Pumpkin Parade. Shall we go and see?',
    btns:[['🎃 Yes, let\'s go!','green',()=>{player.lock=false;intro();}],['Not now','white',()=>{player.lock=false;say('Shake the Season Globe in the plaza whenever you want to play Halloween!');}]]});}
function fromGlow(){if(named()){XM.setSeason('hw');return;}intro();}
/* the grown-ups switch */
{const base=openSettings;openSettings=function(){base.apply(this,arguments);const c=$('#setCard');if(!c)return;const S=state.set;
  const row=document.createElement('div');row.className='srow';row.innerHTML=`🎃 Open Halloween early<div class="opts"><button class="opt${S.hwOpen?'':' on'}" data-x="0">Off</button><button class="opt${S.hwOpen?' on':''}" data-x="1">On</button></div>`;
  const note=document.createElement('div');note.className='snote';note.textContent=glowDone()?'Halloween is already open, because Night Glow is finished. Shake the Season Globe in the village plaza to switch seasons.':'Halloween opens after Night Glow is finished. Turn this on to open it now: an invitation arrives the next time Seb is in the village.';
  const anchor=[...c.querySelectorAll('.srow')].find(r=>/Backup code/.test(r.textContent))||c.querySelector('.btns');c.insertBefore(note,anchor);c.insertBefore(row,note);
  row.querySelectorAll('.opt').forEach(b=>tap(b,()=>{S.hwOpen=b.dataset.x==='1';if(!S.hwOpen&&!glowDone()&&state.season==='hw'){state.season=null;XM.rebuildPack();palHide();openSettings.dirty='season';}save();sfx.boop();const d=openSettings.dirty;openSettings();if(d)openSettings.dirty=d;}));};}

/* ================= the Pumpkin Board (the Season Calendar for Halloween) ================= */
function board(){if(player.lock)return;sfx.chime();const n=nFound(),X=G0()||{bp:{}};
  const rows=ISLANDS.map(I=>`<div class="hbRow"><b>${I.icon}</b>${islX(I).map(p=>`<i class="${xFound(p.id)?'lit':''}">●</i>`).join('')}<em>${X.bp&&X.bp[I.id]?'🐾':''}</em></div>`).join('')+
    `<div class="hbRow"><b>🌟</b>${[HP.marmalade,HP.conker].map(p=>`<i class="${xFound(p.id)?'lit':''}">●</i>`).join('')}<em></em></div>`;
  card({cls:'hboard',h:`🎃 The Pumpkin Board: ${n} of ${all().length}`,p:`A pumpkin lights up for every Halloween pup you find. 🐾 means that island's Brave Paw is earned.<div class="hbGrid">${rows}</div>`,
    say:`${n} of ${all().length} Halloween pups found, and ${nBp()} of 9 Brave Paws.`,btns:[['OK','green']]});}

/* ================= planning hiding spots (offline for hw_spots.js, and as a fallback) ================= */
function plan(A){const out={spots:{}};const L=areaX(A.id);if(!L.length)return out;const Gd=XM.grid(A,1),R=seed(hsh(A.id)+37),chosen=[];
  const avoid=[];(W.exits||[]).forEach(e=>avoid.push([e.x,e.z,9]));W.things.forEach(t=>{if(!t.hpal&&!t.gfly&&!t.xdeer)avoid.push([t.x,t.z,4.5]);});if(A.start)avoid.push([A.start[0],A.start[1],9]);
  L.forEach(p=>{if(p.spot)avoid.push([p.spot.x,p.spot.z,5]);if(p.tag)avoid.push([p.tag.x,p.tag.z,5]);
    [(window.XSPOTS||{})[p.id],(window.GSPOTS||{})[p.id]].forEach(xs=>{if(!xs)return;if(xs.x!=null)avoid.push([xs.x,xs.z,6]);['b','c'].forEach(k=>{if(xs[k])avoid.push([xs[k][0],xs[k][1],5]);});});});
  const okAt=(p,sep)=>{if(avoid.some(a=>Math.hypot(p[0]-a[0],p[1]-a[1])<a[2]))return false;if(chosen.some(q=>Math.hypot(p[0]-q[0],p[1]-q[1])<sep))return false;return true;};
  const st=A.start?Gd.snap(A.start[0],A.start[1],1):Gd.snap(0,0,1);if(st<0)return out;const B0=Gd.bfs(st);
  const best=(B,mc,sep,lo,hi,ideal)=>{let bk=-1,bs=-1e9;for(let k=0;k<Gd.N;k++){if(Gd.clr[k]<mc||B.D[k]>=1e9||B0.D[k]>=1e9)continue;const d=B.D[k];if(d<lo||d>hi)continue;const p=Gd.xz(k);if(!okAt(p,sep))continue;
      const sp=chosen.length?Math.min(30,Math.min(...chosen.map(q=>Math.hypot(p[0]-q[0],p[1]-q[1])))):30,s=sp*.6-Math.abs(d-ideal)*.25+R()*6;if(s>bs){bs=s;bk=k;}}return bk;};
  L.forEach(p=>{const k=kindOf(p);
    if(k==='door'){let a=p.spot?Gd.snap(p.spot.x,p.spot.z,1):-1;if(a<0||B0.D[a]>=1e9)a=st;const Ba=Gd.bfs(a),b=best(Ba,2,10,15,40,26);if(b<0)return;chosen.push(Gd.xz(b));
      const Bb=Gd.bfs(b);let c2=-1,bs=-1e9;const pa=Gd.xz(a);for(let q=0;q<Gd.N;q++){if(Gd.clr[q]<2||Bb.D[q]>=1e9)continue;const d=Bb.D[q];if(d<14||d>34)continue;const pq=Gd.xz(q);if(Math.hypot(pq[0]-pa[0],pq[1]-pa[1])<10||!okAt(pq,10))continue;const s=-Math.abs(d-22)*.3+R()*6;if(s>bs){bs=s;c2=q;}}
      if(c2<0)return;chosen.push(Gd.xz(c2));const P2=k2=>Gd.xz(k2).map(v=>+v.toFixed(1));
      out.spots[p.id]={k:'door',a:P2(a),b:P2(b),c:P2(c2),ab:Gd.path(Ba,b),bc:Gd.path(Bb,c2)};}
    else{const kk=best(B0,k==='look'?3:3,12,12,140,40);if(kk<0)return;const q=Gd.xz(kk);chosen.push(q);out.spots[p.id]={k,x:+q[0].toFixed(1),z:+q[1].toFixed(1)};}});
  return out;}

/* ================= look and API ================= */
const css=document.createElement('style');css.textContent=`
#hpick,#hcarve{z-index:60}#hpCard{max-width:960px;width:94%;background:#fff3e6}#hpRow{display:flex;flex-wrap:wrap;justify-content:center;gap:14px;margin:12px 0}
#hpRow .hpr{background:#4b3a7a;border:4px solid #26232e;border-radius:22px;padding:6px;width:150px;height:160px;display:flex;align-items:flex-end;justify-content:center;cursor:pointer;transform-origin:50% 90%}
#hpRow .hpr.wig svg{animation:hWig 3.2s ease-in-out infinite;transform-origin:50% 90%}#hpRow .hpr .htail{animation:hTail .5s ease-in-out infinite alternate;transform-origin:86px 92px}
@keyframes hWig{0%,72%,100%{transform:rotate(0)}76%{transform:rotate(-9deg)}80%{transform:rotate(8deg)}84%{transform:rotate(-6deg)}88%{transform:rotate(4deg)}92%{transform:rotate(0)}}
@keyframes hTail{from{transform:rotate(-10deg)}to{transform:rotate(14deg)}}
#hpRow .hpr.hint{animation:xhint .5s ease-in-out infinite;box-shadow:0 0 0 6px #ffd23f}#hpRow .hpr.open{background:#5e4a92}
#hpRow .hpr .hsur{font-size:70px;line-height:1;animation:xpop .5s;color:#fff;display:flex;flex-direction:column;align-items:center}#hpRow .hpr .hsur small{font-size:20px;font-weight:900}
#hpRow .hpr .hpup{width:130px;animation:xpop .6s}#hpRow .hpr .hpup svg{width:100%;height:auto}#hpMsg,#hcMsg{min-height:34px;font-size:26px;font-weight:800}
#hcCard{max-width:980px;width:96%;background:#fff0e0}#hcBox svg{width:620px;max-width:100%;height:auto;display:block;margin:4px auto;border-radius:18px}#hcCard h2{margin:0}#hcCard{padding-top:14px;padding-bottom:12px}
#hcSvg .hcd{cursor:pointer}#hcSvg .hcd.next .hcg{opacity:1;animation:hcPulse 1s ease-in-out infinite;transform-box:fill-box;transform-origin:center}#hcSvg .hcd.done .hcg{opacity:.9;fill:#ffd23f}
#hcSvg .hcd.nope{animation:hcNo .4s}#hcSvg .hclit{opacity:0;transition:opacity 1s}#hcSvg.win .hclit{opacity:.95;filter:drop-shadow(0 0 2px #ffd23f)}#hcPic{transition:opacity 1s}
@keyframes hcPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.6)}}@keyframes hcNo{0%,100%{transform:translateX(0)}30%{transform:translateX(-1px)}60%{transform:translateX(1px)}}
#hName{display:block;width:420px;margin:12px auto 8px;font-size:30px;font-weight:900;padding:10px 16px;border:4px solid #26232e;border-radius:18px;text-align:center;font-family:inherit;color:#26232e}
.hbGrid{margin-top:8px}.hbRow{display:flex;align-items:center;gap:3px;justify-content:center;margin:2px 0}.hbRow b{width:34px;font-size:24px}.hbRow em{width:28px;font-style:normal}
.hbRow i{width:22px;height:22px;font-style:normal;font-size:20px;line-height:22px;color:#6a5a8a;display:inline-block}.hbRow i.lit{color:#ff8a1a;text-shadow:0 0 8px #ffb020}`;
document.head.appendChild(css);
window.SEASONS.hw={id:'hw',order:3,name:'Halloween',short:'Halloween',icon:'🎃',tag:'🎃',card:['🎃','Halloween cards'],lockShort:'After Night Glow',
  on,opened,named,nFound,total:()=>all().length,invite,hide:palHide,
  book:{xp:hp,found:xFound,islX,islN,fact:id=>FACT[id],tag:'🎃',word:'Halloween',isl:I=>`${I.name} at Halloween`}};
const HW=window.HW={on,opened,named,GS,G0,all,gpup,xFound,nFound,islN,islX,areaX,nBp,pal,he,his,him,He,found,palSVG,pal3D,usePal,PAL,snd,plan,board,intro,fromGlow,invite,
  carvePuzzle,SHAPES,pumpkin3D,door3D,sweets,glowMat,glowTex,palEnter,palHide,palRefresh,LIVE:()=>LIVE,NEED,LESSON,kindOf,noSpots:false,BRAVE,mixC,pcol};
})();
