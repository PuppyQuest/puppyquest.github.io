/* ================================================================
   Christmas Snow: the Christmas looks (25 Nov 2026, claude/christmas-snow-design.md)
   - a Christmas outfit for every pup (each island's own kit, no two the same on an island),
     shown on the Christmas cards (p.xmas) and on every 3D pup while Christmas Snow is on;
   - nine full Christmas costumes (one pup per island) and the Spa's Christmas jumper;
   - a new winter fact for every pup, and the two secret season pups, Holly and Tinsel.
   Hooks: window.SEASONSPEC (read by pupstyle.js specOf), new pieces in PSTYLE's
   HAT/BODY/NECK and H3/N3/B3, cos2D/cos3D/form2D/form3D/formLook wrappers.
   ================================================================ */
(function(){
const PS=window.PSTYLE,K=INK,PI=Math.PI;
const ol=w=>`stroke="${K}" stroke-width="${w||2.6}" stroke-linejoin="round" stroke-linecap="round"`;
const st=(c,w,o)=>`fill="none" stroke="${c}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" opacity="${o==null?1:o}"`;
const RED='#d9363e',GRN='#2f9a54',WHT='#ffffff',GLD='#ffd23f',NAVY='#2b4a8a',PINK='#ff7fb8',PLUM='#8a2f5a',CREAM='#f3ead8';
const COLS=[RED,GRN,NAVY,CREAM,PLUM,PINK];

/* ---------------- the two secret season pups ---------------- */
const XPUPS={
 holly:{id:'holly',name:'Holly',breed:'Finnish Lapphund',area:'village',island:'village',type:'snow',pitch:1.1,season:'xmas',
   look:{fur:'#3a2a24',ear:'#2a1e1a',ears:'pointy',fluffy:true,muzzle:'#e8c08a',belly:'#d9b07a',paw:'#e8c08a',tail:'curl',collar:RED,acc:[],brows:'#e8c08a'},
   fact:'Finnish Lapphunds have herded reindeer in Lapland for hundreds of years, and their thick double coat keeps them warm all through the Arctic winter.',
   hint:'Holly loves the Christmas market.'},
 tinsel:{id:'tinsel',name:'Tinsel',breed:'Volpino Italiano',area:'factory',island:'gadget',type:'spark',pitch:1.3,season:'xmas',
   look:{fur:'#fbfbf7',ear:'#f2efe6',ears:'pointy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',tail:'curl',collar:GLD,acc:[],scale:.9},
   fact:'Volpino Italiano means "little Italian fox". It is a rare, fluffy white spitz dog that barks to tell its family when someone is coming.',
   hint:'Tinsel is somewhere in the maze of giant presents.'}};
if(window.CARDS&&CARDS.BREEDS&&!CARDS.BREEDS['Volpino Italiano'])CARDS.BREEDS['Volpino Italiano']={sz:'s',spd:7,brn:7,cud:8,brv:7,g:'snow'};
if(PS&&PS.COAT){PS.COAT['Volpino Italiano']='double';PS.COAT['Finnish Lapphund']='double';}

/* ---------------- winter facts (checked 25 Nov 2026) ---------------- */
const FACT={
 buttercup:'Labradoodles were first bred in Australia to be guide dogs, and their curly coats keep them cosy on snowy walks.',
 barley:'Border Terriers have a wiry top coat over a soft under coat, like wearing a raincoat over a woolly jumper.',
 honey:'Cavalier King Charles Spaniels love a cosy lap more than anything, so on a cold winter\'s night they are the perfect cuddle buddy.',
 cali:'Border Collies herd sheep even through winter snow, and one called Chaser learned the names of more than a thousand toys!',
 bumble:'Bulldogs have short noses, so they get chilly and puffed out quickly. A warm coat and short winter walks suit them best.',
 poppy:'Papillon means butterfly in French, because their big fringed ears look like butterfly wings, even when they are dusted with snowflakes.',
 hazel:'Basset Hounds have such short legs that deep snow comes right up to their tummies! Their long ears help sweep smells up to their noses.',
 willow:'Weimaraners have a short, sleek coat with no warm under coat, so they like a snug dog coat on frosty days.',
 lily:'Maltese pups have long, silky white hair but no fluffy under coat, so they feel the cold and love a cosy jumper.',
 dash:'Springer Spaniels got their name because they "spring" birds out of bushes. In winter they love bounding through snowdrifts!',
 acorn:'Miniature Schnauzers have bushy eyebrows and beards, which can collect little balls of snow on a winter walk.',
 bluebell:'Despite their name, Australian Shepherds were mostly bred in America. Their thick double coat keeps them warm in the snow.',
 fern:'Westies come from the Scottish Highlands, where winters are cold and windy, and their white double coat keeps them snug.',
 bobble:'Japanese Spitz have a thick white double coat, like a fluffy snowsuit, and they love playing in fresh snow.',
 teddy:'Leonbergers have webbed feet and a thick waterproof coat, so they are happy splashing through slush and snow.',
 muffin:'Tibetan Terriers have big, flat feet like snowshoes, to help them walk on snow in the Himalayan mountains.',
 biscuit:'Swedish Vallhunds were herding cattle in snowy Sweden more than a thousand years ago, in the time of the Vikings.',
 juniper:'The Eurasier is a mix of three breeds: the Chow Chow, the Wolfspitz and the Samoyed, so it has a very warm fluffy coat.',
 sledge:'Norwegian Elkhounds are one of the oldest dog breeds in Europe, and they have tracked moose through snowy Norwegian forests for thousands of years.',
 snowdrop:'Despite its name, the American Eskimo Dog comes from German spitz dogs, and it once did tricks in travelling circuses!',
 fjord:'The Icelandic Sheepdog came to Iceland with the Vikings, and it is Iceland\'s only native dog breed.',
 yeti:'Kuvasz pups are white so that shepherds could tell them apart from wolves, even in the snowy mountains of Hungary.',
 pinecone:'Keeshonden have dark "spectacles" round their eyes, and a thick ruff of fur round the neck like a cosy scarf.',
 glacier:'Alaskan Klee Kai look like small huskies, and like huskies they can curl up with their fluffy tail over their nose to keep it warm.',
 twinkle:'Lhasa Apsos come from Tibet, high in the snowy Himalayas, where they were watchdogs in mountain monasteries.',
 crystal:'White Swiss Shepherds have a thick white double coat that sheds so much in spring, it can look as if it is snowing indoors!',
 ripple:'Spanish Water Dogs have curly coats that can grow into cords, and they helped fishermen bring in their nets.',
 sandy:'Tollers come from Nova Scotia in Canada, where winters are icy, and they have a water-repellent double coat and webbed feet.',
 kelp:'Lagotto Romagnolos are famous for sniffing out truffles, a tasty fungus that grows underground in autumn and winter.',
 finn:'Flat-coated Retrievers are called the Peter Pan of dogs, because they stay playful like puppies even when they are grown up.',
 scallop:'Boston Terriers have a black and white coat that looks like a smart tuxedo, perfect for a fancy Christmas party!',
 starla:'A Cavapoo is a cross between a Cavalier King Charles Spaniel and a Poodle, so it often has a soft, wavy coat.',
 anchor:'One idea is that Boxers got their name because they play by standing up and batting with their front paws, like a boxer!',
 barnacle:'Otterhounds have a shaggy, oily double coat and big webbed feet, so cold water does not bother them one bit.',
 gulliver:'Irish Water Spaniels have a curly coat that keeps out cold water, and a smooth "rat tail" with hardly any curls on it.',
 inky:'Curly-coated Retrievers have a coat of tight little curls that stops icy water reaching their skin.',
 marina:'Landseers are black and white Newfoundland dogs, named after the artist Edwin Landseer, who loved to paint them.',
 puffin:'Boykin Spaniels were bred in South Carolina to be small enough to fit in little boats, and they are that state\'s official dog.',
 opal:'Havanese come from sunny Cuba, where their silky coat works like a sunshade. On snowy days they need a cosy jumper!',
 chilli:'Shiba Inus have a thick double coat for cold Japanese winters, and some make a funny loud noise called the Shiba scream!',
 dumpling:'Pekingese were the palace dogs of Chinese emperors, and their thick mane of fur makes them look like little lions.',
 bamboo:'Chow Chows have blue-black tongues, and a thick fluffy coat that keeps them warm in the coldest winters.',
 kite:'Shikoku dogs come from the mountains of Japan, where they hunted wild boar in the deep winter forests.',
 frosty:'Kishu dogs are almost always white, and in Japan they are called a "natural monument", a living treasure.',
 noodle:'Shar Peis have so many wrinkles that the puppies look as if they are wearing a coat three sizes too big!',
 blaze:'Akitas have webbed toes, which help them walk on deep snow without sinking.',
 ash:'Kai Kens have a brindle coat with stripes, a bit like a tiger, which helps them hide in the mountain forests of Japan.',
 thunder:'Thai Ridgebacks come from warm Thailand and have a short coat, so on snowy days they would rather stay by the fire!',
 zippy:'Shih Tzu means "little lion" in Chinese. Their long silky hair keeps growing, a bit like human hair.',
 phoenix:'Many Chinese Crested pups have hardly any fur, just a fluffy crest on their heads, so they really need a warm coat in winter!',
 ginger:'Japanese Chins sometimes spin round in circles when they are happy. It is called the Chin spin!',
 glimmer:'Samoyeds pulled sledges in snowy Siberia, and the corners of their mouths turn up, so they always look as if they are smiling.',
 digit:'Dalmatian puppies are born pure white, and their spots appear when they are a few weeks old.',
 dot:'Bichon Frise means "curly lap dog" in French, and their fluffy white coat looks like a snowball!',
 doodle:'Poodles were first water dogs, and their fancy haircut kept their joints and chest warm in cold water.',
 zero:'Great Danes are one of the tallest dog breeds. A big one standing on its back legs can be taller than a grown-up!',
 ruler:'Dachshund means "badger dog" in German. Their short legs mean snow can tickle their tummies!',
 paddle:'Golden Retrievers were first bred in the Highlands of Scotland, and their water-repellent coat keeps them warm on chilly swims.',
 cube:'Bernese Mountain Dogs pulled little carts of milk and cheese in the snowy Swiss Alps.',
 prism:'Whippets have thin skin and very short fur, so they feel the cold and love wearing a cosy coat in winter.',
 pretzel:'A Beagle\'s nose has about 220 million scent sensors, so it could sniff out a mince pie from a long way away!',
 pie:'An old Welsh legend says fairies rode on Corgis, and the markings on their backs are where the fairy saddles went!',
 plus:'A group of Pugs is called a grumble! Their short noses mean they can snore very loudly.',
 seven:'Jack Russell Terriers are named after the Reverend John Russell, who bred them in Devon about 200 years ago.',
 infinity:'Bedlington Terriers look like little lambs, with a soft, woolly coat and a fluffy topknot on their heads.',
 sprocket:'Wire Fox Terriers have a crinkly wiry coat that helps keep out the wind and rain on winter walks.',
 widget:'Chihuahuas are the smallest dog breed in the world, and they shiver to keep warm, so they love a tiny Christmas jumper.',
 dynamo:'Basenjis do not bark. Instead they make a sound like a yodel, called a barroo!',
 pixel:'Pomeranians are tiny, but they come from big spitz sled dogs of the snowy north.',
 turbo:'Vizslas are called Velcro dogs, because they like to stick right next to their people, which is extra cosy in winter!',
 coil:'Puli pups have a coat of long cords, like a mop, which keeps them warm and dry in wind and snow.',
 zap:'Yorkshire Terriers once caught rats in the mills of the north of England, and their hair is a lot like human hair.',
 fuse:'Brussels Griffons come from Belgium, where they were once kept in stables to catch rats.',
 cog:'Cairn Terriers come from the Scottish Highlands, where they dug in piles of stones called cairns. Their shaggy coat is great for windy winters.',
 nano:'Affenpinscher means "monkey terrier" in German, because of its funny monkey-like face.',
 rivet:'Airedales are the biggest of all the terriers, and they are called the King of Terriers.',
 spanner:'French Bulldogs have big bat-like ears and are not good swimmers, so they prefer cosy cuddles to icy puddles.',
 chrome:'Kerry Blue Terrier puppies are born black, and their coat slowly turns blue-grey as they grow up.',
 siren:'Australian Cattle Dog puppies are born white, and their colours come through as they grow.',
 hydrant:'Norfolk Terriers are among the smallest working terriers, with a wiry, weatherproof coat for chilly English winters.',
 buoy:'Newfoundlands are famous water rescue dogs, with webbed feet and a thick oily coat for icy seas.',
 skipper:'Portuguese Water Dogs once swam messages between fishing boats, and two of them lived at the White House!',
 patch:'Scottish Terriers have a thick wiry coat and a beard, and they are brave little dogs from the Highlands of Scotland.',
 plaster:'Welsh Terriers are one of the oldest terrier breeds in Britain, with a wiry coat for wet Welsh winters.',
 flash:'German Shorthaired Pointers have webbed feet and are brilliant swimmers, and they can work in water, woods and snow.',
 gull:'Coton means cotton in French, because their white fur feels as soft as cotton wool, like fresh snow!',
 scout:'A Bloodhound can follow a smell trail that is days old, even across snow.',
 ranger:'Belgian Malinois are super clever working dogs that help police officers and search and rescue teams.',
 ladder:'Irish Wolfhounds are the tallest dog breed of all, but they are known as gentle giants.',
 rocky:'Rottweilers once pulled carts of meat to market in the German town of Rottweil.',
 medal:'Saint Bernards rescued travellers lost in the snow on the Great St Bernard Pass in the Swiss Alps. One called Barry saved more than 40 people!',
 fossil:'Plott Hounds are the state dog of North Carolina, and they have a brindle coat with stripes.',
 digger:'The Mudi is a rare herding dog from Hungary, with a wavy coat and a clever, busy brain.',
 cycad:'Bergamascos have a coat of flat felted mats called flocks, which keep them warm in the snowy Italian Alps.',
 rex:'The Dogue de Bordeaux has one of the biggest heads of any dog, for the size of its body.',
 ammo:'Norwegian Lundehunds have six toes on each foot, to help them climb icy cliffs looking for puffins!',
 dusty:'Canaan Dogs are an ancient breed from the deserts of Israel, so snowy winters are quite new to them!',
 mossy:'A Komondor\'s white corded coat can weigh as much as a big bag of potatoes, and it keeps it warm in freezing winters.',
 bayou:'Catahoula Leopard Dogs often have pale blue "glass eyes", or even one eye of each colour!',
 flint:'Xoloitzcuintli pups come from Mexico. Some are hairless, so on a cold day they love a cosy blanket.',
 tusk:'Neapolitan Mastiffs have lots of loose, wrinkly skin, and they come from Naples in Italy.',
 ridge:'Rhodesian Ridgebacks have a stripe of fur along the back that grows the opposite way to the rest of their coat.',
 jura:'Pharaoh Hounds "blush" when they are happy: their nose and ears turn a rosy pink!',
 nugget:'The Cirneco dell\'Etna comes from around Mount Etna, a volcano in Sicily that often has snow on top in winter!',
 luna:'Bolognese pups come from the city of Bologna in Italy, and their fluffy white coat is like a little cloud of snow.',
 sputnik:'Schipperkes guarded canal boats in Belgium, and their name means "little boatman" in Flemish.',
 rusty:'Redbone Coonhounds have a shiny red coat and a very loud, musical howl called a bay.',
 rover:'Australian Kelpies can run along the backs of sheep to get to the front of the flock!',
 cosmo:'Borzois are Russian sighthounds with a long silky coat, made for racing across snowy fields.',
 astra:'Silken Windhounds are a young breed, first bred in America in the 1980s, with a soft, silky coat.',
 saturn:'Clumber Spaniels are the heaviest of the spaniels, and they are named after Clumber Park in England.',
 halley:'Löwchen means "little lion" in German, because of their lion haircut.',
 solar:'Azawakhs come from the hot Sahara desert, so they would much rather sunbathe than build a snowman!',
 zoom:'Miniature Pinschers are called the King of Toys, and with their short coat they love a warm jumper in winter.',
 speckle:'Bluetick Coonhounds have a dark blue speckled coat, like a night sky full of stars.',
 rocket:'Pumi pups have curly coats and ears that flop over at the tips, which makes them look surprised!',
 stardust:'Biewer Terriers were first bred in Germany in 1984 by a couple called Biewer, and their coats are white, black and gold.',
 holly:XPUPS.holly.fact,tinsel:XPUPS.tinsel.fact};

/* ---------------- 2D pieces ---------------- */
const leaf=(x,y,a,s)=>`<path transform="translate(${x.toFixed(1)} ${y.toFixed(1)}) rotate(${a}) scale(${s||1})" d="M-13 0 L-9 -5 L-5 -3 L-1 -7 L3 -3 L7 -6 L13 0 L7 6 L3 3 L-1 7 L-5 3 L-9 5 Z" fill="#2f8a4a" ${ol(2)}/>`;
const berries=(x,y,r)=>[[-r*.9,0],[r*.9,0],[0,-r*1.2]].map(q=>`<circle cx="${(x+q[0]).toFixed(1)}" cy="${(y+q[1]).toFixed(1)}" r="${r}" fill="#e8302a" ${ol(1.8)}/>`).join('');
const sprig=(x,y,s)=>leaf(x-9*s,y,-25,s)+leaf(x+9*s,y,25,s)+berries(x,y-2*s,4*s);
const flake=(x,y,r,c,o)=>`<path d="M${x-r} ${y} H${x+r} M${x-r*.5} ${y-r*.87} L${x+r*.5} ${y+r*.87} M${x-r*.5} ${y+r*.87} L${x+r*.5} ${y-r*.87}" ${st(c||'#fff',r>5?2.4:1.8,o==null?.9:o)}/>`;
const bell=(x,y,r)=>`<path d="M${x-r} ${y+r*.7} Q${x-r} ${y-r} ${x} ${y-r} Q${x+r} ${y-r} ${x+r} ${y+r*.7} Z" fill="${GLD}" ${ol(2)}/><circle cx="${x}" cy="${y+r*.85}" r="${r*.3}" fill="#c98a2e"/><path d="M${x-r*.4} ${y-r*.3} q${r*.2} -${r*.3} ${r*.5} -${r*.3}" ${st('#fff7c2',2,.8)}/>`;
const tinselLine=(pts,col)=>{let s='';pts.forEach((p,i)=>{const r=4.2,a=i*.9;s+=`<path d="M${(p[0]-r*Math.cos(a)).toFixed(1)} ${(p[1]-r*Math.sin(a)).toFixed(1)} L${(p[0]+r*Math.cos(a)).toFixed(1)} ${(p[1]+r*Math.sin(a)).toFixed(1)} M${(p[0]-r*Math.sin(a)).toFixed(1)} ${(p[1]+r*Math.cos(a)).toFixed(1)} L${(p[0]+r*Math.sin(a)).toFixed(1)} ${(p[1]-r*Math.cos(a)).toFixed(1)}" ${st(col,2.6,1)}/>`;});
  return `<path d="M${pts.map(p=>p[0].toFixed(1)+' '+p[1].toFixed(1)).join(' L')}" ${st(shade(col,-.2),3.4,1)}/>`+s+pts.filter((p,i)=>i%3===1).map(p=>`<circle cx="${p[0].toFixed(1)}" cy="${(p[1]-1).toFixed(1)}" r="1.6" fill="#fff"/>`).join('');};
const neckPts=(c,n,dip)=>{const out=[],y0=c.cy+c.hh-10;for(let i=-n;i<=n;i++)out.push([c.cx+i*(c.hw*.62/n),y0+(n*n-i*i)/(n*n)*(dip||12)]);return out;};
if(PS){
 Object.assign(PS.HAT,{
  santa(c,col){const cx=c.cx,hw=c.hw,yb=c.cy-c.hh*.6;col=col||RED;return `<path d="M${cx-hw*.8} ${yb} C${cx-hw*.62} ${yb-48} ${cx+hw*.2} ${yb-64} ${cx+hw*.9} ${yb-38} C${cx+hw*.52} ${yb-32} ${cx+hw*.72} ${yb-14} ${cx+hw*.8} ${yb} Z" fill="${col}" ${ol(3.5)}/><circle cx="${cx+hw*.94}" cy="${yb-36}" r="11" fill="#fff" ${ol(2.5)}/><rect x="${cx-hw*.88}" y="${yb-11}" width="${hw*1.76}" height="21" rx="10.5" fill="#fff" ${ol(2.5)}/>`;},
  elf(c,col){const cx=c.cx,hw=c.hw,yb=c.cy-c.hh*.6;col=col||'#3fae5a';return `<path d="M${cx-hw*.74} ${yb} Q${cx-hw*.1} ${yb-44} ${cx+hw*.66} ${yb-62} Q${cx+hw*.42} ${yb-30} ${cx+hw*.74} ${yb} Z" fill="${col}" ${ol(3.5)}/>`+bell(cx+hw*.68,yb-60,7)+`<rect x="${cx-hw*.8}" y="${yb-9}" width="${hw*1.6}" height="17" rx="5" fill="${RED}" ${ol(2.5)}/><path d="M${cx-hw*.7} ${yb} h${hw*1.4}" stroke="#fff" stroke-width="4" stroke-dasharray="8 8"/>`;},
  holly(c){const cx=c.cx,hw=c.hw,hh=c.hh,y0=c.cy-hh*.74;let s='';for(let i=-3;i<=3;i++){const t=i/3,x=cx+t*hw*.86,y=y0-(1-t*t)*hh*.16;s+=leaf(x,y,t*40+(i%2?18:-18),.95);}
    for(const t of[-.6,0,.6])s+=berries(cx+t*hw*.86,y0-(1-t*t)*hh*.16-4,4.2);return s;},
  antlers(c,col){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;col=col||RED;let s=`<path d="M${cx-hw*.86} ${cy-hh*.3} Q${cx} ${cy-hh*1.28} ${cx+hw*.86} ${cy-hh*.3}" ${st(K,10,1)}/><path d="M${cx-hw*.86} ${cy-hh*.3} Q${cx} ${cy-hh*1.28} ${cx+hw*.86} ${cy-hh*.3}" ${st(col,6,1)}/>`;
    for(const g of[-1,1]){const x=cx+g*hw*.42,y=cy-hh*.9,d=`M${x} ${y} q${g*-2} -14 ${g*4} -30 M${x+g*1} ${y-14} l${g*12} -9 M${x+g*2.5} ${y-24} l${g*-9} -8`;s+=`<path d="${d}" ${st(K,8,1)}/><path d="${d}" ${st('#b07a46',5,1)}/>`;}
    return s+bell(cx,cy-hh*1.03,6);}});
 Object.assign(PS.BODY,{
  xjumper(c,col,o){const by=c.by,bw=c.bw,bh=c.bh,x1=100-bw,x2=100+bw;col=col||RED;const lt=o.pat==='flake'||o.pat==='nordic'||o.pat==='num'?'#fff':o.pat==='tree'?(col===GRN?'#fff':'#3fae5a'):'#fff';
   let s=`<rect x="${x1}" y="${by-bh}" width="${bw*2}" height="${bh*2}" fill="${col}"/>`;for(let i=0;i<3;i++)s+=`<path d="M${x1} ${by+bh*.62+i*7} H${x2}" ${st(shade(col,-.25),3,1)}/>`;
   if(o.pat==='flake'){s+=`<rect x="${x1}" y="${by-8}" width="${bw*2}" height="16" fill="${shade(col,.18)}"/>`;for(let x=x1+10;x<x2;x+=22)s+=flake(x,by,6);s+=`<path d="M${x1} ${by-13} H${x2} M${x1} ${by+13} H${x2}" ${st('#fff',3,.9)}/>`;}
   if(o.pat==='tree'){for(let x=x1+10;x<x2;x+=24)s+=`<path d="M${x} ${by-12} l9 16 h-18 Z" fill="${lt}" ${ol(1.6)}/><rect x="${x-2}" y="${by+4}" width="4" height="5" fill="#8a5a32"/><circle cx="${x}" cy="${by-13}" r="2.6" fill="${GLD}"/>`;s+=`<path d="M${x1} ${by-bh*.55} H${x2}" ${st('#fff',4,.85)}/>`;}
   if(o.pat==='nordic')s+=PS.BODY.jumper(c,col,{pat:'nordic'});
   if(o.pat==='stripe')for(let x=x1-bh*2;x<x2;x+=18)s+=`<path d="M${x} ${by+bh} L${x+bh*2} ${by-bh}" ${st('#fff',7,.95)}/>`;
   if(o.pat==='num'){s+=`<path d="M${x1} ${by-bh*.5} H${x2}" ${st('#fff',4,.9)}/>`;for(let x=x1+8;x<x2;x+=16)s+=`<circle cx="${x}" cy="${by-bh*.5-7}" r="2.2" fill="#fff"/>`;s+=`<text x="${100+bw*.28}" y="${by+15}" font-size="${String(o.num).length>1?28:36}" font-weight="900" text-anchor="middle" fill="#fff" stroke="${K}" stroke-width="1.6" font-family="Arial">${o.num}</text>`;}
   if(o.pat==='bulbs'){const cs=[RED,GLD,'#5cb8ff','#3fae5a','#ff7fb8'];let d=`M${x1} ${by-4}`;for(let x=x1;x<x2;x+=20)d+=` q10 10 20 0`;s+=`<path d="${d}" ${st('#2a2a2a',2.5,1)}/>`;let k=0;for(let x=x1+10;x<x2;x+=20,k++){const cc=cs[k%5];s+=`<circle cx="${x}" cy="${by+9}" r="9" fill="${cc}" opacity=".35"/><ellipse cx="${x}" cy="${by+9}" rx="4.5" ry="6.5" fill="${cc}" ${ol(1.6)}/><rect x="${x-2.5}" y="${by+1}" width="5" height="3.5" fill="#8a8f99"/>`;}}
   if(o.pat==='hivis'){for(const y of[by-bh*.3,by+bh*.35])s+=`<rect x="${x1}" y="${y-6}" width="${bw*2}" height="12" fill="#d8f23a"/><rect x="${x1}" y="${y-1.5}" width="${bw*2}" height="3" fill="#e6eef6"/>`;s+=sprig(100+bw*.35,by+2,.65);}
   if(o.pat==='spikes'){for(let x=x1+8;x<x2;x+=18)s+=`<path d="M${x} ${by+6} l7 -12 l7 12 Z" fill="#ffb000" opacity=".9"/>`;s+=`<path d="M${x1} ${by+10} H${x2}" ${st('#fff',3,.8)}/>`;}
   return s;}});
 Object.assign(PS.NECK,{
  xscarf(c,col,o){const cx=c.cx,y=c.cy+c.hh-12;col=col||RED;const s2=o.stripe||'#fff';return `<path d="M${cx-c.hw*.66} ${y} Q${cx} ${y+16} ${cx+c.hw*.66} ${y}" ${st(K,22,1)}/><path d="M${cx-c.hw*.66} ${y} Q${cx} ${y+16} ${cx+c.hw*.66} ${y}" ${st(col,16,1)}/><path d="M${cx-c.hw*.5} ${y+3} Q${cx} ${y+18} ${cx+c.hw*.5} ${y+3}" ${st(s2,3,.9)} stroke-dasharray="6 6"/>`+
    `<g transform="rotate(-10 ${cx+c.hw*.32} ${y+6})"><rect x="${cx+c.hw*.22}" y="${y+4}" width="17" height="40" rx="5" fill="${col}" ${ol(2.6)}/><path d="M${cx+c.hw*.22} ${y+20} h17 M${cx+c.hw*.22} ${y+30} h17" ${st(s2,3.5,.95)}/><path d="M${cx+c.hw*.22+3} ${y+44} v6 M${cx+c.hw*.22+8.5} ${y+44} v6 M${cx+c.hw*.22+14} ${y+44} v6" ${st(col,3,1)}/></g>`;},
  tinsel(c,col,o){col=col||GLD;let s=tinselLine(neckPts(c,6,13),col);if(o.shell){const P=neckPts(c,6,13);[P[3],P[6],P[9]].forEach((p,i)=>{s+=`<path d="M${p[0]} ${p[1]+10} l-7 -10 q7 -6 14 0 Z" fill="${['#ffb3c8','#fff3d6','#ffd0a8'][i]}" ${ol(1.6)}/><path d="M${p[0]} ${p[1]+9} v-8 M${p[0]} ${p[1]+9} l-4 -7 M${p[0]} ${p[1]+9} l4 -7" ${st('#d98a8a',1.2,1)}/>`;});}return s;},
  bell(c,col){const cx=c.cx,y=c.cy+c.hh-8;col=col||RED;return `<path d="M${cx-c.hw*.55} ${y} Q${cx} ${y+12} ${cx+c.hw*.55} ${y}" ${st(K,11,1)}/><path d="M${cx-c.hw*.55} ${y} Q${cx} ${y+12} ${cx+c.hw*.55} ${y}" ${st(col,7,1)}/>`+bell(cx,y+16,9);}});
}
/* extra Christmas touches, drawn after the outfit (x in the outfit: holly, bob, tinselhat, bells, spikes) */
function extra2D(w,c,X){const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh;let s='';
  if(w==='behind'){if(X.spikes)for(let i=0;i<5;i++){const x=100-c.bw*.7+i*c.bw*.32,y=c.by-c.bh+2;s+=`<path d="M${x-8} ${y+4} L${x} ${y-14} L${x+8} ${y+4} Z" fill="#ffb000" ${ol(2.2)}/>`;}
    if(X.bells){const x=100-c.bw+2,y=c.by-c.bh+16;s+=bell(x-10,y,8)+bell(x+4,y-6,7)+`<path d="M${x-10} ${y-8} Q${x-4} ${y-18} ${x+4} ${y-13}" ${st(RED,3,1)}/>`;}}
  if(w==='top'){if(X.tinselhat)s+=tinselLine(Array.from({length:9},(v,i)=>[cx-hw*.7+i*hw*.175,cy-hh*.58+Math.sin(i)*2]),GLD);
    if(X.holly)s+=sprig(cx-hw*.42,cy-hh*(X.holly===2?.98:.72),.8);
    if(X.bob){const xs=[c.bcx-17,c.bcx+17];if(c.L.long)xs.push(100+c.bw-36,100+c.bw-10);xs.forEach(x=>{s+=`<circle cx="${x}" cy="167" r="6.5" fill="#fff" ${ol(2)}/>`;});}}
  return s;}

/* ---------------- full costumes ---------------- */
const XC={
 pudding:{n:'Christmas Pudding',body:'#6a3a22',belly:'#7a4a2a',paw:'#4a2814',line:'NAME is dressed as a Christmas pudding, with a sprig of holly on top!'},
 elf:{n:'Elf',body:'#3fae5a',belly:'#5fc06a',paw:'#2f8a4a',line:'NAME is one of the busiest little Christmas elves.'},
 present:{n:'Present',body:'#d9363e',belly:'#d9363e',paw:'#a8262c',line:'NAME is the best present of all!'},
 deer:{n:'Reindeer Onesie',body:'#a8743a',belly:'#f3e2c0',paw:'#6a4422',line:'NAME is a cosy reindeer in a fluffy onesie.'},
 robin:{n:'Robin',body:'#8a5a3a',belly:'#e8603a',paw:'#6a4028',line:'NAME is a cheerful little Christmas robin. Tweet tweet!'},
 angel:{n:'Snow Angel',body:'#ffffff',belly:'#f4f8ff',paw:'#e6eef8',line:'NAME is a sparkly snow angel.'},
 lights:{n:'Fairy Lights',line:'NAME got tangled up in the fairy lights, and now NAME glows!'},
 xjumper:{n:'Christmas Jumper',body:'#d9363e',belly:'#d9363e',paw:'#a8262c',line:'NAME is wearing a cosy Christmas jumper and a bobble hat.'}};
for(const k in XC){XC[k].xmas=true;COS[k]=XC[k];}const COS_ICON_X={pudding:'🍮',elf:'🧝',present:'🎁',deer:'🦌',robin:'🐦',angel:'👼',lights:'💡',xjumper:'🧶'};if(typeof COS_ICON!=='undefined')Object.assign(COS_ICON,COS_ICON_X);
const _ac=applyCos;applyCos=function(L,k){const fur=L.body||L.fur,bel=L.belly,paw=L.paw;const r=_ac(L,k);if(k==='lights'&&r.cos){r.body=fur;r.belly=bel;r.paw=paw;}return r;};
const _c2=cos2D;cos2D=function(w,c){let s=_c2(w,c);const L=c.L,Kc=L.cos;if(!COS[Kc]||!/^(pudding|elf|present|deer|robin|angel|lights|xjumper)$/.test(Kc))return s;
  const cx=c.cx,cy=c.cy,hw=c.hw,hh=c.hh,bw=c.bw,bh=c.bh,by=c.by,bcx=c.bcx,S=c.S,S3=c.S3,k=c.k,yb=cy-hh*.42;
  const dome=(col,lo)=>`<path d="M${cx-hw*.94} ${lo} Q${cx-hw*.94} ${cy-hh*1.2} ${cx} ${cy-hh*1.22} Q${cx+hw*.94} ${cy-hh*1.2} ${cx+hw*.94} ${lo} Z" fill="${col}" ${S}/>`;
  const wire=(pts)=>`<path d="M${pts.map(p=>p.join(' ')).join(' L')}" ${st('#2a3a2a',2.6,1)}/>`+pts.map((p,i)=>{const cc=[RED,GLD,'#5cb8ff','#3fae5a','#ff7fb8'][i%5];return `<circle cx="${p[0]}" cy="${p[1]}" r="9" fill="${cc}" opacity=".35"/><ellipse cx="${p[0]}" cy="${p[1]+3}" rx="4" ry="6" fill="${cc}" ${ol(1.5)}/>`;}).join('');
  if(w==='behind'){
    if(Kc==='angel')for(const g of[-1,1]){const x=100+g*(bw+4),y=by-bh;s+=`<path d="M${x} ${y+16} Q${x+g*46} ${y-34} ${x+g*58} ${y+6} Q${x+g*44} ${y+6} ${x+g*48} ${y+26} Q${x+g*30} ${y+22} ${x+g*30} ${y+40} Q${x+g*14} ${y+30} ${x} ${y+34} Z" fill="#ffffff" ${S}/>`;}
    if(Kc==='robin')for(const g of[-1,1]){const x=100+g*(bw-2);s+=`<ellipse cx="${x}" cy="${by-4}" rx="14" ry="${bh*.7}" fill="#6a4028" transform="rotate(${g*18} ${x} ${by})" ${S3}/>`;}}
  if(w==='bodyClip'){
    if(Kc==='pudding'){[[-.6,-.3],[.2,-.5],[.5,.2],[-.2,.35],[-.55,.55],[.65,-.1],[0,.05]].forEach(q=>{s+=`<ellipse cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" rx="4" ry="3" fill="#2a1408"/>`;});}
    if(Kc==='elf')s+=`<rect x="${100-bw}" y="${by+bh*.3}" width="${bw*2}" height="11" fill="#26232e"/><rect x="${bcx-9}" y="${by+bh*.3-2}" width="18" height="15" rx="2" fill="none" stroke="${GLD}" stroke-width="4"/>`;
    if(Kc==='present')s+=`<rect x="${bcx-7}" y="${by-bh}" width="14" height="${bh*2}" fill="${GLD}"/><rect x="${100-bw}" y="${by-7}" width="${bw*2}" height="14" fill="${GLD}"/>`+[[-.55,-.55],[.55,-.5],[-.5,.55],[.6,.6]].map(q=>`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="4" fill="#fff" opacity=".8"/>`).join('');
    if(Kc==='deer')s+=`<ellipse cx="${bcx}" cy="${by+bh*.15}" rx="${bw*.5}" ry="${bh*.75}" fill="#f3e2c0"/>`+[[-.6,-.4],[.55,-.55],[.7,.2]].map(q=>`<circle cx="${100+q[0]*bw}" cy="${by+q[1]*bh}" r="4" fill="#f3e2c0"/>`).join('');
    if(Kc==='robin')s+=`<ellipse cx="${bcx}" cy="${by+bh*.05}" rx="${bw*.5}" ry="${bh*.8}" fill="#e8603a"/><ellipse cx="${bcx}" cy="${by+bh*.75}" rx="${bw*.4}" ry="${bh*.3}" fill="#f6ead8"/>`;
    if(Kc==='angel')[[-.5,-.3],[.4,.2],[-.1,.55],[.6,-.5]].forEach(q=>{s+=star4(100+q[0]*bw,by+q[1]*bh,6,'#bfe6ff');});
    if(Kc==='xjumper'){s+=`<rect x="${100-bw}" y="${by-8}" width="${bw*2}" height="16" fill="#fff"/>`;for(let x=100-bw+10;x<100+bw;x+=22)s+=flake(x,by,6,RED);for(let i=0;i<3;i++)s+=`<path d="M${100-bw} ${by+bh*.62+i*7} H${100+bw}" ${st('#a8262c',3,1)}/>`;}
    if(Kc==='lights')s+=wire([[100-bw,by-bh*.5],[100-bw*.5,by-bh*.1],[100,by-bh*.55],[100+bw*.5,by-bh*.05],[100+bw,by-bh*.45]])+wire([[100-bw,by+bh*.4],[100-bw*.4,by+bh*.75],[100+bw*.2,by+bh*.35],[100+bw*.8,by+bh*.7]]);}
  if(w==='chest'){
    if(Kc==='elf'){let d=`M${cx-hw*.7} ${cy+hh-12}`;for(let i=0;i<7;i++)d+=` l${hw*.1} ${i%2?-14:14}`;s+=`<path d="${d} Z" fill="${RED}" ${S3}/>`+bell(cx,cy+hh+6,7);}
    if(Kc==='robin')s+='';}
  if(w==='top'){
    if(Kc==='pudding')s+=`<path d="M${cx-hw*.88} ${yb-4} Q${cx-hw*.88} ${cy-hh*1.18} ${cx} ${cy-hh*1.2} Q${cx+hw*.88} ${cy-hh*1.18} ${cx+hw*.88} ${yb-4} q-10 10 -16 0 q-8 14 -16 0 q-10 12 -18 0 q-8 16 -18 0 q-8 12 -16 0 q-8 10 -14 0 Z" fill="#fff8e6" ${S}/>`+sprig(cx,cy-hh*1.22,1);
    if(Kc==='elf')s+=PS.HAT.elf(c,'#3fae5a');
    if(Kc==='present'){const y=cy-hh*.95;s+=`<path d="M${cx} ${y} q-32 -26 -38 -4 q14 12 38 4 q32 -26 38 -4 q-14 12 -38 4" fill="${GLD}" ${S3}/><circle cx="${cx}" cy="${y}" r="8" fill="${GLD}" ${S3}/><path d="M${cx-4} ${y+6} l-10 20 M${cx+4} ${y+6} l10 20" ${st(K,8,1)}/><path d="M${cx-4} ${y+6} l-10 20 M${cx+4} ${y+6} l10 20" ${st(GLD,5,1)}/>`;}
    if(Kc==='deer'){s+=dome('#a8743a',yb);for(const g of[-1,1]){const x=cx+g*hw*.4,y=cy-hh*1.08,d=`M${x} ${y} q${g*-2} -14 ${g*4} -28 M${x+g} ${y-13} l${g*12} -9 M${x+g*2.5} ${y-22} l${g*-9} -8`;s+=`<path d="${d}" ${st(K,8,1)}/><path d="${d}" ${st('#e8d4a8',5,1)}/><ellipse cx="${cx+g*hw*.9}" cy="${cy-hh*.82}" rx="13" ry="7" transform="rotate(${g*-30} ${cx+g*hw*.9} ${cy-hh*.82})" fill="#a8743a" ${S3}/>`;}}
    if(Kc==='robin')s+=dome('#8a5a3a',yb)+`<path d="M${cx-6} ${cy-hh*1.2} q6 -14 14 -10 q-6 4 -4 12 Z" fill="#6a4028" ${S3}/>`;
    if(Kc==='angel')s+=`<ellipse cx="${cx}" cy="${cy-hh*1.2}" rx="${hw*.62}" ry="9" fill="none" stroke="${K}" stroke-width="9"/><ellipse cx="${cx}" cy="${cy-hh*1.2}" rx="${hw*.62}" ry="9" fill="none" stroke="${GLD}" stroke-width="5"/>`+star4(cx+hw*.8,cy-hh*1.3,7,'#fff7c2','twk');
    if(Kc==='xjumper')s+=PS.HAT.beanie(c,RED,{pom:'#fff'});
    if(Kc==='lights')s+=wire([[cx-hw*.9,cy-hh*.5],[cx-hw*.4,cy-hh*.95],[cx+hw*.15,cy-hh*.85],[cx+hw*.7,cy-hh*1.0],[cx+hw*.95,cy-hh*.45]]);}
  return s;};
const _c3=cos3D;cos3D=function(L,b,h,c){const Kc=L.cos;if(!/^(pudding|elf|present|deer|robin|angel|lights|xjumper)$/.test(Kc))return _c3(L,b,h,c);
  const bw=c.bw,lg=c.lg,hs=c.hs||1,helm=col=>{const hm=mk('hemi',col,.62,.6,.6,0,.08,-.02,h);hm.rotation.x=-.32;return hm;},band=(col,y,th)=>{mk('band',col,.51*bw,.65*lg,th||1.8,0,y,0,b).rotation.x=PI/2;};
  const bulbs=(par,pts)=>pts.forEach((q,i)=>mk('sph',[RED,GLD,'#5cb8ff','#3fae5a','#ff7fb8'][i%5],.07,.09,.07,q[0],q[1],q[2],par,true));
  switch(Kc){
   case'pudding':mk('hemi','#fff8e6',.64,.34,.62,0,.3,-.02,h);[-1,1].forEach(s=>mk('sph','#2f8a4a',.16,.04,.08,s*.12,.66,0,h).rotation.z=s*.4);mk('sph','#e8302a',.07,.07,.07,0,.68,.04,h);
     [[-.3,.9,.2],[.25,.8,-.3],[.1,1.0,.4],[-.2,.7,-.5]].forEach(q=>mk('sph','#2a1408',.06,.05,.06,q[0]*bw,q[1],q[2]*lg,b));break;
   case'elf':{const cn=mk('cone','#3fae5a',.32,.84,.32,.04,.84,0,h);cn.rotation.z=-.22;mk('tor',RED,.42,.42,.4,0,.42,0,h).rotation.x=PI/2;mk('sph',GLD,.09,.09,.09,.13,1.24,0,h);band('#26232e',.62,1.1);mk('box',GLD,.16,.12,.04,0,.62,.64*lg,b);break;}
   case'present':band(GLD,.75,1.2);mk('box',GLD,.12,.04,1.32*lg,0,1.14,0,b);[-1,1].forEach(s=>{const lp=mk('tor',GLD,.14,.14,.4,s*.14,.6,0,h);lp.rotation.y=PI/2;lp.rotation.z=s*.5;});mk('sph',GLD,.08,.08,.08,0,.6,0,h);break;
   case'deer':helm('#a8743a');[-1,1].forEach(s=>{mk('cyl','#e8d4a8',.035,.36,.035,s*.2,.72,-.02,h).rotation.z=-s*.25;mk('cyl','#e8d4a8',.03,.16,.03,s*.3,.8,-.02,h).rotation.z=-s*.9;mk('sph','#a8743a',.08,.16,.05,s*.5,.42,-.05,h).rotation.z=-s*.9;});mk('sph','#f3e2c0',.3*bw,.32,.3,0,.7,.45*lg,b);break;
   case'robin':helm('#8a5a3a');mk('sph','#e8603a',.34*bw,.36,.3,0,.74,.45*lg,b);[-1,1].forEach(s=>mk('sph','#6a4028',.06,.24,.42*lg,s*(.5*bw+.04),.85,-.05,b));break;
   case'angel':[-1,1].forEach(s=>{const wg=mk('sph','#ffffff',.06,.42,.5,s*(.42*bw+.12),1.22,-.1*lg,b);wg.rotation.z=s*.55;});mk('tor',GLD,.36,.36,.3,0,.82,0,h,true).rotation.x=PI/2;break;
   case'lights':bulbs(b,[[-.4*bw,.9,.3*lg],[.4*bw,.95,0],[-.3*bw,1.05,-.35*lg],[.45*bw,.7,-.4*lg],[0,1.12,.15*lg],[-.48*bw,.6,-.1*lg]]);bulbs(h,[[-.4,.4,.1],[0,.56,0],[.4,.4,.1]]);mk('band','#2a3a2a',.505*bw,.645*lg,.5,0,.8,0,b).rotation.x=PI/2+.3;break;
   case'xjumper':band('#ffffff',.78,1.6);PS.H3.beanie(h,RED,{pom:'#fff'});break;}};

/* ---------------- 3D pieces ---------------- */
if(PS){
 Object.assign(PS.H3,{
  santa(h,col){const cn=mk('cone',col||RED,.36,.66,.36,.06,.74,-.02,h);cn.rotation.z=-.42;mk('tor','#ffffff',.44,.44,.5,0,.42,-.02,h).rotation.x=PI/2;mk('sph','#ffffff',.13,.13,.13,.26,1.0,-.02,h);},
  elf(h,col){const cn=mk('cone',col||'#3fae5a',.32,.84,.32,.04,.84,0,h);cn.rotation.z=-.22;mk('tor',RED,.42,.42,.4,0,.42,0,h).rotation.x=PI/2;mk('sph',GLD,.09,.09,.09,.13,1.24,0,h);},
  holly(h){for(let i=0;i<10;i++){const a=i*PI/5;mk('sph','#2f8a4a',.13,.04,.07,Math.cos(a)*.5,.34,Math.sin(a)*.46,h).rotation.y=-a;if(i%3===0)mk('sph','#e8302a',.06,.06,.06,Math.cos(a)*.5,.38,Math.sin(a)*.46+.02,h);}},
  antlers(h,col){mk('arc',col||RED,.6,.6,1.2,0,.08,0,h);[-1,1].forEach(s=>{mk('cyl','#b07a46',.035,.36,.035,s*.24,.68,0,h).rotation.z=-s*.25;mk('cyl','#b07a46',.03,.16,.03,s*.34,.74,0,h).rotation.z=-s*.95;});mk('sph',GLD,.06,.07,.06,0,.62,.04,h);}});
 PS.B3.xjumper=RED;
 Object.assign(PS.N3,{
  xscarf(b,col,cz,c){mk('tor',col||RED,.3*c.hs,.3*c.hs,.55*c.hs,0,.98,.4*c.lg,b).rotation.x=PI/2-.5;mk('box',col||RED,.13,.38,.06,.14,.78,cz+.06,b).rotation.z=.15;},
  tinsel(b,col,cz,c){mk('tor',col||GLD,.31*c.hs,.31*c.hs,.4*c.hs,0,.98,.4*c.lg,b,true).rotation.x=PI/2-.5;for(let i=0;i<5;i++){const a=i*1.25;mk('sph','#ffffff',.035,.035,.035,Math.cos(a)*.3*c.hs,.98+Math.sin(a)*.12,.4*c.lg+Math.sin(a)*.2*c.hs,b,true);}},
  bell(b,col,cz,c){mk('tor',col||RED,.3*c.hs,.3*c.hs,.3*c.hs,0,.98,.4*c.lg,b).rotation.x=PI/2-.5;mk('sph',GLD,.11,.11,.11,0,.82,.4*c.lg+.3*c.hs,b);}});
}
function extra3D(X,L,b,h,c){const lg=c.lg,bw=c.bw;
  if(X.holly){[-1,1].forEach(s=>mk('sph','#2f8a4a',.13,.03,.06,-.3+s*.08,X.holly===2?.82:.56,.12,h).rotation.z=s*.5);mk('sph','#e8302a',.06,.06,.06,-.3,X.holly===2?.86:.6,.16,h);}
  if(X.tinselhat)mk('tor',GLD,.45,.45,.4,0,.42,0,h,true).rotation.x=PI/2;
  if(X.bells)[-1,1].forEach(s=>mk('sph',GLD,.08,.09,.08,s*.22,.98,-.48*lg,b));
  if(X.spikes)for(let i=0;i<5;i++)mk('cone','#ffb000',.07,.22,.07,0,1.16,(.4-i*.2)*lg,b);
  if(X.band)mk('band',X.band,.505*bw,.645*lg,1.6,0,.8,0,b).rotation.x=PI/2;
  if(X.bulbs)[[-.42,.85,.3],[.42,.9,0],[-.4,.95,-.35],[.44,.75,-.42],[0,1.12,.1]].forEach((q,i)=>mk('sph',[RED,GLD,'#5cb8ff','#3fae5a','#ff7fb8'][i],.07,.09,.07,q[0]*bw,q[1],q[2]*lg,b,true));}

/* ---------------- who wears what at Christmas ---------------- */
const NUMS={digit:'1',dot:'2',doodle:'10',zero:'0',ruler:'12',paddle:'5',cube:'8',prism:'3',pie:'π',seven:'7',infinity:'∞',plus:'+',pretzel:'6'};
const KIT={
 meadow:(i,p)=>({h:i%3!==1?['holly']:null,n:i%3!==2?[['xscarf',COLS[i%5],{stripe:i%2?GLD:'#fff'}]]:null,f:i%2===0?['wellies',COLS[(i+2)%5]]:null,x:{bob:i%2===0}}),
 snowy:(i,p)=>({b:['xjumper',COLS[i%5],{pat:['flake','tree','nordic','stripe'][i%4]}],h:i%3===0?['beanie',COLS[(i+3)%6],{pom:'#fff'}]:i%3===1?['earmuffs',[RED,GLD,PINK,'#fff'][i%4]]:null,drop:['scarf']}),
 reef:(i,p)=>{const k=i%4;return {h:k===3?['elf']:k!==1?['santa']:null,g:k===0||k===3?['snorkel']:null,n:k!==2?[['tinsel',[GLD,'#c9d2e3',RED,'#ff9ecb'][i%4],{shell:1}]]:null,keep:['bubbles'],drop:['shellneck']};},
 ninja:(i,p)=>{const k=i%4;if(k===0)return {look:{ninja:{suit:RED,band:'#ffffff'},body:RED,belly:shade(RED,.22),paw:shade(RED,-.25),collar:null,fluffy:false,fringe:null,blaze:null,spots:false,face:null,bodyPatch:null,wool:false,eyeWhite:true}};
   if(k===1)return {b:['gi'],n:[['tinsel',[GLD,RED,'#c9d2e3'][i%3]]],h:['headband',i%2?RED:'#ffffff'],drop:['scarf','bow']};
   if(k===2)return {h:['headband',[RED,GRN,'#ffffff'][i%3]],n:[['xscarf',[RED,GRN,'#ffffff'][(i+1)%3],{stripe:i%2?RED:GRN}]],drop:['scarf','bow']};
   return {b:['gi'],n:[['bell',[RED,GRN][i%2]]],x:{holly:1},drop:['scarf','bow']};},
 number:(i,p)=>({b:['xjumper',COLS[i%5],{pat:'num',num:NUMS[p.id]||String(i+1)}],h:i%2?['crown',[GLD,RED,GLD,GRN,GLD,RED]]:['numcrown'],x:{holly:i%2?1:2},drop:['scarf','flower','bow']}),
 gadget:(i,p)=>({b:['xjumper',[RED,GRN,NAVY,PLUM][i%4],{pat:'bulbs'}],h:i%3!==2?['propeller']:['beanie',[RED,GRN][i%2],{pom:GLD}],x:{tinselhat:i%3!==2,bulbs:i%2===0},drop:['scarf','bow']}),
 rescue:(i,p)=>({b:['xjumper',[RED,GRN,NAVY][i%3],{pat:'hivis'}],h:i%2?['hardhat',RED]:['santa'],x:{holly:i%2?1:0},drop:['scarf','glow']}),
 dino:(i,p)=>({b:['xjumper',[GRN,RED,'#7cc85a',NAVY][i%4],{pat:'spikes'}],h:i%3!==2?['explorer',['#8a5a32','#a8743a','#6a4428'][i%3]]:['holly'],x:{holly:i%3!==2?1:0,spikes:1}}),
 planet:(i,p)=>i%2?{space:{trim:[RED,GRN,GLD,'#5cb8ff'][i%4],ant:i%4===1},n:[['tinsel',[GLD,'#c9d2e3',RED][i%3]]]}:{k:['rocketpack'],h:['santa',[RED,GRN][(i/2|0)%2]],x:{bells:1},n:[['bell',GRN]]}};
const COSTUME={bumble:'robin',snowdrop:'snowman',puffin:'lights',ginger:'ginger',pretzel:'pudding',nano:'present',hydrant:'elf',jura:'deer',astra:'angel'};
const XOUT={holly:{h:['holly'],n:[['xscarf',RED,{stripe:'#fff'}]]},tinsel:{h:['antlers',GRN],n:[['tinsel',GLD]]}};
function buildOut(){ISLANDS.forEach(I=>{const f=KIT[I.id];if(!f)return;I.pups.concat(I.bonus||[]).forEach((p,i)=>{XOUT[p.id]=COSTUME[p.id]?{cos:COSTUME[p.id]}:f(i,p);const S=XOUT[p.id];for(const k in S)if(S[k]==null)delete S[k];});});}
buildOut();
/* the unicorns at Christmas: a tinsel garland and a sprig of holly */
const UNI={n:[['tinsel',GLD]],x:{holly:2}};
const isPup=p=>!!(p&&p.id&&(PUPS[p.id]||XPUPS[p.id]));
const seasonOn=()=>!!(typeof state!=='undefined'&&state&&state.season==='xmas');
window.SEASONSPEC=function(p,is2D){if(!p||!p.id||p.guest)return null;
  if(p.uni){if(!p.xmas)return null;return UNI;}
  if(!p.xmas&&(is2D||!seasonOn()))return null;if(!isPup(p))return null;const R=PUPS[p.id]||XPUPS[p.id];if(R.breed!==p.breed)return null;
  return XOUT[p.id]||null;};
/* draw the extras, and apply look overrides in 3D too */
const _f2=form2D;form2D=function(w,c){let s=_f2(w,c);const ps=c.L&&c.L._ps,S=ps&&(ps.S||ps.S3);if(S&&S.x&&!c.L.cos)s+=extra2D(w,c,S.x);return s;};
const _f3=form3D;form3D=function(L,b,h,c){_f3(L,b,h,c);const S=L._ps&&L._ps.S3;if(S&&S.x&&!L.cos)try{extra3D(S.x,L,b,h,c);}catch(e){console.warn('xmas 3D',e);}};
const _fl=formLook;formLook=function(p){const L=_fl(p);const S=L._ps&&L._ps.S3;if(S&&S.look&&!L.cos){Object.assign(L,S.look);L.acc=(L.acc||[]).filter(a=>['glow','twinkle','bubbles','startail'].indexOf(a)>=0);}return L;};

/* a Christmas copy of a pup, for 2D pictures and cards */
const xp=p=>p?Object.assign({},p,{xmas:true}):p;
window.XLOOK={XPUPS,FACT,XOUT,xp,UNI,COSTUME,sprig,flake,bell,leaf,berries};
})();
