/* ================================================================
   Rescue Bay: Region 6 (Star pups), reached by the fire engine over
   the bridge. The Fire Station (start) opens the Harbour (after 2 pups)
   and the Town Square (needs the fire helmet). The Harbour leads to the
   Lighthouse Cliffs (a Star pup shines through the sea fog), the Town
   Square to the Ranger Station (a code lock). Both lead to the Big
   Rescue (boss). Bonus: Seal Cove off the Harbour, across a broken
   jetty that a Sky pup from Gadget Island can float a bridge over.
   ================================================================ */
(function(){
const R=seed(6161),inw=(x,z,f)=>[x*(f||.68),z*(f||.68),Math.atan2(-x,-z)];
const RG={ground:'#9fd87a',ground2:'#b5e290',sky:'#b5e2ff',fog:[70,230],fogC:'#dceefa',hedgeC:'#4f8e3a',biome:'coast'};
const RA=o=>Object.assign({},RG,o);
function pathTo(x1,z1,x2,z2,w,c){const d=Math.hypot(x2-x1,z2-z1),m=new THREE.Mesh(G.plane,M(c||'#c9c2b8'));m.scale.set(w||4,1,d);m.rotation.y=Math.atan2(x2-x1,z2-z1);m.position.set((x1+x2)/2,gy((x1+x2)/2,(z1+z2)/2)+.07,(z1+z2)/2);W.ag.add(m);}
function sea(x1,z1,x2,z2){const SA=W.area,sy=SA.seaDip?SA.sea.y+.01:gy((x1+x2)/2,(z1+z2)/2)+.08,m=new THREE.Mesh(G.plane,new THREE.MeshBasicMaterial({color:'#5fc4f0'}));m.scale.set(x2-x1,1,z2-z1);m.position.set((x1+x2)/2,sy,(z1+z2)/2);W.ag.add(m);W.disp.push(m.material);rect(x1,z1,x2,z2);
  for(let i=0;i<14;i++){const x=x1+R()*(x2-x1),z=z1+R()*(z2-z1);I('box','#ffffff',1.2,.02,.12,x,(SA.seaDip?sy:gy(x,z))+.05,z,0,R()*3,0,true);}}
function boat(x,z,c,rot){const g=grp();mk('box',c||'#e8423a',2,1,5,0,.5,0,g);mk('box','#ffffff',2.1,.2,5.1,0,1,0,g);mk('box','#ffffff',1.4,1.2,1.6,0,1.6,-.6,g);mk('box','#9bdcff',1.42,.4,1.62,0,1.9,-.6,g);mk('cone',c||'#e8423a',1,1.4,.6,0,.5,3,g).rotation.x=Math.PI/2;
  g.rotation.y=rot||0;add(g,x,z,gy(x,z)+.1);W.ticks.push(()=>{g.rotation.z=Math.sin(W.t*1.3+x)*.05;g.position.y=gy(x,z)+.1+Math.sin(W.t*1.7+z)*.08;});col(x,z,2);return g;}
function hydrant(x,z){const y=gy(x,z);I('cyl','#e8423a',.35,1,.35,x,y+.5,z);I('sph','#e8423a',.35,.3,.35,x,y+1.05,z);I('cyl','#ffd23f',.15,.5,.15,x,y+.6,z,0,0,Math.PI/2);col(x,z,.5);}
function zebra(x,z,w,rot){for(let i=0;i<6;i++){const m=new THREE.Mesh(G.plane,M(i%2?'#26232e':'#ffffff'));m.scale.set(w||6,1,.9);m.position.set(x+Math.sin(rot||0)*(i-2.5)*.9,gy(x,z)+.09,z+Math.cos(rot||0)*(i-2.5)*.9);m.rotation.y=rot||0;W.ag.add(m);}}
function trafficLight(x,z){const y=gy(x,z);I('cyl','#26232e',.12,4,.12,x,y+2,z);I('box','#26232e',.7,1.8,.6,x,y+4.6,z);[['#ff6b6b',5.2],['#ffd23f',4.6],['#8fe39a',4]].forEach(l=>I('sph',l[0],.22,.22,.1,x,y+l[1],z+.32,0,0,0,true));col(x,z,.4);}
function rockyCliff(x,z,s){const y=gy(x,z);for(let i=0;i<4;i++)I('box',pick(['#8a8378','#9a9488','#7a7468']),(3+R()*2)*s,(4+R()*4)*s,(3+R()*2)*s,x+(R()-.5)*3*s,y+2*s,z+(R()-.5)*3*s,0,R()*3,0);col(x,z,2.6*s);}
function bridgeArrival(x,z){const y=gy(x,z);for(let i=0;i<14;i++)I('box','#9b6a43',6,.3,1.1,x,y+.4,z+i*1.2);[-3,3].forEach(s=>{for(let i=0;i<8;i++)I('cyl','#5b4636',.12,1.4,.12,x+s,y+1,z+i*2.2);I('box','#9b6a43',.15,.15,17,x+s,y+1.6,z+8);});
  const fe=fireEngine3D();add(fe,x+.2,z+4,y+.5);fe.rotation.y=Math.PI;W.ticks.push(()=>{fe.position.y=y+.5+Math.abs(Math.sin(W.t*3))*.02;});col(x,z+4,2.2);
  const l=label('🚒 Fire engine home',6.5);l.position.set(x,y+6,z+4);W.ag.add(l);W.things.push({x,z:z-2.5,r:4.6,icon:'🚒',label:'Go home',act:goHome});}
function wanderers(n,mkf,cx,cz,r,sp){for(let i=0;i<n;i++){const g=mkf(i);W.ag.add(g);const o={a:i*2.1,s:(sp||.25)+R()*.1};W.ticks.push(dt=>{o.a+=dt*o.s;const x=cx+Math.cos(o.a)*r,z=cz+Math.sin(o.a)*r*.8;g.position.set(x,gy(x,z),z);g.rotation.y=Math.atan2(-Math.sin(o.a),Math.cos(o.a)*.8);});}}
function duckling(){const g=grp();mk('sph','#ffd23f',.4,.35,.5,0,.35,0,g);mk('sph','#ffd23f',.25,.25,.25,0,.75,.3,g);mk('cone','#ff8a3c',.08,.2,.08,0,.72,.55,g).rotation.x=Math.PI/2;return g;}

/* ----------------- the 12 Star pups ----------------- */
const P=[
 {id:'siren',name:'Siren',breed:'Australian Cattle Dog',area:'firestation',pitch:1.1,spot:{x:-22,z:-22,kind:'crate'},hint:'Look in a crate behind the Fire Station.',
  fact:'Australian Cattle Dogs are tough, clever herding dogs. Some are red with speckles, just like Siren!',rescue:{icon:'🚨',verb:'Switch',say:'Siren is dazzled by the flashing lights! Tap to switch them off!'},
  look:{fur:'#c8643a',ear:'#a04a2a',ears:'pointy',spots:true,spotC:'#e8a080',muzzle:'#c8643a',belly:'#d88a60',tail:'thin',acc:['cap','glow']}},
 {id:'hydrant',name:'Hydrant',breed:'Norfolk Terrier',area:'firestation',pitch:1.35,spot:{x:22,z:20,kind:'bucket'},tag:{x:-28,z:20,kind:'haybale'},hint:'Hydrant plays tag. Look by a bucket near the training tower, then by a hay bale.',
  fact:'Norfolk Terriers are small, brave and cheerful. They come from the east of England.',rescue:{icon:'💦',verb:'Dry',say:'Hydrant got soaked by a fire hose! Tap to dry Hydrant with a towel!'},
  look:{fur:'#c8843a',ears:'floppy',fluffy:true,muzzle:'#a8642a',belly:'#d8a060',tail:'stub',scale:.8,acc:['scarf'],scarfC:'#e8423a'}},
 {id:'buoy',name:'Buoy',breed:'Newfoundland',area:'harbour',pitch:.7,spot:{x:-22,z:14,kind:'rockpool'},hint:'Look in a rock pool by the Harbour.',
  fact:'Newfoundlands are huge, gentle swimmers with webbed feet. They have helped rescue people from the sea!',rescue:{icon:'🛟',verb:'Pull',say:'Buoy is tangled in a fishing net! Tap to pull it free!'},
  look:{fur:'#26232e',ears:'floppy',fluffy:true,muzzle:'#26232e',muzzleBig:true,belly:'#3a3338',tail:'plume',hw:64,hh:58,acc:['scarf','glow'],scarfC:'#ffd23f'}},
 {id:'skipper',name:'Skipper',breed:'Portuguese Water Dog',area:'harbour',pitch:1,spot:{x:22,z:-6,kind:'crate'},tag:{x:-12,z:30,kind:'sandcastle'},hint:'Skipper plays tag. Look in a crate on the quay, then by a sandcastle.',
  fact:'Portuguese Water Dogs once helped fishermen by carrying messages from boat to boat. They love to swim!',rescue:{icon:'⚓',verb:'Lift',say:'Skipper is stuck under a heavy anchor rope! Tap to lift it!'},
  look:{fur:'#26232e',ears:'floppy',fluffy:true,wool:true,muzzle:'#ffffff',belly:'#ffffff',paw:'#ffffff',tail:'plume',acc:['cap']}},
 {id:'patch',name:'Patch',breed:'Scottish Terrier',area:'townsq',pitch:1.15,spot:{x:-22,z:-8,kind:'bush'},hint:'Look in a bush by the shops in the Town Square.',
  fact:'Scottish Terriers have long beards and bushy eyebrows. They are proud, brave little dogs.',rescue:{icon:'🩹',verb:'Patch',say:'Patch has a tiny scratch on a paw! Tap to put on a plaster!'},
  look:{fur:'#26232e',ears:'pointy',fluffy:true,fringe:'#26232e',muzzle:'#26232e',muzzleBig:true,belly:'#26232e',tail:'thin',scale:.85,acc:['scarf'],scarfC:'#e8423a'}},
 {id:'plaster',name:'Plaster',breed:'Welsh Terrier',area:'townsq',pitch:1.2,spot:{x:22,z:14,kind:'schoolbag'},tag:{x:-14,z:28,kind:'flowers'},hint:'Plaster plays tag. Look by a school bag near the crossing, then in the flowers.',
  fact:'Welsh Terriers come from Wales and look like little Airedales. They are friendly and full of beans!',rescue:{icon:'🚦',verb:'Cross',say:'Plaster is waiting to cross the road! Tap to press the crossing button!'},
  look:{fur:'#c8843a',ears:'floppy',fluffy:true,muzzle:'#c8843a',belly:'#c8843a',bodyPatch:'#26232e',tail:'stub',acc:['cap']}},
 {id:'flash',name:'Flash',breed:'German Shorthaired Pointer',area:'lighthouse',pitch:1,spot:{x:-20,z:10,kind:'boulder'},hint:'Look behind a rock on the Lighthouse Cliffs.',
  fact:'German Shorthaired Pointers are fast, clever and love to swim. They point their noses at things they find!',rescue:{icon:'🔦',verb:'Shine',say:'Flash is hiding in the dark! Tap to shine a torch!'},
  look:{fur:'#6b3a22',ear:'#6b3a22',ears:'floppy',spots:true,spotC:'#ffffff',muzzle:'#6b3a22',belly:'#8a5a3a',tail:'stub',acc:['glow','scarf'],scarfC:'#ffd23f'}},
 {id:'gull',name:'Gull',breed:'Coton de Tulear',area:'lighthouse',pitch:1.4,spot:{x:22,z:14,kind:'rockpool'},tag:{x:-6,z:30,kind:'sandcastle'},hint:'Gull plays tag. Look in a rock pool, then by a sandcastle.',
  fact:'Cotons have soft cotton-like fur. They come from the island of Madagascar, and love to clown around!',rescue:{icon:'🐦',verb:'Shoo',say:'A seagull is pinching Gull\'s biscuit! Tap to shoo it away!'},
  look:{fur:'#ffffff',ears:'floppy',fluffy:true,muzzle:'#ffffff',belly:'#ffffff',tail:'plume',scale:.8,acc:['bow']}},
 {id:'scout',name:'Scout',breed:'Bloodhound',area:'ranger',pitch:.75,spot:{x:-22,z:-10,kind:'log'},hint:'Look by a log near the Ranger Station.',
  fact:'Bloodhounds have the best noses of all dogs. They can follow a smell that is days old, so they help find lost people!',rescue:{icon:'👃',verb:'Sniff',say:'Scout is busy sniffing a trail! Tap to help Scout sniff!'},
  look:{fur:'#b8642a',ear:'#8a4a20',ears:'long',earLen:1.4,muzzle:'#8a4a20',muzzleBig:true,wrinkle:true,belly:'#c8743a',tail:'thin',acc:['scarf','glow'],scarfC:'#3fae5a'}},
 {id:'ranger',name:'Ranger',breed:'Belgian Malinois',area:'ranger',pitch:1.05,spot:{x:22,z:12,kind:'tent'},tag:{x:-16,z:28,kind:'bush'},hint:'Ranger plays tag. Look in the tent, then in a bush.',
  fact:'Belgian Malinois are clever, hard-working dogs. They train to help rescue teams and rangers.',rescue:{icon:'⛺',verb:'Unzip',say:'Ranger is zipped up in the tent! Tap to unzip it!'},
  look:{fur:'#c8944a',ear:'#26232e',ears:'pointy',earBig:true,muzzle:'#26232e',belly:'#d8a460',tail:'plume',acc:['cap']}},
 {id:'ladder',name:'Ladder',breed:'Irish Wolfhound',area:'bigrescue',pitch:.7,spot:{x:-22,z:6,kind:'boulder'},hint:'Look behind a big rock at the Big Rescue.',
  fact:'Irish Wolfhounds are the tallest dogs in the world! Standing up, they can be taller than a grown-up.',rescue:{icon:'🪜',verb:'Climb',say:'Ladder is stuck at the top of a rope ladder! Tap to help Ladder down!'},
  look:{fur:'#9a9488',ears:'floppy',fluffy:true,muzzle:'#8a8478',muzzleBig:true,belly:'#a8a090',tail:'thin',hw:58,hh:60,acc:['scarf','glow'],scarfC:'#e8423a'}},
 {id:'rocky',name:'Rocky',breed:'Rottweiler',area:'bigrescue',pitch:.85,spot:{x:22,z:10,kind:'crate'},tag:{x:-14,z:26,kind:'haybale'},hint:'Rocky plays tag. Look in a crate by the helicopter, then by a hay bale.',
  fact:'Rottweilers are strong and loyal. Long ago they pulled carts to market for butchers!',rescue:{icon:'🚁',verb:'Wave',say:'The helicopter is blowing Rocky\'s ears about! Tap to wave to the pilot!'},
  look:{fur:'#26232e',ear:'#26232e',ears:'floppy',muzzle:'#a8642a',brows:'#a8642a',paw:'#a8642a',belly:'#26232e',tail:'stub',hw:60,hh:56,acc:['cap']}}];
const MEDAL={id:'medal',name:'Medal',breed:'Saint Bernard',area:'cove',pitch:1,spot:{x:-10,z:-8,kind:'rockpool'},hint:'A sparkly pup is hiding in Seal Cove.',
  fact:'Medal is a sparkly pup! Saint Bernards are huge, gentle dogs from the Swiss Alps. Long ago they helped monks find travellers lost in the snow. You found a secret pup!',rescue:{icon:'🦭',verb:'Tickle',say:'A seal is snuggled up with Medal! Tap to tickle the seal so it waddles away!'},
  look:{fur:'#ffffff',ear:'#a8502a',ears:'floppy',patch:'#a8502a',bodyPatch:'#a8502a',muzzle:'#ffffff',muzzleBig:true,belly:'#ffffff',tail:'plume',hw:62,hh:56,acc:['twinkle','glow']}};
const BEACON={id:'beaconuni',name:'Beacon',breed:'Rescue Unicorn',uni:true,lv:1,pitch:1.2,fact:'Beacon the Rescue Unicorn shines a light to guide everyone home safely.',
  look:{fur:'#fff6e6',ears:'side',earIn:'#ffc9a8',muzzle:'#ffffff',belly:'#ffffff',nose:'#c08a70',iris:'#e8423a',limbs:'hooves',hoofC:'#ffd23f',tail:'plume',tailFill:'rainbow',acc:['unihorn','rmane','glow'],scale:.96}};
const CHIEF={id:'chief',name:'Chief Woofles',breed:'Boxer',look:{fur:'#c8843a',ear:'#a8642a',ears:'floppy',muzzle:'#26232e',belly:'#ffffff',tail:'stub',hw:60,hh:56},dressAs:'fire'};
const CHIEF_SAY=['Chief Woofles says: every rescuer needs a helmet! Take one from the rack.','Chief Woofles says: Star pups can shine through thick fog. Bring one with you!','Chief Woofles says: the Ranger Station gate has a code. Keep your sums sharp!','Chief Woofles says: the jetty to Seal Cove is broken. A Sky pup from Gadget Island could float a bridge across!','Chief Woofles says: in an emergency in the UK, grown-ups call 999.','Chief Woofles says: Beacon the Rescue Unicorn is at the Big Rescue.'];

/* ----------------- areas ----------------- */
const firestation=RA({id:'firestation',name:'Fire Station',icon:'🚒',R:52,start:[0,32,Math.PI],biome:'gadget',
  hf:(x,z)=>Math.sin(x*.06)*.3+Math.cos(z*.06)*.3,
  hello:'Welcome to Rescue Bay! Two pups are hiding at the Fire Station. Say hello to Chief Woofles!',how:'Take the fire engine over the bridge from the village.',
  exits:[{x:-38,z:-34,to:'harbour',arrive:inw(36,36),name:'Harbour',icon:'⚓',open:()=>foundIn(areaPups('firestation'))>=2,lock:()=>{const n=foundIn(areaPups('firestation'));return `The road to the Harbour is closed. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Fire Station to open it!`;}},
         {x:38,z:-34,to:'townsq',arrive:inw(-36,34),name:'Town Square',icon:'🏙️',open:()=>!!state.gear.helmet,lock:'Rescuers always wear a helmet! Take a fire helmet from the rack at the Fire Station.'}],
  build(){bridgeArrival(0,40);pathTo(0,40,0,-4,5,'#8a8f99');pathTo(-2,-4,-34,-30,4,'#8a8f99');pathTo(2,-4,34,-30,4,'#8a8f99');
    {const fx=0,fz=-18,H=house(fx,fz,{w:18,d:10,h:6,wall:'#e8423a',roof:'#8a3a2a',trim:'#ffffff',win:0,chimney:false,label:'🚒 Fire Station',lw:6});
      for(let i=0;i<3;i++){I('box','#c9c2b8',4,4.6,.2,fx-5.5+i*5.5,H.y+2.3,fz+5.05);for(let k=0;k<4;k++)I('box','#9bdcff',3.6,.5,.22,fx-5.5+i*5.5,H.y+1+k*1.1,fz+5.06);}
      I('box','#e8423a',3,10,3,fx+10.5,H.y+5,fz-2);I('box','#ffffff',3.2,.4,3.2,fx+10.5,H.y+10.2,fz-2);I('pyr','#8a3a2a',2.6,1.6,2.6,fx+10.5,H.y+11.2,fz-2,0,Math.PI/4,0);I('cyl','#ffd23f',.6,.6,.6,fx+10.5,H.y+9,fz-.4,Math.PI/2,0,0);rect(fx+8.8,fz-3.7,fx+12.2,fz-.3);camBlock(fx+8.8,fz-3.7,fx+12.2,fz-.3);}
    {const fe=fireEngine3D();add(fe,-8,2);fe.rotation.y=Math.PI;col(-8,2,2.4);col(-8,-.5,2);col(-8,4.5,2);const fe2=fireEngine3D();add(fe2,8,2);fe2.rotation.y=Math.PI;col(8,2,2.4);col(8,-.5,2);col(8,4.5,2);}
    [[-14,10],[14,10],[-20,-4],[20,-4]].forEach(p=>hydrant(p[0],p[1]));
    {const g=pup3D(CHIEF,false);add(g,-4,10);col(-4,10,1);const l=label('🧑‍🚒 Chief Woofles',4.8);l.position.set(-4,gy(-4,10)+4,10);W.ag.add(l);let k=0;W.ticks.push(()=>{g.rotation.y=Math.atan2(player.x+4,player.z-10);});
      W.things.push({x:-4,z:10,r:4,icon:'💬',label:'Chief',act:()=>{sfx.chime();say(state.gear.helmet?CHIEF_SAY[(k++)%CHIEF_SAY.length]:CHIEF_SAY[0]);}});}
    {const hx=5,hz=10,y=gy(hx,hz);I('box','#9b6a43',3,2.4,.4,hx,y+1.2,hz);[-.9,0,.9].forEach(q=>I('hemi','#e8423a',.45,.4,.5,hx+q,y+1.9,hz+.3));const hl=grp();mk('hemi','#ffd23f',.5,.45,.55,0,0,0,hl);mk('box','#ffd23f',1.2,.08,1.3,0,-.05,0,hl);add(hl,hx,hz+.6,y+2.9);hl.visible=!state.gear.helmet;W.ticks.push(()=>{hl.rotation.y+=.03;});col(hx,hz,1.2);
      W.things.push({x:hx,z:hz+2.2,r:3.4,icon:'⛑️',label:'Fire helmet',show:()=>!state.gear.helmet,act:()=>{state.gear.helmet=true;state.stars+=5;save();hud();hl.visible=false;sfx.jingle();confetti(30);card({art:'<div style="font-size:110px;line-height:1">⛑️</div>',h:'You found a fire helmet!',p:'Now you can help in the Town Square. Its arch is on the right of the Fire Station!'});}});}
    {const tx=-24,tz=-2,y=gy(tx,tz);I('box','#c9c2b8',4,12,4,tx,y+6,tz);for(let i=0;i<4;i++)I('box','#26232e',1.4,1.4,.1,tx,y+2.5+i*2.6,tz+2.05);for(let i=0;i<10;i++)I('box','#ffd23f',.15,.15,1.8,tx+2.1,y+1+i*1.1,tz);rect(tx-2.2,tz-2.2,tx+2.2,tz+2.2);camBlock(tx-2,tz-2,tx+2,tz+2);}
    sign(16,16,'🔥 Hose Hero',3,6);W.things.push({x:15,z:13,r:4,icon:'🔥',label:'Hose Hero',act:()=>{sfx.chime();startFlies('activity','flames');}});
    edgeTrees(52,[angOf(-38,-34),angOf(38,-34),90],['#5fbf5a','#7fcf6a'],null,R);}});

const harbour=RA({id:'harbour',name:'Harbour',icon:'⚓',R:52,start:inw(36,36),
  hf:(x,z)=>Math.sin(x*.05)*.3,hello:'The Harbour! Fishing boats bob on the water and the lifeboat is ready to go. Two pups are hiding here.',how:'Find 2 pups at the Fire Station.',
  exits:[{x:36,z:36,to:'firestation',arrive:inw(-38,-34),name:'Fire Station',icon:'🚒'},
    {x:0,z:-52,to:'lighthouse',arrive:inw(0,48),name:'Lighthouse Cliffs',icon:'🗼',gate:{type:'star',key:'fog_lighthouse',look:'fog',verb:'shines a way through the sea fog',done:'The fog clears! The path to the Lighthouse Cliffs is safe!'},lock:'Thick sea fog hides the cliff path. A Star pup could shine the way!'},
    {x:-52,z:0,to:'cove',arrive:inw(30,0,.7),name:'Seal Cove',icon:'🦭',gate:{type:'sky',key:'cove_gap',look:'gap',need:0,verb:'floats a bridge across the broken jetty',done:'Whoosh! A bridge floats across on balloons. Seal Cove is this way!'},lock:'The jetty to Seal Cove is broken. A Sky pup from Gadget Island could float a bridge across!'}],
  build(){sea(-44,-24,30,-10);[[-30,-12],[-6,-14],[18,-12]].forEach((p,i)=>{for(let k=0;k<6;k++)I('box','#c9905f',2.4,.25,1,p[0],gy(p[0],p[1])+.3,p[1]-1-k*1);});
    boat(-20,-20,'#e8423a',0);boat(4,-19,'#3d8fe0',.2);boat(24,-20,'#ffd23f',-.2);
    {const lx=-12,lz=8,H=house(lx,lz,{w:8,d:6,h:4,wall:'#ffffff',roof:'#3d8fe0',trim:'#e8423a',label:'🛟 Lifeboat Station',lw:5.6});I('box','#ff8a3c',2,1.2,5,lx+7,gy(lx+7,lz)+.6,lz);I('box','#3d8fe0',2.1,.3,5.1,lx+7,gy(lx+7,lz)+1.2,lz);col(lx+7,lz,2.4);}
    house(28,8,{w:7,d:6,wall:'#fff2b8',roof:'#e8423a',face:'w',label:'⚓ Harbour Master',lw:5.6});crane(30,-4,-1);
    for(let i=0;i<5;i++)lobsterPot(-2+i*1.4,2);[[-26,4],[26,24]].forEach(p=>buoy(p[0],p[1],'#ffd23f'));lifeRing(-4,-6,gy(-4,-6)+1.2,.3);
    {const px=-24,pz=22;fence(px-6,pz-5,px+6,pz-5,'#9b6a43');fence(px-6,pz+5,px+6,pz+5,'#9b6a43');fence(px+6,pz-5,px+6,pz+5,'#9b6a43');spr('🦆',1.6,px,gy(px,pz)+1,pz);sign(px-2,pz+7,'🦆 Duckling Rescue',3,7);W.things.push({x:px,z:pz+8,r:4,icon:'🦆',label:'Ducklings',act:()=>{sfx.chime();startHerd('activity','ducklings');}});}
    wanderers(4,()=>duckling(),8,26,4,.35);
    edgeTrees(52,[angOf(36,36),270,180],['#5fbf5a','#7fcf6a'],null,R);}});

const townsq=RA({id:'townsq',name:'Town Square',icon:'🏙️',R:50,start:inw(-36,34),biome:'village',
  hf:(x,z)=>Math.sin(x*.05)*.2,hello:'The Town Square! Remember: stop, look and listen before you cross the road. Two pups are hiding here.',how:'Wear the fire helmet from the Fire Station.',
  exits:[{x:-36,z:34,to:'firestation',arrive:inw(38,-34),name:'Fire Station',icon:'🚒'},
    {x:0,z:-50,to:'ranger',arrive:inw(0,48),name:'Ranger Station',icon:'🌲',nlock:{key:'nl_ranger',kind:['add','take','double'],n:3,done:'Click! The Ranger Station gate swings open!'}}],
  build(){const pl=new THREE.Mesh(G.disc,M('#e0d6c4'));pl.scale.set(12,1,12);pl.position.set(0,gy(0,0)+.06,0);W.ag.add(pl);
    {const y=gy(0,0);I('cyl','#c9c2b8',2.4,.8,2.4,0,y+.4,0);I('cyl','#7fd3f0',2,.1,2,0,y+.82,0,0,0,0,true);I('cyl','#c9c2b8',.3,2,.3,0,y+1.6,0);I('sph','#ffd23f',.5,.5,.5,0,y+2.8,0);col(0,0,2.5);}
    [[-24,-14,'e','🧁 Bakery','#ffe1c9'],[-26,4,'e','📚 Books','#c9e6ff'],[24,-14,'w','💊 Chemist','#d9f5c2'],[26,6,'w','🧸 Toys','#e6d9ff'],[0,-30,'s','🏛️ Town Hall','#fff2b8']].forEach(h=>house(h[0],h[1],{w:8,d:6,h:4.4,wall:h[4],roof:pick(['#e8423a','#5b8def','#3fae5a']),face:h[2],label:h[3],lw:5}));
    zebra(0,18,8,0);trafficLight(-5,16);trafficLight(5,20);pathTo(0,10,0,30,8,'#5b6378');
    {const ax=16,az=24,y=gy(ax,az),g=grp();mk('box','#ffffff',2.4,2.4,5,0,1.6,0,g);mk('box','#ffffff',2.4,1.4,1.8,0,1,3.2,g);mk('box','#9bdcff',2.3,.7,.1,0,1.5,4.1,g);mk('box','#3fae5a',2.42,.3,5,0,1.3,0,g);mk('box','#ffd23f',2.42,.3,5,0,1.7,0,g);mk('cyl','#3d8fe0',.18,.2,.18,0,2.9,1,g);
      [[-1.2,-1.5],[1.2,-1.5],[-1.2,2.8],[1.2,2.8]].forEach(q=>mk('cyl','#26232e',.5,.35,.5,q[0],.5,q[1],g).rotation.z=Math.PI/2);add(g,ax,az,y);g.rotation.y=.4;col(ax,az,2.6);}
    bunting(-12,-8,12,-8,5);[[-12,-8],[12,-8]].forEach(p=>lampPost(p[0],p[1]));bench(-8,8,'e');bench(8,8,'w');planter(-6,-6);planter(6,-6,'#ff9ecb');
    sign(-8,24,'🛟 Safety Quiz',3,6);W.things.push({x:-9,z:21,r:4,icon:'🦺',label:'Safety Quiz',act:()=>{sfx.chime();startQuiz('activity','safety');}});
    edgeTrees(50,[angOf(-36,34),270],['#5fbf5a','#7fcf6a'],null,R);}});

const lighthouse_=RA({id:'lighthouse',name:'Lighthouse Cliffs',icon:'🗼',R:50,start:inw(0,48),sky:'#a9d8ff',
  hf:(x,z)=>4*Math.exp(-(x*x+(z+20)*(z+20))/400)+Math.sin(x*.1)*.3,hello:'The Lighthouse Cliffs! The lighthouse shines all night to keep ships safe. Two pups are hiding here.',how:'A Star pup shines through the sea fog at the Harbour.',
  exits:[{x:0,z:50,to:'harbour',arrive:inw(0,-52),name:'Harbour',icon:'⚓'},
    {x:36,z:-34,to:'bigrescue',arrive:inw(-38,30),name:'Big Rescue',icon:'🚁',open:()=>foundIn(areaPups('lighthouse'))>=2,lock:()=>{const n=foundIn(areaPups('lighthouse'));return `The cliff path is too windy. Find ${2-n} more ${2-n>1?'pups':'pup'} on the Lighthouse Cliffs first!`;}}],
  build(){lighthouse(0,-22,1);house(-12,-14,{w:7,d:6,h:4,wall:'#ffffff',roof:'#3d8fe0',face:'e',label:'🏠 Keeper\'s Cottage',lw:5.6});
    sea(-50,-50,50,-38);[[-34,-28],[-20,-34],[18,-32],[30,-24],[-30,14],[32,18]].forEach(p=>rockyCliff(p[0],p[1],1));
    [[-6,-38],[10,-40]].forEach((p,i)=>{const s=sprite('🦭',1.6);W.ag.add(s);W.ticks.push(()=>s.position.set(p[0]+Math.sin(W.t*.6+i)*1.5,Math.max(gy(p[0],p[1]),W.area.seaDip?W.area.sea.y:-9)+.6,p[1]));});
    for(let i=0;i<8;i++)I('box','#c9905f',1.6,.2,1,-4+(i%2)*.5,gy(-4,-4)+.12+i*.0,-6+i*1.6);
    sign(8,-4,'🪜 Lighthouse Steps',3,7);W.things.push({x:9,z:-7,r:4,icon:'🪜',label:'Steps',act:()=>{sfx.chime();startStones('activity','stairs');}});
    edgeTrees(50,[90,angOf(36,-34)],['#5fbf5a','#7fa858'],null,R);}});

const ranger=RA({id:'ranger',name:'Ranger Station',icon:'🌲',R:50,start:inw(0,48),ground:'#7fbf5a',ground2:'#8fcf6a',sky:'#c9ecd0',biome:'meadow',
  hf:(x,z)=>Math.sin(x*.08)*.8+Math.cos(z*.07)*.7,hello:'The Ranger Station! Rangers help anyone who gets lost in the forest. Two pups are hiding here.',how:'Crack the code lock in the Town Square.',
  exits:[{x:0,z:50,to:'townsq',arrive:inw(0,-50),name:'Town Square',icon:'🏙️'},
    {x:-36,z:-34,to:'bigrescue',arrive:inw(38,30),name:'Big Rescue',icon:'🚁',open:()=>foundIn(areaPups('ranger'))>=2,lock:()=>{const n=foundIn(areaPups('ranger'));return `A fallen tree blocks the trail. Find ${2-n} more ${2-n>1?'pups':'pup'} at the Ranger Station and the rangers will move it!`;}}],
  build(){{const hx=0,hz=-18,y=gy(hx,hz);[[-3,-2.5],[3,-2.5],[-3,2.5],[3,2.5]].forEach(q=>I('cyl','#5b4636',.3,3,.3,hx+q[0],y+1.5,hz+q[1]));I('box','#9b6a43',7,4,6,hx,y+5,hz);I('pyr','#3fae5a',5.6,2,4.6,hx,y+8,hz,0,Math.PI/4,0);
      for(let i=0;i<6;i++)I('box','#9b6a43',2,.2,.6,hx,y+.4+i*.55,hz+3.3+i*.5);rect(hx-3.6,hz-3.2,hx+3.6,hz+3.2);camBlock(hx-3.6,hz-3.2,hx+3.6,hz+3.2);const l=label('🌲 Ranger Station',6);l.position.set(hx,y+11,hz);W.ag.add(l);}
    {const tx=22,tz=-16,y=gy(tx,tz);[[-1.5,-1.5],[1.5,-1.5],[-1.5,1.5],[1.5,1.5]].forEach(q=>I('cyl','#5b4636',.2,10,.2,tx+q[0],y+5,tz+q[1]));I('box','#9b6a43',4,2,4,tx,y+11,tz);I('pyr','#e8423a',3.4,1.4,3.4,tx,y+12.7,tz,0,Math.PI/4,0);col(tx,tz,2.2);}
    [[-20,10],[16,24],[-26,-20]].forEach((p,i)=>{const y=gy(p[0],p[1]);I('cone',['#ff8a3c','#3d8fe0','#ffd23f'][i],2,2,2,p[0],y+1,p[1]);col(p[0],p[1],1.6);});
    {const cx=-6,cz=10,y=gy(cx,cz);for(let i=0;i<8;i++){const a=i/8*6.283;I('sphL','#8a8378',.4,.3,.4,cx+Math.cos(a)*1.2,y+.15,cz+Math.sin(a)*1.2);}for(let i=0;i<3;i++)I('cyl','#6b4028',.12,1.6,.12,cx,y+.3,cz,0,i*1.05,Math.PI/2);I('box','#9b6a43',2.4,.4,.6,cx+3,y+.3,cz);col(cx,cz,1.4);}
    signpost(8,4,[['🏙️ Town ↓','#fff2b8'],['🚁 Big Rescue ↖','#ffd9c9']]);
    for(let i=0;i<26;i++){const a=R()*6.283,r=14+R()*30,x=Math.cos(a)*r,z=Math.sin(a)*r;if(Math.hypot(x,z-38)<15||Math.hypot(x-15,z+33)<8||Math.hypot(x+36,z+34)<10||Math.hypot(x-22,z+16)<4||Math.hypot(x,z+18)<7||COLLECT.kittens.items.some(q=>Math.hypot(q[0]-x,q[1]-z)<4)||Math.hypot(x-22,z-12)<4||Math.hypot(x+22,z+10)<4||Math.hypot(x+16,z-28)<4||Math.hypot(x+6,z-10)<4||Math.hypot(x-8,z-4)<4)continue;tree(x,z,1+R()*.4,pick(['#3f8e4a','#4fae4a']),'pine');}
    sign(-12,24,'🐱 Kitten Rescue',3,6);W.things.push({x:-11,z:21,r:4,icon:'🐱',label:'Kitten Rescue',act:()=>{sfx.chime();startCollect('kittens');}});
    edgeTrees(50,[90,angOf(-36,-34)],['#3f8e4a','#4fae4a'],'pine',R);}});

const bigrescue=RA({id:'bigrescue',name:'Big Rescue',icon:'🚁',R:48,start:inw(-38,30),sky:'#9ab8d8',
  hf:(x,z)=>3*Math.exp(-(x*x+(z+22)*(z+22))/450)+Math.sin(x*.1)*.3,hello:'The Big Rescue! The storm has passed, and everyone is helping out. Two pups are hiding here.',how:'Find 2 pups on the Lighthouse Cliffs or at the Ranger Station.',
  exits:[{x:-38,z:30,to:'lighthouse',arrive:inw(36,-34),name:'Lighthouse Cliffs',icon:'🗼'},{x:38,z:30,to:'ranger',arrive:inw(-36,-34),name:'Ranger Station',icon:'🌲'}],
  build(){sea(-48,-48,48,-36);rockyCliff(-8,-30,1.4);rockyCliff(10,-32,1.2);
    {const hx=20,hz=-6,y=gy(hx,hz);I('cyl','#c9c2b8',4,.3,4,hx,y+.15,hz);const m=new THREE.Mesh(G.plane,M('#ffd23f'));m.scale.set(1,1,3);m.position.set(hx,y+.32,hz);W.ag.add(m);
      const h=grp();mk('sph','#e8423a',1.6,1.4,2.4,0,1.6,0,h);mk('sph','#9bdcff',1,.9,1.2,0,1.9,1.4,h);mk('box','#e8423a',.5,.5,4,0,1.8,-3,h);mk('box','#26232e',.1,1.4,.6,.25,2.4,-4.8,h);[-1,1].forEach(q=>mk('box','#26232e',.15,.15,3.6,q*1,.2,0,h));const rot=grp();mk('box','#26232e',7,.08,.4,0,0,0,rot);mk('box','#26232e',.4,.08,7,0,0,0,rot);rot.position.y=3.3;h.add(rot);add(h,hx,hz,y+.3);W.ticks.push(dt=>{rot.rotation.y+=dt*4;});col(hx,hz,3);}
    {const bx=-20,bz=-6;boat(bx,bz,'#ff8a3c',.6);}
    [[-28,14],[26,16],[-4,24]].forEach(p=>buoy(p[0],p[1],'#ff8a3c'));
    sign(-6,10,'🛟 Life Ring Rescue',3,7);W.things.push({x:-5,z:7,r:4,icon:'🛟',label:'Life Rings',act:()=>{sfx.chime();startCollect('rings');}});
    edgeTrees(48,[angOf(-38,30),angOf(38,30)],['#5fbf5a','#7fa858'],null,R);}});

const cove={id:'cove',name:'Seal Cove',icon:'🦭',R:32,ground:'#e8d9a8',ground2:'#f2e6c0',sky:'#a9d8ff',fog:[40,140],fogC:'#cfe8f5',hedgeC:'#8a8378',noEnrich:true,start:inw(30,0,.7),hf:()=>0,
  hello:'Seal Cove! The seals are sunbathing on the rocks. A secret sparkly pup and a treasure chest are hidden here!',how:'A Sky pup from Gadget Island floats a bridge across the broken jetty at the Harbour.',
  exits:[{x:32,z:0,to:'harbour',arrive:inw(-52,0,.85),name:'Harbour',icon:'⚓'}],
  build(){sea(-32,-32,10,-18);[[-20,-14],[-4,-16],[6,-14]].forEach((p,i)=>{I('sphL','#8a8378',2.4,1,1.8,p[0],.4,p[1]);const s=sprite('🦭',1.8);s.position.set(p[0],1.6,p[1]);W.ag.add(s);col(p[0],p[1],2);});
    for(let i=0;i<8;i++){const a=R()*6.283,r=6+R()*16,x=Math.cos(a)*r,z=Math.sin(a)*r+6;if(x>18)continue;spr(pick(['🐚','⭐','🦀']),.8,x,.4,z);}
    [[-18,10],[-8,20],[8,18]].forEach(p=>rockyCliff(p[0],p[1],.7));treasureChest(8,4,'cove');}};

/* ----------------- activities ----------------- */
const fireSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#ffe1c9"/><rect y="560" width="1024" height="208" fill="#c9c2b8"/>`;for(let i=0;i<5;i++)s+=`<rect x="${40+i*200}" y="200" width="160" height="360" fill="#e8d9c4" stroke="${k}" stroke-width="4"/><rect x="${70+i*200}" y="240" width="100" height="80" fill="#9bdcff" stroke="${k}" stroke-width="3"/>`;
  return s+`<text x="900" y="720" font-size="80">🚒</text><text x="40" y="720" font-size="70">🧯</text></svg>`;};
const duckPenSVG=()=>{let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#9fd87a"/><rect width="1024" height="150" fill="#5fc4f0"/>`;for(let i=0;i<30;i++)s+=`<circle cx="${(i*151)%1010+8}" cy="${160+(i*83)%590}" r="${3+i%4}" fill="#8fc86a"/>`;return s+penBox2('🦆 Mummy Duck','#bfeaff','#9b6a43','#5b4636')+`<text x="${PEN.x1+110}" y="${(PEN.y1+PEN.y2)/2+30}" font-size="80">🦆</text></svg>`;};
function duckSVG(){const k=INK;return `<svg viewBox="0 0 90 90"><g stroke="${k}" stroke-width="3.5"><ellipse cx="44" cy="58" rx="28" ry="20" fill="#ffd23f"/><circle cx="58" cy="32" r="16" fill="#ffd23f"/><path d="M72 32 l14 4 l-14 6z" fill="#ff8a3c"/></g><circle cx="62" cy="28" r="3.5" fill="${k}"/><path d="M28 52 q10 10 24 2" stroke="#e8b800" stroke-width="4" fill="none"/></svg>`;}
const stairsSVG=()=>{const k=INK;let s=`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#5fc4f0"/><rect width="1024" height="150" fill="#a9d8ff"/>`;for(let i=0;i<20;i++)s+=`<path d="M${(i*157)%980} ${200+(i*73)%540} q20 -10 40 0" stroke="#fff" stroke-width="4" fill="none" opacity=".6"/>`;
  s+=`<path d="M0 150 H120 Q150 400 120 768 H0Z" fill="#9a9488" stroke="${k}" stroke-width="5"/><path d="M1024 150 H904 Q874 400 904 768 H1024Z" fill="#9a9488" stroke="${k}" stroke-width="5"/>`;return s+`<text x="964" y="140" font-size="44" text-anchor="middle">🗼</text></svg>`;};
CATCH.flames={k:'flames',icon:'🔥',need:15,bg:fireSVG,cls:'',inner:'<b>🔥</b>',art:'🧑‍🚒💦',intro:'Hose Hero! Tap a flame while it flickers to spray it with water. Put out 15 flames!',tip:'Wait until it flickers, then tap!',title:'You put out 15 flames! Super firefighter!'};
HERDS.ducklings={k:'ducklings',icon:'🦆',n:6,animal:duckSVG,herder:()=>buddyPup(),bg:duckPenSVG,title:'All the ducklings are safe with Mummy Duck!',
  intro:p=>`The ducklings have wandered away from Mummy Duck! Help ${p.name} guide them home. Drag your finger and ${p.name} will follow. The ducklings waddle away from ${p.name}!`};
COUNTS.stairs={k:'stairs',icon:'🪜',rounds:[{step:4,word:'fours'},{step:8,word:'eights'},{start:50,step:-5,word:'fives, going down'}],bg:stairsSVG,cls:'stone',intro:'Climb the lighthouse steps! Hop across the stones and count the jumps.',title:'You climbed the lighthouse! What a view!'};
QUIZ.safety={k:'safety',name:'Safety Quiz',icon:'🦺',n:8,bg:()=>`<svg viewBox="0 0 1024 768"><rect width="1024" height="768" fill="#fff6e0"/>${Array.from({length:8},(_,i)=>`<rect x="${i*130}" y="700" width="70" height="68" fill="#26232e" opacity=".15"/>`).join('')}</svg>`,
  intro:'The Rescue Bay Safety Quiz! Let us learn how to stay safe, just like the rescue pups.',
  make:i=>{const Q=[{q:'In an emergency in the UK, which number do you call?',say:'In an emergency in the UK, which number do you call?',pic:'<div style="font-size:100px">☎️</div>',ans:'999',opts:['999','123','100'],hintSay:'It is the same number three times.'},
    {q:'Before you cross the road, you should...',say:'Before you cross the road, what should you do?',pic:'<div style="font-size:100px">🚸</div>',ans:'Stop, look and listen',opts:['Stop, look and listen','Run across fast','Close your eyes'],hintSay:'Stop at the kerb, look both ways, and listen for cars.'},
    {q:'If there is smoke in a room, you should...',say:'If there is smoke in a room, what should you do?',pic:'<div style="font-size:100px">💨</div>',ans:'Get down low and get out',opts:['Get down low and get out','Hide under the bed','Open the cupboard'],hintSay:'Smoke rises, so the clean air is down low. Get out and stay out!'},
    {q:'If you find matches or a lighter, you should...',say:'If you find matches or a lighter, what should you do?',pic:'<div style="font-size:100px">🙅</div>',ans:'Tell a grown-up',opts:['Tell a grown-up','Try them out','Hide them'],hintSay:'Never touch them. Tell a grown-up straight away.'},
    {q:'What does a <b>red</b> traffic light mean?',say:'What does a red traffic light mean?',pic:'<div style="font-size:100px">🚦</div>',ans:'Stop',opts:['Stop','Go','Hurry up'],hintSay:'Red means wait. Green means go.'},
    {q:'What should you wear when you ride your bike?',say:'What should you wear when you ride your bike?',pic:'<div style="font-size:100px">🚲</div>',ans:'A helmet',opts:['A helmet','A crown','Flippers'],hintSay:'It keeps your head safe if you fall.'},
    {q:'Where is the safest place to cross the road?',say:'Where is the safest place to cross the road?',pic:'<div style="font-size:100px">🦓</div>',ans:'At a zebra crossing',opts:['At a zebra crossing','Between parked cars','On a bend'],hintSay:'Look for the black and white stripes.'},
    {q:'When the smoke alarm beeps, you should...',say:'When the smoke alarm beeps, what should you do?',pic:'<div style="font-size:100px">🚨</div>',ans:'Get out and stay out',opts:['Get out and stay out','Keep playing','Go back for toys'],hintSay:'Toys can be replaced. Get out, stay out, and a grown-up calls 999.'}][i];Q.opts=shuffle(Q.opts.slice());return Q;},
  block:()=>'⭐',title:'You are a safety superstar!'};
COLLECT.kittens={k:'kittens',area:'ranger',icon:'🐱',size:2,items:[[-26,2],[26,-2],[-10,-30],[14,32],[-30,22],[28,-28]],start:[-10,20,Math.PI],thing:'lost kitten',art:'🐱',
  intro:'Kitten Rescue! Six kittens are lost in the forest. Find them all and bring them back to the Ranger Station!',title:'All six kittens are safe! Brilliant rescue!'};
COLLECT.rings={k:'rings',area:'bigrescue',icon:'🛟',size:2,items:[[-28,0],[28,4],[-16,20],[14,26],[0,-14],[-30,-16]],start:[-6,8,Math.PI],thing:'life ring',art:'🛟',
  intro:'The storm washed the life rings off the beach! Collect all 6 and put them back for the lifeguards.',title:'All the life rings are back! The beach is safe!'};
regAct('flames',{name:'Hose Hero',icon:'🔥',island:'rescue',area:'firestation',where:'the Fire Station',play:()=>startFlies('arcade','flames')});
regAct('ducklings',{name:'Duckling Rescue',icon:'🦆',island:'rescue',area:'harbour',where:'the Harbour',play:()=>startHerd('arcade','ducklings')});
regAct('safety',{name:'Safety Quiz',icon:'🦺',island:'rescue',area:'townsq',where:'the Town Square',play:()=>startQuiz('arcade','safety')});
regAct('stairs',{name:'Lighthouse Steps',icon:'🪜',island:'rescue',area:'lighthouse',where:'the Lighthouse Cliffs',play:()=>startStones('arcade','stairs')});
regAct('kittens',{name:'Kitten Rescue',icon:'🐱',island:'rescue',area:'ranger',where:'the Ranger Station',play:()=>arcadeTravel('ranger',COLLECT.kittens.start,()=>startCollect('kittens'),'Kitten Rescue is about to start!')});
regAct('rings',{name:'Life Ring Rescue',icon:'🛟',island:'rescue',area:'bigrescue',where:'the Big Rescue',play:()=>arcadeTravel('bigrescue',COLLECT.rings.start,()=>startCollect('rings'),'Life Ring Rescue is about to start!')});

regIsland({id:'rescue',name:'Rescue Bay',icon:'🚒',type:'star',req:['ninja','number'],rideName:'The fire engine',ride:'the fire engine',from:'fire station in the village',rideIcon:'🚒',rideSay:'Nee naw! The fire engine races over the bridge to Rescue Bay!',
  homeSay:'The fire engine drives back over the bridge to the village!',homePos:[27,31,Math.atan2(7,3)],
  badge:'Rescue Badge',cert:'Seb, Rescue Bay Hero!',bossHint:'Beacon the Rescue Unicorn is waiting at the Big Rescue!',
  nextSay:'Hooray! Rescue Bay is safe! Have you been to Gadget Island too?',
  map:{shape:'M80 410 L120 150 L300 90 L560 90 L740 150 L780 410 Q600 470 430 460 Q260 470 80 410Z',
    nodes:{firestation:[430,350],harbour:[230,260],townsq:[630,260],lighthouse:[200,120],ranger:[660,120],bigrescue:[430,80],cove:[95,345]},
    links:[['firestation','harbour'],['firestation','townsq'],['harbour','lighthouse'],['townsq','ranger'],['lighthouse','bigrescue'],['ranger','bigrescue'],['harbour','cove']]},
  boss:{area:'bigrescue',x:0,z:-16,perch:0,uni:BEACON,
    story:[['m','Muddle the Magpie waves from a ledge on the cliff. "Help, Seb! I flew too close to the storm chasing the shiny Rescue Star, and now I am stuck! I was so busy grabbing it that I scared all the pups away."'],
      ['u','Beacon the Rescue Unicorn shines a bright light, and the rescue pups lift Muddle safely down. "Everyone needs help sometimes, Muddle. A true hero helps without being asked. Now give back the shiny Rescue Star."'],
      ['b','Muddle says a big thank you and gives back the Rescue Star, and all 12 Star pups cheer! Chief Woofles rings the fire bell, and Beacon gives Seb the Rescue Badge.']],
    after:['Beacon says: thank you for finding every pup in Rescue Bay!','Muddle says: thank you for rescuing me! I will help you next time.','Beacon says: look, the lighthouse is shining just for you!']},
  pups:P,bonus:[MEDAL],areas:[firestation,harbour,townsq,lighthouse_,ranger,bigrescue,cove]});

/* ----- Release 7 badges and certificates ----- */
MERITS.push(
  {id:'gadget',icon:'⚙️',name:'Gadget Hero',how:'Find all 12 pups on Gadget Island.',ok:()=>!!state.islDone.gadget},
  {id:'rescue',icon:'🚒',name:'Rescue Hero',how:'Find all 12 pups in Rescue Bay.',ok:()=>!!state.islDone.rescue},
  {id:'goggles',icon:'🥽',name:'Safety First',how:'Find the safety goggles and the fire helmet.',ok:()=>!!(state.gear.goggles&&state.gear.helmet)},
  {id:'skypower',icon:'☁️',name:'Sky Power',how:'Use a Sky pup to float a bridge across a gap.',ok:()=>!!(state.vines.mine_gap||state.vines.cove_gap)},
  {id:'starpower',icon:'⭐',name:'Star Power',how:'Use a Star pup to shine through the fog.',ok:()=>!!(state.vines.fog_lighthouse||state.vines.vault_fog)},
  {id:'chrome',icon:'✨',name:'Shiny Find',how:'Find the sparkly pup in the Invention Vault.',ok:()=>isFound('chrome')},
  {id:'medal',icon:'🏅',name:'Cove Explorer',how:'Find the sparkly pup in Seal Cove.',ok:()=>isFound('medal')});
CERTS.push(
  {id:'gadget',icon:'⚙️',title:'Gadget Island Hero',why:'for finding all 12 pups on Gadget Island',ok:()=>!!state.islDone.gadget},
  {id:'rescue',icon:'🚒',title:'Rescue Bay Hero',why:'for finding all 12 pups in Rescue Bay',ok:()=>!!state.islDone.rescue},
  {id:'safety',icon:'🦺',title:'Safety Superstar',why:'for finishing the Safety Quiz',ok:()=>!!(state.acts||{}).safety});
})();
