/* Seb's Puppy Quest website: offline copy of Puppy Quest 2.
   Made by the site build; the version and file list change with every build, which is how the iPad notices an update.
   A new version downloads in the background and takes over once this part of the site is not open (it never mixes files of two versions). */
const V='pq2-32ba3a0cbe58';
const FILES=["index.html", "version.json"];
const ROOT=false;
const BASE=new URL('./',self.location).pathname;

self.addEventListener('install',e=>{
  e.waitUntil(caches.open(V).then(c=>Promise.all(FILES.map(f=>
    fetch(new Request(f+'?v='+V,{cache:'reload'})).then(r=>{if(!r.ok)throw new Error('Could not fetch '+f);return c.put(f,r);})))));
});

self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('pq2-')&&k!==V).map(k=>caches.delete(k))))
    .then(()=>self.clients.claim()));
});

self.addEventListener('fetch',e=>{
  const q=e.request;if(q.method!=='GET')return;
  const u=new URL(q.url);if(u.origin!==self.location.origin||!u.pathname.startsWith(BASE))return;
  let rel=decodeURIComponent(u.pathname.slice(BASE.length));if(rel===''||rel.endsWith('/'))rel+='index.html';
  if(FILES.includes(rel)){
    e.respondWith(caches.open(V).then(c=>c.match(rel)).then(r=>r||fetch(q)));
  }else if(ROOT){
    /* the front page: anything else (such as a game's version note) from the internet, or from a game's offline copy */
    e.respondWith(fetch(q).catch(()=>caches.match(u.pathname+(u.pathname.endsWith('/')?'index.html':''),{ignoreSearch:true})
      .then(r=>r||new Response('',{status:504}))));
  }
});
