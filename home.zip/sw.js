/* Seb's Puppy Quest website: offline copy of the front page.
   Made by the site build; the version and file list change with every build, which is how the iPad notices an update.
   A new version downloads in the background and takes over once this part of the site is not open (it never mixes files of two versions). */
const V='home-9d7f05af4253';
const FILES=["art/pq2_coco.svg", "art/pq2_dotty.svg", "art/pq3_buttercup.svg", "art/pq3_cali.svg", "art/seb.svg", "icons/icon-180.png", "icons/icon-192.png", "icons/icon-512.png", "icons/icon-maskable-512.png", "index.html", "manifest.webmanifest", "robots.txt", "saga.js"];
const ROOT=true;
const BASE=new URL('./',self.location).pathname;

self.addEventListener('install',e=>{
  e.waitUntil(caches.open(V).then(c=>Promise.all(FILES.map(f=>
    fetch(new Request(f+'?v='+V,{cache:'reload'})).then(r=>{if(!r.ok)throw new Error('Could not fetch '+f);return c.put(f,r);})))));
});

self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k.startsWith('home-')&&k!==V).map(k=>caches.delete(k))))
    .then(()=>self.clients.claim()));
});

self.addEventListener('fetch',e=>{
  const q=e.request;if(q.method!=='GET')return;
  const u=new URL(q.url);if(u.origin!==self.location.origin||!u.pathname.startsWith(BASE))return;
  let rel=decodeURIComponent(u.pathname.slice(BASE.length));if(rel===''||rel.endsWith('/'))rel+='index.html';
  if(FILES.includes(rel)){
    e.respondWith(caches.open(V).then(c=>c.match(rel)).then(r=>r||fetch(q)));
  }else if(ROOT){
    /* the front page: anything else (such as a game's version note) from the internet, or from a game's offline copy */
    e.respondWith(fetch(q).catch(()=>caches.match(u.pathname+(u.pathname.endsWith('/')?'index.html':''),{ignoreSearch:true})
      .then(r=>r||new Response('',{status:504}))));
  }
});
