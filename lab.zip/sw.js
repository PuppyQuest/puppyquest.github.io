/* Puppy Quest Lab helper: serves an unlocked test game from this device's own cache.
   Only paths under play/<id>/ are handled; anything missing sends a page back to the Lab's PIN screen. */
const BASE=new URL('./',self.location).pathname;
self.addEventListener('install',()=>self.skipWaiting());
self.addEventListener('activate',e=>e.waitUntil(self.clients.claim()));
self.addEventListener('fetch',e=>{
  const u=new URL(e.request.url);
  if(u.origin!==self.location.origin||!u.pathname.startsWith(BASE+'play/'))return;
  let path=u.pathname;if(path.endsWith('/'))path+='index.html';
  const id=path.slice((BASE+'play/').length).split('/')[0];
  e.respondWith(caches.open('lab-'+id).then(c=>c.match(u.origin+path,{ignoreSearch:true})).then(r=>{
    if(r)return r;
    if(e.request.mode==='navigate')return Response.redirect(BASE,302);
    return new Response('',{status:404});
  }));
});
