/* Puppy Quest Lab: unlock with the PIN, list the test games, and unscramble one into this device's own cache.
   Each test game is <id>.bin (12-byte IV, then AES-GCM of a gzipped JSON bundle of the game's files) with <id>.json beside it.
   The key comes from the PIN (PBKDF2, SHA-256). The Lab helper (sw.js) serves play/<id>/... from the cache "lab-<id>". */
(function(){
  const SALT='69Tw6jDjsK3C0qw8ybHt2Q==',CHECK='lQTALZvCfk905Vga1aqHkxJKJKA4QxAsyEsznSBrEPg1jUcVugKjL7gFjuS9Ow==',ITER=300000;
  const IDS=['kit','pq1','pq3','pq4','pq5','pq6','pq7','pq8','pq9','pq10','pq11'];
  const TYPES={html:'text/html',js:'text/javascript',css:'text/css',json:'application/json',svg:'image/svg+xml',png:'image/png',
    jpg:'image/jpeg',jpeg:'image/jpeg',webp:'image/webp',gif:'image/gif',mp3:'audio/mpeg',m4a:'audio/mp4',wav:'audio/wav',ogg:'audio/ogg',txt:'text/plain',md:'text/plain'};
  const $=s=>document.querySelector(s),enc=new TextEncoder(),dec=new TextDecoder();
  const b64=s=>Uint8Array.from(atob(s),c=>c.charCodeAt(0));
  let KEY=null,pin='',busy=false;

  async function keyFor(p){
    const base=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveKey']);
    return crypto.subtle.deriveKey({name:'PBKDF2',salt:b64(SALT),iterations:ITER,hash:'SHA-256'},base,{name:'AES-GCM',length:256},false,['decrypt']);
  }
  async function unseal(key,bytes){const u=new Uint8Array(bytes);return crypto.subtle.decrypt({name:'AES-GCM',iv:u.slice(0,12)},key,u.slice(12));}
  async function tryPin(p){try{const k=await keyFor(p);return dec.decode(await unseal(k,b64(CHECK)))==='puppy-quest-lab-ok'?k:null;}catch(e){return null;}}
  async function gunzip(buf){return new Response(new Blob([buf]).stream().pipeThrough(new DecompressionStream('gzip'))).text();}
  async function clearPlay(){try{const ks=await caches.keys();await Promise.all(ks.filter(k=>k.startsWith('lab-')).map(k=>caches.delete(k)));}catch(e){}}
  function msg(t){$('#msg').textContent=t||'';}
  function dots(){[...$('#dots').children].forEach((d,i)=>d.classList.toggle('on',i<pin.length));}

  /* the number pad */
  const pad=$('#pad');
  ['1','2','3','4','5','6','7','8','9','⌫','0','✓'].forEach(k=>{const b=document.createElement('button');b.textContent=k;b.onclick=()=>key(k);pad.appendChild(b);});
  async function key(k){
    if(busy)return;msg('');
    if(k==='⌫'){pin=pin.slice(0,-1);dots();return;}
    if(k==='✓'){if(pin.length===6)check();return;}
    if(pin.length<6){pin+=k;dots();if(pin.length===6)check();}
  }
  async function check(){
    busy=true;msg('Checking…');const k=await tryPin(pin);busy=false;
    if(!k){msg('That PIN is not right.');const d=$('#dots');d.classList.remove('shake');void d.offsetWidth;d.classList.add('shake');pin='';dots();return;}
    if($('#rem').checked){try{localStorage.setItem('lab_pin',pin);}catch(e){}}
    pin='';dots();unlocked(k);
  }

  /* the list of test games */
  async function unlocked(k){
    KEY=k;$('#lock').hidden=true;$('#list').hidden=false;msg('');
    const box=$('#games');box.innerHTML='<p class="note">Looking for test games…</p>';
    const found=[];
    await Promise.all(IDS.map(async id=>{try{const r=await fetch(id+'.json?t='+Date.now(),{cache:'no-store'});if(r.ok){const j=await r.json();j.id=id;found.push(j);}}catch(e){}}));
    found.sort((a,b)=>IDS.indexOf(a.id)-IDS.indexOf(b.id));
    box.innerHTML=found.length?'':'<p class="note">No test games here yet.</p>';
    found.forEach(g=>{const d=document.createElement('div');d.className='game';
      d.innerHTML=`<div class="t"><b></b><span></span></div><button>▶ Play</button>`;
      d.querySelector('b').textContent=g.title||g.id;d.querySelector('span').textContent=`Built ${g.date||''} · ${Math.round((g.bytes||0)/1024)} KB`;
      d.querySelector('button').onclick=()=>play(g,d.querySelector('button'));box.appendChild(d);});
  }

  async function play(g,btn){
    if(busy)return;busy=true;const old=btn.textContent;btn.textContent='⏳ Getting ready';
    try{
      const base=new URL('play/'+g.id+'/',location.href).href,name='lab-'+g.id;
      let c=await caches.open(name),m=await c.match(base+'__lab.json');
      const have=m&&(await m.json()).stamp===g.stamp;
      if(!have){
        const r=await fetch(g.id+'.bin?t='+Date.now(),{cache:'no-store'});if(!r.ok)throw new Error('The test game file is missing.');
        const bundle=JSON.parse(await gunzip(await unseal(KEY,await r.arrayBuffer())));
        await caches.delete(name);c=await caches.open(name);
        for(const [path,f] of Object.entries(bundle.files)){
          const ext=(path.split('.').pop()||'').toLowerCase(),body=f.t==='b64'?b64(f.d):f.d;
          await c.put(new Request(base+path),new Response(body,{headers:{'Content-Type':(TYPES[ext]||'application/octet-stream')+(f.t==='b64'?'':';charset=utf-8')}}));
        }
        await c.put(new Request(base+'__lab.json'),new Response(JSON.stringify({stamp:g.stamp}),{headers:{'Content-Type':'application/json'}}));
      }
      await navigator.serviceWorker.register('sw.js',{scope:'./'});await navigator.serviceWorker.ready;
      location.href=base+'index.html';
    }catch(e){busy=false;btn.textContent=old;const n=document.createElement('p');n.className='note';n.style.color='#c0392b';
      n.textContent='Could not open it ('+(e.message||e)+'). Check the internet and try again.';btn.closest('.game').after(n);}
  }

  $('#lockBtn').onclick=async()=>{try{localStorage.removeItem('lab_pin');}catch(e){}KEY=null;await clearPlay();$('#list').hidden=true;$('#lock').hidden=false;$('#pad').hidden=false;msg('Locked.');};

  /* start: register the helper, then unlock straight away if the PIN is remembered, or clear any unlocked copies */
  (async function(){
    if(!('serviceWorker' in navigator)||!window.crypto||!crypto.subtle||!window.DecompressionStream){msg('This browser cannot open the Lab. Please update it.');pad.hidden=true;return;}
    try{await navigator.serviceWorker.register('sw.js',{scope:'./'});}catch(e){}
    let p=null;try{p=localStorage.getItem('lab_pin');}catch(e){}
    if(p){$('#rem').checked=true;const k=await tryPin(p);if(k)return unlocked(k);try{localStorage.removeItem('lab_pin');}catch(e){}}
    await clearPlay();
  })();
})();
